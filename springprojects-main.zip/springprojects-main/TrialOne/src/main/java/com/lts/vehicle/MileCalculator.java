package com.lts.vehicle;

public interface MileCalculator {
	public String showMileage();

}
