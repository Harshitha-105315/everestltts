package com.example.training;

public class GreetServiceImpl implements GreetService {
	public String greet(String name) {
		// TODO Auto-generated method stub
		return "welcome"+" " +name;
	}
}
