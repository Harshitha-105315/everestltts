module hotelapp {
	requires java.base;
}