package com.sportsapp.exceptions;

public class SportNotFoundException extends RuntimeException {

	public SportNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SportNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	


	
	

}
