function abc() {
    return 3;
}

require('dotenv').config();
// Get Selenium and the drivers
var seleniumServer = require('selenium-server');
var chromedriver = require('chromedriver');
var geckodriver = require('geckodriver');

var config = {
    src_folders: [
        // Folders with tests
        'tests/'
    ],
    "custom_commands_path": "commands",
    output_folder: 'reports', // Where to output the test reports
    selenium: {
        // Information for selenium, such as the location of the drivers ect.
        start_process: true,
        server_path: seleniumServer.path,
        port: 4444, // Standard selenium port
        cli_args: {
            'webdriver.chrome.driver': chromedriver.path,
            'webdriver.gecko.driver': geckodriver.path
        }
    },
    test_workers: {
        // This allows more then one browser to be opened and tested in at once
        enabled: true,
        workers: 'auto'
    },
    test_settings: {
        default: {
            "launch_url": 'http://localhost:3000/',
            screenshots: {
                enabled: false
            },
            globals: {
                // How long to wait (in milliseconds) before the test times out
                waitForConditionTimeout: 2000,
                login_success: {
                    username: process.env.HILLROM_ADMIN_USERNAME,
                    password: process.env.HILLROM_ADMIN_PASSWORD,
                },
                login_fail: {
                    username: 'invalid.user@example.com',
                    password: 'invalid-password',
                },
                forgot_password: {
                    email: process.env.FORGOT_PASSWORD_EMAIL,
                },
                registeruser_success: {
                    login_username: process.env.HILLROM_ADMIN_USERNAME,
                    login_password: process.env.HILLROM_ADMIN_PASSWORD,
                    email: process.env.REGISTER_EMAIL,
                    password: process.env.REGISTER_PASSWORD,
                    cpassword: process.env.REGISTER_CPASSWORD,
                },
                registeruser_login_fail: {
                    login_username: process.env.REGISTER_LOGIN_FAIL_LOGINUSER,
                    login_password: process.env.REGISTER_LOGIN_FAIL_LOGINPASSWORD,
                },
                registeruser_second_page_fail: {
                    login_username: process.env.REGISTER_SECOND_FAIL_LOGINUSER,
                    login_password: process.env.REGISTER_SECOND_FAIL_LOGINPASSWORD,
                    email: process.env.REGISTER_SECOND_FAIL_EMAIL,
                    password: process.env.REGISTER_SECOND_FAIL_PASSWORD,
                    cpassword: process.env.REGISTER_SECOND_FAIL_CPASSWORD,
                },
                registeruser_fail: {
                    login_username: process.env.REGISTER_FAIL_LOGINUSER,
                    login_password: process.env.REGISTER_FAIL_LOGINPASSWORD,
                    email: process.env.REGISTER_FAIL_EMAIL,
                    password: process.env.REGISTER_FAIL_PASSWORD,
                    cpassword: process.env.REGISTER_FAIL_CPASSWORD,
                    security_question_id: "1",
                    security_question_answer: process.env.REGISTER_FAIL_ANSWER,
                },
                registeruser_link: {
                    email: process.env.REGISTER_EMAIL,
                    password: process.env.REGISTER_PASSWORD,
                    cpassword: process.env.REGISTER_CPASSWORD,
                },
                create_patient: {
                    login_username: process.env.HILLROM_ADMIN_USERNAME,
                    login_password: process.env.HILLROM_ADMIN_PASSWORD,
                    dateofbirth: process.env.CREATE_PATIENT_DOB,
                    zip: process.env.CREATE_PATIENT_ZIP,
                },

            },
            desiredCapabilities: {
                // The default test
                browserName: 'firefox',
                javascriptEnabled: true,
                acceptSslCerts: true,
                nativeEvents: true
            },
        },
        // Here, we give each of the browsers we want to test in, and their driver configuration
        chrome: {
            desiredCapabilities: {
                browserName: 'chrome',
                javascriptEnabled: true,
                acceptSslCerts: true,
                nativeEvents: true
            }
        },
        firefox: {
            desiredCapabilities: {
                browserName: 'firefox',
                javascriptEnabled: true,
                acceptSslCerts: true,
                nativeEvents: true
            }
        },
        safari: {
            desiredCapabilities: {
                browserName: 'safari',
                javascriptEnabled: true,
                acceptSslCerts: true,
                nativeEvents: true
            }
        }
    }
};

module.exports = config;
