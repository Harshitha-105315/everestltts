function generate_random_string(string_length, string_type = 'alphabetical', hId = false) {
    let random_string = '';
    let random_ascii;
    if (string_type == 'alphabetical') {
        var ascii_low = 65;
        var ascii_high = 90;
    }
    else if (string_type == 'numeric') {
        var ascii_low = 48;
        var ascii_high = 57;
    }
    for (let i = 0; i < string_length; i++) {
        random_ascii = Math.floor((Math.random() * (ascii_high - ascii_low)) + ascii_low);
        random_string += String.fromCharCode(random_ascii)
    }
    if (hId == true) {
        random_string = random_string + "_test"
    }
    return random_string
}

module.exports = {
    'Login Success': function (browser) {
        browser
            .login(browser.globals.login_success.username, browser.globals.login_success.password)
            .logout()
            .end();
    },

    'Login Fail': function (browser) {
        browser
            .login(browser.globals.login_fail.username, browser.globals.login_fail.password)
        browser.waitForElementPresent('#error', browser.globals.waitForConditionTimeout)
        browser.getText('#error', function (result) {
            console.log("Message: ", result.value);
        });
        browser
            .end();
    },

    'Forgot Password': function (browser) {
        browser
            .url(browser.launch_url)
            .waitForElementVisible('body', 1000)
            .waitForElementPresent('#forgot-password', browser.globals.waitForConditionTimeout)
            .click('#forgot-password')
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="email"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="email"]', browser.globals.forgot_password.email)
            .waitForElementVisible('#send-reset-button', browser.globals.waitForConditionTimeout)
            .click('#send-reset-button')
            .pause(browser.globals.waitForConditionTimeout)
        browser.waitForElementPresent('#error', browser.globals.waitForConditionTimeout)
            .getText('#error', function (result) {
                console.log("Message: ", result.value);
            });
        browser.end();
    },

    'Register User Success': function (browser) {
        var Hid = generate_random_string(10, 'numeric', true);
        var first_name = generate_random_string(10, 'alphabetical');
        var last_name = generate_random_string(10, 'alphabetical');
        var email = generate_random_string(10, 'alphabetical') + '@gmail.com';
        browser
            .create_patient(Hid, first_name, last_name, email)
            .useCss()
            .login(email, browser.globals.create_patient.zip + (last_name.substring(0, 4)).toUpperCase() +
                (browser.globals.create_patient.dateofbirth).replace(new RegExp('/', 'gi'), ''))
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="email"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="email"]', browser.globals.registeruser_success.email)
            .waitForElementPresent('[name="password"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="password"]', browser.globals.registeruser_success.password)
            .waitForElementPresent('[name="cpassword"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="cpassword"]', browser.globals.registeruser_success.cpassword)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('#register-button', browser.globals.waitForConditionTimeout)
            .click('#register-button')
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="questionId"]', browser.globals.waitForConditionTimeout)
            .click('[name="questionId"]')
            .pause(browser.globals.waitForConditionTimeout)
            .click('[Id="1"]')
            .waitForElementPresent('[name="answer"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="answer"]', generate_random_string(10, 'alphabetical'))
            .waitForElementPresent('#t-and-c-checkbox', browser.globals.waitForConditionTimeout)
            .click('[for="t-and-c-checkbox"]')
            .waitForElementPresent('#security-questions-button', browser.globals.waitForConditionTimeout)
            .click('#security-questions-button')
            .pause(browser.globals.waitForConditionTimeout)
            .login(browser.globals.registeruser_success.email, browser.globals.registeruser_success.password)
            .pause(browser.globals.waitForConditionTimeout)
            .logout()
            .end();
    },

    'Register Login Page Fail': function (browser) {
        browser
            .login(browser.globals.registeruser_login_fail.login_username, browser.globals.registeruser_login_fail.login_password)
            .pause(browser.globals.waitForConditionTimeout)
        browser.waitForElementPresent('#error', browser.globals.waitForConditionTimeout)
        browser.getText('#error', function (result) {
            console.log("Message: ", result.value);
        });
        browser
            .end();
    },

    'Register Second Page Fail': function (browser) {
        browser
            .login(browser.globals.registeruser_second_page_fail.login_username, browser.globals.registeruser_second_page_fail.login_password)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="email"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="email"]', browser.globals.registeruser_second_page_fail.email)
            .waitForElementPresent('[name="password"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="password"]', browser.globals.registeruser_second_page_fail.password)
            .waitForElementPresent('[name="cpassword"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="cpassword"]', browser.globals.registeruser_second_page_fail.cpassword)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('#register-button', browser.globals.waitForConditionTimeout)
            .click('#register-button')
            .pause(browser.globals.waitForConditionTimeout)
        browser.waitForElementPresent('#error', browser.globals.waitForConditionTimeout)
        browser.getText('#error', function (result) {
            console.log("Message: ", result.value);
        });
        browser
            .end();
    },

    'Register Security Question Page Fail': function (browser) {
        browser
            .login(browser.globals.registeruser_fail.login_username, browser.globals.registeruser_fail.login_password)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="email"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="email"]', browser.globals.registeruser_fail.email)
            .waitForElementPresent('[name="password"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="password"]', browser.globals.registeruser_fail.password)
            .waitForElementPresent('[name="cpassword"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="cpassword"]', browser.globals.registeruser_fail.cpassword)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('#register-button', browser.globals.waitForConditionTimeout)
            .click('#register-button')
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="questionId"]', browser.globals.waitForConditionTimeout)
            .click('[name="questionId"]')
            .pause(browser.globals.waitForConditionTimeout)
            .click('[Id="1"]')
            .waitForElementPresent('[name="answer"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="answer"]', browser.globals.registeruser_fail.security_question_answer)
            .waitForElementPresent('#t-and-c-checkbox', browser.globals.waitForConditionTimeout)
            // .click('[for="t-and-c-checkbox"]')
            .waitForElementPresent('#security-questions-button', browser.globals.waitForConditionTimeout)
            .click('#security-questions-button')
            .pause(browser.globals.waitForConditionTimeout)
        browser
            .end();
    },

    'Registration Link': function (browser) {
        var Hid = generate_random_string(10, 'numeric', true);
        var first_name = generate_random_string(10, 'alphabetical');
        var last_name = generate_random_string(10, 'alphabetical');
        var email = generate_random_string(10, 'alphabetical') + '@gmail.com';
        browser
            .create_patient(Hid, first_name, last_name, email)
            .useCss()
        browser
            .url(browser.launch_url)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .waitForElementPresent('#register-link', browser.globals.waitForConditionTimeout)
            .click('#register-link')
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .login(email, browser.globals.create_patient.zip + (last_name.substring(0, 4)).toUpperCase() +
                (browser.globals.create_patient.dateofbirth).replace(new RegExp('/', 'gi'), ''))
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="email"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="email"]', browser.globals.registeruser_link.email)
            .waitForElementPresent('[name="password"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="password"]', browser.globals.registeruser_link.password)
            .waitForElementPresent('[name="cpassword"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="cpassword"]', browser.globals.registeruser_link.cpassword)
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementPresent('#register-button', browser.globals.waitForConditionTimeout)
            .click('#register-button')
            .pause(browser.globals.waitForConditionTimeout)
            .waitForElementVisible('body', browser.globals.waitForConditionTimeout)
            .waitForElementPresent('[name="questionId"]', browser.globals.waitForConditionTimeout)
            .click('[name="questionId"]')
            .pause(browser.globals.waitForConditionTimeout)
            .click('[Id="1"]')
            .waitForElementPresent('[name="answer"]', browser.globals.waitForConditionTimeout)
            .setValue('[name="answer"]', generate_random_string(10, 'alphabetical'))
            .waitForElementPresent('#t-and-c-checkbox', browser.globals.waitForConditionTimeout)
            .click('[for="t-and-c-checkbox"]')
            .waitForElementPresent('#security-questions-button', browser.globals.waitForConditionTimeout)
            .click('#security-questions-button')
            .pause(browser.globals.waitForConditionTimeout)
            .login(browser.globals.registeruser_success.email, browser.globals.registeruser_success.password)
            .pause(browser.globals.waitForConditionTimeout)
            .logout()
            .end();
    },
}