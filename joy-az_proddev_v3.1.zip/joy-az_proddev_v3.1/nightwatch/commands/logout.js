exports.command = function () {
    this
        .waitForElementVisible('body', this.globals.waitForConditionTimeout)
        .waitForElementPresent('#profile-navbar', this.globals.waitForConditionTimeout)
        .click('#profile-navbar')
        .waitForElementPresent('#logout')
        .click('#logout')
        .pause(this.globals.waitForConditionTimeout)
    return this;
};