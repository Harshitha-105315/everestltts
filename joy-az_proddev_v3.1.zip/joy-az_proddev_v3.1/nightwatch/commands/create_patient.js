var setadate = function (value) {
    $(document).ready(function () {
        $('#dp2').datepicker();
        $('#dp2').datepicker('setDate', value);
    });
};

exports.command = function (Hid, first_name, last_name, email) {
    this
        .url("http://devserver.hillromvest.com/#/login")
        .waitForElementVisible('body', this.globals.waitForConditionTimeout)
        .pause(this.globals.waitForConditionTimeout)
        .waitForElementPresent('[name="username"]', this.globals.waitForConditionTimeout)
        .setValue('[name="username"]', this.globals.create_patient.login_username)
        .waitForElementPresent('[name="password"]', this.globals.waitForConditionTimeout)
        .setValue('[name="password"]', this.globals.create_patient.login_password)
        .waitForElementPresent('.myButton-blue-new-button', this.globals.waitForConditionTimeout)
        .click('.myButton-blue-new-button')
        .pause(10000)
        .waitForElementVisible('body', this.globals.waitForConditionTimeout)
        .pause(this.globals.waitForConditionTimeout)
        .waitForElementPresent('.dashbord-nav__secondary', this.globals.waitForConditionTimeout)
        .click('.dashbord-nav__secondary')
        .pause(this.globals.waitForConditionTimeout)
        .pause(10000)
        .waitForElementPresent('[name="HRID"]', this.globals.waitForConditionTimeout)
        .setValue('[name="HRID"]', Hid)
    this
        .waitForElementPresent('[name="firstName"]', this.globals.waitForConditionTimeout)
        .setValue('[name="firstName"]', first_name)
        .waitForElementPresent('[name="lastName"]', this.globals.waitForConditionTimeout)
        .setValue('[name="lastName"]', last_name)
    this.expect.element('#dp2').to.be.present.before(this.globals.waitForConditionTimeout);
    this
        .execute(setadate, [this.globals.create_patient.dateofbirth])
        .waitForElementPresent('[name="email"]', this.globals.waitForConditionTimeout)
        .setValue('[name="email"]', email)
        .waitForElementPresent('[name="zip"]', this.globals.waitForConditionTimeout)
        .setValue('[name="zip"]', this.globals.create_patient.zip)
        .waitForElementPresent('.multiSelect>button:nth-child(1)', this.globals.waitForConditionTimeout)
        .click('.multiSelect>button:nth-child(1)')
        .waitForElementPresent('div.multiSelectItem:nth-child(1)>div:nth-child(1)>label:nth-child(1)>span:nth-child(2)', this.globals.waitForConditionTimeout)
        .click('div.multiSelectItem:nth-child(1)>div:nth-child(1)>label:nth-child(1)>span:nth-child(2)')
        .waitForElementPresent('div.col-md-16:nth-child(9)>div:nth-child(1)>button:nth-child(1)', this.globals.waitForConditionTimeout)
        .click('div.col-md-16:nth-child(9)>div:nth-child(1)>button:nth-child(1)')
        .useXpath()
        .waitForElementPresent('/html/body/div[2]/div[2]/div/patient/div[2]/form/div/div[9]/div/button[1]', this.globals.waitForConditionTimeout)
        .click('/html/body/div[2]/div[2]/div/patient/div[2]/form/div/div[9]/div/button[1]')
    this.pause(this.globals.waitForConditionTimeout);
    return this;
};