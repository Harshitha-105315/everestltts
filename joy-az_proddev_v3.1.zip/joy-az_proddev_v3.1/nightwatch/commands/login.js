exports.command = function (username = 'sanath.kumar@ymedialabs.com', password = 'Password@123') {
    this
        .url(this.launch_url)
        .pause(this.globals.waitForConditionTimeout)
        .waitForElementVisible('body', this.globals.waitForConditionTimeout)
        .waitForElementPresent('[name="email"]', this.globals.waitForConditionTimeout)
        .setValue('[name="email"]', username)
        .waitForElementPresent('[name="password"]', this.globals.waitForConditionTimeout)
        .setValue('[name="password"]', password)
        .waitForElementPresent('#login-button', this.globals.waitForConditionTimeout)
        .click('#login-button')
        .pause(this.globals.waitForConditionTimeout)
    return this;
};
