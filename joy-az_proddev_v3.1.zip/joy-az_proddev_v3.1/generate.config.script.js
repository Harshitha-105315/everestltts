require('dotenv').config();

const SSM = require('aws-ssm-params'),
  fs = require('fs-extra'),
  InstanceType = process.argv[2],
  ProjectName = "hillrom-web",
  Region = "us-west-2",
  PortPropertyLabel = `/${ProjectName}/${InstanceType}/port`,
  BaseUrlPropertyLabel = `/${ProjectName}/${InstanceType}/base-url`,
  ModuleExportTextString = "module.exports = Config;";

let ssmParams = {
  Path: `/${ProjectName}/${InstanceType}/`,
  WithDecryption: true
},
  awsParams = {},
  ConfigFileTemplate = "";

// get secretAccessKey and accessKeyId for local environment
if (process.env.ACCESS_KEY_ID && process.env.SECRET_ACCESS_KEY) {
  awsParams = {
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    region: Region
  };
} else {
  awsParams = {
    region: Region
  };
}

SSM(ssmParams, awsParams).then(function (parameters) {
  ConfigFileTemplate = `const Config = {
    PORT:${parameters[PortPropertyLabel]},
    BASE_URL:${JSON.stringify(parameters[BaseUrlPropertyLabel])}
  }`;

  // create config file with config data
  fs.outputFileSync("src/config/config.js", ConfigFileTemplate, function (err) {
    if (err) {
      return console.log("unable to create config file");
    }
  });

  fs.appendFile("src/config/config.js", `\n ${ModuleExportTextString}`, function (err) {
    if (err) throw err;
  });
}, function (err) {
  console.log(err)
});
