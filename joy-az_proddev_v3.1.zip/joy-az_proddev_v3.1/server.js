'use strict';
const express = require('express');
const compress = require('compression');
const path = require('path');
const Config = require('./src/config/config.js');
const helmet = require('helmet')

/***** Strict transport security fix *****/
const hsts = require('hsts');

const STSMaxAge = 365 * 24 * 60 * 60;

const hstsConfig = {
  maxAge: STSMaxAge,
  includeSubDomains: false
};

const app = express();

//gzip response
app.use(
  compress(),
  hsts(hstsConfig),
  helmet(),
  helmet.referrerPolicy({ policy: 'same-origin' }),
  helmet.featurePolicy({
    features: {
      geolocation: ["'none'"]
    }
  }),
  helmet.frameguard({ action: 'DENY' })
);

app.disable('etag');

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "https://visiview-test.hillrom.com/,http://devhr.southeastasia.cloudapp.azure.com/,http://qahr.southeastasia.cloudapp.azure.com/,https://visiview.hillrom.com/,https://visiview-mirror.hillrom.com/,http://quatvhr.southeastasia.cloudapp.azure.com/,http://rcfota.hill-rom.com/#/");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

// app.use((req, res, next) => {
//   res.header("Access-Control-Allow-Origin", "https://visiview-test.hillrom.com/,http://devhr.southeastasia.cloudapp.azure.com/,http://qahr.southeastasia.cloudapp.azure.com/,https://visiview.hillrom.com/,https://visiview-mirror.hillrom.com/,http://quatvhr.southeastasia.cloudapp.azure.com/,http://rcfota.hill-rom.com/#/");
//   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// });

app.use(express.static(path.join('./build/')));

app.get('/health', (req, res) => {
  res.sendStatus(200);
});

app.get('*', (req, res) => {
  res.sendFile(__dirname + '/build/index.html');
});

app.listen(Config.PORT, () => {
  console.log('App running on ' + Config.PORT);
});

//to throw uncaught exception error
process.on('uncaughtException', (exception) => {
  console.log(JSON.stringify(exception));
  console.log(exception.stack);
});
