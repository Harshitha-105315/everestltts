import { combineReducers } from 'redux';
import languagesReducer from 'languages/reducers';
import providerReducer from 'provider/reducers';
import constants from 'constants.js';
import loginReducer from './landing/login/reducers';
import therapySettingReducer from './landing/therapysetting/reducers';
import patient from './patient/reducers';
import activateReducer from './landing/activation/reducers';
import forgotPasswordReducer from './landing/forgotpassword/reducers';
import profileReducer from './Profile/reducers';
import userReducer from './user-management/reducers';
import accountReducer from './account/reducers';
import clinicsReducer from './clinics/reducers';
import protocolReducer from './carePlanAndDevice/protocol/reducers';
import editProtocolReducer from './carePlanAndDevice/editProtocol/reducers';
import EditDeviceReducer from './carePlanAndDevice/addDevice/reducers';
import TimsScriptReducer from './timsScript/reducers';
import SandBoxReducer from './sandbox/reducers';
import notificationReducer from './notifications/reducers';
import announcementReducer from './announcements/reducers';
import filterReducer from './components/Navigation/reducers';
import breadcrumbsReducer from './breadcrumbs/reducers';
import AlertMessageReducer from './components/AlertMessage/reducers';
import LoaderReducer from './components/Loader/reducers';

const appReducers = combineReducers({
  patient,
  loginReducer,
  activateReducer,
  forgotPasswordReducer,
  profileReducer,
  userReducer,
  accountReducer,
  clinicsReducer,
  protocolReducer,
  editProtocolReducer,
  EditDeviceReducer,
  languagesReducer,
  providerReducer,
  TimsScriptReducer,
  SandBoxReducer,
  notificationReducer,
  announcementReducer,
  filterReducer,
  breadcrumbsReducer,
  AlertMessageReducer,
  LoaderReducer,
  therapySettingReducer
});

const rootReducers = (state, action) => {
  let appState = state;
  if (action.type === constants.LOGOUT.USER_LOGOUT) {
    appState = undefined;
  }
  return appReducers(appState, action);
};

export default rootReducers;
