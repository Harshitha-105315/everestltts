import React, { Component, PureComponent } from 'react';
import { connect } from 'react-redux';
import Reactour from 'reactour';
import { disableBodyScroll, enableBodyScroll } from 'body-scroll-lock';
import constants from 'constants.js';
import { withRouter } from 'react-router-dom';
import { getUserData, setHelpTipsFlag } from 'utils/helper';
import strings from 'localization/strings';
import 'App.scss';
import InfoIcon from 'assets/img/info.svg';

class App extends Component {
  closeTour = () => {
    const { dispatch } = this.props;
    const mainElement = document.getElementsByClassName('main-app');
    dispatch({
      type: constants.NAVIGATION.NAVIGATION_SHOW_HELP_TIP,
      data: false
    });
    enableBodyScroll(mainElement[0]);
    setHelpTipsFlag();
  };

  componentDidMount() {
    const { breadcrumbs, history } = this.props;
    if (
      breadcrumbs &&
      breadcrumbs.length > 0 &&
      !constants.STATIC_PAGES.includes(history.location.pathname)
    ) {
      const lastRoute = breadcrumbs[breadcrumbs.length - 1];
      lastRoute.path && history.push(lastRoute.path);
    }
  }

  render() {
    const {
      patients,
      providers,
      clinics,
      patientList,
      providerList,
      clinicList,
      patientSelf,
      usersList,
      patientStats
    } = this.props;
    const isMobile = window.innerWidth <= 575;
    const userData = getUserData();
    const userRole = userData && userData.actualRole;
    let showHelpTip = false;
    if (userRole === strings.patientRole && patientSelf) {
      showHelpTip = true;
    } else if (patientList && providerList && clinicList) {
      showHelpTip = true;
    }
    return (
      <div className="main-app">
        {this.props.showHelpTip && !isMobile && showHelpTip && (
          <Tour
            closeTour={this.closeTour}
            isOpen={this.props.showHelpTip}
            rounded={5}
            patients={patients}
            providers={providers}
            clinics={clinics}
            showHelpFlag={this.props.showHelpFlag}
            dispatch={this.props.dispatch}
            usersList={usersList}
            patientStats={patientStats}
          />
        )}
        {this.props.children}
      </div>
    );
  }
}

const getListofSteps = (
  pathname,
  history,
  patients,
  clinics,
  providers,
  usersList,
  patientStats
) => {
  const userData = getUserData();
  const userRole = userData && userData.actualRole;
  if (!userRole) return;
  let patientId = '';
  let clinicId = '';
  let providerId = '';
  let firstUserId = '';
  let isSpiroVal = patientStats !== undefined && patientStats.spiroScore !== undefined &&
    patientStats.spiroScore !== null ? true : false;
  if (usersList && usersList.length) {
    firstUserId = usersList[0].id;
  }
  if (patients && patients.length) {
    if (
      userRole === strings.adminRole ||
      userRole === strings.customerServicesRole
    ) {
      patientId = patients[0].userID;
    }
    if (
      userRole === strings.clinicAdminRole ||
      userRole === strings.associateExecutiveRole ||
      userRole === strings.hcpRole ||
      userRole === strings.caregiverRole
    ) {
      patientId = patients[0].patientInfo.userId;
    }
  }
  if (userRole === strings.patientRole) {
    patientId = getUserData().userId;
  }
  if (clinics && clinics.length) {
    clinicId = clinics[0].id;
  }
  if (providers && providers.length) {
    providerId = providers[0].id;
  }
  let steps = [];
  let clinicAdminSteps = [
    {
      selector: '.patientsTab-container',
      content:
        'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
    },
    {
      selector: '.search-container',
      content: 'Search your patient list by using this search field.'
    },
    {
      selector: '#top-layer',
      content:
        'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.'
    }
  ];
  if (userRole === strings.adminRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
      },
      {
        selector: '.search-container',
        content:
          'Search for a patient by Name, TIMS#, Email, or Serial number by using this search field.'
      },
      {
        selector: '#top-layer',
        content:
          'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.'
      }
    );
    if (patientId) {
      steps.push(
        {
          selector: '#sidebar',
          content:
            'You can further refine your patient list by using the detailed filters on the left.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent your patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),

          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
              <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'Patient details are displayed on this page.  Patient information can be updated here.  The email address can only be updated under the USERS section of the portal.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            } else if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'When you navigate to the Care Plan & Device page, you can view, add, edit, or delete the patient’s protocol.  You can also view their connected device information, total hour meter reading, reset their myScore, and view myScore reset history.',
          action: () => {
            if (pathname === '/' + strings.providers + '/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'Manage Providers page: Displays all of the providers in the portal. You can add a new Provider, search for a provider, and select a provider to view their information.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push('/' + strings.providers + '/');
            } else if (
              pathname ===
              '/' + strings.providers + '/' + providerId + '/details'
            ) {
              history.push('/' + strings.providers + '/');
            }
          }
        }
      );
    }
    if (providerId) {
      steps.push({
        selector: '#main-content',
        content:
          'Provider Details page: In this area you can see clinics provider is linked to, add a clinic, view clinic specific information, and update provider information.',
        action: () => {
          if (pathname === '/' + strings.providers + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          } else if (pathname === '/' + strings.clinics + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          }
        }
      });
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Clinics page: Displays the list of all clinics in the portal.  You can add a clinic, search by clinic name, Hillrom ID, or use the filters on the left side of the page to locate a clinic.',
      action: () => {
        history.push('/' + strings.clinics + '/');
      }
    });
    if (clinicId) {
      steps.push(
        {
          selector: '#main-content',
          content:
            'Once a clinic is selected, associated patients, navigation, and filter options will display.',
          action: () => {
            if (pathname === '/' + strings.clinics + '/') {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.clinics + '/' + clinicId + '/info'
            ) {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'If you Click on Clinic Details, you can view and update clinic information (this information should match TIMS).  Here you can add/edit/delete Clinic Admins, Providers, and Account Executives.  You can also deactivate the clinic.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.clinics +
              '/' +
              clinicId +
              '/' +
              strings.details +
              '/'
            ) {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            } else if (pathname === '/users') {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            }
          }
        }
      );
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Users page: Displays the list of all users in the portal.  You can add a user, search by user name, Hillrom ID, or use the filters on the left side of the page to locate a user.',
      action: () => {
        if (
          clinicId &&
          pathname === '/' + strings.clinics + '/' + clinicId + '/info'
        ) {
          history.push('/users');
        } else if (firstUserId && pathname === '/users/' + firstUserId) {
          history.push('/users');
        }
      }
    });
    if (firstUserId) {
      steps.push({
        selector: '#main-content',
        content:
          'After selecting a user, you can update their information, resend activation link (if pending), reset their password (if active), or deactivate their account.',
        action: () => {
          if ('/users/') {
            history.push('/users/' + firstUserId);
          }
        }
      });
    }
    steps.push(
      {
        selector: '#main-content',
        content:
          'The Manage Announcements page allows you to add a new announcement, edit, or delete an announcement, and filter announcements.',
        action: () => {
          if (firstUserId && pathname === '/users/' + firstUserId) {
            history.push('/announcements');
          } else if (!firstUserId && pathname === '/users') {
            history.push('/announcements');
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.'
      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  } else if (userRole === strings.customerServicesRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
      },
      {
        selector: '.search-container',
        content:
          'Search for a patient by Name, TIMS#, Email, or Serial number by using this search field.'
      },
      {
        selector: '#top-layer',
        content:
          'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.',
        action: () => {
          if (!patientId && pathname === '/' + strings.providers + '/') {
            history.push('/patients');
          }
        }
      }
    );
    if (patientId) {
      steps.push(
        {
          selector: '#sidebar',
          content:
            'You can further refine your patient list by using the detailed filters on the left.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent your patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),

          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        },
      );
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
              <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            `Patient details are displayed on this page.  If any patient information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            } else if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'When you navigate to the Care Plan & Device page, you can view the patient’s protocol, connected device information, total hour meter reading, and myScore reset history.',
          action: () => {
            if (pathname === '/' + strings.providers + '/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        }
      );
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Providers page: In this area you can search for and select a provider to view their information.',
      action: () => {
        if (
          patientId &&
          pathname ===
          '/' +
          strings.patients +
          '/' +
          patientId +
          '/' +
          strings.carePlanDevices +
          '/'
        ) {
          history.push('/' + strings.providers + '/');
        } else if (
          pathname ===
          '/' + strings.providers + '/' + providerId + '/details'
        ) {
          history.push('/' + strings.providers + '/');
        } else if (!patientId) {
          history.push('/' + strings.providers + '/');
        }
      }
    });
    if (providerId) {
      steps.push({
        selector: '#main-content',
        content:
          `Provider details page: In this area you can see clinics provider is linked to and view clinic specific information.  If any provider information needs to be updated, please email ${strings.emailId}.`,
        action: () => {
          if (pathname === '/' + strings.providers + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          } else if (pathname === '/' + strings.clinics + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          }
        }
      });
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Clinics page: Displays the list of all clinics in the portal.  You can search by clinic name, TIMS#, or use the filters on the left side of the page to locate a clinic.',
      action: () => {
        history.push('/' + strings.clinics + '/');
      }
    });
    if (clinicId) {
      steps.push(
        {
          selector: '#main-content',
          content:
            'Once a clinic is selected, associated patients, navigation, and filter options will display.',
          action: () => {
            if (pathname === '/' + strings.clinics + '/') {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.clinics + '/' + clinicId + '/info'
            ) {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            `If you Click on Clinic Details, you can view clinic information.  If any information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.clinics +
              '/' +
              clinicId +
              '/' +
              strings.details +
              '/'
            ) {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            } else if (pathname === '/users') {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            }
          }
        }
      );
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Users page: Displays the list of all users in the portal.',
      action: () => {
        if (
          clinicId &&
          pathname === '/' + strings.clinics + '/' + clinicId + '/info'
        ) {
          history.push('/users');
        } else if (firstUserId && pathname === '/users/' + firstUserId) {
          history.push('/users');
        }
      }
    });
    if (firstUserId) {
      steps.push({
        selector: '#main-content',
        content:
          'After selecting a user, you can resend activation link (if pending), reset their password (if active), or deactivate their account.',
        action: () => {
          if ('/users/') {
            history.push('/users/' + firstUserId);
          }
        }
      });
    }
    steps.push(
      {
        selector: '#main-content',
        content: 'The Announcements page allows you view announcements.',
        action: () => {
          if (firstUserId && pathname === '/users/' + firstUserId) {
            history.push('/announcements');
          } else if (!firstUserId && pathname === '/users') {
            history.push('/announcements');
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.'
      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  } else if (userRole === strings.hcpRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
      },
      {
        selector: '.search-container',
        content: 'Search for a patient by Name by using this search field.'
      },
      {
        selector: '#top-layer',
        content:
          'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.'
      }
    );
    steps.push({
      selector: '#sidebar',
      content:
        'You can further refine your patient list by using the detailed filters on the left.',
      action: () => {
        if (!patientId && pathname !== '/patients') {
          history.push('/patients');
        }
      }
    });
    if (patientId) {
      steps.push(
        {
          selector: '.user-list',
          content:
            'Your patient list by default is sorted by flagged patients, then new patients, and Completed Therapy Session percent range from low (red), medium (yellow), and high (green).'
        },
        {
          selector: '.overview-button',
          content:
            'In your patient list you can sort using the column headers and Flag patients to bring them to the top of your list.  Use the Batch Report feature to run reports for multiple patients at the same time.'
        },
        {
          selector: '.body-check-box',
          content:
            'Select the patients you want to include in the report by clicking on the box to the left of their name.'
        },
        {
          selector: '#date-picker',
          content:
            'The date range under the BATCH REPORT button defaults to 3 months.  Click the drop-down arrows to modify the date range. Then click the BATCH REPORT button to generate the reports.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a Patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent your patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),

          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
              <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        }
      );
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
              <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            `Patient details are displayed on this page.  If any patient information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            } else if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'When you navigate to the Care Plan & Device page, you can view/edit the patient’s protocol, view connected device information, total hour meter reading, and myScore information.',
          action: () => {
            if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        {
          selector: '.resetMyscore-Container',
          content:
            'This section allows you to reset the patient’smyScorein the event ofhospitalization,therapy adherence conversationto get them back on track, etc.'
        }
      );
    }
    steps.push(
      {
        selector: '#main-content',
        content:
          'Here you will receive updates from Hillrom regarding upcoming events, product launches and helpful tips and hints. Stay tuned!',
        action: () => {
          if (
            patientId &&
            pathname ===
            '/' +
            strings.patients +
            '/' +
            patientId +
            '/' +
            strings.carePlanDevices +
            '/'
          ) {
            history.push('/announcements');
          } else if (pathname === '/patients') {
            history.push('/announcements');
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.'
      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  } else if (userRole === strings.patientRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the OVERVIEW section.'
      },
      {
        selector: '.patient-therapy-numbers',
        content: (
          <div>
            Here you can quickly see how adherent the patient is to
            their therapy. The therapy information date range defaults to three
            months.  If you modify the date range in this section, it will apply
            to all of the therapy information displayed here and in the
            reports.  This area has multiple Additional Information Icons
            <img className="info-icon-help" src={InfoIcon} alt="" /> After the
            tour click the icons to learn more.
          </div>
        )
      },
      {
        selector: '.therapy-duration-chart-card',
        content:
          'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
      },
      {
        selector: '.dateSelection',
        content:
          'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
      },
      {
        selector: '#print-button',
        content:
          'The date range selection also determines the data that will be provided if you generate a report.',
        action: () => {
          if (
            pathname ===
            '/' +
            strings.patients +
            '/' +
            patientId +
            '/' +
            strings.carePlanDevices +
            '/'
          ) {
            history.push(
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            );
          }
        }
      },
      {
        selector: '.spirometer-badge',
        content: (
          <div>
            NEW TO CONNEX® - SPIROMETRY!
            <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
            patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
              <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
              <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
              <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
            </div>
          </div>
        )
      },
    );
    if (isSpiroVal) {
      steps.push({
        selector: '.spirometry-report',
        content: (
          <div>
            NEW TO CONNEX® - SPIROMETRY!
            <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
            patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
              <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
              <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
              <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
            </div>
          </div>
        )
      });
    }
    steps.push(
      {
        selector: '#sidebar-menu',
        content:
          'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
        action: () => {
          if (
            pathname ===
            '/' + strings.patients + '/' + patientId + '/details/'
          ) {
            history.push(
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            );
          }
        }
      },
      {
        selector: '#main-content',
        content:
          'Patient details are displayed on this page. If any information needs to be updated, please call home care customer service at 1-800-426-4224.',
        action: () => {
          if (
            pathname ===
            '/' +
            strings.patients +
            '/' +
            patientId +
            '/' +
            strings.overview +
            '/'
          ) {
            history.push(
              '/' + strings.patients + '/' + patientId + '/details/'
            );
          } else if (
            pathname ===
            '/' +
            strings.patients +
            '/' +
            patientId +
            '/' +
            strings.carePlanDevices +
            '/'
          ) {
            history.push(
              '/' + strings.patients + '/' + patientId + '/details/'
            );
          }
        }
      },
      {
        selector: '#main-content',
        content:
          'On the Care Plan & Device page you can view the patient’s Protocol, Device Information, Total Hour Meter Reading, and myScore reset hisotry.',
        action: () => {
          if (
            pathname ===
            '/' + strings.patients + '/' + patientId + '/details/'
          ) {
            history.push(
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            );
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.'
      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  } else if (userRole === strings.caregiverRole) {
    for (let step in clinicAdminSteps) {
      steps.push(clinicAdminSteps[step]);
    }
    if (patientId) {
      steps.push(
        {
          selector: '#sidebar',
          content:
            'You can further refine your patient list by using the detailed filters on the left.'
        },
        {
          selector: '.user-list',
          content:
            'Your patient list by default is sorted by flagged patients, then new patients, and Completed Therapy Session percent range from low (red), medium (yellow), and high (green).'
        },
        {
          selector: '.overview-button',
          content:
            'In your patient list you can sort using the column headers and Flag patients to bring them to the top of your list.  Use the Batch Report feature to run reports for multiple patients at the same time.'
        },
        {
          selector: '.body-check-box',
          content:
            'Select the patients you want to include in the report by clicking on the box to the left of their name.'
        },
        {
          selector: '#date-picker',
          content:
            'The date range under the BATCH REPORT button defaults to 3 months.  Click the drop-down arrows to modify the date range. Then click the BATCH REPORT button to generate the reports.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a Patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent the patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),
          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        },
      );
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        {
          selector: '.total-hmr-container',
          content:
            'On the Care Plan & Device page you can view the patient’s Total Hour Meter Reading.'
        },
        {
          selector: '.helpContainer',
          content:
            'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
        }
      );
    }
    return steps;
  } else if (userRole === strings.associateExecutiveRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
      },
      {
        selector: '.search-container',
        content: 'Search for a patient by Name by using this search field.'
      },
      {
        selector: '#top-layer',
        content:
          'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.',
        action: () => {
          if (!patientId && pathname === '/' + strings.providers + '/') {
            history.push('/patients');
          }
        }
      }
    );
    if (patientId) {
      steps.push(
        {
          selector: '#sidebar',
          content:
            'You can further refine your patient list by using the detailed filters on the left.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent your patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),

          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        }
      );
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
              <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            `Patient details are displayed on this page.  If any patient information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            } else if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'When you navigate to the Care Plan & Device page, you can view the patient’s protocol, connected device information, total hour meter reading, and myScore reset history.',
          action: () => {
            if (pathname === '/' + strings.providers + '/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        }
      );
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Providers page: In this area you can search for and select a provider to view their information.',
      action: () => {
        if (
          patientId &&
          pathname ===
          '/' +
          strings.patients +
          '/' +
          patientId +
          '/' +
          strings.carePlanDevices +
          '/'
        ) {
          history.push('/' + strings.providers + '/');
        } else if (
          pathname ===
          '/' + strings.providers + '/' + providerId + '/details'
        ) {
          history.push('/' + strings.providers + '/');
        } else if (!patientId) {
          history.push('/' + strings.providers + '/');
        }
      }
    });
    if (providerId) {
      steps.push({
        selector: '#main-content',
        content:
          `Provider details page: In this area you can see clinics provider is linked to and view clinic specific information.  If any provider information needs to be updated, please email ${strings.emailId}.`,
        action: () => {
          if (pathname === '/' + strings.providers + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          } else if (pathname === '/' + strings.clinics + '/') {
            history.push(
              '/' + strings.providers + '/' + providerId + '/details'
            );
          }
        }
      });
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Clinics page: Displays the list of all clinics in the portal.  You can search by clinic name, TIMS#, or use the filters on the left side of the page to locate a clinic.',
      action: () => {
        history.push('/' + strings.clinics + '/');
      }
    });
    if (clinicId) {
      steps.push(
        {
          selector: '#main-content',
          content:
            'Once a clinic is selected, associated patients, navigation, and filter options will display.',
          action: () => {
            if (pathname === '/' + strings.clinics + '/') {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.clinics + '/' + clinicId + '/info'
            ) {
              history.push(
                '/' +
                strings.clinics +
                '/' +
                clinicId +
                '/' +
                strings.details +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            `If you Click on Clinic Details, you can view clinic information.  If any information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.clinics +
              '/' +
              clinicId +
              '/' +
              strings.details +
              '/'
            ) {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            } else if (pathname === '/announcements') {
              history.push('/' + strings.clinics + '/' + clinicId + '/info');
            }
          }
        }
      );
    }
    steps.push(
      {
        selector: '#main-content',
        content: 'The Announcements page allows you view announcements.',
        action: () => {
          if (
            clinicId &&
            pathname === '/' + strings.clinics + '/' + clinicId + '/info'
          ) {
            history.push('/announcements');
          } else if (!clinicId && pathname === '/' + strings.clinics + '/') {
            history.push('/announcements');
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.'
      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  } else if (userRole === strings.clinicAdminRole) {
    steps.push(
      {
        selector: '.patientsTab-container',
        content:
          'Welcome to the Connex® Health Portal! This brief tour will help you navigate the different areas of the portal.  Navigation areas are along the top and left side of the portal. Our tour begins with the PATIENTS section.'
      },
      {
        selector: '.search-container',
        content:
          'Search for a patient by Name by using this search field.'
      },
      {
        selector: '#top-layer',
        content:
          'In the highlighted section, you can click on any of the Quick Filter boxes to easily filter your patient list.',
        action: () => {
          if (!patientId && pathname === '/' + strings.clinics + '/') {
            history.push('/patients/');
          }
        }
      }
    );
    if (patientId) {
      steps.push(
        {
          selector: '#sidebar',
          content:
            'You can further refine your patient list by using the detailed filters on the left.'
        },
        {
          selector: '.user-list',
          content:
            'Your patient list by default is sorted by flagged patients, then new patients, and Completed Therapy Session percent range from low (red), medium (yellow), and high (green).'
        },
        {
          selector: '.overview-button',
          content:
            'In your patient list you can sort using the column headers and Flag patients to bring them to the top of your list.  Use the Batch Report feature to run reports for multiple patients at the same time.'
        },
        {
          selector: '.body-check-box',
          content:
            'Select the patients you want to include in the report by clicking on the box to the left of their name.'
        },
        {
          selector: '#date-picker',
          content:
            'The date range under the BATCH REPORT button defaults to 3 months.  Click the drop-down arrows to modify the date range. Then click the BATCH REPORT button to generate the reports.'
        },
        {
          selector: '.listing',
          content:
            'When you click on a Patient’s name you will be brought to their Patient Overview page.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push('/patients');
            }
          }
        },
        {
          selector: '.patient-therapy-numbers',
          content: (
            <div>
              Here you can quickly see how adherent your patient is to
              their therapy. The therapy information date range defaults to
              three months.  If you modify the date range in this section, it
              will apply to all of the therapy information displayed here and in
              the reports.  This area has multiple Additional Information Icons
              <img className="info-icon-help" src={InfoIcon} alt="" /> After the
              tour click the icons to learn more.
            </div>
          ),

          action: () => {
            if (pathname === '/patients' || pathname === '/patients/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.therapy-duration-chart-card',
          content:
            'Therapy Duration Chart: Here you can click on any of the therapy data bars to see more detailed information.  A red dot around the calendar date indicates the patient deviated from their prescribed therapy. The chart displays data one month at a time.  Click another month in the upper right of the chart to view that month’s therapy data.  Below the chart area is the Patient’s prescribed protocol and additional therapy session information.'
        },
        {
          selector: '.dateSelection',
          content:
            'To change the calendar range of the therapy data you are viewing click on the drop-down arrows above the myScore area.'
        },
        {
          selector: '#print-button',
          content:
            'The date range selection also determines the data that will be provided if you generate a report.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              'care-plan-devices' +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.overview +
                '/'
              );
            }
          }
        },
        {
          selector: '.spirometer-badge',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        }
      );
      if (isSpiroVal) {
        steps.push({
          selector: '.spirometry-report',
          content: (
            <div>
              NEW TO CONNEX® - SPIROMETRY!
              <div>Patients can purchase a Smart One® Spirometer that allows patients and healthcare terms to track
              patient's lung health over time, along with their vest therapy data.
                <div>What you will see:</div>
                <div>-If no spirometry data is available for viewing, you will see NA and a LOG button.</div>
                <div>-Patients and their healthcare team can log PFT results from cilinc, or other at home spirometers.</div>
                <div>-When patient has spirometry data, you will see a VIEW button. This will take you to SPIRO DATA tab where you will be able to view PFT results, trends, LOG results, and access a Spirometry Report.</div>
              </div>
            </div>
          )
        });
      }
      steps.push(
        {
          selector: '#sidebar-menu',
          content:
            'The navigation options to the left allow you to view additional Patient Details, Care Plan, & Device information.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content: `Patient details are displayed on this page.  If any patient information needs to be updated, please email ${strings.emailId}.`,
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.overview +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            } else if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push(
                '/' + strings.patients + '/' + patientId + '/details/'
              );
            }
          }
        },
        {
          selector: '#main-content',
          content:
            'When you navigate to the Care Plan & Device page, you can view/edit the patient’s protocol, connected device information, total hour meter reading, and myScore reset history.',
          action: () => {
            if (pathname === '/' + strings.providers + '/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            } else if (
              pathname ===
              '/' + strings.patients + '/' + patientId + '/details/'
            ) {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        // {
        //   selector: '.total-hmr-container',
        //   content:
        //     'On the Care Plan & Device page you can view the patient’s Total Hour Meter Reading.'
        // },
        //{
        //  selector: '.total-hmr-container',
        //  content:
        //    'Patient details are displayed on this page.  If any patient information needs to be updated, please email ConnexSupport@Hillrom.com.'
        //},
        //{
        //  selector: '.total-hmr-container',
        //  content:
        //    'When you navigate to the Care Plan & Device page, you can view/edit the patient’s protocol, view connected device information, total hour meter reading, and myScore reset history.'
        //},
        {
          selector: '.resetMyscore-Container',
          content:
            'This section allows you to reset the patient’s myScore in the event of hospitalization, therapy adherence conversation to get them back on track, etc.',
          action: () => {
            if (pathname === '/' + strings.providers + '/') {
              history.push(
                '/' +
                strings.patients +
                '/' +
                patientId +
                '/' +
                strings.carePlanDevices +
                '/'
              );
            }
          }
        },
        {
          selector: '.table-header',
          content:
            'Manage Providers page: In this area you can create a new Provider and select a provider to modify or delete their information.',
          action: () => {
            if (
              pathname ===
              '/' +
              strings.patients +
              '/' +
              patientId +
              '/' +
              strings.carePlanDevices +
              '/'
            ) {
              history.push('/' + strings.providers + '/');
            } else if (pathname === '/' + strings.clinics + '/') {
              history.push('/' + strings.providers + '/');
            }
          }
        }
      );
    }
    steps.push({
      selector: '#main-content',
      content:
        'Manage Clinics page: Displays the list of clinics you are associated with. You have the option here to navigate to individual clinic pages.',
      action: () => {
        if (pathname === '/' + strings.providers + '/') {
          history.push('/' + strings.clinics + '/');
        } else if (
          pathname ===
          '/' + strings.clinics + '/' + clinicId + '/' + strings.details + '/'
        ) {
          history.push('/' + strings.clinics + '/');
        } else if (pathname === '/announcements') {
          history.push('/' + strings.clinics + '/');
        } else if (!patientId && pathname === '/patients/') {
          history.push('/' + strings.clinics + '/');
        }
      }
    });
    if (clinicId) {
      steps.push({
        selector: '#main-content',
        content:
          `The patients associated to the selected clinic are displayed.  You can also view the clinic details.  If any information needs to be updated, please email ${strings.emailId}.`,
        action: () => {
          if (pathname === '/' + strings.clinics + '/') {
            history.push(
              '/' +
              strings.clinics +
              '/' +
              clinicId +
              '/' +
              strings.details +
              '/'
            );
          } else if (pathname === '/announcements') {
            history.push(
              '/' +
              strings.clinics +
              '/' +
              clinicId +
              '/' +
              strings.details +
              '/'
            );
          }
        }
      });
    }
    steps.push(
      {
        selector: '#main-content',
        content:
          'Here you will receive updates from Hillrom regarding upcoming events, product launches and helpful tips and hints. Stay tuned!',
        action: () => {
          if (
            clinicId &&
            pathname ===
            '/' +
            strings.clinics +
            '/' +
            clinicId +
            '/' +
            strings.details +
            '/'
          ) {
            history.push('/announcements');
          } else if (!clinicId && pathname === '/' + strings.clinics + '/') {
            history.push('/announcements');
          }
        }
      },
      {
        selector: '.resourcesContainer',
        content:
          'The Resources menu provides links to Hillrom’s Respiratory Health’s web page.',

      },
      {
        selector: '.helpContainer',
        content:
          'We are here for you! At anytime, you can reference this tour to remind you of the portal’s many features. And if you ever need any assistance or have a question, please contact us. This is the end of the tour. Thank you!'
      }
    );
    return steps;
  }
};
function disableBody() {
  const mainElement = document.getElementsByClassName('main-app');
  disableBodyScroll(mainElement[0]);
}

function enableBody() {
  const mainElement = document.getElementsByClassName('main-app');
  enableBodyScroll(mainElement[0]);
}

class TourGuide extends PureComponent {
  render() {
    const {
      isOpen,
      closeTour,
      location: { pathname },
      history,
      patients,
      clinics,
      providers,
      usersList,
      patientStats
    } = this.props;
    let steps = getListofSteps(
      pathname,
      history,
      patients,
      clinics,
      providers,
      usersList,
      patientStats
    );
    return (
      <Reactour
        steps={steps}
        isOpen={isOpen}
        onRequestClose={closeTour}
        update={pathname}
        rounded={5}
        disableInteraction={true}
        onAfterOpen={disableBody}
        onBeforeClose={enableBody}
        closeWithMask={false}
        badgeContent={(curr, tot) => `${curr} of ${tot}`}
        showCloseButton={true}
        disableDotsNavigation={true}
        nextButton={<div className="nextButton">Next</div>}
        prevButton={<div className="prevButton">Previous</div>}
        maskSpace={14}
      />
    );
  }
}

const Tour = withRouter(TourGuide);

const mapStateToProps = state => {
  return {
    showHelpTip: state.app.filterReducer.showHelpTip,
    showHelpFlag: state.app.filterReducer.showHelpFlag,
    patients: state.app.patient.patients,
    patientList: state.app.patient.patientList,
    providers: state.app.providerReducer.providers,
    clinics: state.app.clinicsReducer.clinics,
    breadcrumbs: state.app.breadcrumbsReducer.breadcrumbs,
    providerList: state.app.providerReducer.providerList,
    patientStats: state.app.patient.patientStats[Object.keys(state.app.patient.patientStats)[0]],
    clinicList: state.app.clinicsReducer.clinicList,
    patientSelf: state.app.patient.patientSelf,
    usersList: state.app.userReducer.response
  }
};

export default connect(mapStateToProps)(withRouter(App));
