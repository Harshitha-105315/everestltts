import urls from '../urls';
import strings from '../localization/strings';
import constants from 'constants.js';

const { TABS } = constants;

const headerValues = [
  {
    url: urls.PATIENT.ALL,
    label: strings.patients,
    tab: TABS.SEARCH_PATIENTS,
    hasParams: false,
  },
  {
    url: urls.PATIENT.DETAIL.OVERVIEW.ALL,
    label: strings.dashboard,
    tab: TABS.PATIENT_OVERVIEW,
    hasParams: true,
  },
  {
    url: urls.PROVIDER.ALL,
    label: strings.providers,
    tab: TABS.SEARCH_PROVIDERS,
    hasParams: false,
  },
  {
    url: urls.CLINIC.ALL,
    label: strings.clinics,
    tab: TABS.SEARCH_CLINICS,
    hasParams: false,
  },
  {
    url: urls.USER.ALL,
    label: strings.users,
    tab: TABS.SEARCH_USERS,
    hasParams: false,
  },
  {
    url: urls.ANNOUNCEMENT.ALL,
    label: strings.announcements,
    tab: TABS.ANNOUNCEMENT_INFORMATION,
    hasParams: false,
  },
];

export default headerValues;
