import urls from '../urls';

const landingUrls = {
  ADMIN: {
    to: urls.PATIENT.ALL
  },
  CUSTOMER_SERVICES: {
    to: urls.PATIENT.ALL
  },
  PATIENT: {
    to: urls.PATIENT.DETAIL.OVERVIEW.ALL,
    pattern: true
  },
  PROVIDER: {
    to: urls.PATIENT.ALL
  },
  CLINIC_ADMIN: {
    to: urls.PATIENT.ALL
  }
};

export default landingUrls;
