import strings from 'localization/strings';

const roleConstant = {
	ADMIN: {
		ROLE: 'ADMIN',
		LABEL: strings.roles.superAdmin
	},
	ACCT_SERVICES: {
		ROLE: 'ACCT_SERVICES',
		LABEL: strings.roles.rcAdmin
	},
	ASSOCIATES: {
		ROLE: 'ASSOCIATES',
		LABEL: strings.roles.associates
	},
	CUSTOMER_SERVICES: {
		ROLE: 'CUSTOMER_SERVICES',
		LABEL: strings.roles.customerService,
	},
	ASSOCIATE_EXECUTIVE: {
		ROLE: 'ASSOCIATE_EXECUTIVE',
		LABEL: strings.roles.accountExecutive
	},
	PATIENT: {
		ROLE: 'PATIENT',
		LABEL: strings.roles.patientUser
	},
	CARE_GIVER: {
		ROLE: 'CARE_GIVER',
		LABEL: strings.roles.careGiver
	},
	HCP: {
		ROLE: 'HCP',
		LABEL: strings.roles.provider,
	},
	CLINIC_ADMIN: {
		ROLE: 'CLINIC_ADMIN',
		LABEL: strings.roles.clinicAdmin
	},
	FOTA_ADMIN: {
		ROLE: 'FOTA_ADMIN',
		LABEL: strings.roles.fotaAdmin
	},
	FOTA_APPROVER: {
		ROLE: 'FOTA_APPROVER',
		LABEL: strings.roles.fotaApprover
	}
};

export default roleConstant;
