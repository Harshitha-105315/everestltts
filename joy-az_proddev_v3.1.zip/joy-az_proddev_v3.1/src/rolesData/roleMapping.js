import constants from 'constants.js';

const roleMap = {
  // ADMIN
  ADMIN: constants.ROLES.SUPER_ADMIN,
  ACCT_SERVICES: constants.ROLES.SUPER_ADMIN,
  RC_ADMIN: constants.ROLES.SUPER_ADMIN,
  // PATIENT
  PATIENT: constants.ROLES.PATIENT,
  // PROVIDER
  PROVIDER: constants.ROLES.PROVIDER,
  CARE_GIVER: constants.ROLES.PROVIDER,
  HCP: constants.ROLES.PROVIDER,
  // CLINIC_ADMIN
  CLINIC_ADMIN: constants.ROLES.CLINIC_ADMIN,
  ASSOCIATE_EXECUTIVE: constants.ROLES.CLINIC_ADMIN,
  // CUSTOMER_SERVICES
  CUSTOMER_SERVICES: constants.ROLES.SUPER_ADMIN,
  ASSOCIATES: constants.ROLES.SUPER_ADMIN
};

export default roleMap;
