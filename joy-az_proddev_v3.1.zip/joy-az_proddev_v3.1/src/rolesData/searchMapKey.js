const searchKeyMap = {
  ASSOCIATE_EXECUTIVE: 'ae',
  CLINIC_ADMIN: 'ca',
  HCP: 'hcp',
  CARE_GIVER: 'cg',
  PROVIDER: 'hcp'
};
const allowFlag = {
  CLINIC_ADMIN: 'ca',
  HCP: 'hcp'
};

export default searchKeyMap;
export { searchKeyMap, allowFlag };
