const readOnlyMatrix = {
  PATIENT_DETAIL: {
    CUSTOMER_SERVICES: {
      ALL: true,
      PROVIDER: true,
      CLINIC: true,
      DIAGNOSIS: true,
      CARE_GIVER: true
    },
    ASSOCIATES: {
      ALL: true,
      PROVIDER: true,
      CLINIC: true,
      DIAGNOSIS: true,
      CARE_GIVER: true
    },
    PATIENT: {
      PROVIDER: true,
      CLINIC: true,
      DIAGNOSIS: true
    },
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  CARE_PLAN_DEVICE: {
    CUSTOMER_SERVICES: {
      PROTOCOL: true,
      DEVICE: true,
      RESET_SCORE: true
    },
    ASSOCIATES: {
      PROTOCOL: true,
      DEVICE: true,
      RESET_SCORE: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  PROVIDER_DETAIL: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  MANAGE_PROVIDER: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  CLINIC_DETAIL: {
    CUSTOMER_SERVICES: {
      ALL: true,
      CLINIC: true,
      PROVIDER: true,
      ACCOUNT_EXCEUTIVE: true
    },
    ASSOCIATES: {
      ALL: true,
      CLINIC: true,
      PROVIDER: true,
      ACCOUNT_EXCEUTIVE: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  MANAGE_CLINIC: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: { ALL: true },
    ASSOCIATE_EXECUTIVE: { ALL: true }
  },
  MANAGE_USER: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  USER_DETAIL: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  MANAGE_ANNOUNCEMENT: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  },
  ANNOUNCEMENT_DETAIL: {
    CUSTOMER_SERVICES: {
      ALL: true
    },
    ASSOCIATES: {
      ALL: true
    },
    PATIENT: {},
    ADMIN: {},
    ACCT_SERVICES: {},
    RC_ADMIN: {},
    PROVIDER: {},
    HCP: {},
    CARE_GIVER: {},
    CLINIC_ADMIN: {},
    ASSOCIATE_EXECUTIVE: {}
  }
};

export default readOnlyMatrix;
