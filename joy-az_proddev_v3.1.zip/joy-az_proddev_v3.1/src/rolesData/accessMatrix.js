const matrix = {
	SEARCH_PATIENTS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_OVERVIEW: {
		ADMIN: {
			read: false,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	FLAG_PATIENT: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_DEVICE_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_DEVICE_DELETE: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_DEVICE_BYOD: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: true,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_PROTOCOL_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_PROTOCOL_UPDATE_PRESCRIPTION_REQUIRED: {
		ADMIN: {
			read: false,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_PROTOCOL_DELETE: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PATIENT_CAREGIVER: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: true,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_CLINIC: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_PROVIDER: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	PATIENT_MY_SCORE: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	SEARCH_PROVIDERS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CREATE_PROVIDER: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PROVIDER_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	SEARCH_CLINICS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CLINIC_STATUS_FILTER: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CREATE_CLINIC: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CLINIC_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	MODIFY_CLINIC_ACCOUNT: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CLINIC_CLINIC_ADMIN: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CLINIC_PROVIDER: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CLINIC_ACCOUNT_EXECUTIVE: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	ASSOCIATED_PATIENTS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	SEARCH_USERS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CREATE_USER: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	USER_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	MODIFY_USER_ACCOUNT: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: true,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	MODIFY_USER_ACCOUNT_ROLES: {
		ADMIN: {
			ADMIN: true,
			CUSTOMER_SERVICES: true,
			CLINIC_ADMIN: true,
			HCP: true,
			ASSOCIATE_EXECUTIVE: true,
			PATIENT: true,
			CARE_GIVER: true,
			ACCT_SERVICES: true,
			FOTA_ADMIN: true,
			FOTA_APPROVER: true
		},
		CUSTOMER_SERVICES: {
			ADMIN: false,
			CUSTOMER_SERVICES: false,
			CLINIC_ADMIN: true,
			HCP: true,
			ASSOCIATE_EXECUTIVE: false,
			PATIENT: true,
			CARE_GIVER: true,
			ACCT_SERVICES: false,
			FOTA_ADMIN: false,
			FOTA_APPROVER: false
		},
	},
	SEARCH_ANNOUNCEMENTS: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	CREATE_ANNOUNCEMENT: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	ANNOUNCEMENT_INFORMATION: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PROFILE_MANAGEMENT: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: true,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: true,
		},
		PATIENT: {
			read: true,
			write: true,
		},
		CARE_GIVER: {
			read: true,
			write: true,
		},
	},
	CLINIC_LIST_PROFILE: {
		ADMIN: {
			read: false,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	TIMEZONE_PROFILE: {
		ADMIN: {
			read: false,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: true,
		},
		HCP: {
			read: true,
			write: true,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: true,
		},
		PATIENT: {
			read: true,
			write: true,
		},
		CARE_GIVER: {
			read: true,
			write: true,
		},
	},
	ROLE_PROFILE: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		},
	},
	TIMS_SCRIPT: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	SANDBOX: {
		ADMIN: {
			read: true,
			write: true,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: true,
		},
		CLINIC_ADMIN: {
			read: false,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: false,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	PRESCRIBE_DEVICE: {
		ADMIN: {
			read: false,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: false,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: false,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: false,
			write: false,
		},
		CARE_GIVER: {
			read: false,
			write: false,
		},
	},
	DAILY_HMR: {
		ADMIN: {
			read: true,
			write: false,
		},
		CUSTOMER_SERVICES: {
			read: true,
			write: false,
		},
		CLINIC_ADMIN: {
			read: true,
			write: false,
		},
		HCP: {
			read: true,
			write: false,
		},
		ASSOCIATE_EXECUTIVE: {
			read: true,
			write: false,
		},
		PATIENT: {
			read: true,
			write: false,
		},
		CARE_GIVER: {
			read: true,
			write: false,
		}
	}
};

export default matrix;