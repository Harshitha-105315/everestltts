import constants from 'constants.js';

const intialState = {
  deviceData: {},
  contents: [],
  chargerDeviceDataList: {},
  chargerContentsList: [],
  optimusDataContents: [],
  titanDataContents: []
};
function SandBoxReducer(state = intialState, action) {
  switch (action.type) {
    case constants.SANDBOX.CHARGER_DEVICE_DATA_SUCCESS:
      return Object.assign({}, state, {
        chargerDeviceDataList: action.chargerDeviceDataList,
        chargerContentsList: action.chargerContentsList
      });
    case constants.SANDBOX.CHARGER_DEVICE_DATA_FAILURE:
      return Object.assign({}, state, {
        chargerDeviceDataList: {},
        chargerContentsList: []
      });
    case constants.SANDBOX.OPTIMUS_DEVICE_DATA_SUCCESS:
      return Object.assign({}, state, {
        optimusData: action.optimusData
      });
    case constants.SANDBOX.OPTIMUS_DEVICE_DATA_FAILURE:
      return Object.assign({}, state, {
        optimusData: {}
      });
    case constants.SANDBOX.TITAN_DEVICE_DATA_SUCCESS:
      return Object.assign({}, state, {
        titanData: action.titanData
      });
    case constants.SANDBOX.TITAN_DEVICE_DATA_FAILURE:
      return Object.assign({}, state, {
        titanData: {}
      });
    default:
      return state;
  }
}
export default SandBoxReducer;
