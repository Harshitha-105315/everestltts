import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function getChargerDeviceService(payload) {
  const url = API.SANDBOXCHARGER;
  const fromDate = `${payload.fromDate.getFullYear()}-${payload.fromDate.getMonth() +
    1}-${payload.fromDate.getDate()}`;
  const toDate = `${payload.toDate.getFullYear()}-${payload.toDate.getMonth() +
    1}-${payload.toDate.getDate()}`;
  return authRequest({
    url: `${url}?${payload.serialNo ? `serialNo=${payload.serialNo}&` : ''}pageNo=${payload.page}&pageSz=${
      payload.perPage
      }&from=${fromDate}&to=${toDate}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getOptimusDeviceService(payload) {
  const url = API.OPTIMUSDEVICEDATA;
  const fromDate = `${payload.fromDate.getFullYear()}-${payload.fromDate.getMonth() +
    1}-${payload.fromDate.getDate()}`;
  const toDate = `${payload.toDate.getFullYear()}-${payload.toDate.getMonth() +
    1}-${payload.toDate.getDate()}`;
  return authRequest({
    url: `${url}?${payload.serialNo ? `serialNo=${payload.serialNo}&` : ''}pageNo=${payload.page}&pageSz=${
      payload.perPage
      }&from=${fromDate}&to=${toDate}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getTitanDeviceService(payload) {
  const url = API.TITANDEVICEDATA;
  const fromDate = `${payload.fromDate.getFullYear()}-${payload.fromDate.getMonth() +
    1}-${payload.fromDate.getDate()}`;
  const toDate = `${payload.toDate.getFullYear()}-${payload.toDate.getMonth() +
    1}-${payload.toDate.getDate()}`;
  return authRequest({
    url: `${url}?${payload.serialNo ? `serialNo=${payload.serialNo}&` : ''}pageNo=${payload.page}&pageSz=${
      payload.perPage
      }&from=${fromDate}&to=${toDate}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

const SandBoxService = {
  getChargerDeviceService,
  getOptimusDeviceService,
  getTitanDeviceService
};
export default SandBoxService;
