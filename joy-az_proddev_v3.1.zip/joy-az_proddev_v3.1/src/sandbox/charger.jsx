import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment-timezone';
import { Header, SideBar } from 'components/Navigation';
import Search from 'components/Search';
import strings from 'localization/strings';
import constants from 'constants.js';
import Pagination from 'react-js-pagination';
import DatePicker from 'react-datepicker';
import DatePickerCustomInput from 'components/DatePickerCustomInput';
import { isEmpty } from 'lodash';
import { Table, Row, Col } from 'react-bootstrap';
import arrow from 'assets/img/arrow-left.svg';
import './sandbox.scss';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import ButtonComponent from 'components/ButtonComponent';
import MainWrapper from 'components/MainWrapperDisplay';
import { getLastDate, selectPreviousMonth } from 'utils/helper';

class Charger extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chargerDeviceDataList: {},
      chargerTableHeight: '720px',
      tableHeightCheck: false,
      onclickChargerData: {},
      fromDate: selectPreviousMonth(new Date(), constants.DEFAULT_MONTH_RANGE),
      toDate: getLastDate(new Date()),
      page: 0,
      perPage: 10,
      serialNo: ''
    };
    this.myRef = React.createRef();
    this.updateDimensions = this.updateDimensions.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.fetchSandboxCharger = this.fetchSandboxCharger.bind(this);
  }

  componentWillMount() {
    this.dispatchChargerDevice();
    window.addEventListener('resize', this.updateDimensions);
  }

  componentWillReceiveProps(newProps) {
    this.setState({ tableHeightCheck: false });
    const { chargerDeviceDataList } = newProps;
    if (chargerDeviceDataList !== undefined) {
      this.setState({ chargerDeviceDataList });
    }
  }

  componentDidUpdate() {
    const rootFontSize = window
      .getComputedStyle(document.body)
      .getPropertyValue('font-size')
      .split('px')[0];
    if (!this.state.tableHeightCheck) {
      const ref = this.myRef.current;
      const chargerTableHeight = `${ref.offsetHeight / rootFontSize}rem`;
      this.setState({ tableHeightCheck: true });
      this.setState({ chargerTableHeight });
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }

  dispatchChargerDevice = () => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.SANDBOX.CHARGER_DEVICE_DATA,
      payload: this.state
    });
  };

  handleSorting = () => {};

  getActiveDate = date => {
    return moment(date).format('MMM DD, YYYY LT');
  };

  handleChangeFromDate = date => {
    this.setState({ fromDate: date }, () => {
      this.dispatchChargerDevice();
    });
  };

  handleChangeToDate = date => {
    this.setState({ toDate: date }, () => {
      this.dispatchChargerDevice();
    });
  };

  paginationSet = (name, value) => {
    this.setState({ [name]: value });
  };

  handleContentClick = (e, value) => {
    this.setState({ onclickChargerData: value });
  };

  handleClear = () => {
    this.setState({ onclickChargerData: {} });
  };

  handleRefresh = () => {
    // this.dispatchChargerDevice();
  };

  updateDimensions() {
    this.setState({ tableHeightCheck: false });
  }

  async handlePaginate(pageNumber) {
    this.setState({ onclickChargerData: {} });
    await this.paginationSet('page', pageNumber - 1);
    this.dispatchChargerDevice();
  }

  async fetchSandboxCharger(event) {
    const value = event.target.value || '';
    await this.setState({
      serialNo: value,
      page: 0,
      perPage: 10,
      onclickChargerData: {}
    });
    if (value.length >= 10 || value.length === 0) {
      this.dispatchChargerDevice();
    }
  }

  render() {
    const { location } = this.props;
    const {
      chargerDeviceDataList,
      onclickChargerData,
      fromDate,
      toDate,
      page,
      perPage,
      serialNo
    } = this.state;

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.SANDBOX, text: strings.charger },
        { href: urls.OPTIMUS, text: strings.optimus },
        { href: urls.TITAN, text: strings.titan }
      ]
    };
    return (
      <div>
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <Row>
              <Col>
                <h2 className="text-capitalize">{strings.sandboxCharger}</h2>
              </Col>
              <Col>
                <div className="table-header sandbox-search-container d-flex align-items-center">
                  <Search
                    searchString={serialNo}
                    fetchOnChange={this.fetchSandboxCharger}
                    modifierClass="d-sm-inline"
                    placeholder={strings.sandboxSearchPlaceholder}
                  />
                  <span
                    className={`${
                      serialNo !== ''
                        ? 'cross-icon d-md-inline-block ml-auto'
                        : 'd-none'
                    }`}
                    onClick={this.fetchSandboxCharger}
                    tabIndex={0}
                    role="button"
                  />
                </div>
              </Col>
              <Col>
                <div className="py-2 pl-2 pr-0 float-right">
                  <div className="d-flex flex-row">
                    <div>
                      <DatePicker
                        customInput={<DatePickerCustomInput />}
                        name="chargerStartDate"
                        showYearDropdown
                        yearDropdownItemNumber={30}
                        scrollableYearDropdown
                        maxDate={toDate}
                        dateFormat="MMM d, yyyy"
                        selected={fromDate}
                        onChange={this.handleChangeFromDate}
                      />
                    </div>
                    <div className="custom-selection-seperator px-2 text-uppercase">
                      {strings.to}
                    </div>
                    <div>
                      <DatePicker
                        customInput={<DatePickerCustomInput />}
                        name="chargerToDate"
                        showYearDropdown
                        yearDropdownItemNumber={30}
                        scrollableYearDropdown
                        minDate={fromDate}
                        maxDate={new Date()}
                        dateFormat="MMM d, yyyy"
                        popperPlacement="bottom"
                        popperModifiers={{
                          flip: {
                            behavior: ['bottom']
                          },
                          preventOverflow: {
                            enabled: false
                          },
                          hide: {
                            enabled: false
                          }
                        }}
                        selected={toDate}
                        onChange={this.handleChangeToDate}
                      />
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col md={5}>
                <div
                  ref={this.myRef}
                  id="charger-table"
                  className="user-list card"
                >
                  <Table hover>
                    <thead>
                      <tr>
                        <th>{strings.dateAndTime}</th>
                        <th>{strings.serialNo}</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {!isEmpty(chargerDeviceDataList.content) ? (
                        chargerDeviceDataList.content.map((content, key) => (
                          <tr
                            key={Number(key)}
                            onClick={e =>
                              this.handleContentClick(
                                e,
                                chargerDeviceDataList.content[key]
                              )
                            }
                            className={
                              onclickChargerData ===
                              chargerDeviceDataList.content[key]
                                ? 'sandbox-data-active'
                                : ''
                            }
                          >
                            <td>
                              {`
                        ${this.getActiveDate(content.createdTime)}
                        `}
                            </td>
                            <td>{content.deviceSerialNumber}</td>
                            <td>
                              <input
                                type="image"
                                src={arrow}
                                width="14"
                                height="14"
                                className="d-inline-block float-right icon-flipped"
                                alt="edit"
                              />
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan="3"
                            className="text-center text-capitalize"
                          >
                            {strings.noSandBoxDataAvaliable}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>
                <div className="listing-pagination d-inline">
                  <h6 className="d-inline text-capitalize">
                    {chargerDeviceDataList !== undefined &&
                      chargerDeviceDataList.totalElements}{' '}
                    {strings.records}
                  </h6>
                  <nav aria-label="..." className="float-right">
                    <Pagination
                      activePage={page + 1}
                      prevPageText="PREV"
                      nextPageText="NEXT"
                      linkClass="page-link"
                      activeLinkClass=""
                      itemClass="page-item"
                      itemsCountper_Page={perPage}
                      totalItemsCount={
                        chargerDeviceDataList !== undefined &&
                        chargerDeviceDataList.totalElements
                      }
                      pageRangeDisplayed={5}
                      onChange={this.handlePaginate}
                      firstPageText="FIRST"
                      lastPageText="LAST"
                    />
                  </nav>
                </div>
              </Col>
              <Col md={7}>
                <div
                  className={`user-list card charger-data-box ${
                    chargerDeviceDataList.content &&
                    chargerDeviceDataList.content.length === 1
                      ? 'auto-height'
                      : ''
                  }`}
                >
                  {!isEmpty(onclickChargerData) ? (
                    <div className="content">
                      <div>
                        <h6>
                          {this.getActiveDate(onclickChargerData.createdTime)}
                        </h6>
                      </div>
                      <div>{(Uint8Array.from(atob(onclickChargerData.rawMessage), c => c.charCodeAt(0))).toString().split(',').join(' ')}</div>
                    </div>
                  ) : (
                    <div />
                  )}
                </div>
                <div className="float-right">
                  <ButtonComponent
                    id="charger-refresh"
                    buttonClass="float-left"
                    buttonAction={this.handleRefresh}
                    icon="refresh-icon"
                    buttonText={strings.refresh}
                  />
                  <ButtonComponent
                    id="charger-clear"
                    buttonClass="float-right mt-auto ml-2"
                    buttonAction={this.handleClear}
                    icon="clear-icon"
                    buttonText={strings.clear}
                  />
                </div>
              </Col>
            </Row>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    chargerDeviceDataList: state.app.SandBoxReducer.chargerDeviceDataList,
    chargerDeviceData: state.app.SandBoxReducer.chargerDeviceData
  };
};

export default connect(
  mapStateToProps,
  null
)(Charger);
