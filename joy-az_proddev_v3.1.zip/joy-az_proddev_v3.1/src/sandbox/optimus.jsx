import React, { Component } from 'react';
import Pagination from 'react-js-pagination';
import { connect } from 'react-redux';
import moment from 'moment-timezone';
import Search from 'components/Search';
import strings from 'localization/strings';
import { Header, SideBar } from 'components/Navigation';
import { Row, Col, Table } from 'react-bootstrap';
import { isEmpty } from 'lodash';
import arrow from 'assets/img/arrow-left.svg';
import DatePicker from 'react-datepicker';
import DatePickerCustomInput from 'components/DatePickerCustomInput';
import './sandbox.scss';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import { getLastDate, selectPreviousMonth } from 'utils/helper';
import constants from '../constants';

class Optimus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      page: 0,
      perPage: 10,
      optimusData: {},
      optimusTableHeight: '720px',
      optimusMinTableHeight: '126px',
      tableHeightCheck: false,
      onclickData: {},
      fromDate: selectPreviousMonth(new Date(), constants.DEFAULT_MONTH_RANGE),
      toDate: getLastDate(new Date()),
      serialNo: ''
    };
    this.myRef = React.createRef();
    this.updateDimensions = this.updateDimensions.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleChangeFromDate = this.handleChangeFromDate.bind(this);
    this.handleChangeToDate = this.handleChangeToDate.bind(this);
    this.fetchSandboxOptimus = this.fetchSandboxOptimus.bind(this);
  }

  componentWillMount() {
    this.dispatchOptimusDeviceData();
    window.addEventListener('resize', this.updateDimensions);
  }

  componentWillReceiveProps(newProps) {
    this.setState({ tableHeightCheck: false });
    const { optimusData } = newProps;
    if (optimusData !== undefined) {
      this.setState({ optimusData });
    }
  }

  componentDidUpdate() {
    const rootFontSize = window
      .getComputedStyle(document.body)
      .getPropertyValue('font-size')
      .split('px')[0];
    if (!this.state.tableHeightCheck) {
      const ref = this.myRef.current;
      const optimusTableHeight = `${ref.offsetHeight / rootFontSize}rem`;
      this.setState({ tableHeightCheck: true });
      this.setState({ optimusTableHeight });
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }

  dispatchOptimusDeviceData = () => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.SANDBOX.OPTIMUS_DEVICE_DATA,
      payload: this.state
    });
  };

  getActiveDate = date => {
    return moment(date).format('MMM DD, YYYY LT');
  };

  handleContentClick = (e, value) => {
    this.setState({ onclickData: value });
  };

  handleClear = () => {
    this.setState({ onclickData: {} });
  };

  handleChangeFromDate = date => {
    this.setState({ fromDate: date }, () => {
      this.dispatchOptimusDeviceData();
    });
  };

  handleChangeToDate = date => {
    this.setState({ toDate: date }, () => {
      this.dispatchOptimusDeviceData();
    });
  };

  handleRefresh = () => {
    // this.dispatchOptimusDeviceData();
  };

  paginationSet = (name, value) => {
    this.setState({ [name]: value });
  };

  updateDimensions() {
    this.setState({ tableHeightCheck: false });
  }

  async handlePaginate(pageNumber) {
    this.setState({ onclickData: {} });
    await this.paginationSet('page', pageNumber - 1);
    this.dispatchOptimusDeviceData();
  }
  async fetchSandboxOptimus(event) {
    const value = event.target.value || '';
    await this.setState({
      serialNo: value,
      page: 0,
      perPage: 10,
      onclickData: {}
    });
    if (value.length >= 10 || value.length === 0) {
      this.dispatchOptimusDeviceData();
    }
  }

  render() {
    const { location } = this.props;

    const {
      page,
      perPage,
      optimusData,
      fromDate,
      toDate,
      onclickData,
      serialNo
    } = this.state;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.SANDBOX, text: strings.charger },
        { href: urls.OPTIMUS, text: strings.optimus },
        { href: urls.TITAN, text: strings.titan }
      ]
    };

    return (
      <div>
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <Row>
              <Col>
                <h2 className="text-capitalize">{strings.sandboxOptimus}</h2>
              </Col>
              <Col>
                <div className="table-header sandbox-search-container d-flex align-items-center">
                  <Search
                    searchString={serialNo}
                    fetchOnChange={this.fetchSandboxOptimus}
                    modifierClass="d-sm-inline"
                    placeholder={strings.sandboxSearchPlaceholder}
                  />
                  <span
                    className={`${
                      serialNo !== ''
                        ? 'cross-icon d-md-inline-block ml-auto'
                        : 'd-none'
                    }`}
                    onClick={this.fetchSandboxOptimus}
                    tabIndex={0}
                    role="button"
                  />
                </div>
              </Col>
              <Col>
                <div className="py-2 pl-2 pr-0 float-right">
                  <div className="d-flex flex-row">
                    <div>
                      <DatePicker
                        customInput={<DatePickerCustomInput />}
                        name="chargerStartDate"
                        showYearDropdown
                        yearDropdownItemNumber={30}
                        scrollableYearDropdown
                        maxDate={toDate}
                        dateFormat="MMM d, yyyy"
                        selected={fromDate}
                        onChange={this.handleChangeFromDate}
                      />
                    </div>
                    <div className="custom-selection-seperator px-2 text-uppercase">
                      {strings.to}
                    </div>
                    <div>
                      <DatePicker
                        customInput={<DatePickerCustomInput />}
                        name="chargerToDate"
                        showYearDropdown
                        yearDropdownItemNumber={30}
                        scrollableYearDropdown
                        minDate={fromDate}
                        maxDate={new Date()}
                        dateFormat="MMM d, yyyy"
                        popperPlacement="bottom"
                        popperModifiers={{
                          flip: {
                            behavior: ['bottom']
                          },
                          preventOverflow: {
                            enabled: false
                          },
                          hide: {
                            enabled: false
                          }
                        }}
                        selected={toDate}
                        onChange={this.handleChangeToDate}
                      />
                    </div>
                  </div>
                </div>
              </Col>
            </Row>

            <Row>
              <Col md={5}>
                <div ref={this.myRef} className="user-list card">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>{strings.dateAndTime}</th>
                        <th>{strings.serialNo}</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {!isEmpty(optimusData.content) ? (
                        optimusData.content.map((content, key) => (
                          <tr
                            key={Number(key)}
                            onClick={e =>
                              this.handleContentClick(
                                e,
                                optimusData.content[key]
                              )
                            }
                            className={
                              onclickData === optimusData.content[key]
                                ? 'sandbox-data-active'
                                : ''
                            }
                          >
                            <td>
                              {`
                        ${this.getActiveDate(content.createdTime)}

                        `}
                            </td>
                            <td>{content.serialNumber}</td>
                            <td>
                              <input
                                type="image"
                                src={arrow}
                                width="14"
                                height="14"
                                className="d-inline-block float-right icon-flipped"
                                alt="edit"
                              />
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan="3"
                            className="text-center text-capitalize"
                          >
                            {strings.noSandBoxDataAvaliable}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>
                <div className="listing-pagination d-inline">
                  <h6 className="d-inline text-capitalize">
                    {optimusData !== undefined && optimusData.totalElements}{' '}
                    {strings.records}
                  </h6>
                  <nav aria-label="..." className="float-right">
                    <Pagination
                      activePage={page + 1}
                      prevPageText="PREV"
                      nextPageText="NEXT"
                      linkClass="page-link"
                      activeLinkClass=""
                      itemClass="page-item"
                      itemsCountper_Page={perPage}
                      totalItemsCount={
                        optimusData !== undefined && optimusData.totalElements
                      }
                      pageRangeDisplayed={5}
                      onChange={this.handlePaginate}
                      firstPageText="FIRST"
                      lastPageText="LAST"
                    />
                  </nav>
                </div>
              </Col>
              <Col md={7}>
                <div
                  className={`user-list card charger-data-box ${
                    optimusData.content && optimusData.content.length === 1
                      ? 'auto-height'
                      : ''
                  }`}
                >
                  {!isEmpty(onclickData) ? (
                    <div className="content">
                      <div>
                        <h6>{this.getActiveDate(onclickData.createdTime)}</h6>
                      </div>
                      <div className="break-word">{onclickData.deviceData}</div>
                    </div>
                  ) : (
                    <div />
                  )}
                </div>

                <div className="float-right">
                  <ButtonComponent
                    id="charger-refresh"
                    buttonClass="float-left"
                    buttonAction={this.handleRefresh}
                    icon="refresh-icon"
                    buttonText={strings.refresh}
                  />
                  <ButtonComponent
                    id="charger-clear"
                    buttonClass="float-right mt-auto ml-2"
                    buttonAction={this.handleClear}
                    icon="clear-icon"
                    buttonText={strings.clear}
                  />
                </div>
              </Col>
            </Row>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    optimusDataContents: state.app.SandBoxReducer.optimusDataContents,
    optimusData: state.app.SandBoxReducer.optimusData
  };
};

export default connect(
  mapStateToProps,
  null
)(Optimus);
