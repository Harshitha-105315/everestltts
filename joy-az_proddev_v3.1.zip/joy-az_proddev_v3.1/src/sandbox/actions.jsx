import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import SandBoxService from './services';

function* getChargerDeviceData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      SandBoxService.getChargerDeviceService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.SANDBOX.CHARGER_DEVICE_DATA_SUCCESS,
        chargerDeviceDataList: response.data,
        chargerContentsList: response.data.content
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.SANDBOX.CHARGER_DEVICE_DATA_FAILURE
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getOptimusDeviceData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      SandBoxService.getOptimusDeviceService,
      action.payload
    );

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.SANDBOX.OPTIMUS_DEVICE_DATA_SUCCESS,
        optimusData: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.SANDBOX.OPTIMUS_DEVICE_DATA_FAILURE
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getTitanDeviceData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      SandBoxService.getTitanDeviceService,
      action.payload
    );

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.SANDBOX.TITAN_DEVICE_DATA_SUCCESS,
        titanData: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.SANDBOX.TITAN_DEVICE_DATA_FAILURE
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const SandBoxAction = {
  getChargerDeviceData,
  getOptimusDeviceData,
  getTitanDeviceData
};

export default SandBoxAction;
