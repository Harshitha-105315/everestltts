import React, { Component } from 'react';
import { Header, SideBar } from 'components/Navigation';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import Switch from 'components/Switch';
import { isEqual } from 'lodash';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import { setScreenSize } from '../utils/utltity';
import strings from '../localization/strings';
import constants from '../constants';
import './notifications.scss';

class Notifications extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      profile: {},
      MissedTherapyNotificationFreq: null,
      NonHMRNotificationFreq: null,
      SettingDeviationNotificationFreq: null,
      isMessageNotification: false,
      isMissedTherapyNotification: false,
      isNonHMRNotification: false,
      isSettingDeviationNotification: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.setScreenSize = setScreenSize.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.PROFILE.PROFILE_REQUEST
    });
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillReceiveProps(newProps) {
    const { profile } = this.state;
    if (!isEqual(profile, newProps.profile)) {
      this.setState({
        profile: newProps.profile,
        isMissedTherapyNotification: newProps.profile.missedTherapyNotification,
        isNonHMRNotification: newProps.profile.nonHMRNotification,
        isSettingDeviationNotification:
          newProps.profile.settingDeviationNotification,
        MissedTherapyNotificationFreq:
          newProps.profile.missedTherapyNotificationFreq,
        NonHMRNotificationFreq: newProps.profile.nonHMRNotificationFreq,
        SettingDeviationNotificationFreq:
          newProps.profile.settingDeviationNotificationFreq
      });
    }
  }

  handleSelectChange = event => {
    if (event.target.value === '') {
      this.setState({ [event.target.name]: null });
    } else {
      this.setState({ [event.target.name]: event.target.value });
    }
  };

  handleUpdate = () => {
    const {
      MissedTherapyNotificationFreq,
      isMissedTherapyNotification,
      NonHMRNotificationFreq,
      isNonHMRNotification,
      SettingDeviationNotificationFreq,
      isSettingDeviationNotification
    } = this.state;
    if (
      (MissedTherapyNotificationFreq === null ||
        MissedTherapyNotificationFreq === '') &&
      isMissedTherapyNotification === true
    ) {
      // console.log('Please select a missed therapy notitifcation frequency');
    } else if (
      (NonHMRNotificationFreq === null || NonHMRNotificationFreq === '') &&
      isNonHMRNotification === true
    ) {
      // console.log(
      //   'Please select a below treatment minutes notification frequency'
      // );
    } else if (
      (SettingDeviationNotificationFreq === null ||
        NonHMRNotificationFreq === '') &&
      isSettingDeviationNotification === true
    ) {
      // console.log('Please select a setting deviation notitifcation frequency');
    } else {
      const { dispatch } = this.props;
      const payload = Object.assign({}, this.state);
      ['profile'].forEach(element => {
        delete payload[element];
      });
      dispatch({
        type: constants.NOTIFICATION_SETTING.NOTIFICATION_UPDATE_REQUEST,
        payload
      });
    }
  };

  getDropDown = () => {
    return constants.NOTIFICATION_FREQUENCY.map(element => {
      return (
        <option key={element} value={element}>
          {element}
        </option>
      );
    });
  };

  notifications = () => {
    const {
      isSettingDeviationNotification,
      isMissedTherapyNotification,
      isNonHMRNotification,
      NonHMRNotificationFreq,
      SettingDeviationNotificationFreq,
      MissedTherapyNotificationFreq
    } = this.state;
    return [
      {
        isClicked: isMissedTherapyNotification,
        switchName: 'isMissedTherapyNotification',
        handleChange: this.handleChange,
        title: strings.missedTherapyDays,
        desc: strings.missedTherapyDesc,
        selectName: 'MissedTherapyNotificationFreq',
        selectValue: MissedTherapyNotificationFreq,
        handleSelectChange: this.handleSelectChange
      },
      {
        isClicked: isNonHMRNotification,
        switchName: 'isNonHMRNotification',
        handleChange: this.handleChange,
        title: 'Below Treatment Minutes',
        desc: strings.belowTreatmentMinutesDesc,
        selectName: 'NonHMRNotificationFreq',
        selectValue: NonHMRNotificationFreq,
        handleSelectChange: this.handleSelectChange
      },
      {
        isClicked: isSettingDeviationNotification,
        switchName: 'isSettingDeviationNotification',
        handleChange: this.handleChange,
        title: strings.settingDeviation,
        desc: strings.settingDeviationDesc,
        selectName: 'SettingDeviationNotificationFreq',
        selectValue: SettingDeviationNotificationFreq,
        handleSelectChange: this.handleSelectChange
      }
    ].map(element => {
      return (
        <div key={element.switchName}>
          <hr />
          <div className="d-block d-sm-none">
            <Switch
              isChecked={element.isClicked}
              handleChange={element.handleChange}
              name={element.switchName}
              value={element.name}
              className="float-right notification-switch-mobile"
            />
            <h6 className="text-capitalize d-inline-block">{element.title}</h6>
          </div>
          <Form.Row className="align-items-center">
            <Form.Group as={Col} md={1} className="d-none d-sm-block">
              <Switch
                isChecked={element.isClicked}
                handleChange={element.handleChange}
                name={element.switchName}
                value={element.name}
              />
            </Form.Group>
            <Form.Group
              id="title-notif"
              className="d-none d-sm-block"
              as={Col}
              md={2}
            >
              <h6 className="text-capitalize switch-container1">
                {element.title}
              </h6>
            </Form.Group>

            <Form.Group as={Col} md={3}>
              <span
                style={{ fontSize: '0.7rem', color: 'red' }}
                hidden={
                  element.isClicked &&
                    (element.selectValue === '' || element.selectValue === null)
                    ? null
                    : true
                }
              >
                {strings.pleaseSelectNotificationFrequency}
              </span>
              {element.selectName && (
                <Form.Control
                  as="select"
                  name={element.selectName}
                  onChange={element.handleSelectChange}
                  className="text-capitalize"
                  disabled={element.isClicked ? null : true}
                  value={element.selectValue || ''}
                >
                  <option key="" value="" />
                  {this.getDropDown()}
                </Form.Control>
              )}
            </Form.Group>
            <Form.Group id="desc-notif" as={Col} md={6}>
              <p>{element.desc}</p>
            </Form.Group>
          </Form.Row>
        </div>
      );
    });
  };

  async handleChange(event) {
    const { id } = event.target;
    const { state } = this;
    if (id === 'isMissedTherapyNotification' && state[id] === true) {
      await this.setState(prevState => {
        return { [id]: !prevState[id] };
      });
      await this.setState({ MissedTherapyNotificationFreq: null });
    } else if (id === 'isNonHMRNotification' && state[id] === true) {
      await this.setState(prevState => {
        return { [id]: !prevState[id] };
      });
      await this.setState({ NonHMRNotificationFreq: null });
    } else if (id === 'isSettingDeviationNotification' && state[id] === true) {
      await this.setState(prevState => {
        return { [id]: !prevState[id] };
      });
      await this.setState({ SettingDeviationNotificationFreq: null });
    } else {
      await this.setState(prevState => {
        return { [id]: !prevState[id] };
      });
    }
  }

  render() {
    const { location, history } = this.props;
    const { isMobile } = this.state;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.PROFILE.ALL, text: strings.profileDetails },
        { href: urls.PROFILE.UPDATEPASSWORD, text: strings.updatePassword },
        { href: urls.PROFILE.NOTIFICATION, text: strings.notificationSettings }
      ]
    };
    return (
      <div>
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.LANDING}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div>
              <ButtonComponent
                id="save-notif-top"
                buttonClass="float-right"
                buttonAction={this.handleUpdate}
                icon="right-arrow"
                buttonText={strings.save}
                hidden={isMobile}
              />
              <h1 className="text-capitalize">
                {strings.notificationSettings}
              </h1>
            </div>
            <h6 className="d-none d-sm-block text-capitalize">
              {strings.settingsOnOff}
            </h6>
            <div>
              <Form>
                <div>{this.notifications()}</div>
                <hr />
                <ButtonComponent
                  id="save-notif-bottom"
                  buttonClass="float-right"
                  buttonAction={this.handleUpdate}
                  icon="right-arrow"
                  buttonText={strings.save}
                  hidden={isMobile}
                />
              </Form>
            </div>

            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { profileReducer } = state.app;
  return {
    profile: profileReducer.profile
  };
};

export default connect(
  mapStateToProps,
  null
)(Notifications);
