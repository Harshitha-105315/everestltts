import { put, call } from 'redux-saga/effects';
import constants from '../constants';
import {
  fetchNotificationDataService,
  updateNotificationSettingsService
} from './services';

export function* fetchNotificationData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const notification = yield call(fetchNotificationDataService, action.payload);
    yield put({
      type: constants.NOTIFICATION_SETTING.SET_USER_NOTIFICATION,
      notification
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* updateNotificationSettings(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      updateNotificationSettingsService,
      action.payload
    );
    yield put({
      type: constants.NOTIFICATION_SETTING.NOTIFICATION_SETTINGS_SUCCESS,
      response
    });
  } catch (response) {
    yield put({
      type: constants.NOTIFICATION_SETTING.NOTIFICATION_SETTINGS_FAILURE
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
