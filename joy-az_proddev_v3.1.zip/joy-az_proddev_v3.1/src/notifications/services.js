import { authRequest } from 'utils/axios_utils';
import { getUserId } from 'utils/helper';
import API from '../api/api_config';

export function fetchNotificationDataService() {
  return authRequest({
    url: API.NOTIFICATION.replace('{USERID}', getUserId()).replace(
      '{DATE}',
      new Date().getTime()
    ),
    method: 'GET'
  });
}

export function updateNotificationSettingsService(payload) {
  return authRequest({
    url: API.NOTIFICATIONUPDATE.replace('{USERID}', getUserId()),
    method: 'PUT',
    data: payload
  });
}
