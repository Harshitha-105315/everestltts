import constants from '../constants';

const intialState = { notificationSetting: {} };

function notificationReducer(state = intialState, action) {
  const tmpState = Object.assign({}, state);
  if (action.type === constants.NOTIFICATION_SETTING.SET_USER_NOTIFICATION) {
    tmpState.userNotification = action.notification;
    return tmpState;
  }
  return tmpState;
}
export default notificationReducer;
