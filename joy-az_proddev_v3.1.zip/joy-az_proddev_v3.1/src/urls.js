import { include } from 'named-urls';

export default {
  LANDING: '/',
  LOGIN: '/login',
  ACTIVATION: '/activation',
  LOGOUT: '/logout',
  REGISTER: '/register',
  RESETPASSWORD: '/reset-password',
  THERAPYSETTING: '/therapy-setting',
  SANDBOX: '/sandbox',
  OPTIMUS: '/optimus',
  TITAN: '/titan',
  AUTHENTICATE: '/authenticate',
  HIPAA: '/hipaa',
  DISCLOSURES: '/disclosures',
  TERMSOFUSE: '/terms-of-use',
  PRIVACYPOLICY: '/privacy-policy',
  PRIVACYPOLICYMOBILE: '/privacy-policy-mobile',
  PROFILE: include('/profile', {
    ALL: 'details',
    UPDATEPASSWORD: 'update-password',
    NOTIFICATION: 'notification/settings'
  }),
  USER: include('/users', {
    ALL: '',
    ADD: 'add',
    PROFILE: ':id'
  }),
  PATIENT: include('/patients', {
    ALL: '',
    DETAIL: include(':id/', {
      DETAIL: 'details',
      OVERVIEW: include('overview', {
        ALL: '',
        DETAILREPORT: 'detailreport'
      }),
      CAREPLANDEVICE: include('care-plan-devices', {
        ALL: '',
        DEVICE: include('device', {
          EDIT: 'edit/:devicetype/:serialno',
          ADD: 'add'
        }),
        PROTOCOL: include('protocol', {
          ADD: 'add',
          EDIT: ':protocolid/:devicetype/:type'
        })
      })
    })
  }),
  CLINIC: include('/clinics', {
    ALL: '',
    ADD: 'add',
    DETAIL: include(':id/', {
      INFO: 'info',
      DETAILS: 'details'
    })
  }),
  PROVIDER: include('/providers', {
    ALL: '',
    ADD: 'add',
    DETAIL: ':id/details'
  }),
  ANNOUNCEMENT: include('/announcements', {
    ALL: '',
    ADD: 'add',
    EDIT: ':id/edit',
  }),
  TIMS: include('/tims', {
    SCRIPT: 'script',
    EXECUTE: 'execute-job',
    LOG: 'log/:file'
  })
};
