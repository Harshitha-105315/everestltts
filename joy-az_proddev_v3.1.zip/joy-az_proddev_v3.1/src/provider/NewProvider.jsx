import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { uid } from 'react-uid';
import update from 'immutability-helper';
import strings from 'localization/strings';
import { Header, SideBar } from 'components/Navigation';
import CustomSelect from 'components/CustomSelect';
import { last, isEmpty, every } from 'lodash';
import API from 'api/api_config';
import ConfirmationDialog from 'components/ConfirmationDialog';
import urls from 'urls';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import trash from 'assets/icn-delete.svg';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData, validateEmail } from 'utils/helper';
import { FootNote } from '../components/FootNote';
import constants from '../constants';
import {
  handleZipChange,
  getSpeciality,
  removeBreadCrumb,
  getBreadCrumb,
  addBreadCrumb,
  clearZipStoreValue
} from '../utils/utltity';

class NewProvider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      firstName: '',
      lastName: '',
      middleName: '',
      email: '',
      npiNumber: '',
      speciality: '',
      credentials: '',
      clinicList: [{ name: '', id: '' }],
      clinics: [],
      state: '',
      city: '',
      zipcode: '',
      error: '',
      role: 'HCP',
      resetSelect: false,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: true,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleClinicChange = this.handleClinicChange.bind(this);
    this.handleClinicRemove = this.handleClinicRemove.bind(this);
    this.handleClinicAdd = this.handleClinicAdd.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleZipChange = handleZipChange.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.clearZipStoreValue = clearZipStoreValue.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
    dispatch({
      type: constants.PROVIDER.CLEAR_ADD_PROVIDER_STATUS
    });
    this.clearZipStoreValue();
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.addNewProvider });
  }

  componentWillReceiveProps(newProps) {
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
  }

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  handleChange = event => {
    if (event.target.name === 'speciality') {
      if (event.target.value === 'Select Speciality') {
        this.setState({ [event.target.name]: null });
      } else {
        this.setState({ [event.target.name]: event.target.value });
      }
    } else {
      this.setState({ [event.target.name]: event.target.value });
    }
    this.setState({ isDirty: true });
  };

  clinicRemove = () => {
    const { clinics, clinicList, dialog } = this.state;
    const { idx } = dialog;
    clinics.pop();
    this.setState({ clinics });
    this.setState({
      clinicList: update(clinicList, { $splice: [[idx, 1]] })
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  handleClinicAdd = () => {
    const { clinicList } = this.state;
    const ClinicInit = {
      id: '',
      name: ''
    };
    if (!every(last(clinicList), isEmpty)) {
      this.setState({
        clinicList: [...clinicList, ClinicInit]
      });
    }
  };

  clinicChange = () => {
    const { clinicList, clinics, dialog } = this.state;
    const { opt, idx } = dialog;

    if (opt) {
      clinics.push(opt);
      this.setState({ clinics });
    } else {
      this.setState({
        clinics: update(clinics, { $splice: [[idx, 1]] })
      });
    }

    this.setState({
      clinicList: update(clinicList, {
        [idx]: {
          $set: {
            name: opt ? opt.name : '',
            id: opt ? opt.id : ''
          }
        }
      })
    });

    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: true
    });
  };

  getSelectedClinicsLength = clinics => {
    return clinics.filter(clinic => {
      return clinic.id ? true : false;
    });
  };

  submit = () => {
    const { dispatch, history } = this.props;
    const { dialog } = this.state;
    const payload = (({
      firstName,
      lastName,
      middleName,
      email,
      npiNumber,
      speciality,
      credentials,
      clinicList,
      clinics,
      state,
      zipcode,
      city,
      role
    }) => ({
      firstName,
      lastName,
      middleName,
      email,
      npiNumber,
      speciality,
      credentials,
      clinicList,
      clinics,
      city,
      state,
      zipcode,
      role
    }))(this.state);
    dispatch({
      type: constants.PROVIDER.NEW_PROVIDER_REQUEST,
      allData: {
        history,
        path: urls.PROVIDER.ALL,
        payload
      }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  async handleClinicChange(opt, idx) {
    const { dialog } = this.state;
    if (opt) {
      await this.setState({
        dialog: Object.assign(dialog, {
          body: `Associate ${opt.name} clinic with the provider?`,
          title: strings.addNewClinic,
          button: strings.linkClinic,
          confirmFunction: this.clinicChange,
          opt,
          idx,
          show: true
        })
      });
    } else {
      await this.setState({
        dialog: Object.assign(dialog, {
          opt,
          idx
        })
      });
      this.clinicChange();
    }
  }

  async handleClinicRemove(idx) {
    const { dialog, clinicList } = this.state;
    await this.setState({
      dialog: Object.assign(dialog, {
        body: `Disassociate ${clinicList[0].name} clinic with the provider?`,
        title: strings.removeClinicProvider,
        button: strings.removeClinic,
        confirmFunction: this.clinicRemove,
        idx,
        show: true
      })
    });
  }

  async handleSubmit() {
    const { firstName, lastName, zipcode, email, dialog, city } = this.state;
    let { clinicList } = this.state;
    this.setState({ error: '' });
    if (
      clinicList.length === 1 &&
      clinicList[0].id === '' &&
      clinicList[0].name === ''
    ) {
      await this.setState({ error: strings.pleaseEnterClinic });
    } else if (firstName === '') {
      await this.setState({ error: strings.pleaseEnterFirstName });
    } else if (lastName === '') {
      await this.setState({ error: strings.enterLastName });
    } else if (!validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    } else if (zipcode === '') {
      await this.setState({ error: strings.pleaseEnterZipcode });
    } else if (city === '') {
      await this.setState({ error: strings.pleaseEnterValidZipcode });
    } else {
      await this.setState({ error: '' });
      clinicList = clinicList.map(element => {
        return { id: element.id };
      });
      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.addNewProviderMsg.replace(
            '{VALUE}',
            `${firstName} ${lastName}`
          ),
          title: strings.addNewProvider,
          button: strings.addProvider,
          confirmFunction: this.submit,
          show: true
        })
      });
    }
  }

  render() {
    const {
      firstName,
      lastName,
      middleName,
      email,
      npiNumber,
      speciality,
      credentials,
      clinicList,
      state,
      city,
      zipcode,
      dialog,
      isMobile,
      error,
      resetSelect
    } = this.state;
    const { location, breadcrumbs, history, addProviderStatus } = this.props;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [{ href: urls.PROVIDER.ADD, text: strings.addNewProvider }]
    };

    const selectedClinics = this.getSelectedClinicsLength(clinicList);

    if (addProviderStatus === 1) {
      history.push(urls.PROVIDER.ALL);
    }
    const { actualRole } = getUserData();
    const createProviderInformation = accessMatrix.CREATE_PROVIDER[actualRole];

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.PROVIDER.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          {createProviderInformation.write ? (
            <MainContent>
              {!isMobile && this.getBreadCrumb(breadcrumbs)}
              <div>
                <h1 className="d-inline-block text-capitalize">
                  {strings.addNewProvider}
                </h1>
                {!isMobile && (
                  <ButtonComponent
                    buttonClass="float-right"
                    buttonAction={this.handleSubmit}
                    icon="update-icon"
                    buttonText={strings.save}
                  />
                )}
              </div>
              <p id="error" className="text-danger">
                {error}
              </p>
              <Form>
                <div
                  style={isMobile ? { height: '2.25rem' } : {}}
                  className="mb-3"
                >
                  <h6
                    style={isMobile ? { verticalAlign: 'sub' } : {}}
                    className="text-capitalize d-inline"
                  >
                    {strings.clinicDetails}
                  </h6>
                  {isMobile && (
                    <ButtonComponent
                      buttonClass="float-right"
                      buttonAction={this.handleSubmit}
                      icon="update-icon"
                      buttonText={strings.save}
                    />
                  )}
                </div>
                {clinicList.map((clinic, idx) => (
                  <Form.Row>
                    <Form.Group as={Col} md={8}>
                      <Form.Label className="text-uppercase">
                        {strings.clinicName} <span className="asterisk-color">*</span>
                      </Form.Label>
                      <div className="row">
                        <div className="col-11 col-md-11">
                          <CustomSelect
                            key={uid(clinic, idx)}
                            value={clinic}
                            len={clinicList.length}
                            minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                            idx={idx}
                            clearCurrentVal={
                              idx === clinicList.length - 1 && !clinic.id
                                ? resetSelect
                                : false
                            }
                            afterClearCurrentValFn={() => {
                              if (idx === clinicList.length - 1 && !clinic.id) {
                                this.setState({ resetSelect: false });
                              }
                            }}
                            optionUrl={API.CLINICSSEARCH}
                            filterOptions={{ key: 'id', values: clinicList }}
                            searchParam="name"
                            displayAttr={['name', 'hillromId']}
                            onChange={evt => this.handleClinicChange(evt, idx)}
                            onRemove={evt => this.handleClinicRemove(evt, idx)}
                            clearable
                            isDisabled={!isEmpty(clinic.id)}
                          />
                        </div>
                        <div
                          className={`col-1 col-md-1 d-flex justify-content-start align-items-center px-0`}
                        >
                          {!isEmpty(clinic.id) && selectedClinics.length > 1 ? (
                            <img
                              src={trash}
                              role="presentation"
                              alt="Delete"
                              width="14px"
                              height="14px"
                              onClick={evt => this.handleClinicRemove(evt, idx)}
                              onKeyPress={evt =>
                                this.handleClinicRemove(evt, idx)
                              }
                            />
                          ) : null}
                        </div>
                      </div>
                    </Form.Group>
                    <Form.Group
                      as={Col}
                      md={2}
                      className={`provider-clinic-view ${isMobile && !clinic.id ? 'd-none' : ''
                        }`}
                    >
                      {clinic.id && (
                        <Link
                          to={reverse(urls.CLINIC.DETAIL.DETAILS, {
                            id: clinic.id
                          })}
                          className="btn btn-sm btn-outline-info"
                          role="button"
                        >
                          {strings.viewClinic}
                        </Link>
                      )}
                    </Form.Group>
                    {idx === clinicList.length - 1 && (
                      <Form.Group
                        as={isMobile ? Col : 'div'}
                        md={2}
                        className={`pt-4 mt-2 ${!isMobile ? 'ml-auto' : ''}`}
                      >
                        <ButtonComponent
                          buttonAction={this.handleClinicAdd}
                          style={!isMobile ? { marginRight: '1.25rem' } : {}}
                          icon="add-icon"
                          buttonText={strings.addClinic}
                        />
                      </Form.Group>
                    )}
                  </Form.Row>
                ))}
                <hr />
                <h6 className="text-capitalize">{strings.generalDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={firstName}
                      name="firstName"
                      onChange={this.handleChange}
                      maxLength="50"
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.middleName}</Form.Label>
                    <FormControlComponent
                      type="text"
                      value={middleName}
                      name="middleName"
                      onChange={this.handleChange}
                      maxLength="50"
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={lastName}
                      name="lastName"
                      onChange={this.handleChange}
                      maxLength="50"
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.credentials}</Form.Label>
                    <FormControlComponent
                      type="text"
                      value={credentials || ''}
                      name="credentials"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.speciality}</Form.Label>
                    <Form.Control
                      as="select"
                      value={speciality}
                      name="speciality"
                      onChange={this.handleChange}
                      className="text-capitalize"
                    >
                      <option defaultValue value="">
                        {strings.selectSpeciality}
                      </option>
                      {this.getSpeciality()}
                    </Form.Control>
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.npiNumber}</Form.Label>

                    <FormControlComponent
                      className="form-control"
                      value={npiNumber}
                      name="npiNumber"
                      onChange={this.handleChange}
                      maxLength="15"
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <h6>{strings.contactDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={email}
                      name="email"
                      onChange={this.handleChange}
                      maxLength="100"
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      readOnly
                      type="text"
                      name="city"
                      value={city}
                      onChange={this.handleChange}
                      placeholder={strings.city}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={2}>
                    <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      readOnly
                      type="text"
                      name="state"
                      value={state}
                      onChange={this.handleChange}
                      placeholder={strings.state}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={2}>
                    <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>

                    <FormControlComponent
                      type="text"
                      name="zipcode"
                      value={zipcode}
                      onChange={this.handleChange}
                      onBlur={event => {
                        this.handleZipChange(event);
                      }}
                      placeholder={strings.zipcode}
                      maxLength="7"
                    />
                  </Form.Group>
                </Form.Row>
                {!isMobile && <hr />}
                <ButtonComponent
                  id="save-provider-bottom"
                  buttonClass="float-right"
                  buttonAction={this.handleSubmit}
                  icon="update-icon"
                  buttonText={strings.save}
                />
              </Form>
              <p id="error" className="text-danger">
                {error}
              </p>
              <FootNote />
            </MainContent>
          ) : null}
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  const {
    clinicsReducer,
    userReducer,
    breadcrumbsReducer,
    providerReducer
  } = state.app;
  return {
    specialityList: clinicsReducer.speciality,
    cityStateByZip: userReducer.cityStateByZip,
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    addProviderStatus: providerReducer.addProviderStatus
  };
};
export default connect(
  mapStateToProps,
  null
)(NewProvider);
