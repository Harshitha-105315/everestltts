import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Header, SideBar } from 'components/Navigation';
import strings from 'localization/strings';
import Search from 'components/Search';
import constants from 'constants.js';
import TableDisplay from 'components/TableDisplay';
import { FootNote } from 'components/FootNote';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getSearchString, getUserData } from 'utils/helper.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { getCityByStateCountryList } from 'utils/helper.js';
import './Providers.scss';
import ButtonComponent from 'components/ButtonComponent';
import { uid } from 'react-uid';
import { isUndefined, isEmpty } from 'lodash';
import debounce from 'lodash/debounce';
import {
  updateUrl,
  clearBreadCrumb,
  addBreadCrumb,
  clearCustomPatientStoreValue
} from '../utils/utltity';

class Providers extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      asc: true,
      page: 1,
      perPage: 10,
      sortBy: 'firstName',
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      providerSpeciality: null,
      viewMore: '',
      status: 'all',
      filterOn: false
    };
    this.fetchProviders = this.fetchProviders.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.getSearchString = getSearchString.bind(this);
    this.updateUrl = updateUrl.bind(this);
    this.clearBreadCrumb = clearBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.clearCustomPatientStoreValue = clearCustomPatientStoreValue.bind(this);
    this.filterCheck = this.filterCheck.bind(this);
    this.changeSearch = debounce(() => {
      this.dispatchSearch();
      this.updateUrl(this.exempt);
    }, constants.SEARCH_DEBOUNCE_MS);
    this.exempt = ['viewMore', 'filterOn'];
  }

  async componentWillMount() {
    const {
      dispatch
    } = this.props;
    this.clearCustomPatientStoreValue([
      'statesByCountry',
      'cityByStateCountry'
    ]);
    const newState = { ...this.state };
    if (
      newState.country !== null &&
      newState.country !== '' &&
      !isUndefined(newState.country)
    ) {
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [newState.country] }
      });
      if (
        newState.state !== null &&
        newState.state !== '' &&
        !isUndefined(newState.state)
      ) {
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [newState.country], state: [newState.state] }
        });
      }
    } else {
      newState.country = null;
      newState.state = null;
      newState.city = null;
    }
    this.filterCheck();
    this.dispatchSearch();
    this.clearBreadCrumb();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB,
      toggleValue: false
    });
  }

  dispatchSearch = () => {
    const { dispatch } = this.props;
    const payload = Object.assign({}, this.state);
    ['viewMore', 'filterOn'].forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.PROVIDER.PROVIDER_REQUEST,
      payload
    });
  };

  getClinicField = (index, clinics) => {
    let { viewMore } = this.state;
    if (clinics.length === 1) {
      return clinics[0].name;
    }
    return (
      <span>
        {clinics[0].name}
        <span
          name="view-more-provider-clinics"
          value={index}
          className={viewMore === index ? 'd-none' : 'view-more-patients'}
          onClick={() => {
            this.setState({ viewMore: index });
            viewMore = index;
          }}
          role="presentation"
        >
          {` +${clinics.length - 1} more`}
        </span>
        <span className={viewMore === index ? '' : 'd-none'}>
          {clinics.slice(1).map(element => {
            return <div key={uid(element)}>{element.name}</div>;
          })}
        </span>
      </span>
    );
  };

  getStatus = d => {
    if (d.activated && !d.deleted) {
      return (
        <div>
          <div className="green-active d-inline-block" />
          <span className="text-capitalize">{strings.active}</span>
        </div>
      );
    }
    if (!d.activated && !d.deleted) {
      return (
        <div>
          <div className="d-inline-block grey-pending" />
          <span className="text-capitalize">{strings.pending}</span>
        </div>
      );
    }
    return (
      <div>
        <div className=" red-inactive d-inline-block" />
        <span className="text-capitalize">{strings.inactive}</span>
      </div>
    );
  };

  getProvidersList = () => {
    const { providers, history } = this.props;
    if (!isEmpty(providers)) {
      return providers.map(d => (
        <tr
          key={uid(d)}
          className="listing"
          onClick={event => {
            if (
              event.target.getAttribute('name') !== 'view-more-provider-clinics'
            ) {
              this.addBreadCrumb({ title: strings.manageProviders });
              history.push(reverse(urls.PROVIDER.DETAIL, { id: d.id }));
            }
          }}
        >
          <td id="provider-name-providers" className="providers-name-cell">
            {`${d.firstName} ${d.lastName}`}
            <p className="secondary-data d-sm-none">
              {d.id}
              <span className="spacer" />
              {d.clinics.map(element => {
                return element.name;
              })}
            </p>
          </td>
          <td id="clinic-name-providers" className="d-none d-sm-table-cell">
            {d.clinics.length === 0
              ? ''
              : this.getClinicField(providers.indexOf(d), d.clinics)}
          </td>
          <td id="city-state-providers" className="d-none d-sm-table-cell">
            {(d.city ? `${d.city}` : '') +
              (d.city && d.state ? '/' : '') +
              (d.state ? `${d.state}` : '')}
          </td>
          <td id="provider-npi-number" className="d-none d-sm-table-cell">
            {d.npiNumber ? `${d.npiNumber}` : ''}
          </td>
          <td id="status-providers" className="providers-status-cell">
            {this.getStatus(d)}
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="5" className="text-center text-capitalize">
          {strings.noProviderDataAvaliable}
        </td>
      </tr>
    );
  };

  async filterCheck() {
    const { country, status, state } = this.state;
    if (status !== constants.FILTER_VALUES.ALL || country !== constants.LOCATIONS[0] || state !== null) {
      await this.setState({ filterOn: true });
    } else {
      await this.setState({ filterOn: false });
    }
  }

  async fetchProviders(event) {
    const name = (event && event.target.value) || '';
    await this.resetFilter(true);
    await this.setState({ name, page: 1 });
    this.changeSearch();
  }

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
    this.dispatchSearch();
    this.updateUrl(this.exempt);
  }

  async handleFilter(event) {
    const { name, value } = event.target;
    const { dispatch } = this.props;
    if (name === 'country') {
      if (value === 'country') {
        await this.setState({ country: null });
        const { state, city } = this.state;
        if (state !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ state: null });
        }
        if (city !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ city: null });
        }
      } else {
        this.clearCustomPatientStoreValue([
          'statesByCountry',
          'cityByStateCountry'
        ]);
        dispatch({
          type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
          payload: { country: [value] }
        });
        await this.setState({
          [name]: value,
          city: null,
          state: null,
          page: 1
        });
      }
    } else if (name === 'state') {
      if (value === 'state') {
        await this.setState({ state: null, city: null });
        this.clearCustomPatientStoreValue(['cityByStateCountry']);
      } else {
        const { country } = this.state;
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [country], state: [value] }
        });
        await this.setState({ [name]: value, city: null, page: 1 });
      }
    } else if (name === 'city') {
      if (value === 'city') {
        await this.setState({ city: null });
      } else {
        await this.setState({ [name]: value, page: 1 });
      }
    } else {
      await this.setState({ [name]: value, page: 1 });
    }
    this.filterCheck();
    this.dispatchSearch();
    this.updateUrl(this.exempt);
  }

  async handleSorting(event) {
    const { asc, sortBy } = this.state;
    const { name } = event.target;
    await this.setState({ page: 1 });
    if (sortBy !== name) {
      await this.setState({ sortBy: name, asc: true });
    } else {
      await this.setState({ asc: !asc });
    }
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async resetFilter(onlyReset) {
    const { dispatch } = this.props;
    if (this.state.country === constants.LOCATIONS[0]) {
      this.clearCustomPatientStoreValue([
        'cityByStateCountry'
      ]);
    } else {
      this.clearCustomPatientStoreValue([
        'statesByCountry',
        'cityByStateCountry'
      ]);
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [constants.LOCATIONS[0]] }
      });
    }
    await this.setState({
      page: 1,
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      status: 'all',
      filterOn: false
    });
    if (!onlyReset) {
      this.updateUrl(this.exempt);
      this.dispatchSearch();
    }
  }

  render() {
    const {
      name,
      page,
      perPage,
      country,
      state,
      city,
      status,
      filterOn
    } = this.state;
    const {
      totalProviders,
      history,
      showSearch,
      statesByCountry,
      cityByStateCountry
    } = this.props;
    const { actualRole } = getUserData();
    const createProviderInformation = accessMatrix.CREATE_PROVIDER[actualRole];
    const searchProviders = accessMatrix.SEARCH_PROVIDERS[actualRole];
    const cityByStateCountryList = getCityByStateCountryList(
      cityByStateCountry
    );
    return (
      <div>
        <Header
          searchExitHandle={async () => {
            await this.setState({ name: '' });
            const { dispatch } = this.props;
            const payload = { ...this.state };
            ['viewMore', 'filterOn'].forEach(element => {
              delete payload[element];
            });
            dispatch({
              type: constants.PROVIDER.PROVIDER_REQUEST,
              payload
            });
            this.updateUrl(this.exempt);
          }}
        />
        {searchProviders.read ? (
          <MainWrapper>
            <SideBar
              filters={{
                Provider_Status: [
                  {
                    title: strings.all,
                    onChangeFunction: this.handleFilter,
                    name: constants.FILTER_NAME.STATUS,
                    value: constants.FILTER_VALUES.ALL,
                    type: constants.FILTER_TYPE.RADIO,
                    checked:
                      status === constants.FILTER_VALUES.ALL ? true : null
                  },
                  {
                    title: strings.active,
                    onChangeFunction: this.handleFilter,
                    name: constants.FILTER_NAME.STATUS,
                    value: constants.FILTER_VALUES.ACTIVE,
                    type: constants.FILTER_TYPE.RADIO,
                    checked:
                      status === constants.FILTER_VALUES.ACTIVE ? true : null
                  },
                  {
                    title: strings.inactive,
                    onChangeFunction: this.handleFilter,
                    name: constants.FILTER_NAME.STATUS,
                    value: constants.FILTER_VALUES.INACTIVE,
                    type: constants.FILTER_TYPE.RADIO,
                    checked:
                      status === constants.FILTER_VALUES.INACTIVE ? true : null
                  },
                  {
                    title: strings.pending,
                    onChangeFunction: this.handleFilter,
                    name: constants.FILTER_NAME.STATUS,
                    value: constants.FILTER_VALUES.PENDING,
                    type: constants.FILTER_TYPE.RADIO,
                    checked:
                      status === constants.FILTER_VALUES.PENDING ? true : null
                  }
                ],

                Location: [
                  {
                    title: strings.country,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.COUNTRY,
                    value: country || '',
                    onChangeFunction: this.handleFilter,
                    options: constants.LOCATIONS
                  },
                  {
                    title: strings.state,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.STATE,
                    value: state || '',
                    onChangeFunction: this.handleFilter,
                    options: country ? statesByCountry : []
                  },
                  {
                    title: strings.city,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.CITY,
                    value: city || '',
                    onChangeFunction: this.handleFilter,
                    options: country ? cityByStateCountryList : []
                  }
                ]
              }}
              showSearch={showSearch}
              resetFilter={this.resetFilter}
              filterOn={filterOn}
              hidden={name === '' ? false : true}
            />
            <MainContent
              {...(name !== ''
                ? { styleClass: 'col-md-10 table-search-desktop' }
                : {})}
            >
              <div id="table-data">
                <div>
                  <div className="table-header d-flex flex-wrap align-items-center">
                    <h1
                      className={`${
                        showSearch === true
                          ? 'd-none'
                          : 'text-capitalize d-inline marginv-auto'
                      }`}
                    >
                      {name ? strings.searchProviders : strings.manageProviders}
                    </h1>
                    <Search
                      searchString={name}
                      fetchOnChange={this.fetchProviders}
                      modifierClass="d-sm-inline"
                      showSearch={showSearch}
                      placeholder={strings.providerSearchPlaceholder}
                    />
                    <div className="breaker" />
                    <p
                      className={
                        totalProviders === 0 || name !== '' || showSearch
                          ? 'd-none'
                          : 'mobile-table-count d-sm-none text-capitalize'
                      }
                    >
                      {totalProviders} {strings.providers}
                    </p>
                    <ButtonComponent
                      id="new-provider"
                      buttonClass={`${
                        showSearch === true
                          ? 'd-none'
                          : 'overview-button ml-auto'
                      }`}
                      hidden={
                        !createProviderInformation.write || showSearch || name
                      }
                      buttonAction={() => {
                        this.addBreadCrumb({ title: strings.manageProviders });
                        history.push(urls.PROVIDER.ADD);
                      }}
                      icon="add-entity-icon"
                      buttonText={strings.newProvider}
                    />
                    <span
                      className={`${
                        name !== ''
                          ? 'table-search-exit cross-icon d-md-inline-block ml-auto'
                          : 'd-none'
                      }`}
                      onClick={async () => {
                        this.fetchProviders();
                      }}
                      onKeyPress={async () => {
                        this.fetchProviders();
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                  <div>
                    <h6
                      className={`${
                        name === '' ? 'd-none' : 'text-capitalize show-search'
                      } `}
                    >{`${strings.searchResults} (${totalProviders || 0})`}</h6>
                    <h6
                      className={
                        name === '' && showSearch
                          ? 'd-sm-none table-description'
                          : 'd-none'
                      }
                    >
                      {totalProviders || 0} {strings.providers}
                    </h6>
                    <TableDisplay
                      heading={[
                        {
                          text: strings.providerName,
                          sortable: true,
                          name: 'firstName',
                          value: 'firstName'
                        },
                        {
                          text: strings.clinicName,
                          sortable: true,
                          name: 'clinicName',
                          mobile: false
                        },
                        {
                          text: `${strings.city}/${strings.state}`,
                          sortable: false,
                          mobile: false
                        },
                        {
                          text: strings.npiNmber,
                          sortable: true,
                          name: 'npiNumber',
                          mobile: false
                        },
                        {
                          text: strings.status,
                          sortable: false,
                          name: 'isDeleted',
                          value: 'isDeleted'
                        }
                      ]}
                      totalUsers={totalProviders}
                      listing={this.getProvidersList()}
                      handleSorting={this.handleSorting}
                      getSearchString={this.getSearchString}
                      searchDisplay
                      pagination
                      handlePaginate={this.handlePaginate}
                      perPage={perPage}
                      page={page}
                      totalDisplayLabel={strings.providers}
                      searchString={name}
                      noResultFound={strings.noProviderDataAvaliable}
                    />
                  </div>
                </div>
              </div>
              <FootNote />
            </MainContent>
          </MainWrapper>
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { providerReducer, filterReducer, patient } = state.app;
  return {
    providers: providerReducer.providers,
    totalProviders: providerReducer.totalProviders || null,
    showSearch: filterReducer.showSearch,
    statesByCountry: patient.statesByCountry,
    cityByStateCountry: patient.cityByStateCountry
  };
};

export default connect(
  mapStateToProps,
  null
)(Providers);
