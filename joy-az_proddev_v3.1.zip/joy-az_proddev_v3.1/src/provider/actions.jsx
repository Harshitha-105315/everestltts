import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import strings from 'localization/strings';
import {
  fetchProvidersService,
  fetchProviderProfileService,
  associateClinicHcpService,
  disAssociateClinicHcpService,
  newProviderService,
  updateProviderService
} from 'provider/services';
import { filterOutFalsyValues } from 'utils/helper';
import { decryptemail } from '../Cryptocode';

export function* fetchProviders(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(fetchProvidersService, filterOutFalsyValues(action.payload));
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PROVIDER.PROVIDER_SUCCESS,
        response
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.PROVIDER.PROVIDER_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* fetchProviderProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(fetchProviderProfileService, action.id);
    response.data.user.email = decryptemail(response.data.user.email)

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PROVIDER.PROVIDER_PROFILE_SUCCESS,
        response: response.data,
        key: action.id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PROVIDER.PROVIDER_PROFILE_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* associateClinicHcp(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      associateClinicHcpService,
      action.data,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.PROVIDER.ASSOCIATE_CLINIC_SUCCESS,
        key: action.data[0].id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* disAssociateClinicHcp(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      disAssociateClinicHcpService,
      action.data,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.PROVIDER.DISASSOCIATE_CLINIC_SUCCESS,
        idx: action.idx,
        key: action.id
      });
      yield put({
        type: constants.PROVIDER.PROVIDER_PROFILE_REQUEST,
        id: action.id
      });
      yield put({
        type: constants.CLINICS.SPECIALITY_REQUEST
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* newProvider(action) {
  const { path, history, payload } = action.allData;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(newProviderService, payload);
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* updateProvider(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      updateProviderService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
