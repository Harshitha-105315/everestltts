import constants from 'constants.js';
import { setStateByKey } from 'utils/helper.js';

const intialState = {
  providers: [],
  totalProviders: 0,
  providerProfile: {},
  deleteClinicIdx: {},
  providerDisassociateSuccess: {},
  addProviderStatus: 0,
  providerAssociateSuccess: {},
  providerList: false
};

function providerReducer(state = intialState, action) {
  const tmpState = Object.assign({}, state);
  switch (action.type) {
    case constants.PROVIDER.NEW_PROVIDER_SUCCESS:
      tmpState.addProviderStatus = 1;
      return tmpState;
    case constants.PROVIDER.NEW_PROVIDER_FAILURE:
      tmpState.addProviderStatus = 0;
      return tmpState;
    case constants.PROVIDER.PROVIDER_SUCCESS:
      tmpState.providers = action.response.data;
      tmpState.totalProviders = Number(
        action.response.headers['x-total-count']
      );
      tmpState.providerList = true;
      return tmpState;
    case constants.PROVIDER.PROVIDER_FAILURE:
      tmpState.providers = [];
      tmpState.totalProviders = 0;
      return tmpState;
    case constants.PROVIDER.PROVIDER_PROFILE_SUCCESS:
      tmpState.providerProfile = setStateByKey(
        tmpState.providerProfile,
        action.key,
        action.response.user
      );
      return tmpState;
    case constants.PROVIDER.PROVIDER_PROFILE_FAILURE:
      tmpState.providerProfile = setStateByKey(
        tmpState.providerProfile,
        action.key,
        {}
      );
      return tmpState;
    case constants.PROVIDER.CLEAR_ADD_PROVIDER_STATUS:
      tmpState.addProviderStatus = 0;
      return tmpState;
    case constants.PROVIDER.CLEAR_PROVIDER_PROFILE:
      tmpState.providerProfile = setStateByKey(
        tmpState.providerProfile,
        action.key,
        {}
      );
      return tmpState;
    case constants.PROVIDER.DISASSOCIATE_CLINIC_SUCCESS:
      tmpState.providerDisassociateSuccess = setStateByKey(
        tmpState.providerDisassociateSuccess,
        action.key,
        constants.PROVIDER.DISASSOCIATE_CLINIC_SUCCESS
      );
      tmpState.deleteClinicIdx = setStateByKey(
        tmpState.deleteClinicIdx,
        action.key,
        action.idx
      );
      return tmpState;
    case constants.PROVIDER.ASSOCIATE_CLINIC_SUCCESS:
      tmpState.providerAssociateSuccess = setStateByKey(
        tmpState.providerAssociateSuccess,
        action.key,
        constants.PROVIDER.ASSOCIATE_CLINIC_SUCCESS
      );
      return tmpState;
    case constants.PROVIDER.RESET_PROPS_VALUE: {
      tmpState.providerDisassociateSuccess = setStateByKey(
        tmpState.providerDisassociateSuccess,
        action.key,
        false
      );
      tmpState.providerAssociateSuccess = setStateByKey(
        tmpState.providerAssociateSuccess,
        action.key,
        false
      );
      tmpState.deleteClinicIdx = setStateByKey(
        tmpState.deleteClinicIdx,
        action.key,
        ''
      );
      return tmpState;
    }
    default:
      return state;
  }
}

export default providerReducer;
