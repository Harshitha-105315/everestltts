import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { uid } from 'react-uid';
import update from 'immutability-helper';
import { Header, SideBar } from 'components/Navigation';
import trash from 'assets/icn-delete.svg';
import { last, isEmpty, every } from 'lodash';
import strings from 'localization/strings';
import CustomSelect from 'components/CustomSelect';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData, validateEmail } from 'utils/helper';
import API from 'api/api_config';
import ConfirmationDialog from 'components/ConfirmationDialog';
import { FootNote } from 'components/FootNote';
import urls from 'urls';

import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import constants from '../constants';
import {
  getSpeciality,
  removeBreadCrumb,
  addBreadCrumb,
  getBreadCrumb,
  handleZipChange
} from '../utils/utltity';

class ProviderProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      submitted: false,
      firstName: '',
      lastName: '',
      middleName: '',
      email: '',
      npiNumber: '',
      speciality: '',
      credentials: '',
      clinics: [{ name: '', id: '' }],
      error: '',
      city: '',
      state: '',
      zipcode: '',
      role: 'HCP',
      isAllow: false,
      resetSelect: false,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: true,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleClinicChange = this.handleClinicChange.bind(this);
    this.handleClinicRemove = this.handleClinicRemove.bind(this);
    this.handleClinicAdd = this.handleClinicAdd.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.handleZipChange = handleZipChange.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    const { match } = this.props;
    const { id } = match.params;
    dispatch({ type: constants.PROVIDER.PROVIDER_PROFILE_REQUEST, id });
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.providerDetails });
  }

  componentWillReceiveProps(newProps) {
    const { providerProfile } = this.props;
    if (isEmpty(providerProfile) && !isEmpty(newProps.providerProfile)) {
      if (newProps.providerProfile.clinics.length === 0) {
        newProps.providerProfile.clinics = [{ id: '', name: '' }];
      }
      this.setState(newProps.providerProfile);
    }
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }

    const { isAllow } = this.state;
    const { providerDisassociateSuccess, dispatch, match } = this.props;

    const { providerAssociateSuccess } = newProps;
    const { id } = match.params;
    if (
      isAllow &&
      providerDisassociateSuccess ===
      constants.PROVIDER.DISASSOCIATE_CLINIC_SUCCESS
    ) {
      const { deleteClinicIdx } = this.props;
      const { clinics } = this.state;
      this.setState({
        clinics: update(clinics, { $splice: [[deleteClinicIdx, 1]] }),
        isAllow: false
      });
      dispatch({
        type: constants.PROVIDER.RESET_PROPS_VALUE,
        key: id
      });
    }

    if (
      isAllow &&
      providerAssociateSuccess === constants.PROVIDER.ASSOCIATE_CLINIC_SUCCESS
    ) {
      const { clinics, dialog } = this.state;
      const { opt, idx } = dialog;
      this.setState({
        clinics: update(clinics, {
          [idx]: {
            $set: {
              name: opt ? opt.name : '',
              id: opt ? opt.id : ''
            }
          }
        }),
        isAllow: false
      });
      dispatch({
        type: constants.PROVIDER.RESET_PROPS_VALUE,
        key: id
      });
    }
  }

  componentWillUnmount() {
    const { dispatch, match } = this.props;
    const { id } = match.params;
    dispatch({ type: constants.PROVIDER.CLEAR_PROVIDER_PROFILE, key: id });
    this.removeBreadCrumb();
  }

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value, isDirty: true });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  clinicChange = () => {
    const { dialog } = this.state;
    const { opt } = dialog;
    const { dispatch, match } = this.props;
    const { id } = match.params;
    if (opt) {
      dispatch({
        type: constants.PROVIDER.ASSOCIATE_CLINIC_REQUEST,
        id: opt.id,
        data: [{ id }]
      });
    }
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isAllow: true
    });
  };

  getSelectedClinicsLength = clinics => {
    return clinics.filter(clinic => {
      return clinic.id ? true : false;
    });
  };

  submit = () => {
    const { match, dispatch } = this.props;
    const { id } = match.params;
    const { dialog } = this.state;
    const payload = Object.assign({}, this.state);
    ['error', 'isDirty'].forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.PROVIDER.UPDATE_PROVIDER_REQUEST,
      payload,
      id
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  clinicRemove = () => {
    const { clinics, dialog } = this.state;
    const { dispatch, match } = this.props;
    const { id } = match.params;
    const { idx } = dialog;
    dispatch({
      type: constants.PROVIDER.DISASSOCIATE_CLINIC_REQUEST,
      id,
      data: [{ id: clinics[idx].id }],
      idx
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isAllow: true
    });
  };

  async handleSubmit() {
    const {
      firstName,
      lastName,
      clinics,
      zipcode,
      city,
      email,
      dialog
    } = this.state;
    this.setState({ submitted: true });
    if (isEmpty(clinics) || (clinics.length > 0 && clinics[0].id === '')) {
      await this.setState({ error: strings.pleaseChooseClinic });
    } else if (firstName === '' || firstName === null) {
      await this.setState({ error: strings.enterFirstName });
    } else if (lastName === '' || lastName === null) {
      await this.setState({ error: strings.enterLastName });
    } else if (zipcode === '' || zipcode === null) {
      this.setState({ error: strings.pleaseEnterZipcode });
    } else if (email !== '' && !validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    } else if (city === '' || city === null) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else {
      const clinicList = clinics.map(element => {
        return { id: element.id };
      });
      await this.setState({ clinicList, error: '' });

      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.updateProviderMsg.replace(
            '{VALUE}',
            `${firstName} ${lastName}`
          ),
          title: strings.updateProvider,
          button: strings.updateProvider,
          confirmFunction: this.submit,
          show: true
        })
      });
    }
  }

  async handleClinicAdd() {
    const { clinics } = this.state;
    const ClinicInit = {
      id: '',
      name: ''
    };
    if (!every(last(clinics), isEmpty) || isEmpty(clinics)) {
      await this.setState({
        clinics: [...clinics, ClinicInit]
      });
    }
  }

  async handleClinicChange(opt, idx) {
    const { dialog } = this.state;
    if (opt) {
      await this.setState({
        dialog: Object.assign(dialog, {
          body: `Associate ${opt.name} clinic with the provider?`,
          title: strings.addNewClinic,
          button: strings.linkClinic,
          confirmFunction: this.clinicChange,
          opt,
          idx,
          show: true
        })
      });
    } else {
      await this.setState({
        dialog: Object.assign(dialog, {
          opt,
          idx
        })
      });
      this.clinicChange();
    }
  }

  async handleClinicRemove(evt, idx) {
    const { dialog, clinics } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        body: `Disassociate ${clinics[idx].name} clinic with the provider?`,
        title: strings.removeClinicProvider,
        button: strings.removeClinic,
        confirmFunction: this.clinicRemove,
        idx,
        show: true
      })
    });
  }

  render() {
    const {
      firstName,
      lastName,
      middleName,
      email,
      npiNumber,
      speciality,
      credentials,
      clinics,
      city,
      state,
      zipcode,
      isMobile,
      submitted,
      error,
      dialog,
      resetSelect
    } = this.state;
    const { location, match, breadcrumbs, history } = this.props;
    const { id } = match.params;
    const { actualRole } = getUserData();
    const providerInformation = accessMatrix.PROVIDER_INFORMATION[actualRole];

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.PROVIDER.DETAIL, { id }),
          text: 'Provider Details'
        }
      ]
    };
    const selectedClinics = this.getSelectedClinicsLength(clinics);
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.PROVIDER.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <h1 className="d-inline-block">{`${firstName} ${lastName}`}</h1>
              {
                <ButtonComponent
                  buttonClass="float-right"
                  hidden={!providerInformation.write}
                  buttonAction={this.handleSubmit}
                  icon="update-icon"
                  buttonText={strings.update}
                  id="provider-update"
                />
              }
            </div>
            <Form className={`${submitted ? ' submitted' : ''}`}>
              <div
                style={isMobile ? { height: '2.25rem' } : {}}
                className="mb-3"
              >
                <h6
                  style={isMobile ? { verticalAlign: 'sub' } : {}}
                  className="text-capitalize d-inline"
                >
                  {strings.clinicDetails}
                </h6>
                <p className="text-danger">{error}</p>
              </div>

              {clinics.map((clinic, idx) => (
                <Form.Row>
                  <Form.Group as={Col} md={8}>
                    <Form.Label className="text-uppercase">
                      {strings.clinicName} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <div className="row">
                      <div className="col-11 col-md-11">
                        <CustomSelect
                          key={uid(clinic, idx)}
                          value={clinic}
                          len={clinics.length}
                          minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                          idx={idx}
                          clearCurrentVal={
                            idx === clinics.length - 1 && !clinic.id
                              ? resetSelect
                              : false
                          }
                          afterClearCurrentValFn={() => {
                            if (idx === clinics.length - 1 && !clinic.id) {
                              this.setState({ resetSelect: false });
                            }
                          }}
                          optionUrl={`${API.CLINICSSEARCH}?page=1&per_page=100&sort_by=name&asc=true&status=active`}
                          filterOptions={{ key: 'id', values: clinics }}
                          searchParam="name"
                          urlSymbol="&"
                          displayAttr={['name', 'hillromId']}
                          onChange={evt => this.handleClinicChange(evt, idx)}
                          onRemove={evt => this.handleClinicRemove(evt, idx)}
                          clearable
                          isDisabled={!isEmpty(clinic.id)}
                        />{' '}
                      </div>
                      <div
                        className={`col-1 col-md-1 d-flex justify-content-start align-items-center px-0`}
                      >
                        {!isEmpty(clinic.id) &&
                          selectedClinics.length > 1 &&
                          providerInformation.write ? (
                            <img
                              src={trash}
                              role="presentation"
                              alt="Delete"
                              width="14px"
                              height="14px"
                              onClick={evt => this.handleClinicRemove(evt, idx)}
                              onKeyPress={evt =>
                                this.handleClinicRemove(evt, idx)
                              }
                            />
                          ) : null}
                      </div>
                    </div>
                  </Form.Group>
                  <Form.Group
                    as={Col}
                    md={2}
                    className={`provider-clinic-view ${isMobile && !clinic.id ? 'd-none' : ''
                      }`}
                  >
                    {clinic.id && (
                      <React.Fragment>
                        <Link
                          to={reverse(urls.CLINIC.DETAIL.DETAILS, {
                            id: clinic.id
                          })}
                          className="btn btn-sm btn-outline-info"
                          role="button"
                          onClick={() => {
                            this.addBreadCrumb({
                              title: strings.associatedPatients
                            });
                          }}
                          disabled={!providerInformation.write}
                        >
                          {strings.viewClinic}
                        </Link>
                      </React.Fragment>
                    )}
                  </Form.Group>
                  {idx === clinics.length - 1 && (
                    <Form.Group
                      as={isMobile ? Col : 'div'}
                      md={2}
                      className={`pt-4 mt-2 ${!isMobile ? 'ml-auto' : ''}`}
                    >
                      <ButtonComponent
                        buttonClass="float-left"
                        style={!isMobile ? { marginRight: '1.25rem' } : {}}
                        hidden={!providerInformation.write}
                        buttonAction={this.handleClinicAdd}
                        icon="report-detail-icon"
                        buttonText={strings.addClinic}
                        id="provider-addClinic"
                      />
                    </Form.Group>
                  )}
                </Form.Row>
              ))}
              {isEmpty(clinics) && (
                <Form.Row>
                  <Form.Group as={Col} md={9}>
                    {strings.noClinicAssociated}.
                  </Form.Group>

                  <Form.Group
                    as={isMobile ? Col : 'div'}
                    md={2}
                    className={`pt-4 mt-2 ${!isMobile ? 'ml-auto' : ''}`}
                  >
                    <ButtonComponent
                      buttonClass="float-left"
                      style={!isMobile ? { marginRight: '1.25rem' } : {}}
                      hidden={!providerInformation.write}
                      buttonAction={this.handleClinicAdd}
                      icon="report-detail-icon"
                      buttonText={strings.addClinic}
                    />
                  </Form.Group>
                </Form.Row>
              )}
              <hr />
              <div id="provider-generalDetails">
                <h6 className="text-capitalize">{strings.generalDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={firstName}
                      name="firstName"
                      required
                      onChange={this.handleChange}
                      readOnly={!providerInformation.write}
                      maxLength="50"
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.middleName}</Form.Label>
                    <FormControlComponent
                      type="text"
                      value={middleName || ''}
                      name="middleName"
                      onChange={this.handleChange}
                      readOnly={!providerInformation.write}
                      maxLength="50"
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={lastName}
                      name="lastName"
                      required
                      onChange={this.handleChange}
                      readOnly={!providerInformation.write}
                      maxLength="50"
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.credentials}</Form.Label>
                    <FormControlComponent
                      type="text"
                      value={credentials || ''}
                      name="credentials"
                      onChange={this.handleChange}
                      readOnly={!providerInformation.write}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.speciality}</Form.Label>
                    <Form.Control
                      as="select"
                      value={speciality || ''}
                      name="speciality"
                      onChange={this.handleChange}
                      className="text-capitalize"
                      disabled={!providerInformation.write}
                    >
                      <option defaultValue disabled value="">
                        {strings.selectSpeciality}
                      </option>
                      {this.getSpeciality()}
                    </Form.Control>
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.npiNumber}</Form.Label>
                    <FormControlComponent
                      className="form-control"
                      value={npiNumber || ''}
                      name="npiNumber"
                      onChange={this.handleChange}
                      readOnly={!providerInformation.write}
                      maxLength="15"
                    />
                  </Form.Group>
                </Form.Row>
              </div>
              <hr />
              <h6>{strings.contactDetails}</h6>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label>{strings.email}</Form.Label>
                  <FormControlComponent
                    type="text"
                    value={email}
                    name="email"
                    onChange={this.handleChange}
                    readOnly={!providerInformation.write}
                    maxLength="100"
                  />
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                  <FormControlComponent
                    readOnly
                    type="text"
                    name="city"
                    value={city}
                    onChange={this.handleChange}
                    placeholder="City"
                  />
                </Form.Group>
                <Form.Group as={Col} md={2}>
                  <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                  <FormControlComponent
                    readOnly
                    type="text"
                    name="state"
                    value={state}
                    onChange={this.handleChange}
                    placeholder="State"
                  />
                </Form.Group>
                <Form.Group as={Col} md={2}>
                  <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>
                  <FormControlComponent
                    type="text"
                    name="zipcode"
                    value={zipcode}
                    required
                    onChange={this.handleChange}
                    onBlur={event => {
                      this.handleZipChange(event);
                    }}
                    readOnly={!providerInformation.write}
                    maxLength="7"
                  />
                </Form.Group>
              </Form.Row>
              {!isMobile && <hr />}
              <ButtonComponent
                id="save-provider-bottom"
                buttonClass="float-right"
                buttonAction={this.handleSubmit}
                icon="update-icon"
                hidden={!providerInformation.write}
                buttonText={strings.update}
              />
            </Form>
            <p className="text-danger" id="error">
              {error}
            </p>
            <FootNote />
          </MainContent>
        </MainWrapper>
        {providerInformation.write ? (
          <ConfirmationDialog
            show={dialog.show}
            handleClose={dialog.handleClose}
            body={dialog.body}
            title={dialog.title}
            button={dialog.button}
            confirmFunction={dialog.confirmFunction}
          />
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const {
    providerReducer,
    clinicsReducer,
    breadcrumbsReducer,
    userReducer
  } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    providerProfile: providerReducer.providerProfile[id],
    specialityList: clinicsReducer.speciality,
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    cityStateByZip: userReducer.cityStateByZip,
    deleteClinicIdx: providerReducer.deleteClinicIdx[id],
    providerDisassociateSuccess:
      providerReducer.providerDisassociateSuccess[id],
    providerAssociateSuccess: providerReducer.providerAssociateSuccess[id]
  };
};

export default connect(
  mapStateToProps,
  null
)(ProviderProfile);
