import API from 'api/api_config';
import { authRequest } from 'utils/axios_utils';
import constants from 'constants.js';

export function fetchProvidersService(params) {
  return authRequest({
    url: `${API.PROVIDERSEARCH}`,
    params,
    method: 'GET',
    'x-response': true
  });
}

export function fetchProviderProfileService(id) {
  return authRequest({
    url: API.USERPROVIDER.replace('{PROVIDERID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

export function associateClinicHcpService(dataId, id) {
  return authRequest({
    url: API.ASSOCIATEHCP.replace('{ENTITY}', 'clinics').replace(
      '{ENTITYID}',
      id
    ),
    method: 'PUT',
    data: dataId,
    [constants.RETURNRESPONSE]: true
  });
}

export function disAssociateClinicHcpService(dataId, id) {
  return authRequest({
    url: API.DIASSOCIATECLINICSPROVIDER.replace('{ID}', id),
    method: 'PUT',
    data: dataId,
    [constants.RETURNRESPONSE]: true
  });
}

export function newProviderService(payload) {
  return authRequest({
    url: API.PROFILE.replace('{id}', ''),
    method: 'POST',
    data: payload,
    'x-response': true,
    [constants.RETURNRESPONSE]: true
  });
}

export function updateProviderService(payload, id) {
  return authRequest({
    url: API.PROFILE.replace('{id}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}
