import { takeLatest, takeEvery } from 'redux-saga/effects';
import {
  fetchSpeciality,
  clinicsSearch,
  getClinic,
  getClinicAdmins,
  getClinicHcp,
  addClinic,
  associatedPatients,
  getAllClinics,
  updateClinic,
  associateProvider,
  disAssociateProvider,
  getClinicAllAdmins,
  associatedClinicAdmin,
  disassociateClinicAdmin,
  getAssociatedPatientCards,
  flagClinicAction,
  getClinicAccountExecutives,
  diassociateAccountExecutive,
  associateAccountExecutive,
  activateClinic,
  deactivateClinic
} from 'clinics/actions';
import {
  fetchProviders,
  fetchProviderProfile,
  associateClinicHcp,
  disAssociateClinicHcp,
  newProvider,
  updateProvider
} from 'provider/actions';
import getLanguages from 'languages/actions';
import constants from './constants';
import loginUser from './landing/login/actions';
import {
  firstTimeActivation,
  finishResetPassword,
  securityQuestionsAction
} from './landing/activation/actions';
import forgotPasswordAction from './landing/forgotpassword/actions';
import Profile from './Profile/actions';
import PatientAction from './patient/actions';
import {
  fetchTherapySetting,
  updateTherapySetting
} from './landing/therapysetting/actions';
import getAccountAction from './account/actions';
import {
  fetchUserProfiles,
  createUserProfile,
  getUserInfo,
  updateUserInfo,
  cityStateByZip,
  ccityStateByZip,
  activateUserProfile,
  deactivateUserProfile,
  resendActivationLinkUserProfile,
  resetPasswordUserProfile,
  getReasonCodeAction
} from './user-management/actions';
import { logoutUser, flushStore } from './logout/actions';
import ProtocolAction from './carePlanAndDevice/protocol/actions';
import EditProtocolDevice from './carePlanAndDevice/editProtocol/actions';
import EditDeviceAction from './carePlanAndDevice/addDevice/actions';
import TimsScriptAction from './timsScript/actions';
import SandBoxAction from './sandbox/actions';
import {
  fetchNotificationData,
  updateNotificationSettings
} from './notifications/actions';
import AnnouncementAction from './announcements/actions';
import { toggleFilter, toggleHeader } from './components/Navigation/actions';

export default function* rootSaga() {
  yield takeLatest(constants.LOGIN.LOGIN_REQUEST, loginUser);
  yield takeEvery(constants.ACTIVATE.ACTIVATE_ACCOUNT, firstTimeActivation);
  yield takeLatest(constants.ACTIVATE.RESET_PASSWORD, finishResetPassword);
  yield takeEvery(
    constants.ACTIVATE.SECURITYQUESTIONS,
    securityQuestionsAction
  );
  yield takeEvery(
    constants.FORGOTPASSWORD.FORGOT_PASS_REQUEST,
    forgotPasswordAction
  );
  yield takeEvery(
    constants.PROFILE.UPDATEPASSWORD_REQUEST,
    Profile.updatePasswordAction
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_OVERVIEW,
    PatientAction.fetchOverviewData
  );
  yield takeEvery(
    constants.THERAPY_SETTING,
    fetchTherapySetting
  );
  yield takeEvery(
    constants.UPDATE_THERAPY_SETTING,
    updateTherapySetting
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_ALL_PROTOCOL_DATA,
    PatientAction.fetchPatientAllProtocolData
  );
  yield takeLatest(
    constants.PATIENT.RESET_PATIENT_OVERVIEW,
    PatientAction.resetOverviewData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENT_DATA,
    PatientAction.fetchPatientData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENT_SESSION_DATA,
    PatientAction.fetchPatientSessionData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_USER_DATA,
    PatientAction.fetchUserData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENT_CLINIC_DATA,
    PatientAction.fetchPatientClinicData
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_PROVIDER_DATA,
    PatientAction.fetchPatientProviderData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENT_STATS_DATA,
    PatientAction.fetchPatientStatsData
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_ADHERENCE_DATA,
    PatientAction.fetchPatientAdherenceData
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_ADHERENCE_DATA_ALL_MONTHS,
    PatientAction.fetchPatientAdherenceDataAllMonths
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENT_PROTOCOL_DATA,
    PatientAction.fetchPatientProtocolData
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_THERAPY_DATA,
    PatientAction.fetchPatientTherapyData
  );
  yield takeEvery(
    constants.PATIENT.FETCH_ENHANCED_PATIENT_THERAPY_DATA,
    PatientAction.fetchEnhancedPatientTherapyData
  )
  yield takeEvery(
    constants.PATIENT.FETCH_ENHANCED_PATIENTS_THERAPY_DATA,
    PatientAction.fetchEnhancedPatientsTherapyData
  )
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_THERAPY_DATA_ALL_MONTHS,
    PatientAction.fetchPatientTherapyDataAllMonths
  );
  yield takeEvery(
    constants.PATIENT.FETCH_PATIENT_SESSION_DATA_ALL_MONTHS,
    PatientAction.fetchPatientSessionDataAllMonths
  );
  yield takeLatest(
    constants.PATIENT.DOWNLOAD_DETAILED_REPORT,
    PatientAction.downloadDetailedReport
  );
  yield takeLatest(constants.ACCOUNT.ACCOUNT_REQUEST, getAccountAction);
  yield takeLatest(constants.USER.USER_SEARCH_REQUEST, fetchUserProfiles);
  yield takeLatest(constants.USER.USER_CREATE_REQUEST, createUserProfile);
  yield takeLatest(constants.USER.USER_ACTIVATE_REQUEST, activateUserProfile);
  yield takeLatest(
    constants.USER.USER_DEACTIVATE_REQUEST,
    deactivateUserProfile
  );
  yield takeLatest(
    constants.USER.USER_RESET_PASSWORD_REQUEST,
    resetPasswordUserProfile
  );
  yield takeLatest(constants.USER.REASON_CODE_REQUEST, getReasonCodeAction);
  yield takeLatest(
    constants.USER.USER_RESEND_ACTIVATION_LINK_REQUEST,
    resendActivationLinkUserProfile
  );
  yield takeLatest(constants.LOGOUT.LOGOUT_REQUEST, logoutUser);
  yield takeLatest(constants.LOGOUT.FLUSH_STORE_REQUEST, flushStore)
  yield takeEvery(constants.DEVICE.FETCH_PROTOCOL, ProtocolAction.fetchDevice);
  yield takeLatest(
    constants.DEVICE.FETCH_PROTOCOL_OVERVIEW,
    ProtocolAction.fetchProtocolOverview
  );
  yield takeEvery(
    constants.DEVICE.PATIENT_DATA,
    ProtocolAction.getPatientAction
  );
  yield takeEvery(
    constants.DEVICE.FETCH_DEVICE_INFO,
    ProtocolAction.fetchDeviceInfo
  );
  yield takeEvery(
    constants.DEVICE.EDIT_PROTOCOL,
    EditProtocolDevice.editProtocolDevice
  );
  yield takeEvery(
    constants.DEVICE.FETCH_EDIT_DEVICES_INFO,
    EditDeviceAction.fetchEditDeviceInfo
  );
  yield takeLatest(
    constants.DEVICE.FETCH_RTU_SETTING_HISTORY_DATA,
    ProtocolAction.fetchRTUSettingHistoryInfo
  );
  yield takeEvery(
    constants.DEVICE.ADHERENCE_RESET_HISTORY,
    ProtocolAction.adherenceResetHistory
  );
  yield takeLatest(constants.CLINICS.SPECIALITY_REQUEST, fetchSpeciality);
  yield takeLatest(
    constants.PATIENT.PATIENT_SEARCH_REQUEST,
    PatientAction.fetchPatients
  );
  yield takeLatest(
    constants.PATIENT.PATIENT_SEARCH_ROLE_REQUEST,
    PatientAction.fetchRoleBasedPatients
  );
  yield takeLatest(
    constants.PATIENT.STORE_PATIENT_SPIRO_LOG_DATA,
    PatientAction.storePatientSpiroLogData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENTS_COUNT,
    PatientAction.getPatientCounts
  );
  yield takeLatest(
    constants.PATIENT.FETCH_PATIENTS_ROLE_COUNT,
    PatientAction.getPatientRoleCounts
  );
  yield takeLatest(
    constants.PATIENT.PATIENT_INFO_REQUEST,
    PatientAction.getPatientInfo
  );
  yield takeLatest(
    constants.PATIENT.GARMENT_PARAMETERS_REQUEST,
    PatientAction.getGarmentParameters
  );
  yield takeLatest(
    constants.DEVICE.ADD_DEVICE_REQUEST,
    EditDeviceAction.addDeviceRequest
  );
  yield takeLatest(
    constants.DEVICE.DELETE_DEVICE_REQUEST,
    ProtocolAction.deleteDeviceRequest
  );
  yield takeLatest(
    constants.DEVICE.EDIT_DEVICE_REQUEST,
    EditDeviceAction.editDeviceRequest
  );
  yield takeLatest(
    constants.DEVICE.EDIT_PROTOCOL_REQUEST_MONARCH,
    EditProtocolDevice.updateProtocolRequestMonarch
  );
  yield takeLatest(
    constants.DEVICE.EDIT_PROTOCOL_REQUEST_TITAN,
    EditProtocolDevice.updateProtocolRequestTitan
  );

  yield takeLatest(
    constants.DEVICE.EDIT_PROTOCOL_REQUEST_VEST,
    EditProtocolDevice.updateProtocolRequestVest
  );

  yield takeLatest(
    constants.DEVICE.RESET_ADHERENCE,
    ProtocolAction.resetAdherence
  );
  yield takeLatest(
    constants.DEVICE.DELETE_PROTOCOL_REQUEST,
    ProtocolAction.deleteProtocolRequest
  );
  yield takeLatest(
    constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_MONARCH,
    EditProtocolDevice.addNewProtocolMonarch
  );

  yield takeLatest(
    constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_TITAN,
    EditProtocolDevice.addNewProtocolTitan
  );
  yield takeLatest(
    constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_VEST,
    EditProtocolDevice.addNewProtocolVest
  );
  yield takeLatest(
    constants.PATIENT.CLINICSBYPATIENT_REQUEST,
    PatientAction.getClinicsByPatient
  );
  yield takeLatest(
    constants.PATIENT.CAREGIVERBYPATIENT_REQUEST,
    PatientAction.getCaregiverByPatient
  );
  yield takeLatest(
    constants.PATIENT.DIAGNOSIS_SEARCH_REQUEST,
    PatientAction.getDiagnosisSearchResult
  );
  yield takeLatest(constants.FILTER.TOGGLE_HEADER, toggleHeader);
  yield takeLatest(constants.FILTER.TOGGLE_FILTER, toggleFilter);
  yield takeLatest(constants.USER.USER_REQUEST, getUserInfo);
  yield takeLatest(constants.USER.USER_UPDATE_REQUEST, updateUserInfo);
  yield takeLatest(constants.ZIP.CITYSTATEBYZIP_REQUEST, cityStateByZip);
  yield takeLatest(constants.CLINICS.CLINICS_SEARCH_REQUEST, clinicsSearch);
  yield takeLatest(constants.CLINICS.CLINIC_BYID_REQUEST, getClinic);
  yield takeLatest(constants.CLINICS.CLINIC_ADMIN_REQUEST, getClinicAdmins);
  yield takeLatest(constants.CLINICS.CLINIC_HCP_REQUEST, getClinicHcp);
  yield takeLatest(constants.LANGUAGES.LANGUAGES_REQUEST, getLanguages);
  yield takeLatest(constants.CLINICS.ADD_CLINIC_REQUEST, addClinic);
  yield takeLatest(constants.CLINICS.ACTIVATE_CLINIC, activateClinic);
  yield takeLatest(constants.CLINICS.DEACTIVATE_CLINIC, deactivateClinic);
  yield takeLatest(
    constants.PATIENT.UPDATE_PATIENT_REQUEST,
    PatientAction.updatePatientDetails
  );
  yield takeLatest(
    constants.PATIENT.PROVIDERSBYPATIENT_REQUEST,
    PatientAction.getProvidersByPatient
  );
  yield takeLatest(
    constants.PATIENT.ASSOCIATECLINIC_REQUEST,
    PatientAction.associateClinic
  );
  yield takeLatest(
    constants.PATIENT.DISASSOCIATE_REQUEST,
    PatientAction.disassociateClinic
  );
  yield takeLatest(
    constants.PATIENT.HCPBYPATIENTCLINICS_REQUEST,
    PatientAction.getHcpByPatientClinics
  );
  yield takeLatest(
    constants.PATIENT.DISASSOCIATEHCP_REQUEST,
    PatientAction.disassociateHcp
  );
  yield takeLatest(
    constants.PATIENT.ASSOCIATEHCP_REQUEST,
    PatientAction.associateHcp
  );
  yield takeLatest(
    constants.PATIENT.RELATIONSHIPS_REQUEST,
    PatientAction.fetchRelationships
  );
  yield takeLatest(
    constants.PATIENT.ADDCAREGIVER_REQUEST,
    PatientAction.addCaregiver
  );
  yield takeLatest(
    constants.PATIENT.DISASSOCIATECAREGIVER_REQUEST,
    PatientAction.disassociateCaregiver
  );
  yield takeLatest(
    constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_REQUEST,
    associatedPatients
  );
  yield takeEvery(
    constants.PROFILE.PROFILE_REQUEST,
    Profile.profileRequestAction
  );
  yield takeEvery(constants.PROFILE.PROFILE_RESET, Profile.profileResetAction);
  yield takeLatest(
    constants.PROFILE.PROFILE_UPDATE_REQUEST,
    Profile.profileUpdateAction
  );
  yield takeLatest(
    constants.PROFILE.CHANGE_SECURITY_QUESTION,
    Profile.changeSecurityQuestion
  );
  yield takeEvery(constants.PROFILE.FETCH_TIMEZONES, Profile.fetchTimeZone);
  yield takeLatest(constants.PROFILE.TIMEZONE_UPDATE, Profile.updateTimeZone);
  yield takeLatest(constants.PROVIDER.PROVIDER_REQUEST, fetchProviders);
  yield takeLatest(
    constants.PROVIDER.PROVIDER_PROFILE_REQUEST,
    fetchProviderProfile
  );
  yield takeEvery(
    constants.TIMSSCRIPT.TIMSSCRIPT_REQUEST,
    TimsScriptAction.getTimsScript
  );
  yield takeEvery(
    constants.TIMSSCRIPT.TIMSSCRIPT_LOG_DETAILS,
    TimsScriptAction.getTimsLogDetails
  );
  yield takeLatest(
    constants.TIMSSCRIPT.TIMSSCRIPT_EXECUTE_JOB,
    TimsScriptAction.executeJob
  );
  yield takeLatest(constants.ZIP.CCITYSTATEBYZIP_REQUEST, ccityStateByZip);
  yield takeLatest(
    constants.SANDBOX.CHARGER_DEVICE_DATA,
    SandBoxAction.getChargerDeviceData
  );
  yield takeLatest(constants.CLINICS.CLINICS_ALL_REQUEST, getAllClinics);
  yield takeLatest(
    constants.PROVIDER.ASSOCIATE_CLINIC_REQUEST,
    associateClinicHcp
  );
  yield takeLatest(
    constants.PROVIDER.DISASSOCIATE_CLINIC_REQUEST,
    disAssociateClinicHcp
  );
  yield takeLatest(
    constants.PATIENT.STATEBYCOUNTRY_REQUEST,
    PatientAction.fetchStatesByCountry
  );
  yield takeLatest(
    constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
    PatientAction.fetchCityByStateCountry
  );
  yield takeLatest(constants.PROVIDER.NEW_PROVIDER_REQUEST, newProvider);
  yield takeLatest(constants.PROVIDER.UPDATE_PROVIDER_REQUEST, updateProvider);
  yield takeLatest(constants.CLINICS.UPDATE_CLINIC_REQUEST, updateClinic);
  yield takeLatest(
    constants.CLINICS.ASSOCIATE_PROVIDER_REQUEST,
    associateProvider
  );
  yield takeLatest(
    constants.CLINICS.DISASSOCIATE_PROVIDER_REQUEST,
    disAssociateProvider
  );

  yield takeEvery(
    constants.SANDBOX.OPTIMUS_DEVICE_DATA,
    SandBoxAction.getOptimusDeviceData
  );

  yield takeEvery(
    constants.SANDBOX.TITAN_DEVICE_DATA,
    SandBoxAction.getTitanDeviceData
  );

  yield takeEvery(
    constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT,
    AnnouncementAction.getAnnouncement
  );
  yield takeEvery(
    constants.ANNOUNCEMENT.ANNOUNCEMENT_PATIENT_TYPE,
    AnnouncementAction.getAnnouncementPatientType
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.ANNOUNCEMENT_UPLOAD_PDF,
    AnnouncementAction.uploadAnnouncementPDF
  );
  yield takeEvery(
    constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_BY_ID,
    AnnouncementAction.fetchAnnouncementById
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT,
    AnnouncementAction.updateAnnouncement
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.CREATE_ANNOUNCEMENT,
    AnnouncementAction.createAnnouncement
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.DELETE_ANNOUNCEMENT,
    AnnouncementAction.deleteAnnouncement
  );
  yield takeEvery(
    constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH,
    AnnouncementAction.getPatientAnnouncement
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.VIEW_ANNOUNCEMENT_PDF,
    AnnouncementAction.viewAnnouncementPDF
  );
  yield takeLatest(
    constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT_READ_STATUS,
    AnnouncementAction.updateAnnouncementReadStatus
  );
  yield takeLatest(constants.CLINICS.CLINIC_ADMINS_REQUEST, getClinicAllAdmins);
  yield takeLatest(
    constants.CLINICS.ASSOCIATECLINICADMIN_REQUEST,
    associatedClinicAdmin
  );
  yield takeLatest(
    constants.CLINICS.DISASSOCIATECLINICADMIN_REQUEST,
    disassociateClinicAdmin
  );
  yield takeLatest(
    constants.NOTIFICATION_SETTING.FETCH_NOTIFICATION,
    fetchNotificationData
  );
  yield takeLatest(
    constants.NOTIFICATION_SETTING.NOTIFICATION_UPDATE_REQUEST,
    updateNotificationSettings
  );
  yield takeEvery(constants.PROFILE.FETCH_CLINIC, Profile.getClinicAction);
  yield takeLatest(
    constants.PATIENT.FETCH_ALL_PATIENT_OVERVIEW,
    PatientAction.fetchAllOverviewData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_ENHANCED_PATIENTS_OVERVIEW,
    PatientAction.fetchEnhancedPatientsOverviewData
  );
  yield takeLatest(
    constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA,
    PatientAction.fetchEnhancedPatientsSpiroData
  );
  yield takeLatest(
    constants.PATIENT.STOP_PDF_DOWNLOAD,
    PatientAction.setDownloadFalse
  );
  yield takeEvery(
    constants.PATIENT.SET_TYPE_OF_PDF,
    PatientAction.setTypeOfPDF
  );
  yield takeLatest(
    constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_REQUEST,
    getAssociatedPatientCards
  );
  yield takeLatest(
    constants.PATIENT.PATIENT_FLAG,
    PatientAction.flagPatientAction
  );
  yield takeLatest(
    constants.PATIENT.PATIENT_OVERVIEW_FLAG,
    PatientAction.flagPatientOverviewAction
  );
  yield takeLatest(constants.CLINICS.CLINIC_FLAG, flagClinicAction);
  yield takeLatest(
    constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_REQUEST,
    getClinicAccountExecutives
  );
  yield takeEvery(
    constants.CLINICS.DIASSOCIATE_ACCOUNT_EXECUTIVE_REQUEST,
    diassociateAccountExecutive
  );
  yield takeEvery(
    constants.CLINICS.ASSOCIATE_ACCOUNT_EXECUTIVE_REQUEST,
    associateAccountExecutive
  );
  yield takeLatest(
    constants.DEVICE.JUSTIFICATION_RESET,
    ProtocolAction.getJustificationReset
  );
  yield takeLatest(
    constants.DEVICE.UPLOAD_RTP_THERAPY_TITAN_REQUEST,
    ProtocolAction.uploadRTPTherapy
  );
  yield takeLatest(constants.CHECK_PASSWORD, EditProtocolDevice.checkPassword);
}
