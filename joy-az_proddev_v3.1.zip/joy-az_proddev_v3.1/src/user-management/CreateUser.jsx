import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import { Header, SideBar } from 'components/Navigation';
import { connect } from 'react-redux';
import constants from 'constants.js';
import { isValidMobile } from 'utils/helper';
import strings from 'localization/strings';
import NumberFormat from 'react-number-format';
import { FootNote } from 'components/FootNote';
import CustomSelect from 'components/CustomSelect';
import ConfirmationDialog from 'components/ConfirmationDialog';
import API from 'api/api_config';
import { uid } from 'react-uid';
import { isUndefined, last, isEmpty, every } from 'lodash';
import update from 'immutability-helper';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import {
  getBreadCrumb,
  removeBreadCrumb,
  addBreadCrumb
} from '../utils/utltity';
import { getUserData, validateEmail } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';

class CreateUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      firstName: '',
      lastName: '',
      middleName: null,
      email: '',
      hillromId: '',
      mobileNumber: null,
      role: '',
      error: null,
      chooseTerritory: false,
      resetSelect: false,
      isDirty: false,
      territoryList: [{ name: '', id: '' }],
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: dialog.title === strings.addNewTerritory ? true : false,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleTerritoryChange = this.handleTerritoryChange.bind(this);
    this.handleTerritoryRemove = this.handleTerritoryRemove.bind(this);
    this.handleTerritoryAdd = this.handleTerritoryAdd.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({ type: constants.USER.CLEAR_ADD_USER_STATUS });
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
  }

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  handleChange = event => {
    const { error } = this.state;
    if (error !== null) {
      this.setState({ error: null });
    }
    this.setState({ [event.target.name]: event.target.value });
    if (
      event.target.name === 'role' &&
      event.target.value === constants.ROLES.ASSOCIATE_EXECUTIVE
    ) {
      this.setState({ chooseTerritory: true });
      this.setState({ territoryList: [{ name: '', id: '' }] });
    } else if (
      event.target.name === 'role' &&
      event.target.value !== constants.ROLES.ASSOCIATE_EXECUTIVE
    ) {
      this.setState({ chooseTerritory: false });
    }
    this.setState({ isDirty: true });
  };

  handleTerritoryRemove = idx => {
    const { territoryList } = this.state;
    this.setState({
      territoryList: update(territoryList, { $splice: [[idx, 1]] })
    });
  };

  handleTerritoryAdd = () => {
    const { territoryList } = this.state;
    const TerritoryInit = {
      id: '',
      name: ''
    };
    if (!every(last(territoryList), isEmpty)) {
      this.setState({
        territoryList: [...territoryList, TerritoryInit]
      });
    }
  };

  creatUserProfile = () => {
    const payload = Object.assign({}, this.state);
    const { dialog, territoryList } = this.state;
    const { dispatch, history } = this.props;
    if (!isUndefined(territoryList)) {
      payload.territoryList = territoryList.filter(e => e.id !== "").map(element => {
        return { id: element.id };
      });
    }
    [
      'error',
      'clinicAdmin',
      'dialog',
      'chooseTerritory',
      'resetSelect',
      'isMobile',
      'isDirty'
    ].forEach(e => delete payload[e]);
    let allData = { payload, history, path: urls.USER.ALL };
    dispatch({
      type: constants.USER.USER_CREATE_REQUEST,
      allData
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  handleSubmit = () => {
    const {
      firstName,
      lastName,
      dialog,
      email,
      hillromId,
      role,
      mobileNumber
    } = this.state;
    if (hillromId === '') {
      this.setState({
        error: strings.enterHRID
      });
    } else if (role === '') {
      this.setState({ error: strings.pleaseSelectRole });
    } else if (firstName === '') {
      this.setState({
        error: strings.enterFirstName
      });
    } else if (lastName === '') {
      this.setState({ error: strings.enterLastName });
    } else if (!validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    } else if (!isValidMobile(mobileNumber, 10, true)) {
      this.setState({
        error: strings.enterValidMobileNumber
      });
    } else {
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.createUserConfirm.replace(
            '{VALUE}',
            `${firstName} ${lastName}`
          ),
          title: 'Create New User',
          button: 'Create User',
          confirmFunction: this.creatUserProfile,
          show: true
        })
      });
    }
  };

  territoryChange = () => {
    const { territoryList, dialog } = this.state;
    const { opt, idx } = dialog;
    this.setState({
      territoryList: update(territoryList, {
        [idx]: {
          $set: {
            name: opt ? opt.name : '',
            id: opt ? opt.id : ''
          }
        }
      })
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: true
    });
  };

  async handleTerritoryChange(opt, idx) {
    const { dialog } = this.state;
    if (opt) {
      await this.setState({
        dialog: Object.assign(dialog, {
          body: `Associate ${opt.name} territory with the User?`,
          title: strings.addNewTerritory,
          button: strings.linkTerritory,
          confirmFunction: this.territoryChange,
          opt,
          idx,
          show: true
        })
      });
    } else {
      await this.setState({
        dialog: Object.assign(dialog, {
          opt,
          idx
        })
      });
      this.territoryChange();
    }
  }

  render() {
    const {
      firstName,
      lastName,
      middleName,
      email,
      hillromId,
      mobileNumber,
      role,
      territoryList,
      error,
      chooseTerritory,
      dialog,
      isMobile,
      resetSelect
    } = this.state;
    const { location, breadcrumbs, history } = this.props;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [{ href: urls.USER.ADD, text: strings.addNewUser }]
    };

    const { actualRole } = getUserData();
    const createUserInformation = accessMatrix.CREATE_USER[actualRole];

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.USER.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <h1 className="d-inline-block text-capitalize">
                {strings.addNewUser}
              </h1>
              <ButtonComponent
                id="save-user-top"
                buttonClass="float-right"
                buttonAction={this.handleSubmit}
                icon="update-icon"
                buttonText={strings.save}
                hidden={!createUserInformation.write}
              />
              <div>
                <Form>
                  <h6>{strings.userIdentifiers}</h6>
                  <p className="text-danger">{error}</p>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.hillromID} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        name="hillromId"
                        className="text-capitalize"
                        placeholder={strings.hillromID}
                        value={hillromId}
                        onChange={this.handleChange}
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.selectRole} <span className="asterisk-color">*</span></Form.Label>
                      <Form.Control
                        as="select"
                        name="role"
                        value={role}
                        onChange={this.handleChange}
                      >
                        <option value="">{strings.selectRole}</option>
                        <option value={constants.ROLES.SUPER_ADMIN}>
                          {strings.superAdmin}
                        </option>
                        <option value={constants.ROLES.CUSTOMER_SERVICES}>
                          {strings.customerService}
                        </option>
                        <option value={constants.ROLES.ASSOCIATE_EXECUTIVE}>
                          {strings.accountExecutive}
                        </option>
                      </Form.Control>
                    </Form.Group>
                  </Form.Row>
                  <div
                    className={
                      chooseTerritory ? 'choose-clinic-accexec' : 'd-none'
                    }
                    id="yesAssociateExec"
                  >
                    {chooseTerritory ? (
                      <Form.Row id="choose-clinic">
                        {territoryList.map((territory, idx) => (
                          <Form.Row>
                            <Form.Group as={Col} md={8}>
                              <Form.Label className="text-uppercase">
                                {strings.territoryName}
                              </Form.Label>
                              <CustomSelect
                                key={uid(territory, idx)}
                                value={territory}
                                clearCurrentVal={
                                  idx === territoryList.length - 1
                                    ? resetSelect
                                    : false
                                }
                                afterClearCurrentValFn={() => {
                                  if (idx === territoryList.length - 1) {
                                    this.setState({ resetSelect: false });
                                  }
                                }}
                                filterOptions={{
                                  key: 'id',
                                  values: territoryList
                                }}
                                len={territoryList.length}
                                minSearchChars={
                                  constants.TYPEAHEAD_SEARCH_TEXT_LEN
                                }
                                idx={idx}
                                optionUrl={API.TERRITORIESSEARCH}
                                searchParam="searchParam"
                                displayAttr={['name', 'id']}
                                onChange={evt =>
                                  this.handleTerritoryChange(evt, idx)
                                }
                                onRemove={evt =>
                                  this.handleTerritoryRemove(idx)
                                }
                              />
                            </Form.Group>
                            <Form.Group as={Col} md={2} className="">
                            </Form.Group>
                            {idx === territoryList.length - 1 && (
                              <Form.Group as={Col} md={2} className="">
                                <ButtonComponent
                                  id="add-clinic"
                                  buttonClass="float-right"
                                  buttonAction={this.handleTerritoryAdd}
                                  icon="add-icon"
                                  buttonText={strings.addTerritory}
                                />
                              </Form.Group>
                            )}
                          </Form.Row>
                        ))}
                      </Form.Row>
                    ) : (
                        ''
                      )}
                  </div>
                  <hr />
                  <h6 className="text-capitalize">{strings.personalDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.firstName}
                        name="firstName"
                        value={firstName}
                        onChange={this.handleChange}
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.middleName}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.middleName}
                        name="middleName"
                        value={middleName || ''}
                        onChange={this.handleChange}
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.lastName}
                        name="lastName"
                        value={lastName}
                        onChange={this.handleChange}
                        maxLength="50"
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="email"
                        placeholder={strings.email}
                        name="email"
                        value={email}
                        onChange={this.handleChange}
                        maxLength="100"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.primaryPhone}</Form.Label>

                      <NumberFormat
                        className="form-control"
                        placeholder="(___)-___-____"
                        format="(###)-###-####"
                        mask="_"
                        value={mobileNumber || ''}
                        onChange={this.handleChange}
                        name="mobileNumber"
                      />
                    </Form.Group>
                  </Form.Row>

                  <hr />
                  <ButtonComponent
                    id="save-user-bottom"
                    buttonClass="float-right"
                    buttonAction={this.handleSubmit}
                    icon="update-icon"
                    buttonText={strings.save}
                    hidden={!createUserInformation.write}
                  />
                </Form>
                {error && <p className="error text-danger">{error}</p>}
              </div>
              <ConfirmationDialog
                show={dialog.show}
                handleClose={dialog.handleClose}
                body={dialog.body}
                title={dialog.title}
                button={dialog.button}
                confirmFunction={dialog.confirmFunction}
              />
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { breadcrumbsReducer, userReducer } = state.app;
  return {
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    addUserStatus: userReducer.addUserStatus
  };
};

export default connect(
  mapStateToProps,
  null
)(CreateUser);
