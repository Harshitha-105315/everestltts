import React, { Component } from 'react';
import { connect } from 'react-redux';
import './user-management.scss';
import Search from 'components/Search';
import { Header, SideBar } from 'components/Navigation';
import TableDisplay from 'components/TableDisplay';
import strings from 'localization/strings';
import { getSearchString } from 'utils/helper.js';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import { getUserData } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';
import { reverse } from 'named-urls';
import { uid } from 'react-uid';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import debounce from 'lodash/debounce';
import { isEmpty } from 'lodash';
import ButtonComponent from 'components/ButtonComponent';
import moment from 'moment-timezone';
import { decode } from '../utils/helper';
import constants from '../constants';
import {
  updateUrl,
  addBreadCrumb,
  clearBreadCrumb,
  getUserRole
} from '../utils/utltity';
import { decryptemail } from '../Cryptocode';

class User extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchString: '',
      page: 1,
      perPage: 10,
      sortBy: 'firstName',
      asc: true,
      filter: {
        isActivated: 0,
        isDeleted: 'all',
        authority: 'all'
      },
      filterOn: false
    };
    this.handlePaginate = this.handlePaginate.bind(this);
    this.fetchUsers = this.fetchUsers.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.allToggle = this.allToggle.bind(this);
    this.inactiveToggle = this.inactiveToggle.bind(this);
    this.activateToggle = this.activateToggle.bind(this);
    this.pendingToggle = this.pendingToggle.bind(this);
    this.onChangefilterByRole = this.onChangefilterByRole.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.getSearchString = getSearchString.bind(this);
    this.updateUrl = updateUrl.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.clearBreadCrumb = clearBreadCrumb.bind(this);
    this.changeSearch = debounce(() => {
      this.dispatchSearch();
      this.updateUrl(this.exempt);
    }, constants.SEARCH_DEBOUNCE_MS);
    this.exempt = ['filterOn'];
  }

  async componentWillMount() {
    const {
      location: { search }
    } = this.props;
    if (search !== '') {
      const newState = decode(
        search
          .substring(1)
          .replace('sort_by', 'sortBy')
          .replace('per_page', 'perPage')
      );
      newState.filter = decode(
        newState.filter
          .substring(0, newState.filter.length - 1)
          .replace(/:/g, '=')
          .replace(/;/g, '&')
      );
      await this.setState(newState);
    }
    this.filterCheck();
    this.dispatchSearch();
    this.clearBreadCrumb();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB,
      toggleValue: false
    });
  }

  async onChangefilterByRole(event) {
    const { filter } = this.state;
    const { value } = event.target;
    await this.setState({ page: 1 });
    await this.setState({
      filter: Object.assign({}, filter, { authority: value })
    });
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  dispatchSearch = () => {
    const { dispatch } = this.props;
    const payload = Object.assign({}, this.state);
    this.exempt.forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.USER.USER_SEARCH_REQUEST,
      payload
    });
  };

  getStatus = d => {
    if (d.deleted) {
      return (
        <div>
          <div className="red-inactive d-inline-block" />
          <span className="text-capitalize">{strings.inactive}</span>
          {d.deactivationReason ? (
            <div className="user-deactivation-reason text-uppercase">
              {d.deactivationReason}
            </div>
          ) : null}
        </div>
      );
    }
    if (d.activated) {
      return (
        <div>
          <div className="green-active d-inline-block" />
          <span className="text-capitalize">{strings.active}</span>
        </div>
      );
    }
    return (
      <div>
        <div className="d-inline-block grey-pending" />
        <span className="text-capitalize">{strings.pending}</span>
      </div>
    );
  };

  listUsers = () => {
    const { history, response } = this.props;
    if (!isEmpty(response)) {
      return response.map(d => (
        <tr
          key={uid(d)}
          className="listing cursor"
          onClick={() => {
            this.addBreadCrumb({ title: strings.manageUsers });
            history.push(reverse(urls.USER.PROFILE, { id: d.id }));
          }}
        >
          <td id="first-name-user">
            {d.firstName} {d.lastName}
            <p className="secondary-data d-sm-none">{d.hillromId}</p>
          </td>
          <td id="role-user" className="d-none d-sm-table-cell text-capitalize">
            {getUserRole(d.role ? decryptemail(d.role) : '').LABEL}
          </td>
          <td id="hillrom-id-user" className="d-none d-sm-table-cell">
            {d.hillromId}
          </td>
          <td id="email-user" className="d-none d-sm-table-cell">
            {d.email ? decryptemail(d.email) : d.email}
          </td>
          <td id="mobile-user" className="d-none d-sm-table-cell">
            {d.lastLoggedInAt !== 0
              ? moment(d.lastLoggedInAt).format('MMM DD, YYYY hh:mm A')
              : ''}
          </td>
          <td id="status-user">{this.getStatus(d)}</td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="6" className="text-center text-capitalize">
          {strings.noUserDataAvaliable}
        </td>
      </tr>
    );
  };

  async resetFilter(onlyReset) {
    await this.setState({
      //Search Changes
      // searchString: '',
      page: 1,
      perPage: 10,
      sortBy: 'firstName',
      asc: true,
      filter: {
        isActivated: 0,
        isDeleted: 'all',
        authority: 'all'
      },
      filterOn: false
    });
    if (!onlyReset) {
      this.updateUrl(this.exempt);
      this.dispatchSearch();
    }
  }

  async filterCheck() {
    const {
      filter: { authority, isActivated, isDeleted }
    } = this.state;
    if (
      authority === constants.FILTER_VALUES.ALL &&
      (isActivated === 0 && isDeleted === 'all')
    ) {
      await this.setState({ filterOn: false });
    } else {
      await this.setState({ filterOn: true });
    }
  }

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async fetchUsers(event) {
    const name = (event && event.target.value) || '';
    //Search changes
    // await this.resetFilter(true);
    await this.setState({ searchString: name });
    this.changeSearch();
  }

  async activateToggle() {
    const { filter } = this.state;
    await this.setState({ page: 1 });
    await this.setState({
      filter: Object.assign({}, filter, { isDeleted: 0, isActivated: 1 })
    });
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async allToggle() {
    const { filter } = this.state;
    await this.setState({ page: 1 });
    await this.setState({
      filter: Object.assign({}, filter, { isDeleted: 'all', isActivated: 0 })
    });
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async inactiveToggle() {
    const { filter } = this.state;
    await this.setState({ page: 1 });
    await this.setState({
      filter: Object.assign({}, filter, { isDeleted: 1, isActivated: 1 })
    });
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async pendingToggle() {
    const {
      filter: { authority }
    } = this.state;
    await this.setState({ page: 1 });
    await this.setState({
      filter: { isActivated: 0, authority }
    });
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  async handleSorting(event) {
    const { asc, sortBy } = this.state;
    const { name } = event.target;
    await this.setState({ page: 1 });
    if (sortBy !== name) {
      await this.setState({ sortBy: name, asc: true });
    } else {
      await this.setState({ asc: !asc });
    }
    this.updateUrl(this.exempt);
    this.dispatchSearch();
  }

  render() {
    const {
      searchString,
      page,
      perPage,
      filter: { isActivated, isDeleted, authority },
      filterOn
    } = this.state;
    const { history, totalUsers, showSearch } = this.props;
    const { actualRole } = getUserData();
    const createUserInformation = accessMatrix.CREATE_USER[actualRole];
    return (
      <div>
        <Header
          searchExitHandle={async () => {
            await this.setState({ searchString: '' });
            this.updateUrl(this.exempt);
            this.dispatchSearch();
          }}
        />
        <MainWrapper>
          <SideBar
            filters={{
              Status: [
                {
                  title: strings.all,
                  name: constants.FILTER_NAME.ACTIVE_CHECK,
                  value: constants.FILTER_VALUES.ALL,
                  onChangeFunction: this.allToggle,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    isActivated === 0 && isDeleted === 'all' ? true : null
                },
                {
                  title: strings.active,
                  name: constants.FILTER_NAME.ACTIVE_CHECK,
                  value: constants.FILTER_VALUES.ACTIVE,
                  onChangeFunction: this.activateToggle,
                  type: constants.FILTER_TYPE.RADIO,
                  checked: isActivated === 1 && isDeleted === 0 ? true : null
                },
                {
                  title: strings.inactive,
                  name: constants.FILTER_NAME.ACTIVE_CHECK,
                  value: constants.FILTER_VALUES.INACTIVE,
                  onChangeFunction: this.inactiveToggle,
                  type: constants.FILTER_TYPE.RADIO,
                  checked: isActivated === 1 && isDeleted === 1 ? true : null
                },
                {
                  title: strings.pending,
                  name: constants.FILTER_NAME.ACTIVE_CHECK,
                  value: constants.FILTER_VALUES.PENDING,
                  onChangeFunction: this.pendingToggle,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    isActivated === 0 && isDeleted === undefined ? true : null
                }
              ],
              Roles: [
                {
                  title: strings.all,
                  name: constants.FILTER_NAME.AUTHORITY,
                  value: constants.FILTER_VALUES.ALL,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.FILTER_VALUES.ALL ? true : null
                },
                {
                  title: strings.superAdmin,
                  value: constants.ROLES.SUPER_ADMIN,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.ROLES.SUPER_ADMIN ? true : null
                },
                {
                  title: strings.customerService,
                  value: constants.ROLES.CUSTOMER_SERVICES,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.ROLES.CUSTOMER_SERVICES
                      ? true
                      : null
                },
                {
                  title: strings.patientUser,
                  value: constants.ROLES.PATIENT,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked: authority === constants.ROLES.PATIENT ? true : null
                },
                {
                  title: strings.provider,
                  value: constants.ROLES.HCP,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked: authority === constants.ROLES.HCP ? true : null
                },
                {
                  title: strings.clinicAdmin,
                  value: constants.ROLES.CLINIC_ADMIN,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.ROLES.CLINIC_ADMIN ? true : null
                },
                {
                  title: strings.accountExecutive,
                  value: constants.ROLES.ASSOCIATE_EXECUTIVE,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.ROLES.ASSOCIATE_EXECUTIVE
                      ? true
                      : null
                },
                {
                  title: strings.caregiver,
                  value: constants.ROLES.CARE_GIVER,
                  name: constants.FILTER_NAME.AUTHORITY,
                  onChangeFunction: this.onChangefilterByRole,
                  type: constants.FILTER_TYPE.RADIO,
                  checked:
                    authority === constants.ROLES.CARE_GIVER ? true : null
                }
              ]
            }}
            resetFilter={this.resetFilter}
            showSearch={showSearch}
            filterOn={filterOn}
          //Search Changes
          // hidden={searchString === '' ? false : true} 
          />
          <MainContent
            //Search changes
            // {...(searchString !== ''
            //   ? { styleClass: 'col-md-10 table-search-desktop' }
            //   : {})}
            //added below line for search changes
            styleClass='col-md-10 table-search-desktop' >
            <div>
              <div className="table-header d-flex flex-wrap align-items-center">
                <h1
                  className={`${
                    showSearch === true
                      ? 'd-none'
                      : 'text-capitalize marginv-auto'
                    }`}
                >
                  {searchString ? strings.searchUsers : strings.manageUsers}
                </h1>
                <Search
                  searchString={searchString}
                  fetchOnChange={this.fetchUsers}
                  modifierClass="d-sm-inline"
                  showSearch={showSearch}
                  placeholder={strings.userSearchPlaceholder}
                />
                <div className="breaker" />
                <p
                  className={
                    totalUsers === 0 || searchString !== '' || showSearch
                      ? 'd-none'
                      : 'mobile-table-count d-sm-none text-capitalize'
                  }
                >
                  {totalUsers} {strings.users}
                </p>
                <ButtonComponent
                  id="new-user"
                  buttonClass={`${
                    showSearch === true ? 'd-none' : 'overview-button ml-auto'
                    }`}
                  buttonAction={() => {
                    this.addBreadCrumb({ title: strings.manageUsers });
                    this.addBreadCrumb({ title: strings.addNewUser });
                    history.push(urls.USER.ADD);
                  }}
                  hidden={
                    !createUserInformation.write || showSearch || searchString
                  }
                  icon="add-entity-icon"
                  buttonText={strings.newUser}
                />
                <span
                  className={`${
                    searchString !== ''
                      ? 'table-search-exit cross-icon d-md-inline-block ml-auto'
                      : 'd-none'
                    }`}
                  onClick={async () => {
                    this.fetchUsers();
                  }}
                  onKeyPress={async () => {
                    this.fetchUsers();
                  }}
                  tabIndex={0}
                  role="button"
                />
              </div>
              <div>
                <h6
                  className={`${
                    searchString === ''
                      ? 'd-none'
                      : 'text-capitalize show-search'
                    } `}
                >{`${strings.searchResults} (${totalUsers || 0})`}</h6>
                <h6
                  className={
                    searchString === '' && showSearch
                      ? 'd-sm-none table-description'
                      : 'd-none'
                  }
                >
                  {totalUsers || 0} {strings.users}
                </h6>
                <TableDisplay
                  heading={[
                    {
                      text: strings.username,
                      sortable: true,
                      name: 'firstName',
                      value: 'firstName'
                    },
                    {
                      text: strings.role,
                      sortable: false,
                      name: 'name',
                      value: 'role',
                      mobile: false
                    },
                    {
                      text: strings.hillromID,
                      sortable: false,
                      name: 'hillromId',
                      value: 'hillromId',
                      mobile: false
                    },
                    {
                      text: strings.email,
                      sortable: false,
                      name: 'email',
                      value: 'email',
                      mobile: false
                    },
                    {
                      text: strings.lastLogin,
                      sortable: true,
                      name: 'lastLoggedInAt',
                      value: 'lastLoggedInAt',
                      mobile: false
                    },
                    {
                      text: strings.status,
                      sortable: false,
                      name: 'isDeleted',
                      value: 'status'
                    }
                  ]}
                  totalUsers={totalUsers}
                  listing={this.listUsers()}
                  handleSorting={this.handleSorting}
                  getSearchString={this.getSearchString}
                  searchDisplay
                  pagination
                  handlePaginate={this.handlePaginate}
                  perPage={perPage}
                  page={page}
                  totalDisplayLabel={strings.users}
                  searchString={searchString}
                  noResultFound={strings.noUserDataAvaliable}
                />
              </div>
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}
const mapStateToProps = state => {
  const { userReducer, filterReducer } = state.app;
  return {
    response: userReducer.response,
    totalUsers: userReducer.totalUsers || null,
    showSearch: filterReducer.showSearch
  };
};
export default connect(
  mapStateToProps,
  null
)(User);
