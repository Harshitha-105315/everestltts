import API from 'api/api_config';
import { authRequest } from 'utils/axios_utils';
import constants from 'constants.js';

export function fetchUserProfilesService(params) {
  return authRequest({
    url: API.SEARCHUSER,
    params,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}
export function createUserProfileService(payload) {
  return authRequest({
    url: API.CREATEUSER,
    method: 'POST',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function activateUserProfileService(payload) {
  const { id } = payload;
  return authRequest({
    url: API.ACTIVATEUSER.replace('{USERID}', id),
    method: 'PUT',
    [constants.RETURNRESPONSE]: true
  });
}

export function deactivateUserProfileService(payload) {
  const { id, data } = payload;
  return authRequest({
    url: API.DEACTIVATEUSER.replace('{USERID}', id),
    method: 'DELETE',
    data,
    [constants.RETURNRESPONSE]: true
  });
}

export function resendActivationLinkUserProfileService(payload) {
  const { id } = payload;
  return authRequest({
    url: API.RESENDACTIVATIONLINK.replace('{USERID}', id),
    method: 'PUT',
    [constants.RETURNRESPONSE]: true
  });
}

export function resetPasswordUserProfileService(payload) {
  const { id } = payload;
  return authRequest({
    url: API.RESETPASSWORDUSER.replace('{USERID}', id),
    method: 'PUT',
    [constants.RETURNRESPONSE]: true
  });
}

export function getReasonCodeActionService() {
  return authRequest({
    url: API.REASONCODELIST,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

export function getUserInfoService(id) {
  return authRequest({
    url: API.USERBYID.replace('{USERID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

export function updateUserInfoService(payload, id) {
  const { authorities } = payload;
  if (authorities) {
    const role = (authorities && authorities.length > 0 && authorities[0].name) || '';
    payload = Object.assign({ role }, payload);
    delete payload.authorities;
  }
  return authRequest({
    url: API.USERBYID.replace('{USERID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function cityStateByZipService(zip) {
  return authRequest({
    url: API.CITYSTATEBYZIP.replace('{ZIPCODE}', zip),
    method: 'GET'
  });
}
