import constants from 'constants.js';
import strings from 'localization/strings';
import { setStateByKey } from 'utils/helper.js';

const intialState = {
  response: [],
  totalUsers: 0,
  message: '',
  userInfo: {},
  cityStateByZip: undefined,
  ccityStateByZip: {},
  addUserStatus: 0,
  reasonCodes: []
};

function userReducer(state = intialState, action) {
  const tmpState = Object.assign({}, state);
  switch (action.type) {
    case constants.USER.USER_SEARCH_SUCCESS:
      tmpState.response = action.response;
      tmpState.totalUsers = Number(action.totalUsers);
      return tmpState;
    case constants.USER.USER_SEARCH_FAILURE:
      tmpState.response = [];
      tmpState.totalUsers = 0;
      return tmpState;
    case constants.USER.USER_CREATE_SUCCESS:
      tmpState.message = 'SUCCESSFULLY CREATED';
      tmpState.addUserStatus = 1;
      return tmpState;
    case constants.USER.USER_CREATE_FAILURE:
      tmpState.message = action.response;
      tmpState.addUserStatus = 0;
      return tmpState;
    case constants.USER.USER_SUCCESS:
      tmpState.userInfo = setStateByKey(
        tmpState.userInfo,
        action.key,
        action.response || {}
      );
      return tmpState;
    case constants.USER.UPDATE_USER_INFO:
      tmpState.userInfo = {
        ...tmpState.userInfo,
        [action.key]: {
          ...tmpState.userInfo[action.key],
          ...action.response
        }
      };
      return tmpState;
    case constants.USER.USER_FAILURE:
      tmpState.userInfo = setStateByKey(tmpState.userInfo, action.key, {});
      return tmpState;
    case constants.ZIP.CITYSTATEBYZIP_SUCCESS:
      tmpState.cityStateByZip = action.response;
      return tmpState;
    case constants.ZIP.CITYSTATEBYZIP_FAILURE:
      tmpState.cityStateByZip = {};
      return tmpState;
    case constants.ZIP.CCITYSTATEBYZIP_SUCCESS:
      tmpState.ccityStateByZip = action.response;
      return tmpState;
    case constants.ZIP.CCITYSTATEBYZIP_FAILURE:
      tmpState.ccityStateByZip = {};
      return tmpState;
    case constants.ZIP.CLEAR:
      tmpState.cityStateByZip = {};
      tmpState.ccityStateByZip = {};
      return tmpState;
    case constants.USER.CLEAR_ADD_USER_STATUS:
      tmpState.addUserStatus = 0;
      return tmpState;
    case constants.USER.USER_UPDATE_SUCCESS:
      tmpState.updateUserStatus = strings.success;
      return tmpState;
    case constants.USER.CLEAR_USER_PROFILE:
      tmpState.userInfo = setStateByKey(tmpState.userInfo, action.key, {});
      return tmpState;
    case constants.USER.USER_UPDATE_FAILURE:
      tmpState.updateUserStatus = strings.failure;
      return tmpState;
    case constants.USER.UPDATE_STATUS:
      tmpState.updateUserStatus = false;
      return tmpState;
    case constants.USER.REASON_CODE_SUCCESS:
      tmpState.reasonCodes = action.response.typeCode;
      return tmpState;
    case constants.USER.REASON_CODE_FAILURE:
      tmpState.reasonCodes = [];
      return tmpState;
    default:
      return state;
  }
}
export default userReducer;
