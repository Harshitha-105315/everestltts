import React, { Component, Fragment } from 'react';
import { Header, SideBar } from 'components/Navigation';
import { connect } from 'react-redux';
import constants from 'constants.js';
import { Form, Col } from 'react-bootstrap';
import strings from 'localization/strings';
import DatePicker from 'react-datepicker';
import moment from 'moment-timezone';
import NumberFormat from 'react-number-format';
import { FootNote } from 'components/FootNote';
import { isValidMobile } from 'utils/helper';
import ConfirmationDialog from 'components/ConfirmationDialog';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import urls from 'urls.js';
import { getUserData, validateEmail } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';
import { reverse } from 'named-urls';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import LinkButton from '../components/LinkButton';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { isUndefined, last, isEmpty, every } from 'lodash';
import API from 'api/api_config';
import { uid } from 'react-uid';
import CustomSelect from 'components/CustomSelect';
import update from 'immutability-helper';
import {
  handleZipChange,
  languagesDropdown,
  getBreadCrumb,
  addBreadCrumb,
  removeBreadCrumb,
  getUserRole
} from '../utils/utltity';
import DeactivateConfirmDialog from './DeactivateConfirmDialog';
import { decryptemail } from '../Cryptocode';

class UserProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: '',
      hillromId: '',
      firstName: '',
      lastName: '',
      middleName: '',
      dob: new Date(),
      langKey: '',
      address: '',
      city: '',
      state: '',
      zipcode: '',
      primaryPhone: '',
      mobilePhone: '',
      email: '',
      reasonCode: '',
      otherReasonCode: '',
      authorities: [],
      territoryList: [{ name: '', id: '' }],
      resetSelect: false,
      error: null,
      deleted: null,
      activated: null,
      isMobile: false,
      mobileFlag: false,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: dialog.title === strings.addNewTerritory ? true : false,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      },
      deactivateDialog: {
        show: false,
        handleClose: () => {
          this.setState(prevState => {
            return {
              deactivateDialog: { ...prevState.deactivateDialog, show: false },
              reasonCode: '',
              otherReasonCode: '',
              isDirty: false
            };
          });
        }
      }
    };
    this.handleZipChange = handleZipChange.bind(this);
    this.languagesDropdown = languagesDropdown.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.handleActivateAccount = this.handleActivateAccount.bind(this);
    this.activateAccount = this.activateAccount.bind(this);
    this.handleDeactivateAccount = this.handleDeactivateAccount.bind(this);
    this.deactivateAccount = this.deactivateAccount.bind(this);
    this.handleResetPassword = this.handleResetPassword.bind(this);
    this.resetPassword = this.resetPassword.bind(this);
    this.handleResendActivationLink = this.handleResendActivationLink.bind(
      this
    );
    this.resendActivationLink = this.resendActivationLink.bind(this);
    this.handleTerritoryChange = this.handleTerritoryChange.bind(this);
    this.enterFunction = this.enterFunction.bind(this);
  }

  enterFunction(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
    }
  }

  componentWillMount() {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    dispatch({ type: constants.USER.USER_REQUEST, id });
    dispatch({ type: constants.LANGUAGES.LANGUAGES_REQUEST });
    dispatch({ type: constants.USER.REASON_CODE_REQUEST });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.userDetails });
    document.addEventListener("keydown", this.enterFunction, false);
  }

  componentWillReceiveProps(newProps) {
    const { userInfo } = this.props;
    if (isEmpty(userInfo) && !isEmpty(newProps.userInfo)) {
      this.setState({ ...newProps.userInfo });
      if (newProps.userInfo.territoryList === null) {
        this.setState({ territoryList: [{ name: '', id: '' }] });
      }
    }

    if (userInfo.deleted !== newProps.userInfo.deleted) {
      this.setState({
        deleted: newProps.userInfo.deleted,
        activated: newProps.userInfo.activated
      });
    }
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({ zipcode: cityStateByZip.zipCode });
        this.setState({ state: cityStateByZip.state });
        this.setState({ city: cityStateByZip.city });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
  }

  componentWillUnmount() {
    const { dispatch, match } = this.props;
    const { id } = match.params;
    dispatch({ type: constants.USER.CLEAR_USER_PROFILE, key: id });
    this.removeBreadCrumb();
    document.removeEventListener("keydown", this.enterFunction, false);
  }

  territoryChange = () => {
    const { territoryList, dialog } = this.state;
    const { opt, idx } = dialog;
    this.setState({
      territoryList: update(territoryList, {
        [idx]: {
          $set: {
            name: opt ? opt.name : '',
            id: opt ? opt.id : ''
          }
        }
      })
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: true
    });
  };

  async handleTerritoryChange(opt, idx) {
    const { dialog } = this.state;
    if (opt) {
      await this.setState({
        dialog: Object.assign(dialog, {
          body: `Associate ${opt.name} territory with the User?`,
          title: strings.addNewTerritory,
          button: strings.linkTerritory,
          confirmFunction: this.territoryChange,
          opt,
          idx,
          show: true
        })
      });
    } else {
      await this.setState({
        dialog: Object.assign(dialog, {
          opt,
          idx
        })
      });
      this.territoryChange();
    }
  }

  handleTerritoryRemove = idx => {
    const { territoryList } = this.state;
    this.setState({
      territoryList: update(territoryList, { $splice: [[idx, 1]] }),
      isDirty: true
    });
  };

  handleTerritoryAdd = () => {
    const { territoryList } = this.state;
    const TerritoryInit = {
      id: '',
      name: ''
    };
    if (!every(last(territoryList), isEmpty)) {
      this.setState({
        territoryList: [...territoryList, TerritoryInit]
      });
    }
  };

  getTerritories() {
    const { authorities, territoryList, resetSelect } = this.state;
    const role = authorities && authorities.length > 0 && getUserRole(authorities[0].name);
    if (role && role.ROLE === constants.ROLES.ASSOCIATE_EXECUTIVE) {
      return (
        <Form.Row id="choose-clinic" >
          {territoryList.map((territory, idx) => (
            <Form.Row>
              <Form.Group as={Col} md={8}>
                <Form.Label className="text-uppercase">
                  {strings.territoryName}
                </Form.Label>
                <CustomSelect
                  key={uid(territory, idx)}
                  value={territory}
                  clearCurrentVal={
                    idx === territoryList.length - 1
                      ? resetSelect
                      : false
                  }
                  afterClearCurrentValFn={() => {
                    if (idx === territoryList.length - 1) {
                      this.setState({ resetSelect: false });
                    }
                  }}
                  filterOptions={{
                    key: 'id',
                    values: territoryList
                  }}
                  len={territoryList.length}
                  minSearchChars={
                    constants.TYPEAHEAD_SEARCH_TEXT_LEN
                  }
                  idx={idx}
                  optionUrl={API.TERRITORIESSEARCH}
                  searchParam="searchParam"
                  displayAttr={['name', 'id']}
                  onChange={evt =>
                    this.handleTerritoryChange(evt, idx)
                  }
                  onRemove={evt =>
                    this.handleTerritoryRemove(idx)
                  }
                />
              </Form.Group>
              <Form.Group as={Col} md={2} className="">
              </Form.Group>
              {idx === territoryList.length - 1 && (
                <Form.Group as={Col} md={2} className="">
                  <ButtonComponent
                    id="add-clinic"
                    buttonClass="float-right"
                    buttonAction={this.handleTerritoryAdd}
                    icon="add-icon"
                    buttonText={strings.addTerritory}
                  />
                </Form.Group>
              )}
            </Form.Row>
          ))}
        </Form.Row>
      );
    }
  }

  getRoles() {
    const { authorities } = this.state;
    const role = authorities && authorities.length > 0 && getUserRole(authorities[0].name);
    if (role) {
      return (
        <Form.Control as="select" disabled>
          <option defaultValue={role.ROLE}>{role.LABEL}</option>
        </Form.Control>
      );
    }
  }

  handleDateChange = date => {
    if (date === null) {
      this.setState({ dob: null });
    } else {
      this.setState({ dob: moment(date).format('L') });
    }
  };

  updateUserProfile = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { territoryList } = this.state;
    const payload = Object.assign({}, this.state);
    if (!isUndefined(territoryList)) {
      payload.territoryList = territoryList.filter(e => e.id !== "").map(element => {
        return { id: element.id };
      });
    }
    const {
      dialog: { handleClose }
    } = this.state;
    ['error', 'dialog', 'reasonCode', 'isDirty'].forEach(
      e => delete payload[e]
    );
    dispatch({
      type: constants.USER.USER_UPDATE_REQUEST,
      payload,
      id
    });
    handleClose();
    this.setState({ isDirty: false });
  };

  handleUpdate = () => {
    const {
      firstName,
      lastName,
      email,
      zipcode,
      primaryPhone,
      mobilePhone,
      city
    } = this.state;

    this.setState({ error: '' });
    if (firstName === '') {
      this.setState({ error: strings.enterFirstName });
    } else if (lastName === '') {
      this.setState({ error: strings.enterLastName });
    } else if (!isValidMobile(primaryPhone, 10, true)) {
      this.setState({ error: strings.phoneNumberInvalid });
    } else if (!isValidMobile(mobilePhone, 10, true)) {
      this.setState({ error: strings.mobileNumberInvalid });
    } else if (!validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    }
    else if (this.isZipCodeRequired() && zipcode === '') {
      this.setState({ error: strings.pleaseEnterZipcode });
    }
    else if (this.isZipCodeRequired() && (city === '' || city === null)) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    }
    else {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: `Update ${firstName} ${lastName}'s User profile?`,
          title: 'Update  User',
          button: 'Update User',
          confirmFunction: this.updateUserProfile,
          show: true
        })
      });
    }
  };

  isZipCodeRequired = () => {
    const { authorities } = this.state;
    const role =
      authorities && authorities.length > 0 && getUserRole(authorities[0].name);
    if (role && (role.ROLE === constants.ROLES.ASSOCIATE_EXECUTIVE || role.ROLE === constants.ROLES.SUPER_ADMIN
      || role.ROLE === constants.ROLES.CUSTOMER_SERVICES)) {
      return false;
    }
    return true;
  }

  handleChange = event => {
    if (event.target.value === 'langKey') {
      const { languages } = this.props;
      this.setState({
        [event.target.name]: Object.keys(languages).find(
          key => languages[key] === event.target.value
        ),
        isDirty: true
      });
    } else {
      this.setState({ [event.target.name]: event.target.value, isDirty: true });
    }
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
        // this.setState({ mobileFlag: true });
      }
    }
  };

  handleActivateAccount = () => {
    this.setState(prevState => ({
      dialog: {
        ...prevState.dialog,
        body: `Activate User account?`,
        title: 'Activate account',
        button: 'Activate',
        confirmFunction: this.activateAccount,
        show: true
      }
    }));
  };

  handleDeactivateAccount = () => {
    this.setState(prevState => ({
      deactivateDialog: {
        ...prevState.deactivateDialog,
        confirmFunction: this.deactivateAccount,
        show: true
      }
    }));
  };

  handleResetPassword = () => {
    this.setState(prevState => ({
      dialog: {
        ...prevState.dialog,
        body: strings.resetPasswordWarning,
        title: strings.resetPassword,
        button: strings.resetPassword,
        confirmFunction: this.resetPassword,
        show: true
      }
    }));
  };

  handleResendActivationLink = () => {
    this.setState(prevState => ({
      dialog: {
        ...prevState.dialog,
        body: strings.resendActivationLinkWarning,
        title: strings.resendActivationLink,
        button: strings.resendActivationLink,
        confirmFunction: this.resendActivationLink,
        show: true
      }
    }));
  };

  activateAccount = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;

    dispatch({
      type: constants.USER.USER_ACTIVATE_REQUEST,
      payload: { id }
    });
    handleClose();
  };

  deactivateAccount = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      deactivateDialog: { handleClose },
      reasonCode,
      otherReasonCode
    } = this.state;

    dispatch({
      type: constants.USER.USER_DEACTIVATE_REQUEST,
      payload: { id, data: { reasonCode: otherReasonCode || reasonCode } }
    });
    handleClose();
  };

  resetPassword = () => {
    const {
      dialog: { handleClose }
    } = this.state;
    const { dispatch } = this.props;
    const { email } = this.state;
    dispatch({
      type: constants.USER.USER_RESET_PASSWORD_REQUEST,
      payload: { email }
    });
    handleClose();
  };

  resendActivationLink = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;

    dispatch({
      type: constants.USER.USER_RESEND_ACTIVATION_LINK_REQUEST,
      payload: { id }
    });
    handleClose();
  };

  render() {
    const {
      id,
      hillromId,
      firstName,
      middleName,
      lastName,
      dob,
      langKey,
      address,
      city,
      state,
      zipcode,
      primaryPhone,
      mobilePhone,
      activated,
      deleted,
      isMobile,
      email,
      error,
      dialog,
      deactivateDialog,
      reasonCode,
      otherReasonCode,
      authorities
    } = this.state;
    const {
      languages,
      breadcrumbs,
      location,
      history,
      match,
      reasonCodes
    } = this.props;
    const { params } = match;
    const { actualRole, userId } = getUserData();
    const userInformation = accessMatrix.USER_INFORMATION[actualRole];
    const modifyUserAccount = accessMatrix.MODIFY_USER_ACCOUNT[actualRole];
    const modifyUserAccountRole =
      accessMatrix.MODIFY_USER_ACCOUNT_ROLES[actualRole];
    const canModifyAccount =
      userId !== id &&
      authorities &&
      authorities.length > 0 &&
      modifyUserAccountRole[authorities[0].name];
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.USER.PROFILE, { id: params.id }),
          text: strings.userDetails
        }
      ]
    };
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.USER.ALL}
        />

        {userInformation.read ? (
          <MainWrapper>
            <SideBar sideBarData={sideBarData} />

            <MainContent>
              {!isMobile && this.getBreadCrumb(breadcrumbs)}
              <div>
                <h1 className="d-inline-block">
                  {!firstName && !lastName
                    ? ''
                    : (firstName ? `${firstName}` : '') +
                    (lastName ? `\t${lastName}` : '')}
                </h1>
                <ButtonComponent
                  id="update-user-top"
                  buttonClass="float-right"
                  buttonAction={this.handleUpdate}
                  hidden={!userInformation.write}
                  icon="report-icon"
                  buttonText={strings.update}
                />
                <h6>{strings.userIdentifiers}</h6>
                <p className="text-danger">{error}</p>
                <Form>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.userId}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.userId}
                        value={id}
                        onChange={this.handleChange}
                        name="id"
                        readOnly
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.hillromID}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.hillromID}
                        value={hillromId || ''}
                        onChange={this.handleChange}
                        name="hillromId"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                  <hr />
                  <h6 className="text-capitalize">{strings.personalDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.firstName}
                        value={firstName}
                        onChange={this.handleChange}
                        name="firstName"
                        maxLength="50"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.middleName}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.middleName}
                        value={middleName || ''}
                        onChange={this.handleChange}
                        name="middleName"
                        maxLength="50"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.lastName}
                        value={lastName || ''}
                        onChange={this.handleChange}
                        name="lastName"
                        maxLength="50"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.dateOfBirth}</Form.Label>
                      <DatePicker
                        selected={
                          dob === null
                            ? null
                            : new Date(Date.parse(moment(dob)))
                        }
                        name="dob"
                        onChange={this.handleDateChange}
                        className="form-control"
                        disabled={!userInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.language}</Form.Label>
                      <Form.Control
                        as="select"
                        value={languages[langKey]}
                        name="langKey"
                        onChange={this.handleChange}
                        disabled={!userInformation.write}
                      >
                        <option defaultValue value="">
                          Select a Language
                        </option>
                        {this.languagesDropdown()}
                      </Form.Control>
                    </Form.Group>
                  </Form.Row>
                  <hr />
                  <h6>{strings.contactDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.address}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.address}
                        value={address || ''}
                        onChange={this.handleChange}
                        name="address"
                        maxLength="100"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.city}</Form.Label>
                      <FormControlComponent
                        type="text"
                        className="text-capitalize"
                        placeholder={strings.city}
                        value={city || ''}
                        onChange={this.handleChange}
                        name="city"
                        disabled
                      />
                    </Form.Group>
                    <Form.Group as={Col}>
                      <Form.Row>
                        <Form.Group as={Col} md={6}>
                          <Form.Label>{strings.state}</Form.Label>
                          <FormControlComponent
                            type="text"
                            className="text-capitalize"
                            placeholder={strings.state}
                            value={state || ''}
                            onChange={this.handleChange}
                            name="state"
                            disabled
                          />
                        </Form.Group>
                        <Form.Group as={Col} md={6}>
                          <Form.Label>{strings.zip}{this.isZipCodeRequired() && <span className="asterisk-color">*</span>}</Form.Label>
                          <FormControlComponent
                            type="text"
                            className="text-capitalize"
                            placeholder={strings.zip}
                            value={zipcode || ''}
                            onChange={this.handleChange}
                            onBlur={event => {
                              this.handleZipChange(event);
                            }}
                            name="zipcode"
                            readOnly={!userInformation.write}
                            maxLength="7"
                          />
                        </Form.Group>
                      </Form.Row>
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.primaryPhone}</Form.Label>

                      <NumberFormat
                        className="form-control"
                        placeholder="(___)-___-____"
                        format="(###)-###-####"
                        mask="_"
                        value={primaryPhone || ''}
                        onChange={this.handleChange}
                        name="primaryPhone"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.secondaryPhone}</Form.Label>
                      <NumberFormat
                        className="form-control"
                        placeholder="(___)-___-____"
                        format="(###)-###-####"
                        mask="_"
                        value={mobilePhone || ''}
                        onChange={this.handleChange}
                        name="mobilePhone"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        placeholder={strings.email}
                        value={email}
                        onChange={this.handleChange}
                        name="email"
                        maxLength="100"
                        readOnly={!userInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                  <hr />
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.role} <span className="asterisk-color">*</span></Form.Label>
                      {this.getRoles()}
                    </Form.Group>
                  </Form.Row>
                  {this.getTerritories()}
                  <div className="user-actions">
                    <div className="account-modify-actions">
                      {modifyUserAccount.write && canModifyAccount ? (
                        deleted ? (
                          <LinkButton
                            label={strings.activateAccount}
                            onClick={this.handleActivateAccount}
                          />
                        ) : (
                            <Fragment>
                              {activated ? (
                                <LinkButton
                                  label={strings.resetPassword}
                                  onClick={this.handleResetPassword}
                                />
                              ) : (
                                  <LinkButton
                                    label={strings.resendActivationLink}
                                    onClick={this.handleResendActivationLink}
                                  />
                                )}
                              <LinkButton
                                label={strings.deactivateAccount}
                                variant="danger"
                                onClick={this.handleDeactivateAccount}
                              />
                            </Fragment>
                          )
                      ) : null}
                    </div>
                    <ButtonComponent
                      id="update-user-bottom"
                      buttonAction={this.handleUpdate}
                      hidden={!userInformation.write}
                      icon="report-icon"
                      buttonText={strings.update}
                    />
                  </div>
                </Form>
                <p id="error_message" className="text-danger">
                  {error}
                </p>
                <ConfirmationDialog
                  show={dialog.show}
                  handleClose={dialog.handleClose}
                  body={dialog.body}
                  title={dialog.title}
                  button={dialog.button}
                  confirmFunction={dialog.confirmFunction}
                />
                <DeactivateConfirmDialog
                  show={deactivateDialog.show}
                  handleClose={deactivateDialog.handleClose}
                  body={deactivateDialog.body}
                  title={deactivateDialog.title}
                  button={deactivateDialog.button}
                  confirmFunction={deactivateDialog.confirmFunction}
                  reasonCodes={reasonCodes}
                  reasonCode={reasonCode}
                  otherReasonCode={otherReasonCode}
                  handleChange={this.handleChange}
                />
              </div>
              <FootNote />
            </MainContent>
          </MainWrapper>
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { userReducer, languagesReducer, breadcrumbsReducer } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    userInfo: userReducer.userInfo[id] || {},
    cityStateByZip: userReducer.cityStateByZip,
    languages: languagesReducer.languages,
    reasonCodes: userReducer.reasonCodes,
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};
export default connect(
  mapStateToProps,
  null
)(UserProfile);
