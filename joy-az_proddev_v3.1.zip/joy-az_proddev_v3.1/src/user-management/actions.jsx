import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import { decryptemail } from '../Cryptocode';
import {
  fetchUserProfilesService,
  createUserProfileService,
  activateUserProfileService,
  deactivateUserProfileService,
  resendActivationLinkUserProfileService,
  getReasonCodeActionService,
  getUserInfoService,
  updateUserInfoService,
  cityStateByZipService
} from 'user-management/services';
import forgotPasswordService from 'landing/forgotpassword/services';
import strings from 'localization/strings';
import { filterOutFalsyValues } from 'utils/helper';
import { getIVSalt, createEncryptedData } from 'utils/utltity';
const AesUtil = require('utils/AesUtil');

export function* fetchUserProfiles(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const payload = filterOutFalsyValues(action.payload);
    if (action.payload.searchString === '' || action.payload.searchString === null) {
      payload.searchString = '';
    }
    const response = yield call(fetchUserProfilesService, payload);
    if (response.status === 200 || response.status === 201) {
      yield put({
        type: constants.USER.USER_SEARCH_SUCCESS,
        response: response.data,
        totalUsers: response.headers['x-total-count']
      });
    } else {
      yield put({ type: constants.USER.USER_SEARCH_FAILURE, response });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({ type: constants.USER.USER_SEARCH_FAILURE, response });
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* createUserProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload, history, path, userRole, id } = action.allData;
    const response = yield call(createUserProfileService, payload);
    if (response.status === 201) {
      if (userRole === constants.ROLES.CLINIC_ADMIN) {
        yield put({
          type: constants.CLINICS.CLINIC_ADMIN_REQUEST,
          id
        });
      }
      if (userRole === constants.ROLES.ASSOCIATE_EXECUTIVE) {
        yield put({
          type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_REQUEST,
          payload: id
        });
      }
      if (userRole === constants.ROLES.HCP) {
        yield put({
          type: constants.CLINICS.CLINIC_HCP_REQUEST,
          id
        });
      }
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* deactivateUserProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload } = action;
    const { id, data } = payload;
    const response = yield call(deactivateUserProfileService, { id, data });
    yield put({
      type: constants.USER.UPDATE_USER_INFO,
      key: id,
      response: { deleted: true, activated: false }
    });
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: response.data.message, path: false }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* activateUserProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload } = action;
    const { id } = payload;
    const response = yield call(activateUserProfileService, { id });
    if (response.status === 200) {
      yield put({
        type: constants.USER.UPDATE_USER_INFO,
        key: id,
        response: { deleted: false }
      });
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: response.data.message, path: false }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* resetPasswordUserProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextUserName = aesUtil.encrypt(salt, iv, action.payload.email),
      encryptedEmailId = createEncryptedData([iv, salt, ciphertextUserName])
    const response = yield call(forgotPasswordService, encryptedEmailId);
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: response.data.message, path: false }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* resendActivationLinkUserProfile(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload } = action;
    const { id } = payload;
    const response = yield call(resendActivationLinkUserProfileService, { id });
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: response.data.message, path: false }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getReasonCodeAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getReasonCodeActionService);
    if (response.status === 200) {
      yield put({
        type: constants.USER.REASON_CODE_SUCCESS,
        response: response.data
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getUserInfo(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getUserInfoService, action.id);
    response.data.user.email = response.data.user.email ? decryptemail(response.data.user.email) : '';
    response.data.user.createdBy = response.data.user.createdBy ? decryptemail(response.data.user.createdBy) : '';
    response.data.user.authorities[0].name = decryptemail(response.data.user.authorities[0].name)
    yield put({
      type: constants.USER.USER_SUCCESS,
      response: response.data.user || {},
      key: action.id
    });
    if (response.status !== 200 && response.status !== 201) {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({ type: constants.USER.USER_FAILURE, key: action.id });
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* updateUserInfo(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      updateUserInfoService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* cityStateByZip(action) {
  try {
    const response = yield call(cityStateByZipService, action.zip);

    if (response.status === 400) {
      yield put({ type: constants.ZIP.CITYSTATEBYZIP_FAILURE });
    } else {
      yield put({
        type: constants.ZIP.CITYSTATEBYZIP_SUCCESS,
        response: response[0]
      });
    }
  } catch (response) {
    yield put({ type: constants.ZIP.CITYSTATEBYZIP_FAILURE });
  }
}

export function* ccityStateByZip(action) {
  try {
    const response = yield call(cityStateByZipService, action.zip);
    yield put({
      type: constants.ZIP.CCITYSTATEBYZIP_SUCCESS,
      response: response[0]
    });
  } catch (response) {
    yield put({ type: constants.ZIP.CCITYSTATEBYZIP_FAILURE });
  }
}
