import React, { Component } from 'react';
import { Modal, Image, Form, Col } from 'react-bootstrap';
import Close from 'assets/img/ic-close-big-white.svg';
import strings from 'localization/strings';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import { getReasonCodeDropdown } from 'utils/utltity';

class DeactivateConfirmDialog extends Component {
	state = { error: '' }

	handleConfirm = () => {
		const { reasonCode, otherReasonCode, confirmFunction } = this.props;
		if (!reasonCode || (reasonCode === strings.otherReasonCodeValue && !otherReasonCode)) {
			this.setState({ error: strings.deactivationCodeRequired });
		} else {
			this.setState({ error: '' });
			confirmFunction();
		}
	};

	render() {
		const { show, handleClose, handleChange, className, reasonCodes, reasonCode, otherReasonCode } = this.props;
		const { error } = this.state;
		return (
			<Modal className={`modal-main ${className ? className : ''}`} centered show={show} onHide={handleClose}>
				<Modal.Header>
					<Modal.Title>{strings.deactivateAccount}</Modal.Title>
					<Image
						src={Close}
						width="17"
						height="17"
						onClick={handleClose}
						className="d-inline-block"
						alt="Close"
					/>
				</Modal.Header>
				<Modal.Body>
					<div>
						<div>{strings.deactivateUserWarning}</div>
						<Form.Group as={Col} md={8}>
							<Form.Label>{strings.reasonCode} <span className="asterisk-color">*</span></Form.Label>
							<Form.Control
								as="select"
								name="reasonCode"
								onChange={handleChange}
								value={reasonCode}
							>
								<option defaultValue value="">
									{strings.selectReasonCode}
								</option>
								{getReasonCodeDropdown(reasonCodes)}
							</Form.Control>
						</Form.Group>
						{
							reasonCode === strings.otherReasonCodeValue ?
								< Form.Group as={Col} md={8}>
									<Form.Label>{strings.others} <span className="asterisk-color">*</span></Form.Label>
									<FormControlComponent
										type="text"
										placeholder={strings.enterReasonCode}
										value={otherReasonCode}
										onChange={handleChange}
										name="otherReasonCode"
									/>
								</Form.Group>
								:
								null
						}
						{
							(reasonCode === strings.otherReasonCodeValue && !otherReasonCode) || !reasonCode ?
								<p className="text-danger">
									{error}
								</p>
								:
								null
						}
					</div>
				</Modal.Body>
				<Modal.Footer>
					<ButtonComponent
						buttonAction={handleClose}
						icon="cancel-icon"
						buttonText={strings.close}
						textClass="dialog-btn-text"
					/>
					<ButtonComponent
						buttonAction={this.handleConfirm}
						icon="right-arrow"
						buttonClass="mt-auto"
						buttonText={strings.deactivateAccount}
						textClass="dialog-btn-text"
					/>
				</Modal.Footer>
			</Modal >
		);
	}
};

export default DeactivateConfirmDialog;
