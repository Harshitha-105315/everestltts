import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';

function logutUserService() {
  return authRequest({
    url: API.LOGOUT,
    method: 'POST',
    data: {}
  });
}
export default logutUserService;
