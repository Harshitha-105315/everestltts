import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';

import constants from 'constants.js';
import urls from 'urls';

class Logout extends Component {
  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.LOGOUT.LOGOUT_REQUEST
    });
    dispatch({
      type: constants.LOGOUT.FLUSH_STORE_REQUEST
    });
  }

  render() {
    return <Redirect to={urls.LOGIN} />;
  }
}

export default connect()(Logout);
