import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import { resetToken } from 'utils/helper';
import logoutUserService from './service';

export function* logoutUser() {
  try {
    yield call(logoutUserService);
  } catch (error) {
    console.log(error);
  }
}

export function* flushStore() {
  resetToken();
  yield put({
    type: constants.LOGOUT.USER_LOGOUT
  });
}
