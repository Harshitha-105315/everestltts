import constants from 'constants.js';

const initalState = {
  languages: {}
};
function languagesReducer(state = initalState, action) {
  if (action.type === constants.LANGUAGES.LANGUAGES_SUCCESS) {
    return Object.assign({}, state, { languages: action.enLanguage.language });
  }
  if (action.type === constants.LANGUAGES.LANGUAGES_FAILURE) {
    return Object.assign({}, state, { languages: {} });
  }
  return state;
}
export default languagesReducer;
