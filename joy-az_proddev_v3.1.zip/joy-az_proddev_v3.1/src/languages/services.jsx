import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';

function getLanguagesServices() {
  return authRequest({
    url: API.LANGUAGES,
    method: 'GET'
  });
}
export default getLanguagesServices;
