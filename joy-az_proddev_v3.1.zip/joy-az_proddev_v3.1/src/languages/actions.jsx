import { put } from 'redux-saga/effects';
import constants from 'constants.js';
import enLanguage from './i18n/en/language';

function* getLanguages() {
  try {
    yield put({ type: constants.LANGUAGES.LANGUAGES_SUCCESS, enLanguage });
  } catch (response) {
    yield put({ type: constants.LANGUAGES.LANGUAGES_FAILURE });
  }
}
export default getLanguages;
