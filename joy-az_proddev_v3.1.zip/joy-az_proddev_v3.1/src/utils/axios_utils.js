import axios from 'axios';
import config from 'config/config';
import constants from 'constants.js';
import { getToken } from 'utils/helper';
import strings from 'localization/strings';
import store from 'store';
import API from 'api/api_config';
import urls from 'urls';
import history from '../history';

const serverUrl = config.BASE_URL;

const client = axios.create({
  baseURL: serverUrl
});

/**
 * Request Wrapper with default success/error actions
 */

const ajaxClient = options => {
  const clientOptions = Object.assign({}, options);
  delete clientOptions[constants.RETURNRESPONSE];

  const onSuccess = response => {
    // console.debug('Request Successful!', response);
    if (options[constants.RETURNRESPONSE]) {
      return response;
    }
    return response.data;
  };

  const onError = error => {
    // console.error('Request Failed:', error.config);
    if (error.response) {
      // Request was made but server responded with something
      // other than 2xx
      // console.error('Status:', error.response.status);
      // console.error('Data:', error.response.data);
      // console.error('Headers:', error.response.headers);
      if (error.response.status === 401) {
        const skip401Apis = [API.AUTHENTICATE, API.ACTIVATEACCOUNTWITHKEY, API.ACTIVATEUSERACCOUNTWITHKEY, API.ACTIVATEACCOUNTWITHEMAIL, API.FORGOTPASSWORDFINISH, API.LOGOUT];
        if (skip401Apis.indexOf(options.url) < 0) {
          store.dispatch({
            type: constants.LOGOUT.FLUSH_STORE_REQUEST
          });
          store.dispatch({
            type: constants.ALERT.ADD_SUCCESS_RESPONSE,
            response: { history, path: urls.LOGOUT }
          });
        }
      }
    } else if (error.message === 'Network Error' && !navigator.onLine) {
      // Handle internet connectivity error.
      return { data: { ERROR: strings.connectivityErrorMessage } };
    } else {
      // Something else happened while setting up the request
      // triggered the error
      // console.error('Error Message:', error.message);
    }
    return error.response;
  };
  return client(clientOptions)
    .then(onSuccess)
    .catch(onError);
};

const request = options => {
  return ajaxClient(options);
};

const authRequest = options => {
  const authOptions = Object.assign({}, options);
  if (!Object.prototype.hasOwnProperty.call(authOptions, 'headers')) {
    authOptions.headers = {};
  }
  if (
    !Object.prototype.hasOwnProperty.call(
      authOptions.headers,
      constants.AUTHTOKEN
    )
  ) {
    authOptions.headers[constants.AUTHTOKEN] = getToken();
  }
  return ajaxClient(authOptions);
};

export { request, authRequest };
export default request;
