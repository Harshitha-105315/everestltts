import React from 'react';
import moment from 'moment-timezone';
import constants from 'constants.js';
import { set, map, includes } from 'lodash';
import strings from 'localization/strings';
import { decryptdata } from '../Cryptocode';
export function getPatientDevices(patientID) {
  const allDeviceTypes = ['MONARCH', 'VEST', 'TITAN'];
  const deviceType = localStorage.getItem(`deviceType_${patientID}`);
  let deviceTypes = [];
  if (deviceType === 'ALL') {
    deviceTypes = allDeviceTypes;
  } else if (includes(allDeviceTypes, deviceType)) {
    deviceTypes = [deviceType];
  }
  return deviceTypes;
}

export function getBetweenDates(startDate, endDate, interval) {
  // const dayInterval = 1000 * 60 * 60 * 24; // 1 day
  // const halfDayInterval = 1000 * 60 * 60 * 12; // 1/2 day
  const duration = endDate - startDate;
  const steps = duration / interval;
  return Array.from({ length: steps + 1 }, (v, i) =>
    moment(new Date(startDate.valueOf() + interval * i)).format('MM/DD/YYYY')
  );
}

export function getLastDate(date) {
  return new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59);
}

export function getLatestMonth(month1, month2) {
  return month1.isBefore(month2, 'date') ? month2 : month1;
}

export function getMonthsAgoDate(months) {
  return moment().subtract(months, 'months');
}

export function selectPreviousMonth(date, noOfMonth) {
  date.setMonth(date.getMonth() - noOfMonth);
  date.setDate(1);
  return new Date(date);
}

export function dateDiffInDays(a, b) {
  // Discard the time and time-zone information.
  const start = new Date(a.setHours(0, 0, 0, 0));
  const end = new Date(b.setHours(0, 0, 0, 0));
  const utc1 = Date.UTC(start.getFullYear(), start.getMonth(), start.getDate());
  const utc2 = Date.UTC(end.getFullYear(), end.getMonth(), end.getDate());
  return Math.floor((utc2 - utc1) / constants._MS_PER_DAY);
}

export function getTokenData() {
  try {
    const sessionData = JSON.parse(localStorage.getItem(constants.TOKEN));
    return sessionData;
  } catch (e) {
    return null;
  }
}

export function setHelpTipsFlag() {
  const userId = getUserData().userId;
  const idList = JSON.parse(localStorage.getItem(strings.helpTipsAccessed));
  const decryptedList = [];
  const encryptedList = [];
  let flag = false;
  if (idList && idList.length) {
    for (const index in idList) {
      decryptedList[index] = parseInt(window.atob(idList[index]));
    }
    for (const index in decryptedList) {
      if (userId === decryptedList[index]) {
        flag = true;
      }
    }
  }
  if (!flag) {
    decryptedList.push(userId);
    for (const index in decryptedList) {
      encryptedList[index] = window.btoa(decryptedList[index]);
    }
    localStorage.setItem(
      strings.helpTipsAccessed,
      JSON.stringify(encryptedList)
    );
  }
}

export function getHelpTipsFlag() {
  const userId = getUserData().userId;
  const decryptedList = [];
  let flag = false;
  const idList = JSON.parse(localStorage.getItem(strings.helpTipsAccessed));
  if (idList && idList.length) {
    for (const index in idList) {
      decryptedList[index] = parseInt(window.atob(idList[index]));
    }
    for (const index in decryptedList) {
      if (userId === decryptedList[index]) {
        flag = true;
      }
    }
  }
  return flag;
}

export function pinnedSort(list) {
  return list.sort((p1, p2) => {
    const a = p1.patientInfo || p1;
    const b = p2.patientInfo || p2;
    return sortByProps(a, b, [
      { key: 'flagged', asc: false },
      { key: 'isNew', asc: false },
      { key: 'sessionPercentage', asc: true }
    ]);
  });
}

function sortByProps(a, b, props) {
  for (let i = 0; i < props.length; i++) {
    const { key, asc } = props[i];
    const xor = Number(a[key]) ^ Number(b[key]);
    if (xor) {
      return asc ? (a[key] < b[key] ? -1 : 1) : a[key] > b[key] ? -1 : 1;
    }
    if (i === props.length - 1) {
      return -1;
    }
  }
}

export function customSort(arr, key, order, moveLast = 0) {
  // asc-desc sort with move passed argument always to end.
  const ASCENDING = 'asc';
  const DESCENDING = 'desc';
  return arr.sort((a, b) => {
    if (order === ASCENDING) {
      return (
        (a[key] === moveLast) - (b[key] === moveLast) ||
        +(a[key] > b[key]) ||
        -(a[key] < b[key])
      );
    }
    if (order === DESCENDING) {
      return (
        (a[key] === moveLast) - (b[key] === moveLast) ||
        -(a[key] > b[key]) ||
        +(a[key] < b[key])
      );
    }
    return arr;
  });
}

export function getToken() {
  try {
    const sessionData = getTokenData();
    return sessionData.token;
  } catch (e) {
    return null;
  }
}

export function getUserData() {
  try {
    const sessionData = getTokenData();
    return {
      actualRole: decryptdata(sessionData.actualRole, 'Protected$9876'),
      role: decryptdata(sessionData.role, 'Protected$9876'),
      userId: decryptdata(sessionData.userId, 'Protected$9876'),
      hillromId: sessionData.hillromId,
      user: sessionData.user,
      timeZone: sessionData.user.timeZone
    };
  } catch (e) {
    return null;
  }
}

export function getUserId() {
  try {
    const sessionData = JSON.parse(localStorage.getItem(constants.TOKEN));
    return decryptdata(sessionData.userId, 'Protected$9876');
  } catch (e) {
    return null;
  }
}

export function resetToken() {
  try {
    return localStorage.removeItem(constants.TOKEN);
  } catch (e) {
    return null;
  }
}

export function validateEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}

export function isValidMobile(phone, digit, optional) {
  if (optional && !phone) {
    return true;
  }
  let numberLen;
  try {
    numberLen = parseInt(phone.replace(/[^0-9.]/g, ''), 10).toString().length;
  } catch (e) {
    numberLen = 0;
  }
  if (optional && numberLen >= 1 && numberLen === digit) return true;
  if (numberLen === digit) return true;
  return false;
}

export const getSearchString = obj => {
  const parts = [];

  Object.keys(obj).forEach(function nestedObject(element) {
    if (obj[element] === null) return;
    if (typeof obj[element] === 'object') {
      let s = `${element}=`;
      Object.keys(obj[element]).forEach(function noObject(ele) {
        s += `${ele}:${obj[element][ele]};`;
      });
      parts.push(s);
    } else {
      parts.push(`${element}=${obj[element]}`);
    }
  });
  return parts
    .join('&')
    .replace('perPage', 'per_page')
    .replace('sortBy', 'sort_by');
};

export const decode = queryString => {
  const queryStringPieces = queryString
    .replace(/%20/, ' ')
    .replace(/%20/, ' ')
    .split('&');
  const decodedQueryString = {};
  queryStringPieces.forEach(piece => {
    let [key, value] = piece.split('=');
    if (/^\d+$/.test(value)) {
      value = Number(value);
    } else if (value === 'true' || value === 'false') {
      value = value === 'true';
    } else if (/^\d:\w+/.test(value)) {
      value = [value.split(':')[1].replace(';', '')];
    } else {
      value = value || '';
    }
    set(decodedQueryString, key, value);
  });
  return decodedQueryString;
};

export function getCityByStateCountryList(cityByStateCountry) {
  const cityByStateCountryList = [];
  if (cityByStateCountry !== [] && cityByStateCountry !== undefined)
    cityByStateCountry.forEach(element => {
      cityByStateCountryList.push(element.name);
    });
  return cityByStateCountryList;
}

export function setStateByKey(currentState, key, data) {
  return { ...currentState, [key]: data };
}

export function mapRoleValues(role) {
  switch (role) {
    case constants.ROLES.PATIENT:
      return strings.roles.patientUser;
    case constants.ROLES.SUPER_ADMIN:
      return strings.roles.superAdmin;
    case constants.ROLES.HCP:
      return strings.roles.provider;
    case constants.ROLES.CUSTOMER_SERVICES:
      return strings.roles.customerService;
    case constants.ROLES.CLINIC_ADMIN:
      return strings.roles.clinicAdmin;
    case constants.ROLES.ASSOCIATE_EXECUTIVE:
      return strings.roles.accountExecutive;
    case constants.ROLES.CARE_GIVER:
      return strings.roles.careGiver;
    default:
      return role;
  }
}

export function getPaginatedUserIds(currentState, currentProps, pageName) {
  let currentPatientList = [];
  if (pageName === constants.CLINICS) {
    const { perPage, page, order, sortBy } = currentState;
    const { associatedPatients } = currentProps;
    const indexofLastItem = page * perPage;
    const indexOfFirstItem = indexofLastItem - perPage;
    let patientCopy = [...associatedPatients];
    if (sortBy) {
      patientCopy = customSort(patientCopy, sortBy, order);
    }
    currentPatientList = patientCopy.slice(indexOfFirstItem, indexofLastItem);
  } else if (pageName === constants.PATIENT) {
    const { pageSize, pageNo, sortOrder, sortBy } = currentState;
    const { patients } = currentProps;
    const indexofLastItem = pageNo * pageSize;
    const indexOfFirstItem = indexofLastItem - pageSize;
    let patientCopy = [...map(patients, 'patientInfo')];
    if (sortBy) {
      patientCopy = customSort(patientCopy, sortBy, sortOrder.toLowerCase());
    }
    currentPatientList = patientCopy.slice(indexOfFirstItem, indexofLastItem);
  }
  const allIds = currentPatientList.map(d => {
    return d.userId;
  });

  return allIds;
}

export const loadState = () => {
  try {
    const serializedState = sessionStorage.getItem('hillRom_breadCrumbs');
    if (serializedState === null) {
      return {};
    }
    return JSON.parse(serializedState);
  } catch (err) {
    return {};
  }
};

export const saveState = state => {
  const serializedState = JSON.stringify(state);
  sessionStorage.setItem('hillRom_breadCrumbs', serializedState);
};

export const getTransmissionCell = element => {
  if (element.never === true) {
    return (
      <div>
        <p className="text-capitalize never-transmission-warning">
          {strings.neverTransmitted}
        </p>
      </div>
    );
  }
  if (element.stop === true) {
    return (
      <div>
        {element.lastTrans
          ? moment(element.lastTrans).format('MMM DD, YYYY hh:mm A')
          : ''}
        <p className="text-uppercase no-transmission-warning">
          {strings.noTransmission}
        </p>
      </div>
    );
  }
  return element.lastTrans
    ? moment(element.lastTrans).format('MMM DD, YYYY hh:mm A')
    : '';
};

export const filterOutFalsyValues = (obj, skipReplace) => {
  return Object.entries(obj).reduce((a, [k, v]) => {
    if (!skipReplace) {
      k = k === 'perPage' ? 'per_page' : k;
      k = k === 'sortBy' ? 'sort_by' : k;
    }
    if (v === null || v === '' || v === undefined) {
      return a;
    } else if (typeof v === 'object') {
      const val = Object.entries(v).reduce((str, [k, v]) => {
        str += `${k}:${v};`;
        return str;
      }, '');
      a = { ...a, [k]: val };
    } else {
      a = { ...a, [k]: v };
    }
    return a;
  }, {});
};

export const getDeviceTypeList = patient => {
  const { vestTypeCodeList, monrachTypeCodeList, titanTypeCodeList, deviceType } = patient;
  switch (deviceType) {
    case constants.DEVICE_TYPE_CODE.VISIVEST:
      return vestTypeCodeList || [];
    case constants.DEVICE_TYPE_CODE.MONARCH:
      return monrachTypeCodeList || [];
    case constants.DEVICE_TYPE_CODE.TITAN:
      return titanTypeCodeList || [];
    case constants.DEVICE_TYPE_CODE.ALL:
      return [...(vestTypeCodeList || []), ...(monrachTypeCodeList || []), ...(titanTypeCodeList || [])];
    default:
      return [];
  }
};

export function getTimeZoneOffset(timeZone) {
  let offset;
  if (timeZone) {
    offset = timeZone.split('UTC')[1];
  } else {
    let offsetMinutes = moment().utcOffset();
    let sign = '';
    if (offsetMinutes < 0) {
      sign = '-'
      offsetMinutes = offsetMinutes * -1;
    } else {
      sign = '+'
    }

    let hours = parseInt(offsetMinutes / 60);
    let mins = parseInt(offsetMinutes % 60);

    if (hours < 10) {
      hours = `0${hours}`;
    }
    if (mins < 10) {
      mins = `0${mins}`;
    }

    offset = `${sign}${hours}:${mins}`;
  }

  return offset;
}

export function getFormattedTime(datetime) {
  let [hours, minutes] = datetime.split(':');
  hours = Number(hours);
  minutes = Number(minutes);
  const ampm = hours >= 12 ? 'PM' : 'AM';
  minutes = minutes < 10 ? '0' + minutes : minutes;
  hours = hours > 12 ? hours % 12 : hours;
  hours = hours < 10 ? (hours === 0 ? '12' : '0' + hours) : hours;
  return `${hours}:${minutes} ${ampm}`;
}

// get end of the month but maximum end can only be present day
export function getEndDate(date) {
  date = date || moment();
  const endDate = date.clone().endOf('month');
  const today = moment();
  return today.isBefore(endDate) ? today : endDate;
}

export function getNumberRangeOptions(min, max) {
  const options = []
  for (let i = min; i <= max; i++) {
    options.push(
      <option key={i} value={i}>{i}</option>
    )
  }
  return options;
}

export default {
  getPatientDevices,
  getBetweenDates,
  getToken,
  resetToken,
  setStateByKey,
  getPaginatedUserIds,
  getHelpTipsFlag,
  setHelpTipsFlag,
  loadState,
  saveState,
  getTransmissionCell,
  getEndDate,
  getNumberRangeOptions
};
