
const CryptoJS = require("crypto-js");
let keySize, iterationCount;

const AesUtil = function (key, iteration) {
  keySize = key / 32;
  iterationCount = iteration;
};

AesUtil.prototype.generateKey = function (salt, passPhrase) {
  let key = CryptoJS.PBKDF2(
    passPhrase,
    CryptoJS.enc.Hex.parse(salt),
    { keySize: keySize, iterations: iterationCount });
  return key;
}

AesUtil.prototype.encrypt = function (salt, iv, plainText) {
  let passPhrase = '1234098741739271',
    key = this.generateKey(salt, passPhrase),
    encrypted = CryptoJS.AES.encrypt(
      plainText,
      key,
      { iv: CryptoJS.enc.Hex.parse(iv) });
  return encrypted.ciphertext.toString(CryptoJS.enc.Base64);
}

AesUtil.prototype.decrypt = function (salt, iv, cipherText) {
  let passPhrase = 'Protected$9876';
  var key = this.generateKey(salt, passPhrase);
  var cipherParams = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Base64.parse(cipherText)
  });
  var decrypted = CryptoJS.AES.decrypt(
    cipherParams,
    key,
    { iv: CryptoJS.enc.Hex.parse(iv) });
  return decrypted.toString(CryptoJS.enc.Utf8);
}

module.exports = AesUtil;
