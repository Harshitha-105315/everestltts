import React from 'react';
import { Breadcrumb, Form, Col } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import strings from 'localization/strings';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData } from 'utils/helper';
import { uid } from 'react-uid';
import constants from 'constants.js';
import { union, difference } from 'lodash';
import roleConstant from 'rolesData/roleConstant';
import { decryptemail } from '../Cryptocode';

var CryptoJS = require("crypto-js");

export function updateUrl(excempt = []) {
  // const { history } = this.props;
  // const payload = Object.assign({}, this.state);
  // excempt.forEach(element => {
  //   delete payload[element];
  // });
  // // history.replace({ search: this.getSearchString(payload) });
}

export function clearBreadCrumb() {
  const { dispatch } = this.props;
  dispatch({ type: constants.BREADCRUMBS.BREADCRUMBS_CLEAR });
}

export function addBreadCrumb(obj) {
  const { dispatch, location } = this.props;
  dispatch({
    type: constants.BREADCRUMBS.BREADCRUMBS_ADD,
    data: {
      title: obj.title,
      path: location.pathname,
      search: location.search
    }
  });
}

export function getBreadCrumb(breadcrumbs) {
  if (breadcrumbs.length === 1) {
    return null;
  }
  return (
    <Breadcrumb>
      {breadcrumbs.map(element => (
        <LinkContainer
          exact
          key={uid(element)}
          to={`${element.path}${element.search}`}
        >
          <Breadcrumb.Item active={element.active}>
            {element.title}
          </Breadcrumb.Item>
        </LinkContainer>
      ))}
    </Breadcrumb>
  );
}

export function removeBreadCrumb() {
  const { dispatch } = this.props;
  dispatch({ type: constants.BREADCRUMBS.BREADCRUMBS_REMOVE });
}

export function handleZipChange(event) {
  const { value } = event.target;
  const { dispatch } = this.props;
  const { zipcode } = this.state;
  if (value !== '') {
    dispatch({
      type: constants.ZIP.CITYSTATEBYZIP_REQUEST,
      zip: zipcode
    });
  } else {
    dispatch({
      type: constants.ZIP.CITYSTATEBYZIP_FAILURE
    });
  }
}

export function languagesDropdown() {
  const { languages } = this.props;
  return Object.keys(languages).map(function mapLanguages(key) {
    return <option key={languages[key]}>{languages[key]}</option>;
  });
}

export function getReasonCodeDropdown(codes) {
  return codes.map(code => {
    return <option key={code.id} value={code.type_code}>{code.type_code}</option>;
  });
};

export function getSpeciality() {
  const { specialityList } = this.props;
  if (specialityList.length !== undefined) {
    return specialityList.map(element => (
      <option key={element.id}> {element.type_code_value}</option>
    ));
  }
  return [];
}

export function getRelationships() {
  const { relationships } = this.props;
  if (relationships !== []) {
    return relationships.map(element => <option>{element}</option>);
  }
  return [];
}

export function dropDowns(state, props, handleChange) {
  const {
    deviceType,
    monarchGarmentColor,
    vestGarmentSize,
    vestGarmentColor,
    vestGarmentType,
    titanGarmentSize,
    titanGarmentColor,
    titanGarmentType
  } = state;
  const { actualRole } = getUserData();

  const patientInformation = accessMatrix.PATIENT_INFORMATION[actualRole];
  const { visiSize, visiColor, visiType, monarchColor, titanSize, titanColor, titanType, } = props;
  if (deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
    return (
      <Form.Row>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiTitanGarment}</Form.Label>
          <Form.Control
            as="select"
            name="titanGarmentType"
            value={titanGarmentType || ''}
            onChange={handleChange}
            disabled={!patientInformation.write} >
            <option defaultValue disabled value="">
              {strings.selectVisiTitanGarment}
            </option>
            {titanType.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiTitanSize}</Form.Label>
          <Form.Control
            as="select"
            id="dropdown-visi-size"
            name="titanGarmentSize"
            value={titanGarmentSize || ''}
            onChange={handleChange}
            disabled={!patientInformation.write} >
            <option defaultValue disabled value="">
              {strings.selectVisiTitanSize}
            </option>
            {titanSize.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiTitanColor}</Form.Label>
          <Form.Control
            as="select"
            name="titanGarmentColor"
            value={titanGarmentColor || ''}
            onChange={handleChange}
            disabled={!patientInformation.write} >
            <option defaultValue disabled value="">
              {strings.selectVisitTitanColor}
            </option>
            {titanColor.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
      </Form.Row>
    );
  }
  if (deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
    return (
      <Form.Row>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.monarchColor}</Form.Label>
          <Form.Control
            as="select"
            name="monarchGarmentColor"
            onChange={handleChange}
            value={monarchGarmentColor || ''}
            disabled={!patientInformation.write}
          >
            <option defaultValue disabled value="">
              {strings.selectMonarchColor}
            </option>
            {monarchColor.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
      </Form.Row>
    );
  }
  if (deviceType === constants.DEVICE_TYPE_CODE.VISIVEST) {
    return (
      <Form.Row>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiVestGarment}</Form.Label>
          <Form.Control
            as="select"
            name="vestGarmentType"
            value={vestGarmentType || ''}
            onChange={handleChange}
            disabled={!patientInformation.write}
          >
            <option defaultValue disabled value="">
              {strings.selectVisiVestGarment}
            </option>
            {visiType.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiVestSize}</Form.Label>
          <Form.Control
            as="select"
            id="dropdown-visi-size"
            name="vestGarmentSize"
            value={vestGarmentSize || ''}
            onChange={handleChange}
            disabled={!patientInformation.write}
          >
            <option defaultValue disabled value="">
              {strings.selectVisiVestSize}
            </option>
            {visiSize.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
        <Form.Group as={Col} md={4}>
          <Form.Label>{strings.visiVestColor}</Form.Label>
          <Form.Control
            as="select"
            name="vestGarmentColor"
            value={vestGarmentColor || ''}
            onChange={handleChange}
            disabled={!patientInformation.write}
          >
            <option defaultValue disabled value="">
              {strings.selectVisitVestColor}
            </option>
            {visiColor.map(e => {
              return (
                <option key={e.id} value={e.type_code}>
                  {e.type_code_value}
                </option>
              );
            })}
          </Form.Control>
        </Form.Group>
      </Form.Row>
    );
  }
  if (
    deviceType === constants.DEVICE_TYPE_CODE.ALL
  ) {
    return (
      <div>
        <Form.Row>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiVestGarment}</Form.Label>
            <Form.Control
              as="select"
              name="vestGarmentType"
              value={vestGarmentType || ''}
              onChange={handleChange}
              disabled={!patientInformation.write}
            >
              <option defaultValue disabled value="">
                {strings.selectVisiVestGarment}
              </option>
              {visiType.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiVestSize}</Form.Label>
            <Form.Control
              as="select"
              id="dropdown-visi-size"
              name="vestGarmentSize"
              value={vestGarmentSize || ''}
              onChange={handleChange}
              disabled={!patientInformation.write}
            >
              <option defaultValue disabled value="">
                {strings.selectVisiVestSize}
              </option>
              {visiSize.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>          
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiVestColor}</Form.Label>

            <Form.Control
              as="select"
              name="vestGarmentColor"
              value={vestGarmentColor || ''}
              onChange={handleChange}
              disabled={!patientInformation.write}
            >
              <option defaultValue disabled value="">
                {strings.selectVisitVestColor}
              </option>
              {visiColor.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.monarchColor}</Form.Label>
            <Form.Control
              as="select"
              name="monarchGarmentColor"
              value={monarchGarmentColor || ''}
              onChange={handleChange}
              disabled={!patientInformation.write}
            >
              <option disabled defaultValue value="">
                {strings.selectMonarchColor}
              </option>
              {monarchColor.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiTitanGarment}</Form.Label>
            <Form.Control
              as="select"
              name="titanGarmentType"
              value={titanGarmentType || ''}
              onChange={handleChange}
              disabled={!patientInformation.write}  >
              <option defaultValue disabled value="">
                {strings.selectVisiTitanGarment}
              </option>
              {titanType.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiTitanSize}</Form.Label>
            <Form.Control
              as="select"
              id="dropdown-visi-size"
              name="titanGarmentSize"
              value={titanGarmentSize || ''}
              onChange={handleChange}
              disabled={!patientInformation.write} >
              <option defaultValue disabled value="">
                {strings.selectVisiTitanSize}
              </option>
              {titanSize.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.visiTitanColor}</Form.Label>
            <Form.Control
              as="select"
              name="titanGarmentColor"
              value={titanGarmentColor || ''}
              onChange={handleChange}
              disabled={!patientInformation.write} >
              <option defaultValue disabled value="">
                {strings.selectVisitTitanColor}
              </option>
              {titanColor.map(e => {
                return (
                  <option key={e.id} value={e.type_code}>
                    {e.type_code_value}
                  </option>
                );
              })}
            </Form.Control>
          </Form.Group>
        </Form.Row>
      </div>
    );
  }
  return <div />;
}

export function setScreenSize() {
  if (!this.state.mobileFlag) {
    if (window.innerWidth < 575) {
      this.setState({ isMobile: true });
    }
  }
}

export function clearCustomPatientStoreValue(arr) {
  const { dispatch } = this.props;
  dispatch({
    type: constants.PATIENT.CLEAR,
    name: arr
  });
}

export function clearZipStoreValue() {
  const { dispatch } = this.props;
  dispatch({
    type: constants.ZIP.CLEAR
  });
}

export function storeSelectedPatientIds(event, id) {
  event.stopPropagation();
  event.preventDefault();
  const { selectedCheckBoxIds } = this.state;
  const tempPatientIds = selectedCheckBoxIds;
  const index = tempPatientIds.indexOf(id);
  if (index > -1) {
    tempPatientIds.splice(index, 1);
  } else {
    tempPatientIds.push(id);
  }
  this.setState({
    selectedCheckBoxIds: tempPatientIds
  });
}

export function clearAllSelectedCheckBoxes() {
  this.setState({ selectedCheckBoxIds: [] });
}

export function selectAllCheckBoxes(paginatedPatientIds) {
  const { selectedCheckBoxIds } = this.state;
  const patientIds = union(selectedCheckBoxIds, paginatedPatientIds);
  this.setState({
    selectedCheckBoxIds: patientIds
  });
}

export function deselectCheckBoxes(paginatedPatientIds) {
  const { selectedCheckBoxIds } = this.state;
  const patientIds = difference(selectedCheckBoxIds, paginatedPatientIds);
  this.setState({ selectedCheckBoxIds: patientIds });
}

export function getChangeRoleList(CURRENT_ROLE) {
  if (
    CURRENT_ROLE === roleConstant.ADMIN.ROLE
    ||
    CURRENT_ROLE === roleConstant.ACCT_SERVICES.ROLE
    ||
    CURRENT_ROLE === roleConstant.ASSOCIATES.ROLE
    ||
    CURRENT_ROLE === roleConstant.CUSTOMER_SERVICES.ROLE
    ||
    CURRENT_ROLE === roleConstant.ASSOCIATE_EXECUTIVE.ROLE
  ) {
    return [
      roleConstant.ADMIN,
      roleConstant.ACCT_SERVICES,
      roleConstant.ASSOCIATES,
      roleConstant.CUSTOMER_SERVICES,
      roleConstant.ASSOCIATE_EXECUTIVE
    ];
  } else if (CURRENT_ROLE === roleConstant.PATIENT.ROLE) {
    return [
      roleConstant.PATIENT
    ];
  } else if (
    CURRENT_ROLE === roleConstant.HCP.ROLE
    ||
    CURRENT_ROLE === roleConstant.CLINIC_ADMIN.ROLE
  ) {
    return [
      roleConstant.CLINIC_ADMIN,
      roleConstant.HCP
    ];
  } else if (CURRENT_ROLE === roleConstant.CARE_GIVER.ROLE) {
    return [
      roleConstant.CARE_GIVER
    ];
  } else if (CURRENT_ROLE === roleConstant.FOTA_ADMIN.ROLE) {
    return [
      roleConstant.FOTA_ADMIN
    ];
  } else if (CURRENT_ROLE === roleConstant.FOTA_APPROVER.ROLE) {
    return [
      roleConstant.FOTA_APPROVER
    ];
  }
};

export function getUserRole(CURRENT_ROLE) {
  switch (CURRENT_ROLE) {
    case roleConstant.ADMIN.ROLE:
      return roleConstant.ADMIN;
    case roleConstant.ACCT_SERVICES.ROLE:
      return roleConstant.ACCT_SERVICES;
    case roleConstant.ASSOCIATES.ROLE:
      return roleConstant.ASSOCIATES;
    case roleConstant.CUSTOMER_SERVICES.ROLE:
      return roleConstant.CUSTOMER_SERVICES;
    case roleConstant.PATIENT.ROLE:
      return roleConstant.PATIENT;
    case roleConstant.ASSOCIATE_EXECUTIVE.ROLE:
      return roleConstant.ASSOCIATE_EXECUTIVE;
    case roleConstant.CLINIC_ADMIN.ROLE:
      return roleConstant.CLINIC_ADMIN;
    case roleConstant.HCP.ROLE:
      return roleConstant.HCP;
    case roleConstant.CARE_GIVER.ROLE:
      return roleConstant.CARE_GIVER;
    case roleConstant.FOTA_ADMIN.ROLE:
      return roleConstant.FOTA_ADMIN;
    case roleConstant.FOTA_APPROVER.ROLE:
      return roleConstant.FOTA_APPROVER;
    default:
      return {
        ROLE: null,
        LABEL: null,
      };
  }
};

export function getIVSalt() {
  return CryptoJS.lib.WordArray.random(128 / 8).toString(CryptoJS.enc.Hex)
}

export function createEncryptedData(dataArray) {
  return window.btoa(dataArray.join('::'))
}