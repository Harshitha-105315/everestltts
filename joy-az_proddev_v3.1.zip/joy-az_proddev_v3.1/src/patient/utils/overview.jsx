import React from 'react';
import ReactDOM from 'react-dom';
import { Card, Table } from 'react-bootstrap';
import { Subject } from 'rxjs';

import strings from 'localization/strings';
import {
  isEmpty,
  mapValues,
  flatMap,
  forEach,
  chain,
  sum,
  head,
  last,
  sumBy,
  isNil,
  size,
  sortBy,
  findLastIndex,
  map,
  max,
  maxBy,
  groupBy,
  values,
  findKey,
  omit,
  without,
  range,
  orderBy,
  entries
} from 'lodash';
import { uid } from 'react-uid';
import moment from 'moment-timezone';
import pattern from 'patternomaly';
import constants from 'constants.js';
import { getBetweenDates, dateDiffInDays, getFormattedTime } from 'utils/helper';
import tickIcon from 'assets/img/tick-icon-small.png';
import crossIcon from 'assets/img/cross-icon-small.png';
import visiVestLogo from 'assets/img/logo/visivest.png';
import monarchLogo from 'assets/img/logo/monarch.png';
import titanLogo from 'assets/img/logo/titanlogo.png';
import spiroLogo from 'assets/img/logo/icon_spirometer.png';
import PdfCustomGauge from 'pdf-files/PdfCustomGauge';
import PdfCustomBarChart from 'pdf-files/PdfCustomBarChart';
import PdfCustomLineChart from 'pdf-files/PdfCustomLineChart';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import { getEndDate } from 'utils/helper';
import { getUserData } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix';

const logoMap = {
  VEST: visiVestLogo,
  MONARCH: monarchLogo,
  TITAN: titanLogo
};

const lineColor = { HILLROMSPIRO: '#27e7cf', OTHERSPIRO: '#5568e6', THERAPYAVG: '#c1c1c1' };

const subject = new Subject();

var therapyDataG = {};
var spiroDataG = {};
var xSiproLabels = [];
var Gdatasets_t = {};

let activeFromTo = {};
let protocolList = [];
let monthChange = null;
let activeProtocols = {};
let patientFirstTrans = null;
let patientIsManualVest = false;
let manualDeviceName = null;

export function hideCustomTooltip(el, tooltipEl, caretEl) {
  const tooltipElement = el || document.getElementById('CustomBarChart-tooltip');
  const tooltipElementDialog = tooltipEl || document.getElementById('CustomBarChart-tooltip-dialog');
  const caretElement = caretEl || document.getElementById('CustomBarChart-caret');
  if (tooltipElement && tooltipElement.style) {
    tooltipElement.style.opacity = 0;
    tooltipElement.style.display = 'none';
  }
  if (tooltipElementDialog && tooltipElementDialog.style) {
    tooltipElementDialog.style.display = 'none';
  }
  if (caretElement && caretElement.style) {
    caretElement.style.opacity = 0;
    caretElement.style.display = 'none';
  }
}

function daySessionRow(session, removeBorderBottomTr) {
  const lastTherapyIdx = findLastIndex(session.therapyEvents);
  return session.therapyEvents && session.therapyEvents.map((event, eidx) => {
    let removeBorder = false;
    return (
      <tr>
        {eidx === 0 && (
          <td className="border-0">
            {session.device === "VEST" && patientIsManualVest ?
              <img
                src={manualLogo}
                className="d-inline-block"
                alt={'Manual Device'}
                height="20"
                width="40"
              />
              :
              <img
                src={logoMap[session.device]}
                width="32"
                height="32"
                className="d-inline-block"
                alt="logo"
              />
            }
            <span className="align-middle">{session.time}</span>
          </td>
        )}
        {eidx === 1 && (
          <td rowSpan={lastTherapyIdx} className="align-middle text-center">
            <span>Total Duration<br></br></span>
            <img
              src={`${session.deviated ? crossIcon : tickIcon}`}
              width={`${session.deviated ? 8 : 10}`}
              height={`${session.deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span>{session.duration}m</span>
          </td>
        )
        }
        <td className={`${removeBorder ? 'border-0' : ''}`}>
          <img
            src={`${event.dur_deviated ? crossIcon : tickIcon}`}
            width={`${event.dur_deviated ? 8 : 10}`}
            height={`${event.dur_deviated ? 8 : 7}`}
            className="d-inline-block"
            alt=""
          />
          <span className="align-middle">{event.duration}m</span>
        </td>
        {session.device === "VEST" || session.device === "TITAN" && !patientIsManualVest &&
          (<td className={`${removeBorder ? 'border-0' : ''}`}>
            <img
              src={`${event.freq_deviated ? crossIcon : tickIcon}`}
              width={`${event.freq_deviated ? 8 : 10}`}
              height={`${event.freq_deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span className="align-middle">Freq {event.frequency}</span>
          </td>)
        }
        {session.device === "VEST" && !patientIsManualVest &&
          (<td className={`${removeBorder ? 'border-0' : ''}`}>
            <img
              src={`${event.press_deviated ? crossIcon : tickIcon}`}
              width={`${event.press_deviated ? 8 : 10}`}
              height={`${event.press_deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span className="align-middle">Pressure {event.pressure}</span>
          </td>)
        }
        {session.device === "TITAN" && !patientIsManualVest &&
          (<td className={`${removeBorder ? 'border-0' : ''}`}>
            <img
              src={`${event.intensity_deviated ? crossIcon : tickIcon}`}
              width={`${event.intensity_deviated ? 8 : 10}`}
              height={`${event.intensity_deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span className="align-middle">{strings.intensity} {event.intensity}</span>
          </td>)
        }
        {session.device === "MONARCH" &&
          (<td className={`${removeBorder ? 'border-0' : ''}`}>
            <img
              src={`${event.freq_deviated ? crossIcon : tickIcon}`}
              width={`${event.freq_deviated ? 8 : 10}`}
              height={`${event.freq_deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span className="align-middle">Freq {event.frequency}</span>
          </td>)
        }
        {session.device === "MONARCH" &&
          (<td className={`${removeBorder ? 'border-0' : ''}`}>
            <img
              src={`${event.press_deviated ? crossIcon : tickIcon}`}
              width={`${event.press_deviated ? 8 : 10}`}
              height={`${event.press_deviated ? 8 : 7}`}
              className="d-inline-block"
              alt=""
            />
            <span className="align-middle">Pressure {event.pressure}</span>
          </td>)
        }
      </tr>
    );
  });
}

function perDaySessionListItems(sessions) {
  var deviceList = groupBy(sessions, 'device');
  const lastSessionIdx = findLastIndex(sessions);
  const secondLastIdx = lastSessionIdx - 1;
  if (isEmpty(sessions)) {
    return (
      <div className="col-12 text-center">
        <p>No data available.</p>
      </div>
    );
  }
  return (
    Object.keys(deviceList)
      .sort()
      .reverse()
      .map(dType => {
        return (<React.Fragment>
          <div className="col-6">
            {deviceList[dType].map((session, sidx) => {
              const removeBorderBottomTr =
                sidx === lastSessionIdx || sidx === secondLastIdx;
              return (
                <Table size="sm">
                  <tbody>{daySessionRow(session, removeBorderBottomTr)}</tbody>
                </Table>
              );
            })}
          </div>
        </React.Fragment>)
      }
      )
  );
}

export function CustomLineTooltip(props) {
  const { data } = props;
  const { from, to, selectedOption, model, therapyData, totalAvgTherapy } = data;
  const index = model.dataPoints[0].index;
  const isTherapyData = ((therapyData !== undefined && therapyData.VEST !== undefined
    && !isEmpty(therapyData.VEST.avg)) || (therapyData !== undefined && therapyData.MONARCH !== undefined &&
      !isEmpty(therapyData.MONARCH.avg)) || (therapyData !== undefined && therapyData.TITAN !== undefined &&
        !isEmpty(therapyData.TITAN.avg)))
  const isSpiroData = (Gdatasets_t[0][index] !== null) || (Gdatasets_t[1][index] !== null);
  const hillromSpiroVal = Gdatasets_t[1][index] !== null ? Gdatasets_t[1][index] : null;
  const otherSpiroVal = Gdatasets_t[0][index] !== null ? Gdatasets_t[0][index] : null;
  return (
    <Card
      style={{
        minWidth: selectedOption === "all" && isTherapyData && isSpiroData ? '55rem' : '30rem',
        // minWidth: '55rem',
        // maxWidth: '55rem',
        maxWidth: selectedOption === "all" && isTherapyData && isSpiroData ? '55rem' : '30rem',
        maxHeight: '50rem',
        overflow: 'auto',
        boxShadow: 'rgba(0, 0, 0, 0.1) 0px 18px 24px 11px'
      }}
    >
      <Card.Body>
        <Card.Title>
          {moment(from).isSame(to, 'year') ? moment(new Date(from)).format('MMM DD') :
            moment(new Date(from)).format('MMM DD, YYYY')} - {moment(from).isSame(to, 'month') ?
              moment(new Date(to)).format('DD, YYYY') : moment(new Date(to)).format('MMM DD, YYYY')}
          <span
            className="float-right black-cross-small"
            onClick={() => hideCustomTooltip()}
            onKeyDown={() => hideCustomTooltip()}
            role="presentation"
          />
        </Card.Title>
        <div className="row my-2 py-2 mx-0">
          {(selectedOption === "all" || selectedOption === strings.therapy) &&
            <div className={`row${selectedOption === "all" && isTherapyData
              && isSpiroData ? ' col-6' : ' col-12'
              }`}>
              {isTherapyData &&
                <div className="col-12 px-0 font-weight-bold font-color-smoke-grey">
                  <div className="d-flex align-items-center justify-content-between">
                    <div>{strings.dailyTherapyAverage}</div>
                    <div>{getFormatedTime(totalAvgTherapy)}</div>
                  </div>
                </div>
              }

              {therapyData.TITAN !== undefined && !isEmpty(therapyData.TITAN.avg) &&
                <React.Fragment>
                  <div className="col-2 px-0">
                    <img
                      src={logoMap.TITAN}
                      width="32"
                      height="26"
                      className="d-inline-block ml-1"
                      alt="logo"
                    />
                  </div>
                  <div className="col-10 px-0">
                    <div className="d-flex align-items-center justify-content-between">
                      <div>{strings.dailyTherapyAverage}</div>
                      <div>{therapyData.TITAN.avg}</div>
                    </div>
                  </div>
                </React.Fragment>}

              {therapyData.MONARCH !== undefined && !isEmpty(therapyData.MONARCH.avg) &&
                <React.Fragment>
                  <div className="col-2 px-0">
                    <img
                      src={logoMap.MONARCH}
                      width="32"
                      height="26"
                      className="d-inline-block ml-1"
                      alt="logo"
                    />
                  </div>
                  <div className="col-10 px-0">
                    <div className="d-flex align-items-center justify-content-between">
                      <div>{strings.dailyTherapyAverage}</div>
                      <div>{therapyData.MONARCH.avg}</div>
                    </div>
                  </div>
                </React.Fragment>}

              {therapyData.VEST !== undefined && !isEmpty(therapyData.VEST.avg) &&
                <React.Fragment>
                  <div className="col-2 px-0">
                    {patientIsManualVest ?
                      <img
                        src={manualLogo}
                        className="d-inline-block ml-1"
                        alt={'Manual Device'}
                        style={{
                          height: "20px", width: "40px", marginTop: "10%"
                        }}
                      />
                      :
                      <img
                        src={logoMap.VEST}
                        width="32"
                        height="26"
                        className="d-inline-block ml-1"
                        alt="logo"
                      />
                    }
                  </div>
                  <div className="col-10 px-0">
                    <div className="d-flex align-items-center justify-content-between">
                      <div>{strings.dailyTherapyAverage}</div>
                      <div>{therapyData.VEST.avg}</div>
                    </div>
                  </div>
                </React.Fragment>}
            </div>
          }
          {(selectedOption === "all" || selectedOption === strings.spiro) &&
            <div className={`row ml-1${selectedOption === "all" && isTherapyData && isSpiroData ? ' col-6' : ' col-12'
              }`}>
              {isSpiroData && <React.Fragment>
                <div className="col-2 px-0 text-center mt-2">
                  <img
                    src={spiroLogo}
                    width="15"
                    height="20"
                    className="d-inline-block ml-1"
                    alt="logo"
                  />
                </div>
                <div className="col-10 px-0">
                  <div className="d-flex align-items-center justify-content-between" style={{ borderBottom: '1px solid #dce4f1' }}>
                    <div>FEV1% (PRED)</div>
                    <div></div>
                  </div>
                </div>
              </React.Fragment>}
              {hillromSpiroVal !== null &&
                <React.Fragment>
                  <div className="col-2 px-0"></div>
                  <div className="col-4 px-0 text-center">{moment.utc(hillromSpiroVal.testResultDate).format("MMM DD, YYYY")}</div>
                  <div className="col-2 px-0">{hillromSpiroVal.fev1_TO_FVC_RATIO.toFixed(2)}%</div>
                  <div className="col-4 px-0"><span className="home-test-dot"></span>{strings.hillromSpiro}</div>
                </React.Fragment>
              }
              {
                otherSpiroVal !== null &&
                <React.Fragment>
                  <div className="col-2 px-0"></div>
                  <div className="col-4 px-0 text-center">{moment.utc(otherSpiroVal.testResultDate).format("MMM DD, YYYY")}</div>
                  <div className="col-2 px-0">{otherSpiroVal.fev1_TO_FVC_RATIO.toFixed(2)}%</div>
                  <div className="col-4 px-0"><span className="clinic-test-dot"></span>{strings.otherSpiro}</div>
                </React.Fragment>
              }
            </div>}
        </div>
      </Card.Body>
    </Card>
  );
}

export function CustomTooltip(props) {
  const { data } = props;
  const { date, perDaySessions, deviceHMR: { TITAN, MONARCH, VEST } } = data;
  const { actualRole } = getUserData();
  const hmrInformation = accessMatrix.DAILY_HMR[actualRole];
  return (
    <Card
      style={{
        minWidth: '55rem',
        maxWidth: '55rem',
        maxHeight: '50rem',
        overflow: 'auto',
        boxShadow: 'rgba(0, 0, 0, 0.1) 0px 18px 24px 11px'
      }}
    >
      <Card.Body>
        <Card.Title>
          {moment(new Date(date)).format('MMM DD, Y')}
          <span
            className="float-right black-cross-small"
            onClick={() => hideCustomTooltip()}
            onKeyDown={() => hideCustomTooltip()}
            role="presentation"
          />
        </Card.Title>
        {
          hmrInformation.read ?
            <div className="row my-2 py-2 mx-0" style={{ borderBottom: '1px solid #dce4f1' }}>
              {
                TITAN ?
                  <div className="col-6 row">
                    <div className="col-2 px-0">
                      <img
                        src={logoMap.TITAN}
                        width="32"
                        height="32"
                        className="d-inline-block ml-1"
                        alt="logo"
                      />
                    </div>
                    <div className="col-10 px-0">
                      <div className="d-flex align-items-center justify-content-between" style={{ borderBottom: '1px solid #dce4f1' }}>
                        <div>HMR</div>
                        <div>{TITAN.hmr}</div>
                      </div>
                      <div className="d-flex align-items-center justify-content-between">
                        <div>Serial Number</div>
                        <div>{TITAN.serialNo}</div>
                      </div>
                    </div>
                  </div>
                  :
                  null
              }
              {
                MONARCH ?
                  <div className="col-6 row">
                    <div className="col-2 px-0">
                      <img
                        src={logoMap.MONARCH}
                        width="32"
                        height="32"
                        className="d-inline-block ml-1"
                        alt="logo"
                      />
                    </div>
                    <div className="col-10 px-0">
                      <div className="d-flex align-items-center justify-content-between" style={{ borderBottom: '1px solid #dce4f1' }}>
                        <div>HMR</div>
                        <div>{MONARCH.hmr}</div>
                      </div>
                      <div className="d-flex align-items-center justify-content-between">
                        <div>Serial Number</div>
                        <div>{MONARCH.serialNo}</div>
                      </div>
                    </div>
                  </div>
                  :
                  null
              }
              {
                VEST ?
                  <div className="col-6 row">
                    <div className="col-2 px-0">
                      {patientIsManualVest ?
                        <img
                          src={manualLogo}
                          className="d-inline-block ml-1"
                          alt={'Manual Device'}
                          style={{
                            height: "20px", width: "40px", marginTop: "10%"
                          }}
                        />
                        :
                        <img
                          src={logoMap.VEST}
                          width="32"
                          height="32"
                          className="d-inline-block ml-1"
                          alt="logo"
                        />
                      }

                    </div>
                    <div className="col-10 px-0">
                      <div className="d-flex align-items-center justify-content-between" style={{ borderBottom: '1px solid #dce4f1' }}>
                        <div>HMR</div>
                        <div>{VEST.hmr}</div>
                      </div>
                      <div className="d-flex align-items-center justify-content-between">
                        <div>Serial Number</div>
                        <div>{patientIsManualVest ? manualDeviceName : VEST.serialNo}</div>
                      </div>
                    </div>
                  </div>
                  :
                  null
              }
            </div>
            :
            null
        }
        <div className="row">{perDaySessionListItems(perDaySessions)}</div>
      </Card.Body>
    </Card>
  );
}

export const messageService = {
  sendMessage: (protocols, activeFromTo) => subject.next({ deviceGroups: protocols, activeFromTo: activeFromTo }),
  clearMessages: () => subject.next(),
  getMessage: () => subject.asObservable()
};

async function renderLineCustomTooltip(model, chart, from, to, selectedOption, therapyData, totalAvgTherapy) {
  const index = model.dataPoints[0].index;
  const isTherapyData = ((therapyData !== undefined && therapyData.VEST !== undefined
    && !isEmpty(therapyData.VEST.avg)) || (therapyData !== undefined && therapyData.MONARCH !== undefined &&
      !isEmpty(therapyData.MONARCH.avg)) || (therapyData !== undefined && therapyData.TITAN !== undefined &&
        !isEmpty(therapyData.TITAN.avg)))
  const isSpiroData = (Gdatasets_t[0][index] !== null) || (Gdatasets_t[1][index] !== null);

  let el = document.getElementById('CustomBarChart-tooltip');
  let caretEl = document.getElementById('CustomBarChart-caret');
  let tooltipEl = document.getElementById('CustomBarChart-tooltip-dialog');
  // Create element on first render
  if (!el) {
    el = document.createElement('div');
    el.id = 'CustomBarChart-tooltip';
    chart.canvas.parentNode.appendChild(el);
  }
  if (!tooltipEl) {
    tooltipEl = document.createElement('div');
    tooltipEl.id = 'CustomBarChart-tooltip-dialog';
    el.appendChild(tooltipEl);
  }
  if (!caretEl) {
    caretEl = document.createElement('div');
    caretEl.id = 'CustomBarChart-caret';
    el.appendChild(caretEl);
  }
  if (model.opacity === 0) {
    hideCustomTooltip(el, tooltipEl, caretEl);
    return;
  }
  el.style.display = 'block';
  tooltipEl.style.display = 'block';
  caretEl.style.display = 'block';
  if (model.body && isEmpty(model.body[0].lines)) {
    hideCustomTooltip(el, tooltipEl, caretEl);
    return;
  }
  if (window.innerWidth < 575) {
    return;
  }
  if (model.body && model.body[0].lines.length) {
    ReactDOM.render(
      <CustomLineTooltip data={{ from, to, selectedOption, model, therapyData, totalAvgTherapy }} />,
      tooltipEl
    );
    const position = chart.canvas.getBoundingClientRect();
    // Display, position, and set styles for font
    let offset = 0;
    const widthXen = position.width / 2;
    const increasePercent = (model.caretX / widthXen) * 100;

    let extraOffset = 60;
    let extraPaddingY = 55;
    let extraCaretOffset = 3;
    if (window.innerWidth > 1500) {
      extraOffset = 270;
      extraPaddingY = 85;
      extraCaretOffset = 4;
    }
    if (increasePercent > 135) {
      offset = extraOffset;
    }

    if (selectedOption === "all" && isTherapyData && isSpiroData) {
      extraOffset = 340;
      extraPaddingY = 55;
      extraCaretOffset = 4;
      if (window.innerWidth > 1500) {
        extraOffset = 450;
        extraPaddingY = 85;
        extraCaretOffset = 8;
      }
      if (increasePercent > 135) {
        offset = extraOffset;
      }
    }

    el.style.top = `${model.caretY - el.clientHeight + extraPaddingY}px`;
    el.style.opacity = 1;
    el.style.position = 'absolute';
    // el.style.pointerEvents = 'none';
    el.style.left = `${model.caretX - offset - position.left}px`;
    // el.style.left = `${model.caretX - position.left}px`;
    caretEl.setAttribute(
      'style',
      `position:absolute;
       bottom: -19px;
       left:${position.left + offset + extraCaretOffset}px;
       width:0;
       height:0;
       border-style:solid;
       border-color: rgba(136, 183, 213, 0);
       border-top-color:#fff;
       border-width: 10px;
       z-index: 1`
    );
  }
}

async function renderCustomTooltip(model, chart, sessions, date, deviceHMR) {
  if (!isEmpty(protocolList)) {
    activeProtocols = getProtocolList(protocolList, date, false);
    if (!isEmpty(activeProtocols)) {
      messageService.sendMessage(activeProtocols, activeFromTo);
    }
  }
  let el = document.getElementById('CustomBarChart-tooltip');
  let caretEl = document.getElementById('CustomBarChart-caret');
  let tooltipEl = document.getElementById('CustomBarChart-tooltip-dialog');
  // Create element on first render
  if (!el) {
    el = document.createElement('div');
    el.id = 'CustomBarChart-tooltip';
    chart.canvas.parentNode.appendChild(el);
  }
  if (!tooltipEl) {
    tooltipEl = document.createElement('div');
    tooltipEl.id = 'CustomBarChart-tooltip-dialog';
    el.appendChild(tooltipEl);
  }
  if (!caretEl) {
    caretEl = document.createElement('div');
    caretEl.id = 'CustomBarChart-caret';
    el.appendChild(caretEl);
  }
  if (model.opacity === 0) {
    hideCustomTooltip(el, tooltipEl, caretEl);
    return;
  }
  el.style.display = 'block';
  tooltipEl.style.display = 'block';
  caretEl.style.display = 'block';
  if (model.body && isEmpty(model.body[0].lines)) {
    hideCustomTooltip(el, tooltipEl, caretEl);
    return;
  }
  if (window.innerWidth < 575) {
    return;
  }
  if (model.body && model.body[0].lines.length) {
    ReactDOM.render(
      <CustomTooltip data={{ date, perDaySessions: sessions, deviceHMR }} />,
      tooltipEl
    );
    const position = chart.canvas.getBoundingClientRect();
    // Display, position, and set styles for font
    let offset = 0;
    const widthXen = position.width / 2;
    const increasePercent = (model.caretX / widthXen) * 100;
    let extraOffset = 340;
    let extraPaddingY = 55;
    let extraCaretOffset = 4;
    if (window.innerWidth > 1500) {
      extraOffset = 450;
      extraPaddingY = 85;
      extraCaretOffset = 8;
    }
    if (increasePercent > 135) {
      offset = extraOffset;
    }
    el.style.top = `${model.caretY - el.clientHeight + extraPaddingY}px`;
    el.style.opacity = 1;
    el.style.position = 'absolute';
    // el.style.pointerEvents = 'none';
    el.style.left = `${model.caretX - offset - position.left}px`;
    caretEl.setAttribute(
      'style',
      `position:absolute;
       bottom: -19px;
       left:${position.left + offset + extraCaretOffset}px;
       width:0;
       height:0;
       border-style:solid;
       border-color: rgba(136, 183, 213, 0);
       border-top-color:#fff;
       border-width: 10px;
       z-index: 1`
    );
  }
}

export const barTooltipEl = (chart, model, patientID) => {
  renderCustomTooltip(model, chart, patientID);
};

export const lineTooltipEl = (chart, model, selectedOption) => {
  var from = xSiproLabels[model.dataPoints[0].index];
  var to = moment(from).add(6, 'days');
  var totalAvgTherapy = 0;
  var therapyData = {};

  if (selectedOption === "all" || selectedOption === strings.therapy) {
    var filteredTherapyData = therapyDataG.filter(e => moment(e.date) >= from && moment(e.date) <= to);
    var groupedTherapyData = groupBy(filteredTherapyData, 'deviceType');
    if (groupedTherapyData.MONARCH !== undefined) {
      therapyData["MONARCH"] = {};
      let avgVal = getAvgTherapyTime(groupedTherapyData.MONARCH);
      therapyData["MONARCH"]["avg"] = getFormatedTime(avgVal);
      totalAvgTherapy = +totalAvgTherapy + +avgVal;
    }
    if (groupedTherapyData.TITAN !== undefined) {
      therapyData["TITAN"] = {};
      let avgVal = getAvgTherapyTime(groupedTherapyData.TITAN);
      therapyData["TITAN"]["avg"] = getFormatedTime(avgVal);
      totalAvgTherapy = +totalAvgTherapy + +avgVal;
    }
    if (groupedTherapyData.VEST !== undefined) {
      therapyData["VEST"] = {};
      let avgVal = getAvgTherapyTime(groupedTherapyData.VEST)
      therapyData["VEST"]["avg"] = getFormatedTime(avgVal);
      totalAvgTherapy = +totalAvgTherapy + +avgVal;
    }
  }
  renderLineCustomTooltip(model, chart, from, to, selectedOption, therapyData, totalAvgTherapy);
};

const getAvgTherapyTime = (data) => {
  let sumTherapy = data.reduce((prev, next) => prev + next.duration, 0);
  let avgTherapyVal = (sumTherapy / 7).toFixed(0);
  return avgTherapyVal;
}

const getFormatedTime = (data) => {
  // let hours = Math.floor(data / 60);
  // let minutes = data % 60;
  // return (hours > 0 ? hours + " Hrs " : "") + (minutes > 0 ? minutes + " Mins" : "");
  return data > 0 ? data + " Mins" : "";
}

const barEnhancedTooltipEl = (chart, model, dayTherapy, date) => {
  let { sessions } = dayTherapy;
  sessions = sessions && sessions.sort((s1, s2) => {
    const day = moment().format('YYYY-MM-DD');
    const t1 = s1.therapyEvents && s1.therapyEvents[0] && s1.therapyEvents[0]['time'];
    const t2 = s2.therapyEvents && s2.therapyEvents[0] && s2.therapyEvents[0]['time'];
    if (t1 && t2) {
      const t1Time = moment(`${day} ${t1}`).valueOf();
      const t2Time = moment(`${day} ${t2}`).valueOf();
      return t1Time < t2Time ? -1 : 1;
    } else {
      return t1 ? -1 : (t2 ? 1 : 0);
    }
  });
  renderCustomTooltip(model, chart, sessions, date, dayTherapy);
}

export const getBarData = (
  graphSet,
  patient,
  isBlackAndWhite,
  callForPdfBar
) => {
  const barColor =
    isBlackAndWhite && callForPdfBar
      ? {
        MONARCH: '#000',
        VEST: pattern.draw('diagonal-right-left', '#dbdbdb', '#000000', 4)
      }
      : { TITAN: '#5369E5', MONARCH: '#f26222', VEST: '#659fd5' };
  // Color definitions for the black and white version required for PDF.
  const graphDataset = [];
  forEach(graphSet.graphData, (data, dType) => {
    const retval = {
      label: dType,
      backgroundColor: barColor[dType],
      data: data.dataSet,
      borderWidth: 0,
      // Definitions required for the black and white version for PDF.
      // borderWidth: 1,
      borderColor: '#000'
    };
    graphDataset.push(retval);
  });
  const flatGraphSet = flatMap(graphDataset, 'data');
  const averageLine = sum(flatGraphSet) / flatGraphSet.length;
  let labels = [];
  if (!isEmpty(graphSet.graphData)) {
    labels = chain(graphSet.graphData)
      .flatMap()
      .head()
      .value().dates;
  }
  const retval = {
    data: {
      labels,
      datasets: graphDataset
    },
    options: {
      events: ['click'],
      animation: callForPdfBar
        ? false
        : {
          duration: 250 * 1.5,
          easing: 'linear'
        },
      legend: {
        position: 'top',
        align: 'right',
        labels: {
          boxWidth: 6,
          fontSize: 11,
          padding: 15,
          fontStyle: 'bold',
          usePointStyle: true,
        },
        onClick: e => e.stopPropagation() // Disable click action on the legend.
      },
      cornerRadius: 10,
      tooltips: {
        // Disable the on-canvas tooltip
        enabled: false,
        intersect: false,
        mode: 'index',
        callbacks: {
          label(tooltipItem, data) {
            return data.labels[tooltipItem.index];
          }
        },
        position: 'custom',
        custom(tooltipModel) {
          barTooltipEl(this._chart, tooltipModel, patient.id);
        }
      },
      scales: {
        xAxes: [
          {
            stacked: true,
            barPercentage: 0.5,
            barThickness: 10,
            maxBarThickness: 10,
            gridLines: { drawBorder: false, display: false },
            ticks: {
              beginAtZero: true,
              callback(value) {
                const date = new Date(value);
                return date.getDate();
              }
            }
          }
        ],
        yAxes: [
          {
            stacked: true,
            gridLines: { drawBorder: false, display: false },
            ticks: {
              suggestedMin: 25,
              stepSize: 25,
              suggestedMax: 100,
              beginAtZero: true,
              callback(value) {
                return value;
              }
            }
          }
        ]
      },
      elements: {
        point: {
          radius: 40,
          hoverRadius: 40,
          pointStyle: 'rectRounded'
        }
      },
      annotation: {
        annotations: [
          {
            id: 'a-line-1',
            type: 'line',
            mode: 'horizontal',
            drawTime: 'afterDatasetsDraw',
            scaleID: 'y-axis-0',
            borderDash: [2, 2],
            borderDashOffset: 5,
            value: averageLine,
            endValue: averageLine,
            borderColor: '#e3ebf6',
            borderWidth: 1
          }
        ]
      }
    }
  };
  return retval;
};

export const getMinandMAxfromTheraphyData = therapies => {
  const fromDates = [];
  const toDates = [];
  const deviceDates = {};
  forEach(therapies, (d, dType) => {
    if (d.xAxis) {
      const start = new Date(head(d.xAxis.categories));
      const end = new Date(last(d.xAxis.categories));
      deviceDates[dType] = {
        dates: [start, end],
        dayCount: dateDiffInDays(start, end)
      };
      fromDates.push(start);
      toDates.push(end);
    }
  });
  const minDate = new Date(Math.min.apply(null, fromDates));
  const maxDate = new Date(Math.max.apply(null, toDates));
  const dayCountdifference = dateDiffInDays(minDate, maxDate);
  const retval = {
    min: minDate,
    max: maxDate,
    deviceDates,
    dayCount: dayCountdifference
  };
  return retval;
};

export const getTherapyGraphData = (dateGroupedData, dates) => {
  const durationValues = mapValues(dateGroupedData, dateSet => {
    return sumBy(dateSet, 'toolText.duration');
  });
  const durationSet = {};
  forEach(dates, date => {
    if (isNil(durationValues[date])) {
      durationSet[date] = 0;
    } else {
      durationSet[date] = durationValues[date];
    }
  });
  const dataSet = values(durationSet);
  return { dates, dataSet };
};

export const getTherapySesssionMinutes = params => {
  const { therapies, deviceMinutesSet, minMaxTheraphySet } = params;
  const minutesSet = deviceMinutesSet;
  const minMaxDates = minMaxTheraphySet;
  const smSet = {
    session: {},
    minute: {}
  };
  const smGraphSet = {};
  smGraphSet.graphData = {};
  smGraphSet.dateGroupData = {};
  const dates = getBetweenDates(
    minMaxDates.min,
    minMaxDates.max,
    constants._MS_PER_DAY
  );
  forEach(therapies, (therapy, dType) => {
    let sessionDone = 0;
    let totalSession = 0;
    let minutesDone = 0;
    if (!isEmpty(therapy)) {
      const dateGroupedData = groupBy(therapy.series[0].data, v => {
        return v.x.split(' ')[0];
      });
      forEach(dateGroupedData, daySet => {
        const daySorted = sortBy(daySet, 'x');
        const sessionArr = last(daySorted).toolText.sessionNo.split('/');
        sessionDone += parseInt(sessionArr[0], 10);
        totalSession += parseInt(sessionArr[1], 10);
      });
      minutesDone = sumBy(therapy.series[0].data, 'toolText.duration');
      const sessionDonePercentageTotal = parseInt(
        (sessionDone / totalSession) * 100,
        10
      );
      smSet.session[dType] = {
        sessionDone,
        totalSession,
        missedSession: totalSession - sessionDone,
        sessionDonePercentage:
          sessionDonePercentageTotal < 100 ? sessionDonePercentageTotal : 100
      };
      let minutesDonePercentageTotal = 0;
      if (minutesSet[dType]) {
        minutesDonePercentageTotal = parseInt(
          (minutesDone / minutesSet[dType].minutes) * 100,
          10
        );
      }
      smSet.minute[dType] = {
        minutesDone,
        totalMinutes: minutesSet[dType] ? minutesSet[dType].minutes : 0,
        missedMinutes: minutesSet[dType]
          ? minutesSet[dType].minutes - minutesDone
          : 0,
        minutesDonePercentage:
          minutesDonePercentageTotal < 100 ? minutesDonePercentageTotal : 100,

        avgMinutes: minutesDone / size(therapy.series[0].data)
      };
      const smSessionSet = chain(smSet.session).values();
      smSet.session.sessionDone = smSessionSet.sumBy('sessionDone').value();
      smSet.session.totalSession = smSessionSet.sumBy('totalSession').value();
      smSet.session.missedSession = smSessionSet.sumBy('missedSession').value();
      const sessionDonePercentage = parseInt(
        (smSet.session.sessionDone / smSet.session.totalSession) * 100,
        10
      );
      smSet.session.sessionDonePercentage =
        sessionDonePercentage < 100 ? sessionDonePercentage : 100;
      const smMinuteSet = chain(smSet.minute).values();
      smSet.minute.minutesDone = smMinuteSet.sumBy('minutesDone').value();
      smSet.minute.totalMinutes = smMinuteSet.sumBy('totalMinutes').value();
      smSet.minute.missedMinutes = smMinuteSet.sumBy('missedMinutes').value();
      const minutesDonePercentage = parseInt(
        (smSet.minute.minutesDone / smSet.minute.totalMinutes) * 100,
        10
      );
      smSet.minute.minutesDonePercentage =
        minutesDonePercentage < 100 ? minutesDonePercentage : 100;
      smGraphSet.graphData[dType] = getTherapyGraphData(dateGroupedData, dates);
      smGraphSet.dateGroupData[dType] = dateGroupedData;
    }
  });
  return { smSet, smGraphSet, dates };
};

export const getAdherenceScore = adherence => {
  let previousAdherenceScore = 0;
  let latestAdherenceScore = 0;
  let scoreChange = 0;
  if (adherence.series) {
    const adherenceData = adherence.series[0].data;
    const lastIdx = findLastIndex(adherenceData);
    if (lastIdx === -1) {
      return {};
    }
    latestAdherenceScore = adherenceData[lastIdx].y;
    if (lastIdx - 1 !== -1) {
      previousAdherenceScore = adherenceData[lastIdx - 1].y;
    }
    scoreChange = latestAdherenceScore - previousAdherenceScore;
  }
  return { latestAdherenceScore, previousAdherenceScore, scoreChange };
};

export const sanitizeDates = (therapies, patientTz) => {
  return mapValues(therapies, (d, dType) => {
    const offSet = dType === 'VEST' ? '-06:00' : '+00:00';
    // default timezone: EST (UTC-5:00)
    // default timezone: America/New_York
    const defaultTimezone = 'America/New_York';
    const timezone = patientTz ? patientTz.split('#')[0] : defaultTimezone;
    return mapValues(d, (v, k) => {
      if (k === 'xAxis') {
        return {
          type: 'datetime',
          categories: without(
            map(v.categories, date => {
              const momentDate = moment(`${date}${offSet}`, 'L hh:mm:ssZ');
              const momentDateAfterTz = momentDate
                .clone()
                .tz(timezone)
                .format('L hh:mm:ss');
              if (!momentDate.isSame(momentDateAfterTz, 'month')) {
                return null;
              }
              return momentDateAfterTz;
            }),
            null
          )
        };
      }
      return [
        {
          name: v[0].name,
          data: without(
            map(v[0].data, dateSet => {
              const momentDate = moment(
                `${dateSet.x}${offSet}`,
                'L (hh:mm A)Z'
              );
              const momentDateAfterTz = momentDate
                .clone()
                .tz(timezone)
                .format('L (hh:mm A)');
              if (!momentDate.isSame(momentDateAfterTz, 'month')) {
                return null;
              }
              return {
                x: momentDateAfterTz,
                y: dateSet.y,
                toolText: dateSet.toolText
              };
            }),
            null
          )
        }
      ];
    });
  });
};

const getProtocolList = (protocols, date, isMonthClick) => {
  let deviceProtocolList = groupBy(protocols, 'deviceType');
  let points = []
  let finalProtcol = {};
  activeFromTo = {};
  let fromDate = null;
  let toDate = null;
  let isProtocolChange = false;
  if (!isEmpty(deviceProtocolList)) {
    Object.keys(deviceProtocolList)
      .map(dType => {
        if (deviceProtocolList[dType] && deviceProtocolList[dType].length) {
          Object.keys(deviceProtocolList[dType]).map(dPoint => {
            points = [];
            fromDate = null;
            toDate = null;
            isProtocolChange = false;
            let filteredProtocol = getFilteredProtocol(deviceProtocolList[dType][dPoint].protocolList, date);
            if (filteredProtocol !== undefined) {
              fromDate = filteredProtocol.from;
              if (!filteredProtocol.isActive) toDate = filteredProtocol.to;
              (filteredProtocol.points).map(point => {
                return points.push(point);
              })
            }

            if (isMonthClick) {
              let monthRangeFilteredProtocol = (deviceProtocolList[dType][dPoint].protocolList).filter(e => (moment(date).isSame(e.from, 'month') ||
                (!e.isActive && moment(date).isSame(e.to, 'month'))))
              monthRangeFilteredProtocol.length >= 1 ? isProtocolChange = true : isProtocolChange = false;
            }

            if (points.length === 0) {
              points.push(deviceProtocolList[dType][dPoint].defaultProtocol[0]);
              let sortedProtocols = deviceProtocolList[dType][dPoint].protocolList.sort((a, b) => a.from > b.from ? 1 : -1)
              for (let i = 0; i < sortedProtocols.length; i++) {
                if (i === 0) {
                  if (date <= sortedProtocols[i].from) {
                    fromDate = patientFirstTrans
                    toDate = moment(sortedProtocols[i].from).subtract(1, 'days')
                    break;
                  }
                }
                if (i === sortedProtocols.length - 1) {
                  if (date >= sortedProtocols[i].to) {
                    fromDate = moment(sortedProtocols[i].to).add(1, 'days')
                    break;
                  }
                }
                if (i + 1 < sortedProtocols.length) {
                  if (date >= sortedProtocols[i].to && date <= sortedProtocols[i + 1].from) {
                    fromDate = moment(sortedProtocols[i].to).add(1, 'days');
                    toDate = moment(sortedProtocols[i + 1].from).subtract(1, 'days');
                    break;
                  }
                }
              }
            }
          })
        }
        finalProtcol[dType] = points;
        activeFromTo[dType] = { from: fromDate, to: toDate, isProtocolChange: isProtocolChange };
        return null;
      })
  }
  return finalProtcol;
}

export const getFilteredProtocol = (protocols, date) => {
  protocols.sort((a, b) => a.to < b.to ? 1 : -1);
  for (let i = 0; i < protocols.length; i++) {
    if (moment(date).isSameOrAfter(protocols[i].from, 'day') && (protocols[i].isActive || moment(date).isSameOrBefore(protocols[i].to, 'day'))) {
      return protocols[i];
    }
  }
}

export const saveMonthChange = month => {
  monthChange = month;
}

export const getEnhancedScoreData = (
  date,
  allProtocols,
  therapyInformation,
  patientUser,
  isBlackAndWhite,
  callForPdfBar
) => {
  if (!isEmpty(allProtocols) && therapyInformation && !isEmpty(patientUser)) {
    patientFirstTrans = patientUser.firstTrans;
    patientIsManualVest = patientUser.isManual;
    manualDeviceName = patientUser.deviceName;
    protocolList = allProtocols;
    const { therapyData, protocolDuration } = therapyInformation;
    const barChart = getEnhancedBarData({ date, therapyData, protocolDuration, isBlackAndWhite, callForPdfBar, firstTrans: patientUser.firstTrans, vestDeviceName: patientUser.isManual ? patientUser.deviceName : null });
    const sessionTable = getEnhancedTableData({ therapyData, protocolDuration });
    const deviceGroups = activeProtocols;
    return {
      deviceGroups,
      barChart,
      sessionTable
    };
  }
  return {};
}

const getEnhancedTableData = ({ therapyData, protocolDuration }) => {
  const dateGroupData = groupBy(therapyData, 'date');
  const dates = orderBy(Object.keys(dateGroupData), date => {
    return moment(date).format('YYYYMMDD')
  }, ['desc']);
  return {
    dates,
    dateGroupData,
    protocolDuration
  }
};

const getEnhancedBarData = ({ date, therapyData, protocolDuration, isBlackAndWhite, callForPdfBar, firstTrans, vestDeviceName }) => {
  const momentDate = moment(date);
  const momentToday = moment();
  const momentMonthEnd = moment(momentDate.endOf('month').format('YYYY-MM-DD'));
  let queryDate = momentMonthEnd;
  if (momentToday <= momentMonthEnd) {
    queryDate = momentToday;
  }
  if (monthChange === null || moment(monthChange).isSame(moment(date), 'month')) {
    if (!isEmpty(protocolList)) {
      activeProtocols = getProtocolList(protocolList, queryDate, true);
    }
    messageService.sendMessage(null, activeFromTo);
    monthChange = null;
  }
  const endDayOfMonth = Number(momentDate.endOf('month').format('D'));
  const barColor = isBlackAndWhite && callForPdfBar
    ? {
      MONARCH: '#000',
      TITAN: '#000',
      VEST: pattern.draw('diagonal-right-left', '#dbdbdb', '#000000', 4)
    }
    : { TITAN: '#5369E5', MONARCH: '#f26222', VEST: '#659fd5', };
  // label for chart
  const labels = range(1, endDayOfMonth + 1);

  // reds for red circle over ticks of x axis
  const reds = Array(endDayOfMonth).fill(true);
  const monthlySessions = Array(endDayOfMonth).fill({ sessions: [] });

  // set the reds for future dates to false

  const momentStart = moment.utc(firstTrans);
  if (momentToday.format('MM-YYYY') === momentDate.format('MM-YYYY')) {
    const today = momentToday.format('D') - 1;
    for (let i = today + 1; i < endDayOfMonth; i++) {
      reds[i] = null;
    }
  }
  if (momentStart.format('MM-YYYY') === momentDate.format('MM-YYYY')) {
    const startDayOfTransmission = momentStart.format('D') - 1;
    for (let i = 0; i < startDayOfTransmission; i++) {
      reds[i] = null;
    }
  }
  // deviceType wise data map
  const deviceTypeData = groupBy(therapyData, 'deviceType');
  const datasets = [];
  let sumArray;
  if (deviceTypeData.TITAN) {
    let protocolActiveLable = (activeFromTo["TITAN"] !== undefined && activeFromTo["TITAN"].isProtocolChange)
      ? " (Protocol changed)" : "";
    const titan = {
      backgroundColor: barColor.TITAN,
      border: '#000',
      borderWidth: 0,
      label: strings.titan + protocolActiveLable
    };
    titan.data = getDuration(deviceTypeData.TITAN, endDayOfMonth, reds, monthlySessions, protocolDuration);
    datasets.push(titan);
    sumArray = titan.data;
  }

  if (deviceTypeData.MONARCH) {
    let protocolActiveLable = (activeFromTo["MONARCH"] !== undefined && activeFromTo["MONARCH"].isProtocolChange)
      ? " (Protocol changed)" : "";
    const monarch = {
      backgroundColor: barColor.MONARCH,
      border: '#000',
      borderWidth: 0,
      label: strings.monarch + protocolActiveLable
    };
    monarch.data = getDuration(deviceTypeData.MONARCH, endDayOfMonth, reds, monthlySessions, protocolDuration);
    datasets.push(monarch);
    sumArray = monarch.data;
  }
  if (deviceTypeData.VEST) {
    let protocolActiveLable = (activeFromTo["VEST"] !== undefined && activeFromTo["VEST"].isProtocolChange)
      ? " (Protocol changed)" : "";
    const vest = {
      backgroundColor: barColor.VEST,
      border: '#000',
      borderWidth: 0,
      label: vestDeviceName != null ? (vestDeviceName + protocolActiveLable) : (strings.vest + protocolActiveLable)
    };
    vest.data = getDuration(deviceTypeData.VEST, endDayOfMonth, reds, monthlySessions, protocolDuration);
    datasets.push(vest);
    if (sumArray) {
      sumArray = sumArray.map((d, i) => {
        return d + vest.data[i];
      });
    }
  }

  if (!(deviceTypeData.VEST || deviceTypeData.MONARCH || deviceTypeData.TITAN)) {
    const device = {
      backgroundColor: '#fff',
      border: '#fff',
      borderWidth: 0,
      label: ''
    };

    device.data = Array(endDayOfMonth).fill(0);
    datasets.push(device);
  }

  const suggestedMax = getMaxDurationLimit(sumArray);
  const options = {
    events: ['click'],
    animation: callForPdfBar
      ? false
      : {
        duration: 250 * 1.5,
        easing: 'linear'
      },
    legend: {
      position: 'top',
      fullWidth: true,
      labels: {
        boxWidth: 6,
        fontSize: 11,
        padding: 15,
        fontStyle: 'bold',
        usePointStyle: true,
      },
      onClick: e => e.stopPropagation() // Disable click action on the legend.
    },
    cornerRadius: 10,
    tooltips: {
      // Disable the on-canvas tooltip
      enabled: false,
      intersect: false,
      mode: 'index',
      callbacks: {
        label(tooltipItem, data) {
          return data.labels[tooltipItem.index];
        }
      },
      position: 'custom',
      custom(tooltipModel) {
        const day = tooltipModel.body[0].lines[0];
        const cloneDate = momentDate.clone(momentDate);
        const date = cloneDate.set('date', day);
        reds[day - 1] !== null && barEnhancedTooltipEl(this._chart, tooltipModel, monthlySessions[day - 1], date);
      }
    },
    reds,
    scales: {
      xAxes: [
        {
          stacked: true,
          barPercentage: 0.5,
          barThickness: 10,
          maxBarThickness: 10,
          gridLines: { drawBorder: false, display: false },
          ticks: {
            beginAtZero: true,
            fontColor: reds.map(red => {
              return red ? (isBlackAndWhite && callForPdfBar ? '#000' : '#FC2E2E') : null
            }),
            fontFamily: "Sailec",
            callback(value) {
              return value;
            }
          }
        }
      ],
      yAxes: [
        {
          stacked: true,
          fontFamily: "Sailec",
          gridLines: { drawBorder: false, display: false },
          ticks: {
            suggestedMin: 50,
            stepSize: 50,
            suggestedMax: suggestedMax,
            beginAtZero: true,
            callback(value) {
              return value;
            }
          }
        }
      ]
    },
    elements: {
      point: {
        radius: 40,
        hoverRadius: 40,
        pointStyle: 'rectRounded'
      }
    },
    annotation: {
      annotations: [
        {
          id: 'a-line-1',
          type: 'line',
          mode: 'horizontal',
          drawTime: 'beforeDatasetsDraw',
          scaleID: 'y-axis-0',
          borderDash: [2, 2],
          borderDashOffset: 5,
          value: protocolDuration,
          borderColor: '#e3ebf6',
          borderWidth: 2
        }
      ]
    }
  }

  return {
    data: {
      datasets,
      labels
    },
    options
  };
}

const getDuration = (sessions, lastDay, reds, sessionsPerDay, protocolDuration) => {
  const days = Array(lastDay).fill(0);
  forEach(sessions, ({ date, duration, isCompliant, protocolSession, deviceType, hmr, serialNo }) => {
    const dateObj = moment(date);
    const day = dateObj.format('D') - 1;
    if (duration >= 0) {
      days[day] += duration;
      if (protocolSession) {
        sessionsPerDay[day] = { ...sessionsPerDay[day], sessions: [...sessionsPerDay[day].sessions, ...(protocolSession.sessions || [])] };
      }
    }
    sessionsPerDay[day] = { ...sessionsPerDay[day], [deviceType]: { hmr, serialNo } };
    reds[day] = !isCompliant;
  });
  days.forEach((duration, day) => {
    reds[day] = duration < protocolDuration && reds[day] !== null ? true : reds[day];
  });
  return days;
}

const getMaxDurationLimit = (list) => {
  const min = 100;
  const maxDuration = max(list);
  if (maxDuration > min) {
    const a = Math.floor(maxDuration / 25), b = maxDuration % 25;
    if (b > 0) {
      return (a + 1) * 25
    } else {
      return maxDuration;
    }
  } else {
    return min;
  }
}

export const getScoreData = (
  protocols,
  therapyData,
  patient,
  patientUser,
  isBlackAndWhite,
  callForPdfBar
) => {
  if (!isEmpty(protocols) && !isEmpty(therapyData) && !isEmpty(patientUser)) {
    const protocol = {};
    const patientUserTz = patientUser.userPreferenceTimezone;
    // Enable chart even with one device.
    const emptyKey = findKey(therapyData, o => {
      return !o;
    });
    let therapyGraphData = { ...therapyData };
    let deviceGroups = groupBy(protocols, 'deviceType');
    if (emptyKey) {
      deviceGroups = omit(deviceGroups, emptyKey);
      therapyGraphData = omit(therapyGraphData, emptyKey);
    }
    forEach(deviceGroups, deviceGrp => {
      // Pulling minimum duration from the entire protocol list including
      // both Normal and Custom and multiply that with the number of days.
      const device = maxBy(deviceGrp, 'minMinutesPerTreatment');
      protocol[device.deviceType] = device;
    });
    const deviceMinutesSet = {};
    const therapies = sanitizeDates(therapyGraphData, patientUserTz);

    const minMaxTheraphySet = getMinandMAxfromTheraphyData(therapies);
    forEach(protocol, (p, dType) => {
      if (minMaxTheraphySet.deviceDates[dType]) {
        deviceMinutesSet[dType] = {
          minutesPerday: p.minMinutesPerTreatment * p.treatmentsPerDay,
          dayCount: minMaxTheraphySet.deviceDates[dType].dayCount,
          minutes:
            p.minMinutesPerTreatment *
            p.treatmentsPerDay *
            minMaxTheraphySet.deviceDates[dType].dayCount
        };
      }
    });
    const sessionMinuteSet = getTherapySesssionMinutes({
      therapies,
      deviceMinutesSet,
      minMaxTheraphySet
    });
    sessionMinuteSet.barChart = getBarData(
      sessionMinuteSet.smGraphSet,
      patient,
      isBlackAndWhite,
      callForPdfBar
    );
    sessionMinuteSet.deviceGroups = deviceGroups;
    return sessionMinuteSet;
  }
  return {};
};

export const spiroSpan = (month, idx) => {
  let highestSpiro = 0;
  var highestSpiroArray = [];
  var weeklyAvgTherapy = 0;
  var therapySpans = [];
  var noOfWeeks = 0;
  var monthlyAvgTherapy = 0;

  let tmonthStart = moment(month).startOf('month').day('Sunday');
  let nextMonth = moment(month).add(1, 'month');

  let tmonthEnd = moment(nextMonth).startOf('month').day('Sunday');
  tmonthEnd = moment(tmonthEnd).subtract(1, 'day');
  if (idx === 0) {
    tmonthEnd = moment(nextMonth).startOf('month').day('Sunday');
    tmonthEnd = moment(tmonthEnd).add(6, 'days');
  }

  var spiroFiltered = [];

  spiroFiltered = spiroDataG.filter(e => moment(e.testResultDate) >= tmonthStart
    && moment(e.testResultDate) <= tmonthEnd && e.fev1_TO_FVC_RATIO > 0);
  var filteredTherapyData = therapyDataG.filter(e => moment(e.date) >= tmonthStart && moment(e.date) <= tmonthEnd);

  while (tmonthEnd > tmonthStart) {
    var weeklyTherapyData = filteredTherapyData.filter(e => moment(e.date) <= tmonthEnd && moment(e.date) >= moment(moment(tmonthEnd).subtract(6, 'days')));
    var totalAvgTherapy = 0;
    var groupedTherapyData = groupBy(weeklyTherapyData, 'deviceType');
    if (groupedTherapyData.MONARCH !== undefined) {
      let avgVal = getAvgTherapyTime(groupedTherapyData.MONARCH);
      totalAvgTherapy = +totalAvgTherapy + +avgVal;
    }
    if (groupedTherapyData.VEST !== undefined) {
      let avgVal = getAvgTherapyTime(groupedTherapyData.VEST)
      totalAvgTherapy = +totalAvgTherapy + +avgVal;
    }
    // var sumTherapy = weeklyTherapyData.reduce((prev, next) => prev + next.duration, 0);
    // weeklyAvgTherapy += (sumTherapy / 7);
    weeklyAvgTherapy += totalAvgTherapy;
    if (totalAvgTherapy > 0) {
      therapySpans.push(<div className="align-middle mt-2">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-5 text-left font-size-11">
            {moment(moment(tmonthEnd).subtract(6, 'days')).format('MMM DD')} -
            {moment(moment(tmonthEnd).subtract(6, 'days')).isSame(month, 'month') ? moment(tmonthEnd).format('DD')
              : moment(tmonthEnd).format('MMM DD')}
          </div>
          <div className="col-md-4 therapy-avg-style">
            <div className="font-size-11">{totalAvgTherapy} Mins</div>
          </div>
        </div>
      </div>);
    }
    noOfWeeks++;
    tmonthEnd = moment(tmonthEnd).subtract(7, 'days');
  }
  monthlyAvgTherapy = (weeklyAvgTherapy / noOfWeeks).toFixed(0);

  spiroFiltered.sort(function (a, b) {
    var keyA = moment(a.testResultDate),
      keyB = moment(b.testResultDate);
    if (keyA > keyB) return -1;
    if (keyA < keyB) return 1;
    return 0;
  });
  var dayWiseSipro = groupBy(spiroFiltered, 'testResultDate');
  const spiroVal = Object.keys(dayWiseSipro)
    .map(key => {
      var spiro = (dayWiseSipro[key]).reduce((p, n) => (p.fev1_TO_FVC_RATIO > n.fev1_TO_FVC_RATIO) ? p : n);
      highestSpiroArray.push(spiro)
      return (<div className="align-middle mt-2">
        <div className="row text-left">
          <div className="col-md-4 font-size-11 px-0">{moment.utc(spiro.testResultDate).format('MMM DD, YYYY')}</div>
          <div className="col-md-3 font-size-11 font-weight-bold px-0">{(spiro.fev1_TO_FVC_RATIO).toFixed(2)}%</div>
          <div className="col-md-5 px-0" style={{ marginTop: '-1px' }}>
            {spiro.type === "SPIRO" ?
              <span className="font-size-10"><span className="home-test-dot"></span>{strings.hillromSpiro}</span>
              :
              <span className="font-size-10"><span className="clinic-test-dot"></span>{strings.otherSpiro}</span>}
          </div>
        </div>
      </div>)
    });
  highestSpiro = highestSpiroArray.length > 0 ? highestSpiroArray[0].fev1_TO_FVC_RATIO !== undefined ?
    (highestSpiroArray[0].fev1_TO_FVC_RATIO).toFixed(2) : 0
    : highestSpiro;
  return { monthlyAvgTherapy: monthlyAvgTherapy, therapySpans: therapySpans, highestSpiro: highestSpiro, spiroSpans: spiroVal };
}

export const therapySpan = (dateGroupData, date, protocolDuration, deviceRef) => {
  let totalDuration = 0;
  const daySessions = dateGroupData[date];
  let deviated = true;
  // var spiroFiltered = spiroDataG.filter(e => moment(e.testResultDate).format("YYYY-MM-DD") === date);
  // const spiroVal = spiroFiltered.map(spiro => {
  //   return (<span className="device-session">
  //     <img
  //       src={spiroLogo}
  //       width="15"
  //       height="15"
  //       className="d-inline-block device-logo"
  //       alt="Spiro Logo"
  //     />
  //     <span className="align-middle">
  //       {spiro.fev1_TO_FVC_RATIO}%
  //         {spiro.type === "SPIRO" ?
  //         <div><span className="home-test-dot"></span>{strings.hillromSpiro}</div>
  //         :
  //         <div><span className="clinic-test-dot"></span>{strings.otherSpiro}</div>}
  //     </span>
  //   </span>)
  // });
  const retval = map(daySessions, (daySession) => {
    const { deviceType, duration, dateTime, isCompliant } = daySession;
    if (duration >= 0) {
      totalDuration += duration;
    }
    deviated = !isCompliant && deviated;
    return duration >= 0 && dateTime ? (
      <span key={uid(date, dateTime)} className="device-session">
        {deviceRef[deviceType][0] === strings.vest && patientIsManualVest ?
          <img
            src={manualLogo}
            width="40"
            height="20"
            className="d-inline-block device-logo"
            alt={'Manual Device'}
          />
          :
          <img
            src={deviceRef[deviceType][1]}
            width="28"
            height="28"
            className="d-inline-block device-logo"
            alt={deviceRef[deviceType][0]}
          />
        }
        <span className="align-middle">
          {getFormattedTime(dateTime)} - {`${duration} m`}
        </span>
      </span>
    ) : null;
  });
  return { duration: totalDuration, spans: retval, deviated: totalDuration < protocolDuration ? true : deviated };
};

export const protocolTable = (deviceGroups, dType, patient) => {
  const isManualVest = (dType === 'VEST' && patient.isManual) ? true : false;
  return (
    <table className="table text-center">
      <thead>
        <tr>
          <th scope="col">
            <span className="d-none d-sm-inline">{strings.program}</span>
            <span className="d-inline d-sm-none">{strings.prog}</span>
          </th>
          <th scope="col">
            <span className="d-none d-sm-inline">{strings.sessions}</span>
            <span className="d-inline d-sm-none">{strings.sess}</span>
          </th>
          <th scope="col">
            <span className="d-none d-sm-inline">{strings.duration}</span>
            <span className="d-inline d-sm-none">{strings.dura}</span>
          </th>
          <th scope="col">
            <span className="d-none d-sm-inline">{strings.frequency}</span>
            <span className="d-inline d-sm-none">{strings.freq}</span>
          </th>

          {dType === 'TITAN' || dType === 'MONARCH' ?
            <th scope="col">
              <span className="d-none d-sm-inline">{strings.intensity}</span>
              <span className="d-inline d-sm-none">{strings.ints}</span>
            </th> :
            <th scope="col">
              <span className="d-none d-sm-inline">{strings.pressure}</span>
              <span className="d-inline d-sm-none">{strings.pres}</span>
            </th>
          }
        </tr>
      </thead>
      <tbody>
        {deviceGroups[dType] && deviceGroups[dType].length ? (
          deviceGroups[dType].map((dPoint, idx) => (
            <tr key={uid(dPoint.id)}>
              <td>{idx + 1}</td>
              {idx === 0 && (
                <td
                  rowSpan={deviceGroups[dType].length + 1}
                  className="rowspan"
                >
                  {dPoint.treatmentsPerDay}
                </td>
              )}
              <td>{dPoint.minMinutesPerTreatment} m</td>
              <td>
                {isManualVest ? ' - ' : dPoint.minFrequency}
                {
                  isManualVest ? '' : (dPoint.maxFrequency === dPoint.minFrequency ||
                    !dPoint.maxFrequency)
                    ? ''
                    : `-${dPoint.maxFrequency}`
                }
              </td>
              <td>
                {dPoint.minIntensity}
                {
                  dPoint.maxIntensity === dPoint.minIntensity ||
                    !dPoint.maxIntensity
                    ? ''
                    : `-${dPoint.maxIntensity}`
                }
                {isManualVest ? ' - ' : dPoint.minPressure}
                {isManualVest ? '' :
                  (dPoint.maxPressure === dPoint.minPressure ||
                    !dPoint.maxPressure)
                    ? ''
                    : `-${dPoint.maxPressure}`
                }
              </td>
            </tr>
          ))
        ) : (
          <tr />
        )}
      </tbody>
    </table>
  );
};

export const buildDefaultProtocol = (from, to, isActive, key, points) => {
  return {
    from: moment(from).valueOf(),
    isActive: isActive,
    key: key,
    points: points,
    to: to !== null ? moment(to).valueOf() : to
  };
}

export const getProtocols = () => {
  const momentToday = moment();
  let deviceProtocolList = groupBy(protocolList, 'deviceType');
  let protocols = {};
  if (!isEmpty(deviceProtocolList)) {
    Object.keys(deviceProtocolList)
      .map(dType => {
        if (deviceProtocolList[dType] && deviceProtocolList[dType].length) {
          Object.keys(deviceProtocolList[dType]).map(dPoint => {
            let defaultProtocolList = [];
            let sortedProtocols = deviceProtocolList[dType][dPoint].protocolList.sort((a, b) => a.from > b.from ? 1 : -1);
            let points = [deviceProtocolList[dType][dPoint].defaultProtocol[0]];
            for (let j = 0; j < sortedProtocols.length; j++) {
              if (j === 0) {
                if (patientFirstTrans < sortedProtocols[j].from) {
                  defaultProtocolList.push(buildDefaultProtocol(patientFirstTrans,
                    moment(sortedProtocols[j].from).subtract(1, 'days'),
                    false, dType + j, points));
                }
              }
              if (j === sortedProtocols.length - 1) {
                if (momentToday >= sortedProtocols[j].to && !sortedProtocols[j].isActive) {
                  defaultProtocolList.push(buildDefaultProtocol(moment(sortedProtocols[j].to).add(1, 'days'),
                    null, true, dType + j, points));
                }
              }
              if (j + 1 < sortedProtocols.length) {
                let add = moment(sortedProtocols[j].to).add(1, 'day');
                let isSameDay = moment(add).isSame(moment(sortedProtocols[j + 1].from), 'day');
                if (!isSameDay) {
                  if (momentToday >= sortedProtocols[j].to && !sortedProtocols[j].isActive) {
                    defaultProtocolList.push(buildDefaultProtocol(moment(sortedProtocols[j].to).add(1, 'days'),
                      moment(sortedProtocols[j + 1].from).subtract(1, 'days'), false, dType + j, points));
                  }
                }
              }
            }
            for (let k = 0; k <= defaultProtocolList.length - 1; k++) {
              sortedProtocols.push(defaultProtocolList[k]);
            }
            protocols[dType] = sortedProtocols;
            return null;
          })
        }
        return null;
      })
  }
  return protocols;
}

export const getWeeklySiproData = (spiroData, start, end) => {
  return spiroData.filter(e => moment(e.testResultDate) >= start && moment(e.testResultDate) < end);
  // return spiroData.filter(e => e.testResultDate >= moment(start).format("MM/DD/YYYY") && e.testResultDate < moment(end).format("MM/DD/YYYY"));
}

export const getWeeklyTherapyData = (therapyData, start, end) => {
  return therapyData.filter(e => moment(e.date) >= start && moment(e.date) < end);
}

export const getFilteredSpiroData = (spiroData, selectedOption, isBlackAndWhite, callForPdfBar) => {
  var filteredData = {};
  var maxSpiroYAxisLimit = 100;
  var maxTherapyYAxisLimit = 100;

  filteredData["data"] = {};
  filteredData["data"]["labels"] = spiroData.data.labels;
  if (selectedOption === strings.spiro) {
    filteredData["data"]["datasets"] = spiroData.data.datasets.filter(e => e.label !== strings.dailyTherapyAverage);
    maxSpiroYAxisLimit = max([max(filteredData["data"]["datasets"][0].data), max(filteredData["data"]["datasets"][1].data)])
    maxSpiroYAxisLimit = maxSpiroYAxisLimit > 1 ? maxSpiroYAxisLimit : 100;
  }
  else if (selectedOption === strings.therapy) {
    filteredData["data"]["datasets"] = spiroData.data.datasets.filter(e => e.label === strings.dailyTherapyAverage);
    maxTherapyYAxisLimit = max(filteredData["data"]["datasets"][0].data);
    maxTherapyYAxisLimit = maxTherapyYAxisLimit > 1 ? maxTherapyYAxisLimit : 100;
  }
  else {
    filteredData["data"]["datasets"] = spiroData.data.datasets;
    maxSpiroYAxisLimit = max([max(filteredData["data"]["datasets"][0].data), max(filteredData["data"]["datasets"][1].data)]);
    maxTherapyYAxisLimit = max(filteredData["data"]["datasets"][2].data)
    maxSpiroYAxisLimit = maxSpiroYAxisLimit > 1 ? maxSpiroYAxisLimit : 100;
    maxTherapyYAxisLimit = maxTherapyYAxisLimit > 1 ? maxTherapyYAxisLimit : 100;
  }

  var yAxisObj = [
    {
      id: 1,
      position: "left",
      display: selectedOption === 'all' || selectedOption === 'spiro' ? true : false,
      fontFamily: "Sailec",
      scaleLabel: {
        labelString: "FEV1% Pridicted",
        fontFamily: "Sailec",
        fontSize: callForPdfBar ? 14 : 10,
        fontStyle: 'bold',
        display: selectedOption === 'all' || selectedOption === 'spiro' ? true : false
      },
      gridLines: { drawBorder: false, display: false },
      ticks: {
        fontSize: callForPdfBar ? 12 : 10,
        suggestedMin: 0,
        suggestedMax: maxSpiroYAxisLimit,
        display: selectedOption === 'all' || selectedOption === 'spiro' ? true : false,
        beginAtZero: true,
        callback(value) {
          return value;
        }
      }
    },
    {
      id: 2,
      position: selectedOption === 'all' ? "right" : "left",
      fontFamily: "Sailec",
      scaleLabel: {
        labelString: "Daily Therapy Avg. by Week (mins)",
        fontFamily: "Sailec",
        fontStyle: 'bold',
        fontSize: callForPdfBar ? 14 : 10,
        display: selectedOption === 'all' || selectedOption === 'therapy' ? true : false
      },
      gridLines: { drawBorder: false, display: false },
      ticks: {
        fontSize: callForPdfBar ? 12 : 10,
        suggestedMin: 0,
        suggestedMax: maxTherapyYAxisLimit,
        display: selectedOption === 'all' || selectedOption === 'therapy' ? true : false,
        beginAtZero: true,
        callback(value) {
          return value;
        }
      }
    }
  ]

  const options = {
    events: ['click'],
    animation: callForPdfBar
      ? false
      : {
        duration: 250 * 1.5,
        easing: 'linear'
      },
    legend: {
      position: 'top',
      fullWidth: true,
      labels: {
        boxWidth: 6,
        fontSize: callForPdfBar ? 12 : 10,
        padding: 15,
        fontStyle: 'bold',
        fontFamily: "Sailec",
        usePointStyle: true,
      },
      onClick: e => e.stopPropagation() // Disable click action on the legend.
    },
    cornerRadius: 10,
    tooltips: {
      // Disable the on-canvas tooltip
      enabled: false,
      intersect: false,
      mode: 'point',
      callbacks: {
        label(tooltipItem, data) {
          return data.labels[tooltipItem.index];
        }
      },
      position: 'custom',
      custom(tooltipModel) {
        lineTooltipEl(this._chart, tooltipModel, selectedOption);
      }
    },
    scales: {
      xAxes: [
        {
          gridLines: { drawBorder: false, display: false },
          barPercentage: 0.5,
          barThickness: 5,
          maxBarThickness: 5,
          ticks: {
            fontSize: callForPdfBar ? 12 : 9,
            fontFamily: "Sailec",
            fontColor: "black",
            callback(value) {
              return value;
            }
          }
        }
      ],
      yAxes: yAxisObj
    },
    // elements: {
    //   point: {
    //     radius: 40,
    //     hoverRadius: 40,
    //     pointStyle: 'rectRounded'
    //   }
    // },
    annotation: {
      annotations: [
        {
          id: 'a-line-1',
          type: 'line',
          mode: 'horizontal',
          drawTime: 'beforeDatasetsDraw',
          scaleID: 'y-axis-0',
          borderDash: [2, 2],
          borderDashOffset: 5,
          value: 100,
          borderColor: '#e3ebf6',
          borderWidth: 2
        }
      ]
    }
  }
  filteredData["options"] = options;
  return filteredData;
}

export const getEnhancedSpiroData = (spiroData, therapyData, selectedSpiroYear, isBlackAndWhite, callForPdfBar) => {
  therapyDataG = therapyData;
  spiroDataG = spiroData;
  var isSpiroData = spiroData.length > 0;
  var isTherapyData = therapyData.length > 0;

  var yearStart = moment(selectedSpiroYear).startOf('year');
  var start = moment(yearStart).startOf('week');
  var end = moment(selectedSpiroYear).endOf('year');

  var xaxisArray = [];
  xSiproLabels = [];
  const datasets = [];
  const datasets_g = [];

  const homeTest = {
    label: 'Hillrom Spiro',
    type: 'line',
    borderColor: isBlackAndWhite && callForPdfBar ? '#000' : lineColor.HILLROMSPIRO,
    backgroundColor: isBlackAndWhite && callForPdfBar ? '#000' : lineColor.HILLROMSPIRO,
    lineTension: 0,
    borderWidth: 1,
    fill: false,
    yAxisID: 1,
    spanGaps: true,
  }

  const clinicalTest = {
    label: 'Other Spiro',
    type: 'line',
    borderColor: isBlackAndWhite && callForPdfBar ? '#737373' : lineColor.OTHERSPIRO,
    backgroundColor: isBlackAndWhite && callForPdfBar ? '#737373' : lineColor.OTHERSPIRO,
    borderWidth: 1,
    lineTension: 0,
    radius: isBlackAndWhite && callForPdfBar ? 5 : 3,
    fill: false,
    yAxisID: 1,
    spanGaps: true,
    pointStyle: isBlackAndWhite && callForPdfBar ? 'triangle' : 'circle'
  };

  const theraphyAvg = {
    label: 'Daily Therapy Average',
    borderColor: lineColor.THERAPYAVG,
    backgroundColor: lineColor.THERAPYAVG,
    yAxisID: 2,
    type: 'bar'
  };

  var clinicSpiroList = [];
  var clinicSpiroListFull = [];
  var homeSpiroList = [];
  var homeSpiroListFull = [];
  var avgTherapyList = [];

  while ((isSpiroData || isTherapyData) && start <= end) {
    var weekDate = moment(start).startOf('week');
    // xaxisArray.push(moment(weekDate).format('MMM') + " " + moment(weekDate).format('DD'))
    xaxisArray.push(moment(weekDate).format('DD'))
    xSiproLabels.push(moment(weekDate));
    // var weekNum = start.week() - moment(start).startOf('month').week() + 1;
    // weekNum === 1 ? xaxisArray.push(moment(weekDate).format('MMM') + moment(weekDate).format('DD')) :
    //   xaxisArray.push(moment(weekDate).format('DD'));
    start.add(7, 'days');

    var frmI = therapyData.indexOf(therapyData.find(e => moment(e.date) >= weekDate && moment(e.date) < start));
    if (frmI !== -1) {
      var weeklyTherapyData = getWeeklyTherapyData(therapyData.slice(frmI, frmI + 32), weekDate, start);
      var sumTherapy = weeklyTherapyData.reduce((prev, next) => prev + next.duration, 0);
      var avgTherapyVal = (sumTherapy / 7);
      avgTherapyList.push(avgTherapyVal);
    }
    else {
      avgTherapyList.push(0);
    }

    var weeklySiproData = getWeeklySiproData(spiroData, weekDate, start);
    var groupedSpiroData = groupBy(weeklySiproData, 'type');
    var curHomeVal = 0;
    var curClinicVal = 0;
    if (groupedSpiroData.clinic !== undefined) {
      curClinicVal = (groupedSpiroData.clinic).reduce((p, n) =>
        (p.fev1_TO_FVC_RATIO > n.fev1_TO_FVC_RATIO) ? p : n)
    }
    else if (groupedSpiroData.CLINIC !== undefined) {
      curClinicVal = (groupedSpiroData.CLINIC).reduce((p, n) =>
        (p.fev1_TO_FVC_RATIO > n.fev1_TO_FVC_RATIO) ? p : n)
    }
    if (groupedSpiroData !== undefined && groupedSpiroData.SPIRO !== undefined) {
      curHomeVal = (groupedSpiroData.SPIRO).reduce((p, n) =>
        (p.fev1_TO_FVC_RATIO > n.fev1_TO_FVC_RATIO) ? p : n)
    }
    clinicSpiroList.push(curClinicVal.fev1_TO_FVC_RATIO !== undefined && curClinicVal.fev1_TO_FVC_RATIO > 0 ? curClinicVal.fev1_TO_FVC_RATIO : null);
    clinicSpiroListFull.push(curClinicVal.fev1_TO_FVC_RATIO !== undefined && curClinicVal.fev1_TO_FVC_RATIO > 0 ? curClinicVal : null);
    homeSpiroList.push(curHomeVal.fev1_TO_FVC_RATIO !== undefined && curHomeVal.fev1_TO_FVC_RATIO > 0 ? curHomeVal.fev1_TO_FVC_RATIO : null);
    homeSpiroListFull.push(curHomeVal.fev1_TO_FVC_RATIO !== undefined && curHomeVal.fev1_TO_FVC_RATIO > 0 ? curHomeVal : null);
  }

  const labels = xaxisArray;

  homeTest.data = homeSpiroList;
  clinicalTest.data = clinicSpiroList;
  datasets.push(homeTest);
  datasets.push(clinicalTest);

  datasets_g.push(clinicSpiroListFull);
  datasets_g.push(homeSpiroListFull);

  theraphyAvg.data = avgTherapyList;
  datasets.push(theraphyAvg);
  Gdatasets_t = datasets_g;
  var isNoData = false;

  var isEmptyHomeSpiroList = homeSpiroList.filter(e => e !== null);
  if (isEmptyHomeSpiroList.length === 0) {
    var isEmptyclinicSpiroList = clinicSpiroList.filter(e => e !== null);
    if (isEmptyclinicSpiroList.length === 0) {
      var isEmptyTherapy = avgTherapyList.filter(e => e !== 0);
      isNoData = isEmptyTherapy.length > 0 ? false : true;
    }
  }

  var data = {
    labels: labels,
    datasets: datasets
  };
  if (isNoData) {
    data = [];
  }
  return {
    data
  };
}

export const getEnhancedPatientsGroupData = (
  patientsOverview,
  isBlackAndWhite,
  callForPdfBar,
  spiroRawData,
  therapyRawData,
  isSpiroPdf
) => {
  const sessionGaugeGraph = {};
  const minuteGaugeGraph = {};
  const barCharts = {};
  const lineCharts = {};
  let patientsData = [];
  let filteredProtocols = {};
  if (
    !isEmpty(patientsOverview) && isBlackAndWhite !== undefined
  ) {
    patientsData = entries(patientsOverview).reduce((patientsData, [patientId, patientOverview]) => {
      const { patient, clinics, providers, stats, protocols, therapy } = patientOverview;
      const fromMonth = Object.keys(therapy)[0];
      const toMonth = Object.keys(therapy)[Object.keys(therapy).length - 1];
      let fromDate = moment(moment(fromMonth).startOf('month').format('YYYY-MM-DD'));
      const momentToday = moment();
      const momentMonthEnd = moment(moment(toMonth).endOf('month').format('YYYY-MM-DD'));
      let toDate = momentMonthEnd;
      if (momentToday <= momentMonthEnd) {
        toDate = momentToday;
      }
      let allProtocolList = getProtocols();
      let deviceProtocolList = groupBy(protocolList, 'deviceType');
      if (!isEmpty(deviceProtocolList)) {
        Object.keys(deviceProtocolList)
          .map(dType => {
            if (deviceProtocolList[dType] && deviceProtocolList[dType].length) {
              let typeProtocol = allProtocolList[dType].sort((a, b) => a.from < b.from ? 1 : -1);
              let fromIdx = null;
              let toIdx = null;
              let protoArray = [];
              for (let i = 0; i <= typeProtocol.length - 1; i++) {
                if (typeProtocol[i].from <= fromDate && (typeProtocol[i].to >= fromDate || typeProtocol[i].isActive)) {
                  fromIdx = i;
                }
                if (typeProtocol[i].from <= toDate && (typeProtocol[i].to >= toDate || typeProtocol[i].isActive)) {
                  toIdx = i;
                }
              }
              let n = fromIdx !== null ? fromIdx : typeProtocol.length - 1;
              let m = toIdx !== null ? toIdx : 0;
              while (n >= m) {
                protoArray.push(typeProtocol[n])
                n--;
              }
              filteredProtocols[dType] = protoArray;
            }
            return null;
          })
      }
      if (!isEmpty(patient) && !isEmpty(stats)) {
        const deviceGroups = groupBy(protocols, 'deviceType');

        // session gauge and minute gauge
        let sessionGauge = {};
        let minuteGauge = {};
        const minutesGaugeRef = React.createRef();
        const sessionGaugeRef = React.createRef();
        const barChartRef = [];
        const lineChartRef = [];

        if (!isEmpty(stats)) {
          sessionGauge = {
            percentage: stats.completed_sessions_percentage,
            done: stats.total_completed_sessions,
            recommended: stats.total_sessions,
            headText: strings.o_completedSessions
          };
          minuteGauge = {
            percentage: stats.completed_minutes_percentage,
            done: stats.total_completed_minutes,
            recommended: stats.total_minutes,
            headText: strings.completedMinutes
          };
        }

        minuteGaugeGraph[patientId] = (
          <React.Fragment key={uid(`${patientId}-minutGauge`)}>
            <PdfCustomGauge
              ref={minutesGaugeRef}
              data={minuteGauge}
              isBlackAndWhite={isBlackAndWhite}
              idx={`${patientId}-minutGauge`}
            />
          </React.Fragment>
        );
        sessionGaugeGraph[patientId] = (
          <React.Fragment key={uid(`${patientId}-sessionGauge`)}>
            <PdfCustomGauge
              ref={sessionGaugeRef}
              data={sessionGauge}
              isBlackAndWhite={isBlackAndWhite}
              idx={`${patientId}-sessionGauge`}
            />
          </React.Fragment>
        );

        var years = [];
        var scoreCards = [];
        var months = [];
        if (isSpiroPdf) {
          const yearMap = {};
          for (var i = 2; i >= 0; i--) {
            const year = moment(moment().subtract(i, 'years')).format('YYYY-MM-DD');
            const therapyData = therapyRawData[year] !== undefined ? therapyRawData[year] : [];
            const spiroData = spiroRawData[year] !== undefined ? spiroRawData[year] : [];
            const lineChartData = getEnhancedSpiroData(spiroData, therapyData, year, isBlackAndWhite, callForPdfBar);
            var lineChart = {};
            if (!isEmpty(lineChartData.data)) {
              lineChart = getFilteredSpiroData(lineChartData, 'all', isBlackAndWhite, callForPdfBar);
            }
            var spiroSessionData = {};
            spiroSessionData["therapy"] = therapyData;
            spiroSessionData["spiro"] = spiroData;
            yearMap[year] = {
              lineChart,
              spiroSessionData
            }
          }
          years = Object.keys(yearMap).sort((m1, m2) => moment(m1).valueOf() < moment(m2).valueOf() ? 1 : -1);
          lineCharts[patientId] = [];
          forEach(years, (year, index) => {
            lineChartRef[index] = React.createRef();
            lineCharts[patientId].push(
              <div className="row position-relative" key={uid(year)}>
                <PdfCustomLineChart
                  key={`${index}-${patientId}-${year}`}
                  idx={`${index}-${patientId}-${year}`}
                  ref={lineChartRef[index]}
                  scoreCard={yearMap[year].lineChart}
                />
              </div>
            );
            scoreCards[year] = yearMap[year].spiroSessionData;
          });
        }
        else {
          const monthMap = entries(therapy).reduce((monthMap, [date, { therapyData, protocolDuration }]) => {
            const month = moment(`${date}-01`).format('YYYY-MM-DD');
            const barChart = getEnhancedBarData({ date: month, therapyData, protocolDuration, isBlackAndWhite, callForPdfBar, firstTrans: patient.firstTrans, vestDeviceName: patient.isManual ? patient.deviceName : null });
            const sessionTable = getEnhancedTableData({ therapyData, protocolDuration });
            monthMap[month] = {
              barChart,
              sessionTable
            }
            return monthMap;
          }, {});


          months = Object.keys(monthMap).sort((m1, m2) => moment(m1).valueOf() < moment(m2).valueOf() ? 1 : -1);
          barCharts[patientId] = [];
          forEach(months, (month, index) => {
            barChartRef[index] = React.createRef();
            barCharts[patientId].push(
              <div className="row position-relative" key={uid(month)}>
                <PdfCustomBarChart
                  key={`${index}-${patientId}-${month}`}
                  idx={`${index}-${patientId}-${month}`}
                  ref={barChartRef[index]}
                  scoreCard={monthMap[month].barChart}
                />
              </div>
            );
            scoreCards[month] = monthMap[month].sessionTable;
          });
        }

        patientsData.push({
          patient,
          clinics,
          providers,
          minutesGaugeRef,
          sessionGaugeRef,
          barChartRef,
          scoreCards,
          stats,
          months,
          deviceGroups,
          filteredProtocols,
          years,
          lineChartRef
        });
      }
      return patientsData;
    }, []);
  }

  return {
    patientsData,
    minuteGaugeGraph,
    sessionGaugeGraph,
    barCharts,
    lineCharts
  };
}

export const getAllPatientsGroupData = (
  allOverviewData,
  allUserallMonthsTherapyData,
  isBlackAndWhite
) => {
  try {
    const minutGaugeGraph = {};
    const sessionGaugeGraph = {};
    const barCharts = {};
    const patientsData = [];
    if (
      !isEmpty(allOverviewData) &&
      !isEmpty(allUserallMonthsTherapyData) &&
      isBlackAndWhite !== undefined
    ) {
      const listOfids =
        allOverviewData !== null && allOverviewData !== undefined
          ? Object.keys(allOverviewData)
          : [];
      let idx = 0;
      for (let i = 0; i < listOfids.length; i++) {
        const id = listOfids[i];
        const idData = allOverviewData[id];
        const patient = idData.patientData;
        const pUserData = idData.userData;
        const clinic = idData.clinicData;
        const provider = idData.providerData;
        const { therapyData, patientStats } = idData;
        const protocols = idData.protocolData;
        const scoreCard = getScoreData(
          protocols,
          therapyData,
          patient,
          pUserData,
          isBlackAndWhite,
          true
        );
        scoreCard.patientStats = patientStats;
        const allMonthsTherapyData = allUserallMonthsTherapyData[id];
        let sessionGauge = {};
        let minuteGauge = {};
        const barChartRef = [];
        const ScoreCards = [];
        const minutesGaugeRef = React.createRef();
        const sessionGaugeRef = React.createRef();
        const sessionTempRef = React.createRef();
        const minutesTempRef = React.createRef();
        barChartRef[0] = React.createRef();
        if (!isEmpty(patientStats)) {
          sessionGauge = {
            percentage: patientStats.completed_sessions_percentage,
            done: patientStats.total_completed_sessions,
            recommended: patientStats.total_sessions,
            headText: strings.o_TotalSessions
          };
          minuteGauge = {
            percentage: patientStats.completed_minutes_percentage,
            done: patientStats.total_completed_minutes,
            recommended: patientStats.total_minutes,
            headText: strings.completedMinutes
          };
        }

        minutGaugeGraph[id] = (
          <React.Fragment key={uid(`${id}-minutGauge`)}>
            <PdfCustomGauge
              ref={minutesGaugeRef}
              data={minuteGauge}
              isBlackAndWhite={isBlackAndWhite}
              idx={`${id}-minutGauge`}
            />
            {i === listOfids.length - 1 && (
              <PdfCustomGauge
                ref={minutesTempRef}
                data={minuteGauge}
                isBlackAndWhite={isBlackAndWhite}
                idx={`${id}-sessionGauge+1`}
              />
            )}
          </React.Fragment>
        );
        sessionGaugeGraph[id] = (
          <React.Fragment key={uid(`${id}-sessionGauge`)}>
            <PdfCustomGauge
              ref={sessionGaugeRef}
              data={sessionGauge}
              isBlackAndWhite={isBlackAndWhite}
              idx={`${id}-sessionGauge`}
            />
            {i === listOfids.length - 1 && (
              <PdfCustomGauge
                ref={sessionTempRef}
                data={sessionGauge}
                isBlackAndWhite={isBlackAndWhite}
                idx={`${id}-sessionGauge+1`}
              />
            )}
          </React.Fragment>
        );
        let index = 0;
        if (
          allMonthsTherapyData !== null &&
          allMonthsTherapyData !== undefined &&
          Object.keys(allMonthsTherapyData).length !== 0
        ) {
          if (barCharts[id] === undefined) {
            barCharts[id] = [];
          }
          Object.keys(allMonthsTherapyData).map(month => {
            const date = getEndDate(moment(month))
              .format('YYYY-MM-DD');
            const scoreCardOfOne = getScoreData(
              protocols,
              allMonthsTherapyData[month],
              patient,
              pUserData,
              isBlackAndWhite,
              true
            );

            barChartRef[index] = React.createRef();
            ScoreCards[index] =
              isEmpty(scoreCardOfOne) || scoreCardOfOne.dates.length === 0
                ? { dates: [date] }
                : scoreCardOfOne;
            barCharts[id].push(
              <div className="row position-relative" key={uid(month)}>
                <PdfCustomBarChart
                  key={`${index}-${id}-${month}`}
                  idx={`${index}-${id}-${month}`}
                  ref={barChartRef[index]}
                  scoreCard={scoreCardOfOne}
                />
              </div>
            );
            index++;
            return true;
          });
        }
        if (
          allMonthsTherapyData !== null &&
          allMonthsTherapyData !== undefined &&
          Object.keys(allMonthsTherapyData).length !== 0
        ) {
          patientsData[idx] = {
            patient,
            pClinics: clinic,
            pProviders: provider,
            minutesGaugeRef,
            sessionGaugeRef,
            barChartRef,
            scoreCards: ScoreCards,
            yScoreCard: scoreCard
          };
          idx++;
        }
      }
    }
    return {
      patientsData,
      minutGaugeGraph,
      sessionGaugeGraph,
      barCharts
    };
  } catch (error) {
    console.log(error);
  }
};
