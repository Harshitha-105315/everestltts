import React from 'react';
import strings from 'localization/strings';
import { getCityByStateCountryList } from 'utils/helper.js';
import { uid } from 'react-uid';
import moment from 'moment-timezone';
import { isEmpty, groupBy, entries } from 'lodash';
import DeleteIcon from 'assets/icn-delete.svg';
import constants from 'constants.js';
import titanLogo from 'assets/img/logo/titanlogo.png';
import monarchLogo from 'assets/img/logo/monarch.png';
import visiVestLogo from 'assets/img/logo/visivest.png';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import { decryptemail } from '../Cryptocode';

export const getManagePatientsFilters = ({
  currState,
  handleFilter,
  cityByStateCountry,
  statesByCountry
}) => {
  const {
    gender,
    clinicSts,
    patientSts,
    deviceSts,
    country,
    state,
    city,
    range,
    ageRange
  } = currState;
  const cityByStateCountryList = getCityByStateCountryList(cityByStateCountry);
  const filters = {
    Patient_Level_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ],
    Clinic_Level_Status: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.CLINIC_STATUS,
        value: constants.FILTER_VALUES.ALL,
        type: constants.FILTER_TYPE.RADIO,
        onChangeFunction: handleFilter,
        checked: clinicSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        name: constants.FILTER_NAME.CLINIC_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        type: constants.FILTER_TYPE.RADIO,
        onChangeFunction: handleFilter,
        checked: clinicSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        name: constants.FILTER_NAME.CLINIC_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        type: constants.FILTER_TYPE.RADIO,
        onChangeFunction: handleFilter,
        checked: clinicSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ],
    Device_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ],
    Transmission_Within: [
      {
        title: strings.transmissionWithin,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.RANGE,
        value: range,
        onChangeFunction: handleFilter,
        options: constants.TRANSMISSION_RANGE,
        optionType: 'object',
        optionValue: { key: 'value', value: 'label' },
        allSelection: false
      }
    ],
    Age: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: ageRange === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.age18,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE18,
        checked: ageRange === constants.FILTER_VALUES.AGE18 ? true : null
      },
      {
        title: strings.age35,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE35,
        checked: ageRange === constants.FILTER_VALUES.AGE35 ? true : null
      },
      {
        title: strings.age65,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65,
        checked: ageRange === constants.FILTER_VALUES.AGE65 ? true : null
      },
      {
        title: strings.age65plus,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65PLUS,
        checked: ageRange === constants.FILTER_VALUES.AGE65PLUS ? true : null
      }
    ],
    Gender: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: gender === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.male,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.MALE,
        checked: gender === constants.FILTER_VALUES.MALE ? true : null
      },
      {
        title: strings.female,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.FEMALE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.FEMALE ? true : null
      },
      {
        title: strings.other,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.OTHERS,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.OTHERS ? true : null
      }
    ],
    Location: [
      {
        title: strings.country,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.COUNTRY,
        value: country || '',
        onChangeFunction: handleFilter,
        options: constants.LOCATIONS
      },
      {
        title: strings.state,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.STATE,
        value: state || '',
        onChangeFunction: handleFilter,
        options: country ? statesByCountry : []
      },
      {
        title: strings.city,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.CITY,
        value: city || '',
        onChangeFunction: handleFilter,
        options: country ? cityByStateCountryList : []
      }
    ]
  };
  return filters;
};

export const getManageRolePatientsFilters = ({
  currState,
  handleFilter,
  clinicFilterList,
  providerFilterList
}) => {
  const {
    gender,
    patientSts,
    transmission,
    deviceSts,
    clinicId,
    providerId,
    ageRange
  } = currState;
  let filters = {
    Clinic_Name: [
      {
        title: strings.clinicName,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.CLINIC_ID,
        value: clinicId,
        onChangeFunction: handleFilter,
        options: clinicFilterList ? clinicFilterList || [] : [],
        optionType: 'object',
        optionValue: { key: 'id', value: ['name'] },
        allSelection: true
      }
    ],
    Provider_Name: [
      {
        title: strings.clinicName,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.PROVIDER_ID,
        value: providerId,
        onChangeFunction: handleFilter,
        options: providerFilterList ? providerFilterList || [] : [],
        optionType: 'object',
        optionValue: { key: 'id', value: ['firstName', 'lastName'] },
        allSelection: true
      }
    ],
    Patient_Level_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: handleFilter,
        checked: patientSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ],
    Transmission: [
      {
        title: strings.transmitting,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.TRANSMITTING,
        onChangeFunction: handleFilter,
        checked:
          transmission === constants.FILTER_VALUES.TRANSMITTING ? true : null
      },
      {
        title: strings.stoppedTranmission,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.STOPPED,
        onChangeFunction: handleFilter,
        checked: transmission === constants.FILTER_VALUES.STOPPED ? true : null
      },
      {
        title: strings.neverTransmitted,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.NEVER,
        onChangeFunction: handleFilter,
        checked: transmission === constants.FILTER_VALUES.NEVER ? true : null
      },
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: handleFilter,
        checked: transmission === constants.FILTER_VALUES.ALL ? true : null
      }
    ],
    Age: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: ageRange === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.age18,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE18,
        checked: ageRange === constants.FILTER_VALUES.AGE18 ? true : null
      },
      {
        title: strings.age35,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE35,
        checked: ageRange === constants.FILTER_VALUES.AGE35 ? true : null
      },
      {
        title: strings.age65,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65,
        checked: ageRange === constants.FILTER_VALUES.AGE65 ? true : null
      },
      {
        title: strings.age65plus,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65PLUS,
        checked: ageRange === constants.FILTER_VALUES.AGE65PLUS ? true : null
      }
    ],
    Gender: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: gender === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.male,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.MALE,
        checked: gender === constants.FILTER_VALUES.MALE ? true : null
      },
      {
        title: strings.female,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.FEMALE,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.FEMALE ? true : null
      },
      {
        title: strings.other,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.OTHERS,
        onChangeFunction: handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.OTHERS ? true : null
      }
    ],
    Device_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ]
  };
  return filters;
};

export function getManagePatientCardData(data) {
  return data.map((element, index) => {
    return {
      title: element.title,
      value: element.value,
      id: index + 1,
      onClickHandle: element.handleFunction,
      sessionValues: element.sessionValues,
      customClass: element.customClass,
      filterIcon: element.filterIcon,
      logo: element.logo
    };
  });
}

export function getClinicList(clinics) {
  let patientClinics = [
    {
      id: null,
      name: null
    }
  ];
  if (!isEmpty(clinics)) {
    patientClinics = clinics;
  }
  return patientClinics.map(clinic => {
    return (
      <React.Fragment key={uid(clinic)}>
        <div className="breaker" />
        <span className="mr-3 mt-3 d-inline-block clinic-id-label">
          <span className="key text-capitalize">{strings.clinicId}: </span>
          <span className="text">{clinic.hillromId || '-'}</span>
        </span>
        <span className="mr-3 mt-3 d-inline-block">
          <span className="key text-capitalize">{strings.clinic}: </span>
          <span className="text">{clinic.name ? clinic.name : '-'}</span>
        </span>
      </React.Fragment>
    );
  });
}

export function getDiagnosisDeviceCodeList(diagnosis) {
  let diagnosisCodes = [
    {
      type_code: null,
      type_code_value: null
    }
  ];
  if (diagnosis && !isEmpty(diagnosis)) {
    diagnosisCodes = diagnosis;
  }
  return diagnosisCodes.map(type => {
    return (
      <React.Fragment key={uid(type)}>
        <div className="breaker" />
        <span className="mr-3 d-inline-block">
          <span className="key text-capitalize">{strings.diagnosisCode}: </span>
          <span className="text">
            {type.type_code ? `${type.type_code} ${type.type_code_value}` : '-'}
          </span>
        </span>
      </React.Fragment>
    );
  });
}

export function getProviderList(providers) {
  let patientProviders = [
    {
      id: null,
      firstName: null
    }
  ];
  if (!isEmpty(providers)) {
    patientProviders = providers;
  }
  return patientProviders.map(provider => {
    const fullName = [
      provider.firstName,
      provider.middleName,
      provider.lastName
    ]
      .filter(Boolean)
      .join(' ');
    return (
      <React.Fragment key={uid(provider)}>
        <div className="breaker" />
        <span className="mr-3 mt-3 d-inline-block">
          <span className="key text-capitalize">{strings.provider}: </span>
          <span className="text">{fullName || '-'}</span>
        </span>
      </React.Fragment>
    );
  });
}

export function getClinicsBody(flag, clinicsByPatient, handleDeleteClinic) {
  if (!isEmpty(clinicsByPatient)) {
    return clinicsByPatient.map(element => (
      <tr key={uid(element)}>
        <td className="clinic-name">
          {element.name}
          <p className="secondary-data d-sm-none">{element.hillromId}</p>
        </td>
        <td className="d-none d-sm-table-cell">{element.address}</td>
        <td className="d-none d-sm-table-cell">{`${element.city}/${element.state}`}</td>
        <td className="d-none d-sm-table-cell">{element.hillromId}</td>
        {flag && (
          <td className="clinic-info-actions">
            <img
              src={DeleteIcon}
              alt="Delete Clinic"
              onClick={event => {
                handleDeleteClinic(event, element.id);
              }}
              onKeyDown={event => {
                handleDeleteClinic(event, element.id);
              }}
              name={element.name}
              role="presentation"
            />
          </td>
        )}
      </tr>
    ));
  }
  return (
    <tr>
      <td colSpan="5" className="text-center">
        {strings.noClinicAssociated}
      </td>
    </tr>
  );
}

export function getProvidersBody(flag, providersByPatient, handleDeleteHcp) {
  if (!isEmpty(providersByPatient)) {
    return providersByPatient.map(element => (
      <tr>
        <td className="provider-name" key={element.firstName}>
          {`${element.firstName} ${element.lastName}`}
          <p className="secondary-data d-sm-none">{element.hillromId}</p>
        </td>
        <td className="d-none d-sm-table-cell">{element.credentials}</td>
        <td className="d-none d-sm-table-cell">{element.hillromId}</td>
        <td className="d-none d-sm-table-cell">{`${element.city || ''}${element.city && element.state ? '/' : ''
          }${element.state || ''}`}</td>
        <td className="d-none d-sm-table-cell">{element.primaryPhone}</td>
        {flag && (
          <td className="provider-actions">
            <img
              src={DeleteIcon}
              alt="Delete Clinic"
              onClick={event => {
                handleDeleteHcp(event, element.id);
              }}
              onKeyDown={event => {
                handleDeleteHcp(event, element.id);
              }}
              name={`${element.firstName} ${element.lastName}`}
              role="presentation"
            />
          </td>
        )}
      </tr>
    ));
  }
  return (
    <tr>
      <td colSpan={6} className="text-center">
        {strings.noProviderAssociated}
      </td>
    </tr>
  );
}

export function getCaregiverBody(flag, caregivers, handleDeleteCaregiver) {
  if (!isEmpty(caregivers)) {
    return caregivers.map(element => (
      <tr key={element.user.id}>
        <td key={element.user.firstName} className="caregiver-name">
          {`${element.user.firstName} ${element.user.lastName}`}
          <p className="secondary-data d-sm-none">
            {element.user.primaryPhone}
          </p>
        </td>
        <td key={element.address} className="d-none d-sm-table-cell">
          {element.user.address}
        </td>
        <td key={element.user.primaryPhones} className="d-none d-sm-table-cell">
          {element.user.primaryPhone}
        </td>
        <td className="d-none d-sm-table-cell">{element.user.mobilePhone}</td>
        <td className="d-none d-sm-table-cell">{element.relationshipLabel ? decryptemail(element.relationshipLabel) : ''}</td>
        {flag && (
          <td className="caregiver-options">
            <img
              src={DeleteIcon}
              alt="Delete Clinic"
              onClick={event => {
                handleDeleteCaregiver(event, element.user.id);
              }}
              onKeyDown={event => {
                handleDeleteCaregiver(event, element.user.id);
              }}
              name={`${element.user.firstName} ${element.user.lastName}`}
              role="presentation"
            />
          </td>
        )}
      </tr>
    ));
  }
  return (
    <tr>
      <td colSpan={6} className="text-center">
        {strings.noCaregiverAssociated}
      </td>
    </tr>
  );
}

export function getClinicsList(clinics) {
  if (clinics !== []) {
    const clinicList = [];
    clinics.forEach(function clinicsIdName(a) {
      clinicList.push({ value: a.id, label: a.name });
    });
    return clinicList;
  }
  return [];
}

export function getProvidersList(hcpByPatientClinics) {
  if (hcpByPatientClinics !== []) {
    const providerByClinicList = [];
    hcpByPatientClinics.forEach(function hcpByPatientClinicsIdName(a) {
      providerByClinicList.push({
        value: a.id,
        label: `${a.firstName} ${a.lastName}`
      });
    });
    return providerByClinicList;
  }
  return [];
}

export function parseDate(date) {
  if (date) {
    return new Date(Date.parse(moment(date)));
  }
  return undefined;
}

export function setFormattedDate(date) {
  this.setState({
    formatedDOB: moment(new Date(date)).format('MM/DD/YY')
  });
}

export async function setAssociateEntityState(obj) {
  const { associateEntity } = this.state;
  await this.setState({
    associateEntity: Object.assign({}, associateEntity, obj)
  });
}

export function getClinicTableHeading(flag) {
  const clinicTableHeading = [
    { text: strings.clinicName, sortable: false },
    { text: strings.address, sortable: false, mobile: false },
    {
      text: `${strings.city}/${strings.state}`,
      sortable: false,
      mobile: false
    },
    { text: strings.hillromID, sortable: false, mobile: false }
  ];
  if (flag) {
    clinicTableHeading.push({
      text: strings.options,
      name: 'options',
      value: 'options'
    });
  }
  return clinicTableHeading;
}

export function getProviderTableHeading(flag) {
  const providerTableHeading = [
    { text: strings.providerName, sortable: false },
    { text: strings.credentials, sortable: false, mobile: false },
    { text: strings.hillromID, sortable: false, mobile: false },
    {
      text: `${strings.city}/${strings.state}`,
      sortable: false,
      mobile: false
    },
    { text: strings.phone, sortable: false, mobile: false }
  ];
  if (flag) {
    providerTableHeading.push({
      text: strings.options,
      name: 'options',
      value: 'options'
    });
  }
  return providerTableHeading;
}

export function getCaregiverTableHeading(flag) {
  const caregiverTableHeading = [
    { text: strings.caregiverName, sortable: false },
    { text: strings.address, sortable: false, mobile: false },
    { text: strings.phone, sortable: false, mobile: false },
    { text: strings.mobile, sortable: false, mobile: false },
    { text: strings.relationship, sortable: false, mobile: false }
  ];
  if (flag) {
    caregiverTableHeading.push({
      text: strings.options,
      name: 'options',
      value: 'options'
    });
  }
  return caregiverTableHeading;
}

export function getDeviceImage(devices, patient) {
  if (devices !== null) {
    return devices.map(element => {
      if (element === 'VEST') {
        return (
          <span key={uid(element)}>
            {
              patient.isManual ? <img src={manualLogo} width="30" height="20" alt="Manual Visi Vest" />
                : <img src={visiVestLogo} width="32" height="32" alt="Visi Vest" />
            }
          </span>
        );
      }
      if (element === 'MONARCH') {
        return (
          <span key={uid(element)}>
            <img src={monarchLogo} width="32" height="32" alt="Monarch" />
          </span>
        );
      }
      if (element === 'TITAN') {
        return (
          <span key={uid(element)}>
            <img src={titanLogo} width="32" height="32" alt="Vest APX" />
          </span>
        );
      }
      return null;
    });
  }
  return null;
}

export function getSessionsField(sessionPercentage) {
  if (sessionPercentage >= 80) {
    return (
      <div>
        <div className="green-active d-inline-block" />
        <span className="text-capitalize">{`${sessionPercentage}%`}</span>
      </div>
    );
  }
  if (sessionPercentage >= 50) {
    return (
      <div>
        <div className="yellow-session d-inline-block" />
        <span className="text-capitalize">{`${sessionPercentage}%`}</span>
      </div>
    );
  }
  return (
    <div>
      <div className=" red-inactive d-inline-block" />
      <span className="text-capitalize">{`${sessionPercentage}%`}</span>
    </div>
  );
}

export function getProviderField(index, providers) {
  let { viewMore } = this.state;
  if (providers.length === 1) {
    return `${providers[0].firstName} ${providers[0].lastName}`;
  }
  return (
    <span>
      {`${providers[0].firstName} ${providers[0].lastName}`}
      <span
        name="view-more-provider-clinics"
        value={index}
        className={viewMore === index ? 'd-none' : 'view-more-patients'}
        onClick={() => {
          this.setState({ viewMore: index });
          viewMore = index;
        }}
        role="presentation"
      >
        {` +${providers.length - 1} more`}
      </span>
      <span className={viewMore === index ? '' : 'd-none'}>
        {providers.slice(1).map(element => {
          return (
            <div
              key={uid(element)}
            >{`${element.firstName} ${element.lastName}`}</div>
          );
        })}
      </span>
    </span>
  );
}

export function getDeviceTypeText(type) {
  switch (type) {
    case constants.DEVICE_TYPE_CODE.VISIVEST:
      return strings.visi;
    case constants.DEVICE_TYPE_CODE.MONARCH:
      return strings.monarch;
    case constants.DEVICE_TYPE_CODE.TITAN:
      return strings.titan;
    case constants.DEVICE_TYPE_CODE.ALL:
      return `${strings.visi}, ${strings.monarch}, ${strings.titan}`;
    default:
      return '';
  }
}

export function getMonthsOfYear(year) {
  var start = moment(year).startOf('year');
  var yend = moment(year).endOf('year')
  var end = moment(yend).isAfter(moment()) ? moment() : moment(yend);

  var monthsArray = [];
  while (end > start) {
    monthsArray.push(end);
    end = moment(end).subtract(1, 'month');
  }
  return monthsArray;
}

export function getDeviceList(type, stats = {}) {
  switch (type) {
    case constants.DEVICE_TYPE_CODE.VISIVEST:
      if (stats.monarch_minutes || stats.monarch_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.MONARCH,
          constants.DEVICE_TYPE_CODE.VISIVEST
        ];
      } else if (stats.titan_minutes || stats.titan_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.TITAN,
          constants.DEVICE_TYPE_CODE.VISIVEST
        ];
      } else {
        return [constants.DEVICE_TYPE_CODE.VISIVEST];
      }
    case constants.DEVICE_TYPE_CODE.TITAN:
      if (stats.monarch_minutes || stats.monarch_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.MONARCH,
          constants.DEVICE_TYPE_CODE.TITAN
        ];
      } else if (stats.vest_minutes || stats.vest_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.TITAN,
          constants.DEVICE_TYPE_CODE.VISIVEST
        ];
      } else {
        return [constants.DEVICE_TYPE_CODE.TITAN];
      }
    case constants.DEVICE_TYPE_CODE.MONARCH:
      if (stats.vest_minutes || stats.vest_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.MONARCH,
          constants.DEVICE_TYPE_CODE.VISIVEST
        ];
      } else if (stats.titan_minutes || stats.titan_sessions) {
        return [
          constants.DEVICE_TYPE_CODE.MONARCH,
          constants.DEVICE_TYPE_CODE.TITAN
        ];
      } else {
        return [constants.DEVICE_TYPE_CODE.MONARCH];
      }
    case constants.DEVICE_TYPE_CODE.ALL:
      return [
        constants.DEVICE_TYPE_CODE.TITAN,
        constants.DEVICE_TYPE_CODE.MONARCH,
        constants.DEVICE_TYPE_CODE.VISIVEST
      ];
    default:
      return [];
  }
}

export function groupTherapyDataByMonth(start, end, data) {
  const dateStart = moment(start);
  const dateEnd = moment(end);
  const monthMap = {};

  while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
    const m = dateStart.format('YYYY-MM');
    monthMap[m] = [];
    dateStart.add(1, 'month');
  }
  const { therapyData, protocolDuration } = data;
  let monthTherapyMap = groupBy(therapyData, therapy => {
    return moment(therapy.date).format('YYYY-MM');
  });
  monthTherapyMap = { ...monthMap, ...monthTherapyMap };
  const monthlyTherpayData = entries(monthTherapyMap).reduce((acc, [k, v]) => {
    acc[k] = { protocolDuration, therapyData: v };
    return acc;
  }, {});
  return monthlyTherpayData;
}

export function getProtocolTypeLabel(type, treatmentLabel) {
  if (type === constants.PROTOCOL_TYPES.NORMAL) {
    return strings.protocolTypes[type];
  } else {
    return `${strings.protocolTypes[type]} ${mapPointToPt(treatmentLabel)} `;
  }
}

function mapPointToPt(label) {
  if (label) {
    const point = label.match(/\d+/)[0];
    return `Pt ${point}`;
  } else {
    return '';
  }
}
