import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';
import { getUserData, getTimeZoneOffset } from 'utils/helper';

function getPatientData(id) {
  return authRequest({
    url: API.PATIENTBYID.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function storeSpiroLogDataService(data) {
  return authRequest({
    url: API.LOGSPIRODATA.replace('{USERID}', data.pid),
    method: 'POST',
    data: Object.assign({}, data),
    [constants.RETURNRESPONSE]: true
  });
}

function fetchPatientsSpiroDataService(id, start, end, timeZone) {
  const url = API.FETCHSPIRODATA.replace('{USERID}', id)
  return authRequest({
    url: `${url}?from=${start}&to=${end}&timeZone=${timeZone}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientClinicData(id) {
  return authRequest({
    url: API.CLINICBYPATIENTID.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientProviderData(id) {
  return authRequest({
    url: API.PROVIDERBYPATIENTID.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getUserDataById(id) {
  return authRequest({
    url: API.USERBYID.replace('{USERID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientStatsData(params) {
  const { id, start, end, timeZone } = params;
  const url = API.STATSBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?from=${start}&to=${end}&timeZone=${timeZone}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientProtocolByDate(params) {
  const { id, date } = params;
  const url = API.PROTOCOLBYPATIENTFORDATE.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?date=${date}`,
    method: 'GET'
  });
}

function getPatientSessionDetail(params) {
  const { id, start, end, pageSz, pageNo, order, timeZone } = params;
  const url = API.SESSIONBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?from=${start}&to=${end}&pageSz=${pageSz}&pageNo=${pageNo}&sortOrder=${order}&timeZone=${timeZone}`,
    method: 'GET'
  });
}

function getPatientAdherenceData(id, deviceType, start, end, range) {
  const url = API.ADHERENCEBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?from=${start}&to=${end}&duration=${range}&deviceType=${deviceType}`,
    method: 'GET'
  });
}

function getPatientProtocolData(id) {
  const url = API.PROTOCOLBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?deviceType=ALL`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientTherapyData(id, deviceType, start, end, range) {
  const url = API.THERAPYBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}?from=${start}&to=${end}&duration=${range}&deviceType=${deviceType}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function fetchPatientsService(params, roleBaseKey) {
  const timeZone = getTimeZoneOffset(getUserData().timeZone);
  params = { ...params, timeZone: timeZone };
  return authRequest({
    url: `${API.SEARCHPATIENT}${roleBaseKey ? `/${roleBaseKey}` : ''
      }`,
    params,
    method: 'GET',
    'x-response': true
  });
}

function getEnhancedPatientTherapyData(id, from, to, timeZone, extendedInfo) {
  const url = API.ENHANCEDTHERAPYBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url,
    params: { id, from, to, timeZone, extendedInfo },
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  })
}

function getPatientInfoService(payload) {
  return authRequest({
    url: API.PATIENT.replace('{PATIENTID}', payload.id),
    method: 'GET',
    'x-response': true
  });
}
function getVisiSizeService() {
  return authRequest({
    url: API.VISISIZE,
    method: 'GET'
  });
}
function getVisiColorService() {
  return authRequest({
    url: API.VISICOLOR,
    method: 'GET'
  });
}

function getVisiTypeService() {
  return authRequest({
    url: API.VISITYPE,
    method: 'GET'
  });
}

function getMonarchColorService() {
  return authRequest({
    url: API.MONARCHCOLOR,
    method: 'GET'
  });
}

function getMonarchSizeService() {
  return authRequest({
    url: API.MONARCHSIZE,
    method: 'GET'
  });
}

function getMonarchTypeService() {
  return authRequest({
    url: API.MONARCHTYPE,
    method: 'GET'
  });
}

function getTitanSizeService() {
  return authRequest({
    url: API.TITANSIZE,
    method: 'GET'
  });
}
function getTitanColorService() {
  return authRequest({
    url: API.TITANCOLOR,
    method: 'GET'
  });
}

function getTitanTypeService() {
  return authRequest({
    url: API.TITANTYPE,
    method: 'GET'
  });
}

function getClinicsByPatientService(id) {
  return authRequest({
    url: API.CLINICSBYPATIENT.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}
function getCaregiverByPatientService(id) {
  return authRequest({
    url: API.CAREGIVERBYPATIENT.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getProvidersByPatientService(id) {
  return authRequest({
    url: API.PROVIDERBYPATIENT.replace('{PATIENTID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getDiagnosisSearchResultService(searchUrl) {
  return authRequest({
    url: `${API.DIAGNOSISSEARCH}searchString=${searchUrl}`,
    method: 'GET'
  });
}

function updatePatientDetailsService(id, payload) {
  return authRequest({
    url: API.UPDATEPATIENT.replace('{PATIENTID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function associateClinicService(payload, id) {
  return authRequest({
    url: API.ASSOCIATECLINIC.replace('{PATIENTID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function disassociateClinicService(payload, id) {
  return authRequest({
    url: API.DIASSOCIATECLINICS.replace('{ENTITYID}', id).replace(
      '{ENTITY}',
      'patient'
    ),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function getHcpByPatientClinicsService(searchUrl, id) {
  return authRequest({
    url: API.HCPBYPATIENTCLINICS.replace('{PATIENTID}', id) + searchUrl,
    method: 'GET'
  });
}

function disassociateHcpService(payload, id) {
  return authRequest({
    url: API.DISASSOCIATEHCP.replace('{ENTITYID}', id).replace(
      '{ENTITY}',
      'patient'
    ),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function associateHcpService(payload, id) {
  return authRequest({
    url: API.ASSOCIATEHCP.replace('{ENTITYID}', id).replace(
      '{ENTITY}',
      'patient'
    ),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function fetchRelationshipsService() {
  return authRequest({
    url: API.RELATIONSHIPS,
    method: 'GET'
  });
}

function addCaregiverService(id, payload) {
  return authRequest({
    url: API.CAREGIVERBYPATIENT.replace('{PATIENTID}', id),
    method: 'POST',
    data: Object.assign({}, payload, { role: 'CARE_GIVER' }),
    [constants.RETURNRESPONSE]: true
  });
}

function disassociateCaregiverService(id, deleteId) {
  return authRequest({
    url: API.DISASSOCIATECAREGIVER.replace('{PATIENTID}', id).replace(
      '{CAREGIVERID}',
      deleteId
    ),
    method: 'DELETE',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientCountsService(entity, params) {
  const timeZone = getTimeZoneOffset(getUserData().timeZone);
  params = { ...params, timeZone: timeZone };

  const url = `${API.PATIENTCARDS}${entity || ''}`;
  return authRequest({
    url,
    params,
    method: 'GET',
    'x-response': true
  });
}

function fetchPatientAllProtocolDataService(id) {
  const url = API.ALLPROTOCOLBYPATIENTID.replace('{PATIENTID}', id);
  return authRequest({
    url: `${url}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function fetchStatesByCountryService(payload) {
  return authRequest({
    url: API.STATEBYCOUNTRY,
    method: 'POST',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function fetchCityByStateCountryService(payload) {
  return authRequest({
    url: API.CITYBYSTATECOUNTRY,
    method: 'POST',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function flagPatientService(payload) {
  const { patientId, flagged, entity } = payload;
  return authRequest({
    url: API.PATIENTFLAG.replace('{ENTITY}', entity),
    method: 'POST',
    data: [
      {
        patientId,
        flag: flagged
      }
    ],
    [constants.RETURNRESPONSE]: true
  });
}

function fetchDetailedReportPdf({ data, params }) {
  return authRequest({
    url: API.DETAILEDTHERAPYBYPATIENTID,
    method: 'POST',
    data,
    params,
    responseType: 'blob',
    [constants.RETURNRESPONSE]: true
  });
}

const PatientService = {
  getPatientData,
  storeSpiroLogDataService,
  fetchPatientsSpiroDataService,
  getUserDataById,
  getPatientClinicData,
  getPatientProviderData,
  getPatientStatsData,
  getPatientProtocolByDate,
  getPatientAdherenceData,
  getPatientSessionDetail,
  getPatientProtocolData,
  getPatientTherapyData,
  fetchPatientsService,
  getPatientInfoService,
  getVisiSizeService,
  getVisiColorService,
  getVisiTypeService,
  getMonarchColorService,
  getMonarchSizeService,
  getMonarchTypeService,
  getTitanSizeService,
  getTitanColorService,
  getTitanTypeService,
  getClinicsByPatientService,
  getCaregiverByPatientService,
  getDiagnosisSearchResultService,
  updatePatientDetailsService,
  getProvidersByPatientService,
  associateClinicService,
  disassociateClinicService,
  getHcpByPatientClinicsService,
  disassociateHcpService,
  associateHcpService,
  fetchRelationshipsService,
  addCaregiverService,
  disassociateCaregiverService,
  getPatientCountsService,
  fetchPatientAllProtocolDataService,
  fetchStatesByCountryService,
  fetchCityByStateCountryService,
  flagPatientService,
  getEnhancedPatientTherapyData,
  fetchDetailedReportPdf
};

export default PatientService;
