import React, { Component } from 'react';
import { Donut } from 'gaugeJS';
import { isEqual, isEmpty } from 'lodash';

export default class LineGraph extends Component {
  chartRef = React.createRef();
  boxRef = React.createRef();

  componentDidMount() {
    let canvasWidth = this.boxRef.current.offsetWidth;
    let canvasHeight = this.boxRef.current.offsetHeight;
    this.chartRef.current.setAttribute('width', canvasWidth);
    this.chartRef.current.setAttribute('height', canvasHeight);
    this.initGraph();
  }

  componentDidUpdate(prevProps) {
    const { data: newGraphData } = this.props;
    const { data: oldGraphData } = prevProps;
    if (!isEqual(oldGraphData, newGraphData)) {
      this.initGraph();
    }
  }

  initGraph() {
    const { data: graphData } = this.props;
    const gaugeRef = this.chartRef.current;
    const maxValue = 100;
    if (!isEmpty(graphData)) {
      const { percentage } = graphData;
      let color;
      if (percentage >= 80) {
        color = '#61d623'; // 80 - 100
      } else if (percentage >= 50) {
        color = '#ffd224'; // 50 - 79
      } else {
        color = '#fc2e2e'; // 0 - 49
      }
      const opts = {
        angle: 0.2,
        lineWidth: 0.1,
        radiusScale: 1,
        colorStart: color,
        colorStop: color,
        strokeColor: '#e6e9ee',
        shadowColor: '#e6e9ee',
        highDpiSupport: false
      };
      const customGauge = new Donut(gaugeRef).setOptions(opts);
      customGauge.maxValue = maxValue;
      customGauge.set(percentage || 0.1);
      customGauge.lineWidth = 12;
    }
  }

  render() {
    const { data: graphData, children } = this.props;
    if (!isEmpty(graphData)) {
      const { percentage, done, recommended, headText } = graphData;
      return (
        <div className="custom-gauge col-6 col-lg-5">
          <div className="canvas-box" ref={this.boxRef}>
            <canvas className="custom-gauge-canvas" ref={this.chartRef} />
          </div>
          <div className="text">
            <div className="main">
              {percentage}
              <span className="percentage">%</span>
            </div>
            <div className="extra-text">
              {done}/{recommended}
            </div>
            <div className="head">
              <span>{headText}</span>
              {children}
            </div>
          </div>
        </div>
      );
    }
    return null;
  }
}
