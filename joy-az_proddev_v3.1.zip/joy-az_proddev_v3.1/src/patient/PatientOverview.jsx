import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import strings from 'localization/strings';
import { getUserData, getDeviceTypeList, getEndDate, getMonthsAgoDate, getLatestMonth } from 'utils/helper';
import { Bar, Line } from 'components/Chart.js';
import RangeMonthlyPicker from 'components/RangeMonthPicker';
import constants from 'constants.js';
import Pagination from 'react-js-pagination';
import { Header, SideBar } from 'components/Navigation';
import { LinkContainer } from 'react-router-bootstrap';
import monarchLogo from 'assets/img/logo/monarch.png';
import titanLogo from 'assets/img/logo/titanlogo.png';
import visiVestLogo from 'assets/img/logo/visivest.png';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import spiroLogo from 'assets/img/logo/icon_spirometer.png';
import newLogo from 'assets/img/img_new_white.png';
import upArrowLogo from 'assets/img/icon_collapse.png';
import downArrowLogo from 'assets/img/icon_expand.png';
import { FootNote } from 'components/FootNote';
import { Breadcrumb, Card, ProgressBar, Modal, Button, Form, Image } from 'react-bootstrap';
import FormControlComponent from 'components/FormControlComponent';
import DatePicker from 'react-datepicker';
import urls from 'urls';
import { reverse as url_reverse } from 'named-urls';
import './PatientOverview.scss';
import { isEmpty, findLastIndex } from 'lodash';
import { uid } from 'react-uid';
import ButtonComponent from 'components/ButtonComponent';
import SelectColorDialog from 'components/SelectColorDialog';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { PDFDownloadLink } from '@react-pdf/renderer';
import moment from 'moment-timezone';
import { saveAs } from 'file-saver';
import Close from 'assets/img/close.png';

import accessMatrix from 'rolesData/accessMatrix.js';
import {
  getClinicList,
  getProviderList,
  getDiagnosisDeviceCodeList,
  getDeviceList,
  getMonthsOfYear
} from './helper';
import CustomGauge from './CustomGauge';
import Pdf from '../pdf-files/Pdf';
import SpiroReportPdf from '../pdf-files/spiroReportPdf';
import {
  therapySpan,
  spiroSpan,
  protocolTable,
  hideCustomTooltip,
  getEnhancedScoreData,
  messageService,
  getEnhancedPatientsGroupData,
  getEnhancedSpiroData,
  saveMonthChange,
  getFilteredSpiroData
} from './utils/overview';
import { allowFlag } from '../rolesData/searchMapKey';

import InfoIcon from 'assets/img/info.svg';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import { Row, Col } from 'react-bootstrap';

class PatientOverview extends React.PureComponent {
  constructor(props, context) {
    super(props, context);
    this.state = {
      isSpiroDataLoaded: false,
      updatedProtocolList: null,
      activeFromtoLable: null,
      sessionActivePage: 1,
      sessionPerPage: 10,
      sessionRange: 5,
      startDate: null,
      endDate: getEndDate(),
      selectedMonth: moment(),
      selectedYear: moment(),
      sessionSelectedMonth: [],
      testResultDate: new Date(),
      isMobile: false,
      openPopup: false,
      openLogPopup: false,
      isBlackAndWhite: true,
      viewMoreClinics: false,
      viewMoreProviders: false,
      viewMoreVestCodes: false,
      showDialog: false,
      isSpiroPdf: undefined,
      isTherapyshow: true,
      isTabView: false,
      selectedRadioType: 'all',
      error: '',
      fev1_L: '',
      fev1_P: '',
      pef_L_Min: '',
      pef_P: ''
    };
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleRangeChange = this.handleRangeChange.bind(this);
    this.changeSelectedMonth = this.changeSelectedMonth.bind(this);
    this.generatePdf = this.generatePdf.bind(this);
    this.generateSpiroPdf = this.generateSpiroPdf.bind(this);
    this.cancelDownload = this.cancelDownload.bind(this);
    this.stayWithOpen = this.stayWithOpen.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
    this.displayClinics = this.displayClinics.bind(this);
    this.toggleViewMoreClinics = this.toggleViewMoreClinics.bind(this);
    this.displayProviderList = this.displayProviderList.bind(this);
    this.toggleViewMoreVestCodes = this.toggleViewMoreVestCodes.bind(this);
    this.getDiagnosisDeviceTypeCodes = this.getDiagnosisDeviceTypeCodes.bind(
      this
    );
    this.toggleViewMoreProviders = this.toggleViewMoreProviders.bind(this);
    messageService.getMessage().subscribe(message => {
      if (message) {
        this.setState({ updatedProtocolList: message.deviceGroups, activeFromtoLable: message.activeFromTo });
      } else {
        // clear messages when empty message received

      }
    });
    this.handleChangeRadio = this.handleChangeRadio.bind(this);
  }

  componentWillMount() {
    document.addEventListener('mousedown', this.handleOutsideClick, false);
  }

  componentDidMount() {
    const {
      location,
      match,
      addBreadCrumb,
      getPatientViewData,
      // getEnhancedPatientSpiroData
    } = this.props;
    const { id } = match.params;
    // const year = this.state.selectedYear;
    // const { timeZone } = getUserData();
    // const start = year.startOf('year').format('YYYY-MM-DD');
    // const end = year.endOf('year').format('YYYY-MM-DD');
    // getEnhancedPatientSpiroData({
    //   id,
    //   start,
    //   end,
    //   timeZone
    // });
    addBreadCrumb(location, { title: strings.overview });
    this.setScreenSize();
    getPatientViewData(id);
  }

  componentWillUnmount() {
    const { resetPatientOverview, removeBreadCrumb, toggleTherapyOptions } = this.props;
    document.removeEventListener('mousedown', this.handleOutsideClick, false);
    resetPatientOverview();
    removeBreadCrumb();
    toggleTherapyOptions(true);
  }

  toggleViewMoreClinics = () => {
    this.setState({ viewMoreClinics: true });
  };

  toggleViewMoreVestCodes = () => {
    this.setState({ viewMoreVestCodes: true });
  };

  logPopup = () => {
    this.setState({ openLogPopup: true });
  }

  closeLogPopup = () => {
    this.setState({ openLogPopup: false });
    this.setState({ error: '' });
    this.setState({ testResultDate: new Date() });
  }

  onViewClick = (e) => {
    if (e.target.value === 'view') {
      this.setState({ isTabView: true });
      this.changeTabView(false);
    }
    else {
      this.setState({ isTabView: false });
      this.changeTabView(true);
    }
  }

  async handleChangeRadio(event) {
    const { value } = event.target;
    if ((value === strings.dailyTherapyAverage && this.state.selectedRadioType === 'all')
      || (value === strings.spirometry && this.state.selectedRadioType === strings.spiro)) {
      await this.setState({ selectedRadioType: strings.spiro });
    }
    else if ((value === strings.spirometry && this.state.selectedRadioType === 'all')
      || (value === strings.dailyTherapyAverage && this.state.selectedRadioType === strings.therapy)) {
      await this.setState({ selectedRadioType: strings.therapy });
    }
    else {
      await this.setState({ selectedRadioType: 'all' });
    }
  }

  handlePostLog = e => {
    const { match, postPatientSpiroData } = this.props;
    const { id } = match.params;
    const {
      testResultDate,
      fev1_L,
      fev1_P,
      pef_L_Min,
      pef_P
    } = this.state;
    this.setState({ error: '' });
    if (testResultDate === '') {
      this.setState({ error: strings.logDateRequired });
    } else if (fev1_L === '' || !(!isNaN(fev1_L) && fev1_L >= 0.01 && fev1_L <= 9.99)) {
      this.setState({ error: strings.fev1LRequired });
    } else if (fev1_P === '' || !(!isNaN(fev1_P) && fev1_L >= 0.01 && fev1_P <= 9.99)) {
      this.setState({ error: strings.fev1LPredRequired });
    } else if (pef_L_Min !== '' && !(!isNaN(pef_L_Min) && pef_L_Min >= 0.01 && pef_L_Min <= 999.99)) {
      this.setState({ error: strings.pefLMinRequired });
    } else if (pef_P !== '' && !(!isNaN(pef_P) && pef_P >= 0.01 && pef_P <= 999.99)) {
      this.setState({ error: strings.pefLMinPredRequired });
    } else {
      const payload = {
        pid: id,
        testResultDate: this.dateConvert(testResultDate),
        fev1_L,
        fev1_P,
        pef_L_Min,
        pef_P,
        type: 'clinic',
        fev1_TO_FVC_RATIO: ((fev1_L / fev1_P) * 100).toFixed(2)
      };
      postPatientSpiroData(payload);
    }
  };

  toggleViewMoreProviders = () => {
    this.setState({ viewMoreProviders: true });
  };

  getBreadCrumb = breadcrumbs => {
    if (breadcrumbs.length === 1) {
      return null;
    }
    return (
      <Breadcrumb id="patient-overview-breadcrumb">
        {breadcrumbs.map(element => (
          <LinkContainer
            key={uid(element)}
            exact
            to={`${element.path}${element.search}`}
          >
            <Breadcrumb.Item active={element.active}>
              {element.title}
            </Breadcrumb.Item>
          </LinkContainer>
        ))
        }
      </Breadcrumb>
    );
  };

  handleOutsideClick = event => {
    const therapyBarChartDiv = document.getElementById('therapy-bar-chart');
    const spiroChartDiv = document.getElementById('spiro-line-chart');
    if (therapyBarChartDiv) {
      const isClickInside = therapyBarChartDiv.contains(event.target);
      if (!isClickInside) {
        hideCustomTooltip();
      }
    }
    if (spiroChartDiv) {
      const isClickInside = spiroChartDiv.contains(event.target);
      if (!isClickInside) {
        hideCustomTooltip();
      }
    }
  };

  therapyMonthRange = () => {
    const betweenMonths = [];
    const { startDate, endDate } = this.state;
    if (!startDate) return betweenMonths;
    const startingDate = startDate.clone();

    while (
      endDate > startingDate ||
      startingDate.format('M') === endDate.format('M')
    ) {
      betweenMonths.push(startingDate.clone());
      getEndDate(startingDate.add(1, 'month'));
    }
    return betweenMonths;
  };

  spiroYearRange = () => {
    const yearsList = [];
    for (var i = 2; i >= 0; i--) {
      yearsList.push(moment().subtract(i, 'years'))
    }
    return yearsList;
  };

  handlePageChange = activePage => {
    this.setState({ sessionActivePage: activePage });
  };

  handleChange = (event, newValue) => {
    this.setState({ value: newValue });
  };

  handleRangeChange = ({ startDate, endDate }) => {
    const { match, getPatientStatsData, patient: { firstTrans } } = this.props;
    const { id } = match.params;
    const { selectedMonth } = this.state;
    const { timeZone } = getUserData();
    const start = getLatestMonth(startDate, moment.utc(firstTrans));
    this.setState({ startDate: start, endDate, timeZone });
    getPatientStatsData({
      id,
      start,
      end: getEndDate(endDate),
      timeZone
    });
    if (
      moment(selectedMonth).diff(startDate, 'months', true) < 0 ||
      moment(selectedMonth).diff(endDate, 'months', true) > 0
    ) {
      this.changeSelectedMonth(endDate);
    }
  };

  changeTabView = isTherapy => {
    const { toggleTherapyOptions } = this.props;
    if (this.state.isTherapyshow !== isTherapy) {
      this.setState({ isTherapyshow: isTherapy },
        () => toggleTherapyOptions(isTherapy));
      if (!isTherapy && !this.state.isSpiroDataLoaded) {
        const { getEnhancedPatientSpiroData, match } = this.props;
        const { id } = match.params;
        const year = this.state.selectedYear;
        const { timeZone } = getUserData();
        const start = year.startOf('year').format('YYYY-MM-DD');
        const end = year.endOf('year').format('YYYY-MM-DD');
        getEnhancedPatientSpiroData({
          id,
          start,
          end,
          timeZone
        });
        this.setState({ isSpiroDataLoaded: true });
      }
    }
  }

  changeSelectedMonth = month => {
    const { match, getEnhancedPatientTherapyData, patient: { firstTrans } } = this.props;
    const { id } = match.params;
    this.setState({ selectedMonth: month });
    const { timeZone } = getUserData();
    const start = getLatestMonth(month.startOf('month'), moment.utc(firstTrans));
    saveMonthChange(start);
    const end = getEndDate(month);
    getEnhancedPatientTherapyData({
      id,
      start,
      end,
      timeZone
    });

    this.setState({ sessionActivePage: 1 });
  };

  changeViewSpiro = (option, month) => {
    if (option === 1) {
      this.setState({
        sessionSelectedMonth: this.state.sessionSelectedMonth.concat([moment(month).format('DD/MM/YYYY')])
      })
    }
    else if (option === 0) {
      const filteredSessionMonths = this.state.sessionSelectedMonth.filter(
        value => { return value !== moment(month).format('DD/MM/YYYY') });
      this.setState({ sessionSelectedMonth: filteredSessionMonths });
    }
  }

  changeSelectedYear = year => {
    const { match, getEnhancedPatientSpiroData } = this.props;
    const { id } = match.params;
    const { timeZone } = getUserData();
    const start = year.startOf('year').format('YYYY-MM-DD');
    const end = year.endOf('year').format('YYYY-MM-DD');
    this.setState({ selectedYear: year },
      () => getEnhancedPatientSpiroData({
        id,
        start,
        end,
        timeZone
      }));


    this.setState({ sessionActivePage: 1 });
  };

  handleSetLogDate = date => {
    const from = moment(date);
    from.isValid() ? this.setState({ testResultDate: from }) : this.setState({
      testResultDate: moment()
    });

  };

  dateConvert = date => {
    const newDate = new Date(date);
    return `${newDate.getFullYear()}-${newDate.getMonth() +
      1}-${newDate.getDate()}`;
  };

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  cancelDownload = () => {
    window.location.reload();
  };

  stayWithOpen = () => {
    return false;
  };

  getDiagnosisDeviceTypeCodes = codes => {
    let list = [];
    if (codes && codes.length) {
      let code = [];
      code.push(codes[0]);
      list.push(getDiagnosisDeviceCodeList(code));
    }
    if (codes && codes.length > 1 && !this.state.viewMoreVestCodes) {
      list.push(
        <span
          className="viewMoreTab d-inline-block"
          onClick={this.toggleViewMoreVestCodes}
        >
          {` +${codes.length - 1} more`}
        </span>
      );
    }
    if (codes && codes.length > 1 && this.state.viewMoreVestCodes) {
      list.push(getDiagnosisDeviceCodeList(codes.slice(1, codes.length)));
    }
    if (!codes || !codes.length) {
      list.push(
        <React.Fragment>
          <div className="breaker" />
          <span className="mr-3 d-inline-block">
            <span className="key text-capitalize">
              {strings.diagnosisCode}:{' '}
            </span>
            <span className="text">{'-'}</span>
          </span>
        </React.Fragment>
      );
    }
    return list;
  };

  displayClinics = clinics => {
    const list = [];
    if (clinics && clinics.length) {
      const clinic = [];
      clinic.push(clinics[0]);
      list.push(getClinicList(clinic));
    }
    if (clinics && clinics.length > 1 && !this.state.viewMoreClinics) {
      list.push(
        <span
          className="viewMoreTab d-inline-block"
          onClick={this.toggleViewMoreClinics}
        >
          {` +${clinics.length - 1} more`}
        </span>
      );
    }
    if (clinics && clinics.length > 1 && this.state.viewMoreClinics) {
      list.push(getClinicList(clinics.slice(1, clinics.length)));
    }
    if (!clinics || !clinics.length) {
      list.push(
        <React.Fragment>
          <div className="breaker" />
          <span className="mr-3 mt-3 d-inline-block clinic-id-label">
            <span className="key text-capitalize">{strings.clinicId}: </span>
            <span className="text">{'-'}</span>
          </span>
          <span className="mr-3 mt-3 d-inline-block">
            <span className="key text-capitalize">{strings.clinic}: </span>
            <span className="text">{'-'}</span>
          </span>
        </React.Fragment>
      );
    }
    return list;
  };

  displayProviderList = providers => {
    const list = [];
    if (providers && providers.length) {
      const provider = [];
      provider.push(providers[0]);
      list.push(getProviderList(provider));
    }
    if (providers && providers.length > 1 && !this.state.viewMoreProviders) {
      list.push(
        <span
          className="viewMoreTab d-inline-block"
          onClick={this.toggleViewMoreProviders}
        >
          {` +${providers.length - 1} more`}
        </span>
      );
    }
    if (providers && providers.length > 1 && this.state.viewMoreProviders) {
      list.push(getProviderList(providers.slice(1, providers.length)));
    }
    if (!providers || !providers.length) {
      list.push(
        <React.Fragment>
          <div className="breaker" />
          <span className="mr-3 mt-3 d-inline-block">
            <span className="key text-capitalize">{strings.provider}: </span>
            <span className="text">{'-'}</span>
          </span>
        </React.Fragment>
      );
    }
    return list;
  };

  saveFileAsPdf = blob => {
    this.props.setPdfDownloadStatus(false);
    saveAs(blob, 'Summary Report.pdf');
    this.props.resetPdfData();
    this.setState({ isSpiroPdf: undefined });
  };

  saveSpiroFileAsPdf = blob => {
    this.props.setPdfDownloadStatus(false);
    saveAs(blob, 'Spiro Report.pdf');
    this.props.resetPdfData();
    this.setState({ isSpiroPdf: undefined });
  };

  async generatePdf() {
    this.setState({ showDialog: true, isSpiroPdf: false });
  }

  async generateSpiroPdf() {
    this.setState({ showDialog: true, isSpiroPdf: true });
  }

  handleColorChange = isBlackAndWhite => {
    this.setState({ isBlackAndWhite, showDialog: false });
    const { match, getEnhancedPatientsTherapyData, setTypeOfPdf } = this.props;
    const { id } = match.params;
    const patientIds = [id];
    const { startDate, endDate, isSpiroPdf } = this.state;
    const { timeZone } = getUserData();
    this.setState({ openPopup: true });

    getEnhancedPatientsTherapyData({
      patientIds,
      start: startDate,
      end: getEndDate(endDate),
      timeZone,
      id,
      isSpiroPdf
    });

    this.props.setPdfDownloadStatus(true);

    setTypeOfPdf(isBlackAndWhite);
  };

  componentWillReceiveProps(nextProps) {
    if (
      this.props.isAllowed === true &&
      this.state.openPopup === true &&
      nextProps.isAllowed === false
    ) {
      this.setState({ openPopup: false });
    }
    const { patient } = nextProps;
    if (nextProps.spiroDataLogStatus !== undefined && nextProps.spiroDataLogStatus !== null) {
      this.closeLogPopup();
      const { id, firstTrans } = patient;
      const { selectedMonth, endDate } = this.state;
      const { timeZone } = getUserData();
      const { resetSpiroDataLogStatus, getPatientStatsData, getEnhancedPatientSpiroData } = this.props;
      const start = getLatestMonth(selectedMonth.startOf('month'), moment.utc(firstTrans));
      const year = this.state.selectedYear;
      const spiroStart = year.startOf('year').format('YYYY-MM-DD');
      const spiroEnd = year.endOf('year').format('YYYY-MM-DD');
      this.setState({ isTabView: true });
      this.changeTabView(false);
      getPatientStatsData({
        id,
        start,
        end: getEndDate(endDate),
        timeZone
      });
      getEnhancedPatientSpiroData({
        id,
        start: spiroStart,
        end: spiroEnd,
        timeZone
      });
      this.setState({ testResultDate: new Date() });
      resetSpiroDataLogStatus();
    }
    if (nextProps.isTherapyOption !== undefined && nextProps.isTherapyOption !== this.state.isTherapyshow) {
      this.changeTabView(nextProps.isTherapyOption);
    }
    if (patient.id && patient.id !== this.props.patient.id) {
      const { id, firstTrans } = patient;
      const date1 = getMonthsAgoDate(constants.DEFAULT_MONTH_RANGE).startOf('month');
      const date2 = moment.utc(firstTrans);
      const startDate = getLatestMonth(date1, date2);
      this.setState({ startDate });
      const { getPatientOverviewData } = this.props;
      const { selectedMonth, endDate } = this.state;
      const { timeZone } = getUserData();
      const monthStart = getLatestMonth(selectedMonth.startOf('month'), moment.utc(firstTrans));
      const monthEnd = getEndDate(selectedMonth);

      getPatientOverviewData(
        id,
        startDate,
        endDate,
        monthStart,
        monthEnd,
        timeZone
      );
    }
  }

  hideSessionsCompletedPopover = () => {
    this.sessionsCompetedOverlayRef.hide();
  };

  hideMinutesCompletedPopover = () => {
    this.minutesCompletedOverlayRef.hide();
  };

  hideMySpiroPopover = () => {
    this.mySpiroOverlayRef.hide();
  };

  hideMyScorePopover = () => {
    this.myScoreOverlayRef.hide();
  };

  render() {
    const {
      patient,
      enhancedScoreCard,
      breadcrumbs,
      history,
      pClinics,
      pProviders,
      addBreadCrumb,
      enhancedGroupData,
      enhancedSiproData,
      patientStats,
      handleFlag,
    } = this.props;

    const {
      patientsData,
      minuteGaugeGraph,
      sessionGaugeGraph,
      barCharts,
      lineCharts
    } = enhancedGroupData;

    const { match, location } = this.props;
    const { id } = match.params;
    const { isBlackAndWhite, openPopup } = this.state;
    let sessionGauge = {};
    let minuteGauge = {};
    const deviceRef = {
      TITAN: [strings.titan, titanLogo, 'titan'],
      MONARCH: [strings.monarch, monarchLogo, 'monarch'],
      VEST: [strings.vest, visiVestLogo, 'visivest'],
    };
    const {
      sessionActivePage,
      sessionPerPage,
      sessionRange,
      startDate,
      endDate,
      selectedMonth,
      selectedYear,
      isMobile,
      isTherapyshow,
      isTabView,
      openLogPopup,
      testResultDate,
      error,
      selectedRadioType,
      sessionSelectedMonth,
      isSpiroPdf
    } = this.state;
    const { actualRole } = getUserData();
    const myScoreInformation = accessMatrix.PATIENT_MY_SCORE[actualRole];
    const flagPatient = accessMatrix.FLAG_PATIENT[actualRole];

    const progressTime = this.props.progressTime;
    var filteredSpiroData = {};
    if (!isEmpty(enhancedSiproData.data)) {
      filteredSpiroData = getFilteredSpiroData(enhancedSiproData, selectedRadioType, false, false);
    }

    var sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: url_reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview,
          options: [

          ]
        },
        {
          href: url_reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: url_reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    if (isTabView) {
      sideBarData = {
        activeKey: location.pathname,
        menu: [
          {
            href: url_reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
            text: strings.overview,
            options: [
              {
                text: strings.therapyDuration,
                isTherapyOption: true,
                isTherapyshow: isTherapyshow
              },
              {
                text: strings.spiroData,
                isTherapyOption: false,
                isTherapyshow: !isTherapyshow
              }
            ]
          },
          {
            href: url_reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
            text: strings.patientDetails
          },
          {
            href: url_reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
            text: strings.carePlanAndDevice
          }
        ]
      };
    }
    if (!isEmpty(patientStats)) {
      sessionGauge = {
        percentage: patientStats.completed_sessions_percentage,
        done: patientStats.total_completed_sessions,
        recommended: patientStats.total_sessions,
        headText: strings.o_completedSessions
      };
      minuteGauge = {
        percentage: patientStats.completed_minutes_percentage,
        done: patientStats.total_completed_minutes,
        recommended: patientStats.total_minutes,
        headText: strings.completedMinutes
      };
    }
    let sessionCount = 0;

    var monthsArray = getMonthsOfYear(selectedYear);
    // let sessionListSpiroItems = (
    //   <tr>
    //     <td colSpan="3" className="text-center text-capitalize">
    //       {strings.noSessionData}
    //     </td>
    //   </tr>
    // );
    // if (!isEmpty(patientStats) && patientStats.spiroScore !== null) {
    let sessionListSpiroItems = monthsArray.map((month, idx) => {
      const { monthlyAvgTherapy, therapySpans, highestSpiro, spiroSpans } = spiroSpan(
        month, idx
      );
      return (
        <tr key={uid(month)}>
          <td width="150" className="align-middle">
            {moment(month).format('MMM YYYY')}
          </td>
          <td>{monthlyAvgTherapy > 0 ? monthlyAvgTherapy : 0} Mins {sessionSelectedMonth.indexOf(moment(month).format('DD/MM/YYYY')) !== -1 ? therapySpans : null}</td>
          <td className="d-none d-sm-table-cell">{(sessionSelectedMonth.indexOf(moment(month).format('DD/MM/YYYY')) === -1
            && highestSpiro > 0) ? highestSpiro + '%' : null}</td>
          <td className="d-none d-sm-table-cell">
            {sessionSelectedMonth.indexOf(moment(month).format('DD/MM/YYYY')) !== -1 ?
              <React.Fragment>
                <div className="d-inline-block ml cursor float-right"
                  onClick={() => this.changeViewSpiro(0, month)} >
                  <img
                    src={upArrowLogo}
                    width="15"
                    height="10"
                    alt="up"
                  />
                </div>
                <div className="mt-5">
                  {spiroSpans}
                </div>
              </React.Fragment>
              :
              (monthlyAvgTherapy > 0 || highestSpiro > 0) ? (<div className="d-inline-block ml float-right cursor"
                onClick={() => this.changeViewSpiro(1, month)}>
                <img
                  src={downArrowLogo}
                  width="15"
                  height="10"
                  alt="down"
                />
              </div>) :
                null
            }
          </td>
        </tr >
      );
    });
    // }

    let sessionListItems = (
      <tr>
        <td colSpan="3" className="text-center text-capitalize">
          {strings.noSessionData}
        </td>
      </tr>
    );
    let indexOfLastSession;
    let indexOfFirstSession;
    let currentSessionList;
    const { sessionTable } = enhancedScoreCard;
    if (
      sessionTable &&
      sessionTable.dates.length &&
      sessionTable.dateGroupData
    ) {
      sessionCount = sessionTable.dates.length;
      indexOfLastSession = sessionActivePage * sessionPerPage;
      indexOfFirstSession = indexOfLastSession - sessionPerPage;
      const scoreDates = [...sessionTable.dates];
      currentSessionList = scoreDates.slice(
        indexOfFirstSession,
        indexOfLastSession
      );

      sessionListItems = currentSessionList.map(date => {
        const { duration, spans, deviated } = therapySpan(
          sessionTable.dateGroupData,
          date,
          sessionTable.protocolDuration,
          deviceRef
        );
        return (
          <tr key={uid(date)}>
            <td width="150" className="align-middle">
              {moment(date).format('MMM DD')}
            </td>
            <td className="d-none d-sm-table-cell">{spans}</td>
            <td className="align-middle">
              <span>{duration} mins</span>
              {deviated ? <span className="deviated-day"></span> : null}
            </td>
            {/* <td className="d-none d-sm-table-cell">{spiroSpans}</td> */}
          </tr>
        );
      });
    }
    const therapyMonthSelect = (
      <div className="d-block d-sm-none p-4 select-wrapper">
        <select
          onChange={event => {
            this.changeSelectedMonth(moment(parseInt(event.target.value, 10)));
          }}
        >
          {this.therapyMonthRange().map((month, idx) => {
            const active = selectedMonth.isSame(month, 'month');
            return (
              <option value={month} key={uid(month)} selected={active}>
                {month.format('MMM YYYY')}
              </option>
            );
          })}
        </select>
        <span className="custom-dropdown-indicator" role="presentation" />
      </div>
    );
    const therapyMonthRangeItems = this.therapyMonthRange().map(
      (month, idx) => {
        const active = selectedMonth.isSame(month, 'month');
        const lastChild = findLastIndex(this.therapyMonthRange()) === idx;
        return (
          <div
            key={uid(month, idx)}
            role="presentation"
            onClick={() => this.changeSelectedMonth(month)}
            onKeyDown={() => this.changeSelectedMonth(month)}
            className={`d-none d-sm-inline-block px-0 mx-2 pt-4 mb-auto therapy-month text-uppercase cursor${active ? ' active' : ''
              } ${lastChild ? ' mr-4' : ''}`}
          >
            {month.format("MMM 'YY")}
          </div>
        );
      }
    );

    const spiroYearRangeItems = this.spiroYearRange().map(
      (year, idx) => {
        const active = selectedYear.isSame(year, 'year');
        const lastChild = findLastIndex(this.spiroYearRange()) === idx;
        return (
          <div
            key={uid(year, idx)}
            role="presentation"
            onClick={() => this.changeSelectedYear(year)}
            onKeyDown={() => this.changeSelectedYear(year)}
            className={`d-none d-sm-inline-block px-0 mx-3 mb-auto therapy-month text-uppercase cursor${active ? ' active' : ''
              } ${lastChild ? ' mr-4' : ''}`}
          >
            {year.format("YYYY")}
          </div>
        );
      }
    );

    let showBack = true;
    let showBrand = false;
    let showToggle = false;
    if (getUserData().role === constants.ROLES.PATIENT) {
      showBack = false;
      showBrand = true;
      showToggle = true;
    }

    const printButton = (
      <div>
        <div className="float-right" style={{ display: 'inline-block' }}>
          {!isMobile && patientStats !== undefined && patientStats.spiroScore !== undefined &&
            patientStats.spiroScore !== null && (
              <ButtonComponent
                buttonClass={isMobile ? '' : 'ml-4 spirometry-report'}
                buttonAction={this.generateSpiroPdf}
                icon="report-detail-icon"
                buttonText={strings.SPIROMETRYREPORT}
              />
            )}
        </div>
        <div id="print-button">
          <div className="text-right">
            <ButtonComponent
              icon="report-detail-icon"
              buttonText={strings.VIEWDETAILREPORT}
              buttonAction={() => {
                addBreadCrumb(location, {
                  title: strings.detailReport
                });
                history.push(
                  url_reverse(
                    urls.PATIENT.DETAIL.OVERVIEW.DETAILREPORT,
                    { id }
                  )
                );
              }}
            />
            {!isMobile && (
              <ButtonComponent
                buttonClass={isMobile ? '' : 'ml-4'}
                buttonAction={this.generatePdf}
                icon="report-detail-icon"
                buttonText={strings.PRINTSUMMARYREPORT}
              />
            )}
          </div>
        </div>

      </div>

    );

    const sessionsCompetedPopover = (
      <Popover id="sessions-completed-info">
        <Popover.Title>
          <Row className="justify-content-between align-items-center">
            <Col className="info-title">
              {strings.completedSessionsInfo.title}
            </Col>
            <Col>
              <span
                className="black-cross-small float-right close-icon"
                onClick={this.hideSessionsCompletedPopover}
              ></span>
            </Col>
          </Row>
        </Popover.Title>
        <Popover.Content>
          <div className="info-section" key="1">
            <p>What is Completed Sessions?</p>
            <ul>
              <li key="1">A percentage calculating how many therapy sessions were completed per day compared to the prescribed number or sessions, during the selected date range.</li>
            </ul>
          </div>
          <div className="info-section" key="2">
            <p>How is Completed Sessions calculated?</p>
            <ul>
              <li key="1">The Connex® Technology looks at the prescribed protocol to determine number of therapy sessions, and the duration of each session that should be performed daily.</li>
              <li key="2">The percentage is calculated based on the number of fully completed sessions per day, divided by the number of daily sessions prescribed, for the selected date range.</li>
              <li key="3">A session is only considered complete if it meets or surpasses the prescribed duration of the session.
                <ul>
                  <li key="1">If a therapy session is performed, but not to the prescribed treatment time, it will not be considered a completed session but will be captured in “Completed Minutes”.</li>
                </ul>
              </li>
              <li key="4">Completed Sessions is limited to the number of prescribed sessions per day, per the prescribed protocol.
                <ul>
                  <li key="1">If the prescription indicates two 30 minutes treatments, but patient does four 30 minute sessions, they will only get credit for 2 Completed Sessions, per the protocol. The extra therapy time will be represented in the “Completed Minutes”.</li>
                </ul>
              </li>
            </ul>
          </div>
          <div className="info-section" key="3">
            <p>Example of Completed Sessions calculation</p>
            <ul>
              <li key="1">If the selected date range is set at 3 months and the patient's prescribed protocol is for 30 minutes twice a day, they should have 2 therapy session per day for a total of 180 sessions during that 3 month time frame. If the patient finishes 2 sessions per day for a total of 180 therapies for the prescribed duration they would have 100% Completed Sessions.</li>
              <li key="2">If the patient only finishes 100 therapies to their prescribed duration, they would have 55% Completed Sessions.</li>
              <li key="3">If the patient completed 180 therapies, but had days where they completed four 30 minutes sessions and days where they did not complete any therapy, this would reduce their completed sessions percentage.</li>
              <li key="4">If a patient exceeds the prescribed number of sessions or duration of sessions per day, the additional session(s) and/or minutes would not be counted towards their completed sessions percentage, but would be counted in their Completed Minutes percentage.</li>
            </ul>
          </div>
          {strings.completedSessionsInfo.notes.map((para, index) => (
            <p key={index}>*{para}</p>
          ))}
        </Popover.Content>
      </Popover>
    );

    const minutesCompletedPopover = (
      <Popover id="minutes-completed-info">
        <Popover.Title>
          <Row className="justify-content-between align-items-center">
            <Col className="info-title">
              {strings.completedMinutesInfo.title}
            </Col>
            <Col>
              <span
                className="black-cross-small float-right close-icon"
                onClick={this.hideMinutesCompletedPopover}
              ></span>
            </Col>
          </Row>
        </Popover.Title>
        <Popover.Content>
          {strings.completedMinutesInfo.content.map((para, index) => (
            <div className="info-section" key={index}>
              <p>{para.title}</p>
              <ul>
                {para.items.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
          {strings.completedMinutesInfo.notes.map((para, index) => (
            <p key={index}>*{para}</p>
          ))}
        </Popover.Content>
      </Popover>
    );

    const mySpiroPopover = (
      <Popover id="my-spiro-info">
        <Popover.Title>
          <Row className="justify-content-between align-items-center">
            <Col className="info-title">{strings.mySpiroInfo.title}</Col>
            <Col>
              <span
                className="black-cross-small float-right close-icon"
                onClick={this.hideMySpiroPopover}
              ></span>
            </Col>
          </Row>
        </Popover.Title>
        <Popover.Content>
          <div className="info-section" key="1">
            <p>What is mySpiro?</p>
            <ul>
              <li key="1">When connected to a SmartOne® Spirometer, mySpiro will reflect the most recent FEV1 Score.  The Smart One®  spirometer allows patients to track their lung health over time, along with their vest therapy data, in the Connex App. It is available for purchase through Hillrom with no medical prescription required. Patients can contact Hillrom Respiratory Health at <a href="tel:800-426-4224" style={{ color: "blue" }}>800-426-4224</a> or email <a href="mailto:HCCSWeb@Hillrom.com" style={{ color: "blue" }}>HCCSWeb@Hillrom.com</a>.</li>
            </ul>
          </div>
        </Popover.Content>
      </Popover>
    );

    const myScorePopover = (
      <Popover id="my-score-info">
        <Popover.Title>
          <Row className="justify-content-between align-items-center">
            <Col className="info-title">{strings.myScoreInfo.title}</Col>
            <Col>
              <span
                className="black-cross-small float-right close-icon"
                onClick={this.hideMyScorePopover}
              ></span>
            </Col>
          </Row>
        </Popover.Title>
        <Popover.Content>
          {strings.myScoreInfo.content.map((para, index) => (
            <div className="info-section" key={index}>
              <p>{para.title}</p>
              <ul>
                {para.items.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
          {strings.myScoreInfo.notes.map((para, index) => (
            <p key={index}>*{para}</p>
          ))}
        </Popover.Content>
      </Popover>
    );

    const { deviceType } = patient;
    const deviceList = getDeviceList(deviceType, patientStats);
    return (
      <div>
        {barCharts !== undefined &&
          Object.keys(barCharts).length !== 0 &&
          Object.values(barCharts)}
        {lineCharts !== undefined &&
          Object.keys(lineCharts).length !== 0 &&
          Object.values(lineCharts)}
        {minuteGaugeGraph !== undefined &&
          Object.keys(minuteGaugeGraph).length !== 0 && (
            <div style={{ display: 'none' }}>
              {Object.values(minuteGaugeGraph)}
            </div>
          )}
        {sessionGaugeGraph !== undefined &&
          Object.keys(sessionGaugeGraph).length !== 0 && (
            <div style={{ display: 'none' }}>
              {Object.values(sessionGaugeGraph)}
            </div>
          )}
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.PATIENT.ALL}
          showBack={showBack}
          showBrand={showBrand}
          showToggle={showToggle}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div className="patient-overview">
              {!isMobile && (
                <div>
                  {this.getBreadCrumb(breadcrumbs)}
                  {printButton}
                </div>
              )}
              <div
                className={`${isMobile ? 'mb-4' : 'mt-2 mb-4'} patient-name`}
              >
                {flagPatient.read ? (
                  flagPatient.write ? (
                    <span
                      onClick={e => {
                        handleFlag(
                          patient.id,
                          patient.patient_id,
                          patient.flagged,
                          allowFlag[actualRole]
                        );
                      }}
                      className={`align-middle d-inline-block patient-flag cursor ${patient.flagged ? 'hr-flag' : 'disable-flag'
                        }`}
                    />
                  ) : patient.flagged ? (
                    <span className="align-middle d-inline-block patient-flag hr-flag" />
                  ) : null
                ) : null}
                {[patient.firstName, patient.lastName]
                  .filter(Boolean)
                  .join(' ')}
              </div>
              {isMobile && printButton}
              <div
                style={isMobile ? { marginTop: '1rem' } : {}}
                className="row align-items-end patient-info-and-date-box"
              >
                <div className="col-12 col-md-9 patient-info d-flex flex-column flex-sm-row flex-wrap">
                  <span className="mr-3 d-inline-block">
                    <span className="key text-capitalize">
                      {strings.status}:{' '}
                    </span>
                    <span className="text text-capitalize">
                      {patient.isDeleted ? strings.inactive : strings.active}{' '}
                      {patient.isDeleted && patient.inactiveReason
                        ? `(${patient.inactiveReason})`
                        : ''}
                    </span>
                  </span>
                  <span className="mr-3 d-inline-block">
                    <span className="key text-capitalize">
                      {strings.o_hillromId}:{' '}
                    </span>
                    <span className="text">{patient.hillromId}</span>
                  </span>
                  <span className="mr-3 d-inline-block">
                    <span className="key text-capitalize">{strings.dob}: </span>
                    <span className="text">
                      {`${moment(patient.dob).isValid()
                        ? moment.tz(patient.dob, 'UTC').format('DD MMM YYYY')
                        : '-'
                        }`}
                    </span>
                  </span>
                  {this.getDiagnosisDeviceTypeCodes(getDeviceTypeList(patient))}
                  {this.displayProviderList(pProviders)}
                  {this.displayClinics(pClinics)}
                </div>
                <div className="col-12 col-md-3 text-right dateSelection">
                  {isTherapyshow ? <RangeMonthlyPicker
                    startDate={startDate}
                    endDate={endDate}
                    onChange={this.handleRangeChange}
                    min={patient.firstTrans}
                  /> : null}
                </div>
              </div>
              <div className="patient-therapy-numbers row">
                {!isEmpty(patientStats) && (
                  <div className="col-12 col-md-4 patient-overview-gauge-container pr-0">
                    <div className="row">
                      <CustomGauge data={sessionGauge}>
                        <OverlayTrigger
                          trigger="click"
                          placement="right"
                          overlay={sessionsCompetedPopover}
                          ref={ref => (this.sessionsCompetedOverlayRef = ref)}
                          rootClose
                        >
                          <img
                            className="popover-info-icon"
                            src={InfoIcon}
                            alt="Info"
                            role="presentation"
                          />
                        </OverlayTrigger>
                      </CustomGauge>
                      <CustomGauge data={minuteGauge}>
                        <OverlayTrigger
                          trigger="click"
                          placement="top"
                          overlay={minutesCompletedPopover}
                          ref={ref => (this.minutesCompletedOverlayRef = ref)}
                          rootClose
                        >
                          <img
                            className="popover-info-icon"
                            src={InfoIcon}
                            alt="Info"
                            role="presentation"
                          />
                        </OverlayTrigger>
                      </CustomGauge>
                    </div>
                  </div>
                )}
                {!isEmpty(patientStats) && (
                  <div className="row flex-column col-12 col-md-8 justify-content-around pr-0 pl-0">
                    <div className="therapy-main row">
                      <div className="col-6 col-md-2">
                        <div className="row boxed therapy-info py-md-4">
                          <span className="number col pl-0">
                            {patientStats.total_completed_sessions}
                          </span>
                          <span className="text col pl-0">
                            {strings.o_completedSessions}
                          </span>
                        </div>
                      </div>
                      <div className="col-6 col-md-2">
                        <div className="row boxed therapy-info py-md-4 align-items-center">
                          <span className="number col pl-0">
                            {patientStats.missed_sessions}
                          </span>
                          <span className="text col pl-0">
                            {strings.missedSession}
                          </span>
                        </div>
                      </div>
                      <div className="col-12 col-md-4">
                        <div className="row boxed therapy-info my-score-info py-md-4 justify-content-center">
                          <span className="number col-md-3 pl-1">
                            <span>{patientStats.myScore}</span>
                          </span>
                          <span className="text col-md-4 px-0">
                            <div className="d-flex align-items-center justify-content-center">
                              <span>{strings.myScore}</span>
                            </div>
                            {patientStats.myScore !== 0 ? (
                              <div className="ml-0">
                                {patientStats.myScoreDiff}
                                <span
                                  className={`trend-arrow ml-1 ${patientStats.myScoreDiff >= 0
                                    ? 'positive'
                                    : 'negative'
                                    } d-inline-block`}
                                />
                              </div>
                            ) : null}
                          </span>
                          <span
                            className={`my-score-info-container ${patientStats.myScore !== 0
                              ? 'align-self-start'
                              : ''
                              }`}
                          >
                            <OverlayTrigger
                              trigger="click"
                              placement="left"
                              overlay={myScorePopover}
                              ref={ref => (this.myScoreOverlayRef = ref)}
                              rootClose
                            >
                              <img
                                className="popover-info-icon"
                                src={InfoIcon}
                                alt="Info"
                                role="presentation"
                              />
                            </OverlayTrigger>
                          </span>
                          {myScoreInformation.write ? (
                            <span className="col col-md-3 pl-0 text-right m-auto pr-0">
                              <Link
                                to={`${url_reverse(
                                  urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL,
                                  {
                                    id
                                  }
                                )}#reset-myscore`}
                                className="btn btn-sm btn-outline-info text-upper pt-2"
                                role="button"
                              >
                                {strings.reset}
                              </Link>
                            </span>
                          ) : null}
                        </div>
                      </div>
                      <div className="col-6 col-md-4 spirometer-badge">
                        <div className="row boxed therapy-info px-md-2 py-md-4 d-flex align-items-center justify-content-between">
                          <div>
                            <img
                              src={spiroLogo}
                              width="12"
                              height="18"
                              alt="Spiro"
                            />
                          </div>
                          <div style={{ marginTop: '-28%', marginLeft: '-20%' }}>
                            <img
                              src={newLogo}
                              width="25"
                              height="25"
                              alt="Spiro"
                            />
                          </div>
                          <div className="">
                            {(patientStats.spiroScore === undefined || patientStats.spiroScore === null) ? 'NA' : patientStats.spiroScore + '%'}
                          </div>
                          <div>
                            <div className="d-flex">
                              <span>{strings.mySpiro}</span>
                            </div>
                            <div className="ml-0 text-left">
                              FEV<sub>1</sub>% (Pred)
                            </div>
                          </div>

                          <div>
                            <span
                              className={`my-score-info-container
                                  `}
                            >
                              <OverlayTrigger
                                trigger="click"
                                placement="left"
                                overlay={mySpiroPopover}
                                ref={ref => (this.mySpiroOverlayRef = ref)}
                                rootClose
                              >
                                <img
                                  className="popover-info-icon"
                                  src={InfoIcon}
                                  alt="Info"
                                  role="presentation"
                                />
                              </OverlayTrigger>
                            </span>
                          </div>

                          <div>
                            {patientStats.spiroScore === null ?
                              <span className="text">
                                <input type="button" value="Log" onClick={this.logPopup} style={{ backgroundColor: '#739ddb', color: 'white' }}
                                  className={`btn btn-sm text-upper pt-2 log-button
                            ${(actualRole === constants.ROLES.CUSTOMER_SERVICES ||
                                      actualRole === constants.ROLES.ASSOCIATE_EXECUTIVE) ? 'd-none' : ''}
                          `}></input>
                              </span> :
                              <span className="text">
                                {!isTabView ? <input type="button" value="view" onClick={this.onViewClick} className="btn btn-sm btn-outline-info text-upper pt-2"></input>
                                  : <input type="button" value="back" onClick={this.onViewClick} className="btn btn-sm btn-outline-info text-upper pt-2"></input>}
                              </span>
                            }
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="therapy-device row">
                      {deviceList.map(dType => (
                        <div className={`col-md-${deviceList.length > 1 ? 4 : 12} mt-3 device`} key={uid(dType)}>
                          <div className={`mt-4 mb-1 d-block d-sm-none mobile-device-name ${deviceRef[dType][2]}-logo-text`}>
                            <img
                              src={deviceRef[dType][1]}
                              width="32"
                              height="32"
                              className="d-inline-block device-logo"
                              alt={deviceRef[dType][0]}
                            />
                            {deviceRef[dType][0]}
                          </div>
                          <div className="boxed row py-md-4 px-sm-2 px-4 mr-auto d-flex flex-row justify-content-between align-items-center">
                            <div className="device-logo-content d-none d-sm-inline">
                              {
                                (deviceRef[dType][0] === strings.vest && patient.deviceName !== null
                                  && patient.isManual) ?
                                  <img
                                    src={manualLogo}
                                    className="d-inline-block manual-logo-pad"
                                    alt={'Manual Device'}
                                    style={{
                                      height: "auto", width: "auto"
                                    }}
                                  />
                                  :
                                  <img
                                    src={deviceRef[dType][1]}
                                    width="48"
                                    height="48"
                                    className="d-inline-block"
                                    alt={deviceRef[dType][0]}
                                  />
                              }
                            </div>
                            <div className="device-info d-flex flex-row mt-2">
                              <div className="number-info">
                                {patientStats[`${dType.toLowerCase()}_sessions`]}
                              </div>
                              <div className="label">
                                {strings.o_completedSessions}
                              </div>
                            </div>
                            <div className="device-info d-flex flex-row mt-2">
                              <div className="number-info">
                                {patientStats[`${dType.toLowerCase()}_minutes`]}
                              </div>
                              <div className="label">
                                {strings.completedMinutes}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <Modal show={openPopup} onHide={this.stayWithOpen} centered>
                <Modal.Header className="justify-content-center bg-white">
                  <Modal.Title className="text-dark text-uppercase">
                    {strings.downloading}
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body className="mt-4 mb-4 justify-content-center">
                  <ProgressBar
                    striped
                    variant="dark"
                    role="progressbar"
                    animated
                    now={progressTime}
                    label={`${progressTime}%`}
                    style={{ height: '2rem', width: '100%' }}
                  />
                </Modal.Body>
                <Modal.Footer className="justify-content-center">
                  <Button variant="white" onClick={this.cancelDownload}>
                    {strings.cancel}
                  </Button>
                </Modal.Footer>
              </Modal>

              <Modal show={openLogPopup} onHide={this.stayWithOpen} centered className="log-popup">
                <Modal.Header className="bg-white">
                  <Modal.Title className="text-dark">
                    {strings.enterPftReault}
                  </Modal.Title>
                  <Image
                    src={Close}
                    width="17"
                    height="17"
                    onClick={this.closeLogPopup}
                    className="d-inline-block cursor-pointer"
                    alt="Report Detail Icon"
                  />
                </Modal.Header>
                <Modal.Body className="mb-4 justify-content-center">
                  <Form>
                    <Form.Row>
                      <Form.Group as={Col} md={8}>
                        <Form.Label htmlFor="reset">{strings.date} <span className="asterisk-color">*</span></Form.Label>
                        <br />
                        <DatePicker
                          className="custom-select"
                          name="testResultDate"
                          minDate={new Date(moment().subtract(60, 'days').format('MM-DD-YYYY'))}
                          maxDate={new Date()}
                          dateFormat="MM/dd/yyyy"
                          selected={new Date(Date.parse(moment(testResultDate)))}
                          onChange={this.handleSetLogDate}
                        />
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md={3}>
                        <Form.Label htmlFor="reset">{strings.fev1L} <span className="asterisk-color">*</span></Form.Label>
                        <br />
                        <FormControlComponent
                          type="text"
                          name="fev1_L"
                          onChange={this.handleChange}
                          defaultValue=''
                          required=""
                          placeholder="0.01-9.99"
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={3}>
                        <Form.Label htmlFor="reset">{strings.fev1LPred} <span className="asterisk-color">*</span></Form.Label>
                        <br />
                        <FormControlComponent
                          type="text"
                          name="fev1_P"
                          onChange={this.handleChange}
                          defaultValue=''
                          required=""
                          placeholder="0.01-9.99"
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={3}>
                        <Form.Label htmlFor="reset">{strings.pefLMin}</Form.Label>
                        <br />
                        <FormControlComponent
                          type="text"
                          name="pef_L_Min"
                          onChange={this.handleChange}
                          defaultValue=''
                          required=""
                          placeholder="0.01-999.99"
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={3}>
                        <Form.Label htmlFor="reset">{strings.pefLMinPred}</Form.Label>
                        <br />
                        <FormControlComponent
                          type="text"
                          name="pef_P"
                          onChange={this.handleChange}
                          defaultValue=''
                          required=""
                          placeholder="0.01-999.99"
                        />
                      </Form.Group>
                    </Form.Row>
                    <p className="text-danger" id="error-message">
                      {error}
                    </p>
                    <hr />
                    <div>
                      <ButtonComponent
                        id="add-announcement-bottom"
                        buttonClass="float-right"
                        buttonAction={this.handlePostLog}
                        icon="right-arrow"
                        buttonText={strings.log}
                      />
                      <ButtonComponent
                        id="add-announcement-bottom"
                        buttonClass="float-right mr-4"
                        buttonAction={this.closeLogPopup}
                        icon="cancel-icon"
                        buttonText={strings.cancel}
                      />
                    </div>
                  </Form>
                </Modal.Body>
              </Modal>

              <Card className="therapy-duration-chart-card">
                {!isTabView ?
                  null
                  :
                  <div style={{ backgroundColor: '#dce4f1b0' }}>
                    <div
                      role="presentation"
                      onClick={() => this.changeTabView(true)}
                      onKeyDown={() => this.changeTabView(true)}
                      className={`float-left text-uppercase tab-heading pad-10 cursor${isTherapyshow ? ' active' : ''
                        }`}
                    >
                      {strings.therapyDuration}
                    </div>
                    <div
                      role="presentation"
                      onClick={() => this.changeTabView(false)}
                      onKeyDown={() => this.changeTabView(false)}
                      className={`float-left text-uppercase tab-heading pad-10 cursor${!isTherapyshow ? ' active' : ''
                        }`}
                    >
                      {strings.spiroData}
                    </div>
                  </div>
                }
                <Card.Body>
                  {isTherapyshow ? <div>
                    <div className={
                      "d-flex therapy-duration" +
                      (isTabView ? " hideHcolor" : "")}>
                      <p className="mr-auto card-title  p-4">
                        {!isTabView ? strings.therapyDuration : null}
                      </p>
                      {therapyMonthSelect}
                      {therapyMonthRangeItems}
                    </div>
                    {!isEmpty(enhancedScoreCard.barChart) ? (
                      <div id="therapy-bar-chart" className="chart-wrapper">
                        <Bar
                          id="patient-overview-chart"
                          height={60}
                          data={enhancedScoreCard.barChart.data}
                          options={enhancedScoreCard.barChart.options}
                        />
                      </div>
                    ) : (
                      <p className="text-center text-capitalize">
                        {strings.dataNotAvailable}
                      </p>
                    )}
                  </div> :
                    <div>
                      <div className="row">
                        <div className="col-md-6">
                          <Form.Row>
                            <Form.Group>
                              <Form.Check
                                inline
                                custom
                                className="filter-checkbox"
                                id="spiro"
                                type="checkbox"
                                value={strings.spirometry}
                                label={strings.spirometry}
                                name={strings.spirometry}
                                checked={selectedRadioType === 'all' || selectedRadioType === strings.spiro}
                                onChange={this.handleChangeRadio}
                                onClick={this.handleChangeRadio}
                              />
                              <Form.Check
                                inline
                                custom
                                className="filter-checkbox"
                                id="therapy"
                                type="checkbox"
                                value={strings.dailyTherapyAverage}
                                label={strings.dailyTherapyAverage}
                                name={strings.dailyTherapyAverage}
                                checked={selectedRadioType === 'all' || selectedRadioType === strings.therapy}
                                onChange={this.handleChangeRadio}
                                onClick={this.handleChangeRadio}
                              />
                            </Form.Group>
                          </Form.Row>
                        </div>
                        <div className="col-md-6 therapy-duration text-right pr-0">
                          <input type="button" value="Log" onClick={this.logPopup} style={{ backgroundColor: '#739ddb', color: 'white' }}
                            className={`btn btn-sm text-upper pt-2 log-button
                            ${(actualRole === constants.ROLES.CUSTOMER_SERVICES ||
                                actualRole === constants.ROLES.ASSOCIATE_EXECUTIVE) ? 'd-none' : ''}
                          `}></input>
                          {spiroYearRangeItems}
                        </div>
                      </div>

                      {!isEmpty(enhancedSiproData.data) ? (
                        <div id="spiro-line-chart" className="chart-wrapper">
                          <Line
                            id="patient-overview-chart"
                            height={60}
                            data={filteredSpiroData.data}
                            options={filteredSpiroData.options}
                          />
                          <div className="row month-disp">
                            {["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map(mon => {
                              return <div className="col-md-1 font-weight-bold font-color-smoke-grey">{mon}</div>
                            })}
                          </div>
                        </div>
                      ) : (
                        <p className="text-center text-capitalize">
                          {strings.dataNotAvailable} for {moment(selectedYear).format('YYYY')}
                        </p>
                      )}
                    </div>}
                </Card.Body>
              </Card>

              {/* <Card className="therapy-duration-chart-card">
                <div className="d-flex therapy-duration">
                  <p className="mr-auto card-title  p-4">
                    {strings.therapyDuration}
                  </p>
                  {therapyMonthSelect}
                  {therapyMonthRangeItems}
                </div>
                <Card.Body>
                  {!isEmpty(enhancedScoreCard.barChart) ? (
                    <div id="therapy-bar-chart" className="chart-wrapper">
                      <Bar
                        id="patient-overview-chart"
                        height={60}
                        data={enhancedScoreCard.barChart.data}
                        options={enhancedScoreCard.barChart.options}
                      />
                    </div>
                  ) : (
                      <p className="text-center text-capitalize">
                        {strings.dataNotAvailable}
                      </p>
                    )}
                </Card.Body>
              </Card> */}
              <div className="row protocol-tables mobile-full-width-table">
                {this.state.updatedProtocolList ?
                  Object.keys(this.state.updatedProtocolList)
                    .sort()
                    .reverse()
                    .map(dType => (
                      <div className="col-12 col-md-6" key={uid(dType)}>
                        <div className="device-table-brand">
                          {
                            (deviceRef[dType][0] === strings.vest && patient.deviceName !== null
                              && patient.isManual) ?
                              <img
                                src={manualLogo}
                                className="d-inline-block device-logo manual-logo-pad"
                                alt={'Manual Device'}
                              />
                              :
                              <img
                                src={deviceRef[dType][1]}
                                width="48"
                                height="48"
                                className="d-inline-block device-logo"
                                alt={`${deviceRef[dType][0]} ${strings.protocol}`}
                              />
                          }
                          <span className={`${deviceRef[dType][2]}-logo-text`}>
                            {(deviceRef[dType][0] === strings.vest && patient.deviceName !== null
                              && patient.isManual) ?
                              `${patient.deviceName} Daily ${strings.protocol}` :
                              `${deviceRef[dType][0]} Daily ${strings.protocol}`}
                          </span>
                          <span>
                            {this.state.activeFromtoLable !== null && this.state.activeFromtoLable[dType].from !== null
                              && this.state.activeFromtoLable[dType].to !== null &&
                              ` ( Active from ${moment(this.state.activeFromtoLable[dType].from).format('MMM DD, Y')} to
                               ${moment(this.state.activeFromtoLable[dType].to).format('MMM DD, Y')} )`}
                            {this.state.activeFromtoLable !== null && this.state.activeFromtoLable[dType].from !== null
                              && this.state.activeFromtoLable[dType].to === null &&
                              ` ( Active since ${moment(this.state.activeFromtoLable[dType].from).format('MMM DD, Y')} )`}
                          </span>
                        </div>
                        <div className="card">
                          {protocolTable(this.state.updatedProtocolList, dType, patient)}
                        </div>
                      </div>
                    )) : enhancedScoreCard && enhancedScoreCard.deviceGroups &&
                  Object.keys(enhancedScoreCard.deviceGroups)
                    .sort()
                    .reverse()
                    .map(dType => (
                      <div className="col-12 col-md-6" key={uid(dType)}>
                        <div className="device-table-brand">
                          {
                            (deviceRef[dType][0] === strings.vest && patient.deviceName !== null
                              && patient.isManual) ?
                              <img
                                src={manualLogo}
                                className="d-inline-block device-logo manual-logo-pad"
                                alt={'Manual Device'}
                              />
                              :
                              <img
                                src={deviceRef[dType][1]}
                                width="48"
                                height="48"
                                className="d-inline-block device-logo"
                                alt={`${deviceRef[dType][0]} ${strings.protocol}`}
                              />
                          }
                          <span className={`${deviceRef[dType][2]}-logo-text`}>
                            {(deviceRef[dType][0] === strings.vest && patient.deviceName !== null
                              && patient.isManual) ?
                              `${patient.deviceName} Daily ${strings.protocol}` :
                              `${deviceRef[dType][0]} Daily ${strings.protocol}`}
                          </span>
                          <span>
                            {this.state.activeFromtoLable !== null && this.state.activeFromtoLable[dType].from !== null
                              && this.state.activeFromtoLable[dType].to !== null &&
                              `( Active from ${moment(this.state.activeFromtoLable[dType].from).format('MMM DD, Y')} to
                               ${moment(this.state.activeFromtoLable[dType].to).format('MMM DD, Y')} )`}
                            {this.state.activeFromtoLable !== null && this.state.activeFromtoLable[dType].from !== null
                              && this.state.activeFromtoLable[dType].to === null &&
                              ` ( Active since ${moment(this.state.activeFromtoLable[dType].from).format('MMM DD, Y')} )`}
                          </span>
                        </div>
                        <div className="card">
                          {protocolTable(enhancedScoreCard.deviceGroups, dType, patient)}
                        </div>
                      </div>
                    ))}
              </div>

              {!isEmpty(patientsData) && isSpiroPdf !== undefined && (
                <div style={{ display: 'none' }}>
                  <PDFDownloadLink
                    id="pdf-dowload"
                    className="downloadlink text-uppercase"
                    document={
                      !isSpiroPdf ? <Pdf
                        data={patientsData}
                        isBlackAndWhite={isBlackAndWhite}
                        tableRequired={true}
                        isSpiroPdf={isSpiroPdf}
                      /> : <SpiroReportPdf
                        data={patientsData}
                        isBlackAndWhite={isBlackAndWhite}
                        tableRequired={true}
                        isSpiroPdf={isSpiroPdf}
                      />
                    }
                    fileName={isSpiroPdf ? "Spiro Report.pdf" : "Summary Report.pdf"}
                  >
                    {({ blob, loading }) =>
                      loading ? '' : isSpiroPdf ? this.saveSpiroFileAsPdf(blob) : this.saveFileAsPdf(blob)
                    }
                  </PDFDownloadLink>
                </div>
              )}

              {isTherapyshow ?
                <div className="row session-table-wrapper listing-pagination mobile-full-width-table">
                  <div className="col-12">
                    <div className="card">
                      <table className="table">
                        <thead>
                          <tr>
                            <th scope="col">{strings.o_date}</th>
                            <th scope="col" className="d-none d-sm-table-cell">
                              {strings.sessions}
                            </th>
                            <th className="total-duration-col" scope="col">
                              {strings.totalDuration}
                            </th>
                            {/* <th scope="col" className="d-none d-sm-table-cell">
                              {strings.fev1Pred}
                            </th> */}
                          </tr>
                        </thead>
                        <tbody>{sessionListItems}</tbody>
                      </table>
                    </div>
                    <nav
                      aria-label="..."
                      className="d-flex justify-content-center justify-content-sm-end"
                    >
                      <Pagination
                        activePage={sessionActivePage}
                        prevPageText="PREV"
                        nextPageText="NEXT"
                        itemClass="page-item"
                        linkClass="page-link"
                        activeLinkClass=""
                        itemsCountper_page={sessionPerPage}
                        totalItemsCount={sessionCount}
                        pageRangeDisplayed={sessionRange}
                        onChange={this.handlePageChange}
                        firstPageText="FIRST"
                        lastPageText="LAST"
                      />
                    </nav>
                  </div>
                </div>
                :
                <div className="row session-table-wrapper listing-pagination mobile-full-width-table">
                  <div className="col-12">
                    <div className="card">
                      <table className="table">
                        <thead>
                          <tr>
                            <th scope="col" width='26%'>{strings.monthYear}</th>
                            <th scope="col" width='30%'>{strings.dailyTherapyAverage}</th>
                            <th scope="col" width='19%'>
                              <span className="mr-2">
                                <img
                                  src={spiroLogo}
                                  width="18"
                                  height="20"
                                  alt="Spiro"
                                />
                              </span>
                              FEV1% (Predicted)
                            </th>
                            <th scope="col" className="d-none d-sm-table-cell text-right" width='25%'>
                              CLICK <span className="d-inline-block ml mr-2 ml-2" >
                                <img
                                  src={downArrowLogo}
                                  width="15"
                                  height="10"
                                  alt="Spiro"
                                /></span> FOR MORE DATA
                            </th>
                          </tr>
                        </thead>
                        <tbody>{sessionListSpiroItems}</tbody>
                      </table>
                    </div>
                  </div>
                </div>
              }

            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
        <SelectColorDialog
          show={this.state.showDialog}
          handleClose={() => this.setState({ showDialog: false })}
          handleChange={this.handleColorChange}
        />
      </div >
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { breadcrumbsReducer, patient } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    patient: patient.pData[id] || {},
    pUserData: patient.pUserData[id],
    pClinics: patient.pClinics[id],
    pProviders: patient.pProviders[id],
    patientStats: patient.patientStats[id],
    spiroDataLogStatus: patient.spiroDataLogStatus,
    isTherapyOption: patient.isTherapyOption,
    enhancedScoreCard: getEnhancedScoreData(
      patient.pmEnhancedTherapyMonth[id],
      patient.allProtocols[id],
      patient.pmEnhancedTherapy[id],
      patient.pData[id],
      null,
      null
    ),
    enhancedGroupData: patient.patientsRangeEnhancedTherapy[id]
      ? getEnhancedPatientsGroupData(
        {
          [id]: {
            patient: patient.pData[id],
            stats: patient.patientStats[id],
            clinics: patient.pClinics[id],
            providers: patient.pProviders[id],
            protocols: patient.pProtocols[id],
            therapy: patient.patientsRangeEnhancedTherapy[id]
          }
        },
        state.app.patient.isBlackAndWhite,
        true,
        patient.spiroRawData,
        patient.therapyRawData,
        patient.isSpiroPdf
      )
      : {},
    enhancedSiproData: !patient.isTherapyOption ? getEnhancedSpiroData(
      patient.patientsSpiroData,
      patient.patientYearTherapyData,
      patient.selectedSpiroYear,
      false,
      false) : {},
    isAllowed: patient.isAllowed,
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    progressTime: patient.progressTime,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    toggleTherapyOptions: (isTherapy) =>
      dispatch({
        type: constants.PATIENT.TOGGLE_THERAPY_OPTION,
        data: isTherapy
      }),
    postPatientSpiroData: (payload) =>
      dispatch({
        type: constants.PATIENT.STORE_PATIENT_SPIRO_LOG_DATA,
        data: payload
      }),
    getPatientOverviewData: (id, start, end, mStart, mEnd, timeZone) =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_OVERVIEW,
        data: { id, start, end, mStart, mEnd, timeZone }
      }),
    getPatientViewData: (id) =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_DATA,
        data: { id }
      }),
    getPatientStatsData: params =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_STATS_DATA,
        data: params
      }),
    getPatientTherapyData: params =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_THERAPY_DATA,
        data: params
      }),
    getEnhancedPatientTherapyData: params =>
      dispatch({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENT_THERAPY_DATA,
        data: params
      }),
    getEnhancedPatientSpiroData: params =>
      dispatch({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA,
        data: params
      }),
    resetSpiroDataLogStatus: () =>
      dispatch({
        type: constants.PATIENT.RESET_SPIRO_DATA_LOG_STATUS
      }),
    resetPatientOverview: () =>
      dispatch({
        type: constants.PATIENT.RESET_PATIENT_OVERVIEW
      }),
    resetPdfData: () =>
      dispatch({
        type: constants.PATIENT.RESET_PROPS_VALUES
      }),
    getPatientTherapyDataForAllMonths: (patientIds, months) =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_THERAPY_DATA_ALL_MONTHS,
        data: { patientIds, months }
      }),
    getEnhancedPatientsTherapyData: params =>
      dispatch({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENTS_THERAPY_DATA,
        data: params
      }),
    setTypeOfPdf: isBlackAndWhite =>
      dispatch({
        type: constants.PATIENT.SET_TYPE_OF_PDF,
        data: { isBlackAndWhite }
      }),
    setPdfDownloadStatus: status =>
      dispatch({
        type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD,
        data: status
      }),
    addBreadCrumb: (location, obj) =>
      dispatch({
        type: constants.BREADCRUMBS.BREADCRUMBS_ADD,
        data: {
          title: obj.title,
          path: location.pathname,
          search: location.search
        }
      }),
    removeBreadCrumb: () =>
      dispatch({ type: constants.BREADCRUMBS.BREADCRUMBS_REMOVE }),
    handleFlag: (userId, patientId, flag, entity) =>
      dispatch({
        type: constants.PATIENT.PATIENT_OVERVIEW_FLAG,
        data: {
          patientId,
          flagged: !flag,
          entity
        },
        userId
      })
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PatientOverview);
