import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import { isEmpty, every, last } from 'lodash';
import update from 'immutability-helper';
import { uid } from 'react-uid';
import constants from 'constants.js';
import TableDisplay from 'components/TableDisplay';
import { Header, SideBar } from 'components/Navigation';
import API from 'api/api_config';
import CustomSelect from 'components/CustomSelect';
import DatePicker from 'react-datepicker';
import DatePickerDisabledInput from 'components/DatePickerDisabledInput';
import moment from 'moment-timezone';
import trash from 'assets/icn-delete.svg';
import strings from 'localization/strings';
import NumberFormat from 'react-number-format';
import { isValidMobile, validateEmail } from 'utils/helper';
import { FootNote } from 'components/FootNote';
import ConfirmationDialog from 'components/ConfirmationDialog';
import accessMatrix from 'rolesData/accessMatrix.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { getUserData } from 'utils/helper';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import {
  getClinicsBody,
  getProvidersBody,
  getCaregiverBody,
  parseDate,
  setFormattedDate,
  setAssociateEntityState,
  getClinicTableHeading,
  getProviderTableHeading,
  getCaregiverTableHeading,
  getDeviceTypeText
} from 'patient/helper.jsx';
import {
  addBreadCrumb,
  getBreadCrumb,
  removeBreadCrumb,
  languagesDropdown,
  getRelationships,
  dropDowns,
  setScreenSize
} from 'utils/utltity.jsx';
import AddNewCaregiver from 'patient/AddNewCaregiver';
import 'patient/PatientProfile.scss';
import { decryptemail } from '../Cryptocode';

const diagnosisDeviceKey = {
  vestTypeCodeList: 'vestTypeCodeList',
  monarchTypeCodeList: 'monarchTypeCodeList',
  allTypeCodeList: 'allTypeCodeList'
};

class PatientProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      submitted: false,
      hillromId: '',
      firstName: '',
      lastName: '',
      middleName: '',
      dob: '',
      langKey: '',
      address: '',
      city: '',
      state: '',
      zipcode: '',
      primaryPhone: '',
      mobilePhone: '',
      email: '',
      deviceType: '',
      monarchGarmentColor: null,
      vestGarmentSize: null,
      vestGarmentColor: null,
      vestGarmentType: null,
      vestTypeCodeList: [],
      monarchTypeCodeList: [],
      allTypeCodeList: [],
      role: 'PATIENT',
      error: null,
      caregiverError: null,
      associateEntity: {
        addClinic: false,
        addProvider: false,
        addCaregiver: false
      },
      resetSelect: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: true,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      },
      isDirty: false
    };
    this.setAssociateEntityState = setAssociateEntityState.bind(this);
    this.getRelationships = getRelationships.bind(this);
    this.dropDowns = dropDowns.bind(this);
    this.setScreenSize = setScreenSize.bind(this);
    this.setFormattedDate = setFormattedDate.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.languagesDropdown = languagesDropdown.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.getDeviceTypeText = getDeviceTypeText.bind(this);
  }

  componentWillMount() {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    dispatch({
      type: constants.PATIENT.PATIENT_INFO_REQUEST,
      payload: { id }
    });
    dispatch({
      type: constants.PATIENT.GARMENT_PARAMETERS_REQUEST
    });
    dispatch({
      type: constants.PATIENT.CLINICSBYPATIENT_REQUEST,
      id
    });
    dispatch({
      type: constants.PATIENT.CAREGIVERBYPATIENT_REQUEST,
      id
    });
    dispatch({ type: constants.LANGUAGES.LANGUAGES_REQUEST });
    dispatch({
      type: constants.PATIENT.PROVIDERSBYPATIENT_REQUEST,
      id
    });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.patientProfile });
  }

  getDiagnosisCombinedList = patientInfo => {
    if (patientInfo.deviceType === constants.DEVICE_TYPE_CODE.ALL) {
      const { vestTypeCodeList, monrachTypeCodeList } = patientInfo;
      return [...(vestTypeCodeList || []), ...(monrachTypeCodeList || [])];
    } else {
      return [];
    }
  };

  componentWillReceiveProps(newProps) {
    const { patientInfo } = this.props;
    const newPatientInfo = { ...newProps.patientInfo };

    if (isEmpty(patientInfo) && !isEmpty(newPatientInfo)) {
      this.setState({
        ...newPatientInfo,
        vestTypeCodeList: newPatientInfo.vestTypeCodeList || [],
        monarchTypeCodeList: newPatientInfo.monrachTypeCodeList || [],
        allTypeCodeList: this.getDiagnosisCombinedList(newPatientInfo)
      });
    }

    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
    this.setState({
      clinicsByPatient: newProps.clinicsByPatient,
      providersByPatient: newProps.providersByPatient,
      caregivers: newProps.caregivers
    });
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    dispatch({ type: constants.PATIENT.PATIENT_INFO_CLEAR, key: id });
  }

  handleChange = event => {
    this.setState({ isDirty: true });
    if (event.target.name === 'langKey') {
      const { languages } = this.props;
      this.setState({
        [event.target.name]: Object.keys(languages).find(
          key => languages[key] === event.target.value
        )
      });
    } else if (
      event.target.value === '' &&
      event.target.name !== 'zipcode' &&
      event.target.name !== 'zip'
    ) {
      this.setState({ [event.target.name]: null });
    } else {
      this.setState({ [event.target.name]: event.target.value });
    }
  };

  setAge = date => {
    const ageFromDob =
      new Date(moment().format('MM/DD/YYYY')).getFullYear() -
      new Date(date).getFullYear();
    this.setState({
      age: ageFromDob
    });
  };

  handleDateChange = date => {
    if (date !== null) {
      this.setState({ isDirty: true });
      this.setState({ dob: moment(date).format('L') });
      this.setAge(date);
      this.setFormattedDate(date);
    }
  };

  diagnosisRemove = (event, idx) => {
    this.setState({ isDirty: true });
    const { deviceType } = this.state;
    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        this.removeFromDeviceTypeCodeList(
          idx,
          diagnosisDeviceKey.vestTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.MONARCH:
        this.removeFromDeviceTypeCodeList(
          idx,
          diagnosisDeviceKey.monarchTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.ALL:
        this.removeFromDeviceTypeCodeList(
          idx,
          diagnosisDeviceKey.allTypeCodeList
        );
        break;
      default:
    }
  };

  removeFromDeviceTypeCodeList = (idx, key) => {
    this.setState(prevState => ({
      [key]: update(prevState[key], {
        $splice: [[idx, 1]]
      })
    }));
  };

  dobDateLimit = () => {
    let date = new Date();
    date = date.setDate(date.getDate() - 1);
    return new Date(date);
  };

  updateProfile = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;

    const diagnosisDeviceTypeList = this.getDeviceCodeRequestObject();

    const payload = Object.assign({}, this.state, diagnosisDeviceTypeList);
    [
      'clinicsByPatient',
      'providersByPatient',
      'caregivers',
      'error',
      'associateEntity',
      'dialog',
      'isDirty',
      'allTypeCodeList',
      'vestTypeCodeList',
      'monarchTypeCodeList'
    ].forEach(e => delete payload[e]);

    dispatch({
      type: constants.PATIENT.UPDATE_PATIENT_REQUEST,
      id,
      payload
    });
    this.setState({ isDirty: false });
    handleClose();
  };

  handleUpdateProfile = () => {
    const {
      hillromId,
      firstName,
      lastName,
      dob,
      address,
      city,
      state,
      zip,
      primaryPhone,
      mobilePhone,
      deviceType,
      dialog
    } = this.state;
    this.setState({ submitted: true });
    this.setState({ error: '' });
    if (hillromId === '' || hillromId === null) {
      this.setState({ error: strings.pleaseEnterHillromID });
    } else if (firstName === '' || firstName === null) {
      this.setState({ error: strings.pleaseEnterFirstName });
    } else if (lastName === '' || lastName === null) {
      this.setState({ error: strings.pleaseSelectLastName });
    } else if (dob === null) {
      this.setState({ error: strings.pleaseSelectDOB });
    } else if (address === '' || address === null) {
      this.setState({ error: strings.pleaseEnterAddress });
    } else if (city === '' || city === null) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else if (state === '' || state === null) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else if (zip === '' || zip === null) {
      this.setState({ error: strings.pleaseEnterZipcode });
    } else if (primaryPhone === '' || primaryPhone === null) {
      this.setState({ error: strings.pleaseEnterPrimaryPhone });
    } else if (deviceType === '') {
      this.setState({ error: strings.pleaseSelectDeviceType });
    } else if (!isValidMobile(primaryPhone, 10, true)) {
      this.setState({ error: strings.phoneNumberisInvalid });
    } else if (!isValidMobile(mobilePhone, 10, true)) {
      this.setState({ error: strings.mobileNumberisInvalid });
    } else {
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.updateProfileMsg
            .replace('{VALUE}', `${firstName} ${lastName}`)
            .replace('{ENTITY}', 'patient'),
          title: strings.updatePatientProfile,
          button: strings.update,
          confirmFunction: this.updateProfile,
          show: true
        })
      });
    }
  };

  handleZipChange = event => {
    const { name, value } = event.target;
    const { dispatch } = this.props;
    const { zipcode } = this.state;
    if (value !== '') {
      if (name === 'czipcode') {
        dispatch({
          type: constants.ZIP.CCITYSTATEBYZIP_REQUEST,
          zip: event.target.value
        });
      } else {
        dispatch({
          type: constants.ZIP.CITYSTATEBYZIP_REQUEST,
          zip: zipcode
        });
      }
    } else if (name === 'czipcode') {
      dispatch({
        type: constants.ZIP.CCITYSTATEBYZIP_FAILURE
      });
    } else {
      dispatch({
        type: constants.ZIP.CITYSTATEBYZIP_FAILURE
      });
    }
  };

  linkCaregiverPatient = state => {
    this.setState({ caregiverError: '' });
    const { dialog } = this.state;
    if (state.cfirstName === '') {
      this.setState({ caregiverError: strings.pleaseEnterFirstName });
    } else if (state.clastName === '') {
      this.setState({ caregiverError: strings.pleaseSelectLastName });
    } else if (!isValidMobile(state.cphoneNumber, 10, false)) {
      this.setState({ caregiverError: strings.phoneNumberisInvalid });
    } else if (state.crelationship === '') {
      this.setState({ caregiverError: strings.pleaseSelectRelationship });
    } else if (!isValidMobile(state.cmobileNumber, 10, true)) {
      this.setState({ caregiverError: strings.mobileNumberInvalid });
    } else if (!validateEmail(state.cemail)) {
      this.setState({ caregiverError: strings.pleaseEnterValidEmail });
    } else if (state.czipcode !== '' && state.ccity === '') {
      this.setState({ caregiverError: strings.pleaseEnterValidZipcode });
    } else if (
      state.cfirstName !== '' &&
      state.clastName !== '' &&
      state.cemail !== '' &&
      state.cphoneNumber !== '' &&
      state.crelationship !== ''
    ) {
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateCaregiver.replace(
            '{VALUE}',
            `${state.cfirstName} ${state.clastName}`
          ),
          title: strings.addCaregiver,
          button: strings.addCaregiver,
          confirmFunction: () => {
            this.addCaregiver(state);
          },
          show: true
        })
      });
    }
  };

  addCaregiver = state => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.ADDCAREGIVER_REQUEST,
      id,
      payload: {
        title: state.ctitle,
        firstName: state.cfirstName,
        middleName: state.cmiddleName,
        lastName: state.clastName,
        address: state.caddress,
        city: state.ccity,
        state: state.cstate,
        zipcode: state.czipcode,
        email: state.cemail,
        primaryPhone: state.cphoneNumber,
        mobilePhone: state.cmobileNumber,
        relationship: state.crelationship
      }
    });
    this.setAssociateEntityState({ addCaregiver: false });
    handleClose();
  };

  deleteClinic = clinicId => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.DISASSOCIATE_REQUEST,
      payload: [{ id: clinicId }],
      id
    });
    this.setAssociateEntityState({ addClinic: false });
    handleClose();
  };

  addClinic = clinicId => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.ASSOCIATECLINIC_REQUEST,
      payload: [{ id: clinicId, mrnId: null, notes: null }],
      id
    });
    this.setAssociateEntityState({ addClinic: false });
    handleClose();
  };

  deleteProvider = providerId => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.DISASSOCIATEHCP_REQUEST,
      payload: [{ id: providerId }],
      id
    });
    this.setAssociateEntityState({ addProvider: false });
    handleClose();
  };

  addProvider = providerId => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.ASSOCIATEHCP_REQUEST,
      payload: [{ id: providerId }],
      id
    });
    this.setAssociateEntityState({ addProvider: false });
    handleClose();
  };

  deleteCaregiver = caregiverId => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { handleClose }
    } = this.state;
    dispatch({
      type: constants.PATIENT.DISASSOCIATECAREGIVER_REQUEST,
      deleteId: caregiverId,
      id
    });
    this.setAssociateEntityState({ addCaregiver: false });
    handleClose();
  };

  addDiagnosis = (opt, idx) => {
    this.setState({ isDirty: true });
    const { deviceType } = this.state;
    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        this.addToDeviceTypeCodeList(
          opt,
          idx,
          diagnosisDeviceKey.vestTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.MONARCH:
        this.addToDeviceTypeCodeList(
          opt,
          idx,
          diagnosisDeviceKey.monarchTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.ALL:
        this.addToDeviceTypeCodeList(
          opt,
          idx,
          diagnosisDeviceKey.allTypeCodeList
        );
        break;
      default:
    }
  };

  handleDiagnosisAdd = () => {
    const diagnosisInit = {
      type_code: '',
      type_code_value: ''
    };
    const { deviceType } = this.state;
    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        this.addEmptyDeviceTypeCodeList(
          diagnosisInit,
          diagnosisDeviceKey.vestTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.MONARCH:
        this.addEmptyDeviceTypeCodeList(
          diagnosisInit,
          diagnosisDeviceKey.monarchTypeCodeList
        );
        break;
      case constants.DEVICE_TYPE_CODE.ALL:
        this.addEmptyDeviceTypeCodeList(
          diagnosisInit,
          diagnosisDeviceKey.allTypeCodeList
        );
        break;
      default:
    }
  };

  addEmptyDeviceTypeCodeList = (diagnosisInit, key) => {
    const list = this.state[key];
    if (!every(last(list), isEmpty) || isEmpty(list)) {
      this.setState({
        [key]: [...list, diagnosisInit]
      });
    }
  };

  addToDeviceTypeCodeList = (opt, idx, key) => {
    this.setState(prevState => ({
      [key]: update(prevState[key], {
        [idx]: {
          $set: {
            type_code: opt ? opt.type_code : '',
            type_code_value: opt ? opt.type_code_value : ''
          }
        }
      })
    }));
  };

  handleDeleteCaregiver = (event, caregiverId) => {
    const { name } = event.target;
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        body: strings.disassociateCaregiver.replace('{VALUE}', name),
        title: strings.removeCaregiver,
        button: strings.removeCaregiver,
        confirmFunction: () => {
          this.deleteCaregiver(caregiverId);
        },
        show: true
      })
    });
  };

  handleDeleteHcp = (event, providerId) => {
    const { name } = event.target;
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        body: strings.disassociateProvider
          .replace('{VALUE}', name)
          .replace('{ENTITY}', 'patient'),
        title: strings.removeProvider,
        button: strings.removeProvider,
        confirmFunction: () => {
          this.deleteProvider(providerId);
        },
        show: true
      })
    });
  };

  handleAdditionClinics = tag => {
    if (tag) {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateClinic.replace('{VALUE}', tag.name),
          title: strings.addClinic,
          button: strings.addClinic,
          confirmFunction: () => {
            this.addClinic(tag.id);
          },
          show: true
        })
      });
    }
  };

  handleDeleteClinic = (event, clinicId) => {
    const { dialog } = this.state;
    const { name } = event.target;
    this.setState({
      dialog: Object.assign(dialog, {
        body: strings.disassociateClinic.replace('{VALUE}', name),
        title: strings.removeClinic,
        button: strings.removeClinic,
        confirmFunction: () => {
          this.deleteClinic(clinicId);
        },
        show: true
      })
    });
  };

  handleAdditionProvider = tag => {
    if (tag) {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateProvider
            .replace('{VALUE}', `${tag.firstName} ${tag.lastName}`)
            .replace('{ENTITY}', 'patient'),
          title: strings.addProvider,
          button: strings.addProvider,
          confirmFunction: () => {
            this.addProvider(tag.id);
          },
          show: true
        })
      });
    }
  };

  getDeviceCodeRequestObject = () => {
    const {
      deviceType,
      vestTypeCodeList,
      monarchTypeCodeList,
      allTypeCodeList
    } = this.state;
    const vestDiagnosis = 'vestDiagnosis',
      monarchDiagnosis = 'monarchDiagnosis';

    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        return vestTypeCodeList.reduce((map, code, index) => {
          const { type_code } = code;
          if (type_code) {
            map[`${vestDiagnosis}${index + 1}`] = code.type_code;
          }
          return map;
        }, {});
      case constants.DEVICE_TYPE_CODE.MONARCH:
        return monarchTypeCodeList.reduce((map, code, index) => {
          const { type_code } = code;
          if (type_code) {
            map[`${monarchDiagnosis}${index + 1}`] = code.type_code;
          }
          return map;
        }, {});
      case constants.DEVICE_TYPE_CODE.ALL:
        return allTypeCodeList.reduce((map, code, index) => {
          const { type_code } = code;

          if (type_code) {
            if (index < 2) {
              map[`${vestDiagnosis}${index + 1}`] = code.type_code;
            } else {
              map[`${monarchDiagnosis}${index - 1}`] = code.type_code;
            }
          }
          return map;
        }, {});
      default:
        return {};
    }
  };

  getDeviceCodeList = () => {
    const {
      deviceType,
      vestTypeCodeList,
      monarchTypeCodeList,
      allTypeCodeList
    } = this.state;

    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        return vestTypeCodeList;
      case constants.DEVICE_TYPE_CODE.MONARCH:
        return monarchTypeCodeList;
      case constants.DEVICE_TYPE_CODE.ALL:
        return allTypeCodeList;
      default:
        return [];
    }
  };

  canAddDiagnosis = () => {
    const {
      deviceType,
      vestTypeCodeList,
      monarchTypeCodeList,
      allTypeCodeList
    } = this.state;

    switch (deviceType) {
      case constants.DEVICE_TYPE_CODE.VISIVEST:
        return vestTypeCodeList.length < 2;
      case constants.DEVICE_TYPE_CODE.MONARCH:
        return monarchTypeCodeList.length < 2;
      case constants.DEVICE_TYPE_CODE.ALL:
        return allTypeCodeList.length < 4;
      default:
        return false;
    }
  };

  render() {
    const {
      hillromId,
      firstName,
      middleName,
      lastName,
      dob,
      langKey,
      address,
      city,
      state,
      zipcode,
      primaryPhone,
      mobilePhone,
      email,
      deviceType,
      dialog,
      isMobile,
      associateEntity,
      error,
      clinicsByPatient,
      providersByPatient,
      caregivers,
      submitted,
      resetSelect,
      caregiverError
    } = this.state;
    const {
      location,
      match: {
        params: { id }
      },
      languages,
      breadcrumbs,
      history
    } = this.props;
    const { actualRole } = getUserData();
    const patientInformation = accessMatrix.PATIENT_INFORMATION[actualRole];
    const clinicInformation = accessMatrix.PATIENT_CLINIC[actualRole];
    const providerInformation = accessMatrix.PATIENT_PROVIDER[actualRole];
    const caregiverInformation = accessMatrix.PATIENT_CAREGIVER[actualRole];
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    let showBack = true;
    let showBrand = false;
    let showToggle = false;
    if (getUserData().role === constants.ROLES.PATIENT) {
      showBack = false;
      showBrand = true;
      showToggle = true;
    }

    const updateButton = (
      <ButtonComponent
        id="save-patient-bottom"
        buttonClass={isMobile ? 'ml-auto' : 'float-right'}
        hidden={!patientInformation.write}
        buttonAction={this.handleUpdateProfile}
        icon="update-icon"
        buttonText={strings.update}
      />
    );

    const deviceCodeList = this.getDeviceCodeList();
    const enableAddDiagnosis = this.canAddDiagnosis();

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.USER.ALL}
          showBack={showBack}
          showBrand={showBrand}
          showToggle={showToggle}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <div
                className={`${isMobile ? 'mb-4' : 'mt-2 mb-4'
                  } d-inline-block text-break patient-name`}
              >{`${firstName || ''} ${lastName || ''}`}</div>
              {!isMobile && (
                <div>
                  <ButtonComponent
                    id="update-patient"
                    buttonClass="float-right"
                    hidden={!patientInformation.write}
                    buttonAction={this.handleUpdateProfile}
                    icon="update-icon"
                    buttonText={strings.update}
                  />
                  <h6>{strings.patientIdentifiers}</h6>
                </div>
              )}
              {isMobile && (
                <div>
                  <ButtonComponent
                    id="update-patient"
                    buttonClass="float-right d-inline-block"
                    hidden={!patientInformation.write}
                    buttonAction={this.handleUpdateProfile}
                    icon="update-icon"
                    buttonText={strings.update}
                  />
                  <h6
                    style={{ marginTop: '0.8rem' }}
                    className="d-inline-block"
                  >
                    {strings.patientIdentifiers}
                  </h6>
                </div>
              )}
              <p id="error" className="text-danger">
                {error}
              </p>
              <Form className={`${submitted ? ' submitted' : ''}`}>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.hillromID} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={hillromId}
                      name="hillromId"
                      onChange={this.handleChange}
                      readOnly
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <div id="patient-personalDetails">
                  <h6 className="text-capitalize">{strings.personalDetails} Info</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        className="input-field"
                        type="text"
                        value={firstName}
                        name="firstName"
                        required
                        onChange={this.handleChange}
                        readOnly={!patientInformation.write}
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.middleName}</Form.Label>
                      <FormControlComponent
                        type="text"
                        name="middleName"
                        value={middleName || ''}
                        onChange={this.handleChange}
                        readOnly={!patientInformation.write}
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        value={lastName}
                        required
                        name="lastName"
                        onChange={this.handleChange}
                        readOnly={!patientInformation.write}
                        maxLength="50"
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.dateOfBirth} <span className="asterisk-color">*</span></Form.Label>
                      <DatePicker
                        selected={parseDate(dob)}
                        name="dob"
                        onChange={this.handleDateChange}
                        showYearDropdown
                        customInput={<DatePickerDisabledInput />}
                        yearDropdownItemNumber={30}
                        scrollableYearDropdown
                        maxDate={this.dobDateLimit()}
                        className="form-control"
                        disabled={!patientInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.language}</Form.Label>
                      <Form.Control
                        as="select"
                        value={languages[langKey]}
                        name="langKey"
                        onChange={this.handleChange}
                        disabled={!patientInformation.write}
                      >
                        <option defaultValue value="">
                          {strings.selectLanguage}
                        </option>
                        {this.languagesDropdown()}
                      </Form.Control>
                    </Form.Group>
                  </Form.Row>
                </div>
                <hr />
                <h6>{strings.contactDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.address} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={address || ''}
                      name="address"
                      required
                      onChange={this.handleChange}
                      readOnly={!patientInformation.write}
                      maxLength="100"
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                    <Form.Control
                      type="text"
                      value={city || ''}
                      name="city"
                      required
                      onChange={this.handleChange}
                      readOnly
                    />
                  </Form.Group>
                  <Form.Group as={Col}>
                    <Form.Row>
                      <Form.Group as={Col} md={6}>
                        <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                        <Form.Control
                          type="text"
                          value={state || ''}
                          name="state"
                          required
                          onChange={this.handleChange}
                          readOnly
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={6}>
                        <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>
                        <FormControlComponent
                          type="text"
                          value={zipcode || ''}
                          name="zipcode"
                          required
                          onChange={this.handleChange}
                          onBlur={this.handleZipChange}
                          readOnly={!patientInformation.write}
                          maxLength="7"
                        />
                      </Form.Group>
                    </Form.Row>
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.primaryPhone} <span className="asterisk-color">*</span></Form.Label>
                    <NumberFormat
                      className="form-control"
                      placeholder={strings.numberPlaceholder}
                      format={strings.numberFormat}
                      mask="_"
                      name="primaryPhone"
                      required
                      value={primaryPhone || ''}
                      onChange={this.handleChange}
                      readOnly={!patientInformation.write}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.secondaryPhone}</Form.Label>
                    <NumberFormat
                      className="form-control"
                      placeholder={strings.numberPlaceholder}
                      format={strings.numberFormat}
                      mask="_"
                      name="mobilePhone"
                      value={mobilePhone || ''}
                      onChange={this.handleChange}
                      readOnly={!patientInformation.write}
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.email}</Form.Label>
                    <FormControlComponent
                      type="text"
                      value={email ? decryptemail(email) : email}
                      name="email"
                      onChange={this.handleChange}
                      readOnly
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <h6 className="text-capitalize">{strings.deviceDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.deviceType} <span className="asterisk-color">*</span></Form.Label>
                    <Form.Control as="select" disabled>
                      <option>{this.getDeviceTypeText(deviceType)}</option>
                    </Form.Control>
                  </Form.Group>
                </Form.Row>
                {this.dropDowns(this.state, this.props, this.handleChange)}
                <hr />
                <h6>{strings.diagnosisDetails}</h6>
                <div>
                  {deviceCodeList.map((diagnosis, idx) => (
                    <Form.Row key={uid(diagnosis, idx)}>
                      <Form.Group as={Col} md={9}>
                        <Form.Label>{strings.diagnosisCode}</Form.Label>
                        <Form.Label
                          style={{ fontSize: isMobile ? '0.875rem' : '' }}
                        ></Form.Label>
                        <div className="row">
                          <div className="col-11 col-md-11">
                            <CustomSelect
                              key={uid(diagnosis, idx)}
                              value={diagnosis}
                              filterOptions={{
                                key: 'type_code',
                                values: deviceCodeList
                              }}
                              len={deviceCodeList.length}
                              minSearchChars={
                                constants.TYPEAHEAD_SEARCH_TEXT_LEN
                              }
                              idx={idx}
                              optionUrl={API.DIAGNOSISSEARCH}
                              searchParam="searchString"
                              resAttr="typeCode"
                              displayAttr={['type_code', 'type_code_value']}
                              onChange={evt => this.addDiagnosis(evt, idx)}
                              clearable
                              isDeleteAllow
                              isDisabled={!patientInformation.write}
                            />
                          </div>
                          <div
                            className={`col-1 col-md-1 d-flex justify-content-start align-items-center px-0`}
                          >
                            {!isEmpty(diagnosis.type_code) &&
                              patientInformation.write ? (
                                <img
                                  src={trash}
                                  role="presentation"
                                  alt="Delete"
                                  width="14px"
                                  height="14px"
                                  onClick={evt => this.diagnosisRemove(evt, idx)}
                                  onKeyPress={evt =>
                                    this.diagnosisRemove(evt, idx)
                                  }
                                />
                              ) : null}
                          </div>
                        </div>
                      </Form.Group>
                      {idx === deviceCodeList.length - 1 && (
                        <Form.Group as={Col} md={3} className="pt-4 mt-2">
                          <ButtonComponent
                            id="add-diagnosis-patient"
                            buttonClass={
                              isMobile ? 'float-left' : 'float-right'
                            }
                            hidden={!patientInformation.write}
                            buttonAction={this.handleDiagnosisAdd}
                            icon="add-icon"
                            buttonText={strings.addDiagnosis}
                            disabled={!enableAddDiagnosis}
                          />
                        </Form.Group>
                      )}
                    </Form.Row>
                  ))}
                  {isEmpty(deviceCodeList) && (
                    <Form.Row>
                      <Form.Group as={Col} md={9}>
                        {strings.noDiagnosisCodeAssociated}.
                      </Form.Group>

                      <Form.Group as={Col} md={3} className="pt-4 mt-2">
                        <ButtonComponent
                          id="add-diagnosis-patient"
                          buttonClass={isMobile ? 'float-left' : 'float-right'}
                          hidden={!patientInformation.write}
                          buttonAction={this.handleDiagnosisAdd}
                          icon="add-icon"
                          buttonText={strings.addDiagnosis}
                          disabled={!enableAddDiagnosis}
                        />
                      </Form.Group>
                    </Form.Row>
                  )}
                </div>
                <hr />
                {isMobile && <hr />}
                <h1 className="text-capitalize">{strings.clinicInfo}</h1>
                <TableDisplay
                  heading={getClinicTableHeading(clinicInformation.write)}
                  listing={getClinicsBody(
                    clinicInformation.write,
                    clinicsByPatient,
                    this.handleDeleteClinic
                  )}
                  tableClass="patient-profile-clinic-table"
                />
                {associateEntity.addClinic && (
                  <div
                    className={`${associateEntity.addClinic
                      ? 'add-clinic-patient'
                      : 'd-none'
                      }`}
                    id="all-clinic-tag"
                  >
                    <CustomSelect
                      clearable
                      len={-1}
                      minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                      className="d-inline-block"
                      clearCurrentVal={resetSelect}
                      afterClearCurrentValFn={() => {
                        this.setState({ resetSelect: false });
                      }}
                      filterOptions={{ key: 'id', values: clinicsByPatient }}
                      optionUrl={`${API.CLINICSSEARCH}?page=1&per_page=100&sort_by=name&asc=true&status=active`}
                      searchParam="name"
                      urlSymbol="&"
                      placeholder={strings.chooseClinicPlaceholder}
                      displayAttr={['name', 'hillromId']}
                      onChange={this.handleAdditionClinics}
                    />
                    <span
                      className="cross-icon d-inline-block align-middle"
                      onClick={() => {
                        this.setAssociateEntityState({ addClinic: false });
                      }}
                      onKeyPress={() => {
                        this.setAssociateEntityState({ addClinic: false });
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                )}
                <div
                  className={associateEntity.addClinic ? 'd-none' : 'd-flex'}
                >
                  {actualRole !== constants.ROLES.PATIENT && (
                    <ButtonComponent
                      id="add-clinic-patient"
                      buttonClass={isMobile ? 'ml-0' : 'ml-auto'}
                      hidden={!clinicInformation.write}
                      buttonAction={() => {
                        this.setAssociateEntityState({ addClinic: true });
                      }}
                      icon="add-icon"
                      buttonText={strings.addClinic}
                    />
                  )}
                </div>
                <hr />
                {isMobile && <hr />}
                <h1 className="text-capitalize">{strings.providerInfo}</h1>
                <TableDisplay
                  heading={getProviderTableHeading(providerInformation.write)}
                  listing={getProvidersBody(
                    providerInformation.write,
                    providersByPatient,
                    this.handleDeleteHcp
                  )}
                  tableClass="patient-profile-provider-table"
                />
                {associateEntity.addProvider && (
                  <div
                    className={
                      associateEntity.addProvider
                        ? 'add-provider-patient'
                        : 'd-none'
                    }
                    id="all-provider-tag"
                  >
                    <CustomSelect
                      clearable
                      len={-1}
                      minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                      className="d-inline-block"
                      clearCurrentVal={resetSelect}
                      afterClearCurrentValFn={() => {
                        this.setState({ resetSelect: false });
                      }}
                      filterOptions={{ key: 'id', values: providersByPatient }}
                      optionUrl={`${API.HCPBYPATIENTCLINICS.replace(
                        '{PATIENTID}',
                        id
                      )}`}
                      resAttr="HCPUser"
                      seperator=" "
                      searchParam="searchString"
                      placeholder={strings.chooseProviderPlaceholder}
                      displayAttr={['firstName', 'lastName']}
                      onChange={this.handleAdditionProvider}
                    />
                    <span
                      className="cross-icon d-inline-block align-middle"
                      onClick={() => {
                        this.setAssociateEntityState({ addProvider: false });
                      }}
                      onKeyPress={() => {
                        this.setAssociateEntityState({ addProvider: false });
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                )}
                <div
                  className={associateEntity.addProvider ? 'd-none' : 'd-flex'}
                >
                  {actualRole !== constants.ROLES.PATIENT && (
                    <ButtonComponent
                      id="add-provider-patient"
                      buttonClass={isMobile ? 'ml-0' : 'ml-auto'}
                      hidden={!providerInformation.write}
                      buttonAction={() => {
                        this.setAssociateEntityState({ addProvider: true });
                      }}
                      icon="add-icon"
                      buttonText={strings.addProvider}
                    />
                  )}
                </div>
                <hr />
                {isMobile && <hr />}
                <h1 className="text-capitalize">{strings.caregiverInfo}</h1>
                <TableDisplay
                  heading={getCaregiverTableHeading(caregiverInformation.write)}
                  listing={getCaregiverBody(
                    caregiverInformation.write,
                    caregivers,
                    this.handleDeleteCaregiver
                  )}
                  tableClass="patient-profile-caregiver-table"
                />
                {caregiverInformation.write && (
                  <AddNewCaregiver
                    key={uid(associateEntity)}
                    updateButton={updateButton}
                    isMobile={isMobile}
                    associateEntity={associateEntity}
                    linkCaregiverPatient={this.linkCaregiverPatient}
                    handleZipChange={this.handleZipChange}
                    setAssociateEntityState={this.setAssociateEntityState}
                    caregiverError={caregiverError}
                    history={history}
                    location={location}
                  />
                )}
                {!isMobile && <hr />}
                {!isMobile && updateButton}
              </Form>
            </div>
            <p id="error" className="text-danger">
              {error}
            </p>
            <FootNote />
          </MainContent>
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { match } = ownProps;
  const { id } = match.params;
  const {
    patient,
    languagesReducer,
    userReducer,
    breadcrumbsReducer
  } = state.app;
  return {
    patientInfo: patient.patientInfo[id] || {},
    visiSize: patient.visiSize,
    visiColor: patient.visiColor,
    visiType: patient.visiType,
    monarchSize: patient.monarchSize,
    monarchColor: patient.monarchColor,
    monarchType: patient.monarchType,
    titanSize: patient.titanSize,
    titanColor: patient.titanColor,
    titanType: patient.titanType,
    clinicsByPatient: patient.clinicsByPatient[id],
    caregivers: patient.caregivers[id],
    providersByPatient: patient.providersByPatient[id],
    hcpByPatientClinics: patient.hcpByPatientClinics[id],
    relationships: patient.relationships,
    languages: languagesReducer.languages,
    cityStateByZip: userReducer.cityStateByZip,
    ccityStateByZip: userReducer.ccityStateByZip,
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};

export default connect(
  mapStateToProps,
  null
)(PatientProfile);
