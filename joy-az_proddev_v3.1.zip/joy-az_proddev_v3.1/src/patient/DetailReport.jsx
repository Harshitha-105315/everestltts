import React from 'react';
import { connect } from 'react-redux';
import { Header, SideBar } from 'components/Navigation';
import urls from 'urls';
import { Breadcrumb, ProgressBar, Modal, Button } from 'react-bootstrap';
import { FootNote } from 'components/FootNote';
import RangeMonthlyPicker from 'components/RangeMonthPicker';
import strings from 'localization/strings';
import moment from 'moment-timezone';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { LinkContainer } from 'react-router-bootstrap';
import titanLogo from 'assets/img/logo/titanlogo.png';
import monarchLogo from 'assets/img/logo/monarch.png';
import visiVestLogo from 'assets/img/logo/visivest.png';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import Pagination from 'react-js-pagination';
import { isEmpty, sumBy, values, mapValues } from 'lodash';
import { uid } from 'react-uid';
import {
  getClinicList,
  getProviderList,
  getDiagnosisDeviceCodeList
} from './helper';
import constants from '../constants';
import ButtonComponent from 'components/ButtonComponent';
import { getUserData, getDeviceTypeList, getEndDate, getMonthsAgoDate, getLatestMonth, getTimeZoneOffset } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';
import { allowFlag } from '../rolesData/searchMapKey';
import { saveAs } from 'file-saver';

class DetailReport extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      startDate: null,
      endDate: getEndDate(),
      pageRange: 5,
      pageNo: 1,
      pageSz: 10,
      pageOrder: 'desc',
      isMobile: false,
      isBlackAndWhite: true,
      openPopup: false,
      initializeDownload: true,
      viewMoreClinics: false,
      viewMoreProviders: false,
      viewMoreVestCodes: false
    };
    this.handleRangeChange = this.handleRangeChange.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleSessionDetail = this.handleSessionDetail.bind(this);
    this.setScreenSize = this.setScreenSize.bind(this);
    this.generatePdf = this.generatePdf.bind(this);
    this.stayWithOpen = this.stayWithOpen.bind(this);
    this.cancelDownload = this.cancelDownload.bind(this);
    this.displayClinics = this.displayClinics.bind(this);
    this.toggleViewMoreClinics = this.toggleViewMoreClinics.bind(this);
    this.displayProviderList = this.displayProviderList.bind(this);
    this.toggleViewMoreVestCodes = this.toggleViewMoreVestCodes.bind(this);
    this.getDiagnosisDeviceTypeCodes = this.getDiagnosisDeviceTypeCodes.bind(
      this
    );
    this.toggleViewMoreProviders = this.toggleViewMoreProviders.bind(this);
  }

  componentWillMount() {
    const { match, getPatientData, getClincData, getProviderData } = this.props;
    const { id } = match.params;
    getPatientData(id);
    getClincData(id);
    getProviderData(id);
  }

  componentDidMount() {
    const { addBreadCrumb, location } = this.props;
    addBreadCrumb(location, { title: strings.detailReport });
    this.setScreenSize();
  }

  componentWillUnmount() {
    const {
      resetPatientOverview,
      resetPatientSessionDetail,
      removeBreadCrumb
    } = this.props;
    resetPatientOverview();
    resetPatientSessionDetail();
    removeBreadCrumb();
    removeBreadCrumb();
  }

  componentWillReceiveProps(nextProps) {
    const { patient } = nextProps;
    if (patient.id && patient.id !== this.props.patient.id) {
      const { getPatientSessionData } = this.props;
      const { endDate, pageSz, pageNo, pageOrder } = this.state;
      const { id, firstTrans } = patient;
      const date1 = getMonthsAgoDate(constants.DEFAULT_MONTH_RANGE).startOf('month');
      const date2 = moment.utc(firstTrans);
      const startDate = getLatestMonth(date1, date2);
      this.setState({ startDate });
      const { timeZone } = getUserData();
      getPatientSessionData(id, startDate, getEndDate(endDate), pageSz, pageNo, pageOrder, timeZone);
    }
  }

  handleSessionDetail = () => {
    const { getPatientSessionData, patient } = this.props;
    const { id, firstTrans } = patient;
    let { startDate, endDate, pageSz, pageNo, pageOrder } = this.state;
    startDate = getLatestMonth(startDate, moment.utc(firstTrans));
    const { timeZone } = getUserData();
    getPatientSessionData(id, startDate, getEndDate(endDate), pageSz, pageNo, pageOrder, timeZone);
  };

  handlePageChange = activePage => {
    this.setState({ pageNo: activePage }, () => this.handleSessionDetail());
  };

  getBreadCrumb = breadcrumbs => {
    if (breadcrumbs.length === 1) {
      return null;
    }
    return (
      <Breadcrumb>
        {breadcrumbs.map(element => (
          <LinkContainer
            exact
            to={`${element.path}${element.search}`}
          >
            <Breadcrumb.Item active={element.active}>
              {element.title}
            </Breadcrumb.Item>
          </LinkContainer>
        ))}
      </Breadcrumb>
    );
  };

  stayWithOpen = () => {
    return false;
  };

  cancelDownload = () => {
    window.location.reload();
  };

  therapyMonthRange = () => {
    const { startDate, endDate } = this.state;
    const startingDate = startDate.clone();
    const betweenMonths = [];

    while (
      endDate > startingDate ||
      startingDate.format('M') === endDate.format('M')
    ) {
      betweenMonths.push(startingDate.clone());
      getEndDate(startingDate.add(1, 'month'));
    }
    return betweenMonths;
  };

  toggleViewMoreClinics = () => {
    this.setState({ viewMoreClinics: true });
  };

  toggleViewMoreVestCodes = () => {
    this.setState({ viewMoreVestCodes: true });
  };

  toggleViewMoreProviders = () => {
    this.setState({ viewMoreProviders: true });
  };

  componentDidUpdate(nextProps) {
    const { isAllowed } = nextProps;
    const { openPopup } = this.state;
    if (isAllowed === false && openPopup === true) {
      setTimeout(() => {
        this.setState({ openPopup: false });
      }, 2000);
    }
  }

  generatePdf = () => {
    const {
      downloadDetailedReport,
      patient,
      clinics,
      providers,
      setPdfDownloadStatus
    } = this.props;
    let { startDate, endDate } = this.state;
    const {
      id,
      flagged,
      firstName,
      lastName,
      isDeleted,
      hillromId,
      dob,
      inactiveReason,
      firstTrans
    } = patient;
    this.setState({ openPopup: true });
    setPdfDownloadStatus(true);
    const diagnosisCodeList = getDeviceTypeList(patient);
    startDate = getLatestMonth(startDate, moment.utc(firstTrans));
    endDate = getEndDate(endDate);
    const { timeZone, user } = getUserData();
    const reportRanDate = moment().format('YYYY/MM/DD hh:mm:ss');
    const reportRequester = `${user.firstName} ${user.lastName}`;
    const clinicList = clinics ? clinics.map(({ hillromId, name }) => {
      return { hillromId, name };
    }) : [];
    const providerList = providers ? providers.map(({ firstName, lastName, middleName }) => {
      return { firstName, lastName, middleName };
    }) : [];
    const diagnosisCodes = diagnosisCodeList ? diagnosisCodeList.map(({ type_code, type_code_value }) => {
      return { typeCode: type_code, typeCodeValue: type_code_value };
    }) : [];

    const params = { userId: id, startDate: startDate.format('YYYY-MM-DD'), endDate: endDate.format('YYYY-MM-DD'), timeZone: getTimeZoneOffset(timeZone) }
    const data = {
      flagged,
      firstName,
      lastName,
      isDeleted,
      inactiveReason,
      hillromId,
      dob,
      clinics: clinicList,
      diagnosisCodes,
      providers: providerList,
      reportRanDate,
      reportRequester
    };

    downloadDetailedReport(data, params, (blob) => {
      saveAs(blob, 'Detail Report.pdf');
      setPdfDownloadStatus(false);
    });
  }

  getDiagnosisDeviceTypeCodes = codes => {
    let list = [];
    if (codes && codes.length) {
      let code = [];
      code.push(codes[0]);
      list.push(getDiagnosisDeviceCodeList(code));
    }
    if (codes && codes.length > 1 && !this.state.viewMoreVestCodes) {
      list.push(
        <span className="viewMoreTab" onClick={this.toggleViewMoreVestCodes}>
          {` +${codes.length - 1} more`}
        </span>
      );
    }
    if (codes && codes.length > 1 && this.state.viewMoreVestCodes) {
      list.push(getDiagnosisDeviceCodeList(codes.slice(1, codes.length)));
    }
    return list;
  };

  displayClinics = clinics => {
    const list = [];
    if (clinics && clinics.length) {
      const clinic = [];
      clinic.push(clinics[0]);
      list.push(getClinicList(clinic));
    }
    if (clinics && clinics.length > 1 && !this.state.viewMoreClinics) {
      list.push(
        <span className="viewMoreTab" onClick={this.toggleViewMoreClinics}>
          {` +${clinics.length - 1} more`}
        </span>
      );
    }
    if (clinics && clinics.length > 1 && this.state.viewMoreClinics) {
      list.push(getClinicList(clinics.slice(1, clinics.length)));
    }
    return list;
  };

  displayProviderList = providers => {
    const list = [];
    if (providers && providers.length) {
      const provider = [];
      provider.push(providers[0]);
      list.push(getProviderList(provider));
    }
    if (providers && providers.length > 1 && !this.state.viewMoreProviders) {
      list.push(
        <span className="viewMoreTab" onClick={this.toggleViewMoreProviders}>
          {` +${providers.length - 1} more`}
        </span>
      );
    }
    if (providers && providers.length > 1 && this.state.viewMoreProviders) {
      list.push(getProviderList(providers.slice(1, providers.length)));
    }
    return list;
  };

  handleRangeChange = ({ startDate, endDate }) => {
    this.setState({ pageNo: 1, startDate, endDate }, () =>
      this.handleSessionDetail()
    );
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  render() {
    const {
      match,
      patient,
      clinics,
      providers,
      breadcrumbs,
      history,
      patientSessions,
      handleFlag
    } = this.props;
    const {
      startDate,
      endDate,
      isMobile,
      pageNo,
      pageSz,
      pageRange,
      openPopup
    } = this.state;
    const { id } = match.params;
    const deviceRef = {
      TITAN: titanLogo,
      VEST: visiVestLogo,
      MONARCH: monarchLogo
    };
    const { actualRole } = getUserData();
    const flagPatient = accessMatrix.FLAG_PATIENT[actualRole];
    const sideBarData = {
      activeKey: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    let sessionListItems = (
      <tr>
        <td colSpan="7" className="text-center text-capitalize">
          {strings.noSessionData}
        </td>
      </tr>
    );

    if (patientSessions && !isEmpty(patientSessions.content)) {
      if (isMobile) {
        sessionListItems = patientSessions.content.map((dateSet, idx) => {
          const sessionDuration = sumBy(dateSet.sessions, 'duration');
          return (
            <tr>
              <td>{moment(new Date(dateSet.date)).format('MMM D')}</td>
              <td>{sessionDuration} mins</td>
            </tr>
          );
        });
      } else {
        sessionListItems = patientSessions.content.map((dateSet, idx) => {
          const maxEventLen = sumBy(
            values(mapValues(dateSet.sessions, 'events')),
            'length'
          );
          return dateSet.sessions.map((session, sidx) => {
            if (session.events) {
              return session.events.map((event, eventidx) => {
                return (
                  <tr key={uid(event)}>
                    {sidx === 0 && eventidx === 0 && (
                      <td rowSpan={maxEventLen} className="rowspan text-center">
                        {dateSet.date}
                      </td>
                    )}
                    <td>
                      {event.time}
                    </td>
                    <td>{event.name}</td>
                    <td>{session.device === "VEST" && patient.isManual ? "" : event.frequency}</td>
                    <td>{session.device === "VEST" && patient.isManual ? "" : event.pressure}</td>
                    {eventidx === 0 && (
                      <React.Fragment>
                        <td
                          rowSpan={session.events.length}
                          className="rowspan text-center"
                        >
                          {session.duration} mins
                        </td>
                        <td
                          rowSpan={session.events.length}
                          className="rowspan text-center"
                        >
                          {session.device === "VEST" && patient.isManual ?
                            < img
                              src={manualLogo}
                              width="40"
                              height="20"
                              className="d-inline-block device-logo"
                              alt={'Manual Device'}
                            />
                            :
                            <img
                              src={deviceRef[session.device]}
                              width="28"
                              height="28"
                              className="d-inline-block device-logo"
                              alt={session.device}
                            />
                          }

                        </td>
                      </React.Fragment>
                    )}
                  </tr>
                );
              });
            }
            return '';
          });
        });
      }
    }

    const printButton = (
      <div id="print-button">
        <ButtonComponent
          buttonClass={isMobile ? '' : 'ml-4'}
          buttonAction={this.generatePdf}
          icon="report-icon"
          buttonText={strings.PRINTDETAILREPORT}
        />
      </div>
    );

    const progressTime = isNaN(this.props.progressTime)
      ? 0
      : Math.round(this.props.progressTime);

    return (
      <div>
        <Header
          history={history}
          displayScrollBar={isMobile}
          prevURL={urls.PATIENT.ALL}
          showBack
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && (
              <div className="d-flex justify-content-between">
                {this.getBreadCrumb(breadcrumbs)}
                {printButton}
              </div>
            )}
            {isMobile && (
              <div className="mt-2 mb-4 patient-name text-capitalize">
                {strings.detailReport}
              </div>
            )}

            <div className="row">
              <div className="col-md-6" />
              <div className="col-md-6 text-right" />
            </div>

            <div className={`${isMobile ? 'mb-4' : 'mt-2 mb-4'} patient-name`}>
              {flagPatient.read ? (
                flagPatient.write ? (
                  <span
                    onClick={e => {
                      handleFlag(
                        patient.id,
                        patient.patient_id,
                        patient.flagged,
                        allowFlag[actualRole]
                      );
                    }}
                    className={`align-middle d-inline-block patient-flag cursor ${patient.flagged ? 'hr-flag' : 'disable-flag'
                      }`}
                  />
                ) : patient.flagged ? (
                  <span
                    className={`align-middle d-inline-block patient-flag hr-flag`}
                  />
                ) : null
              ) : null}
              {[patient.firstName, patient.lastName].filter(Boolean).join(' ')}
            </div>
            <div className="row align-items-end patient-info-and-date-box">
              <div className="col-12 col-md-9 patient-info d-flex flex-column flex-sm-row flex-wrap">
                <span className="mr-3 d-inline-block">
                  <span className="key text-capitalize">
                    {strings.status}:{' '}
                  </span>
                  <span className="text text-capitalize">
                    {patient.isDeleted ? strings.inactive : strings.active}{' '}
                    {patient.isDeleted && patient.inactiveReason
                      ? `(${patient.inactiveReason})`
                      : ''}
                  </span>
                </span>
                <span className="mr-3 d-inline-block">
                  <span className="key text-capitalize">
                    {strings.o_hillromId}:{' '}
                  </span>
                  <span className="text">{patient.hillromId}</span>
                </span>
                <span className="mr-3 d-inline-block">
                  <span className="key text-capitalize">{strings.dob}: </span>
                  <span className="text">
                    {`${moment(patient.dob).isValid()
                      ? moment(patient.dob).format('DD MMM YYYY')
                      : '-'
                      }`}
                  </span>
                </span>
                {this.getDiagnosisDeviceTypeCodes(getDeviceTypeList(patient))}
                {this.displayProviderList(providers)}
                {this.displayClinics(clinics)}
              </div>
              <div className="col-12 col-md-3 text-right">
                <RangeMonthlyPicker
                  startDate={startDate}
                  endDate={endDate}
                  onChange={this.handleRangeChange}
                  min={patient.firstTrans}
                />
              </div>
            </div>
            <div className="row session-table-wrapper listing-pagination mobile-full-width-table">
              <div className="col-12">
                <div className="card">
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">{strings.o_date}</th>
                        <th scope="col" className="d-none d-sm-table-cell">
                          TIME
                        </th>
                        <th scope="col" className="d-none d-sm-table-cell">
                          EVENT
                        </th>
                        <th scope="col" className="d-none d-sm-table-cell">
                          FREQUENCY
                        </th>
                        <th scope="col" className="d-none d-sm-table-cell">
                          PRESSURE
                        </th>
                        <th scope="col">SESSION DURATION</th>
                        {!isMobile && (
                          <th scope="col" className="d-none d-sm-table-cell">
                            DEVICE
                          </th>
                        )}
                      </tr>
                    </thead>
                    <tbody>{sessionListItems}</tbody>
                  </table>
                </div>
                {patientSessions && patientSessions.content && (
                  <nav
                    aria-label="..."
                    className="d-flex justify-content-center justify-content-sm-end"
                  >
                    <Pagination
                      activePage={pageNo}
                      prevPageText="PREV"
                      nextPageText="NEXT"
                      itemClass="page-item"
                      linkClass="page-link"
                      activeLinkClass=""
                      itemsCountper_page={pageSz}
                      totalItemsCount={patientSessions.totalElements}
                      pageRangeDisplayed={pageRange}
                      onChange={this.handlePageChange}
                      firstPageText="FIRST"
                      lastPageText="LAST"
                    />
                  </nav>
                )}
              </div>
            </div>
            <FootNote />
            <Modal show={openPopup} onHide={this.stayWithOpen} centered>
              <Modal.Header className="justify-content-center bg-white">
                <Modal.Title className="text-dark">DOWNLODING</Modal.Title>
              </Modal.Header>
              <Modal.Body className="mt-4 mb-4 justify-content-center">
                <ProgressBar
                  striped
                  variant="dark"
                  role="progressbar"
                  animated
                  now={progressTime}
                  label={`${progressTime}%`}
                  style={{ height: '2rem', width: '100%' }}
                />
              </Modal.Body>
              <Modal.Footer className="justify-content-center">
                <Button variant="white" onClick={this.cancelDownload}>
                  Cancel
                </Button>
              </Modal.Footer>
            </Modal>
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { breadcrumbsReducer, patient } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    patient: patient.pData[id] || {},
    clinics: patient.pClinics[id],
    providers: patient.pProviders[id],
    patientSessions: patient.patientSessions[id] || {},
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    progressTime: patient.progressTime,
    isAllowed: patient.isAllowed
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getPatientData: id =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_DATA,
        data: { id }
      }),
    getClincData: id =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_CLINIC_DATA,
        data: { id }
      }),
    getProviderData: id =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_PROVIDER_DATA,
        data: { id }
      }),
    resetPatientOverview: () =>
      dispatch({
        type: constants.PATIENT.RESET_PATIENT_OVERVIEW
      }),
    resetPatientSessionDetail: () =>
      dispatch({
        type: constants.PATIENT.STORE_PATIENT_SESSION_DATA,
        data: {}
      }),
    getPatientSessionData: (id, start, end, pageSz, pageNo, order, timeZone) =>
      dispatch({
        type: constants.PATIENT.FETCH_PATIENT_SESSION_DATA,
        data: { id, start, end, pageSz, pageNo, order, timeZone }
      }),
    addBreadCrumb: (location, obj) =>
      dispatch({
        type: constants.BREADCRUMBS.BREADCRUMBS_ADD,
        data: {
          title: obj.title,
          path: location.pathname,
          search: location.search
        }
      }),
    removeBreadCrumb: () =>
      dispatch({ type: constants.BREADCRUMBS.BREADCRUMBS_REMOVE }),
    setTypeOfPdf: isBlackAndWhite =>
      dispatch({
        type: constants.PATIENT.SET_TYPE_OF_PDF,
        data: { isBlackAndWhite }
      }),
    downloadDetailedReport: (data, params, callbackFn) =>
      dispatch({
        type: constants.PATIENT.DOWNLOAD_DETAILED_REPORT,
        payload: { data, params, callbackFn }
      }),
    setPdfDownloadStatus: (status) =>
      dispatch({ type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD, data: status }),
    handleFlag: (userId, patientId, flag, entity) =>
      dispatch({
        type: constants.PATIENT.PATIENT_OVERVIEW_FLAG,
        data: {
          patientId,
          flagged: !flag,
          entity
        },
        userId
      })
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DetailReport);
