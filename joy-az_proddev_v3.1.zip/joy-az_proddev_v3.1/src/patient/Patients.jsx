import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment-timezone';
import { Header, SideBar } from 'components/Navigation';
import TableDisplay from 'components/TableDisplay';
import Search from 'components/Search';
import './patients.scss';
import strings from 'localization/strings';
import getCardComponent from 'components/CardComponent';
import { FootNote } from 'components/FootNote';
import { uid } from 'react-uid';
import urls from 'urls';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import SelectColorDialog from 'components/SelectColorDialog';
import debounce from 'lodash/debounce';
import { isUndefined, map, isEmpty } from 'lodash';
import ButtonComponent from 'components/ButtonComponent';
import RangeMonthlyPicker from 'components/RangeMonthPicker';
import { PDFDownloadLink } from '@react-pdf/renderer';
import { Form, ProgressBar, Modal, Button, Badge } from 'react-bootstrap';
import { saveAs } from 'file-saver';
import constants from '../constants';
import { decryptemail } from '../Cryptocode';
import {
  getUserData,
  customSort,
  getPaginatedUserIds,
  getTransmissionCell,
  getEndDate
} from '../utils/helper';
import {
  updateUrl,
  clearBreadCrumb,
  addBreadCrumb,
  clearCustomPatientStoreValue,
  clearAllSelectedCheckBoxes,
  storeSelectedPatientIds,
  selectAllCheckBoxes,
  deselectCheckBoxes
} from '../utils/utltity';
import {
  getManagePatientsFilters,
  getManageRolePatientsFilters,
  getManagePatientCardData,
  getDeviceImage,
  getSessionsField,
  getProviderField
} from './helper';
import roleMap from '../rolesData/roleMapping';
import { searchKeyMap, allowFlag } from '../rolesData/searchMapKey';
import Pdf from '../pdf-files/Pdf';
import { getEnhancedPatientsGroupData } from './utils/overview';
import accessMatrix from 'rolesData/accessMatrix.js';

class Patients extends Component {
  constructor(props) {
    const start = moment()
      .subtract(constants.DEFAULT_MONTH_RANGE, 'months')
      .startOf('month');
    const end = getEndDate();
    super(props);
    this.state = {
      patientViewVariant: constants.PATIENT_VARIANT.DEFAULT,
      pattern: '',
      pageNo: 1,
      pageSize: 10,
      sortBy: 'name',
      type: constants.FILTER_VALUES.ALL,
      transmission: constants.FILTER_VALUES.TRANSMITTING,
      active: 'temp-1',
      sortOrder: 'ASC',
      gender: constants.FILTER_VALUES.ALL,
      clinicSts: constants.FILTER_VALUES.ACTIVE,
      deviceSts: constants.FILTER_VALUES.ACTIVE,
      patientSts: constants.FILTER_VALUES.ACTIVE,
      ageRange: constants.FILTER_VALUES.ALL,
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      range: 90,
      clinicId: null,
      providerId: null,
      filterOn: false,
      viewMore: '',
      from: start.format('YYYY-MM-DD'),
      to: end.format('YYYY-MM-DD'),
      startDate: start,
      endDate: end,
      openPopup: false,
      pdf: '',
      isBlackAndWhite: true,
      allUserData: [],
      barCharts: {},
      gaugeGraphs: {},
      isMobile: false,
      selectedCheckBoxIds: [],
      showDialog: false
    };

    this.fetchPatients = this.fetchPatients.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.handleAll = this.handleAll.bind(this);
    this.getCardComponent = getCardComponent.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.updateUrl = updateUrl.bind(this);
    this.clearBreadCrumb = clearBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.filterCheck = this.filterCheck.bind(this);
    this.getProviderField = getProviderField.bind(this);
    this.getManagePatientsFilters = getManagePatientsFilters.bind(this);
    this.getManageRolePatientsFilters = getManageRolePatientsFilters.bind(this);
    this.handleCardChange = this.handleCardChange.bind(this);
    this.clearCustomPatientStoreValue = clearCustomPatientStoreValue.bind(this);
    this.generateBatchReport = this.generateBatchReport.bind(this);
    this.therapyMonthRange = this.therapyMonthRange.bind(this);
    this.handleRangeChange = this.handleRangeChange.bind(this);
    this.cancelDownload = this.cancelDownload.bind();
    this.closeWarnMsg = this.closeWarnMsg.bind();
    this.clearAllSelectedCheckBoxes = clearAllSelectedCheckBoxes.bind(this);
    this.storeSelectedPatientIds = storeSelectedPatientIds.bind(this);
    this.selectAllCheckBoxes = selectAllCheckBoxes.bind(this);
    this.deselectCheckBoxes = deselectCheckBoxes.bind(this);
    this.handleFlagged = this.handleFlagged.bind(this);

    this.changeSearch = debounce(() => {
      const { dispatch } = this.props;
      const { patientViewVariant } = this.state;
      const { actualRole } = getUserData();
      let payload = Object.assign({}, this.state);
      this.excempt.forEach(element => {
        delete payload[element];
      });
      let { pattern } = this.state;
      pattern = pattern.trim();
      payload = { ...payload, pattern };
      let { to, from, ...rest } = payload;
      payload = rest;
      if (patientViewVariant === constants.PATIENT_VARIANT.CUSTOM) {
        dispatch({
          type: constants.PATIENT.PATIENT_SEARCH_ROLE_REQUEST,
          payload,
          roleBaseKey: searchKeyMap[actualRole]
        });
      } else {
        dispatch({
          type: constants.PATIENT.PATIENT_SEARCH_REQUEST,
          payload
        });
      }
    }, constants.SEARCH_DEBOUNCE_MS);

    this.excempt = [
      'active',
      'isMobile',
      'startDate',
      'endDate',
      'pdf',
      'isDownloadable',
      'isBlackAndWhite',
      'allUserData',
      'barCharts',
      'gaugeGraphs',
      'openPopup',
      'initializeDownload',
      'pdfDownloadLink',
      'selectedCheckBoxIds',
      'viewMore',
      'order',
      'filterOn',
      'patientViewVariant',
      'checkBoxData',
      'showDialog'
    ];
  }

  componentWillMount() {
    const { dispatch } = this.props;
    const { role } = getUserData();
    this.clearCustomPatientStoreValue([
      'statesByCountry',
      'cityByStateCountry'
    ]);
    this.clearBreadCrumb();
    const payload = { ...this.state };
    this.excempt.forEach(element => {
      delete payload[element];
    });
    if (role !== constants.ROLES.SUPER_ADMIN) {
      this.setState({
        patientViewVariant: constants.PATIENT_VARIANT.CUSTOM,
        sortBy: null
      });
      this.fetchPatientsCountByRole(payload);
      dispatch({
        type: constants.CLINICS.CLINICS_SEARCH_REQUEST,
        payload: { page: 1, per_page: 100, sort_by: 'name', asc: true, status: 'all' }
      });
      dispatch({
        type: constants.PROVIDER.PROVIDER_REQUEST,
        payload: { page: 1, per_page: 100, asc: true, sort_by: 'firstName', country: null, state: null, city: null, status: 'all', clinicId: null }
      });
    } else {
      dispatch({
        type: constants.PATIENT.FETCH_PATIENTS_COUNT,
        payload
      });
    }
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const newState = { ...this.state };
    if (
      newState.country !== null &&
      newState.country !== '' &&
      !isUndefined(newState.country)
    ) {
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [newState.country] }
      });
      if (
        newState.state !== null &&
        newState.state !== '' &&
        !isUndefined(newState.state)
      ) {
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [newState.country], state: [newState.state] }
        });
      }
    } else {
      newState.country = null;
      newState.state = null;
      newState.city = null;
    }
    this.filterCheck();
    const { pattern } = this.state;
    if (pattern !== '') {
      this.dispatchSearch();
    } else {
      this.handleAll();
    }
    this.setScreenSize();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB,
      toggleValue: false
    });
  }

  getSearchString = obj => {
    const parts = [];
    Object.keys(obj).forEach(function nestedObject(element) {
      if (
        obj[element] === null ||
        element === 'filterOn' ||
        element === 'viewMore' ||
        obj[element] === ''
      )
        return;
      if (typeof obj[element] === 'object') {
        let s = `${element}=`;
        Object.keys(obj[element]).forEach(function noObject(ele) {
          s += `${ele}:${obj[element][ele]};`;
        });
        parts.push(s);
      } else {
        parts.push(`${element}=${obj[element]}`);
      }
    });

    return parts.join('&');
  };

  async getActiveCard() {
    const { active, patientViewVariant } = this.state;
    if (active === 'temp-1') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'session50'
            : 'titan'
      });
    }
    if (active === 'temp-2') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'session80'
            : 'monarch'
      });
    }
    if (active === 'temp-3') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'session100'
            : 'visi'
      });
    }
    if (active === 'temp-4') {
      await this.setState({ type: 'all' });
    }
    if (active === 'temp-5') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'titan'
            : 'new'
      });

    }
    if (active === 'temp-6') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'flagged'
            : 'multi'
      });
    }
    if (active === 'temp-7') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'monarch'
            : 'stopped'
      });
    }
    if (active === 'temp-8') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'monarch'
            : 'never'
      });
    }
    if (active === 'temp-9') {
      await this.setState({
        type:
          patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? 'vest'
            : 'inactive'
      });
    }

  }

  getClinicField = (index, clinicName) => {
    if (!clinicName || clinicName.length === 0) return null;
    let { viewMore } = this.state;
    if (clinicName.length === 1) {
      return clinicName[0];
    }
    return (
      <span>
        {clinicName[0]}
        <span
          name="view-more-patient-clinics"
          value={index}
          className={viewMore === index ? 'd-none' : 'view-more-patients'}
          onClick={() => {
            this.setState({ viewMore: index });
            viewMore = index;
          }}
          role="presentation"
        >
          {` +${clinicName.length - 1} more`}
        </span>
        <span className={viewMore === index ? '' : 'd-none'}>
          {clinicName.slice(1).map((element, idx) => {
            return <div key={uid(element, idx)}>{element}</div>;
          })}
        </span>
      </span>
    );
  };

  getPatientsBody() {
    const {
      pageSize,
      pageNo,
      sortOrder,
      sortBy,
      isMobile,
      selectedCheckBoxIds,
      patientViewVariant
    } = this.state;
    const { patients, history } = this.props;
    const userData = getUserData();
    const indexofLastItem = pageNo * pageSize;
    const indexOfFirstItem = indexofLastItem - pageSize;
    const flagPatient = accessMatrix.FLAG_PATIENT[userData.actualRole];
    let patientCopy = [
      ...map(patients, patient => {
        const tempPatient = { ...patient };
        tempPatient.patientInfo.providerInfo = tempPatient.providerInfo;
        return tempPatient.patientInfo;
      })
    ];
    if (sortBy) {
      patientCopy = customSort(patientCopy, sortBy, sortOrder.toLowerCase());
    }
    const currentPatientList = patientCopy.slice(
      indexOfFirstItem,
      indexofLastItem
    );
    if (!isEmpty(currentPatientList)) {
      return currentPatientList.map((patient, key) => (
        <tr
          key={uid(patient)}
          className="listing"
          onClick={event => {
            if (
              event.target.getAttribute('name') !==
              'view-more-provider-clinics' &&
              event.target.getAttribute('type') !== 'checkbox' &&
              event.target.getAttribute('name') !== 'flagged'
            ) {
              this.addBreadCrumb({ title: strings.managePatients });
              history.push(
                reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, {
                  id: patient.userId
                })
              );
            }
          }}
        >
          {!isMobile &&
            patientViewVariant === constants.PATIENT_VARIANT.CUSTOM && (
              <td>
                <div
                  onClick={event =>
                    this.storeSelectedPatientIds(event, patient.userId)
                  }
                >
                  <Form.Check
                    checked={
                      !isEmpty(selectedCheckBoxIds) &&
                      selectedCheckBoxIds.includes(patient.userId)
                    }
                    custom
                    type="checkbox"
                    label=""
                    className="body-check-box"
                    id={`check-box-${patient.userId}`}
                  />
                </div>
              </td>
            )}
          <td className="flagged align-middle">
            {flagPatient.read ? (
              <span
                name="flagged"
                className={`${flagPatient.write ? 'cursor' : 'no-cursor'
                  } d-inline-block ${patient.flagged ? 'hr-flag' : 'disable-flag'
                  }`}
                onClick={e => {
                  if (flagPatient.write) {
                    this.handleFlagged(
                      e,
                      patient.flagged,
                      patient.patientId,
                      allowFlag[userData.actualRole]
                    );
                  }
                }}
                role="presentation"
              />
            ) : null}
          </td>
          <td className="patient-name-cell">
            {`${patient.firstName || ''} ${patient.lastName || ''}`}
            {patient.isNew ? (
              <div className="d-inline new-tag">
                <span className="text-uppercase">{strings.new}</span>
              </div>
            ) : (
              ''
            )}
            {!patient.active ? (
              <div className="d-inline inactive-tag">
                <span className="text-uppercase">{strings.inactive}</span>
              </div>
            ) : (
              ''
            )}
            {!patient.active ? (
              <div className="inactive-warning">
                <span className="text-capitalize ">{patient.reason}</span>
              </div>
            ) : (
              ''
            )}
            <p className="secondary-data d-sm-none">{patient.email ? decryptemail(patient.email) : ''}</p>
          </td>
          <td id="clinic-name-providers" className="d-none d-sm-table-cell">
            {patient.providerInfo === null || patient.providerInfo.length === 0
              ? ''
              : this.getProviderField(key, patient.providerInfo)}
          </td>
          <td className="d-none d-sm-table-cell">
            {getTransmissionCell(patient)}
          </td>
          <td className="d-none d-sm-table-cell">
            {getDeviceImage(patient.devices, patient)}
          </td>
          <td className="patient-sessions-cell">
            {getSessionsField(patient.sessionPercentage)}
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td
          colSpan={`${!isMobile && patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
            ? '7'
            : '5'
            }`}
          className="text-center text-capitalize"
        >
          {strings.noPatientDataAvaliable}
        </td>
      </tr>
    );
  }

  fetchPatientsCountByRole = payload => {
    const { dispatch } = this.props;
    const { actualRole } = getUserData();
    dispatch({
      type: constants.PATIENT.FETCH_PATIENTS_ROLE_COUNT,
      entity: searchKeyMap[actualRole],
      data: payload
    });
  };

  dispatchSearch = (from, to) => {
    const { dispatch } = this.props;
    const { patientViewVariant } = this.state;
    const { actualRole } = getUserData();
    let payload = Object.assign({}, this.state);
    this.excempt.forEach(element => {
      delete payload[element];
    });
    if (from && to) {
      payload = { ...payload, from, to };
    }
    if (patientViewVariant === constants.PATIENT_VARIANT.CUSTOM) {
      dispatch({
        type: constants.PATIENT.PATIENT_SEARCH_ROLE_REQUEST,
        payload,
        roleBaseKey: searchKeyMap[actualRole]
      });
      this.fetchPatientsCountByRole(payload);
    } else {
      dispatch({
        type: constants.PATIENT.PATIENT_SEARCH_REQUEST,
        payload
      });
      dispatch({
        type: constants.PATIENT.FETCH_PATIENTS_COUNT,
        payload
      });
    }
  };

  onCardChange = (start, end) => {
    const { dispatch } = this.props;
    const { patientViewVariant } = this.state;
    const { actualRole } = getUserData();
    let payload = Object.assign({}, this.state);
    if (start && end) {
      payload.from = start;
      payload.to = end;
    }
    this.excempt.forEach(element => {
      delete payload[element];
    });
    if (patientViewVariant === constants.PATIENT_VARIANT.CUSTOM) {
      dispatch({
        type: constants.PATIENT.PATIENT_SEARCH_ROLE_REQUEST,
        payload,
        roleBaseKey: searchKeyMap[actualRole]
      });
    } else {
      dispatch({
        type: constants.PATIENT.PATIENT_SEARCH_REQUEST,
        payload
      });
    }
  };

  listPatients = () => {
    const { patients, history } = this.props;
    if (!isEmpty(patients)) {
      return patients.map(d => (
        <tr
          className="listing"
          key={uid(d)}
          name="patient-row"
          onClick={event => {
            this.addBreadCrumb({ title: strings.managePatients });
            if (
              event.target.getAttribute('name') !== 'view-more-patient-clinics'
            ) {
              history.push(
                reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id: d.userID })
              );
            }
          }}
        >
          <td id="patient-name-patient">
            {`${d.firstName} ${d.lastName}`}
            {d.new ? (
              <div className="d-inline new-tag">
                <span className="text-uppercase">{strings.new}</span>
              </div>
            ) : (
              ''
            )}
            {!d.active ? (
              <div className="d-inline inactive-tag">
                <span className="text-uppercase">{strings.inactive}</span>
              </div>
            ) : (
              ''
            )}
            {!d.active ? (
              <div className="inactive-warning">
                <span className="text-capitalize ">{d.reason}</span>
              </div>
            ) : (
              ''
            )}
            <p className="secondary-data d-sm-none">{d.hrID}</p>
          </td>
          <td id="hillrom-id-patient" className="d-none d-sm-table-cell">
            {d.hrID}
          </td>
          <td id="clinic-name-patient" className="d-none d-sm-table-cell">
            {d.clinicName === null
              ? d.clinicName
              : this.getClinicField(patients.indexOf(d), d.clinicName)}
          </td>
          <td id="last-transmission-patient">{getTransmissionCell(d)}</td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="4" className="text-center text-capitalize">
          {strings.noPatientDataAvaliable}
        </td>
      </tr>
    );
  };

  getActiveCardName = () => {
    const { active, patientViewVariant } = this.state;
    switch (active) {
      case 'temp-1':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.totalPatients
          : strings.titanPatients;

      case 'temp-2':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? `${strings.sessionsCompleted} ${strings.session1}`
          : strings.monarchPatients;

      case 'temp-3':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? `${strings.sessionsCompleted} ${strings.session2}`
          : strings.visiVestPatients;

      case 'temp-4':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? `${strings.sessionsCompleted} ${strings.session3}`
          : strings.totalPatients;

      case 'temp-5':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.flaggedPatients
          : strings.newlyAddedPatients;

      case 'temp-6':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.titanPatients
          : strings.multiDevicePatients;

      case 'temp-7':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.monarchPatients
          : strings.stoppedTransmitting;
      case 'temp-8':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.visiVestPatients
          : strings.neverTransmitted;

      case 'temp-9':
        return patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
          ? strings.multiDevicePatients
          : strings.inactivePatients;
      default:
        return strings.totalPatients;
    }
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  cancelDownload = () => {
    window.location.reload();
  };

  closeWarnMsg = () => {
    this.setState({ openPopup: false });
  };

  saveFileAsPdf = blob => {
    const { dispatch } = this.props;
    dispatch({ type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD, data: false });
    saveAs(blob, 'Batch Report.pdf');
    dispatch({ type: constants.PATIENT.RESET_PROPS_VALUES });
  };

  therapyMonthRange = () => {
    const { startDate, endDate } = this.state;
    const startingDate = startDate.clone();
    const betweenMonths = [];

    while (
      endDate > startingDate ||
      startingDate.format('M') === endDate.format('M')
    ) {
      betweenMonths.push(startingDate.clone());
      getEndDate(startingDate.add(1, 'month'));
    }
    return betweenMonths;
  };

  handleRangeChange = ({ startDate, endDate }) => {
    this.setState({ startDate, endDate, pageNo: 1 });
    const from = startDate
      .clone()
      .startOf('month')
      .format('YYYY-MM-DD');
    const to = getEndDate(endDate).format('YYYY-MM-DD');
    this.setState({ from, to });
    this.dispatchSearch(from, to);
  };

  filterCheck = () => {
    const {
      clinicSts,
      gender,
      country,
      state,
      patientSts,
      range,
      deviceSts,
      transmission,
      clinicId,
      providerId,
      ageRange
    } = this.state;
    if (
      clinicSts === constants.FILTER_VALUES.ACTIVE &&
      ageRange === constants.FILTER_VALUES.ALL &&
      gender === constants.FILTER_VALUES.ALL &&
      country === constants.LOCATIONS[0] &&
      state === null &&
      deviceSts === constants.FILTER_VALUES.ACTIVE &&
      patientSts === constants.FILTER_VALUES.ACTIVE &&
      range === 90 &&
      transmission === constants.FILTER_VALUES.TRANSMITTING &&
      (clinicId === '' || clinicId === null) &&
      (providerId === '' || providerId === null)
    ) {
      this.setState({ filterOn: false });
    } else {
      this.setState({ filterOn: true });
    }
  };

  async handleAll() {
    this.getActiveCard();
    this.dispatchSearch();
  }

  async handleCardChange(obj) {
    const { dispatch } = this.props;
    dispatch({ type: constants.PATIENT.CLEAR_TABLE });
    await this.setState({ pageNo: 1, ...obj });
    this.onCardChange();
    this.clearAllSelectedCheckBoxes();
  }

  async handleSorting(event) {
    const { sortOrder, sortBy, patientViewVariant } = this.state;
    const { name } = event.target;
    if (patientViewVariant === constants.PATIENT_VARIANT.CUSTOM) {
      const orderMap = {
        ASC: 'DESC',
        DESC: 'ASC'
      };
      if (sortBy === name) {
        await this.setState({ sortOrder: orderMap[sortOrder] });
      } else {
        await this.setState({ sortBy: name, sortOrder: 'ASC' });
      }
    } else {
      if (sortBy !== name) {
        await this.setState({ sortBy: name, sortOrder: 'ASC' });
      } else if (sortOrder === 'ASC') {
        await this.setState({ sortOrder: 'DESC' });
      } else {
        await this.setState({ sortOrder: 'ASC' });
      }
      this.dispatchSearch();
    }
    await this.setState({ pageNo: 1 });
    this.updateUrl();
  }

  async handleFlagged(e, flag, patientId, entity) {
    const { dispatch } = this.props;
    let payload = Object.assign({}, this.state);
    this.excempt.forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.PATIENT.PATIENT_FLAG,
      data: {
        patientId,
        flagged: !flag,
        payload,
        entity
      }
    });
  }

  async fetchPatients(event) {
    const { value } = event.target;
    if (!value) {
      this.resetFilter();
    } else {
      const { pattern } = this.state;
      await this.setState({
        viewMore: '',
        pattern: value,
        type: 'simple',
        pageNo: 1,
        perPage: 10,
        transmission: constants.FILTER_VALUES.ALL,
        patientSts: constants.FILTER_VALUES.ALL,
        deviceSts: constants.FILTER_VALUES.ALL,
        clinicSts: constants.FILTER_VALUES.ALL,
        gender: constants.FILTER_VALUES.ALL,
        ageRange: constants.FILTER_VALUES.ALL,
        country: null,
        city: null,
        state: null,
        range: constants.FILTER_VALUES.ALL
      });
      if (value.trim() !== pattern.trim()) {
        this.changeSearch();
      }
    }
  }

  async handlePaginate(pageNumber) {
    const { patientViewVariant } = this.state;
    await this.setState({ pageNo: pageNumber });
    if (patientViewVariant !== constants.PATIENT_VARIANT.CUSTOM) {
      await this.dispatchSearch();
    }
    this.updateUrl(this.excempt);
  }

  async handleFilter(event) {
    const { dispatch } = this.props;
    const { name, value } = event.target;
    if (name === 'country') {
      if (value === 'country') {
        await this.setState({ country: null });
        const { state, city } = this.state;
        if (state !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ state: null });
        }
        if (city !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ city: null });
        }
      } else {
        dispatch({
          type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
          payload: { country: [value] }
        });
        await this.setState({
          [name]: value,
          city: null,
          state: null,
          pageNo: 1
        });
        this.clearCustomPatientStoreValue([
          'statesByCountry',
          'cityByStateCountry'
        ]);
      }
    } else if (name === 'state') {
      if (value === 'state') {
        await this.setState({ state: null, city: null });
        this.clearCustomPatientStoreValue(['cityByStateCountry']);
      } else {
        const { country } = this.state;
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [country], state: [value] }
        });
        await this.setState({ [name]: value, city: null, pageNo: 1 });
      }
    } else if (name === 'city') {
      if (value === 'city') {
        await this.setState({ city: null });
      } else {
        await this.setState({ [name]: value, pageNo: 1 });
      }
    } else if (name === 'range') {
      await this.setState({
        [name]: value === constants.FILTER_VALUES.ALL ? value : Number(value),
        pageNo: 1
      });
    } else if (name === 'clinicId') {
      await this.setState({ [name]: value ? value : null, pageNo: 1, providerId: null });
      await dispatch({
        type: constants.PROVIDER.PROVIDER_REQUEST,
        payload: { page: 1, per_page: 100, asc: true, sort_by: 'firstName', country: null, state: null, city: null, status: 'all', clinicId: value }
      });
    }
    else {
      await this.setState({ [name]: value ? value : null, pageNo: 1 });
    }
    this.filterCheck();
    this.dispatchSearch();
  }

  async resetFilter() {
    const { dispatch } = this.props;
    if (this.state.country === constants.LOCATIONS[0]) {
      this.clearCustomPatientStoreValue(['cityByStateCountry']);
    } else {
      this.clearCustomPatientStoreValue([
        'statesByCountry',
        'cityByStateCountry'
      ]);
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [constants.LOCATIONS[0]] }
      });
    }
    await this.setState({
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      range: 90,
      pattern: '',
      gender: constants.FILTER_VALUES.ALL,
      clinicSts: constants.FILTER_VALUES.ACTIVE,
      patientSts: constants.FILTER_VALUES.ACTIVE,
      deviceSts: constants.FILTER_VALUES.ACTIVE,
      ageRange: constants.FILTER_VALUES.ALL,
      providerId: null,
      clinicId: null,
      transmission: constants.FILTER_VALUES.TRANSMITTING
    });
    this.filterCheck();
    this.handleAll();
  }

  handleColorChange = isBlackAndWhite => {
    this.setState({ isBlackAndWhite, showDialog: false });

    const { selectedCheckBoxIds } = this.state;
    this.setState({ openPopup: true });
    if (!isEmpty(selectedCheckBoxIds)) {
      const { dispatch } = this.props;
      const { startDate, endDate } = this.state;
      const { timeZone } = getUserData();
      dispatch({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENTS_OVERVIEW,
        data: {
          patientIds: this.getPatientIdsWithLastTrans(selectedCheckBoxIds),
          start: startDate,
          end: getEndDate(endDate),
          timeZone,
          extendedInfo: false
        }
      });

      dispatch({ type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD, data: true });

      dispatch({
        type: constants.PATIENT.SET_TYPE_OF_PDF,
        data: { isBlackAndWhite }
      });
    }
  };

  getPatientIdsWithLastTrans = ids => {
    const { patients } = this.props;
    const list = [];
    patients.forEach(patient => {
      const { userId, firstTrans } = patient.patientInfo;
      if (ids.includes(userId)) {
        list.push({ id: userId, firstTrans });
      }
    });
    return list;
  };

  async generateBatchReport() {
    this.setState({ showDialog: true });
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.props.isAllowed === true &&
      this.state.openPopup === true &&
      nextProps.isAllowed === false
    ) {
      this.setState({ openPopup: false });
    }
  }

  render() {
    const {
      totalUsers,
      totalPatients,
      titanPatients,
      monarchPatients,
      visiVestPatients,
      neverTransPatients,
      inactivePatients,
      multiDevicePatients,
      newlyAddedPatients,
      flaggedPatients,
      session50Patients,
      session80Patients,
      session100Patients,
      stoppedTransmitting,
      statesByCountry,
      cityByStateCountry,
      clinicFilterList,
      providerFilterList,
      showSearch,
      patients,
      enhancedPatientsGroupData
    } = this.props;
    const {
      from,
      openPopup,
      to,
      isBlackAndWhite,
      isMobile,
      patientViewVariant,
      selectedCheckBoxIds
    } = this.state;
    const { actualRole } = getUserData();
    const searchPatients = accessMatrix.SEARCH_PATIENTS[actualRole];
    const {
      patientsData,
      minuteGaugeGraph,
      sessionGaugeGraph,
      barCharts
    } = enhancedPatientsGroupData;
    const checkBoxData =
      !isMobile && patientViewVariant === constants.PATIENT_VARIANT.CUSTOM
        ? {
          paginatedPatientIds: getPaginatedUserIds(
            this.state,
            this.props,
            constants.PATIENT
          ),
          selectedPatientIds: selectedCheckBoxIds,
          isCheckBoxRequired: true,
          selectAllCheckBoxes: this.selectAllCheckBoxes,
          deselectCheckBoxes: this.deselectCheckBoxes
        }
        : {};

    const { pattern, pageNo, pageSize, filterOn, active } = this.state;
    const { role } = getUserData();
    const cardData =
      role === roleMap.ADMIN
        ? [
          {
            value:
              filterOn && active === 'temp-1' && patients !== null
                ? titanPatients || 0
                : titanPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-1',
                type: constants.FILTER_VALUES.TITAN
              });
            },
            title: strings.titanPatients,
            filterIcon: filterOn,
            logo: require('../assets/img/logo/titanlogo.png')
          },
          {
            value:
              filterOn && active === 'temp-2' && patients !== null
                ? totalUsers || 0
                : monarchPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-2',
                type: constants.FILTER_VALUES.MONARCH
              });
            },
            title: strings.monarchPatients,
            filterIcon: filterOn,
            logo: require('../assets/img/logo/monarch.png')
          },
          {
            value:
              filterOn && active === 'temp-3' && patients !== null
                ? totalUsers || 0
                : visiVestPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-3',
                type: constants.FILTER_VALUES.VEST
              });
            },
            title: strings.visiVestPatients,
            filterIcon: filterOn,
            logo: require('../assets/img/logo/visivest.png')
          },
          {
            value:
              filterOn && active === 'temp-4' && patients !== null
                ? totalUsers || 0
                : totalPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-4',
                type: constants.FILTER_VALUES.ALL
              });
            },
            title: strings.totalPatients,
            filterIcon: filterOn
          },
          {
            value:
              filterOn && active === 'temp-5' && patients !== null
                ? totalUsers || 0
                : newlyAddedPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-5',
                type: constants.FILTER_VALUES.NEW
              });
            },
            title: strings.newlyAddedPatients,
            filterIcon: filterOn
          },
          {
            value:
              filterOn && active === 'temp-6' && patients !== null
                ? totalUsers || 0
                : multiDevicePatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-6',
                type: constants.FILTER_VALUES.MULTI
              });
            },
            title: strings.multiDevicePatients,
            filterIcon: filterOn
          },
          {
            value:
              filterOn && active === 'temp-7' && patients !== null
                ? totalUsers || 0
                : stoppedTransmitting,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-7',
                type: constants.FILTER_VALUES.STOP
              });
            },
            title: strings.stoppedTransmitting,
            filterIcon: filterOn
          },
          {
            value:
              filterOn && active === 'temp-8' && patients !== null
                ? totalUsers || 0
                : neverTransPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-8',
                type: constants.FILTER_VALUES.NEVER
              });
            },
            title: strings.neverTransmitted,
            filterIcon: filterOn
          },
          {
            value:
              filterOn && active === 'temp-9' && patients !== null
                ? totalUsers || 0
                : inactivePatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-9',
                type: constants.FILTER_VALUES.INACTIVE
              });
            },
            title: strings.inactivePatients,
            filterIcon: filterOn
          },
        ]
        : [
          {
            title: strings.totalPatients,
            value:
              filterOn && active === 'temp-1' && patients !== null
                ? totalUsers || 0
                : totalPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-1',
                type: constants.FILTER_VALUES.ALL,
              });
            },
            filterIcon: filterOn
          },
          {
            title: strings.sessionsCompleted,
            value:
              filterOn && active === 'temp-2' && patients !== null
                ? totalUsers || 0
                : session50Patients,
            sessionValues: strings.session1,
            customClass: 'red-inactive-card',
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-2',
                type: constants.FILTER_VALUES.SESSION50
              });
            },
            filterIcon: filterOn
          },

          {
            title: strings.sessionsCompleted,
            value:
              filterOn && active === 'temp-3' && patients !== null
                ? totalUsers || 0
                : session80Patients,
            sessionValues: strings.session2,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-3',
                type: constants.FILTER_VALUES.SESSION80
              });
            },
            customClass: 'yellow-session-card',
            filterIcon: filterOn
          },
          {
            title: strings.sessionsCompleted,
            value:
              filterOn && active === 'temp-4' && patients !== null
                ? totalUsers || 0
                : session100Patients,
            sessionValues: strings.session3,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-4',
                type: constants.FILTER_VALUES.SESSION100
              });
            },
            customClass: 'green-active-card',
            filterIcon: filterOn
          },
          {
            title: strings.flaggedPatients,
            value:
              filterOn && active === 'temp-5' && patients !== null
                ? totalUsers || 0
                : flaggedPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-5',
                type: constants.FILTER_VALUES.FLAGGED
              });
            },
            filterIcon: filterOn
          },
          {
            title: strings.titanPatients,
            value:
              filterOn && active === 'temp-6' && patients !== null
                ? totalUsers || 0
                : titanPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-6',
                type: constants.FILTER_VALUES.TITAN
              });
            },
            filterIcon: filterOn
          },
          {
            title: strings.monarchPatients,
            value:
              filterOn && active === 'temp-7' && patients !== null
                ? totalUsers || 0
                : monarchPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-7',
                type: constants.FILTER_VALUES.MONARCH
              });
            },
            filterIcon: filterOn
          },
          {
            title: strings.visiVestPatients,
            value:
              filterOn && active === 'temp-8' && patients !== null
                ? totalUsers || 0
                : visiVestPatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-8',
                type: constants.FILTER_VALUES.VEST
              });
            },
            filterIcon: filterOn
          },
          {
            title: strings.multiDevicePatients,
            value:
              filterOn && active === 'temp-9' && patients !== null
                ? totalUsers || 0
                : multiDevicePatients,
            handleFunction: () => {
              this.handleCardChange({
                active: 'temp-9',
                type: constants.FILTER_VALUES.MULTI
              });
            },
            filterIcon: filterOn
          }


        ];

    const showWarn = isEmpty(selectedCheckBoxIds);
    const barChartRefLength = !isEmpty(barCharts)
      ? Object.keys(barCharts).length
      : 0;
    const minuteGaugeGraphRefLength = !isEmpty(minuteGaugeGraph)
      ? Object.keys(minuteGaugeGraph).length
      : 0;
    const sessionGaugeGraphRefLength = !isEmpty(sessionGaugeGraph)
      ? Object.keys(sessionGaugeGraph).length
      : 0;
    const multiProgressTime = this.props.multiProgressTime;
    return (
      <div>
        {!isMobile && barChartRefLength !== 0 && Object.values(barCharts)}
        {!isMobile && minuteGaugeGraphRefLength !== 0 && (
          <div style={{ display: 'none' }}>
            {Object.values(minuteGaugeGraph)}
          </div>
        )}
        {!isMobile && sessionGaugeGraphRefLength !== 0 && (
          <div style={{ display: 'none' }}>
            {Object.values(sessionGaugeGraph)}
          </div>
        )}
        <Header
          searchExitHandle={async () => {
            await this.setState({ pattern: '' });
            this.getActiveCard();
            this.updateUrl(this.excempt);
            this.dispatchSearch();
          }}
        />
        {searchPatients.read ? (
          <MainWrapper>
            {patientViewVariant === constants.PATIENT_VARIANT.DEFAULT && (
              <SideBar
                filters={this.getManagePatientsFilters({
                  currState: this.state,
                  handleFilter: this.handleFilter,
                  cityByStateCountry,
                  statesByCountry
                })}
                resetFilter={this.resetFilter}
                hidden={pattern === '' ? null : true}
                showSearch={showSearch}
                filterOn={filterOn}
              />
            )}
            {patientViewVariant === constants.PATIENT_VARIANT.CUSTOM && (
              <SideBar
                filters={this.getManageRolePatientsFilters({
                  currState: this.state,
                  handleFilter: this.handleFilter,
                  clinicFilterList,
                  providerFilterList,
                  ignores:
                    role === constants.ROLES.PROVIDER ? ['Provider_Name'] : []
                })}
                resetFilter={this.resetFilter}
                hidden={pattern === '' ? null : true}
                showSearch={showSearch}
                filterOn={filterOn}
              />
            )}
            <MainContent
              {...(!isMobile && pattern !== ''
                ? { styleClass: 'col-md-10 table-search-desktop' }
                : {})}
            >
              <div>
                <div className="table-header d-flex flex-wrap align-items-center">
                  <h1
                    className={` ${showSearch === true
                      ? 'd-none'
                      : 'd-block d-sm-inline marginv-auto page-desc text-capitalize'
                      }`}
                  >
                    {pattern === ''
                      ? strings.managePatients
                      : strings.searchPatients}
                  </h1>
                  <Search
                    searchString={pattern}
                    fetchOnChange={this.fetchPatients}
                    modifierClass="d-sm-inline"
                    showSearch={showSearch}
                    placeholder={
                      patientViewVariant === constants.PATIENT_VARIANT.DEFAULT
                        ? strings.patientSearchPlaceholder
                        : strings.associatedPatientSearchPlaceholder
                    }
                  />
                  {!isMobile && (
                    <span
                      className={`${pattern !== ''
                        ? 'table-search-exit cross-icon d-md-inline-block ml-auto'
                        : 'd-none'
                        }`}
                      name="resetSearch"
                      onClick={this.fetchPatients}
                      onKeyPress={this.fetchPatients}
                      tabIndex={0}
                      role="button"
                    />
                  )}
                  {role &&
                    pattern === '' &&
                    !isMobile &&
                    patientViewVariant === constants.PATIENT_VARIANT.CUSTOM && (
                      <ButtonComponent
                        buttonClass="float-right ml-auto"
                        buttonAction={() => this.generateBatchReport()}
                        icon="report-detail-icon"
                        buttonText={strings.batchReport}
                      />
                    )}
                </div>
                {role &&
                  pattern === '' &&
                  !isMobile &&
                  patientViewVariant === constants.PATIENT_VARIANT.CUSTOM && (
                    <div
                      className="col-md-3 text-right float-right d-inline ml-4 mt-2"
                      id="date-picker"
                    >
                      <RangeMonthlyPicker
                        startDate={moment(from)}
                        endDate={moment(to)}
                        onChange={this.handleRangeChange}
                      />
                    </div>
                  )}
              </div>
              <div
                id="manage-patients"
                className={`${pattern === '' ? 'container-fluid' : 'd-none'} ${showSearch === true ? 'd-none' : 'container-fluid'
                  }`}
              >
                <div
                  id="top-layer"
                  className="row flex-row flex-nowrap flex-sm-wrap justify-content-space-between"
                >
                  {this.getCardComponent(
                    getManagePatientCardData(cardData),
                    this.state
                  )}
                </div>
              </div>
              <div>
                <div>
                  <h6
                    className={`${pattern === '' ? 'd-none' : 'text-capitalize show-search'
                      } `}
                  >{`${strings.searchResults} (${totalUsers || 0})`}</h6>
                </div>
                <div
                  className={`justify-content-between ${pattern ? 'd-none' : 'd-flex table-description'
                    }`}
                >
                  <h6>{this.getActiveCardName()}</h6>
                  {patientViewVariant === constants.PATIENT_VARIANT.CUSTOM &&
                    !isMobile &&
                    !isEmpty(selectedCheckBoxIds) && (
                      <div>
                        <span className="pr-2 align-middle text-uppercase">
                          <Badge pill className="hr-badge">
                            {selectedCheckBoxIds.length}
                          </Badge>
                          <span className="align-middle">
                            {' '}
                            {strings.selected}
                          </span>
                        </span>
                        <ButtonComponent
                          buttonClass="btn btn-outline-info"
                          noDefault
                          buttonAction={() => this.clearAllSelectedCheckBoxes()}
                          buttonText={strings.resetAll}
                        />
                      </div>
                    )}
                </div>
                <Modal show={openPopup} onHide={this.stayWithOpen} centered>
                  <Modal.Header className="justify-content-center bg-white">
                    <Modal.Title className="text-dark">
                      {showWarn ? strings.WARNING : strings.DOWNLOADING}
                    </Modal.Title>
                  </Modal.Header>
                  <Modal.Body className="mt-4 mb-4 justify-content-center">
                    {showWarn ? (
                      strings.warningMessage
                    ) : (
                      <ProgressBar
                        striped
                        variant="dark"
                        role="progressbar"
                        animated
                        now={multiProgressTime}
                        label={`${multiProgressTime}%`}
                        style={{ height: '2rem' }}
                      />
                    )}
                  </Modal.Body>
                  <Modal.Footer className="justify-content-center">
                    {showWarn ? (
                      <Button variant="white" onClick={this.closeWarnMsg}>
                        {strings.ok}
                      </Button>
                    ) : (
                      <Button variant="white" onClick={this.cancelDownload}>
                        {strings.cancel}
                      </Button>
                    )}
                  </Modal.Footer>
                </Modal>
                {patientViewVariant === constants.PATIENT_VARIANT.DEFAULT && (
                  <TableDisplay
                    heading={[
                      {
                        text: strings.patientName,
                        sortable: true,
                        name: 'name',
                        value: 'name'
                      },
                      {
                        text: strings.hillromID,
                        sortable: true,
                        name: 'hrID',
                        value: 'hrID',
                        mobile: false
                      },
                      {
                        text: strings.clinicName,
                        sortable: true,
                        name: 'clinicName',
                        value: 'clinicName',
                        mobile: false
                      },
                      {
                        text: strings.lastTransmission,
                        sortable: true,
                        name: 'lastTrans',
                        value: 'lastTrans'
                      }
                    ]}
                    totalUsers={totalUsers}
                    listing={this.listPatients()}
                    handleSorting={this.handleSorting}
                    pagination
                    handlePaginate={this.handlePaginate}
                    perPage={pageSize}
                    page={pageNo}
                    totalDisplayLabel={strings.patients}
                    searchString={pattern}
                    showSearchToggle
                    noResultFound={strings.noPatientDataAvaliable}
                  />
                )}

                {patientViewVariant === constants.PATIENT_VARIANT.CUSTOM && (
                  <TableDisplay
                    heading={[
                      {
                        text: '',
                        name: 'flagged',
                        value: 'flagged'
                      },
                      {
                        text: strings.patientName,
                        sortable: true,
                        name: 'firstName',
                        value: 'firstName'
                      },
                      {
                        text: strings.providerName,
                        sortable: false,
                        name: 'providerName',
                        value: 'providerName',
                        mobile: false
                      },
                      {
                        text: strings.lastTransmission,
                        sortable: true,
                        name: 'lastTrans',
                        value: 'lastTrans',
                        mobile: false
                      },
                      {
                        text: strings.device,
                        sortable: false,
                        name: 'device',
                        value: 'device',
                        mobile: false
                      },
                      {
                        text: strings.completedSessions,
                        sortable: true,
                        name: 'sessionPercentage',
                        value: 'sessionPercentage'
                      }
                    ]}
                    totalUsers={totalUsers}
                    listing={this.getPatientsBody()}
                    handleSorting={this.handleSorting}
                    pagination
                    handlePaginate={this.handlePaginate}
                    perPage={pageSize}
                    page={pageNo}
                    totalDisplayLabel={strings.patients}
                    searchString={pattern}
                    showSearchToggle
                    checkBoxData={checkBoxData}
                    noResultFound={strings.noPatientDataAvaliable}
                  />
                )}
              </div>
              <FootNote />
            </MainContent>
          </MainWrapper>
        ) : null}

        {!isEmpty(patientsData) && (
          <div style={{ dispatch: 'none' }}>
            <PDFDownloadLink
              id="pdf-dowload"
              className="downloadlink text-uppercase"
              document={
                <Pdf
                  data={patientsData}
                  isBlackAndWhite={isBlackAndWhite}
                  tableRequired={false}
                />
              }
              fileName="Batch Report.pdf"
            >
              {({ blob, loading }) => (loading ? '' : this.saveFileAsPdf(blob))}
            </PDFDownloadLink>
          </div>
        )}
        <SelectColorDialog
          show={this.state.showDialog}
          handleClose={() => this.setState({ showDialog: false })}
          handleChange={this.handleColorChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  const { patient, filterReducer, clinicsReducer, providerReducer } = state.app;
  return {
    patients: patient.patients,
    totalUsers: patient.totalUsers,
    totalPatients: patient.totalPatients,
    titanPatients: patient.titanPatients,
    monarchPatients: patient.monarchPatients,
    visiVestPatients: patient.visiVestPatients,
    multiDevicePatients: patient.multiDevicePatients,
    flaggedPatients: patient.flaggedPatients,
    session50Patients: patient.session50Patients,
    session80Patients: patient.session80Patients,
    session100Patients: patient.session100Patients,
    neverTransPatients: patient.neverTransPatients,
    inactivePatients: patient.inactivePatients,
    newlyAddedPatients: patient.newlyAddedPatients,
    stoppedTransmitting: patient.stoppedTransPatients,
    statesByCountry: patient.statesByCountry,
    cityByStateCountry: patient.cityByStateCountry,
    clinicFilterList: clinicsReducer.clinics,
    providerFilterList: customSort(providerReducer.providers, 'firstName', 'asc'),
    showSearch: filterReducer.showSearch,
    enhancedPatientsGroupData: patient.patientsEnhancedOverview
      ? getEnhancedPatientsGroupData(
        patient.patientsEnhancedOverview,
        patient.isBlackAndWhite,
        true
      )
      : {},
    allMonthsTherapyData: patient.allMonthsTherapyData,
    multiProgressTime: patient.multiProgressTime,
    isAllowed: patient.isAllowed
  };
};
export default connect(
  mapStateToProps,
  null
)(Patients);