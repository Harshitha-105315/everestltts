import constants from 'constants.js';
import strings from 'localization/strings';
import { setStateByKey, pinnedSort } from 'utils/helper.js';
import { each } from 'lodash';
import moment from 'moment';

const initialState = {
  pData: {},
  pUserData: {},
  pClinics: {},
  pProviders: {},
  pProtocols: {},
  patients: [],
  totalUsers: 0,
  totalPatients: 0,
  titanPatients: 0,
  monarchPatients: 0,
  visiVestPatients: 0,
  multiDevicePatients: 0,
  flaggedPatients: 0,
  session50Patients: 0,
  session80Patients: 0,
  session100Patients: 0,
  neverTransPatients: 0,
  inactivePatients: 0,
  stoppedTransPatients: 0,
  newlyAddedPatients: 0,
  patientInfo: {},
  pmTherapy: {},
  pmEnhancedTherapy: {},
  pmEnhancedTherapyMonth: {},
  patientsSpiroData: [],
  patientYearTherapyData: [],
  patientsRangeEnhancedTherapy: {},
  patientsEnhancedOverview: {},
  visiSize: [],
  visiColor: [],
  visiType: [],
  monarchSize: [],
  monarchColor: [],
  monarchType: [],
  titanSize: [],
  titanColor: [],
  titanType: [],
  clinicsByPatient: {},
  caregivers: {},
  providersByPatient: {},
  diagnosis: [],
  hcpByPatientClinics: {},
  relationships: [],
  statesByCountry: [],
  cityByStateCountry: [],
  allMonthsAdherenceData: {},
  allMonthsTherapyData: {},
  allOverviewData: {},
  patientSessions: {},
  allProtocols: {},
  patientStats: {},
  isBlackAndWhite: {},
  isAllowed: false,
  patientId: '',
  flag: '',
  progressTime: constants.MIN_PROGRESS_START_TIME,
  multiProgressTime: constants.MULTI_MIN_PROGRESS_START_TIME,
  patientList: false,
  patientSelf: false,
  spiroDataLogStatus: undefined,
  isTherapyOption: undefined,
  selectedSpiroYear: moment(),
  spiroRawData: {},
  therapyRawData: {},
  isSpiroPdf: false
};

function patient(state = initialState, action) {
  const tmpState = Object.assign({}, state);
  if (action.type === constants.PATIENT.STORE_PATIENT_DATA) {
    tmpState.pData = setStateByKey(tmpState.pData, action.key, action.data);
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_USER_DATA) {
    tmpState.pUserData = setStateByKey(
      tmpState.pUserData,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_CLINIC_DATA) {
    tmpState.pClinics = setStateByKey(
      tmpState.pClinics,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.TOGGLE_THERAPY_OPTION) {
    tmpState.isTherapyOption = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_PROVIDER_DATA) {
    tmpState.pProviders = setStateByKey(
      tmpState.pProviders,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_PROTOCOL_DATA) {
    tmpState.pProtocols = setStateByKey(
      tmpState.pProtocols,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_YEAR_ADHERENCE_DATA) {
    tmpState.pyAdherence = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_MONTH_ADHERENCE_DATA) {
    tmpState.pmAdherence = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_YEAR_THERAPY_DATA) {
    tmpState.pyTherapy = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_MONTH_THERAPY_DATA) {
    tmpState.pmTherapy = setStateByKey(
      tmpState.pmTherapy,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (
    action.type === constants.PATIENT.STORE_ENHANCED_PATIENT_MONTH_THERAPY_DATA
  ) {
    const { therapy, month } = action.data;
    tmpState.pmEnhancedTherapy = setStateByKey(
      tmpState.pmEnhancedTherapy,
      action.key,
      therapy
    );
    tmpState.pmEnhancedTherapyMonth = setStateByKey(
      tmpState.pmEnhancedTherapyMonth,
      action.key,
      month
    );
    return tmpState;
  }
  if (
    action.type === constants.PATIENT.STORE_ENHANCED_PATIENTS_RANGE_THERAPY_DATA
  ) {
    tmpState.patientsRangeEnhancedTherapy = action.data;
    tmpState.spiroRawData = action.spiroRawData;
    tmpState.therapyRawData = action.therapyRawData;
    tmpState.isSpiroPdf = action.isSpiroPdf;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_ENHANCED_PATIENTS_OVERVIEW) {
    tmpState.patientsEnhancedOverview = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA_SUCCESS) {
    tmpState.selectedSpiroYear = action.response.selectedYear;
    tmpState.patientsSpiroData = action.response.data;
    tmpState.patientYearTherapyData = action.response.therapy;
    return tmpState;
  }
  if (action.type === constants.PATIENT.RESET_SPIRO_DATA_LOG_STATUS) {
    tmpState.spiroDataLogStatus = undefined;
    return tmpState;
  }
  if (action.type === constants.PATIENT.RESET_PATIENT_DATA) {
    return Object.assign({}, state, {
      pData: {},
      pUserData: {},
      pClinics: {},
      pProviders: {},
      pyAdherence: {},
      pmAdherence: {},
      pyTherapy: {},
      pmTherapy: {},
      pmEnhancedTherapy: {},
      pmEnhancedTherapyMonth: {},
      pProtocols: {},
      patientStats: {}
    });
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_SESSION_DATA) {
    tmpState.patientSessions = setStateByKey(
      tmpState.patientSessions,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_SEARCH_SUCCESS) {
    if (action.response.result === null) {
      tmpState.patients = [];
      tmpState.totalUsers = null;
      tmpState.patientList = true;
    } else {
      tmpState.patients = action.response.result;
      tmpState.totalUsers = action.response.totalCnt;
      tmpState.patientList = true;
    }
    return tmpState;
  }
  if (action.type === constants.PATIENT.ALL_PROTOCOL_DATA_SUCCESS) {
    tmpState.allProtocols = setStateByKey(
      tmpState.allProtocols,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.SPIRO_LOG_DATA_SUCCESS) {
    tmpState.spiroDataLogStatus = strings.spiroLogSuccessMsg;
    return tmpState;
  }
  if (action.type === constants.PATIENT.SPIRO_LOG_DATA_FAILURE) {
    tmpState.spiroDataLogStatus = undefined
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_SEARCH_ROLE_SUCCESS) {
    if (action.response.results === null) {
      tmpState.patients = [];
      tmpState.totalUsers = null;
      tmpState.patientList = true;
    } else {
      tmpState.patients = pinnedSort(action.response.results);
      tmpState.totalUsers = action.response.totalCnt;
      tmpState.patientList = true;
    }
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_SEARCH_FAILURE) {
    tmpState.patients = [];
    tmpState.totalUsers = 0;
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_INFO_SUCCESS) {
    tmpState.patientInfo = setStateByKey(
      tmpState.patientInfo,
      action.key,
      action.response.data
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_INFO_CLEAR) {
    tmpState.patientInfo = setStateByKey(tmpState.patientInfo, action.key, {});
    return tmpState;
  }
  if (action.type === constants.PATIENT.PATIENT_INFO_FAILURE) {
    tmpState.patientInfo = setStateByKey(
      tmpState.patientInfo,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.GARMENT_PARAMETERS_SUCCESS) {
    tmpState.visiSize = action.visiSize;
    tmpState.visiColor = action.visiColor;
    tmpState.visiType = action.visiType;
    tmpState.monarchSize = action.monarchSize;
    tmpState.monarchColor = action.monarchColor;
    tmpState.monarchType = action.monarchType;
    tmpState.titanSize = action.titanSize;
    tmpState.titanColor = action.titanColor;
    tmpState.titanType = action.titanType;
    return tmpState;
  }
  if (action.type === constants.PATIENT.CLINICSBYPATIENT_SUCCESS) {
    tmpState.clinicsByPatient = setStateByKey(
      tmpState.clinicsByPatient,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.CLINICSBYPATIENT_FAILURE) {
    tmpState.clinicsByPatient = setStateByKey(
      tmpState.clinicsByPatient,
      action.key,
      []
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.CAREGIVERBYPATIENT_SUCCESS) {
    tmpState.caregivers = setStateByKey(
      tmpState.caregivers,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.CAREGIVERBYPATIENT_FAILURE) {
    tmpState.caregivers = setStateByKey(tmpState.caregivers, action.key, []);
    return tmpState;
  }
  if (action.type === constants.PATIENT.DIAGNOSIS_SEARCH_SUCCESS) {
    tmpState.diagnosis = action.response.typeCode;
    return tmpState;
  }
  if (action.type === constants.PATIENT.DIAGNOSIS_SEARCH_FAILURE) {
    tmpState.diagnosis = [];
    return tmpState;
  }
  if (action.type === constants.PATIENT.PROVIDERSBYPATIENT_SUCCESS) {
    tmpState.providersByPatient = setStateByKey(
      tmpState.providersByPatient,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.PROVIDERSBYPATIENT_FAILURE) {
    tmpState.providersByPatient = setStateByKey(
      tmpState.providersByPatient,
      action.key,
      []
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.ASSOCIATECLINIC_SUCCESS) {
    tmpState.clinicsByPatient = setStateByKey(
      tmpState.clinicsByPatient,
      action.key,
      action.response.clinics
    );
    return tmpState;
  }

  if (action.type === constants.PATIENT.HCPBYPATIENTCLINICS_SUCCESS) {
    tmpState.hcpByPatientClinics = setStateByKey(
      tmpState.hcpByPatientClinics,
      action.key,
      action.response
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.HCPBYPATIENTCLINICS_FAILURE) {
    tmpState.hcpByPatientClinics = setStateByKey(
      tmpState.hcpByPatientClinics,
      action.key,
      []
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.ASSOCIATEHCP_SUCCESS) {
    tmpState.providersByPatient = setStateByKey(
      tmpState.providersByPatient,
      action.key,
      action.response.hcpUsers
    );
    return tmpState;
  }
  if (action.type === constants.PATIENT.RELATIONSHIPS_SUCCESS) {
    tmpState.relationships = action.response;
    return tmpState;
  }
  if (action.type === constants.PATIENT.RELATIONSHIPS_FAILURE) {
    tmpState.relationships = [];
    return tmpState;
  }
  if (action.type === constants.PATIENT.ADDCAREGIVER_SUCCESS) {
    return tmpState;
  }
  if (action.type === constants.PATIENT.SUCCESS_PATIENTS_ROLE_COUNT) {
    const cardKeyMap = {
      total_patients: 'temp-1',
      session50: 'temp-2',
      session80: 'temp-3',
      session100: 'temp-4',
      flagged_patients: 'temp-5',
      monarch_patients: 'temp-7',
      vest_patients: 'temp-8',
      multi_device_patients: 'temp-9',
      titan_patients: 'temp-6',
    };
    const clinicFilterList = {};
    each(cardKeyMap, (val, key) => {
      clinicFilterList[val] = action.response[key].clinicInfo;
    });
    const providerFilterList = {};
    each(cardKeyMap, (val, key) => {
      providerFilterList[val] = action.response[key].providerInfo;
    });
    tmpState.clinicFilterList = clinicFilterList;
    tmpState.providerFilterList = providerFilterList;
    tmpState.totalPatients = action.response.total_patients.count;
    tmpState.titanPatients = action.response.titan_patients.count;
    tmpState.monarchPatients = action.response.monarch_patients.count;
    tmpState.visiVestPatients = action.response.vest_patients.count;
    tmpState.multiDevicePatients = action.response.multi_device_patients.count;
    tmpState.flaggedPatients = action.response.flagged_patients.count;
    tmpState.session50Patients = action.response.session50.count;
    tmpState.session80Patients = action.response.session80.count;
    tmpState.session100Patients = action.response.session100.count;
    return tmpState;
  }
  if (action.type === constants.PATIENT.SUCCESS_PATIENTS_COUNT) {
    tmpState.totalPatients = action.response.all;
    tmpState.titanPatients = action.response.titan;
    tmpState.monarchPatients = action.response.monarch;
    tmpState.visiVestPatients = action.response.vest;
    tmpState.multiDevicePatients = action.response.multi;
    tmpState.neverTransPatients = action.response.never;
    tmpState.inactivePatients = action.response.inactive;
    tmpState.stoppedTransPatients = action.response.stop;
    tmpState.newlyAddedPatients = action.response.newPatients;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STATEBYCOUNTRY_SUCCESS) {
    tmpState.statesByCountry = action.response;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STATEBYCOUNTRY_FAILURE) {
    tmpState.statesByCountry = [];
    return tmpState;
  }
  if (action.type === constants.PATIENT.CITYBYSTATECOUNTRY_SUCCESS) {
    tmpState.cityByStateCountry = action.response;
    return tmpState;
  }
  if (action.type === constants.PATIENT.CITYBYSTATECOUNTRY_FAILURE) {
    tmpState.cityByStateCountry = [];
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_STATS_DATA) {
    tmpState.patientStats = setStateByKey(
      tmpState.patientStats,
      action.key,
      action.data
    );
    tmpState.patientSelf = true;
    return tmpState;
  }
  if (
    action.type === constants.PATIENT.STORE_PATIENT_ADHERENCE_DATA_ALL_MONTHS
  ) {
    tmpState.allMonthsAdherenceData = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_THERAPY_DATA_ALL_MONTHS) {
    tmpState.allMonthsTherapyData = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_PATIENT_SESSION_DATA_ALL_MONTHS) {
    tmpState.allMonthsSessionData = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STORE_ALL_PATIENT_DATA) {
    tmpState.allOverviewData = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.PROGRESS_BAR_LOADING) {
    let progressTime = action.data;
    if (progressTime > 100) {
      progressTime = 100;
    }
    tmpState.progressTime = progressTime;
    return tmpState;
  }
  if (action.type === constants.PATIENT.MULTI_PROGRESS_BAR_LOADING) {
    tmpState.multiProgressTime =
      tmpState.multiProgressTime + action.data > 100
        ? 100
        : tmpState.multiProgressTime + action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.PROGRESS_BAR_FAILURE) {
    tmpState.error = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.STATUS_OF_PDF_DOWNLOAD) {
    tmpState.isAllowed = action.data;
    if (tmpState.isAllowed === false) {
      tmpState.progressTime = 100;
    }
    return tmpState;
  }
  if (action.type === constants.PATIENT.GET_TYPE_OF_PDF) {
    tmpState.isBlackAndWhite = action.data;
    return tmpState;
  }
  if (action.type === constants.PATIENT.CLEAR) {
    action.name.forEach(element => {
      tmpState[element] = [];
    });
    return tmpState;
  }
  if (action.type === constants.PATIENT.CLEAR_TABLE) {
    tmpState.patients = null;
    return tmpState;
  }
  if (action.type === constants.PATIENT.RESET_PROPS_VALUES) {
    tmpState.progressTime = constants.MIN_PROGRESS_START_TIME;
    tmpState.multiProgressTime = constants.MULTI_MIN_PROGRESS_START_TIME;
    tmpState.allOverviewData = {};
    tmpState.allMonthsTherapyData = {};
    tmpState.patientsRangeEnhancedTherapy = {};
    tmpState.patientsEnhancedOverview = {};
    tmpState.spiroRawData = {};
    tmpState.therapyRawData = {};
    return tmpState;
  }
  if (action.type === constants.PATIENT.FLAG_PATIENT_SUCCESS) {
    const { patientId, flagged } = action.data;
    tmpState.patients = tmpState.patients.map(elem => {
      const tempPatient = { ...elem };
      if (tempPatient.patientInfo.patientId === patientId) {
        tempPatient.patientInfo.flagged = flagged;
      }
      return tempPatient;
    });
    return tmpState;
  }
  if (action.type === constants.PATIENT.FLAG_PATIENT_OVERVIEW_SUCCESS) {
    const { flagged, id } = action.data;
    tmpState.pData = {
      ...tmpState.pData,
      [id]: { ...tmpState.pData[id], flagged }
    };
    return tmpState;
  }
  return state;
}
export default patient;

