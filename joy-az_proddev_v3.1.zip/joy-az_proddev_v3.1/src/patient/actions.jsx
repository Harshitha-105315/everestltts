import { put, call, all, cancelled } from 'redux-saga/effects';
import _ from 'lodash';
import constants from 'constants.js';
import { getPatientDevices, filterOutFalsyValues, getTimeZoneOffset, getEndDate, getLatestMonth } from 'utils/helper';
import { groupTherapyDataByMonth } from './helper';
import strings from 'localization/strings';
import PatientService from './services';
import moment from 'moment-timezone';

function* fetchPatientData(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let patientData = yield call(PatientService.getPatientData, patientID);

    if (
      patientData &&
      (patientData.status === 200 || patientData.status === 201)
    ) {
      yield put({
        type: constants.PATIENT.STORE_PATIENT_DATA,
        data: patientData.data,
        key: patientID
      });
    } else {
      const response = patientData;
      patientData = {};
      yield put({
        type: constants.PATIENT.STORE_PATIENT_DATA,
        data: patientData.data,
        key: patientID
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientSessionData(action) {
  yield put({ type: constants.SHOW_LOADER, payload: true });
  let { id, start, end, timeZone } = action.data;
  start = start.format('YYYY-MM-DD');
  end = end.format('YYYY-MM-DD');
  timeZone = getTimeZoneOffset(action.data.timeZone);
  try {
    const patientSessionData = yield call(
      PatientService.getPatientSessionDetail,
      { ...action.data, start, end, timeZone }
    );
    if (patientSessionData.status && patientSessionData.status !== 200) {
      throw Object();
    }
    yield put({
      type: constants.PATIENT.STORE_PATIENT_SESSION_DATA,
      data: patientSessionData,
      key: id
    });
  } catch (error) {
    yield put({
      type: constants.PATIENT.STORE_PATIENT_SESSION_DATA,
      data: error,
      key: id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* resetOverviewData() {
  yield put({
    type: constants.PATIENT.RESET_PATIENT_DATA
  });
}

function* fetchUserData(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let userData = yield call(PatientService.getUserDataById, patientID);

    if (userData && (userData.status === 200 || userData.status === 201)) {
      yield put({
        type: constants.PATIENT.STORE_USER_DATA,
        data: userData.data.user,
        key: patientID
      });
    } else {
      const response = userData;
      userData = {};
      yield put({
        type: constants.PATIENT.STORE_USER_DATA,
        data: userData,
        key: patientID
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientClinicData(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let clinicData = yield call(PatientService.getPatientClinicData, patientID);

    if (
      clinicData &&
      (clinicData.status === 200 || clinicData.status === 201)
    ) {
      yield put({
        type: constants.PATIENT.STORE_PATIENT_CLINIC_DATA,
        data: clinicData.data.clinics,
        key: patientID
      });
    } else {
      const response = clinicData;
      clinicData = [];
      yield put({
        type: constants.PATIENT.STORE_PATIENT_CLINIC_DATA,
        data: clinicData,
        key: patientID
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientProviderData(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let providerData = yield call(
      PatientService.getPatientProviderData,
      patientID
    );

    if (
      providerData &&
      (providerData.status === 200 || providerData.status === 201)
    ) {
      yield put({
        type: constants.PATIENT.STORE_PATIENT_PROVIDER_DATA,
        data: providerData.data.hcpUsers,
        key: patientID
      });
    } else {
      const response = providerData;
      providerData = [];
      yield put({
        type: constants.PATIENT.STORE_PATIENT_PROVIDER_DATA,
        data: providerData,
        key: patientID
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientStatsData(action) {
  const { id } = action.data;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let { start, end, timeZone } = action.data;
    if (start && end) {
      start = start.format('YYYY-MM-DD');
      end = end.format('YYYY-MM-DD');
      timeZone = getTimeZoneOffset(timeZone);
    }

    const patientStatsData = yield call(PatientService.getPatientStatsData, {
      id,
      start,
      end,
      timeZone
    });
    if (
      patientStatsData &&
      (patientStatsData.status === 200 || patientStatsData.status === 201)
    ) {
      yield put({
        type: constants.PATIENT.STORE_PATIENT_STATS_DATA,
        data: patientStatsData.data,
        key: id
      });
    } else {
      throw Object({
        custom_message:
          patientStatsData.data.ERROR || patientStatsData.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.STORE_PATIENT_STATS_DATA,
      data: response,
      key: id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientAdherenceData(action) {
  const { id, range } = action.data;
  const deviceType = localStorage.getItem(`deviceType_${id}`);
  let { start, end } = action.data;
  if (start && end) {
    start = start.format('YYYY-MM-DD');
    end = end.format('YYYY-MM-DD');
  }
  if (range === constants.MONTH) {
    const { mStart, mEnd } = action.data;
    start = mStart;
    end = mEnd;
  }
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const adherence = yield call(
      PatientService.getPatientAdherenceData,
      id,
      deviceType,
      start,
      end,
      range
    );
    let actionType = constants.PATIENT.STORE_PATIENT_YEAR_ADHERENCE_DATA;
    if (range === constants.MONTH) {
      actionType = constants.PATIENT.STORE_PATIENT_MONTH_ADHERENCE_DATA;
    }
    yield put({
      type: actionType,
      data: adherence
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
function* fetchPatientProtocolData(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let protocolData = yield call(
      PatientService.getPatientProtocolData,
      patientID
    );

    if (
      protocolData &&
      (protocolData.status === 200 || protocolData.status === 201)
    ) {
      yield put({
        type: constants.PATIENT.STORE_PATIENT_PROTOCOL_DATA,
        data: protocolData.data.protocol,
        key: patientID
      });
    } else {
      const response = protocolData;
      protocolData = [];
      yield put({
        type: constants.PATIENT.STORE_PATIENT_PROTOCOL_DATA,
        data: protocolData,
        key: patientID
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchEnhancedPatientsTherapyData(action) {
  try {
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_LOADING,
      data: 40
    });
    let { patientIds, start, end, timeZone, extendedInfo = false, isSpiroPdf } = action.data;
    var spiroRawData = {};
    var therapyRawData = [];
    if (isSpiroPdf) {
      var therapyResponse = {};
      var spiroResponse = {};
      timeZone = getTimeZoneOffset(timeZone);
      for (var i = 2; i >= 0; i--) {
        const year = moment(moment().subtract(i, 'years')).format('YYYY-MM-DD');
        const yearStart = moment(year).startOf('year').format('YYYY-MM-DD');
        const yearEnd = moment(year).endOf('year').format('YYYY-MM-DD');
        var startDate = moment(yearStart).startOf('week').format('YYYY-MM-DD');
        var endDate = moment(yearEnd).isAfter(moment()) ? moment().format('YYYY-MM-DD') :
          moment(yearEnd).endOf('week').format('YYYY-MM-DD');
        var res = yield call(
          PatientService.getEnhancedPatientTherapyData, action.data.id, startDate, endDate, timeZone, false
        );
        if (res.status === 200 || res.status === 201) {
          therapyResponse[year] = res.data.message === undefined ? res.data.therapyData : [];
        }
        var response = yield call(
          PatientService.fetchPatientsSpiroDataService,
          action.data.id, startDate, endDate, action.data.timeZone
        );
        if (response.status === 200 || response.status === 201) {
          spiroResponse[year] = response.data.message === undefined ? response.data : [];
        }
      }
      spiroRawData = spiroResponse
      therapyRawData = therapyResponse
    }
    if (start && end) {
      start = start.format('YYYY-MM-DD');
      end = end.format('YYYY-MM-DD');
      timeZone = getTimeZoneOffset(timeZone);
    }
    const responses = yield all(
      patientIds.map(id => call(PatientService.getEnhancedPatientTherapyData, id, start, end, timeZone, extendedInfo))
    );
    const therapies = responses.map(response => {
      if (response.status === 200 || response.status === 201) {
        return groupTherapyDataByMonth(start, end, response.data);
      } else {
        throw Object({
          custom_message: response.data.ERROR || response.data.error
        });
      }
    });
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_LOADING,
      data: 100
    });
    const patientTherapyMap = _.zipObject(patientIds, therapies);
    yield put({
      type: constants.PATIENT.STORE_ENHANCED_PATIENTS_RANGE_THERAPY_DATA,
      data: patientTherapyMap,
      spiroRawData: spiroRawData,
      therapyRawData: therapyRawData,
      isSpiroPdf: isSpiroPdf
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  }
}

function* fetchEnhancedPatientTherapyData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let { id, start, end, timeZone, extendedInfo = true } = action.data;
    if (start && end) {
      start = start.format('YYYY-MM-DD');
      end = end.format('YYYY-MM-DD');
      timeZone = getTimeZoneOffset(timeZone);
    }
    const response = yield call(PatientService.getEnhancedPatientTherapyData, id, start, end, timeZone, extendedInfo);
    if (response.status === 200) {
      yield put({
        type: constants.PATIENT.STORE_ENHANCED_PATIENT_MONTH_THERAPY_DATA,
        data: { therapy: response.data, month: start },
        key: id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {

    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientTherapyData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, range } = action.data;
    let { start, end } = action.data;
    if (start && end) {
      start = start.format('YYYY-MM-DD');
      end = end.format('YYYY-MM-DD');
    }
    if (range === constants.MONTH) {
      const { mStart, mEnd } = action.data;
      start = mStart;
      end = mEnd;
    }
    const deviceTypes = getPatientDevices(id);

    const therapyData = {};

    const allTherapyData = yield all(
      deviceTypes.map(dType =>
        call(PatientService.getPatientTherapyData, id, dType, start, end, range)
      )
    );

    let isError = false;
    _.forEach(allTherapyData, (val, idx) => {
      if (val.status === 200 || val.status === 201) {
        therapyData[deviceTypes[idx]] = val.data;
      } else {
        isError = true;
      }
    });

    let actionType = constants.PATIENT.STORE_PATIENT_YEAR_THERAPY_DATA;
    if (range === constants.MONTH) {
      actionType = constants.PATIENT.STORE_PATIENT_MONTH_THERAPY_DATA;
    }
    yield put({
      type: actionType,
      data: therapyData,
      key: id
    });
    if (isError) {
      throw Object({
        custom_message: undefined
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
function* fetchAllOverviewData(action) {
  try {
    let { start, end, timeZone } = action.data;
    const { patientIds, months } = action.data;
    const MRANGE = constants.MONTH;
    const allPatientData = {};
    if (start && end) {
      start = start.format('YYYY-MM-DD');
      end = end.format('YYYY-MM-DD');
      timeZone = getTimeZoneOffset(timeZone);
    }
    for (let i = 0; i < patientIds.length; i++) {
      const patientID = patientIds[i];
      // patient data
      let patientData = yield call(PatientService.getPatientData, patientID);
      if (patientData.status && patientData.status !== 200) {
        patientData = {};
      } else if (!localStorage.getItem(`deviceType_${patientData.data.id}`)) {
        localStorage.setItem(
          `deviceType_${patientData.data.id}`,
          patientData.data.deviceType
        );
      }

      // user data
      let userData = yield call(PatientService.getUserDataById, patientID);
      if (userData.status && userData.status !== 200) {
        userData = {};
      } else {
        userData = userData.data.user;
      }
      // fetch patient clinic data
      let clinicData = yield call(
        PatientService.getPatientClinicData,
        patientID
      );
      if (clinicData.status && clinicData.status !== 200) {
        clinicData = [];
      } else {
        clinicData = clinicData.data.clinics;
      }
      // fetch Provider data
      let providerData = yield call(
        PatientService.getPatientProviderData,
        patientID
      );
      if (providerData.status && providerData.status !== 200) {
        providerData = [];
      } else {
        providerData = providerData.data.hcpUsers;
      }

      const patientStats = yield call(PatientService.getPatientStatsData, {
        id: patientID,
        start,
        end,
        timeZone
      });
      // fetch patient protocal data
      let protocolData = yield call(
        PatientService.getPatientProtocolData,
        patientID
      );
      // TODO: Rewrite this as utility fn.
      if (protocolData.status && protocolData.status !== 200) {
        protocolData = [];
      } else {
        protocolData = protocolData.data.protocol;
      }

      // fetch patient theramy data of Year
      const deviceTypes = getPatientDevices(patientID);
      const therapyData = {};
      const allTherapyData = yield all(
        deviceTypes.map(dType =>
          call(
            PatientService.getPatientTherapyData,
            patientID,
            dType,
            start,
            end,
            MRANGE
          )
        )
      );
      _.forEach(allTherapyData, (val, idx) => {
        therapyData[deviceTypes[idx]] = val.data;
      });

      const patientDictData = {
        patientData: patientData.data,
        patientStats: patientStats.data,
        userData,
        clinicData,
        providerData,
        protocolData,
        therapyData
      };
      allPatientData[patientID] = patientDictData;
    }
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_THERAPY_DATA_ALL_MONTHS,
      data: { patientIds, months }
    });
    yield put({
      type: constants.PATIENT.STORE_ALL_PATIENT_DATA,
      data: allPatientData
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  }
}

function* fetchEnhancedPatientsOverviewData(action) {
  try {
    let { patientIds, start, end, timeZone, extendedInfo = false } = action.data;
    let startDate, endDate;
    if (start && end) {
      startDate = start.format('YYYY-MM-DD');
      endDate = end.format('YYYY-MM-DD');
      timeZone = getTimeZoneOffset(timeZone);
    }

    const time = Math.floor(100 / patientIds.length);

    const patientOverviewMap = {};
    for (let i = 0; i < patientIds.length; i++) {
      const patientId = patientIds[i];
      const { id, firstTrans } = patientId;
      startDate = getLatestMonth(start, moment.utc(firstTrans));
      startDate = startDate.format('YYYY-MM-DD');
      const [patient, stats, clinics, providers, protocals, therapy] = yield all([
        call(PatientService.getPatientData, id),
        call(PatientService.getPatientStatsData, { id, start: startDate, end: endDate, timeZone }),
        call(PatientService.getPatientClinicData, id),
        call(PatientService.getPatientProviderData, id),
        call(PatientService.getPatientProtocolData, id),
        call(PatientService.getEnhancedPatientTherapyData, id, startDate, endDate, timeZone, extendedInfo)
      ]);

      patientOverviewMap[id] = {
        patient: patient.data,
        stats: stats.data,
        clinics: clinics.data.clinics,
        providers: providers.data.hcpUsers,
        protocols: protocals.data.protocol,
        therapy: groupTherapyDataByMonth(startDate, endDate, therapy.data)
      };
      yield put({
        type: constants.PATIENT.MULTI_PROGRESS_BAR_LOADING,
        data: time
      });
    }
    yield put({
      type: constants.PATIENT.STORE_ENHANCED_PATIENTS_OVERVIEW,
      data: patientOverviewMap
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  }
}

function* fetchOverviewData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let { id, start, end, mStart, mEnd, timeZone } = action.data;
    yield put({
      type: constants.PATIENT.FETCH_USER_DATA,
      data: { id }
    });
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_CLINIC_DATA,
      data: { id }
    });
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_PROVIDER_DATA,
      data: { id }
    });
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_STATS_DATA,
      data: { id, start, end, timeZone }
    });
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_ALL_PROTOCOL_DATA,
      data: { id }
    });
    yield put({
      type: constants.PATIENT.FETCH_PATIENT_PROTOCOL_DATA,
      data: { id }
    });
    yield put({
      type: constants.PATIENT.FETCH_ENHANCED_PATIENT_THERAPY_DATA,
      data: { id, start: mStart, end: mEnd, timeZone }
    });
  } finally {
    if (yield cancelled()) {
      yield put({
        type: constants.PATIENT.RESET_PATIENT_OVERVIEW
      });
    }
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* storePatientSpiroLogData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.storeSpiroLogDataService,
      action.data
    );
    if (response.status === 200 || response.status === 201) {
      yield put({
        type: constants.PATIENT.SPIRO_LOG_DATA_SUCCESS,
        response: response.data
      });
    } else {
      yield put({
        type: constants.PATIENT.SPIRO_LOG_DATA_FAILURE,
        response: []
      });
    }
  } catch (response) {
    yield put({ type: constants.PATIENT.SPIRO_LOG_DATA_FAILURE, response: [] });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchEnhancedPatientsSpiroData(action) {
  var startDate = moment(action.data.start).startOf('week').format('YYYY-MM-DD');
  var endDate = moment(action.data.end).isAfter(moment()) ? moment().format('YYYY-MM-DD') :
    moment(action.data.end).endOf('week').format('YYYY-MM-DD');
  const timeZone = getTimeZoneOffset(action.data.timeZone);
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchPatientsSpiroDataService,
      action.data.id, startDate, endDate, action.data.timeZone
    );
    const therapyResponse = yield call(
      PatientService.getEnhancedPatientTherapyData, action.data.id, startDate, endDate, timeZone, false
    );
    if (response.status === 200 && therapyResponse.status === 200) {
      response.selectedYear = action.data.start
      response.data = response.data.message === undefined ? response.data : []
      response.therapy = therapyResponse.data.message === undefined ? therapyResponse.data.therapyData : []
      yield put({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA_SUCCESS,
        response: response
      });
    } else {
      yield put({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA_FAILURE,
        response: []
      });
    }
  } catch (response) {
    yield put({ type: constants.PATIENT.FETCH_ENHANCED_PATIENT_SPIRO_DATA_FAILURE, response: [] });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchRoleBasedPatients(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchPatientsService,
      filterOutFalsyValues(action.payload, true),
      action.roleBaseKey
    );
    if (response.status === 200) {
      yield put({
        type: constants.PATIENT.PATIENT_SEARCH_ROLE_SUCCESS,
        response: response.data
      });
    } else {
      yield put({
        type: constants.PATIENT.PATIENT_SEARCH_FAILURE,
        response: []
      });
    }
  } catch (response) {
    yield put({ type: constants.PATIENT.PATIENT_SEARCH_FAILURE, response: [] });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatients(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchPatientsService,
      filterOutFalsyValues(action.payload, true)
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.PATIENT_SEARCH_SUCCESS,
        response: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.PATIENT.PATIENT_SEARCH_FAILURE, response: [] });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getPatientRoleCounts(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getPatientCountsService,
      action.entity,
      action.data
    );
    if (response.status === 200) {
      yield put({
        type: constants.PATIENT.SUCCESS_PATIENTS_ROLE_COUNT,
        response: response.data
      });
    } else {
      yield put({ type: constants.PATIENT.FAILURE_PATIENTS_ROLE_COUNT });
    }
  } catch (response) {
    yield put({ type: constants.PATIENT.FAILURE_PATIENTS_ROLE_COUNT });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getPatientCounts(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getPatientCountsService,
      action.entity,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.SUCCESS_PATIENTS_COUNT,
        response: response.data
      });
    } else {
      yield put({ type: constants.PATIENT.FAILURE_PATIENTS_COUNT });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.PATIENT.FAILURE_PATIENTS_COUNT });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getPatientInfo(action) {
  const { id } = action.payload;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getPatientInfoService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.PATIENT_INFO_SUCCESS,
        response,
        key: id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.PATIENT_INFO_FAILURE,
      response,
      key: id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getGarmentParameters() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const {
      visiSize,
      visiColor,
      visiType,
      monarchColor,
      monarchType,
      titanSize,
      titanColor,
      titanType
    } = yield all({
      visiSize: call(PatientService.getVisiSizeService),
      visiColor: call(PatientService.getVisiColorService),
      visiType: call(PatientService.getVisiTypeService),
      monarchColor: call(PatientService.getMonarchColorService),
      monarchType: call(PatientService.getMonarchTypeService),
      titanSize: call(PatientService.getTitanSizeService),
      titanColor: call(PatientService.getTitanColorService),
      titanType: call(PatientService.getTitanTypeService),
    });
    yield put({
      type: constants.PATIENT.GARMENT_PARAMETERS_SUCCESS,
      visiSize: visiSize.typeCode,
      visiColor: visiColor.typeCode,
      visiType: visiType.typeCode,
      monarchColor: monarchColor.typeCode,
      monarchType: monarchType.typeCode,
      titanSize: titanSize.typeCode,
      titanColor: titanColor.typeCode,
      titanType: titanType.typeCode
    });
  } catch (response) {
    yield put({ type: constants.PATIENT.GARMENT_PARAMETERS_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getClinicsByPatient(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getClinicsByPatientService,
      action.id
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.CLINICSBYPATIENT_SUCCESS,
        response: response.data.clinics,
        key: action.id
      });
    } else {
      yield put({
        type: constants.PATIENT.CLINICSBYPATIENT_FAILURE,
        response: [],
        key: action.id
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.CLINICSBYPATIENT_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getCaregiverByPatient(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getCaregiverByPatientService,
      action.id
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.CAREGIVERBYPATIENT_SUCCESS,
        response: response.data.caregivers,
        key: action.id
      });
    } else {
      yield put({
        type: constants.PATIENT.CAREGIVERBYPATIENT_SUCCESS,
        response: [],
        key: action.id
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.CAREGIVERBYPATIENT_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientAllProtocolData(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchPatientAllProtocolDataService,
      action.data.id
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.ALL_PROTOCOL_DATA_SUCCESS,
        response: response.data,
        key: action.data.id
      });
    } else {
      yield put({
        type: constants.PATIENT.ALL_PROTOCOL_DATA_FAILURE,
        key: action.id
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.ALL_PROTOCOL_DATA_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getProvidersByPatient(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getProvidersByPatientService,
      action.id
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.PROVIDERSBYPATIENT_SUCCESS,
        response: response.data.hcpUsers,
        key: action.id
      });
    } else {
      yield put({
        type: constants.PATIENT.PROVIDERSBYPATIENT_FAILURE,
        key: action.id
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.PATIENT.PROVIDERSBYPATIENT_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getDiagnosisSearchResult(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getDiagnosisSearchResultService,
      action.searchUrl
    );
    yield put({ type: constants.PATIENT.DIAGNOSIS_SEARCH_SUCCESS, response });
  } catch (response) {
    yield put({ type: constants.PATIENT.DIAGNOSIS_SEARCH_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updatePatientDetails(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.updatePatientDetailsService,
      action.id,
      action.payload
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.user
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* associateClinic(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.associateClinicService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.PATIENT.CLINICSBYPATIENT_REQUEST,
        id: action.id
      });
      yield put({
        type: constants.PATIENT.ASSOCIATECLINIC_SUCCESS,
        response: response.data,
        key: action.id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* disassociateClinic(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, payload } = action;
    const response = yield call(
      PatientService.disassociateClinicService,
      payload,
      id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.PATIENT.CLINICSBYPATIENT_REQUEST,
        id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getHcpByPatientClinics(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.getHcpByPatientClinicsService,
      action.searchUrl,
      action.id
    );
    yield put({
      type: constants.PATIENT.HCPBYPATIENTCLINICS_SUCCESS,
      response: response.HCPUser,
      key: action.id
    });
  } catch (response) {
    yield put({
      type: constants.PATIENT.HCPBYPATIENTCLINICS_FAILURE,
      key: action.id
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* disassociateHcp(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload, id } = action;
    const response = yield call(
      PatientService.disassociateHcpService,
      payload,
      id
    );

    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.PATIENT.PROVIDERSBYPATIENT_REQUEST,
        id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* associateHcp(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.associateHcpService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.PATIENT.ASSOCIATEHCP_SUCCESS,
        response: response.data,
        key: action.id
      });
      yield put({
        type: constants.PATIENT.PROVIDERSBYPATIENT_REQUEST,
        id: action.id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchRelationships() {
  try {
    const response = yield call(PatientService.fetchRelationshipsService);
    yield put({
      type: constants.PATIENT.RELATIONSHIPS_SUCCESS,
      response: response.relationshipLabels
    });
  } catch (response) {
    yield put({ type: constants.PATIENT.RELATIONSHIPS_FAILURE, response });
  }
}

function* addCaregiver(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.addCaregiverService,
      action.id,
      action.payload
    );
    if (response.status === 201) {
      yield put({
        type: constants.ZIP.CCITYSTATEBYZIP_FAILURE
      });
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.PATIENT.ADDCAREGIVER_SUCCESS,
        response: response.data.caregiver
      });
      yield put({
        type: constants.PATIENT.CAREGIVERBYPATIENT_REQUEST,
        id: action.id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* disassociateCaregiver(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, deleteId } = action;
    const response = yield call(
      PatientService.disassociateCaregiverService,
      id,
      deleteId
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.PATIENT.CAREGIVERBYPATIENT_REQUEST,
        id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchStatesByCountry(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchStatesByCountryService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.STATEBYCOUNTRY_SUCCESS,
        response: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.PATIENT.STATEBYCOUNTRY_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchCityByStateCountry(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      PatientService.fetchCityByStateCountryService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.CITYBYSTATECOUNTRY_SUCCESS,
        response: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.PATIENT.CITYBYSTATECOUNTRY_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchPatientAdherenceDataAllMonths(action) {
  try {
    const { patientIds, months } = action.data;
    const allPatientAdherenceData = {};
    let assginedValue = 0;
    const loadingValue = 98 / (patientIds.length * months.length);
    for (let j = 0; j < patientIds.length; j++) {
      const id = patientIds[j];
      const deviceType = localStorage.getItem(`deviceType_${id}`);
      const adherenceDataOfMonths = {};
      for (let i = 0; i < months.length; i++) {
        const month = months[i];
        const start = month.startOf('month').format('YYYY-MM-DD');
        const end = getEndDate(month).format('YYYY-MM-DD');
        const adherence = yield call(
          PatientService.getPatientAdherenceData,
          id,
          deviceType,
          start,
          end
        );
        adherenceDataOfMonths[month] = adherence;
        assginedValue += loadingValue;
        yield put({
          type: constants.PATIENT.PROGRESS_BAR_LOADING,
          data: assginedValue
        });
      }
      allPatientAdherenceData[id] = adherenceDataOfMonths;
    }
    yield put({
      type: constants.PATIENT.STORE_PATIENT_ADHERENCE_DATA_ALL_MONTHS,
      data: allPatientAdherenceData
    });
    yield put({
      type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD,
      data: true
    });
  } catch (response) {
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_FAILURE,
      data: 'error'
    });
  }
}

function* fetchPatientTherapyDataAllMonths(action) {
  try {
    const { patientIds } = action.data;
    const allPatientTheraphyData = {};
    for (let j = 0; j < patientIds.length; j++) {
      const id = patientIds[j];
      allPatientTheraphyData[id] = {};
    }
    yield put({
      type: constants.PATIENT.STORE_PATIENT_THERAPY_DATA_ALL_MONTHS,
      data: allPatientTheraphyData
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  }
}
function* fetchPatientSessionDataAllMonths(action) {
  const { months } = action.data;
  const loadingValue = 98 / months.length;
  let assginedValue = 0;
  const AllMonthsSessionData = [];
  for (let i = 0; i < months.length; i++) {
    const month = months[i];
    const start = month.startOf('month').format('YYYY-MM-DD');
    const end = getEndDate(month).format('YYYY-MM-DD');
    const data = {
      id: action.data.id,
      start: start,
      end: end,
      order: 'desc',
      pageNo: 1,
      pageSz: 1000
    };
    const allSessionData = yield call(
      PatientService.getPatientSessionDetail,
      data
    );
    AllMonthsSessionData[i] = allSessionData.content;
    assginedValue += loadingValue;
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_LOADING,
      data: assginedValue
    });
  }
  yield put({
    type: constants.PATIENT.STORE_PATIENT_SESSION_DATA_ALL_MONTHS,
    data: AllMonthsSessionData
  });
  yield put({
    type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD,
    data: true
  });
}
function* setDownloadFalse() {
  yield put({
    type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD,
    data: false
  });
}
function* setTypeOfPDF(action) {
  const { isBlackAndWhite } = action.data;
  yield put({
    type: constants.PATIENT.GET_TYPE_OF_PDF,
    data: isBlackAndWhite
  });
}

function* flagPatientAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(PatientService.flagPatientService, action.data);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.FLAG_PATIENT_SUCCESS,
        data: action.data
      });
      const patientsCount = yield call(
        PatientService.getPatientCountsService,
        action.data.entity,
        action.data.payload
      );
      if (patientsCount.status === 200 || patientsCount.status === 201) {
        yield put({
          type: constants.PATIENT.SUCCESS_PATIENTS_ROLE_COUNT,
          response: patientsCount.data
        });
      } else {
        yield put({ type: constants.PATIENT.FAILURE_PATIENTS_ROLE_COUNT });
      }
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* flagPatientOverviewAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(PatientService.flagPatientService, action.data);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.FLAG_PATIENT_OVERVIEW_SUCCESS,
        data: { ...action.data, id: action.userId }
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: false }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* downloadDetailedReport(action) {
  const { params, data, callbackFn } = action.payload;
  try {
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_LOADING,
      data: 20
    });
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(PatientService.fetchDetailedReportPdf, { data, params });
    yield put({
      type: constants.PATIENT.PROGRESS_BAR_LOADING,
      data: 80
    });
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PATIENT.PROGRESS_BAR_LOADING,
        data: 100
      });
      callbackFn && callbackFn(response.data);
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: false }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const PatientAction = {
  fetchPatientData,
  fetchPatientSessionData,
  fetchUserData,
  fetchPatientClinicData,
  fetchPatientProviderData,
  fetchPatientStatsData,
  fetchPatientAdherenceData,
  fetchPatientAdherenceDataAllMonths,
  fetchPatientProtocolData,
  fetchPatientTherapyData,
  fetchPatientTherapyDataAllMonths,
  fetchOverviewData,
  fetchPatientAllProtocolData,
  resetOverviewData,
  fetchPatients,
  fetchRoleBasedPatients,
  fetchEnhancedPatientsSpiroData,
  storePatientSpiroLogData,
  getPatientCounts,
  getPatientRoleCounts,
  getPatientInfo,
  getGarmentParameters,
  getClinicsByPatient,
  getCaregiverByPatient,
  getDiagnosisSearchResult,
  updatePatientDetails,
  getProvidersByPatient,
  associateClinic,
  disassociateClinic,
  getHcpByPatientClinics,
  disassociateHcp,
  associateHcp,
  fetchRelationships,
  addCaregiver,
  disassociateCaregiver,
  fetchStatesByCountry,
  fetchCityByStateCountry,
  fetchAllOverviewData,
  setDownloadFalse,
  setTypeOfPDF,
  fetchPatientSessionDataAllMonths,
  flagPatientAction,
  flagPatientOverviewAction,
  fetchEnhancedPatientTherapyData,
  fetchEnhancedPatientsTherapyData,
  fetchEnhancedPatientsOverviewData,
  downloadDetailedReport,
};

export default PatientAction;
