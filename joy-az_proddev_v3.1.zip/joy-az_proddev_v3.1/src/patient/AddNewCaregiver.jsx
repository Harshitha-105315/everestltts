import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import NumberFormat from 'react-number-format';
import strings from 'localization/strings';
import { connect } from 'react-redux';
import constants from 'constants.js';
import ButtonComponent from 'components/ButtonComponent';
import { getRelationships } from 'utils/utltity.jsx';
import { isEmpty } from 'lodash';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';

class AddNewCaregiver extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ctitle: '',
      cfirstName: '',
      clastName: '',
      cmiddleName: '',
      ccity: '',
      cstate: '',
      czipcode: '',
      caddress: '',
      cphoneNumber: '',
      cmobileNumber: '',
      crelationship: '',
      cemail: '',
      associateEntity: props.associateEntity,
      isDirty: false,
    };
    this.getRelationships = getRelationships.bind(this);
  }

  componentWillReceiveProps(newProps) {
    const { ccityStateByZip } = newProps;
    if (ccityStateByZip !== undefined && !isEmpty(ccityStateByZip)) {
      this.setState({
        czipcode: ccityStateByZip.zipCode,
        cstate: ccityStateByZip.state,
        ccity: ccityStateByZip.city
      });
    } else {
      this.setState({ cstate: '', ccity: '' });
    }
  }

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value, isDirty: true });
  };

  render() {
    const {
      ctitle,
      cfirstName,
      cmiddleName,
      clastName,
      caddress,
      ccity,
      cstate,
      czipcode,
      cmobileNumber,
      cphoneNumber,
      crelationship,
      cemail
    } = this.state;
    const {
      linkCaregiverPatient,
      associateEntity,
      handleZipChange,
      setAssociateEntityState,
      caregiverError,
      isMobile,
      updateButton,
      history,
      location
    } = this.props;
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        {associateEntity.addCaregiver && (
          <div
            className={
              associateEntity.addCaregiver ? 'add-caregiver-patient' : 'd-none'
            }
            id="add-caregiver-form"
          >
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.title}</Form.Label>
                <Form.Control
                  as="select"
                  name="ctitle"
                  value={ctitle}
                  onChange={this.handleChange}
                >
                  <option value="Mr.">{strings.mr}</option>
                  <option value="Mrs.">{strings.mrs}</option>
                  <option value="Ms.">{strings.ms}</option>
                </Form.Control>
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                <FormControlComponent
                  type="text"
                  value={cfirstName}
                  name="cfirstName"
                  onChange={this.handleChange}
                  maxLength="50"
                />
              </Form.Group>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.middleName}</Form.Label>
                <FormControlComponent
                  type="text"
                  name="cmiddleName"
                  value={cmiddleName || ''}
                  onChange={this.handleChange}
                  maxLength="50"
                />
              </Form.Group>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                <FormControlComponent
                  type="text"
                  value={clastName}
                  name="clastName"
                  onChange={this.handleChange}
                  maxLength="50"
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.relationship} <span className="asterisk-color">*</span></Form.Label>
                <Form.Control
                  as="select"
                  value={crelationship}
                  name="crelationship"
                  onChange={this.handleChange}
                >
                  <option defaultValue value="">
                    {strings.selectRelationship}
                  </option>
                  {this.getRelationships()}
                </Form.Control>
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={8}>
                <Form.Label>{strings.addressLine1}</Form.Label>
                <FormControlComponent
                  type="text"
                  value={caddress || ''}
                  name="caddress"
                  onChange={this.handleChange}
                  maxLength="100"
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.city}</Form.Label>
                <Form.Control
                  type="text"
                  value={ccity || ''}
                  name="ccity"
                  onChange={this.handleChange}
                  readOnly
                />
              </Form.Group>
              <Form.Group as={Col}>
                <Form.Row>
                  <Form.Group as={Col} md={6}>
                    <Form.Label>{strings.state}</Form.Label>
                    <Form.Control
                      type="text"
                      value={cstate}
                      name="cstate"
                      onChange={this.handleChange}
                      readOnly
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={6}>
                    <Form.Label>{strings.zip}</Form.Label>

                    <FormControlComponent
                      type="text"
                      value={czipcode}
                      name="czipcode"
                      onChange={this.handleChange}
                      onMouseLeave={event => {
                        handleZipChange(event);
                      }}
                      maxLength="7"
                    />
                  </Form.Group>
                </Form.Row>
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.phoneNumber} <span className="asterisk-color">*</span></Form.Label>
                <NumberFormat
                  className="form-control"
                  placeholder={strings.numberPlaceholder}
                  format={strings.numberFormat}
                  mask="_"
                  name="cphoneNumber"
                  value={cphoneNumber || ''}
                  onChange={this.handleChange}
                />
              </Form.Group>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.mobileNumber}</Form.Label>
                <NumberFormat
                  className="form-control"
                  placeholder={strings.numberPlaceholder}
                  format={strings.numberFormat}
                  mask="_"
                  name="cmobileNumber"
                  value={cmobileNumber || ''}
                  onChange={this.handleChange}
                />
              </Form.Group>
            </Form.Row>
            <Form.Row>
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                <FormControlComponent
                  type="text"
                  value={cemail}
                  name="cemail"
                  onChange={this.handleChange}
                  maxLength="100"
                />
              </Form.Group>
            </Form.Row>
            <p id="error" className="text-danger">
              {caregiverError}
            </p>
            <div className="d-flex justify-content-end">
              <ButtonComponent
                buttonAction={() => {
                  const { dispatch } = this.props;
                  dispatch({
                    type: constants.ZIP.CCITYSTATEBYZIP_FAILURE
                  });
                  setAssociateEntityState({
                    addCaregiver: false
                  });
                }}
                icon="add-icon"
                buttonText={strings.cancel}
              />
              <ButtonComponent
                buttonAction={() => {
                  linkCaregiverPatient(this.state, this.handleClose);
                }}
                icon="add-icon"
                buttonClass="ml-4"
                buttonText={strings.addCaregiver}
              />
            </div>
          </div>
        )}
        <div className={associateEntity.addCaregiver ? 'd-none' : 'd-flex'}>
          <ButtonComponent
            id="add-caregiver"
            buttonClass={isMobile ? 'ml-0' : 'ml-auto'}
            buttonAction={() => {
              const { dispatch } = this.props;
              dispatch({
                type: constants.PATIENT.RELATIONSHIPS_REQUEST
              });
              setAssociateEntityState({
                addCaregiver: true
              });
            }}
            icon="add-icon"
            buttonText={strings.addCaregiver}
          />
          {isMobile && updateButton}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { patient, userReducer } = state.app;
  return {
    relationships: patient.relationships,
    ccityStateByZip: userReducer.ccityStateByZip
  };
};

export default connect(
  mapStateToProps,
  null
)(AddNewCaregiver);
