import React, { Component } from 'react';
import { Document, Page, Text, View, Image, Font } from '@react-pdf/renderer';
import monarchLogoColor from 'assets/img/monarch.png';
import visiVestLogoColor from 'assets/img/visivest.png';
import monarchBlackAndWhite from 'assets/img/monarchBlackAndWhite.png';
import titanBlackAndWhite from 'assets/img/titanBlackAndWhite.png';
import visiVestLogoBlackAndWhite from 'assets/img/visivestBlackAndWhite.png';
import titanLogoColor from 'assets/img/logo/titanlogo.png';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import manualBlackAndWhiteLogo from 'assets/img/logo/icn_nonconnected@2xBlackAndWhite.png';
import greenArrow from 'assets/img/green-arrow.png';
import redArrow from 'assets/img/red-arrow.png';
import grayArrow from 'assets/img/gray-arrow.png';
import blackArrow from 'assets/img/black-arrow.png';
import isBlackAndWhiteFlag from 'assets/img/flag.png';
import Flagged from 'assets/img/red-flag.png';
import { isEmpty } from 'lodash';
import moment from 'moment-timezone';
import { uid } from 'react-uid';
import strings from 'localization/strings';
import SailecBold from '../assets/fonts/SailecBold.ttf';
import SailecThin from '../assets/fonts/SailecThin.ttf';
import Sailec from '../assets/fonts/Sailec.ttf';
import SailecBlack from '../assets/fonts/SailecBlack.ttf';
import SailecMedium from '../assets/fonts/SailecMedium.ttf';
import {
  getStyles,
  getSessionListItems,
  getClinics,
  getProviders,
  getProtocolDeviseDetails,
  getDiagnosisCode
} from './helper';
import { getDeviceTypeList } from 'utils/helper.js';
import { getDeviceList } from 'patient/helper.jsx';
import hillRomLogo from 'assets/img/logo-Hillrom.png';
import hillRomLogoBW from 'assets/img/logo-HillromBW.png';

class MyDocument extends Component {
  render() {
    const { isBlackAndWhite, data, tableRequired } = this.props;
    const flaggedPatient = isBlackAndWhite ? isBlackAndWhiteFlag : Flagged;
    const Pdf = [];
    const monarchLogo = isBlackAndWhite
      ? monarchBlackAndWhite
      : monarchLogoColor;
    const visiVestLogo = isBlackAndWhite
      ? visiVestLogoBlackAndWhite
      : visiVestLogoColor;
    const visiVestmanualLogo = isBlackAndWhite
      ? manualBlackAndWhiteLogo
      : manualLogo;
    const titanLogo = isBlackAndWhite
      ? titanBlackAndWhite
      : titanLogoColor;
    const deviceRef = {
      TITAN: [strings.titan, titanLogo, 'titan'],
      MONARCH: [strings.monarch, monarchLogo, 'monarch'],
      VEST: [strings.vest, visiVestLogo, 'visiVest']
    };

    Font.register({
      family: 'SailecBold',
      src: SailecBold,
      fontWeight: 700,
      fontStyle: 'normal'
    });

    Font.register({
      family: 'SailecThin',
      fontWeight: 100,
      fontStyle: 'normal',
      src: SailecThin
    });
    Font.register({
      family: 'Sailec',
      fontWeight: 400,
      fontStyle: 'normal',
      src: Sailec
    });
    Font.register({
      family: 'SailecBlack',
      fontWeight: 600,
      fontStyle: 'normal',
      src: SailecBlack
    });
    Font.register({
      family: 'SailecMedium',
      fontWeight: 600,
      fontStyle: 'normal',
      src: SailecMedium
    });
    const border_color = isBlackAndWhite ? '#e5e5e5' : '#dce4f1';
    const styles = getStyles(border_color, isBlackAndWhite);
    Object.keys(data).map(each => {
      let barCharts = [];
      let sessionLists = [];
      let {
        patient,
        clinics,
        providers,
        minutesGaugeRef,
        sessionGaugeRef,
        barChartRef,
        scoreCards,
        months,
        stats,
        filteredProtocols
      } = data[each];

      const { deviceType } = patient;

      const deviceList = getDeviceList(deviceType, stats);

      const deviceDetails = {
        TITAN: null,
        MONARCH: null,
        VEST: null
      };

      deviceList.forEach(device => {
        if (device === 'VEST') {
          deviceDetails.VEST = {};
          deviceDetails.VEST.sessionDone = stats.vest_sessions;
          deviceDetails.VEST.minutesDone = stats.vest_minutes;
        } else if (device === 'TITAN') {
          deviceDetails.TITAN = {};
          deviceDetails.TITAN.sessionDone = stats.titan_sessions;
          deviceDetails.TITAN.minutesDone = stats.titan_minutes;
        } else {
          deviceDetails.MONARCH = {};
          deviceDetails.MONARCH.sessionDone = stats.monarch_sessions;
          deviceDetails.MONARCH.minutesDone = stats.monarch_minutes;
        }
      });

      const TitanDetails = deviceDetails.TITAN || '';
      const MonarchDetails = deviceDetails.MONARCH || '';
      const vestDetails = deviceDetails.VEST || '';

      clinics = getClinics(clinics, styles);
      providers = getProviders(providers, styles);
      const missedSession = stats !== undefined ? stats.missed_sessions : '';
      const sessionDone =
        stats !== undefined ? stats.total_completed_sessions : '';
      const myScore = stats !== undefined ? stats.myScore : '';
      const sessionPercentage =
        stats !== undefined ? stats.completed_sessions_percentage : '';
      const sessionRecommended =
        stats !== undefined ? stats.total_sessions : '';
      const minutPercentage =
        stats !== undefined ? stats.completed_minutes_percentage : '';
      const minutDone =
        stats !== undefined ? stats.total_completed_minutes : '';
      const minutRecommended = stats !== undefined ? stats.total_minutes : '';
      let colorArrow = '';
      let blackAndWhiteArrow = '';
      let scoreArrow = '';
      let scoreOfadherence = '';
      if (stats !== undefined) {
        colorArrow = stats.myScoreDiff >= 0 ? greenArrow : redArrow;
        blackAndWhiteArrow = stats.myScoreDiff >= 0 ? grayArrow : blackArrow;
        scoreArrow = isBlackAndWhite ? blackAndWhiteArrow : colorArrow;
        scoreOfadherence = stats.myScoreDiff;
      }
      const minutGuageURL =
        minutesGaugeRef.current !== null &&
          minutesGaugeRef.current.chartRef.current !== null
          ? minutesGaugeRef.current.chartRef.current.toDataURL('image/png', 1.0)
          : '';
      const sessionGuageURL =
        sessionGaugeRef.current !== null &&
          sessionGaugeRef.current.chartRef.current !== null
          ? sessionGaugeRef.current.chartRef.current.toDataURL('image/png', 1.0)
          : '';
      if (barChartRef.length !== 0) {
        let idx = 0;
        barCharts = barChartRef.map(barChart => {
          const barChartURL =
            barChart.current !== null
              ? barChart.current
                .getChartURL()
                .current.chartInstance.canvas.toDataURL('image/png', 2.0)
              : '';
          const monthYear = moment(months[idx]).format('MMM YY');
          idx++;
          return barChartURL !== '' ? (
            <View
              key={uid(barChart)}
              style={styles.barChartBorder}
              wrap={false}
            >
              <View style={styles.barChartTitle}>
                <Text>{strings.therapyDuration.toUpperCase()}</Text>
                <View style={styles.barChartMonthYear}>
                  <Text style={styles.monthYear}>
                    {monthYear.toUpperCase()}
                  </Text>
                </View>
              </View>
              {barChartURL !== '' && <Image key={uid(idx)} src={barChartURL} />}
            </View>
          ) : (
            <View style={styles.barChartBorder} wrap={false}>
              <View style={styles.barChartTitle}>
                <Text>{strings.therapyDuration.toUpperCase()}</Text>
                <View style={styles.barChartMonthYear}>
                  <Text style={styles.monthYear}>
                    {monthYear.toUpperCase()}
                  </Text>
                </View>
              </View>
              <Text style={styles.noDataToDisplay}>No data to display</Text>
            </View>
          );
        });
      } else {
        barCharts.push(
          <View style={styles.barChartBorder} wrap={false}>
            <View style={styles.barChartTitle}>
              <Text>{strings.therapyDuration.toUpperCase()}</Text>
              <View style={styles.barChartMonthYear}>
                <Text style={styles.monthYear}></Text>
              </View>
            </View>
            <Text style={styles.noDataToDisplay}>No data to display</Text>
          </View>
        );
      }
      if (tableRequired && months.length !== 0) {
        let idx = 0;
        sessionLists = months.map(month => {
          const scoreCard = scoreCards[month];
          const sessionList = getSessionListItems(
            scoreCard,
            styles,
            deviceRef,
            idx,
            isBlackAndWhite,
            month,
            patient
          );
          idx++;
          return (
            <View key={uid(scoreCard)} style={styles.sessionList}>
              {sessionList}
            </View>
          );
        });
      } else if (tableRequired) {
        sessionLists.push(
          <View style={styles.sessionList}>
            <View
              style={styles.sessionListHeader}
              fixed
              wrap={false}
              key={uid('head')}
            >
              <Text style={[styles.sessionListLeftColumn, { fontSize: 6 }]}>
                {strings.o_date.toUpperCase()}
              </Text>
              <Text style={[styles.sesssionListMiddleColumn, { fontSize: 6 }]}>
                {strings.sessions.toUpperCase()}
              </Text>
              <Text style={[styles.sessionListRightColumn, { fontSize: 6 }]}>
                {strings.totalDuration.toUpperCase()}
              </Text>
            </View>
            <Text key="body" style={styles.noDataFound}>
              No Session Data Available.
            </Text>
          </View>
        );
      }
      const protocolDetails =
        !isEmpty(filteredProtocols) && Object.keys(filteredProtocols)
          .sort()
          .reverse()
          .map(dType => {
            let protocolList = filteredProtocols[dType];
            const protocolDetailsList = protocolList !== undefined && protocolList.map((eachProtocol, i) => {
              let deviceProto = {}
              deviceProto[dType] = eachProtocol.points;
              const protocolNew = getProtocolDeviseDetails(
                styles,
                deviceRef,
                dType,
                deviceProto,
                i,
                isBlackAndWhite,
                patient,
                eachProtocol.from,
                eachProtocol.to,
                eachProtocol.isActive
              );
              return (
                <View
                  key={uid(dType)}
                  style={styles.protocolDetails}
                  wrap={false}
                >
                  {protocolNew}
                </View>
              );
            });
            return protocolDetailsList;
          });

      Pdf.push(
        <Page size="A4" style={styles.page} key={uid(each)}>
          <View key={`user-${uid(each)}`} style={styles.container}>
            <View style={{ marginBottom: 100 }}>
              <Image
                src={isBlackAndWhite ? hillRomLogoBW : hillRomLogo}
                style={{
                  width: '110px',
                  height: '40px',
                  marginLeft: '20px',
                  marginBottom: '20px'
                }}
              />
              <View
                style={{ flexDirection: 'column', flexWrap: 1, margin: 10 }}
              >
                <View style={styles.patientInfo}>
                  {patient.flagged && (
                    <Image
                      src={flaggedPatient}
                      style={{ height: 10, width: 10, marginTop: 12 }}
                    />
                  )}
                  <Text style={styles.patientName}>
                    {patient.firstName} {patient.lastName}
                  </Text>
                </View>
              </View>

              <View
                style={{ flexDirection: 'column', flexWrap: 1, margin: 10 }}
              >
                <View style={styles.patientInfo}>
                  <Text style={styles.key}>{strings.Status}:</Text>
                  <Text style={styles.value}>
                    {patient.isDeleted ? strings.inactive : strings.active}{' '}
                    {patient.isDeleted && patient.inactiveReason
                      ? `(${patient.inactiveReason})`
                      : ''}
                  </Text>
                  <Text style={styles.key}> {strings.o_hillromId}: </Text>
                  <Text style={styles.value}>{patient.hillromId}</Text>
                  <Text style={styles.key}>{strings.dob.toUpperCase()}: </Text>
                  <Text style={styles.value}>{patient.dob}</Text>
                </View>
                {getDiagnosisCode(getDeviceTypeList(patient), styles)}
                {clinics}
                {providers}
              </View>
              {minutPercentage !== undefined &&
                sessionDone !== undefined &&
                myScore !== undefined &&
                scoreArrow !== undefined &&
                sessionPercentage !== undefined &&
                sessionGuageURL !== undefined &&
                minutGuageURL !== undefined &&
                missedSession !== undefined &&
                minutPercentage !== '' &&
                minutDone !== undefined &&
                minutDone !== '' &&
                sessionDone !== '' &&
                myScore !== '' &&
                scoreArrow !== '' &&
                sessionGuageURL !== '' &&
                minutGuageURL !== '' &&
                missedSession !== '' &&
                sessionPercentage !== '' && (
                  <View
                    style={{
                      marginBottom: 20
                    }}
                  >
                    <View style={{ flexDirection: 'row' }}>
                      {sessionGuageURL !== '' && (
                        <Image
                          src={sessionGuageURL}
                          style={{
                            width: '125px',
                            height: '100px',
                            position: 'absolute'
                          }}
                        />
                      )}

                      <View
                        style={{
                          flexDirection: 'column',
                          top: '20%',
                          position: 'absolute',
                          left: '8%',
                          color: isBlackAndWhite ? '#000000' : '#0d2457'
                        }}
                      >
                        <View
                          style={{
                            top: 35,
                            position: 'absolute',
                            textAlign: 'center',
                            flexDirection: 'row',
                            left:
                              sessionPercentage.toString().length === 1
                                ? 6
                                : sessionPercentage.toString().length === 3
                                  ? -8
                                  : 0
                          }}
                        >
                          <Text
                            style={{
                              fontFamily: 'SailecBold'
                            }}
                          >
                            <Text style={{ fontSize: 25, letterSpacing: 6 }}>
                              {sessionPercentage}
                            </Text>
                            <Text>{'  '}</Text>
                            {
                              <Text
                                style={{ fontSize: 15, fontFamily: 'Sailec' }}
                              >
                                %
                              </Text>
                            }
                          </Text>
                        </View>
                        <View
                          style={{
                            top: 65,
                            left: 5,
                            fontSize: 7,
                            textAlign: 'center',
                            fontFamily: 'Sailec'
                          }}
                        >
                          <Text>
                            {sessionDone}/{sessionRecommended}
                          </Text>
                        </View>
                        <View
                          style={{
                            top: 87,
                            left: -17,
                            fontSize: 7,
                            textAlign: 'center',
                            fontFamily: 'Sailec'
                          }}
                        >
                          {minutGuageURL !== '' && (
                            <Text>{strings.o_completedSessions}</Text>
                          )}
                        </View>
                      </View>
                      {minutGuageURL !== '' && (
                        <Image
                          src={minutGuageURL}
                          style={{
                            width: '125px',
                            height: '100px',
                            right: '57%',
                            position: 'absolute'
                          }}
                          color="black"
                        />
                      )}
                      <View
                        style={{
                          flexDirection: 'column',
                          top: '20%',
                          position: 'absolute',
                          left: '29%',
                          color: isBlackAndWhite ? '#000000' : '#0d2457'
                        }}
                      >
                        <View
                          style={{
                            top: 35,
                            flexDirection: 'row',
                            textAlign: 'center',
                            left:
                              minutPercentage.toString().length === 1
                                ? 6
                                : minutPercentage.toString().length === 3
                                  ? -8
                                  : 0
                          }}
                        >
                          <Text style={{ fontFamily: 'SailecBold' }}>
                            <Text style={{ fontSize: 25, letterSpacing: 6 }}>
                              {minutPercentage}
                            </Text>
                            <Text>{'  '}</Text>
                            {
                              <Text
                                style={{ fontSize: 15, fontFamily: 'Sailec' }}
                              >
                                %
                              </Text>
                            }
                          </Text>
                        </View>
                        <Text
                          style={{
                            top: 65,
                            fontSize: 7,
                            left: 0,
                            textAlign: 'center',
                            fontFamily: 'Sailec'
                          }}
                        >
                          {minutDone}/{minutRecommended}
                        </Text>
                        {minutGuageURL !== '' && (
                          <Text
                            style={{
                              top: 87,
                              left: -15,
                              fontSize: 7,
                              textAlign: 'center',
                              fontFamily: 'Sailec'
                            }}
                          >
                            Completed Minutes
                          </Text>
                        )}
                      </View>
                      <View
                        style={{
                          flexDirection: 'column',
                          fontFamily: 'SailecBold',
                          left: 248
                        }}
                      >
                        <View
                          style={{
                            flexDirection: 'row',
                            // left: -6,
                            flexWrap: 1,
                            padding: 5
                          }}
                        >
                          <View style={styles.scoreUpperCard}>
                            <Text style={styles.scoreUpperCardNumber}>
                              <Text>{sessionDone}</Text>
                            </Text>
                            <View style={styles.scoreUpperCardText}>
                              <Text>Completed</Text>
                              <Text>Sessions</Text>
                            </View>
                          </View>
                          <View style={[styles.scoreUpperCard, { left: 110 }]}>
                            <Text style={styles.scoreUpperCardNumber}>
                              <Text>{missedSession}</Text>
                            </Text>
                            <View style={styles.scoreUpperCardText}>
                              <Text>Missed</Text>
                              <Text>Sessions</Text>
                            </View>
                          </View>
                          <View style={[styles.scoreUpperCard, { left: 220 }]}>
                            <Text style={styles.scoreUpperCardNumber}>
                              {myScore}
                            </Text>
                            <View style={[styles.scoreUpperCardText, { paddingTop: myScore === 0 ? 10 : 5 }]}>
                              <Text>myScore</Text>
                              {
                                myScore !== 0 ?
                                  <View style={{ flexDirection: 'row' }}>
                                    <Text>{scoreOfadherence} </Text>
                                    <Image
                                      src={scoreArrow}
                                      style={{ height: 5, width: 5 }}
                                    />
                                  </View>
                                  :
                                  null
                              }
                            </View>
                          </View>
                        </View>

                        <View
                          style={{
                            flexDirection: 'row',
                            top: 50,
                            left: 2
                          }}
                        >
                          {TitanDetails !== '' &&
                            TitanDetails.sessionDone !== null && (
                              <View
                                style={
                                  MonarchDetails !== ''
                                    ? [styles.scoreDowncard]
                                    : [styles.scoreDowncard]
                                }
                              >
                                <View style={{ padding: 2, paddingTop: 7 }}>
                                  <Image
                                    style={{ height: 20, width: 20 }}
                                    src={deviceRef.TITAN[1]}
                                  />
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: MonarchDetails === '' ? 10 : 0
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {TitanDetails.sessionDone}
                                  </Text>
                                  <View style={styles.scoreDownCardText}>
                                    <Text>Total</Text>
                                    <Text>Sessions</Text>
                                  </View>
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: MonarchDetails === '' ? 20 : 2
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {TitanDetails.minutesDone}
                                  </Text>
                                  <View style={styles.scoreDownCardText}>
                                    <Text>Completed</Text>
                                    <Text>Minutes</Text>
                                  </View>
                                </View>
                              </View>
                            )}

                          {MonarchDetails !== '' &&
                            MonarchDetails.sessionDone !== null && (
                              <View
                                style={
                                  vestDetails !== ''
                                    ? [styles.scoreDowncard, { left: 110 }]
                                    : [styles.scoreDowncard]
                                }
                              >
                                <View style={{ padding: 2, paddingTop: 7 }}>
                                  <Image
                                    style={{ height: 20, width: 20 }}
                                    src={deviceRef.MONARCH[1]}
                                  />
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: vestDetails === '' ? 5 : 0
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {MonarchDetails.sessionDone}
                                  </Text>
                                  <View style={styles.scoreDownCardText}>
                                    <Text>Total</Text>
                                    <Text>Sessions</Text>
                                  </View>
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: vestDetails === '' ? 5 : 2
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {MonarchDetails.minutesDone}
                                  </Text>
                                  <View style={styles.scoreDownCardText}>
                                    <Text>Completed</Text>
                                    <Text>Minutes</Text>
                                  </View>
                                </View>
                              </View>
                            )}

                          {vestDetails !== '' &&
                            vestDetails.sessionDone !== null && (
                              <View
                                style={
                                  TitanDetails !== ''
                                    ? [styles.scoreDowncard, { left: 220 }]
                                    : [styles.scoreDowncard]
                                }
                              >
                                <View style={{ padding: 2, paddingTop: 7 }}>
                                  <Image
                                    style={patient.isManual ? { height: 18, width: 25 } : { height: 20, width: 20 }}
                                    src={patient.isManual ? visiVestmanualLogo : deviceRef.VEST[1]}
                                  />
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: TitanDetails === '' ? 5 : 0
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {vestDetails.sessionDone}
                                  </Text>

                                  <View style={styles.scoreDownCardText}>
                                    <Text>Total</Text>
                                    <Text>Sessions</Text>
                                  </View>
                                </View>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    left: TitanDetails === '' ? 5 : 2
                                  }}
                                >
                                  <Text style={styles.scoreDownCardNumber}>
                                    {vestDetails.minutesDone}
                                  </Text>
                                  <View style={styles.scoreDownCardText}>
                                    <Text>Completed</Text>
                                    <Text>Minutes</Text>
                                  </View>
                                </View>
                              </View>
                            )}
                        </View>
                      </View>
                    </View>
                  </View>
                )}
            </View>
            {barCharts}
            {protocolDetails}
            {sessionLists}
          </View>
        </Page>
      );
      return true;
    });
    return <Document>{Pdf}</Document>;
  }
}

export default MyDocument;
