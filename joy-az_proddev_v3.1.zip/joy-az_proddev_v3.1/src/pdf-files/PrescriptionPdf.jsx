import React, { Component } from 'react';
import { Document, Page, Text, View, Image } from '@react-pdf/renderer';
import strings from 'localization/strings';
import moment from 'moment-timezone';
import { getStyles } from './helper';
import visiVestLogo from 'assets/img/visivestBlackAndWhite.png';
import monarchLogo from 'assets/img/monarchBlackAndWhite.png';
import titanLogo from 'assets/img/logo/titanlogo.png';
import hillRomLogo from 'assets/img/logo-Hillrom.png';
import { getProtocolTypeLabel } from 'patient/helper';

const styles = getStyles();
class MyDocument extends Component {
  protocolData() {
    const newProtocol = this.props.protocols;
    const deviceRef = {
      TITAN: ['Titan', titanLogo, 'titan'],
      MONARCH: ['Monarch', monarchLogo, 'monarch'],
      VEST: ['VisiVest', visiVestLogo, 'visivest']
    };
    let protocols = [];
    let devices = [];
    let types = [];
    let treatments = [];
    let minutes = [];
    let frequencies = [];
    let intensities = [];
    let count = 0;

    newProtocol.forEach((newPro, index) => {
      count = newProtocol.length;
      index === 0 &&
        devices.push(
          <View
            style={{
              height: 30 * count,
              alignItems: 'center',
              justifyContent: 'center',
              borderLeft: 1,
              borderBottom: 1,
              borderColor: '#dedede'
            }}
          >
            <Image
              src={deviceRef[newPro.deviceType][1]}
              style={styles.deviceImage}
              alt={deviceRef[newPro.deviceType][0]}
            />
          </View>
        );
      types.push(
        <Text
          style={{
            height: '30px',
            fontSize: 9,
            paddingTop: '8px',
            textAlign: 'center',
            border: 1,
            borderColor: '#dedede',
            borderTop: 0,
            fontFamily: 'Sailec'
          }}
        >
          {getProtocolTypeLabel(newPro.type, newPro.treatmentLabel)}
        </Text>
      );
      index === 0 &&
        treatments.push(
          <View
            style={{
              height: 30 * count,
              alignItems: 'center',
              justifyContent: 'center',
              borderBottom: 1,
              borderColor: '#dedede'
            }}
          >
            <Text
              style={{
                fontSize: 9,
                fontFamily: 'Sailec'
              }}
            >
              {newPro.treatmentsPerDay}
            </Text>
          </View>
        );
      minutes.push(
        <Text
          style={{
            height: '30px',
            fontSize: 9,
            paddingTop: '8px',
            textAlign: 'center',
            border: 1,
            borderColor: '#dedede',
            borderTop: 0,
            fontFamily: 'Sailec'
          }}
        >
          {newPro.minMinutesPerTreatment}
        </Text>
      );
      frequencies.push(
        <Text
          style={{
            height: '30px',
            fontSize: 9,
            paddingTop: '8px',
            textAlign: 'center',
            borderBottom: 1,
            borderColor: '#dedede',
            fontFamily: 'Sailec'
          }}
        >
          {newPro.minFrequency}
          {newPro.maxFrequency === newPro.minFrequency || !newPro.maxFrequency
            ? ''
            : `-${newPro.maxFrequency}`}
        </Text>
      );
      newPro.deviceType === 'VEST'
        ? intensities.push(
          <Text
            style={{
              height: '30px',
              fontSize: 9,
              paddingTop: '8px',
              textAlign: 'center',
              border: 1,
              borderColor: '#dedede',
              borderTop: 0,
              fontFamily: 'Sailec'
            }}
          >
            {newPro.minPressure}
            {newPro.maxPressure === newPro.minPressure || !newPro.maxPressure
              ? ''
              : `-${newPro.maxPressure}`}
          </Text>
        )
        : intensities.push(
          <Text
            style={{
              height: '30px',
              fontSize: 9,
              paddingTop: '8px',
              textAlign: 'center',
              border: 1,
              borderColor: '#dedede',
              borderTop: 0,
              fontFamily: 'Sailec'
            }}
          >
            {newPro.minIntensity}
            {newPro.maxIntensity === newPro.minIntensity ||
              !newPro.maxIntensity
              ? ''
              : `-${newPro.maxIntensity}`}
          </Text>
        );
    });
    protocols.push(
      <View style={{ display: 'flex', flexDirection: 'row' }}>
        <View
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '8%'
          }}
        >
          {devices}
        </View>
        <View
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '25.5%'
          }}
        >
          {types}
        </View>
        <View
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '15%'
          }}
        >
          {treatments}
        </View>
        <View
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '17%'
          }}
        >
          {minutes}
        </View>
        <View
          style={{ display: 'flex', flexDirection: 'column', width: '17%' }}
        >
          {frequencies}
        </View>
        <View
          style={{ display: 'flex', flexDirection: 'column', width: '17%' }}
        >
          {intensities}
        </View>
      </View>
    );
    return protocols;
  }
  render() {
    let Pdf = [];
    Pdf.push(
      <Page style={{ padding: '10px' }} size="A4">
        <View>
          <Text
            style={{
              textAlign: 'center',
              marginTop: '20px',
              fontFamily: 'Sailec'
            }}
          >
            Hillrom Respiratory Care
          </Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'flex-start',
              marginBottom: '5px'
            }}
          >
            <Image
              src={hillRomLogo}
              style={{
                width: '110px',
                height: '40px'
              }}
            />
          </View>
          <View
            style={{
              width: '100%',
              backgroundColor: 'black',
              height: '1px',
              marginBottom: '30px'
            }}
          ></View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              paddingBottom: '20px'
            }}
          >
            <Text style={styles.date}>Report Generation Date : </Text>
            <Text style={styles.date}>{moment().format(' MM/DD/YYYY')}</Text>
          </View>
          <Text style={styles.heading}>Details</Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginBottom: '20px'
            }}
          >
            <View style={{ display: 'flex', flexDirection: 'column' }}>
              <Text style={styles.label}>PATIENT NAME</Text>
              <Text style={styles.content}>{this.props.patientName}</Text>
            </View>
            <View
              style={{
                display: 'flex',
                flexDirection: 'column',
                marginLeft: '10px'
              }}
            >
              <Text style={styles.label}>PATIENT DOB</Text>
              <Text style={styles.content}>{this.props.patientDob}</Text>
            </View>
          </View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginBottom: '20px'
            }}
          >
            <View style={{ display: 'flex', flexDirection: 'column' }}>
              <Text style={styles.label}>PRESCRIBER NAME</Text>
              <Text style={styles.content}>{this.props.prescriberName}</Text>
            </View>
            <View
              style={{
                display: 'flex',
                flexDirection: 'column',
                marginLeft: '10px'
              }}
            >
              <Text style={styles.label}>DATE</Text>
              <Text style={styles.content}>
                {moment().format('DD/MM/YYYY')}
              </Text>
            </View>
          </View>
          <View>
            <Text style={styles.heading}>New Protocol</Text>
            <View
              style={{
                display: 'flex',
                flexDirection: 'row',
                border: 1,
                height: '30px',
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                padding: '7px',
                borderColor: '#dedede'
              }}
            >
              <View style={{ width: '10%', marginLeft: '2px' }}>
                <Text style={styles.headingCell}>{strings.device}</Text>
              </View>
              <View style={{ width: '12%', marginLeft: '42px' }}>
                <Text style={styles.headingCell}>{strings.type}</Text>
              </View>
              <View style={{ width: '15%', marginLeft: '30px' }}>
                <Text style={styles.headingCell}>
                  {strings.treatmentsPerDay}
                </Text>
              </View>
              <View style={{ width: '16%', marginLeft: '2px' }}>
                <Text style={styles.headingCell}>
                  {strings.minutesPerTreatment}
                </Text>
              </View>
              <View style={{ width: '17%', marginLeft: '2px' }}>
                <Text style={styles.headingCell}>
                  {strings.frequencyPerTreatment}
                </Text>
              </View>
              <View style={{ width: '17%', marginLeft: '2px' }}>
                <Text style={styles.headingCell}>
                  {strings.pressurePerTreatment}
                </Text>
              </View>
            </View>
            <View>{this.protocolData()}</View>
          </View>
          <View
            style={{ display: 'flex', flexDirection: 'row', marginTop: '40px' }}
          >
            <Text
              style={{ fontSize: 9, marginRight: '5px', fontFamily: 'Sailec' }}
            >
              Signature:
            </Text>
            <Text
              style={{ borderBottom: 1, fontSize: 9, fontFamily: 'Sailec' }}
            >
              Electronically signed by {this.props.prescriberName} on
              {moment().format(' MMMM Do YYYY, HH:MM')}
            </Text>
          </View>
        </View>
      </Page>
    );

    return <Document>{Pdf}</Document>;
  }
}
export default MyDocument;
