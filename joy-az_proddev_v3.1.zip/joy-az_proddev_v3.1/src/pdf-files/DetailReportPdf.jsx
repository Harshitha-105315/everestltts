import React, { Component } from 'react';
import { Document, Page, Text, View, Font, Image } from '@react-pdf/renderer';
import { uid } from 'react-uid';
import SailecBold from '../assets/fonts/SailecBold.ttf';
import SailecThin from '../assets/fonts/SailecThin.ttf';
import Sailec from '../assets/fonts/Sailec.ttf';
import SailecBlack from '../assets/fonts/SailecBlack.ttf';
import SailecMedium from '../assets/fonts/SailecMedium.ttf';
import strings from 'localization/strings';
import moment from 'moment-timezone';
import hrFlag from 'assets/img/flag.png';
import { getDeviceTypeList } from 'utils/helper.js';

import {
  getStyles,
  getClinics,
  getProviders,
  getDiagnosisCode,
  getSessionItems
} from './helper';

class MyDocument extends Component {
  render() {
    const { isBlackAndWhite, data } = this.props;
    let Pdf = [];
    Font.register({
      family: 'SailecBold',
      src: SailecBold,
      fontWeight: 700,
      fontStyle: 'normal'
    });

    Font.register({
      family: 'SailecThin',
      fontWeight: 100,
      fontStyle: 'normal',
      src: SailecThin
    });
    Font.register({
      family: 'Sailec',
      fontWeight: 400,
      fontStyle: 'normal',
      src: Sailec
    });
    Font.register({
      family: 'SailecBlack',
      fontWeight: 600,
      fontStyle: 'normal',
      src: SailecBlack
    });
    Font.register({
      family: 'SailecMedium',
      fontWeight: 600,
      fontStyle: 'normal',
      src: SailecMedium
    });
    const border_color = isBlackAndWhite ? '#e5e5e5' : '#dce4f1';
    const styles = getStyles(border_color, isBlackAndWhite);
    let sessionLists = [];
    const { patient, pClinics, pProviders } = data;
    let clinics = getClinics(pClinics, styles);
    let providers = getProviders(pProviders, styles);
    let noData = true;
    if (data.allMonthsSessionData.length !== 0) {
      for (let i = 0; i < data.allMonthsSessionData.length; i++) {
        let sessionDetails = data.allMonthsSessionData[i];
        if (sessionDetails.length !== 0) {
          noData = false;
        }
      }
      if (!noData) {
        let idx = 0;
        sessionLists = data.allMonthsSessionData.map(session => {
          let sessionList = getSessionItems(
            session,
            styles,
            idx,
            isBlackAndWhite
          );
          idx++;
          return (
            <View key={uid(session)} style={styles.sessionList}>
              {sessionList}
            </View>
          );
        });
      } else {
        sessionLists.push(
          <View style={styles.sessionList}>
            <View
              style={styles.sessionListHeader}
              fixed
              wrap={false}
              key={uid('head')}
            >
              <Text style={[styles.sessionDateHeading]}>DATE</Text>
              <Text style={[styles.sessionTimeHeading, { fontSize: 6 }]}>
                TIME
              </Text>
              <Text style={[styles.sessionEventHeading, { fontSize: 6 }]}>
                EVENT
              </Text>
              <Text style={[styles.sessionFrequencyHeading, { fontSize: 6 }]}>
                FREQUENCY
              </Text>
              <Text style={[styles.sessionPressureHeading, { fontSize: 6 }]}>
                PRESSURE
              </Text>
              <Text style={[styles.sessionSessionDurHeading, { fontSize: 6 }]}>
                SESSION DURATION
              </Text>
              <Text style={[styles.sessionDeviceHeading, { fontSize: 6 }]}>
                DEVICE
              </Text>
            </View>
            <Text key={'body'} style={styles.noDataFound}>
              No Session Data Available.
            </Text>
          </View>
        );
      }
    }
    Pdf.push(
      <Page size="A4" style={styles.page} key={uid(data)}>
        <View key={'user-' + uid(data)} style={styles.container}>
          <View wrap={false} style={{ marginBottom: 100 }}>
            {patient.flagged && (
              <Image style={styles.imageAlign} src={hrFlag} />
            )}
            <Text style={styles.patientNameAlign}>
              {patient.firstName} {patient.lastName}
            </Text>
            <View style={{ flexDirection: 'column', flexWrap: 1, margin: 10 }}>
              <View style={styles.patientInfo}>
                <Text style={styles.key}> {strings.Status}: </Text>
                <Text style={styles.value}>
                  {patient.isDeleted ? strings.inactive : strings.active}{' '}
                  {patient.isDeleted && patient.inactiveReason ? `(${patient.inactiveReason})` : ''}
                </Text>
                <Text style={styles.key}> {strings.o_hillromId}: </Text>
                <Text style={styles.value}>{patient.hillromId}</Text>
                <Text style={styles.key}>{strings.dob.toUpperCase()}: </Text>
                <Text style={styles.value}>
                  {`${
                    moment(new Date(patient.dob)).isValid()
                      ? moment(new Date(patient.dob)).format('DD MMM YYYY')
                      : '-'
                    }`}
                </Text>
              </View>
              {getDiagnosisCode(getDeviceTypeList(patient), styles)}
              {clinics}
              {providers}
            </View>
          </View>
          {sessionLists}
        </View>
      </Page>
    );

    return <Document>{Pdf}</Document>;
  }
}
export default MyDocument;
