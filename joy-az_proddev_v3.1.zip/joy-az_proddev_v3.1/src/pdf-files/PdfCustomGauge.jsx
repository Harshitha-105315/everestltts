import React, { Component } from 'react';
import { Donut } from 'gaugeJS';
import { isEqual, isEmpty } from 'lodash';

class PdfCustomGauge extends Component {
  chartRef = React.createRef();

  componentDidMount() {
    this.initGraph();
  }

  componentDidUpdate(prevProps) {
    const { data: newGraphData } = this.props;
    const { data: oldGraphData } = prevProps;
    if (!isEqual(oldGraphData, newGraphData)) {
      this.initGraph();
    }
  }

  initGraph() {
    const { data: graphData } = this.props;
    const gaugeRef = this.chartRef.current;
    const maxValue = 100;
    if (!isEmpty(graphData)) {
      const { percentage } = graphData;
      let color;
      if (percentage >= 80) {
        color = this.props.isBlackAndWhite ? '#000000' : '#61d623';  // 80 - 100
      } else if (percentage >= 50) {
        color = this.props.isBlackAndWhite ? '#777367' : '#ffd224';  // 50 - 79
      } else {
        color = this.props.isBlackAndWhite ? '#a09898' : '#fc2e2e';  // 0 - 49
      }
      const opts = {
        angle: 0.2,
        lineWidth: 0.1,
        radiusScale: 1,
        colorStart: color,
        colorStop: color,
        strokeColor: '#e6e9ee',
        shadowColor: '#e6e9ee',
        highDpiSupport: true
      };
      const customGauge = new Donut(gaugeRef);
      customGauge.setOptions(opts);
      customGauge.maxValue = maxValue;
      customGauge.animationSpeed = 1;
      customGauge.set(percentage);
    }
  }

  render() {
    const { data: graphData, idx } = this.props;
    if (!isEmpty(graphData)) {
      return (
        <div key={idx}>
          <canvas width="250" height="200" ref={this.chartRef} key={idx} />
        </div>
      );
    }
    return null;
  }
}
export default PdfCustomGauge;
