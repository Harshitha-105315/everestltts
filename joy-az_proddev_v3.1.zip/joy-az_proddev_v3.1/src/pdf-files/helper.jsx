import { Text, View, Image, StyleSheet } from '@react-pdf/renderer';
import React from 'react';
import moment from 'moment-timezone';
import { map, isEmpty, groupBy } from 'lodash';
import strings from 'localization/strings';
import { uid } from 'react-uid';
import monarchBlackAndWhite from 'assets/img/monarchBlackAndWhite.png';
import visiVestLogoBlackAndWhite from 'assets/img/visivestBlackAndWhite.png';
import { getFormattedTime } from 'utils/helper';
import { getProtocolTypeLabel } from 'patient/helper';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import manualBlackAndWhiteLogo from 'assets/img/logo/icn_nonconnected@2xBlackAndWhite.png';
import { getMonthsOfYear } from 'patient/helper.jsx';
import spiroLogoColor from 'assets/img/spiro.png';
import spiroBlackAndWhiteLogo from 'assets/img/spiro_black_and_white.png';
import grayArrow from 'assets/img/gray-arrow.png';

export function spiroSpan(scoreCard, month, idx, styles, isBlackAndWhite) {
  var weeklyAvgTherapy = 0;
  var therapySpans = [];
  var noOfWeeks = 0;
  var monthlyAvgTherapy = 0;
  var spiroData = scoreCard["spiro"] !== undefined ? scoreCard["spiro"] : [];
  var therapyData = scoreCard["therapy"] !== undefined ? scoreCard["therapy"] : [];

  let tmonthStart = moment(month).startOf('month').day('Sunday');
  let nextMonth = moment(month).add(1, 'month');

  let tmonthEnd = moment(nextMonth).startOf('month').day('Sunday');
  tmonthEnd = moment(tmonthEnd).subtract(1, 'day');
  if (idx === 0) {
    tmonthEnd = moment(nextMonth).startOf('month').day('Sunday');
    tmonthEnd = moment(tmonthEnd).add(6, 'days');
  }
  var spiroFiltered = [];

  spiroFiltered = spiroData.filter(e => moment(e.testResultDate) >= tmonthStart && moment(e.testResultDate) <= tmonthEnd
    && e.fev1_TO_FVC_RATIO > 0);
  var filteredTherapyData = therapyData.filter(e => moment(e.date) >= tmonthStart && moment(e.date) <= tmonthEnd);
  var tindex = 0;
  while (tmonthEnd > tmonthStart) {
    var weeklyTherapyData = filteredTherapyData.filter(e => moment(e.date) <= tmonthEnd && moment(e.date) >= moment(moment(tmonthEnd).subtract(6, 'days')));
    var sumTherapy = weeklyTherapyData.reduce((prev, next) => prev + next.duration, 0);
    weeklyAvgTherapy += (sumTherapy / 7);
    if ((sumTherapy / 7) > 0) {
      therapySpans.push(<View key={uid(month, tindex)} style={styles.sessionListBody} >
        <Text style={{
          color: 'black',
          fontSize: 7,
          width: 60,
          margin: 1
        }}>
          {moment(moment(tmonthEnd).subtract(6, 'days')).format('MMM DD')} -
            {moment(moment(tmonthEnd).subtract(6, 'days')).isSame(month, 'month') ? moment(tmonthEnd).format('DD')
            : moment(tmonthEnd).format('MMM DD')}
        </Text>
        <Text style={{
          color: 'black',
          fontSize: 7,
          margin: 1,
        }}>{(sumTherapy / 7).toFixed(0)} Mins</Text>
      </View >);
    }
    noOfWeeks++;
    tindex++;
    tmonthEnd = moment(tmonthEnd).subtract(7, 'days');
  }
  monthlyAvgTherapy = (weeklyAvgTherapy / noOfWeeks).toFixed(0);

  spiroFiltered.sort(function (a, b) {
    var keyA = moment(a.testResultDate),
      keyB = moment(b.testResultDate);
    if (keyA > keyB) return -1;
    if (keyA < keyB) return 1;
    return 0;
  });
  var dayWiseSipro = groupBy(spiroFiltered, 'testResultDate');

  const spiroVal = Object.keys(dayWiseSipro)
    .map(key => {
      var spiro = (dayWiseSipro[key]).reduce((p, n) => (p.fev1_TO_FVC_RATIO > n.fev1_TO_FVC_RATIO) ? p : n);
      return (<View style={{ marginTop: 3 }}>
        {spiro.type === "SPIRO" ?
          <View key={uid(key)} style={styles.sessionListBody} >
            <Text style={{ width: 60, fontSize: 7 }}>{moment.utc(spiro.testResultDate).format('MMM DD, YYYY')}</Text>
            <Text style={{
              width: 40, color: 'black',
              fontSize: 7,
              fontWeight: 'bold',
            }}>{(spiro.fev1_TO_FVC_RATIO).toFixed(2)}%</Text>
            <View style={{ width: 10 }}
              style={{ backgroundColor: isBlackAndWhite ? '#000' : '#27e7cf', height: 5, width: 5, marginRight: 3, marginLeft: 3, borderRadius: 50 }}
            ></View>
            <Text style={{ width: 50, fontSize: 6 }}>{strings.hillromSpiro}</Text>
          </View>
          :
          <View key={uid(key)} style={styles.sessionListBody} >
            <Text style={{ width: 60 }} className="font-size-11">{moment.utc(spiro.testResultDate).format('MMM DD, YYYY')}</Text>
            <Text style={{
              width: 40,
              fontSize: 7,
              fontWeight: 'bold',
            }}>{(spiro.fev1_TO_FVC_RATIO).toFixed(2)}%</Text>
            {isBlackAndWhite ?
              <Image
                src={grayArrow}
                style={{ height: 5, width: 5, marginRight: 3, marginLeft: 3 }}
              />
              :
              <View
                style={{ backgroundColor: '#5568e6', height: 5, width: 5, marginRight: 3, marginLeft: 3, borderRadius: 50 }}
              ></View>
            }
            <Text style={{ width: 50, fontSize: 6 }}>{strings.otherSpiro}</Text>
          </View>}
      </View>)

      // return (<View key={uid(key)} style={styles.sessionListBody} >
      //   <Text className="font-size-11">{moment(spiro.testResultDate).format('MMM DD, YYYY')}</Text>
      //   <Text className="font-size-11 font-weight-bold" style={{ marginLeft: 10 }}>{(spiro.fev1_TO_FVC_RATIO).toFixed(2)}%</Text>
      //   {spiro.type === "SPIRO" ?
      //     <Text className="font-size-10" style={{ marginLeft: 10 }}>
      //       <Text style={{ backgroundColor: '#FC2E2E', height: 10, width: 10, marginLeft: 10, borderRadius: 50 }}
      //         className="home-test-dot"></Text>{strings.hillromSpiro}</Text>
      //     :
      //     <Text className="font-size-10" style={{ marginLeft: 10 }}><Text className="clinic-test-dot"></Text>{strings.otherSpiro}</Text>}
      // </View>)
    });

  return { monthlyAvgTherapy: `${monthlyAvgTherapy} Mins`, therapySpans: therapySpans, spiroSpans: spiroVal };
}

export function therapySpan(dateGroupData, date, protocolDuration, deviceRef, styles, isBlackAndWhite, patient) {
  let totalDuration = 0;
  const daySessions = dateGroupData[date];
  let deviated = true;
  const visiVestmanualLogo = isBlackAndWhite
    ? manualBlackAndWhiteLogo
    : manualLogo;
  const retval = map(daySessions, (daySession, index) => {
    const { deviceType, duration, dateTime, isCompliant } = daySession;
    const isManualVest = deviceRef[deviceType][0] === strings.vest && patient.isManual ? true : false;
    if (duration >= 0) {
      totalDuration += duration;
    }
    deviated = !isCompliant && deviated;
    return duration >= 0 && dateTime ? (
      <View key={uid(date, index)} style={styles.sessionListBody}>
        <Image
          src={isManualVest ? visiVestmanualLogo : deviceRef[deviceType][1]}
          style={isManualVest ? { height: 10, width: 15, marginTop: -3 } : { height: 18, width: 18, marginTop: -5 }}
        />
        <Text
          key={`${uid(date, index)}-text`}
          style={{
            color: 'black',
            fontSize: 7,
            margin: 1
          }}
        >
          {getFormattedTime(dateTime)} - {`${duration} m`}
        </Text>
      </View>
    ) : null;
  });
  return { duration: `${totalDuration} min`, spans: retval, deviated: totalDuration < protocolDuration ? true : deviated };
}

export function getSpiroSessionListItems(
  scoreCards,
  styles,
  idx,
  isBlackAndWhite,
  years
) {
  const sessionListItems = [];
  const spirometerLogo = isBlackAndWhite
    ? spiroBlackAndWhiteLogo
    : spiroLogoColor;
  let index = 1;
  if (
    scoreCards
    // scoreCard &&
    // scoreCard.dateGroupData
  ) {
    sessionListItems.push(
      <View
        key={uid(index)}
        style={styles.sessionListHeader}
        fixed
        wrap={false}
      >
        <Text style={[styles.spiroSessionListLeftColumn, { fontSize: 6 }]}>
          {strings.monthYear.toUpperCase()}
        </Text>
        <Text style={[styles.spiroSesssionListMiddleHeaderColumn, { fontSize: 6 }]}>
          {strings.dailyTherapyAverage.toUpperCase()}
        </Text>
        <Text style={[styles.spiroSessionListRightColumn, { fontSize: 6, paddingLeft: 135 }]}>
          <Image
            src={spirometerLogo}
            style={{ height: 10, width: 15 }}
          /> {strings.fev1Predicted.toUpperCase()}
        </Text>
      </View>
    );
    years.map(year => {
      var monthList = getMonthsOfYear(year);
      monthList.map((month, inx) => {
        const bodyRow = styles.sessionListRow;
        //   scoreCard.dates.length === index
        //     ? styles.sessionListBottomRow
        //     : styles.sessionListRow;
        const { monthlyAvgTherapy, therapySpans, spiroSpans } = spiroSpan(
          scoreCards[year],
          month,
          inx,
          styles,
          isBlackAndWhite
        );

        sessionListItems.push(
          <View key={`${uid(month)}-${index}`} style={bodyRow} wrap={false}>
            <View style={styles.spiroSessionListLeftColumn}>
              <Text>{moment(month).format('MMM YYYY')}</Text>
            </View>
            <View
              style={[
                styles.spiroSesssionListMiddleColumn,
                { flexWrap: 1 }
              ]}
            >
              <Text style={{
                color: 'black',
                fontSize: 7,
                margin: 1
              }}>{monthlyAvgTherapy} </Text>
            </View>
            <View
              style={[
                styles.spiroSesssionListSecondMiddleColumn,
                { flexWrap: 1 }
              ]}
            >
              {therapySpans}
            </View>
            <View style={[styles.spiroSessionListRightColumn]}>
              {spiroSpans}
            </View>
          </View>
        );
        index++;
        return true;
      });
    });

  }
  else {
    sessionListItems.push(
      <View
        key={uid(`header-${idx}`)}
        style={styles.sessionListHeader}
        fixed
        wrap={false}
      >
        <Text style={[styles.sessionListLeftColumn, { fontSize: 6 }]}>
          {strings.monthYear.toUpperCase()}
        </Text>
        <Text style={[styles.spiroSesssionListMiddleColumn, { fontSize: 6 }]}>
          {strings.dailyTherapyAverage.toUpperCase()}
        </Text>
        <Text style={[styles.spiroSessionListRightColumn, { fontSize: 6, paddingLeft: 135 }]}>
          <Image
            src={spirometerLogo}
            style={{ height: 10, width: 15 }}
          />{strings.fev1Predicted.toUpperCase()}
        </Text>
      </View>
    );
    sessionListItems.push(
      <Text style={styles.noDataFound} key={uid(`body-${idx}`)}>
        {`No session data available`}
      </Text>
    );
  }
  return sessionListItems;
}

export function getSessionListItems(
  scoreCard,
  styles,
  deviceRef,
  idx,
  isBlackAndWhite,
  month,
  patient
) {
  const sessionListItems = [];
  let index = 1;
  if (
    scoreCard.dates &&
    scoreCard.dates.length &&
    scoreCard &&
    scoreCard.dateGroupData
  ) {
    sessionListItems.push(
      <View
        key={uid(index)}
        style={styles.sessionListHeader}
        fixed
        wrap={false}
      >
        <Text style={[styles.sessionListLeftColumn, { fontSize: 6 }]}>
          {strings.o_date.toUpperCase()}
        </Text>
        <Text style={[styles.sesssionListMiddleColumn, { fontSize: 6 }]}>
          {strings.sessions.toUpperCase()}
        </Text>
        <Text style={[styles.sessionListRightColumn, { fontSize: 6 }]}>
          {strings.totalDuration.toUpperCase()}
        </Text>
      </View>
    );

    const scoreDates = [...scoreCard.dates];
    scoreDates.map(date => {
      const bodyRow =
        scoreCard.dates.length === index
          ? styles.sessionListBottomRow
          : styles.sessionListRow;
      const { duration, spans, deviated } = therapySpan(
        scoreCard.dateGroupData,
        date,
        scoreCard.protocolDuration,
        deviceRef,
        styles,
        isBlackAndWhite,
        patient
      );
      sessionListItems.push(
        <View key={`${uid(date)}-${index}`} style={bodyRow} wrap={false}>
          <View style={styles.sessionListLeftColumn}>
            <Text>{moment(date).format('MMM   DD')}</Text>
          </View>
          <View
            style={[
              styles.sesssionListMiddleColumn,
              { flexDirection: 'row', flexWrap: 1 }
            ]}
          >
            {spans}
          </View>
          <View style={[styles.sessionListRightColumn, { display: 'flex', flexDirection: 'row' }]}>
            <Text>{duration} </Text>
            {deviated ? <View style={{ backgroundColor: isBlackAndWhite ? '#000' : '#FC2E2E', height: 10, width: 10, marginLeft: 10, borderRadius: 50 }} ></View> : null}
          </View>
        </View>
      );
      index++;
      return true;
    });
  } else {
    sessionListItems.push(
      <View
        key={uid(`header-${month}`)}
        style={styles.sessionListHeader}
        fixed
        wrap={false}
      >
        <Text style={[styles.sessionListLeftColumn, { fontSize: 6 }]}>
          {strings.o_date.toUpperCase()}
        </Text>
        <Text style={[styles.sesssionListMiddleColumn, { fontSize: 6 }]}>
          {strings.sessions.toUpperCase()}
        </Text>
        <Text style={[styles.sessionListRightColumn, { fontSize: 6 }]}>
          {strings.totalDuration.toUpperCase()}
        </Text>
      </View>
    );
    sessionListItems.push(
      <Text style={styles.noDataFound} key={uid(`body-${month}`)}>
        {`No session data available for ${moment(month).format('MMM YY')}`}
      </Text>
    );
  }
  return sessionListItems;
}
export function getSessionItems(session, styles, isBlackAndWhite) {
  let sessionItems = [];
  if (session.length) {
    let noData = true;
    sessionItems.push(
      <View
        style={[styles.sessionListHeader, { paddingLeft: '5px' }]}
        fixed
        wrap={false}
        key={uid('head')}
      >
        <Text style={[styles.sessionDateHeading]}>DATE</Text>
        <Text style={[styles.sessionTimeHeading]}>TIME</Text>
        <Text style={[styles.sessionEventHeading]}>EVENT</Text>
        <Text style={[styles.sessionFrequencyHeading]}>FREQUENCY</Text>
        <Text style={[styles.sessionPressureHeading]}>PRESSURE</Text>
        <Text style={[styles.sessionSessionDurHeading]}>SESSION DURATION</Text>
        <Text style={[styles.sessionDeviceHeading]}>DEVICE</Text>
      </View>
    );
    session.forEach(date => {
      if (date.sessions && date.sessions.length) {
        date.sessions.forEach(sessionDate => {
          if (sessionDate.events && sessionDate.events.length) {
            noData = false;
            const dates = [];
            const times = [];
            const events = [];
            const frequencies = [];
            const pressures = [];
            const sessionDurations = [];
            const devices = [];
            for (let j = 0; j < sessionDate.events.length; j++) {
              const dPoint = sessionDate.events[j];
              times.push(
                <Text style={styles.detailsCell}>
                  {moment(parseInt(dPoint.time)).format('LT')}
                </Text>
              );
              j === 0 &&
                dates.push(
                  <Text
                    style={{
                      height: `${25 * sessionDate.events.length -
                        sessionDate.events.length -
                        (sessionDate.events.length / 12 >= 1
                          ? 4 + (sessionDate.events.length % 12)
                          : 0)}`,
                      paddingTop: `${(25 * sessionDate.events.length) / 2.2}`,
                      border: sessionDate.events.length > 1 ? 1 : 0,
                      paddingLeft: 15,
                      paddingRight: 15,
                      borderBottom: 1,
                      borderTop: 0,
                      textAlign: 'center',
                      fontSize: 7,
                      borderColor: isBlackAndWhite ? '#e5e5e5' : '#dce4f1'
                    }}
                    key={uid(j)}
                  >
                    {moment(parseInt(date.date)).format('MMM   DD')}
                  </Text>
                );
              events.push(
                <Text style={styles.detailsCell} key={uid(j)}>
                  {dPoint.name}
                </Text>
              );
              frequencies.push(
                <Text style={styles.detailsCell} key={uid(j)}>
                  {dPoint.frequency}
                </Text>
              );
              pressures.push(
                <Text style={styles.detailsCell} key={j}>
                  {dPoint.pressure}
                </Text>
              );
              j === 0 &&
                sessionDurations.push(
                  <Text
                    style={{
                      height: `${25 * sessionDate.events.length -
                        sessionDate.events.length -
                        (sessionDate.events.length / 12 >= 1
                          ? 4 + (sessionDate.events.length % 12)
                          : 0)}`,
                      paddingTop: `${(25 * sessionDate.events.length) / 2.2}`,
                      border: sessionDate.events.length > 1 ? 1 : 0,
                      paddingLeft: 15,
                      paddingRight: 15,
                      borderBottom: 1,
                      borderTop: 0,
                      textAlign: 'center',
                      fontSize: 7,
                      borderColor: isBlackAndWhite ? '#e5e5e5' : '#dce4f1'
                    }}
                    key={uid(j)}
                  >
                    {sessionDate.duration}
                  </Text>
                );
              j === 0 &&
                devices.push(
                  <Text
                    style={{
                      height: `${25 * sessionDate.events.length -
                        sessionDate.events.length -
                        (sessionDate.events.length / 12 >= 1
                          ? 4 + (sessionDate.events.length % 12)
                          : 0)}`,
                      paddingTop: `${(25 * sessionDate.events.length) / 2.2}`,
                      border: sessionDate.events.length > 1 ? 1 : 0,
                      paddingLeft: 15,
                      paddingRight: 15,
                      borderBottom: 1,
                      borderTop: 0,
                      borderLeft: 0,
                      textAlign: 'center',
                      fontSize: 7,
                      borderColor: isBlackAndWhite ? '#e5e5e5' : '#dce4f1'
                    }}
                    key={uid(j)}
                  >
                    <Image
                      style={{ height: 15, width: 15 }}
                      src={
                        sessionDate.device === 'MONARCH'
                          ? monarchBlackAndWhite
                          : visiVestLogoBlackAndWhite
                      }
                    />
                  </Text>
                );
            }
            sessionItems.push(
              <View
                style={[
                  styles.protocolDetailsRow,
                  {
                    fontFamily: 'Sailec',
                    color: '#000000'
                  }
                ]}
                wrap={false}
              >
                <View style={{ flexDirection: 'column', width: '10%' }}>
                  {dates}
                </View>
                <View style={{ flexDirection: 'column', width: '11%' }}>
                  {times}
                </View>
                <View style={{ flexDirection: 'column', width: '30%' }}>
                  {events}
                </View>
                <View style={{ flexDirection: 'column', width: '11%' }}>
                  {frequencies}
                </View>
                <View style={{ flexDirection: 'column', width: '11%' }}>
                  {pressures}
                </View>
                <View style={{ flexDirection: 'column', width: '14%' }}>
                  {sessionDurations}
                </View>
                <View style={{ flexDirection: 'column', width: '13%' }}>
                  {devices}
                </View>
              </View>
            );
          }
        });
      }
    });
    if (noData) {
      sessionItems = [];
    }
  }
  return sessionItems;
}
export function getDiagnosisCode(diagnosis, styles) {
  let diagnosisCodes = [
    {
      type_code: null,
      type_code_value: null
    }
  ];
  if (diagnosis && !isEmpty(diagnosis)) {
    diagnosisCodes = diagnosis;
  }
  return diagnosisCodes.map(type => {
    return (
      <View style={styles.patientInfo} key={uid(type)}>
        <Text style={styles.key}>{strings.diagnosisCode}: </Text>
        <Text style={styles.value}>
          {type.type_code ? `${type.type_code} ${type.type_code_value}` : '-'}
        </Text>
      </View>
    );
  });
}

export function getProtocolDeviseDetails(
  styles,
  deviceRef,
  dType,
  deviceGroups,
  i,
  isBlackAndWhite,
  patient,
  from,
  to,
  isActive
) {
  const protocolDeviseDetails = [];
  const isManualVest = deviceRef[dType][0] === strings.vest && patient.isManual ? true : false;
  const visiVestmanualLogo = isBlackAndWhite
    ? manualBlackAndWhiteLogo
    : manualLogo;
  const manualDeviceName = patient.deviceName;
  protocolDeviseDetails.push(
    <View key={uid(i)} style={styles.protocolDeviceDetailsHeadings}>
      <View key={`${uid(i)}-image`} style={{ paddingRight: -5 }}>
        <Image
          src={isManualVest ? visiVestmanualLogo : deviceRef[dType][1]}
          style={isManualVest ? { width: '30px', height: '20px' } : { width: '30px', height: '30px' }}
        />
      </View>
      <View key={`${uid(i)}-text`}>
        <Text
          style={
            deviceRef[dType][0] === strings.monarch
              ? styles.monarchText
              : styles.visiVestText
          }
        >
          {'    '} {isManualVest ? manualDeviceName : deviceRef[dType][0]} Daily Protocol {from !== null && to !== null && !isActive && `(Active from ${moment(from).format('MMM DD, Y')} to ${moment(to).format('MMM DD, Y')})`}
          {from !== null && (to === null || isActive) && `(Active since ${moment(from).format('MMM DD, Y')})`}
        </Text>
      </View>
    </View>
  );
  protocolDeviseDetails.push(
    <View key={uid(dType)} style={styles.protocolDetailsRow} fixed>
      <Text style={styles.protocolDetailsLeftHeadCell}>{strings.type}</Text>
      <Text style={styles.treamentHeadCell}>
        {strings.treatmentsPerDay.toUpperCase()}
      </Text>
      <Text style={styles.protocolDetailsHead}>
        {strings.minutesPerTreatment.toUpperCase()}
      </Text>
      <Text style={styles.protocolDetailsHead}>
        {strings.frequencyPerTreatment.toUpperCase()}
      </Text>
      <Text style={styles.protocolDetailsRightHeadCell}>
        {strings.pressurePerTreatment.toUpperCase()}
      </Text>
    </View>
  );
  const deviceGroupData = deviceGroups[dType];
  const types = [];
  const treatmentsPerDay = [];
  const minuts = [];
  const frequencies = [];
  const pressures = [];
  for (let j = 0; j < deviceGroupData.length; j++) {
    const dPoint = deviceGroupData[j];
    types.push(
      <Text
        style={
          j === deviceGroupData.length - 1
            ? styles.protocolDetailsLeftMostCell
            : styles.protocolDetailsBottomLeftCell
        }
        key={uid(j)}
      >
        {isManualVest ? ' - ' : getProtocolTypeLabel(dPoint.type, dPoint.treatmentLabel)}
      </Text>
    );
    j === 0 &&
      treatmentsPerDay.push(
        <Text
          style={{
            height: `${deviceGroupData.length > 1 ? (41 * deviceGroupData.length -
              deviceGroupData.length -
              (deviceGroupData.length / 12 >= 1
                ? 4 + (deviceGroupData.length % 12)
                : 0)) : (42 * deviceGroupData.length -
                  deviceGroupData.length -
                  (deviceGroupData.length / 12 >= 1
                    ? 4 + (deviceGroupData.length % 12)
                    : 0))}`,
            paddingTop: `${(40 * deviceGroupData.length) / 2.2}`,
            border: deviceGroupData.length > 1 ? 1 : 0,
            paddingLeft: 15,
            paddingRight: 15,
            borderBottom: 1,
            borderTop: 0,
            textAlign: 'center',
            fontSize: 7,
            borderColor: isBlackAndWhite ? '#e5e5e5' : '#dce4f1'
          }}
          key={uid(j)}
        >
          {dPoint.treatmentsPerDay}
        </Text>
      );
    minuts.push(
      <Text style={styles.protocolDetailsCell} key={uid(j)}>
        {dPoint.minMinutesPerTreatment} m
      </Text>
    );
    frequencies.push(
      <Text style={styles.protocolDetailsCell} key={uid(j)}>
        {isManualVest ? ' - ' : dPoint.minFrequency}
        {isManualVest ? '' : dPoint.maxFrequency === dPoint.minFrequency || !dPoint.maxFrequency
          ? ''
          : `-${dPoint.maxFrequency}`}
      </Text>
    );
    pressures.push(
      <Text
        style={
          j === deviceGroupData.length - 1
            ? styles.protocolDetailsRightMostCell
            : styles.protocolDetailsBottomRightCell
        }
        key={j}
      >
        {' '}
        {dPoint.minIntensity}
        {dPoint.maxIntensity === dPoint.minIntensity || !dPoint.maxIntensity
          ? ''
          : `-${dPoint.maxIntensity}`}
        {isManualVest ? ' - ' : dPoint.minPressure}
        {isManualVest ? '' : dPoint.maxPressure === dPoint.minPressure || !dPoint.maxPressure
          ? ''
          : `-${dPoint.maxPressure}`}
      </Text>
    );
  }
  protocolDeviseDetails.push(
    <View
      style={[
        styles.protocolDetailsRow,
        {
          fontFamily: 'Sailec',
          color: '#000000'
        }
      ]}
      key={`${uid(dType)}-${i}`}
      wrap={false}
    >
      <View style={{ flexDirection: 'column', width: '20%' }}>{types}</View>
      <View style={{ flexDirection: 'column', width: '20%' }}>
        {treatmentsPerDay}
      </View>
      <View style={{ flexDirection: 'column', width: '20%' }}>{minuts}</View>
      <View style={{ flexDirection: 'column', width: '20%' }}>
        {frequencies}
      </View>
      <View style={{ flexDirection: 'column', width: '20%' }}>{pressures}</View>
    </View>
  );
  return protocolDeviseDetails;
}

export function getStyles(border_color, isBlackAndWhite) {
  const styles = StyleSheet.create({
    barChartBorder: {
      border: 1,
      padding: 15,
      borderRadius: 7,
      borderColor: border_color,
      itemAlignment: 'center',
      marginBottom: 20,
      fontSize: 6
    },
    container: {
      flex: 1,
      '@media max-width: 400': {
        flexDirection: 'column'
      }
    },
    page: {
      padding: 10,
      paddingTop: 60
    },
    monthLabel: {
      color: '#666666',
      fontSize: 5,
      fontWeight: 'bold',
      fontFamily: 'Sailec',
      paddingLeft: 20,
      paddingRight: 14,
    },
    flexRowStyle: {
      paddingLeft: 10,
      paddingRight: 10,
      flexDirection: 'row',
    },
    patientInfo: {
      flexDirection: 'row',
      margin: 3,
      fontSize: 7,
      fontFamily: 'SailecBold'
    },
    pateintDetailsSub: {
      textAlign: 'justify',
      flexDirection: 'row',
      flexGrow: 2
    },
    key: {
      opacity: 0.6,
      padding: 5,
      color: isBlackAndWhite ? '#000000' : '#0d2457'
    },
    value: {
      padding: 5,
      textTransform: 'capitalize'
    },
    spiroSessionListRightColumn: {
      fontSize: 7,
      width: '45%',
      paddingLeft: 100
    },
    spiroSesssionListMiddleHeaderColumn: {
      width: '30%',
      paddingLeft: 30
    },
    spiroSesssionListMiddleColumn: {
      width: '7%',
    },
    spiroSesssionListSecondMiddleColumn: {
      width: '23%',
      paddingTop: 10,
      paddingRight: 50
    },
    spiroSessionListLeftColumn: {
      fontSize: 7,
      width: '25%'
    },
    sessionListLeftColumn: {
      fontSize: 7,
      width: '15%'
    },
    sessionListRightColumn: {
      fontSize: 7,
      width: '13%'
    },
    sesssionListMiddleColumn: {
      width: '72%',
      paddingLeft: 50,
      paddingRight: 50
    },
    patientName: {
      fontSize: 15,
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000000' : '#0d2457',
      margin: 10,
      textTransform: 'capitalize'
    },
    patientNameAlign: {
      fontSize: 15,
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000000' : '#0d2457',
      margin: 10,
      marginLeft: 40
    },
    imageAlign: {
      width: 9,
      height: 9,
      position: 'absolute',
      marginTop: 11,
      marginLeft: 16
    },
    deviceImage: {
      width: '15px',
      height: '15px'
    },

    sessionListHeader: {
      flexDirection: 'row',
      padding: 15,
      border: 1,
      borderTopLeftRadius: 7,
      borderTopRightRadius: 7,
      borderColor: border_color,
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000000' : '#0d2457'
    },
    sessionListRow: {
      flexDirection: 'row',
      padding: 15,
      border: 1,
      borderTop: 0,
      borderColor: border_color
    },
    sessionListBottomRow: {
      flexDirection: 'row',
      padding: 15,
      border: 1,
      borderTop: 0,
      borderBottomLeftRadius: 7,
      borderBottomRightRadius: 7,
      borderColor: border_color
    },
    sessionList: {
      paddingBottom: 20
    },
    sessionListBody: {
      flexDirection: 'row',
      margin: 1,
      fontFamily: 'Sailec'
    },
    monthYear: {
      alignSelf: 'flex-end',
      justifySelf: 'flex-end'
    },
    barChartTitle: {
      paddingBottom: 20,
      flexDirection: 'row',
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000000' : '#0d2457'
    },
    barChartMonthYear: {
      flexDirection: 'column',
      flexGrow: 2,
      alignSelf: 'flex-end',
      justifySelf: 'flex-end'
    },
    protocolDetailsHead: {
      padding: 15,
      width: '20%',
      border: 1,
      borderLeft: 0,
      borderRight: 0,
      borderColor: border_color
    },
    treamentHeadCell: {
      padding: 15,
      width: '20%',
      border: 1,
      borderLeft: 0,
      borderRight: 0,
      borderColor: border_color
    },
    treamentHeadCell1: {
      padding: 15,
      width: '17%',
      border: 1,
      borderLeft: 0,
      borderRight: 0,
      borderColor: border_color
    },
    protocolDetailsLeftHeadCell: {
      padding: 15,
      width: '20%',
      border: 1,
      borderRight: 0,
      borderTopLeftRadius: 7,
      borderColor: border_color
    },
    protocolDetailsRightHeadCell: {
      padding: 15,
      width: '20%',
      border: 1,
      borderLeft: 0,
      borderTopRightRadius: 7,
      borderColor: border_color
    },
    protocolDetailsRow: {
      flexDirection: 'row',
      fontSize: 6,
      color: isBlackAndWhite ? '#000000' : '#0d2457',
      fontFamily: 'SailecBold'
    },
    protocolDetailsCell: {
      padding: 15,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderLeft: 0,
      borderRight: 0,
      borderColor: border_color,
      textAlign: 'center'
    },
    detailsCell: {
      padding: 7,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderLeft: 0,
      borderRight: 0,
      borderColor: border_color,
      textAlign: 'center'
    },
    protocolDetailsLeftMostCell: {
      padding: 15,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderRight: 0,
      borderBottomLeftRadius: 7,
      borderColor: border_color
    },
    protocolDetailsRightMostCell: {
      padding: 15,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderLeft: 0,
      borderBottomRightRadius: 7,
      borderColor: border_color,
      textAlign: 'center'
    },
    protocolDetailsBottomLeftCell: {
      padding: 15,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderRight: 0,
      borderColor: border_color
    },
    protocolDetailsBottomRightCell: {
      padding: 15,
      fontSize: 7,
      border: 1,
      borderTop: 0,
      borderLeft: 0,
      textAlign: 'center',
      borderColor: border_color
    },
    protocolDetails: {
      paddingBottom: 20,
      fontSize: 8
    },
    treatmentsPerDay: {},
    protocolDeviceDetailsHeadings: {
      flexDirection: 'row',
      padding: 10
    },
    visiVestText: {
      fontSize: 9,
      top: 8,
      fontFamily: 'SailecBold',
      fontStyle: 'normal',
      color: isBlackAndWhite ? '#000' : '#659fd5'
    },
    monarchText: {
      fontSize: 9,
      top: 9,
      fontStyle: 'normal',
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000' : '#f26222'
    },
    titanText: {
      fontSize: 9,
      top: 9,
      fontStyle: 'normal',
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000' : '#f26222'
    },

    treatmentPerDayCellForNomal: {
      padding: 15,
      fontSize: 7,
      width: '15%',
      borderBottom: 1,
      borderColor: border_color,
      textAlign: 'center'
    },
    treatmentPerDayCellForCustom: {
      padding: 15,
      fontSize: 7,
      width: '15%',
      border: 1,
      borderTop: 0,
      borderButtom: 0,
      borderColor: border_color,
      textAlign: 'center'
    },
    bulletMonarch: {
      width: '4px',
      height: '4px',
      borderRadius: 2,
      backgroundColor: isBlackAndWhite ? '#000000' : '#f26222',
      top: 0,
      margin: 2
    },
    bulletVisiVest: {
      width: '4px',
      height: '4px',
      borderRadius: 2,
      backgroundColor: isBlackAndWhite ? '#000000' : '#659fd5',
      top: 0,
      margin: 2
    },
    scoreUpperCardText: {
      flexDirection: 'column',
      fontSize: 8,
      flexWrap: 1,
      paddingTop: 5
    },
    spiroScoreUpperCardText: {
      flexDirection: 'column',
      fontSize: 7,
      flexWrap: 1,
      paddingTop: 2
    },
    scoreUpperCardNumber: {
      fontSize: 14,
      marginRight: 8,
      color: isBlackAndWhite ? '#000000' : '#0d2457',
      paddingTop: 8
    },
    spiroScoreUpperCardNumber: {
      fontSize: 9,
      marginRight: 8,
      color: isBlackAndWhite ? '#000000' : '#0d2457',
      paddingTop: 2
    },
    scoreUpperCard: {
      flexDirection: 'row',
      border: 1,
      paddingTop: 9,
      paddingBottom: 9,
      paddingLeft: 9,
      paddingRight: 4,
      margin: 5,
      borderColor: border_color,
      borderRadius: 4,
      width: 102,
      flexWrap: 1,
      position: 'absolute'
    },
    spiroScoreUpperCard: {
      flexDirection: 'row',
      border: 1,
      paddingTop: 9,
      paddingBottom: 9,
      paddingLeft: 9,
      paddingRight: 4,
      margin: 5,
      borderColor: border_color,
      borderRadius: 4,
      width: 70,
      flexWrap: 1,
      position: 'absolute'
    },
    scoreDownCardText: {
      flexDirection: 'column',
      fontSize: 5,
      left: -2,
      top: 4,
      paddingTop: 5
    },
    scoreDownCardNumber: {
      fontSize: 10,
      marginRight: 2,
      paddingTop: 10,
      fontFamily: 'SailecBold',
      color: isBlackAndWhite ? '#000000' : '#0d2457'
    },
    scoreDownCardHeaders: {
      fontSize: 7,
      top: 5,
      left: -7,
      margin: 2,
      fontFamily: 'SailecBold'
    },
    scoreDowncard: {
      flexDirection: 'row',
      border: 1,
      borderRadius: 4,
      paddingTop: 4,
      paddingBottom: 4,
      paddingLeft: 2,
      margin: 3,
      width: 102,
      position: 'absolute',
      borderColor: border_color
    },
    noDataFound: {
      border: 1,
      borderTop: 0,
      borderBottomLeftRadius: 7,
      borderBottomRightRadius: 7,
      borderColor: border_color,
      fontSize: 7,
      padding: 15,
      textAlign: 'center',
      marginDown: 10,
      width: '100%'
    },
    noDataToDisplay: {
      fontSize: 8,
      textAlign: 'center',
      fontFamily: 'Sailec'
    },
    sessionDateHeading: {
      fontSize: 6,
      width: '10%',
      paddingLeft: '12px'
    },
    sessionTimeHeading: {
      fontSize: 6,
      width: '11%',
      paddingLeft: '18px'
    },
    sessionEventHeading: {
      fontSize: 6,
      width: '30%',
      paddingLeft: '75px'
    },
    sessionFrequencyHeading: {
      fontSize: 6,
      width: '12%',
      paddingLeft: '21px'
    },
    sessionPressureHeading: {
      fontSize: 6,
      width: '11%',
      paddingLeft: '20px'
    },
    sessionSessionDurHeading: {
      fontSize: 6,
      width: '14%',
      paddingLeft: '15px'
    },
    sessionDeviceHeading: {
      fontSize: 6,
      width: '12%',
      paddingLeft: '30px'
    },
    label: {
      width: '200px',
      height: '20px',
      fontFamily: 'Sailec',
      fontSize: 7,
      fontWeight: 'bold',
      color: '#757575'
    },
    content: {
      width: '200px',
      height: '30px',
      borderRadius: 4,
      border: 1,
      paddingTop: '10px',
      paddingLeft: '10px',
      borderColor: '#dedede',
      fontFamily: 'Sailec',
      fontSize: 9,
      fontWeight: 500,
      color: '#3d3d3d'
    },
    heading: {
      width: '118px',
      height: '25px',
      fontFamily: 'Sailec',
      fontSize: 12,
      fontWeight: 500,
      color: '#201547'
    },
    headingCell: {
      fontSize: 9,
      fontWeight: 'bold',
      fontFamily: 'Sailec',
      marginTop: '2px'
    },
    date: {
      fontFamily: 'Sailec',
      fontSize: 10,
      fontWeight: 500,
      color: '#3d3d3d'
    },
  });
  return styles;
}

export function getClinics(pClinics, styles) {
  let clinics = [];
  if (pClinics) {
    clinics = pClinics.map(eachClinic => {
      return (
        <View key={uid(eachClinic)} style={styles.patientInfo} wrap={false}>
          <Text style={styles.key}>{strings.clinicId}: </Text>
          <Text style={styles.value}>{eachClinic.hillromId || '-'}</Text>
          <Text style={styles.key}>{strings.clinic}: </Text>
          <Text style={styles.value}>
            {eachClinic.name ? eachClinic.name : '-'}
          </Text>
        </View>
      );
    });
  } else {
    clinics.push(
      <View key={uid(1)} style={styles.patientInfo} wrap={false}>
        <Text style={styles.key}>{strings.clinicId}: </Text>
        <Text style={styles.value}>-</Text>
        <Text style={styles.key}>{strings.clinic}: </Text>
        <Text style={styles.value}>-</Text>
      </View>
    );
  }
  return clinics;
}

export function getProviders(pProviders, styles) {
  let providers = [];
  if (pProviders) {
    providers = pProviders.map(provider => {
      const fullName = [
        provider.firstName,
        provider.middleName,
        provider.lastName
      ]
        .filter(Boolean)
        .join(' ');
      return (
        <View key={uid(provider.id)} style={styles.patientInfo} wrap={false}>
          <Text style={styles.key}>{strings.Provider}: </Text>
          <Text style={styles.value}>{fullName}</Text>
        </View>
      );
    });
  } else {
    providers.push(
      <View key={uid(1)} style={styles.patientInfo} wrap={false}>
        <Text style={styles.key}>{strings.provider}: </Text>
        <Text style={styles.value}>-</Text>
      </View>
    );
  }
  return providers;
}
