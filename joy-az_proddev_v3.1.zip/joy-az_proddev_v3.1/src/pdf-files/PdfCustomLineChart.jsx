import React, { Component } from 'react';
import { Line } from 'components/Chart.js';
import { isEmpty } from 'lodash';

class PdfCustomLineChart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            url: ''
        };
        this.lineChartRef = React.createRef();
        this.getChartURL = this.getChartURL.bind(this);
    }

    getChartURL = () => {
        return this.lineChartRef;
    };

    render() {
        return (
            <Line
                id={`line-chart-${this.props.idx}`}
                height={60}
                data={!isEmpty(this.props.scoreCard) ? this.props.scoreCard.data : []}
                options={!isEmpty(this.props.scoreCard) ? this.props.scoreCard.options : []}
                ref={this.lineChartRef}
                style={{ display: 'none' }}
            />
        )
    }
}

export default PdfCustomLineChart;
