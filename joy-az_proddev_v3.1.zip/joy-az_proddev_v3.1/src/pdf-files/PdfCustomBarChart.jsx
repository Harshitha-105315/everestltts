import React, { Component } from 'react';
import { Bar } from 'components/Chart.js';

class PdfCustomBarChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      url: ''
    };
    this.barChartRef = React.createRef();
    this.getChartURL = this.getChartURL.bind(this);
  }

  getChartURL = () => {
    return this.barChartRef;
  };

  render() {
    return (
      <Bar
        id={`bar-chart-${this.props.idx}`}
        height={60}
        data={this.props.scoreCard.data}
        options={this.props.scoreCard.options}
        ref={this.barChartRef}
        style={{ display: 'none' }}
      />
    )
  }
}

export default PdfCustomBarChart;
