import { put, call } from 'redux-saga/effects';
import _ from 'lodash';
import constants from 'constants.js';
import strings from 'localization/strings';
import EditDeviceService from './services';

function* fetchEditDeviceInfo(action) {
  const patientID = action.data.id;
  const deviceType = action.data.device;
  const serial = action.data.serialno;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const deviceFinds = yield call(
      EditDeviceService.getDeviceInformation,
      patientID,
      deviceType,
      serial
    );
    const deviceFind = _.find(deviceFinds.data.deviceList, function (device) {
      return device.serialNumber === serial.trim();
    });

    if (
      deviceFinds &&
      (deviceFinds.status === 200 || deviceFinds.status === 201)
    ) {
      yield put({
        type: constants.DEVICE.STORE_EDIT_DEVICE,
        data: deviceFind,
        key: serial
      });
    } else {
      throw Object({
        custom_message: deviceFinds.data.ERROR || deviceFinds.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* addDeviceRequest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { history, path, data } = action.allData;
    const response = yield call(EditDeviceService.addDevice, data);
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* editDeviceRequest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const patientID = action.id;
    const response = yield call(
      EditDeviceService.editDevice,
      action.data,
      patientID
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.message
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const EditDeviceAction = {
  fetchEditDeviceInfo,
  addDeviceRequest,
  editDeviceRequest
};

export default EditDeviceAction;
