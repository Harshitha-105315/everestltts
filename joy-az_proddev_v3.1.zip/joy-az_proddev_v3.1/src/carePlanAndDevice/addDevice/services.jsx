import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function getDeviceInformation(patientID, deviceType) {
  const url = API.PROTOCOLDEVICEINFO.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}?deviceType=${deviceType}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function addDevice(payload) {
  const patientID = payload.id;
  const deviceValue = payload.deviceSelect;
  const deviceType = payload.patient.deviceType
  const url = API.ADDDEVICEREQUEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}?deviceType=${deviceType}&deviceValue=${deviceValue}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: JSON.stringify({
      serialNumber: payload.serialNumber,
      bluetoothId: payload.bluetoothId,
      wifiId: payload.lteId,
      hubId: payload.hubId,
      isByod: payload.isByod
    }),
    [constants.RETURNRESPONSE]: true
  });
}

function editDevice(payload, patientID) {
  const deviceValue = payload.deviceType;
  const url = API.EDITDEVICEREQUEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}?deviceType=ALL&deviceValue=${deviceValue}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}
const EditDeviceService = {
  getDeviceInformation,
  addDevice,
  editDevice
};

export default EditDeviceService;
