/* eslint-disable react/destructuring-assignment */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';
import { Form, Col } from 'react-bootstrap';
import constants from 'constants.js';
import { Header, SideBar } from 'components/Navigation';
import strings from 'localization/strings';
import ConfirmationDialog from 'components/ConfirmationDialog';
import urls from 'urls';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { FootNote } from 'components/FootNote';
import ButtonComponent from 'components/ButtonComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import Switch from 'components/Switch';
import {
  getBreadCrumb,
  addBreadCrumb,
  removeBreadCrumb
} from '../../utils/utltity';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData } from 'utils/helper';
import { getDeviceTypeText } from 'patient/helper';

class EditDevice extends Component {
  constructor(props) {
    super(props);

    this.state = {
      serialNumber: '',
      bluetoothId: '',
      lteId: '',
      hubId: '',
      wifiId: '',
      deviceType: '',
      isByod: null,
      byodState: null,
      optOutReason: null,
      optOutFeedback: null,
      error: '',
      edit: true,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeWifi = this.handleChangeWifi.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.onByodDeviceStateChange = this.onByodDeviceStateChange.bind(this);

    this.exempt = [
      'dialog',
      'isDirty',
      'error',
      'edit'
    ]
  }

  componentWillMount() {
    const { match } = this.props;
    const { id, devicetype, serialno } = match.params;
    this.getDeviceInfo(id, devicetype, serialno);
  }

  componentDidMount() {
    this.addBreadCrumb({ title: strings.editDevice });
  }

  componentWillReceiveProps(newProps) {
    const { deviceFind } = newProps;
    if (deviceFind !== undefined) {
      this.setState(deviceFind);
    }
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
    this.removeBreadCrumb();
  }

  getDeviceInfo = (id, devicetype, serialno) => {
    const { dispatch } = this.props;

    dispatch({
      type: constants.DEVICE.FETCH_EDIT_DEVICES_INFO,
      data: { device: devicetype, id, serialno }
    });
  };

  handleChange = evt => {
    this.setState({
      [evt.target.name]: evt.target.value,
      isDirty: true
    });
  };

  handleChangeWifi = evt => {
    this.setState({
      [evt.target.name]: evt.target.value,
      lteId: evt.target.value,
      isDirty: true
    });
  };

  handleUpdate = e => {
    const { match } = this.props;
    const { devicetype } = match.params;
    const { serialNumber, bluetoothId, lteId, hubId, isByod } = this.state;
    this.setState({ error: '' });
    let flag = true;

    if (devicetype === constants.DEVICE_TYPE_CODE.MONARCH && isByod === false) {
      if (lteId === '') {
        this.setState({ error: `${strings.wifiIdRequired}` });
        flag = false;
      }
    }
    if (devicetype === constants.DEVICE_TYPE_CODE.VISIVEST) {
      if (isByod === true && bluetoothId === '') {
        this.setState({ error: `${strings.bluetoothIdRequired}` });
        flag = false;
      }
      if (isByod === false && hubId === '') {
        this.setState({ error: `${strings.hubIdRequired}` });
        flag = false;
      }
    }
    if (serialNumber === '') {
      this.setState({ error: `${strings.serialNumberRequired}` });
      flag = false;
    }
    if (flag) {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          title: strings.updateDevice,
          button: strings.update,
          body: strings.editDeviceDialogBody,
          confirmFunction: this.handleUpdateDispatch,
          show: true
        })
      });
    }
  };

  handleUpdateDispatch = () => {
    const { dispatch } = this.props;
    const { match } = this.props;
    const { id } = match.params;
    const { dialog } = this.state;
    const payload = { ...this.state };
    this.exempt.forEach(element => {
      delete payload[element];
    });

    dispatch({
      type: constants.DEVICE.EDIT_DEVICE_REQUEST,
      data: payload,
      id
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  handleCancelDevice = e => {
    const { history } = this.props;
    const { match } = this.props;
    const { id } = match.params;
    e.preventDefault();
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  onByodStatusChange = (event) => {
    this.setState({ byodState: event.target.value, isDirty: true });
  }

  onByodDeviceStateChange = () => {
    const { byodState } = this.props.deviceFind;
    const stateByodState = this.state.byodState;
    if (constants.BYOD_ENABLE_STATES[byodState]) {
      if (constants.BYOD_ENABLE_STATES[stateByodState]) {
        this.setState({ byodState: constants.BYOD_DISABLE_STATES.OPT_OUT_REQUESTED });
      } else {
        this.setState({ byodState });
      }
    } else {
      if (constants.BYOD_ENABLE_STATES[stateByodState]) {
        this.setState({ byodState });
      } else {
        this.setState({ byodState: constants.BYOD_ENABLE_STATES.NOT_PAIRED });
      }
    }
  }

  render() {
    const {
      serialNumber,
      deviceType,
      bluetoothId,
      lteId,
      hubId,
      wifiId,
      error,
      dialog,
      isByod,
      byodState,
      optOutReason,
      optOutFeedback
    } = this.state;
    const { match, breadcrumbs, location, history } = this.props;
    const { devicetype, serialno, id } = match.params;

    const sideBarData = {
      activeKey: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };

    const { actualRole } = getUserData();
    const deviceInformation = accessMatrix.PATIENT_DEVICE_INFORMATION[actualRole];
    const byodDeviceInformation = accessMatrix.PATIENT_DEVICE_BYOD[actualRole];

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {this.getBreadCrumb(breadcrumbs)}
            <h2>{strings.editDevice}</h2>
            <div>
              <Form>
                {!_.isUndefined(serialno) && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.selectDevice} <span className="asterisk-color">*</span></Form.Label>
                      <Form.Control
                        name="deviceType"
                        defaultValue={getDeviceTypeText(deviceType)}
                        disabled="disabled"
                        required
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.serialNo} <span className="asterisk-color">*</span></Form.Label>
                    <Form.Control
                      type="text"
                      name="serialNumber"
                      defaultValue={serialNumber}
                      onChange={e => this.handleChange(e)}
                      required
                      maxLength="254"
                      disabled={!deviceInformation.write}
                    />
                  </Form.Group>
                </Form.Row>
                {devicetype === constants.DEVICE_TYPE_CODE.VISIVEST && isByod === true && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.bluetoothId} <span className="asterisk-color">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="bluetoothId"
                        defaultValue={bluetoothId}
                        onChange={e => this.handleChange(e)}
                        required
                        maxLength="254"
                        disabled={!deviceInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                {devicetype === constants.DEVICE_TYPE_CODE.MONARCH && isByod === false && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.Wifi} <span className="asterisk-color">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="wifiId"
                        defaultValue={lteId || wifiId}
                        onChange={e => this.handleChangeWifi(e)}
                        required
                        maxLength="254"
                        disabled={!deviceInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                {devicetype === constants.DEVICE_TYPE_CODE.VISIVEST && isByod === false && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.hubId} <span className="asterisk-color">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        required
                        name="hubId"
                        defaultValue={hubId}
                        onChange={e => this.handleChange(e)}
                        maxLength="254"
                        disabled={!deviceInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                {/* {
                  isByod && byodDeviceInformation.write && (
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label htmlFor="byod-switch">{strings.byodOptOut}</Form.Label>
                        <Switch
                          id="byod-switch"
                          value=""
                          handleChange={this.onByodDeviceStateChange}
                          isChecked={constants.BYOD_DISABLE_STATES[byodState]}
                        />
                      </Form.Group>
                    </Form.Row>
                  )
                } */}
                {
                  isByod && byodDeviceInformation.write && (
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>
                          {strings.byodConnectivityStatus}
                        </Form.Label>
                        <Form.Control
                          name="deviceType"
                          value={strings.byodStatesLabel[byodState]}
                          disabled
                        />
                      </Form.Group>
                    </Form.Row>
                  )
                }
                {
                  isByod && byodDeviceInformation.write && (
                    <Form.Row>
                      <Form.Group as={Col} md={5}>
                        <Form.Label>
                          {strings.optOutReason}
                        </Form.Label>
                        <Form.Control
                          name="deviceType"
                          value={optOutReason}
                          disabled
                        />
                      </Form.Group>
                    </Form.Row>
                  )}
                {
                  isByod && byodDeviceInformation.write && (
                    <Form.Row>
                      <Form.Group as={Col} md={8}>
                        <Form.Label>
                          {strings.optOutFeedback}
                        </Form.Label>
                        <Form.Control
                          name="deviceType"
                          as="textarea"
                          value={optOutFeedback}
                          disabled
                        />
                      </Form.Group>
                    </Form.Row>
                  )}
                <p id="error" className="text-danger">
                  {error}
                </p>

                <ButtonComponent
                  buttonClass="float-right ml-4"
                  buttonAction={e => this.handleUpdate(e)}
                  icon="right-arrow"
                  buttonText={strings.update}
                />
                <ButtonComponent
                  buttonClass="float-right"
                  buttonAction={this.handleCancelDevice}
                  icon="cancel-icon"
                  buttonText={strings.cancel}
                />
              </Form>
            </div>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { EditDeviceReducer, breadcrumbsReducer } = state.app;
  const { match } = ownProps;
  const { serialno } = match.params;
  return {
    deviceFind: EditDeviceReducer.deviceFinds[serialno],
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};

export default connect(mapStateToProps)(EditDevice);
