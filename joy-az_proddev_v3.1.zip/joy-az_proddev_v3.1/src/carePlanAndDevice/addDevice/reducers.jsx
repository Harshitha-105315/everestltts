import constants from 'constants.js';
import { setStateByKey } from 'utils/helper.js';

const initialState = {
  deviceFinds: {
    deviceType: '',
    serialNumber: '',
    bluetoothId: '',
    wifiId: '',
    hubId: ''
  }
};

function EditDeviceReducer(state = initialState, action) {
  const tmpState = Object.assign({}, state);

  if (action.type === constants.DEVICE.STORE_EDIT_DEVICE) {
    tmpState.deviceFinds = setStateByKey(
      tmpState.deviceFinds,
      action.key,
      action.data
    );
    return tmpState;
  }

  return state;
}
export default EditDeviceReducer;
