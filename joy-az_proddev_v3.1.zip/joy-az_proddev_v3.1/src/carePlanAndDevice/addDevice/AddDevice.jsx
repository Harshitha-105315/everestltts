/* eslint-disable react/destructuring-assignment */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import constants from 'constants.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import ConfirmationDialog from 'components/ConfirmationDialog';
import { Header, SideBar } from 'components/Navigation';
import strings from 'localization/strings';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { FootNote } from 'components/FootNote';
import ButtonComponent from 'components/ButtonComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import Switch from 'components/Switch';
import {
  getBreadCrumb,
  addBreadCrumb,
  removeBreadCrumb
} from '../../utils/utltity';
import { getDeviceTypeText } from 'patient/helper';

class AddDevice extends Component {
  constructor(props) {
    super(props);
    this.state = {
      deviceSelect: '',
      serialNumber: '',
      bluetoothId: '',
      lteId: '',
      hubId: '',
      error: '',
      isDirty: false,
      isByod: false,
      byodState: null,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleChange = this.handleChange.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
  }

  componentDidMount() {
    const { match, dispatch } = this.props;
    const { id } = match.params;
    this.addBreadCrumb({ title: strings.addDevice });
    dispatch({
      type: constants.PATIENT.FETCH_PATIENT_DATA,
      data: { id }
    })
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
    this.removeBreadCrumb();
  }

  getDeviceInfo = (id, devicetype, serialNo) => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.DEVICE.FETCH_EDIT_DEVICES_INFO,
      data: { device: devicetype, id, serialNo }
    });
  };

  handleChange = evt => {
    this.setState({ [evt.target.name]: evt.target.value, isDirty: true });
  };

  handleSelectChange = event => {
    this.setState({
      deviceSelect: event.target.value,
      serialNumber: '',
      bluetoothId: '',
      lteId: '',
      hubId: '',
      error: '',
      isDirty: true
    });
  };

  handleSave = e => {
    const { deviceSelect, serialNumber, bluetoothId, lteId, hubId, isByod } = this.state;
    this.setState({ error: '' });
    let flag = true;
    if (deviceSelect === constants.DEVICE_TYPE_CODE.MONARCH && isByod === false) {
      if (lteId === '') {
        this.setState({ error: `${strings.wifiIdRequired}` });
        flag = false;
      }
    }
    if (deviceSelect === constants.DEVICE_TYPE_CODE.TITAN && isByod === false) {
      if (lteId === '') {
        this.setState({ error: `${strings.wifiapxIdRequired}` });
        flag = false;
      }
    }
    if (deviceSelect === constants.DEVICE_TYPE_CODE.VISIVEST) {
      if (isByod === true && bluetoothId === '') {
        this.setState({ error: `${strings.bluetoothIdRequired}` });
        flag = false;
      }
      if (isByod === false && hubId === '') {
        this.setState({ error: `${strings.hubIdRequired}` });
        flag = false;
      }
    }
    if (serialNumber === '') {
      this.setState({ error: `${strings.serialNumberRequired}` });
      flag = false;
    }
    if (deviceSelect === '') {
      this.setState({ error: `${strings.selectDeviceType}` });
      flag = false;
    }
    if (flag) {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          title: strings.addDevice,
          button: strings.save,
          body: strings.addDeviceDialogBody,
          confirmFunction: this.addDeviceDispatch,
          show: true
        })
      });
    }
  };

  addDeviceDispatch = e => {
    const { match, dispatch, history, patient } = this.props;
    const { id } = match.params;
    const {
      deviceSelect,
      serialNumber,
      bluetoothId,
      lteId,
      hubId,
      isByod,
      dialog
    } = this.state;
    let data;
    if (deviceSelect === constants.DEVICE_TYPE_CODE.VISIVEST) {
      if (isByod) {
        data = { id, deviceSelect, serialNumber, bluetoothId, isByod, patient };
      } else {
        data = { id, deviceSelect, serialNumber, hubId, isByod, patient };
      }
    } else {
      if (isByod) {
        data = { id, deviceSelect, serialNumber, isByod, patient };
      } else {
        data = { id, deviceSelect, serialNumber, lteId, isByod, patient };
      }
    }
    dispatch({
      type: constants.DEVICE.ADD_DEVICE_REQUEST,
      allData: {
        data,
        history,
        path: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id })
      }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });

    e.preventDefault();
  };

  handleCancelDevice = e => {
    const { history, match } = this.props;
    const { id } = match.params;
    e.preventDefault();
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  onByodDeviceChange = () => {
    this.setState(prevState => {
      let changeObj = {};
      if (prevState.isByod) {
        changeObj.hubId = '';
        changeObj.lteId = '';
      } else {
        changeObj.bluetoothId = '';
      }
      return { isByod: !prevState.isByod, ...changeObj, isDirty: true };
    });
  }

  render() {
    const { match, breadcrumbs, location, history, patient } = this.props;
    const { id } = match.params;
    const {
      deviceSelect,
      serialNumber,
      bluetoothId,
      lteId,
      hubId,
      error,
      dialog,
      isByod
    } = this.state;
    const sideBarData = {
      activeKey: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {this.getBreadCrumb(breadcrumbs)}
            <h2>{strings.addDevice}</h2>
            <div>
              <Form>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="addProtocol">
                      {strings.selectDevice} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      className="custom-select"
                      as="select"
                      name="type"
                      defaultValue={getDeviceTypeText(deviceSelect)}
                      onChange={this.handleSelectChange}
                      required=""
                    >
                      <option value="">Select device</option>
                      <option value="MONARCH">{strings.monarch}</option>
                      <option value="TITAN">{strings.titan}</option>
                      {patient.isManual ? "" : <option value="VEST">{strings.vest}</option>}
                    </Form.Control>
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="add">{strings.serialNo} <span className="asterisk-color">*</span> </Form.Label>
                    <Form.Control
                      type="text"
                      name="serialNumber"
                      value={serialNumber}
                      onChange={this.handleChange}
                      required
                      maxLength="254"
                    />
                  </Form.Group>
                </Form.Row>

                {/* <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="byod-switch">{strings.byodEnabled}</Form.Label>
                    <Switch
                      id="byod-switch"
                      value=""
                      handleChange={this.onByodDeviceChange}
                      isChecked={isByod === true}
                    />
                  </Form.Group>
                </Form.Row> */}

                {deviceSelect === constants.DEVICE_TYPE_CODE.VISIVEST && isByod === true && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label htmlFor="add">
                        {strings.bluetoothId} <span className="asterisk-color">*</span>
                      </Form.Label>
                      <Form.Control
                        type="text"
                        name="bluetoothId"
                        defaultValue={bluetoothId}
                        onChange={this.handleChange}
                        required
                        maxLength="254"
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                {deviceSelect === constants.DEVICE_TYPE_CODE.MONARCH && isByod === false && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label htmlFor="add">{strings.Wifi} <span className="asterisk-color">*</span> </Form.Label>
                      <Form.Control
                        type="text"
                        name="lteId"
                        defaultValue={lteId}
                        onChange={this.handleChange}
                        required
                        maxLength="254"
                      />
                    </Form.Group>
                  </Form.Row>
                )}

                {deviceSelect === constants.DEVICE_TYPE_CODE.TITAN && isByod === false && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label htmlFor="add">{strings.Wifiapx} <span className="asterisk-color">*</span> </Form.Label>
                      <Form.Control
                        type="text"
                        name="lteId"
                        defaultValue={lteId}
                        onChange={this.handleChange}
                        required
                        maxLength="254"
                      />
                    </Form.Group>
                  </Form.Row>
                )}

                {deviceSelect === constants.DEVICE_TYPE_CODE.VISIVEST && isByod === false && (
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label htmlFor="add">{strings.hubId} <span className="asterisk-color">*</span> </Form.Label>
                      <Form.Control
                        type="text"
                        required
                        name="hubId"
                        defaultValue={hubId}
                        onChange={this.handleChange}
                        maxLength="254"
                      />
                    </Form.Group>
                  </Form.Row>
                )}
                <p id="error" className="text-danger">
                  {error}
                </p>
                <ButtonComponent
                  buttonClass="float-right ml-4"
                  buttonAction={e => this.handleSave(e)}
                  icon="right-arrow"
                  buttonText={strings.save}
                />
                <ButtonComponent
                  buttonClass="float-right"
                  buttonAction={this.handleCancelDevice}
                  icon="cancel-icon"
                  buttonText={strings.cancel}
                />
              </Form>
            </div>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { breadcrumbsReducer, patient } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    patient: patient.pData[id] || {}
  };
};

export default connect(mapStateToProps)(AddDevice);
