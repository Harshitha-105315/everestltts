import React from 'react';

class CustomToggle extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(e) {
    const { onClick } = this.props;
    e.preventDefault();
    onClick(e);
  }

  render() {
    const { children } = this.props;
    return (
      <a href="#!" onClick={this.handleClick}>
        {children}
      </a>
    );
  }
}

export default CustomToggle;
