import strings from 'localization/strings';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import urls from 'urls';
import { reverse } from 'named-urls';
import { isEmpty } from 'lodash';
import trash from 'assets/icn-delete.svg';
import edit from 'assets/edit.svg';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import './DeviceInformationList.scss';
import { uid } from 'react-uid';

class DeviceInformationList extends Component {
  renderMobile() {
    const {
      deviceInfo,
      deviceRef,
      newDeviceInfo,
      getTotalHmr,
      getActiveDate
    } = this.props;
    return !isEmpty(deviceInfo.deviceList) ? (
      Object.keys(newDeviceInfo).map(key =>
        newDeviceInfo[key].map(device => (
          <div key={uid(device)}>
            <div
              className={`mt-4 mb-1 d-block d-sm-none mobile-device-name ${
                deviceRef[device.deviceType][2]
                }-logo-text`}
            >
              <img
                src={deviceRef[device.deviceType][1]}
                width="32"
                height="32"
                className="d-inline-block device-logo"
                alt={deviceRef[device.deviceType][0]}
              />
              {deviceRef[device.deviceType][0]}
            </div>

            <div className="mobile-device-table">
              <div className="d-flex device-line-item">
                <div>{strings.serialNumber}</div>
                <div className={device.active !== true ? 'inactive-data' : ''}>
                  {device.serialNumber}
                </div>
              </div>
              <div className="d-flex device-line-item">
                <div>{strings.conectivityId}</div>
                <div className={device.active !== true ? 'inactive-data' : ''}>
                  {device.deviceType === 'VEST'
                    ? device.bluetoothId
                    : device.lteId || device.wifiId}
                </div>
              </div>
              <div className="d-flex device-line-item">
                <div>{strings.status}</div>
                <div className={device.active !== true ? 'inactive-data' : ''}>
                  {device.active ? 'Active' : 'Inactive'}
                </div>
              </div>
              <div className="d-flex device-line-item">
                <div>{strings.deviceHMR}</div>
                <div className={device.active !== true ? 'inactive-data' : ''}>
                  {getTotalHmr(device.hmr)}
                </div>
              </div>
              <div className="d-flex device-line-item">
                <div>{strings.activeOrInactive}</div>
                <div className={device.active !== true ? 'inactive-data' : ''}>
                  {getActiveDate(device.createdDate)}
                </div>
              </div>
            </div>
          </div>
        ))
      )
    ) : (
        <p>{strings.noDeviceAssociated}</p>
      );
  }

  render() {
    const {
      patientID,
      deviceInfo,
      deviceRef,
      newDeviceInfo,
      canUpdate,
      canDelete,
      handleDeviceRemove,
      getTotalHmr,
      getActiveDate,
      addBreadCrumb,
      isMobile
    } = this.props;
    if (isMobile) {
      return this.renderMobile();
    }
    return (
      <div className="card">
        <table className="table text-center">
          <thead>
            <tr>
              <th> {strings.deviceType}</th>
              <th> {strings.serialNumber}</th>
              <th> {strings.conectivityId}</th>
              <th> {strings.status}</th>
              <th> {strings.totalHMR}</th>
              <th> {strings.activeOrInactive}</th>
              {(canUpdate || canDelete) && <th>{strings.options}</th>}
            </tr>
          </thead>
          <tbody>
            {!isEmpty(deviceInfo.deviceList) ? (
              Object.keys(newDeviceInfo).map(key =>
                newDeviceInfo[key].map((device, index) => (
                  <tr
                    key={Number(index)}
                    className={device.active !== true ? 'inactive-data' : ''}
                  >
                    <td>
                      {
                        device.isManual ?
                          <img
                            src={manualLogo}
                            weight="32"
                            alt={'Manual Device'}
                          />
                          :
                          <img
                            src={deviceRef[device.deviceType][1]}
                            width="32"
                            height="32"
                            alt={deviceRef[device.deviceType][0]}
                          />
                      }
                    </td>

                    <td className="align-middle">{device.isManual ? device.name : device.serialNumber}</td>

                    {device.deviceType === 'VEST' ? (
                      <td className="align-middle">{device.bluetoothId}</td>
                    ) : (
                        <td className="align-middle">
                          {device.lteId || device.wifiId}
                        </td>
                      )}
                    <td className="align-middle">
                      {device.active ? 'Active' : 'Inactive'}
                    </td>
                    <td className="align-middle">{getTotalHmr(device.hmr)}</td>
                    <td className="align-middle">
                      {getActiveDate(device.active ? device.createdDate : device.lastModifiedDate)}
                    </td>
                    <td className="align-middle">
                      {device.active && canUpdate && !(device.isManual) && (
                        <Link
                          to={reverse(
                            urls.PATIENT.DETAIL.CAREPLANDEVICE.DEVICE.EDIT,
                            {
                              id: patientID,
                              devicetype: device.deviceType,
                              serialno: device.serialNumber
                            }
                          )}
                          onClick={() => {
                            addBreadCrumb({
                              title: strings.editDevice
                            });
                          }}
                        >
                          <input
                            type="image"
                            src={edit}
                            style={{ marginRight: '0.3rem' }}
                            width="14"
                            height="14"
                            className="d-inline-block"
                            alt="edit"
                          />
                        </Link>
                      )}

                      {device.active && canDelete && !(device.isManual) && (
                        <input
                          type="image"
                          src={trash}
                          style={{ marginRight: '0.3rem' }}
                          width="14"
                          height="14"
                          alt="delete"
                          onClick={e =>
                            handleDeviceRemove(
                              e,
                              device.deviceType,
                              device.serialNumber
                            )
                          }
                        />
                      )}
                    </td>
                  </tr>
                ))
              )
            ) : (
                <tr>
                  <td colSpan="7" className="text-center">
                    {strings.noDeviceAssociated}
                  </td>
                </tr>
              )}
          </tbody>
        </table>
      </div>
    );
  }
}

export default DeviceInformationList;
