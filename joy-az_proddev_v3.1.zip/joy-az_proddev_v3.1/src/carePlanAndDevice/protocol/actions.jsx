import { put, call } from 'redux-saga/effects';
import constants from 'constants.js';
import ProtocolDevice from './services';
import strings from 'localization/strings';

function* fetchDevice(action) {
  const patientID = action.data.id;
  const deviceType = action.data.device;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const protocols = yield call(
      ProtocolDevice.getProtocolDevice,
      patientID,
      deviceType
    );

    if (protocols && (protocols.status === 200 || protocols.status === 201)) {
      yield put({
        type: constants.DEVICE.STORE_PROTOCOL,
        data: protocols.data,
        key: patientID
      });
    } else {
      throw Object({
        custom_message: protocols.data.ERROR || protocols.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
    yield put({
      type: constants.ALERT.HANDLE_SCROLLING,
      response: { isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchDeviceInfo(action) {
  const patientID = action.data.id;
  const deviceType = action.data.device;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const deviceInfo = yield call(
      ProtocolDevice.getDeviceInformation,
      patientID,
      deviceType
    );
    if (
      deviceInfo &&
      (deviceInfo.status === 200 || deviceInfo.status === 201)
    ) {
      yield put({
        type: constants.DEVICE.STORE_DEVICE_INFO,
        data: deviceInfo.data,
        key: patientID
      });
    } else {
      throw Object({
        custom_message: deviceInfo.data.ERROR || deviceInfo.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
    yield put({
      type: constants.ALERT.HANDLE_SCROLLING,
      response: { isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* adherenceResetHistory(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const adherenceHistory = yield call(
      ProtocolDevice.getAdherenceResetHistory,
      action.data
    );

    if (
      adherenceHistory &&
      (adherenceHistory.status === 200 || adherenceHistory.status === 201)
    ) {
      yield put({
        type: constants.DEVICE.STORE_ADHERENCE_RESET_HISTORY,
        data: adherenceHistory.data,
        key: action.data.id
      });
    } else {
      throw Object({
        custom_message:
          adherenceHistory.data.ERROR || adherenceHistory.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
    yield put({
      type: constants.ALERT.HANDLE_SCROLLING,
      response: { isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getPatientAction(action) {
  const patientID = action.data.id;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const PatientData = yield call(ProtocolDevice.getPatientService, patientID);

    if (
      PatientData &&
      (PatientData.status === 200 || PatientData.status === 201)
    ) {
      yield put({
        type: constants.DEVICE.STORE_PATIENT_DATA,
        data: PatientData.data,
        key: patientID
      });
    } else {
      throw Object({
        custom_message: PatientData.data.ERROR || PatientData.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
    yield put({
      type: constants.ALERT.HANDLE_SCROLLING,
      response: { isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* deleteDeviceRequest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const patientID = action.data.id;
    const deviceType = action.data.devicetype;
    const serialNumber = action.data.serialNo;
    const response = yield call(
      ProtocolDevice.deleteDeviceService,
      patientID,
      deviceType,
      serialNumber
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.DEVICE.FETCH_DEVICE_INFO,
        data: { device: 'ALL', id: patientID }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchProtocolOverview(action) {
  const patientID = action.data.id;
  const deviceType = action.data.deviceTypes;
  yield put({
    type: constants.DEVICE.FETCH_PROTOCOL,
    data: { device: deviceType, id: patientID }
  });
  yield put({
    type: constants.DEVICE.FETCH_DEVICE_INFO,
    data: { device: deviceType, id: patientID }
  });
  yield put({ type: constants.DEVICE.JUSTIFICATION_RESET });
  yield put({
    type: constants.DEVICE.PATIENT_DATA,
    data: { id: patientID }
  });
}

function* resetAdherence(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, perPage } = action.data;
    const response = yield call(
      ProtocolDevice.resetAdherenceService,
      action.data
    );
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.RESET_SUCCESS
      });
      yield put({
        type: constants.DEVICE.ADHERENCE_RESET_HISTORY,
        data: { device: 'ALL', id, page: 1, perPage }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* deleteProtocolRequest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id } = action.data;
    const response = yield call(
      ProtocolDevice.deleteProtocolService,
      action.data
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.DEVICE.FETCH_PROTOCOL,
        data: { device: 'ALL', id }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getJustificationReset() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(ProtocolDevice.getJustificationResetService);
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.DEVICE.JUSTIFICATION_RESET_SUCCESS,
        data: response.data.typeCode
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* uploadRTPTherapy(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { data } = action.allData;
    const response = yield call(ProtocolDevice.upload_RTPTherapy_ServiceTitan, data);
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.DEVICE.FETCH_RTU_SETTING_HISTORY_SUCCESS,
        data: response.data.therapyData,
        key: action.allData.data.patientId
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.message
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchRTUSettingHistoryInfo(action) {
  const patientId = action.patientId;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const rtuSettingHistoryInf = yield call(
      ProtocolDevice.getRTUSettingHistory,
      patientId
    );
    if (
      rtuSettingHistoryInf &&
      (rtuSettingHistoryInf.status === 200 || rtuSettingHistoryInf.status === 201)
    ) {
      yield put({
        type: constants.DEVICE.FETCH_RTU_SETTING_HISTORY_RESET,
      });
      yield put({
        type: constants.DEVICE.FETCH_RTU_SETTING_HISTORY_SUCCESS,
        data: rtuSettingHistoryInf.data,
        key: patientId
      });
    } else {
      throw Object({
        custom_message: rtuSettingHistoryInf.data.ERROR || rtuSettingHistoryInf.data.error
      });
    }
  } catch (rtuSettingHistoryInf) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      rtuSettingHistoryInf: rtuSettingHistoryInf.custom_message
    });
    yield put({
      type: constants.ALERT.HANDLE_SCROLLING,
      rtuSettingHistoryInf: { isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const ProtocolAction = {
  fetchDevice,
  fetchDeviceInfo,
  fetchProtocolOverview,
  adherenceResetHistory,
  getPatientAction,
  deleteDeviceRequest,
  resetAdherence,
  deleteProtocolRequest,
  getJustificationReset,
  uploadRTPTherapy,
  fetchRTUSettingHistoryInfo
};

export default ProtocolAction;
