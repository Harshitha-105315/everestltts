import React, { Component } from 'react';
import strings from 'localization/strings';
import constants from 'constants.js';
import './RTUTherapyUpload';
import settings1 from 'assets/img/logo/settings.png';
import './RTUTherapyUpload.scss';
import InfoIcon from 'assets/img/info.svg';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import titanlogo from 'assets/img/logo/titanlogo.png';
import { connect } from 'react-redux';
import { decryptdata, decryptemail } from '../../Cryptocode';
import moment from 'moment-timezone';
import { isEmpty } from 'lodash';
class RTPsettings extends Component {
    constructor(props) {
        super(props);
    };

    componentWillMount() {
        setTimeout(this.handleDispatchRTU(this.props.patientId), 3000);
    }
    handleClose = () => {
        this.mycoughpausesettingsOverlayRef.hide();
    };

    hideMyDatePopover = () => {
        this.myDateOverlayRef.hide();
    };

    handleDispatchRTU = (patient_id) => {
        const { dispatch } = this.props;
        dispatch({
            type: constants.DEVICE.FETCH_RTU_SETTING_HISTORY_DATA,
            patientId: patient_id
        });
    }

    rtutableBody = () => {
        let rtuTr = [];
        const patientVlaues = Object.values(this.props.rtuSettingHistoryInf);
        function ObjectLength(object) {
            var length = 0;
            for (var key in object) {
                if (object.hasOwnProperty(key)) {
                    ++length;
                }
            }
            return length;
        };

        for (let i = 0; i < ObjectLength(patientVlaues); i++) {
            for (let j = 0; j < ObjectLength(patientVlaues[i]); j++) {
                rtuTr.push(patientVlaues[i][j]);
            }
        }
        return rtuTr;
    }

    render() {
        const details = JSON.parse(localStorage.getItem(constants.TOKEN));
        const currentUserRole = decryptdata(details.actualRole, 'Protected$9876');
        const myDatePopover = (
            <Popover id="my-date-info">
                <Popover.Title>
                    <div className="info-title">{strings.updatesubmitted}</div>
                </Popover.Title>
            </Popover >
        );
        const myResponseDatePopover = (
            <Popover id="my-date-info">
                <Popover.Title>
                    <div className="info-title">{strings.updateresponse}</div>
                </Popover.Title>
            </Popover >
        );

        const removeZeroSteps = (eightSteps) => {
            const therapy_paramSteps = [];
            for (var i = 0; i < eightSteps.length; i++) {
                if (eightSteps[i].frequency != 0) {
                    therapy_paramSteps.push(eightSteps[i]);
                }
            }
            return therapy_paramSteps
        }

        const mycoughpausesettingsPopover = (therapy_paramSteps, coughSettingVal) => (
            <Popover id="stepsettings">
                <Popover.Title>
                    <div className="row">
                        <div className="col-6"><h5>{strings.settings}</h5></div>
                        <div className="col-6"><button className='right' onClick={() => this.handleClose()}>OK </button></div>
                    </div>
                    <div className="card mobile-full-width-table">
                        <table className="table text-center rtuCoughTable">
                            <thead>
                                <tr>
                                    <th>{strings.frequency}</th>
                                    <th>{strings.intensity}</th>
                                    <th>{strings.duration}</th>
                                </tr>
                                {therapy_paramSteps && therapy_paramSteps.map((item =>
                                    <tr key={item.step}>
                                        <td>{item.frequency}</td>
                                        <td>{item.intensity}</td>
                                        <td>{item.duration}</td>
                                    </tr>
                                ))}
                                <tr>
                                    <td colSpan="3"><div style={{ textAlign: 'left' }}>COUGH PAUSE {coughSettingVal != undefined && coughSettingVal.caughPauseEnable != 0 ? <b>ON</b> : <b>OFF</b>}</div></td>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </Popover.Title>
            </Popover>
        );
        return (<div>
            <div>  <h2 className="section-heading">{strings.rtpsetting}</h2></div>
            <div className="card mobile-full-width-table">
                <table className="table text-center">
                    <thead>
                        <tr>
                            <th>{strings.date} <span className={`my-date-info-container`} >
                                <OverlayTrigger
                                    trigger="click"
                                    placement="right"
                                    overlay={myDatePopover}
                                    ref={ref => (this.myDateOverlayRef = ref)}
                                    rootClose >
                                    <img
                                        className="popover-info-icon"
                                        src={InfoIcon}
                                        alt="Info"
                                        role="presentation" />
                                </OverlayTrigger>
                            </span> </th>
                            <th>{strings.device}</th>
                            <th>{strings.users}</th>
                            <th>{strings.settings}</th>
                            <th>{strings.date} <span className={`my-date-info-container`}>
                                <OverlayTrigger
                                    trigger="click"
                                    placement="right"
                                    overlay={myResponseDatePopover}
                                    ref={ref => (this.myDateOverlayRef = ref)}
                                    rootClose >
                                    <img
                                        className="popover-info-icon"
                                        src={InfoIcon}
                                        alt="Info"
                                        role="presentation"
                                    />
                                </OverlayTrigger>
                            </span> </th>
                            <th>{strings.status}</th>

                        </tr>
                    </thead>
                    <tbody>
                        {!isEmpty(this.rtutableBody()) ? (
                            this.rtutableBody().map((item, index) => (
                                < tr key={index}>
                                    <td className='rowspan'>{item.createDate && item.createDate ? moment(item.createDate).format('MM/DD/YYYY') : '-'}</td>
                                    <td className='rowspan'> <img src={titanlogo} width="28" height="28" className="d-inline-block" /></td>
                                    <td className='rowspan'>{currentUserRole}<br />{item.emailId ? decryptemail(item.emailId) : ''}</td>
                                    <td className='rowspan'>
                                        <OverlayTrigger
                                            trigger="click"
                                            placement="top"
                                            overlay={mycoughpausesettingsPopover(removeZeroSteps(item.therapyParam), item.caughPauseSetting)}
                                            ref={ref => (this.mycoughpausesettingsOverlayRef = ref)}
                                            rootClose >
                                            <input type="image" width="17" height="17" src={settings1}></input>
                                        </OverlayTrigger>
                                    </td>
                                    <td className='rowspan'>{(item.updateDate && item.status === 'PENDING') && item.updateDate ? '-' : moment(item.updateDate).format('MM/DD/YYYY')}</td>
                                    <td className={`rowspan ${item.status}-color`}>{item.status}</td>
                                </tr>
                            )
                            )
                        ) : <tr><td colSpan="6"><p>No data available</p></td></tr>
                        }
                    </tbody>
                </table>
            </div>
        </div >
        );
    }
}
const mapStateToProps = (state, ownProps) => {
    const { protocolReducer } = state.app;
    return {
        rtuSettingHistoryInf: protocolReducer.rtuSettingHistoryInf || {}
    };
};
export default connect(mapStateToProps)(RTPsettings)