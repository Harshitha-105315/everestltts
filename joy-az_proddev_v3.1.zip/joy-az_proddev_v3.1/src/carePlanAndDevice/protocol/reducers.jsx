import constants from 'constants.js';
import { setStateByKey } from 'utils/helper.js';
const initialState = {
  PatientData: {},
  protocolData: {},
  deviceInfo: {},
  adherenceHistory: {},
  adherenceResetHistory: {},
  typeCode: [],
  rtuSettingHistoryInf: {},
};

function protocolReducer(state = initialState, action) {
  const tmpState = Object.assign({}, state);
  if (action.type === constants.DEVICE.STORE_PROTOCOL) {
    tmpState.protocolData = setStateByKey(
      tmpState.protocolData,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.STORE_DEVICE_INFO) {
    tmpState.deviceInfo = setStateByKey(
      tmpState.deviceInfo,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.FETCH_RTU_SETTING_HISTORY_SUCCESS) {
    tmpState.rtuSettingHistoryInf = setStateByKey(
      tmpState.rtuSettingHistoryInf,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.FETCH_RTU_SETTING_HISTORY_RESET) {
    return Object.assign({}, state, {
      rtuSettingHistoryInf: {}
    });
  }
  if (action.type === constants.DEVICE.STORE_ADHERENCE_RESET_HISTORY) {
    tmpState.adherenceHistory = setStateByKey(
      tmpState.adherenceHistory,
      action.key,
      action.data
    );
    tmpState.adherenceResetHistory = setStateByKey(
      tmpState.adherenceResetHistory,
      action.key,
      action.data.Adherence_Reset_History
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.STORE_PATIENT_DATA) {
    tmpState.PatientData = setStateByKey(
      tmpState.PatientData,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.JUSTIFICATION_RESET_SUCCESS) {
    tmpState.typeCode = action.data;
    return tmpState;
  }
  return state;
}
export default protocolReducer;
