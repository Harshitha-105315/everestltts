import React, { Component } from 'react';
import './DeviceInformationList.scss';
import strings from 'localization/strings';
import ButtonComponent from 'components/ButtonComponent';
import RTPsettings from './RTPsettings';
import { getUserData } from 'utils/helper';
import constants from 'constants.js';
import settings from 'assets/img/logo/settings.png';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import './RTUTherapyUpload.scss';
import './RTPSettings.scss';
import titanlogo from 'assets/img/logo/titanlogo.png';
import urls from 'urls';
import { reverse } from 'named-urls';
import { connect } from 'react-redux';
import { decryptemail } from '../../Cryptocode';
class RTUTherapyUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      therapy_name: 'My Therapy',
      therapy_param: [
        {
          step: 1,
          frequency: (this.defaultMinFeq() != undefined) ? this.defaultMinFeq() : 5,
          intensity: (this.defaultMinInt() != undefined) ? this.defaultMinInt() : 1,
          duration: 1
        }
      ],
      enablecoughpausestatus: false,
      aftereachstepstatus: false,
      autorestartstatus: false,
      coughpauseduration: 30,
      coughpauseinterval: 1,
      toggle: false,
      toggle1: false,
      toggle2: false,
      maxstepduration: 0,
    };
  };

  componentDidUpdate(prevProps) {
    if (this.props.rtuSettingHistoryInf !== prevProps.rtuSettingHistoryInf) {
      this.updateRTUuploaded()
    }
  }

  enablecoughpauseCheck = () => {
    this.setState(prevState => ({
      toggle: !prevState.toggle,
      enablecoughpausestatus: !prevState.enablecoughpausestatus,
    }))
    if (this.state.toggle) {
      this.setState({
        aftereachstepstatus: false,
        autorestartstatus: false,
        toggle1: false,
        toggle2: false
      })
    }
  }

  defaultMinFeq() {
    if (this.props.propsdata.protocol.protocol != undefined) {
      let defProtocolTitan = this.props.propsdata.protocol.protocol.find(o => o.deviceType === 'TITAN');
      if (defProtocolTitan != undefined) {
        return defProtocolTitan.minFrequency
      } else {
        return 5
      }
    }
  }
  defaultMinInt() {
    if (this.props.propsdata.protocol.protocol != undefined) {
      let defProtocolTitan = this.props.propsdata.protocol.protocol.find(o => o.deviceType === 'TITAN');
      if (defProtocolTitan != undefined) {
        return defProtocolTitan.minIntensity
      } else {
        return 1
      }
    }
  }

  increment = (name, key) => {
    let defProtocolTitan = this.props.propsdata.protocol.protocol.find(o => o.deviceType === 'TITAN');
    const maxFeq = defProtocolTitan ? defProtocolTitan.maxFrequency : 20;
    const maxInt = defProtocolTitan ? defProtocolTitan.maxIntensity : 10;
    this.setState(prevState => {
      let sum = 1;
      switch (name) {
        case 'frequency':
          const therapy_param_feq = [...prevState.therapy_param];
          if (therapy_param_feq[key].frequency < maxFeq) {
            therapy_param_feq[key].step = sum + key;
            therapy_param_feq[key].frequency += 1;
            return { therapy_param: therapy_param_feq };
          }
          break
        case 'intensity':
          const therapy_param_int = [...prevState.therapy_param];
          if (therapy_param_int[key].intensity < maxInt) {
            therapy_param_int[key].step = sum + key;
            therapy_param_int[key].intensity += 1;
            return { therapy_param: therapy_param_int };
          }
          break
        case 'duration':
          const therapy_param_dur = [...prevState.therapy_param];
          if (therapy_param_dur[key].duration < 60 || this.state.maxstepduration) {
            therapy_param_dur[key].step = sum + key;
            therapy_param_dur[key].duration += 1;
            const maxduration = therapy_param_dur.map(item => item.duration).reduce((prev, curr) => prev + curr, 0);
            prevState.maxstepduration = maxduration
            return { therapy_param: therapy_param_dur };
          }
          break
        case 'coughpauseinterval':
          if (prevState[name] < 20) {
            return {
              [name]: prevState[name] + 1
            }
          }
          break
        case 'coughpauseduration':
          if (prevState[name] < 120) {
            return {
              [name]: prevState[name] + 30
            }
          }
          break
      }
    });
  }

  decrement = (name, key) => {
    this.setState(prevState => {
      let sum = 1;
      switch (name) {
        case 'frequency':
          const therapy_param_feq = [...prevState.therapy_param];
          if (therapy_param_feq[key].frequency > this.defaultMinFeq()) {
            therapy_param_feq[key].step = sum + key;
            therapy_param_feq[key].frequency -= 1;
            return { therapy_param: therapy_param_feq };
          }
          break
        case 'intensity':
          const therapy_param_int = [...prevState.therapy_param];
          if (therapy_param_int[key].intensity > this.defaultMinInt()) {
            therapy_param_int[key].step = sum + key;
            therapy_param_int[key].intensity -= 1;
            return { therapy_param: therapy_param_int };
          }
          break
        case 'duration':
          const therapy_param_dur = [...prevState.therapy_param];
          if (therapy_param_dur[key].duration > 1) {
            therapy_param_dur[key].step = sum + key;
            therapy_param_dur[key].duration -= 1;
            const maxduration = therapy_param_dur.map(item => item.duration).reduce((prev, curr) => prev + curr, 0);
            prevState.maxstepduration = maxduration
            return { therapy_param: therapy_param_dur };
          }
          break
        case 'coughpauseinterval':
          if (prevState[name] > 1) {
            return {
              [name]: prevState[name] - 1
            }
          }
          break
        case 'coughpauseduration':
          if (prevState[name] > 30) {
            return {
              [name]: prevState[name] - 30
            }
          }
          break
      }
    });
  }

  handleupload = () => {
    let { therapy_name, therapy_param, enablecoughpausestatus, aftereachstepstatus, autorestartstatus, coughpauseduration, coughpauseinterval } = this.state;
    const { dispatch, history, PatientData } = this.props.propsdata;
    const data = {
      therapyName: therapy_name,
      therapyParam: therapy_param,
      caughPauseSetting: {
        caughPauseEnable: enablecoughpausestatus ? 1 : 0,
        afterEachStepStatus: aftereachstepstatus ? 0 : 1,
        autoRestartStatus: autorestartstatus ? 1 : 0,
        caughPauseDuration: coughpauseduration,
        caughPauseInterval: coughpauseinterval
      },
      therapyType: 2,
      deviceType: 'TITAN',
      status: 'PENDING',
      patientId: PatientData.patient_id,
      emailId: PatientData.email ? decryptemail(PatientData.email) : '',
      isDeleted: 0
    };
    const allData = {
      path: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL),
      history,
      data
    };

    dispatch({
      type: constants.DEVICE.UPLOAD_RTP_THERAPY_TITAN_REQUEST,
      allData
    });
  };

  handleClose = () => {
    this.mycoughpausesettingsOverlayRef.hide();
  };

  handlsave = () => {
    this.mycoughpausesettingsOverlayRef.hide();
  }

  handleAddNewSteps = () => {
    const { therapy_param } = this.state;
    const stepcount = therapy_param.length;
    this.setState({
      therapy_param: therapy_param.concat([
        {
          step: stepcount + 1,
          frequency: this.defaultMinFeq(),
          intensity: this.defaultMinInt(),
          duration: 1
        }
      ]),
    });
  };

  handleDeleteStep = key => {
    let currentStep = this.state.therapy_param;
    if (this.state.therapy_param.length > 1) {
      currentStep.splice(key, 1);
    }
    if (currentStep != undefined) {
      for (let i = 0; i < currentStep.length; i++) {
        if (currentStep[i].step != i + 1) {
          currentStep[i].step = i + 1;
        }
      }
    }
    this.setState({
      therapy_param: currentStep
    });
  };

  rtutableBody = () => {
    let rtuTr = [];
    const patientVlaues = Object.values(this.props.rtuSettingHistoryInf);
    function ObjectLength(object) {
      var length = 0;
      for (var key in object) {
        if (object.hasOwnProperty(key)) {
          ++length;
        }
      }
      return length;
    };

    for (let i = 0; i < ObjectLength(patientVlaues); i++) {
      for (let j = 0; j < ObjectLength(patientVlaues[i]); j++) {
        rtuTr.push(patientVlaues[i][j])
        break;
      }
    }
    return rtuTr;
  }

  removeZeroSteps = (eightSteps) => {
    const therapy_paramSteps = [];
    for (var i = 0; i < eightSteps.length; i++) {
      if (eightSteps[i].frequency != 0) {
        therapy_paramSteps.push(eightSteps[i]);
      }
    }
    return therapy_paramSteps
  }

  updateRTUuploaded = () => {
    this.rtutableBody().map((item) => (
      this.setState({
        therapy_param: this.removeZeroSteps(item.therapyParam),
        enablecoughpausestatus: (item.caughPauseSetting.caughPauseEnable == 1) ? true : false,
        toggle: (item.caughPauseSetting.caughPauseEnable == 1) ? true : false,
        aftereachstepstatus: (item.caughPauseSetting.afterEachStepStatus == 0) ? true : false,
        toggle1: (item.caughPauseSetting.afterEachStepStatus == 0) ? true : false,
        autorestartstatus: (item.caughPauseSetting.autoRestartStatus == 1) ? true : false,
        toggle2: (item.caughPauseSetting.autoRestartStatus == 1) ? true : false,
        coughpauseduration: item.caughPauseSetting.caughPauseDuration,
        coughpauseinterval: item.caughPauseSetting.caughPauseInterval
      })
    ))
  }

  render() {
    const { therapy_param } = this.state;
    const mycoughpausesettingsPopover = (
      <Popover id="my-coughpausesettings-info">
        <Popover.Title>
          <div className="row">
            <div className="col-6"> <h5>{strings.coughpausesetting}</h5></div>
            <div className="col-6"><button className="right1" onClick={() => this.handleClose()}>  CANCEL </button>
              <button className="right" onClick={() => this.handlsave()}>  SAVE </button></div>
          </div>
          <div className="row">
            <div className="col-6">
              <strong>
                <div className="dbold">{strings.coughpause}</div>
              </strong>
              <strong>
                <div style={{ paddingTop: '2px' }}>
                  {strings.coughpauseenablestatus}
                </div>{' '}
              </strong>
              <div><span className='btnswitch'>Off</span>
                <button
                  className="toggle"
                  onClick={this.enablecoughpauseCheck}
                  style={{
                    background: `${this.state.toggle ? '#000839' : '#D3D3D3'}`
                  }}
                >
                  <div
                    className="btn"
                    style={{
                      marginLeft: `${this.state.toggle ? '15px' : '-25px'}`,
                      background: `${this.state.toggle ? '#fff' : '#fff'}`
                    }}
                  />
                </button>
                <span className='btnswitch'>On</span>
              </div>
              <strong>
                {' '}
                <div className="dbold">{strings.autopauseenablestatus}</div>{' '}
              </strong>
              <div><span className='btnswitch'>Off</span>
                <button
                  disabled={!this.state.enablecoughpausestatus}
                  className="toggle"
                  onClick={() =>
                    this.setState(prevState => ({
                      toggle1: !prevState.toggle1,
                      aftereachstepstatus: !prevState.aftereachstepstatus
                    }))
                  }
                  style={{
                    background: `${this.state.toggle1 ? '#201547' : '#D3D3D3'}`
                  }}
                >
                  <div
                    className="btn"
                    style={{
                      marginLeft: `${this.state.toggle1 ? '15px' : '-25px'}`,
                      background: `${this.state.toggle1 ? '#fff' : '#fff'}`
                    }}
                  />
                </button>
                <span className='btnswitch'>On</span>
              </div>
              <strong>
                {' '}
                <div className="dbold"> {strings.intervalenablestatus}</div>
              </strong>
              <div>
                <span className='btnswitch'>Off</span>
                <button
                  disabled={!this.state.enablecoughpausestatus}
                  className="toggle"
                  onClick={() =>
                    this.setState(prevState => ({
                      toggle2: !prevState.toggle2,
                      autorestartstatus: !prevState.autorestartstatus
                    }))
                  }
                  style={{
                    background: `${this.state.toggle2 ? '#201547' : '#D3D3D3'}`
                  }}
                >
                  <div
                    className="btn"
                    style={{
                      marginLeft: `${this.state.toggle2 ? '15px' : '-25px'}`,
                      background: `${this.state.toggle2 ? '#fff' : '#fff'}`
                    }}
                  />
                </button>
                <span className='btnswitch'>On</span>
              </div>
            </div>

            <div className="col-6">
              <div><strong>
                <div className="dbold"> {strings.coughpauseinterval}</div>
              </strong>
                <button className="bton" onClick={() => this.decrement('coughpauseinterval')} > - </button>
                <input size="1" name="coughpauseinterval" value={this.state.coughpauseinterval} />
                <button className="bton" onClick={() => this.increment('coughpauseinterval')}> + </button>
              </div>

              <div>
                <strong>
                  <div className="dbold" style={{ float: "left", width: "100%" }}>{strings.coughpauseduration}</div>
                </strong>
                <button className="bton" onClick={() => this.decrement('coughpauseduration')}>  -  </button>
                <input size="1" name="coughpauseduration" value={this.state.coughpauseduration} />
                <button className="bton" onClick={() => this.increment('coughpauseduration')}> {' '} + </button>
              </div>
            </div>
          </div>
        </Popover.Title>
      </Popover>
    );
    return (
      <div id="form">
        {getUserData().actualRole === constants.ROLES.SUPER_ADMIN &&
          <div className="card mobile-full-width-table">
            <table className="table text-center rtp-table">
              <thead>
                <tr>
                  <th>{strings.device}</th>
                  <th>{strings.steps}</th>
                  <th>{strings.frequency}</th>
                  <th>{strings.intensity}</th>
                  <th>{strings.duration}</th>
                  <th>{strings.coughpausesetting}</th>
                </tr>
              </thead>
              <tbody>

                {therapy_param.map((step, key) => (
                  <tr>
                    <td className={`rowspan ${key === 0 ? '' : 'removetd'}`} rowspan={`${Number(this.state.therapy_param.length)}`}> <img src={titanlogo} width="28"
                      height="28"
                      className="d-inline-block" /></td>
                    <td className='rowspan'>{` ${strings.step} ${Number(key) + 1}`}<br />
                      {therapy_param.length > 1 && (
                        <ButtonComponent
                          buttonAction={this.handleDeleteStep.bind(this, key)}
                          icon="cancel-icon"
                          buttonText={strings.deleteStep}
                          style={{ marginBottom: '20px' }}
                        />
                      )}
                      {therapy_param.length < 8 && (<><br />
                        <ButtonComponent
                          buttonClass={(key === therapy_param.length - 1 && this.state.maxstepduration < 60) ? "" : 'removeaddNewStepBtn'}
                          buttonAction={this.handleAddNewSteps}
                          icon="report-icon"
                          buttonText={strings.addNewStep}
                        /></>
                      )}

                    </td>
                    <td className='rowspan'>
                      <div className='swbtnfeq'>
                        <button className='bton' onClick={() => this.decrement('frequency', key)}>-</button>
                        <input size="1" name='frequency' value={this.state.therapy_param[key].frequency} />
                        <button className='bton' onClick={() => this.increment('frequency', key)}>+</button>
                      </div>
                    </td>
                    <td className='rowspan'>
                      <div className='swbtnint'>
                        <button className='bton' onClick={() => this.decrement('intensity', key)}>-</button>
                        <input size="1" name='intensity' value={this.state.therapy_param[key].intensity} />
                        <button className='bton' onClick={() => this.increment('intensity', key)}>+</button>
                      </div>
                    </td>
                    <td className='rowspan'>
                      <div className='swbtndur'>
                        <button className='bton' onClick={() => this.decrement('duration', key)}>-</button>
                        <input size="1" name='duration' value={this.state.therapy_param[key].duration} />
                        <button className='bton' disabled={this.state.maxstepduration === 60} onClick={() => this.increment('duration', key)}>+</button>
                      </div>
                    </td>

                    {key == 0 ? <td className='rowspan' rowspan={`${Number(this.state.therapy_param.length)}`}>
                      <OverlayTrigger
                        trigger="click"
                        placement="top"
                        overlay={mycoughpausesettingsPopover}
                        ref={ref => (this.mycoughpausesettingsOverlayRef = ref)}
                        rootClose >
                        <input type="image" width="17" height="17" src={settings}></input>
                      </OverlayTrigger><div>COUGH PAUSE {this.state.enablecoughpausestatus ? <b>ON</b> : <b>OFF</b>}</div></td> :
                      <td className={`rowspan ${key === 0 ? '' : 'removetd'}`} rowspan={`${Number(this.state.therapy_param.length)}`}>
                        <div>COUGH PAUSE {this.state.enablecoughpausestatus ? <b>ON</b> : <b>OFF</b>}</div>
                      </td>
                    }

                    <td className={`rowspan ${key === 0 ? '' : 'removetd'}`} rowspan={`${Number(this.state.therapy_param.length)}`}>
                      <ButtonComponent
                        buttonAction={() => { this.handleupload() }}
                        icon="right-arrow"
                        buttonText={strings.upload}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div >
        }
        <RTPsettings patientId={this.props.propsdata.PatientData.patient_id} onChildData={this.handleChildData} />
      </div >
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { protocolReducer } = state.app;
  return {
    rtuSettingHistoryInf: protocolReducer.rtuSettingHistoryInf || {}
  };
};
export default connect(mapStateToProps)(RTUTherapyUpload)

