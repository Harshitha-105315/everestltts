/* eslint-disable react/prefer-stateless-function */
import React, { Component } from 'react';
import { Form, Row, Col } from 'react-bootstrap';
import strings from 'localization/strings';
import DatePicker from 'react-datepicker';
import { uid } from 'react-uid';
import DatePickerDisabledInput from 'components/DatePickerDisabledInput';
import ButtonComponent from 'components/ButtonComponent';

class ResetScore extends Component {
  justification = () => {
    const { justificationOptions } = this.props;
    return justificationOptions.map(option => {
      return (
        <option key={uid(option)} value={option.type_code}>
          {option.type_code_value}
        </option>
      );
    });
  };

  render() {
    const {
      disabled,
      isMobile,
      justification,
      error,
      resetStartDate,
      Others,
      getActiveDate,
      handleChangeResetDate,
      handleSelectChange,
      handleResetAdherence,
      handleChange
    } = this.props;
    return (
      <div className="resetMyscore-Container">
        <h2 className="section-heading">{strings.resetMyscore}</h2>
        {disabled ? (
          <Form>
            <Form.Row>
              <Form.Group as={Col} className="col-12 col-sm">
                {strings.noActiveDeviceResetMsg}
              </Form.Group>
            </Form.Row>
          </Form>
        ) : (
            <Form>
              <Form.Row>
                <Form.Group as={Col} className="col-12 col-sm">
                  <Form.Label htmlFor="reset">
                    {strings.myScoreStartDate} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <br />
                  <DatePicker
                    className="custom-select"
                    id="custom-select-datepicker"
                    disabled={disabled}
                    name="adherenceStartDate"
                    customInput={<DatePickerDisabledInput />}
                    maxDate={new Date()}
                    dateFormat="MMM d, yyyy"
                    selected={resetStartDate}
                    onChange={handleChangeResetDate}
                    placeholderText={strings.selectDate}
                  />
                </Form.Group>

                <Form.Group as={Col} className="col-12 col-sm">
                  <Form.Label htmlFor="reset">{strings.resetDate} <span className="asterisk-color">*</span></Form.Label>
                  <Form.Control
                    className="custom-select"
                    readOnly
                    name="date"
                    value={getActiveDate}
                    disabled={disabled}
                  />
                </Form.Group>
                <Form.Group as={Col} className="col-12 col-sm">
                  <Form.Label htmlFor="reset">{strings.resetTo} <span className="asterisk-color">*</span></Form.Label>
                  <Form.Control
                    name="ResetTo"
                    type="text"
                    value="100"
                    required=""
                    disabled="disabled"
                  />
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.Justification} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <Form.Control
                    className="custom-select"
                    as="select"
                    name="justification"
                    placeholder={strings.select}
                    disabled={disabled}
                    onChange={handleSelectChange}
                  >
                    <option value="" label="Select a justification" />
                    {this.justification()}
                  </Form.Control>
                </Form.Group>
              </Form.Row>
              {justification === 'Others' && (
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="reset">{strings.comment} <span className="asterisk-color">*</span></Form.Label>

                    <Form.Control
                      name="Others"
                      type="textarea"
                      value={Others}
                      onChange={handleChange}
                      required
                    />
                  </Form.Group>
                </Form.Row>
              )}
              <p className="text-danger">{error}</p>
              <Row>
                <Col>
                  <ButtonComponent
                    buttonClass={!isMobile ? 'float-right' : ''}
                    buttonAction={handleResetAdherence}
                    hidden={disabled}
                    icon="refresh-icon"
                    buttonText={strings.reset}
                  />
                </Col>
              </Row>
            </Form>
          )}
      </div>
    );
  }
}

export default ResetScore;
