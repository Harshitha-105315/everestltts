/* eslint-disable react/prefer-stateless-function */
import React, { Component } from 'react';
import strings from 'localization/strings';
import { isEmpty } from 'lodash';
import { Dropdown } from 'react-bootstrap';
import moreicon from 'assets/img/icn-more.svg';
import trash from 'assets/icn-delete.svg';
import edit from 'assets/edit.svg';
import urls from 'urls';
import { reverse } from 'named-urls';
import CustomToggle from './customToggle';

class ProtocolInformationList extends Component {
  render() {
    const {
      isMobile,
      canUpdate,
      canDelete,
      protocolData,
      protocol,
      newProtocol,
      deviceRef,
      id,
      handleProtocolRemove,
      addBreadCrumb
    } = this.props;
    return (
      <div>
        <h1 className="text-capitalize">{strings.carePlanAndDevice}</h1>
        <h2 className="section-heading">{strings.protocol}</h2>
        {!isMobile && (
          <div className="card mobile-full-width-table">
            <table className="table text-center">
              <thead>
                <tr>
                  <th>{strings.device}</th>
                  <th>{strings.type}</th>
                  <th>{strings.treatmentsPerDay}</th>
                  <th>{strings.minutesPerTreatment}</th>
                  <th>{strings.frequencyPerTreatment}</th>
                  <th>{strings.pressurePerTreatment}</th>
                  {(canUpdate || canDelete) && <th>{strings.options}</th>}
                </tr>
              </thead>
              <tbody>{protocolData}</tbody>
            </table>
          </div>
        )}
        {isMobile && !isEmpty(protocol.protocol) ? (
          Object.keys(newProtocol).map((device, key) => (
            <div>
              <div
                className={`mt-4 mb-1 d-block d-sm-none mobile-device-name ${deviceRef[device][2]
                  }-logo-text device-title`}
              >
                <img
                  src={deviceRef[device][1]}
                  width="32"
                  height="32"
                  alt={deviceRef[device][0]}
                />
                {deviceRef[device][0]}
                {(canUpdate || canDelete) && (
                  <Dropdown className="d-inline-block float-right">
                    <Dropdown.Toggle as={CustomToggle}>
                      <img
                        src={moreicon}
                        width="19"
                        height="19"
                        alt="more"
                        className="float-right"
                      />
                    </Dropdown.Toggle>
                    <Dropdown.Menu alignRight>
                      {canUpdate && (
                        <Dropdown.Item
                          href={reverse(
                            urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT,
                            {
                              id,
                              protocolid: newProtocol[device][0].id,
                              devicetype: newProtocol[device][0].deviceType,
                              type: newProtocol[device][0].type
                            }
                          )}
                          onClick={() => {
                            addBreadCrumb({
                              title: strings.editProtocol
                            });
                          }}
                        >
                          <span className="text-capitalize">
                            <img
                              src={edit}
                              width="14"
                              height="14"
                              className="d-inline-block dropdown-item-icon"
                              alt="edit-icon"
                            />
                            {strings.edit}
                          </span>
                        </Dropdown.Item>
                      )}
                      {canDelete && (
                        <Dropdown.Item
                          onClick={e =>
                            handleProtocolRemove(
                              e,
                              newProtocol[device][0].deviceType,
                              newProtocol[device][0].protocolKey
                            )
                          }
                        >
                          <span className="text-capitalize">
                            <img
                              src={trash}
                              width="14"
                              height="14"
                              className="d-inline-block dropdown-item-icon"
                              alt="delete"
                            />
                            {strings.delete}
                          </span>
                        </Dropdown.Item>
                      )}
                    </Dropdown.Menu>
                  </Dropdown>
                )}
              </div>
              <div className="card mobile-full-width-table">
                <table className="table text-center" key={Number(key)}>
                  <thead key={Number(key)}>
                    <tr>
                      <th>{strings.prog}</th>
                      <th>{strings.sess}</th>
                      <th>{strings.dura}</th>
                      <th>{strings.freq}</th>
                      <th>{strings.pres}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {newProtocol[device].map((d, ids) => (
                      <tr key={Number(ids)}>
                        <td>{ids + 1}</td>
                        {ids === 0 && (
                          <td
                            rowSpan={newProtocol[device].length}
                            className="rowspan"
                          >
                            {d.treatmentsPerDay}
                          </td>
                        )}

                        <td>{d.minMinutesPerTreatment}m</td>
                        <td>
                          {d.minIntensity}
                          {d.maxIntensity === d.minIntensity || !d.maxIntensity
                            ? ''
                            : `-${d.maxIntensity}`}
                        </td>
                        {d.deviceType === 'VEST' || d.deviceType === 'TITAN' ? (
                          <td>
                            {d.minPressure}
                            {d.maxPressure === d.minPressure || !d.maxPressure
                              ? ''
                              : `-${d.maxPressure}`}
                          </td>
                        ) : (
                          <td>
                            {d.minIntensity}
                            {d.maxIntensity === d.minIntensity ||
                              !d.maxIntensity
                              ? ''
                              : `-${d.maxIntensity}`}
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))
        ) : (
          <div>
            {isMobile && (
              <h2 className="section-heading text-capitalize">
                {strings.noProtocolAssociated}
              </h2>
            )}
          </div>
        )}
      </div>
    );
  }
}

export default ProtocolInformationList;
