/* eslint-disable no-nested-ternary */
/* eslint-disable react/no-unused-state */
import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import 'react-datepicker/dist/react-datepicker.css';
import { Row, Col } from 'react-bootstrap';
import { sumBy, groupBy, isEmpty, orderBy, some } from 'lodash';
import urls from 'urls';
import { reverse } from 'named-urls';
import Pagination from 'react-js-pagination';
import monarchLogo from 'assets/img/logo/monarch.png';
import titanlogo from 'assets/img/logo/titanlogo.png';
import visiVestLogo from 'assets/img/logo/visivest.png';
import manualLogo from 'assets/img/logo/icn_nonconnected@2x.png';
import trash from 'assets/icn-delete.svg';
import edit from 'assets/edit.svg';
import constants from 'constants.js';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData } from 'utils/helper';
import ConfirmationDialog from 'components/ConfirmationDialog';
import { Header, SideBar } from 'components/Navigation';
import strings from 'localization/strings';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { FootNote } from 'components/FootNote';
import ButtonComponent from 'components/ButtonComponent';
import {
  addBreadCrumb,
  getBreadCrumb,
  removeBreadCrumb
} from '../../utils/utltity';
import './protocolDevice.scss';
import DeviceInformationList from './DeviceInformationList';
import ResetScore from './ResetScore';
import ProtocolInformationList from './ProtocolInformationList';
import { getProtocolTypeLabel } from 'patient/helper';
import RTUTherapyUpload from './RTUTherapyUpload';

class ProtocolDevice extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      deviceType: '',
      resetStartDate: new Date(),
      resetScoreTo: '100',
      justification: '',
      Others: '',
      error: '',
      page: 1,
      perPage: 5,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      },
      showMsg: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleDeviceRemove = this.handleDeviceRemove.bind(this);
    this.handleProtocolRemove = this.handleProtocolRemove.bind(this);
    this.handleChangeResetDate = this.handleChangeResetDate.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.scrollToRef = this.scrollToRef.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.resetScoreRef = React.createRef();
    this.handlePaginate = this.handlePaginate.bind(this);
  }

  componentWillMount() {
    const { match } = this.props;
    const { id } = match.params;
    this.getProtocolData(id);
    this.dispatchAdHerenceResetHistory();
    {
      this.props && this.props.PatientData && this.props.PatientData.patient_id &&
        this.dispatchRTUHistoryData(this.props.PatientData.patient_id)
    }

  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.carePlanAndDevice });
  }


  componentWillReceiveProps(nextProps) {
    const { PatientData } = this.props;
    if (nextProps.PatientData.deviceType !== PatientData.deviceType) {
      this.setState({ deviceType: nextProps.PatientData.deviceType });
    }
  }

  componentDidUpdate() {
    const { location } = this.props;
    if (location.hash === '#reset-myscore') {
      this.scrollToRef(this.resetScoreRef);
    }
  }

  componentWillUnmount() {
    this.props.dispatch({
      type: constants.PATIENT.RESET_PATIENT_DATA
    });
    this.removeBreadCrumb();
  }

  handleChangeResetDate = date => {
    this.setState({ resetStartDate: date });
  };

  scrollToRef = ref => {
    ref.current.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
      inline: 'center'
    });
  };

  handleChange = evt => {
    this.setState({ [evt.target.name]: evt.target.value }, () => {
      // eslint-disable-next-line react/destructuring-assignment
      if (this.state.Others !== '') {
        this.setState({ error: '' });
      } else {
        this.setState({ error: `${strings.commentsRequired}` });
      }
    });
  };

  handleSelectChange = event => {
    this.setState({ justification: event.target.value }, () => {
      // eslint-disable-next-line react/destructuring-assignment
      if (this.state.justification !== '') {
        this.setState({ error: '' });
      } else {
        this.setState({ error: `${strings.justificationRequired}` });
      }
    });
  };

  getProtocolData = id => {
    const {
      dispatch,
      PatientData: { deviceType }
    } = this.props;
    dispatch({
      type: constants.DEVICE.FETCH_PROTOCOL_OVERVIEW,
      data: { deviceTypes: deviceType, id }
    });
  };

  dispatchAdHerenceResetHistory = () => {
    const { match, dispatch } = this.props;
    const { id } = match.params;
    const { perPage, page } = this.state;
    dispatch({
      type: constants.DEVICE.ADHERENCE_RESET_HISTORY,
      data: { device: 'ALL', id, page, perPage }
    });
  };

  dispatchRTUHistoryData = (patient_id) => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.DEVICE.FETCH_RTU_SETTING_HISTORY_DATA,
      patientId: patient_id
    });
  };

  getActiveDate = date => {
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    const activedate = new Date(date);
    const date1 = activedate.getDate();
    const month = monthNames[activedate.getMonth()];
    const year = activedate.getFullYear();
    return `${month} ${date1}, ${year}`;
  };

  getTotalHmr = (hmr, HMR) => {
    let hours = Math.floor(hmr / 60);
    let minutes = Math.floor(hmr % 60);
    if (HMR === 'HMR') {
      return `${hours} ${strings.hours} ${minutes} ${strings.minutes}`;
    }
    hours = hours < 10 ? `0${hours}` : hours;
    minutes = minutes < 10 ? `0${minutes}` : minutes;
    return `${hours}:${minutes}`;
  };

  getTotal = data => {
    return sumBy(data, o => {
      return o.hmr;
    });
  };

  getDate = () => {
    const tempDate = new Date();
    const date = `${tempDate.getMonth() +
      1}/${tempDate.getDate()}/${tempDate.getFullYear()}`;
    return date;
  };

  selectedDate = () => {
    const { resetStartDate } = this.state;
    const date = `${resetStartDate.getDate()}/${resetStartDate.getMonth() +
      1}/${resetStartDate.getFullYear()}`;
    return date;
  };

  handleResetAdherence = () => {
    const { justification, Others } = this.state;
    const { PatientData } = this.props;
    this.setState({ error: '' });
    let flag = true;
    if (justification === '') {
      this.setState({ error: strings.justificationRequired });
      flag = false;
    }
    if (justification === strings.Others) {
      if (Others === '') {
        this.setState({ error: strings.commentsRequired });
        flag = false;
      }
    }
    if (flag) {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: `${strings.resetAdherenceDialogBody} ${PatientData.firstName} ${PatientData.lastName
            } ${strings.resetAdherenceDialogBody2} ${this.selectedDate()}`,
          title: strings.resetAdherenceScore,
          button: strings.reset,
          confirmFunction: this.handleResetAdherenceDispatch,
          show: true
        })
      });
    }
  };

  handleResetAdherenceDispatch = () => {
    const { match, dispatch, PatientData } = this.props;
    const { id } = match.params;
    const { userId } = getUserData();
    const {
      resetStartDate,
      resetScoreTo,
      justification,
      perPage,
      dialog,
      Others
    } = this.state;
    dispatch({
      type: constants.DEVICE.RESET_ADHERENCE,
      data: {
        resetScore: resetScoreTo,
        createdBy: userId,
        deviceType: PatientData.deviceType,
        userId: PatientData.id,
        patientId: PatientData.hillromId,
        resetStartDate,
        justification: `${justification === 'Others' ? Others : justification}`,
        id,
        perPage
      }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      showMsg: true,
      page: 1
    });
  };

  handleDeleteDevice = () => {
    const { dialog } = this.state;
    const { deviceType, serialNumber } = dialog;
    const devicetype = deviceType;
    const serialNo = serialNumber;
    const { dispatch, history } = this.props;
    const { match } = this.props;
    const { id } = match.params;

    dispatch({
      type: constants.DEVICE.DELETE_DEVICE_REQUEST,
      data: { id, devicetype, serialNo }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  handleDeleteProtocol = () => {
    const { dialog } = this.state;
    const { deviceType, protocolKey } = dialog;
    const devicetype = deviceType;
    const protocolID = protocolKey;
    const { dispatch, history, match } = this.props;
    const { id } = match.params;
    dispatch({
      type: constants.DEVICE.DELETE_PROTOCOL_REQUEST,
      data: { id, devicetype, protocolID }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (document.documentElement.clientWidth <= 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  deviceInfoArray = () => {
    const { deviceInfo } = this.props;
    const deviceFilter = deviceInfo.deviceList;
    const newDeviceInfoOrder = orderBy(deviceFilter, ['active'], ['desc']);
    const newDeviceInfo = groupBy(newDeviceInfoOrder, 'active');
    return newDeviceInfo;
  };

  protocolArray = () => {
    const { protocol } = this.props;
    const newArray = groupBy(protocol.protocol, 'deviceType');
    return newArray;
  };

  protocolData({ canUpdate, canDelete }) {
    const newProtocol = this.protocolArray();
    const deviceRef = {
      VEST: ['VisiVest', visiVestLogo, 'visivest'],
      MONARCH: ['Monarch', monarchLogo, 'monarch'],
      TITAN: ['Titan', titanlogo, 'titan']
    };
    const { match, deviceInfo } = this.props;
    var isManualVest = false;

    !isEmpty(deviceInfo.deviceList) && (
      Object.keys(deviceInfo.deviceList).map(key => {
        if (deviceInfo.deviceList[key].deviceType === "VEST")
          isManualVest = deviceInfo.deviceList[key].isManual;
        return null;
      }
      ))
    const { id } = match.params;
    if (!isEmpty(newProtocol)) {
      return Object.keys(newProtocol).map(key =>
        newProtocol[key].map((newPro, index) => (
          <tr key={Number(index)}>
            {index === 0 && (
              <td
                rowSpan={newProtocol[key].length}
                className="protocol-table-row-span d-none d-sm-table-cell"
              >
                {
                  newPro.deviceType === 'VEST' && isManualVest ?
                    <img
                      src={manualLogo}
                      weight="32"
                      alt={'Manual Device'}
                    />
                    :
                    <img
                      src={deviceRef[key][1]}
                      width="32"
                      height="32"
                      alt={deviceRef[key][0]}
                    />
                }
              </td>
            )}

            <td className="align-middle">
              {newPro.deviceType === 'VEST' && isManualVest ? ' - ' :
                getProtocolTypeLabel(newPro.type, newPro.treatmentLabel)}
            </td>

            {index === 0 && (
              <td rowSpan={newProtocol[key].length} className="rowspan">
                {newPro.treatmentsPerDay}
              </td>
            )}

            <td className="align-middle">{newPro.minMinutesPerTreatment}</td>
            <td className="align-middle">
              {newPro.deviceType === 'VEST' && isManualVest
                ? ' - ' : newPro.minFrequency}
              {newPro.deviceType === 'VEST' && isManualVest
                ? '' : (newPro.maxFrequency === newPro.minFrequency ||
                  !newPro.maxFrequency)
                  ? ''
                  : `-${newPro.maxFrequency}`}
            </td>
            {newPro.deviceType === 'VEST' ? (
              <td className="align-middle">
                {isManualVest ? ' - ' : newPro.minPressure}
                {isManualVest ? '' :
                  newPro.maxPressure === newPro.minPressure ||
                    !newPro.maxPressure
                    ? ''
                    : `-${newPro.maxPressure}`}
              </td>
            ) : (
              <td className="align-middle">
                {newPro.minIntensity}
                {newPro.maxIntensity === newPro.minIntensity ||
                  !newPro.maxIntensity
                  ? ''
                  : `-${newPro.maxIntensity}`}
              </td>
            )}
            {index === 0 && (canUpdate || canDelete) && (
              <td
                rowSpan={newProtocol[key].length}
                className="rowspan d-none d-sm-table-cell"
              >
                {canUpdate && !(newPro.deviceType === 'VEST' && isManualVest) ? (
                  <Link
                    to={reverse(
                      urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT,
                      {
                        id,
                        protocolid: newPro.id,
                        devicetype: newPro.deviceType,
                        type: newPro.type
                      }
                    )}
                    onClick={() => {
                      this.addBreadCrumb({
                        title: strings.editProtocol
                      });
                    }}
                  >
                    <input
                      type="image"
                      src={edit}
                      style={{ marginRight: '0.3rem' }}
                      width="14"
                      height="14"
                      className="d-inline-block"
                      alt="edit"
                    />
                  </Link>
                ) : null}
                {canDelete && !(newPro.deviceType === 'VEST' && isManualVest) ? (
                  <input
                    type="image"
                    src={trash}
                    style={{ marginRight: '0.3rem' }}
                    width="14"
                    height="14"
                    alt="Trash"
                    className="d-inline-block"
                    onClick={e =>
                      this.handleProtocolRemove(
                        e,
                        newPro.deviceType,
                        newPro.protocolKey
                      )
                    }
                  />
                ) : null}
              </td>
            )}
          </tr>
        ))
      );
    }
    return (
      <tr>
        <td colSpan="7" className="text-center">
          {strings.noProtocolAssociated}
        </td>
      </tr>
    );
  }

  async handleDeviceRemove(e, deviceType, serialNumber) {
    const { dialog } = this.state;
    await this.setState({
      dialog: Object.assign(dialog, {
        body: strings.deleteDeviceDialogBody,
        title: strings.deleteDevice,
        button: strings.removeDevice,
        confirmFunction: this.handleDeleteDevice,
        deviceType,
        serialNumber,
        show: true
      })
    });
  }

  async handleProtocolRemove(e, deviceType, protocolKey) {
    const { dialog } = this.state;
    await this.setState({
      dialog: Object.assign(dialog, {
        body: strings.deleteProtocolDialogBody,
        title: strings.deleteProtocol,
        button: strings.removeProtocol,
        confirmFunction: this.handleDeleteProtocol,
        deviceType,
        protocolKey,
        show: true
      })
    });
  }

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
    this.dispatchAdHerenceResetHistory();
  }

  hasActiveDevice = deviceList => {
    return deviceList && some(deviceList, { active: true });
  };

  render() {
    const {
      resetStartDate,
      justification,
      Others,
      error,
      dialog,
      isMobile,
      page,
      perPage
    } = this.state;
    const {
      deviceInfo,
      adherenceHistory,
      match,
      location,
      breadcrumbs,
      history,
      protocol,
      adherenceResetHistory,
      justificationTypeCode,
      PatientData
    } = this.props;
    const { id } = match.params;
    const newProtocol = this.protocolArray();
    const size = Object.keys(newProtocol).length;
    const maxProtocolLength =
      PatientData.deviceType === constants.DEVICE_TYPE_CODE.ALL ? 3 : 1;
    const newDeviceInfo = this.deviceInfoArray();
    const deviceRef = {
      VEST: ['VisiVest', visiVestLogo, 'visivest'],
      MONARCH: ['Monarch', monarchLogo, 'monarch'],
      TITAN: ['Titan', titanlogo, 'titan']
    };
    const { actualRole } = getUserData();
    const deviceInformation =
      accessMatrix.PATIENT_DEVICE_INFORMATION[actualRole];
    const deviceDelete = accessMatrix.PATIENT_DEVICE_DELETE[actualRole];
    const byodDeviceInformation = accessMatrix.PATIENT_DEVICE_BYOD[actualRole];
    const protocolInformation =
      accessMatrix.PATIENT_PROTOCOL_INFORMATION[actualRole];
    const protocolDelete = accessMatrix.PATIENT_PROTOCOL_DELETE[actualRole];
    const myScoreInformation = accessMatrix.PATIENT_MY_SCORE[actualRole];

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    let showBack = true;
    let showBrand = false;
    let showToggle = false;
    if (getUserData().actualRole === constants.ROLES.PATIENT) {
      showBack = false;
      showBrand = true;
      showToggle = true;
    }

    const canReset = this.hasActiveDevice(deviceInfo.deviceList);

    return (
      <div>
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.USER.ALL}
          showBack={showBack}
          showBrand={showBrand}
          showToggle={showToggle}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <ProtocolInformationList
                isMobile={isMobile}
                canUpdate={protocolInformation.write}
                canDelete={protocolDelete.read}
                protocolData={this.protocolData({
                  canUpdate: protocolInformation.write,
                  canDelete: protocolDelete.read
                })}
                protocol={protocol}
                newProtocol={newProtocol}
                deviceRef={deviceRef}
                id={id}
                handleProtocolRemove={this.handleProtocolRemove}
                addBreadCrumb={this.addBreadCrumb}
              />

              <div>
                <Row>
                  <Col>
                    <ButtonComponent
                      id="execute-continue"
                      hidden={!protocolInformation.write}
                      buttonClass={!isMobile ? 'float-right' : ''}
                      disabled={size === maxProtocolLength}
                      buttonAction={() => {
                        this.addBreadCrumb({
                          title: strings.addProtocol
                        });
                        history.push(
                          reverse(
                            urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.ADD,
                            { id }
                          )
                        );
                      }}
                      icon={
                        size !== maxProtocolLength
                          ? 'add-icon'
                          : 'add-icon disabled'
                      }
                      buttonText={strings.addProtocol}
                    />
                  </Col>
                </Row>
              </div>
              <div>
                {getUserData().actualRole === constants.ROLES.SUPER_ADMIN &&
                  <><hr /><h2 className="section-heading">{strings.therapysettings}</h2></>}
                {this.props && this.props.PatientData && this.props.PatientData.patient_id &&
                  <RTUTherapyUpload propsdata={this.props} patient_id={this.props.PatientData.patient_id} />
                }
              </div>

              <h2 className="section-heading">{strings.deviceInformation}</h2>
              <DeviceInformationList
                patientID={id}
                canUpdate={deviceInformation.write || byodDeviceInformation.write}
                canDelete={deviceDelete.read}
                deviceInfo={deviceInfo}
                deviceRef={deviceRef}
                newDeviceInfo={newDeviceInfo}
                handleDeviceRemove={this.handleDeviceRemove}
                getTotalHmr={this.getTotalHmr}
                getActiveDate={this.getActiveDate}
                addBreadCrumb={this.addBreadCrumb}
                isMobile={isMobile}
              />

              <div className="d-small-total-hmr">
                <Row>
                  <Col className="total-hmr-container">
                    <h2 className="total-hmr-heading">{strings.globalHmr}</h2>
                    {!isEmpty(deviceInfo) && (
                      <div className="total-hmr">
                        {this.getTotalHmr(
                          this.getTotal(deviceInfo.deviceList),
                          'HMR'
                        )}
                      </div>
                    )}
                  </Col>
                  <Col>
                    <ButtonComponent
                      hidden={!deviceInformation.write}
                      buttonClass="float-right"
                      buttonAction={() => {
                        this.addBreadCrumb({ title: strings.addDevice });
                        history.push(
                          reverse(
                            urls.PATIENT.DETAIL.CAREPLANDEVICE.DEVICE.ADD,
                            { id }
                          )
                        );
                      }}
                      icon="add-icon"
                      buttonText={strings.addDevice}
                      textClass="dialog-btn-text"
                    />
                  </Col>
                </Row>
              </div>
              {myScoreInformation.write ? (
                <Fragment>
                  <hr />
                  <div ref={this.resetScoreRef}>
                    <ResetScore
                      disabled={!canReset}
                      isMobile={isMobile}
                      error={error}
                      justification={justification}
                      resetStartDate={resetStartDate}
                      Others={Others}
                      getActiveDate={this.getActiveDate(this.getDate())}
                      handleChangeResetDate={this.handleChangeResetDate}
                      handleSelectChange={this.handleSelectChange}
                      handleChange={this.handleChange}
                      handleResetAdherence={this.handleResetAdherence}
                      justificationOptions={justificationTypeCode}
                    />
                  </div>
                </Fragment>
              ) : null}
              {myScoreInformation.read ? (
                <Fragment>
                  <hr />
                  <h2 className="section-heading">
                    {strings.myScoreResetHistory}
                  </h2>
                  <div className="reset-table-wrapper">
                    <div className="card mobile-full-width-table">
                      <table className="table">
                        <thead>
                          <tr>
                            <th> {strings.startDate}</th>
                            <th> {strings.resetDate}</th>
                            <th> {strings.resetTime} </th>
                            <th className="d-none d-sm-table-cell">
                              {strings.justification}
                            </th>
                            <th className="d-none d-sm-table-cell">
                              {strings.comments}
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {!isEmpty(adherenceHistory.Adherence_Reset_History) &&
                            !isEmpty(
                              adherenceHistory.Adherence_Reset_History.content
                            ) ? (
                            adherenceHistory.Adherence_Reset_History.content.map(
                              (obj, idx) => {
                                return (
                                  <tr key={Number(idx) + 1}>
                                    <td>
                                      {this.getActiveDate(obj.resetStartDate)}
                                    </td>
                                    <td>{this.getActiveDate(obj.resetDate)}</td>
                                    <td>{obj.resetTime}</td>
                                    <td className="d-none d-sm-table-cell">
                                      {obj.justification}
                                    </td>
                                    <td className="d-none d-sm-table-cell">
                                      {obj.comments}
                                    </td>
                                  </tr>
                                );
                              }
                            )
                          ) : (
                            <tr>
                              <td colSpan="5" className="text-center">
                                {strings.noResetHistory}
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                    <div className="listing-pagination d-inline">
                      <nav aria-label="..." className="float-right">
                        <Pagination
                          activePage={page}
                          prevPageText="PREV"
                          nextPageText="NEXT"
                          linkClass="page-link"
                          activeLinkClass=""
                          itemClass="page-item"
                          itemsCountPerPage={perPage}
                          totalItemsCount={
                            adherenceResetHistory !== undefined &&
                            adherenceResetHistory.totalElements
                          }
                          pageRangeDisplayed={5}
                          onChange={this.handlePaginate}
                          firstPageText="FIRST"
                          lastPageText="LAST"
                        />
                      </nav>
                    </div>
                    {!isMobile && (
                      <h6 className="text-capitalize">
                        {!isEmpty(adherenceHistory.Adherence_Reset_History) &&
                          adherenceHistory.Adherence_Reset_History
                            .totalElements}
                        {` Reset History Records Found`}
                      </h6>
                    )}
                  </div>
                </Fragment>
              ) : null}
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { protocolReducer, breadcrumbsReducer } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    PatientData: protocolReducer.PatientData[id] || {},
    protocol: protocolReducer.protocolData[id] || {},
    deviceInfo: protocolReducer.deviceInfo[id] || {},
    adherenceHistory: protocolReducer.adherenceHistory[id] || {},
    adherenceResetHistory: protocolReducer.adherenceResetHistory[id] || {},
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    justificationTypeCode: protocolReducer.typeCode,
  };
};


export default connect(mapStateToProps)(ProtocolDevice);
