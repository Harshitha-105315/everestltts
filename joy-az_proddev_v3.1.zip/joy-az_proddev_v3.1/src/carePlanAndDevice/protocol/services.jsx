import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function getPatientService(patientID) {
  const url = API.GETPATIENT.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getProtocolDevice(patientID, deviceType) {
  const url = API.PROTOCOLDEVICE.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}?deviceType=${deviceType}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getDeviceInformation(patientID, deviceType) {
  const url = API.PROTOCOLDEVICEINFO.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}?deviceType=${deviceType}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}
function getAdherenceResetHistory(payload) {
  const url = API.ADHERENCERESETHISTORY.replace('{PATIENTID}', payload.id);
  return authRequest({
    url: `${url}?&page=${payload.page}&per_page=${payload.perPage}&deviceType=${payload.device
      }`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function deleteDeviceService(patientID, deviceType, serialNumber) {
  const url = API.DELETEDEVICEREQUEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}/${serialNumber}?deviceType=${deviceType}`,
    method: 'DELETE',
    headers: {
      accept: 'application/json'
    },
    [constants.RETURNRESPONSE]: true
  });
}

function resetAdherenceService(payload) {
  const startDate = `${payload.resetStartDate.getFullYear()}-${payload.resetStartDate.getMonth() +
    1}-${payload.resetStartDate.getDate()}`;
  const url = API.RESETADHERENCE;
  return authRequest({
    url: `${url}`,
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: JSON.stringify({
      createdBy: payload.createdBy,
      userId: payload.userId,
      patientId: payload.patientId,
      resetStartDate: startDate,
      resetScore: payload.resetScore,
      justification: payload.justification,
      deviceType: payload.deviceType
    }),
    [constants.RETURNRESPONSE]: true
  });
}

function deleteProtocolService(payload) {
  const patientID = payload.id;
  const deviceType = payload.devicetype;
  const protocolId = payload.protocolID;
  const url = API.DELETEPROTOCOLREQUEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}/${protocolId}?deviceType=${deviceType}`,
    method: 'DELETE',
    [constants.RETURNRESPONSE]: true
  });
}

function getJustificationResetService() {
  return authRequest({
    url: API.JUSTIFICATION_OPTIONS,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function upload_RTPTherapy_ServiceTitan(payload) {
  const url = API.UPLOADRTPTHERAPY;
  return authRequest({
    url: `${url}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: JSON.stringify({
      therapyName: payload.therapyName,
      therapyParam: payload.therapyParam,
      caughPauseSetting: payload.caughPauseSetting,
      therapyType: payload.therapyType,
      deviceType: payload.deviceType,
      status: payload.status,
      patientId: payload.patientId,
      emailId: payload.emailId,
      isDeleted: payload.isDeleted
    }),
    [constants.RETURNRESPONSE]: true
  });
}

function getRTUSettingHistory(patientID) {
  const url = API.RTUHISTORY.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

const ProtocolDevice = {
  getProtocolDevice,
  getDeviceInformation,
  getAdherenceResetHistory,
  getPatientService,
  deleteDeviceService,
  resetAdherenceService,
  deleteProtocolService,
  getJustificationResetService,
  upload_RTPTherapy_ServiceTitan,
  getRTUSettingHistory
};

export default ProtocolDevice;
