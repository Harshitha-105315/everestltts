import constants from 'constants.js';
import { setStateByKey } from 'utils/helper.js';

const initialState = {
  message: '',
  editProtocolData: {
    protocol: [
      {
        createdBy: '',
        createdDate: '',
        lastModifiedDate: '',
        id: '',
        type: '',
        treatmentsPerDay: '',
        minMinutesPerTreatment: '',
        treatmentLabel: '',
        minFrequency: '',
        maxFrequency: '',
        minPressure: '',
        maxPressure: '',
        minIntensity: '',
        maxIntensity: '',
        deleted: '',
        protocolKey: '',
        deviceType: '',
        hmr: ''
      }
    ]
  },
  checkPassword: false,
  status: false
};

function editProtocolReducer(state = initialState, action) {
  const tmpState = Object.assign({}, state);
  if (action.type === constants.DEVICE.STORE_EDIT_PROTOCOL) {
    tmpState.editProtocolData = setStateByKey(
      tmpState.editProtocolData,
      action.key,
      action.data
    );
    return tmpState;
  }
  if (action.type === constants.DEVICE.ADD_NEW_PROTOCOL_MONARCH_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.DEVICE.ADD_NEW_PROTOCOL_TITAN_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.DEVICE.ADD_NEW_PROTOCOL_VEST_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.DEVICE.UPDATE_PROTOCOL_MONARCH_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.DEVICE.UPDATE_PROTOCOL_TITAN_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.DEVICE.UPDATE_PROTOCOL_VEST_SUCCESS) {
    tmpState.message = action.message;
    return tmpState;
  }
  if (action.type === constants.STORE_CHECK_RESULT) {
    tmpState.checkPassword = true;
    tmpState.status = action.data;
    return tmpState;
  }
  if (action.type === constants.RESET_CHECK_PASSWORD) {
    tmpState.checkPassword = false;
    tmpState.status = false;
    return tmpState;
  }
  if (action.type === constants.DEVICE.EDIT_PROTOCOL_DATA) {
    tmpState.editProtocolData[action.data.protocolid].protocol[
      action.data.key
    ].deleted = true;
    return tmpState;
  }
  return state;
}
export { initialState };
export default editProtocolReducer;
