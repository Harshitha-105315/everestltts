import React, { Component } from 'react';
import './PopupScreen.scss';
import reload from 'assets/img/reload.png';
import close from 'assets/img/close.png';
import { getUserData } from 'utils/helper';
import { disableBodyScroll, enableBodyScroll } from 'body-scroll-lock';
import { connect } from 'react-redux';
import constants from 'constants.js';
import { Font } from '@react-pdf/renderer';
import Sailec from '../../assets/fonts/Sailec.ttf';
import { decryptemail } from '../../Cryptocode';

function alphanumeric_unique() {
  return Math.random()
    .toString(36)
    .split('')
    .filter(function(value, index, self) {
      return self.indexOf(value) === index;
    })
    .join('')
    .substr(2, 8);
}

function disableBody() {
  const mainElement = document.getElementsByClassName('main-app');
  disableBodyScroll(mainElement[0]);
}

function enableBody() {
  const mainElement = document.getElementsByClassName('main-app');
  enableBodyScroll(mainElement[0]);
}
class PopupScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      captchaText: '',
      captchaValue: '',
      errorMessage: '',
      email: '',
      password: ''
    };
  }
  componentWillMount() {
    this.setState({ captchaText: alphanumeric_unique() });
    const { dispatch } = this.props;
    dispatch({ type: constants.RESET_CHECK_PASSWORD });
  }
  reloadCaptcha = () => {
    this.setState({
      captchaText: alphanumeric_unique(),
      errorMessage: '',
      captchaValue: ''
    });
    const { dispatch } = this.props;
    dispatch({ type: constants.RESET_CHECK_PASSWORD });
  };
  componentWillReceiveProps(newProps) {
    if (newProps.checkPassword) {
      if (newProps.status) {
        this.props.generatePdf();
      } else {
        this.setState({ errorMessage: 'Password is incorrect' });
      }
    }
  }
  savePrescription = () => {
    if (this.state.password === '' || this.state.captchaValue === '') {
      return;
    } else {
      const userData = getUserData();
      const { dispatch } = this.props;
      if (this.state.captchaValue === '') {
        this.setState({ errorMessage: 'Enter captcha text' });
      } else if (this.state.password === '') {
        this.setState({ errorMessage: 'Enter password' });
      } else if (this.state.captchaValue !== this.state.captchaText) {
        this.setState({ errorMessage: 'Wrong captcha text' });
      } else {
        this.setState({ checkVerification: true });
        const data = {
          username: userData.user.email,
          password: this.state.password
        };
        dispatch({ type: constants.CHECK_PASSWORD, data: data });
      }
    }
  };
  captchaChange = e => {
    this.setState({ captchaValue: e.target.value });
  };
  passwordChange = e => {
    this.setState({ password: e.target.value });
  };
  close = () => {
    this.props.close();
  };
  componentDidMount() {
    const userData = getUserData();
    this.setState({ email: userData.user.email });
    window.scrollTo(0, 0);
    disableBody();
    Font.register({
      family: 'Sailec',
      fontWeight: 400,
      fontStyle: 'normal',
      src: Sailec
    });
  }
  componentWillUnmount() {
    enableBody();
  }
  render() {
    let highlight = false;
    if (this.state.password !== '' && this.state.captchaValue !== '') {
      highlight = true;
    }
    return (
      <div className="background">
        <div className="popup-container">
          <img
            className="close"
            alt="close"
            onClick={this.close.bind(this)}
            src={close}
          />
          <div className="heading">Login Verification</div>
          <div className="message">
            We need to verify that you are not a robot, but a human being!
          </div>
          <div className="row">
            <div className="cell">
              <div className="label">EMAIL ADDRESS</div>
              <input
                className="content email"
                type="email"
                value={this.state.email ? decryptemail(this.state.email) : this.state.email}
                readOnly={true}
              />
            </div>
            <div className="cell">
              <div className="label">PASSWORD</div>
              <input
                className="content password"
                type="password"
                value={this.state.password}
                onChange={this.passwordChange.bind(this)}
              />
            </div>
          </div>
          <div className="row">
            <div className="cell">
              <div className="label">CAPTCHA</div>
              <input
                value={this.state.captchaValue}
                onChange={this.captchaChange.bind(this)}
                className="content captcha"
              />
              {this.state.errorMessage === '' && (
                <div className="captcha-message">
                  Please enter the captcha from picture on the right.
                </div>
              )}
              {this.state.errorMessage !== '' && (
                <div className="errorMessage">{this.state.errorMessage}</div>
              )}
            </div>
            <div className="cell-captcha">
              <div className="captcha-text">{this.state.captchaText}</div>
              <img
                src={reload}
                className="reload"
                alt="reload"
                onClick={this.reloadCaptcha.bind(this)}
              />
            </div>
          </div>
          <div className="confirm-container">
            <div
              className={highlight ? 'highlight confirm' : 'confirm'}
              onClick={this.savePrescription.bind(this)}
            >
              CONFIRM AND GENERATE
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { editProtocolReducer } = state.app;
  return {
    status: editProtocolReducer.status,
    checkPassword: editProtocolReducer.checkPassword
  };
};

export default connect(mapStateToProps)(PopupScreen);
