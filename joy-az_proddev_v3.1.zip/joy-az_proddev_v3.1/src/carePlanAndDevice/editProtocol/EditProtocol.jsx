import React, { Component } from 'react';
import { connect } from 'react-redux';
import { isEmpty } from 'lodash';
import { Form, Col } from 'react-bootstrap';
import NumberFormat from 'react-number-format';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import constants from 'constants.js';
import { Header, SideBar } from 'components/Navigation';
import ConfirmationDialog from 'components/ConfirmationDialog';
import urls from 'urls';
import { FootNote } from 'components/FootNote';
import { reverse } from 'named-urls';
import strings from '../../localization/strings';
import './editProtocol.scss';
import {
  getBreadCrumb,
  addBreadCrumb,
  removeBreadCrumb
} from '../../utils/utltity';
import ButtonComponent from 'components/ButtonComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { initialState } from './reducers';
import { getUserData } from 'utils/helper';
import UpdatePrescription from './UpdatePrescription';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getDeviceTypeText } from 'patient/helper';
import { getNumberRangeOptions } from 'utils/helper';
import { decryptemail } from '../../Cryptocode';

class AddProtocol extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: '',
      error: '',
      protocols: [
        {
          createdBy: '',
          createdDate: '',
          lastModifiedDate: '',
          id: '',
          type: '',
          treatmentsPerDay: '',
          minMinutesPerTreatment: '',
          treatmentLabel: '',
          minFrequency: '',
          maxFrequency: '',
          minPressure: '',
          maxPressure: '',
          minIntensity: '',
          maxIntensity: '',
          deleted: '',
          protocolKey: '',
          deviceType: '',
          hmr: ''
        }
      ],
      isDirty: false,
      isDeleted: false,
      newPoint: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      },
      showUpdatePrescription: false,
      isModified: false
    };
    this.baseState = this.state;
    this.handleTreatmentsPerDayChange = this.handleTreatmentsPerDayChange.bind(
      this
    );
    this.handleChangeRadio = this.handleChangeRadio.bind(this);
    this.handleOnClick = this.handleOnClick.bind(this);
    this.handleProtocolChange = this.handleProtocolChange.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
  }

  componentWillMount() {
    const { match } = this.props;
    const { id, protocolid, devicetype, type } = match.params;
    this.getProtocolData(id, protocolid, devicetype, type);
  }

  componentDidMount() {
    this.addBreadCrumb({ title: strings.editProtocol });
  }

  componentWillReceiveProps(nextProps) {
    const { editProtocolData } = this.props;
    if (nextProps.editProtocolData !== editProtocolData) {
      let protocolsData = nextProps.editProtocolData.protocol;
      protocolsData = protocolsData.map(protocol => {
        const data = { ...protocol };
        data.createdBy = decryptemail(data.createdBy)
        if (
          data.maxFrequency === data.minFrequency ||
          data.maxFrequency === null
        ) {
          data.maxFrequency = '';
        }
        if (data.deviceType === constants.DEVICE_TYPE_CODE.VISIVEST || data.deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
          if (
            data.maxPressure === data.minPressure ||
            data.maxPressure === null
          ) {
            data.maxPressure = '';
          }
        }
        if (data.deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
          if (
            data.maxIntensity === data.minIntensity ||
            data.maxIntensity === null
          ) {
            data.maxIntensity = '';
          }
        }
        if (data.deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
          if (
            data.maxIntensity === data.minIntensity ||
            data.maxIntensity === null
          ) {
            data.maxIntensity = '';
          }
        }
        return data;
      });
      this.setState({ protocols: protocolsData });
    }
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
    this.removeBreadCrumb();
  }

  handleChangeRadio = event => {
    this.setState({
      type: event.target.value
    });
  };

  handleTreatmentsPerDayChange = (evt, key) => {
    const { protocols, type } = this.state;
    const newProtocol = protocols.map((protocol, sidx) => {
      if (key !== sidx) {
        return protocol;
      }
      return {
        ...protocol,
        [evt.target.name]:
          evt.target.value !== '' ? parseInt(evt.target.value) : '',
        type
      };
    });
    this.setState({ protocols: newProtocol, isDirty: true });
  };

  handleProtocolChange = (evt, idx) => {
    const { protocols, type } = this.state;
    const newProtocol = protocols.map((protocol, sidx) => {
      if (idx !== sidx) {
        return protocol;
      }
      if (type === constants.PROTOCOL_TYPES.CUSTOM) {
        return {
          ...protocol,
          [evt.target.name]:
            evt.target.value !== '' ? parseInt(evt.target.value) : '',
          type,
          treatmentLabel: `point${sidx + 1}`
        };
      }
      return {
        ...protocol,
        [evt.target.name]:
          evt.target.value !== '' ? parseInt(evt.target.value) : '',
        type
      };
    });
    this.setState({ protocols: newProtocol, isDirty: true, isModified: true });
  };

  lastModifiedDate = () => {
    const tempDate = new Date();
    let date = `${tempDate.getDate()}/${tempDate.getMonth() +
      1}/${tempDate.getFullYear()}`;
    date = date.split('/');
    const newDate = `${date[1]}/${date[0]}/${date[2]}`;
    return new Date(newDate).getTime();
  };

  handleAddNewpoints = () => {
    const { protocols } = this.state;
    this.setState({
      protocols: protocols.concat([
        {
          minMinutesPerTreatment: '',
          minFrequency: '',
          maxFrequency: '',
          minIntensity: '',
          maxIntensity: '',
          minPressure: '',
          maxPressure: '',
          treatmentLabel: ''
        }
      ]),
      isDirty: true,
      newPoint: true
    });
  };

  getProtocolData = (id, protocolid, devicetype, type) => {
    const { dispatch } = this.props;
    this.setState({ type });
    dispatch({
      type: constants.DEVICE.EDIT_PROTOCOL,
      data: { devicetype, id, protocolid }
    });
  };
  handleCloseDialog = () => {
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };
  updatePrescription = blob => {
    this.handleUpdateProtocolDispatch(blob);
    this.setState({ showUpdatePrescription: false });
  };

  checkForUpdate = () => {
    let propsData = this.props.editProtocolData.protocol;
    let stateData = this.state.protocols;
    let updated = false;
    if (stateData.length && propsData.length) {
      if (stateData[0].type === propsData[0].type) {
        for (let index = 0; index < propsData.length; index++) {
          let prop = propsData[index];
          let state = stateData[index];
          if (prop['maxFrequency'] !== state['maxFrequency']) {
            updated = true;
          }
          if (prop['minFrequency'] !== state['minFrequency']) {
            updated = true;
          }
          if (propsData[0].deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
            if (prop['maxIntensity'] !== state['maxIntensity']) {
              updated = true;
            }
            if (prop['minIntensity'] !== state['minIntensity']) {
              updated = true;
            }
          } else if (
            propsData[0].deviceType === constants.DEVICE_TYPE_CODE.VISIVEST
          ) {
            if (prop['maxPressure'] !== state['maxPressure']) {
              updated = true;
            }
            if (prop['minPressure'] !== state['minPressure']) {
              updated = true;
            }
          }
          if (
            prop['minMinutesPerTreatment'] !== state['minMinutesPerTreatment']
          ) {
            updated = true;
          }
          if (index === 0) {
            if (prop['treatmentsPerDay'] !== state['treatmentsPerDay']) {
              updated = true;
            }
          }
        }
      } else {
        updated = true;
      }
    }

    return updated;
  };

  handleUpdateProtocol = e => {
    const { dialog } = this.state;
    const updatedFlag = this.checkForUpdate();
    if (!updatedFlag && !this.state.isDeleted && !this.state.newPoint) {
      this.setState({
        dialog: Object.assign(dialog, {
          body:
            'You have not made any changes in the protocol. You must make an update in the protocol before the protocol can be authorized in Connex.',
          title: 'Alert !!',
          button: 'Continue',
          show: true,
          confirmFunction: this.handleCloseDialog
        })
      });
    } else if (!this.state.protocols.length) {
      this.setState({
        dialog: Object.assign(dialog, {
          body: 'Please add at least one point',
          title: 'Alert !!',
          button: 'Continue',
          show: true,
          confirmFunction: this.handleCloseDialog
        })
      });
    } else {
      const { actualRole } = getUserData();
      const { match } = this.props;
      const { devicetype } = match.params;
      const { protocols } = this.state;
      this.setState({ error: '' });
      let flag = true;
      protocols.map(protocol => {
        if (!protocol.deleted) {
          if (devicetype === constants.DEVICE_TYPE_CODE.MONARCH) {
            if (
              protocol.maxIntensity !== '' &&
              protocol.maxIntensity !== false &&
              (protocol.maxIntensity < Number(protocol.minIntensity) ||
                protocol.maxIntensity > 10)
            ) {
              this.setState({
                error: this.placeholderText(
                  protocol.minIntensity,
                  1,
                  10,
                  'Maximum intensity',
                  'Maximum intensity'
                )
              });
              flag = false;
            }
            if (protocol.minIntensity === '') {
              this.setState({ error: `${strings.minimumIntensityRequired}` });
              flag = false;
            } else if (
              protocol.minIntensity < 1 ||
              protocol.minIntensity > 10
            ) {
              this.setState({
                error: `${strings.minimumIntensityBetween1to10}`
              });
              flag = false;
            }
          } else if (devicetype === constants.DEVICE_TYPE_CODE.VISIVEST) {
            if (
              protocol.maxPressure !== '' &&
              protocol.maxPressure !== false &&
              (protocol.maxPressure < Number(protocol.minPressure) ||
                protocol.maxPressure > 10)
            ) {
              this.setState({
                error: this.placeholderText(
                  protocol.minPressure,
                  1,
                  10,
                  'Maximum pressure',
                  'Maximum pressure'
                )
              });
              flag = false;
            }
            if (protocol.minPressure === '') {
              this.setState({ error: `${strings.minimumPressureRequired}` });
              flag = false;
            } else if (protocol.minPressure < 1 || protocol.minPressure > 10) {
              this.setState({
                error: `${strings.minimumPressureBetween1to10}`
              });
              flag = false;
            }
          }
          if (
            protocol.maxFrequency !== '' &&
            protocol.maxFrequency !== false &&
            (protocol.maxFrequency < Number(protocol.minFrequency) ||
              protocol.maxFrequency > 20)
          ) {
            this.setState({
              error: this.placeholderText(
                protocol.minFrequency,
                5,
                20,
                'Maximum frequency',
                'Maximum frequency'
              )
            });
            flag = false;
          }
          if (protocol.minFrequency === '') {
            this.setState({ error: `${strings.minimumFrequencyRequired}` });
            flag = false;
          } else if (protocol.minFrequency < 5 || protocol.minFrequency > 20) {
            this.setState({ error: `${strings.minimumFrequencyBetween5to20}` });
            flag = false;
          }
          if (protocol.minMinutesPerTreatment === '') {
            this.setState({ error: `${strings.minimumMinutesRequired}` });
            flag = false;
          } else if (
            protocol.minMinutesPerTreatment < 1 ||
            protocol.minMinutesPerTreatment > 99
          ) {
            this.setState({ error: `${strings.minimumMinutesBetween1to99}` });
            flag = false;
          }
          if (protocol.treatmentsPerDay === '') {
            this.setState({ error: `${strings.protocolTreatmentRequired}` });
            flag = false;
          } else if (
            protocol.treatmentsPerDay < 1 ||
            protocol.treatmentsPerDay > 9
          ) {
            this.setState({ error: `${strings.protocolTreatmentBetween1to9}` });
            flag = false;
          }
        }
        return true;
      });

      if (flag) {
        const prescriptionRequired =
          accessMatrix.PATIENT_PROTOCOL_UPDATE_PRESCRIPTION_REQUIRED[
          actualRole
          ];
        if (prescriptionRequired.write) {
          this.setState({
            dialog: Object.assign(dialog, {
              body:
                'You must authorize an update to the prescription before the protocol can be updated in Connex. You will need the prescriber to electronically sign the updated prescription.',
              title: 'Update prescription',
              button: 'Authorize Updated Prescription',
              confirmFunction: this.handleUpdatePrescription,
              show: true
            })
          });
        } else {
          this.setState({
            dialog: Object.assign(dialog, {
              body: strings.updateProtocolDialogBody,
              title: strings.protocolUpdate,
              button: strings.update,
              confirmFunction: this.handleUpdateProtocolDispatch,
              show: true
            })
          });
        }
      }
    }
  };

  handleUpdatePrescription = () => {
    const { dialog } = this.state;
    this.setState({
      showUpdatePrescription: true,
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  toggleScreen = () => {
    this.setState({ showUpdatePrescription: false });
  };

  handleUpdateProtocolDispatch = blob => {
    const { actualRole } = getUserData();
    const { dispatch, match } = this.props;
    const { id } = match.params;
    const { protocols, dialog } = this.state;
    const history = this.props.history;
    let path = '';
    const prescriptionRequired =
      accessMatrix.PATIENT_PROTOCOL_UPDATE_PRESCRIPTION_REQUIRED[actualRole];
    if (prescriptionRequired.write) {
      path = reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id });
    }

    const protocoldata = protocols.map(protocol => {
      const data = { ...protocol };
      if (data.maxFrequency === '' || data.maxFrequency < data.minFrequency) {
        data.maxFrequency = data.minFrequency;
      }
      if (data.deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
        if (data.maxIntensity === '' || data.maxIntensity < data.minIntensity) {
          data.maxIntensity = data.minIntensity;
        }
      }
      if (data.deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
        if (data.maxIntensity === '' || data.maxIntensity < data.minIntensity) {
          data.maxIntensity = data.minIntensity;
        }
      }
      if (data.deviceType === constants.DEVICE_TYPE_CODE.VISIVEST) {
        if (data.maxPressure === '' || data.maxPressure < data.minPressure) {
          data.maxPressure = data.minPressure;
        }
      }
      return data;
    });
    let protocldata = [];
    protocoldata.map(protocol => {
      if (!protocol.deleted || protocol.id) {
        protocldata.push(protocol);
      }
      return protocldata;
    });
    if (protocols.length) {
      if (protocols[0].deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
        dispatch({
          type: constants.DEVICE.EDIT_PROTOCOL_REQUEST_MONARCH,
          data: {
            id,
            protocldata,
            path,
            history,
            blob: blob instanceof Blob ? blob : null
          }
        });
      } else if (protocols[0].deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
        dispatch({
          type: constants.DEVICE.EDIT_PROTOCOL_REQUEST_TITAN,
          data: {
            id,
            protocldata,
            path,
            history,
            blob: blob instanceof Blob ? blob : null
          }
        });
      } else {
        dispatch({
          type: constants.DEVICE.EDIT_PROTOCOL_REQUEST_VEST,
          data: {
            id,
            protocldata,
            path,
            history,
            blob: blob instanceof Blob ? blob : null
          }
        });
      }
    }
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  handleCancelProtocol = e => {
    const { history } = this.props;
    const { match } = this.props;
    const { id } = match.params;
    e.preventDefault();
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  async handleOnClick(event) {
    const { editProtocolData } = this.props;
    const { protocols } = this.state;
    const type = event.target.value;
    if (
      !isEmpty(editProtocolData) &&
      !isEmpty(editProtocolData.protocol) &&
      editProtocolData.protocol[0].type !== type
    ) {
      const data = protocols;
      const protocolEntries = [
        {
          createdBy: decryptemail(data[0].createdBy),
          createdDate: data[0].createdDate,
          lastModifiedDate: data[0].lastModifiedDate,
          id: data[0].id,
          type,
          treatmentsPerDay: data[0].treatmentsPerDay,
          minMinutesPerTreatment: '',
          treatmentLabel: '',
          minFrequency: '',
          maxFrequency: '',
          minPressure: '',
          maxPressure: '',
          minIntensity: '',
          maxIntensity: '',
          deleted: data[0].deleted,
          protocolKey: data[0].protocolKey,
          deviceType: data[0].deviceType,
          hmr: data[0].hmr ? data[0].hmr : null
        }
      ];
      this.setState({
        protocols: protocolEntries,
        type: event.target.value
      });
    } else {
      let protocolsData = [];
      if (!isEmpty(editProtocolData) && !isEmpty(editProtocolData.protocol)) {
        protocolsData = editProtocolData.protocol.map(protocol => {
          const data = { ...protocol };
          if (
            data.maxFrequency === data.minFrequency ||
            data.maxFrequency === null
          ) {
            data.maxFrequency = '';
          }
          if (data.deviceType === constants.DEVICE_TYPE_CODE.VISIVEST) {
            if (
              data.maxPressure === data.minPressure ||
              data.maxPressure === null
            ) {
              data.maxPressure = '';
            }
          }
          if (data.deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
            if (
              data.maxIntensity === data.minIntensity ||
              data.maxIntensity === null
            ) {
              data.maxIntensity = '';
            }
          }
          if (data.deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
            if (
              data.maxIntensity === data.minIntensity ||
              data.maxIntensity === null
            ) {
              data.maxIntensity = '';
            }
          }
          return data;
        });
      }
      await this.setState({ protocols: protocolsData, isDirty: true });
    }
  }

  placeholderText = (value, minValue, maxValue, valueText, rangeText) => {
    let text = '';
    if (value === maxValue) {
      text = `${valueText} should be ${maxValue}`;
    } else {
      text = `${rangeText} between ${value === ''
        ? minValue
        : value >= minValue && value <= maxValue
          ? Number(value)
          : minValue
        } to ${maxValue}`;
    }
    return text;
  };

  handleDeletePoint = key => {
    const { protocols } = this.state;
    const { dispatch, editProtocolData } = this.props;
    if (protocols.length > 1) {
      protocols[key].deleted = true;
      this.setState({
        protocols: protocols,
        isDirty: true,
        isModified: true,
        isDeleted: true
      });
      if (editProtocolData.length >= key)
        dispatch({
          type: constants.DEVICE.EDIT_PROTOCOL_DATA,
          data: { key: key, protocolid: this.props.match.params.protocolid }
        });
    }
  };

  render() {
    const { protocols, error, type, dialog } = this.state;
    const {
      match,
      editProtocolData,
      breadcrumbs,
      location,
      history
    } = this.props;
    const { id, devicetype } = match.params;
    const sideBarData = {
      activeKey: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };
    const aliveProtocols = protocols.filter(protocol => !protocol.deleted);
    let protocolIndex = 0;
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {this.getBreadCrumb(breadcrumbs)}
            {!this.state.showUpdatePrescription && (
              <div>
                <h2>{strings.editProtocol}</h2>
                <Form.Row>
                  <Form.Group lg={4}>
                    <Form.Check
                      inline
                      custom
                      className="radio-button"
                      type="radio"
                      value="Normal"
                      label={strings.Manual}
                      onChange={this.handleChangeRadio}
                      name="type"
                      id="normal"
                      checked={type === constants.PROTOCOL_TYPES.NORMAL}
                      onClick={e => this.handleOnClick(e)}
                    />
                  </Form.Group>

                  <Form.Group lg={4}>
                    <Form.Check
                      inline
                      custom
                      className="radio-button"
                      type="radio"
                      value="Custom"
                      label={strings.Program}
                      onChange={this.handleChangeRadio}
                      id="custom"
                      name="type"
                      checked={type === constants.PROTOCOL_TYPES.CUSTOM}
                      onClick={e => this.handleOnClick(e)}
                    />
                  </Form.Group>
                </Form.Row>
                {!isEmpty(editProtocolData.protocol) &&
                  Object.keys(editProtocolData.protocol).map(key => (
                    <div key={Number(key) + 1}>
                      {key < 1 && (
                        <Form.Row>
                          <Form.Group as={Col} md={4}>
                            <Form.Label>{strings.selectDevice} <span className="asterisk-color">*</span> :</Form.Label>
                            <Form.Control
                              type="text"
                              name="deviceType"
                              defaultValue={getDeviceTypeText(
                                editProtocolData.protocol[key].deviceType
                              )}
                              required=""
                              disabled="disabled"
                            />
                          </Form.Group>
                        </Form.Row>
                      )}
                    </div>
                  ))}

                {!isEmpty(aliveProtocols) &&
                  aliveProtocols.map((protocol, key) => (
                    <div key={Number(key) + 1}>
                      {key < 1 && (
                        <Form.Row>
                          <Form.Group as={Col} md={4}>
                            <Form.Label>
                              {strings.treatmentsPerDay} <span className="asterisk-color">*</span> :
                            </Form.Label>

                            <Form.Control
                              as="select"
                              name="treatmentsPerDay"
                              onChange={e =>
                                this.handleTreatmentsPerDayChange(e, key)
                              }
                              value={protocol.treatmentsPerDay}
                              required
                            >
                              <option value="">
                                {strings.selectTreatmentPerDay}
                              </option>
                              {getNumberRangeOptions(1, 9)}
                            </Form.Control>
                          </Form.Group>
                        </Form.Row>
                      )}
                    </div>
                  ))}
                <Form>
                  {protocols.map((protocol, key) => {
                    if (protocol.deleted) return null;
                    protocolIndex = protocolIndex + 1;
                    return (
                      <div key={Number(key) + 1}>
                        <h4>
                          {type === constants.PROTOCOL_TYPES.CUSTOM
                            ? ` ${strings.point} ${Number(protocolIndex)}`
                            : ''}
                        </h4>
                        {type === constants.PROTOCOL_TYPES.CUSTOM &&
                          aliveProtocols.length > 1 && (
                            <ButtonComponent
                              buttonAction={this.handleDeletePoint.bind(
                                this,
                                key
                              )}
                              buttonText={strings.deletePoint}
                              style={{ marginBottom: '20px' }}
                            />
                          )}

                        <Form.Row>
                          <Form.Group as={Col} md={4}>
                            <Form.Label>
                              {strings.minMinutesPerTreatment} <span className="asterisk-color">*</span> :
                            </Form.Label>
                            <NumberFormat
                              className="form-control"
                              name="minMinutesPerTreatment"
                              value={protocol.minMinutesPerTreatment}
                              placeholder="Range between 1 to 99"
                              onChange={e => this.handleProtocolChange(e, key)}
                              required
                              isAllowed={values => {
                                const { formattedValue, floatValue } = values;
                                return (
                                  formattedValue === '' || floatValue <= 99
                                );
                              }}
                            />
                          </Form.Group>
                        </Form.Row>
                        <Form.Row>
                          <Form.Group as={Col} md={4}>
                            <Form.Label>{strings.minFrequency} <span className="asterisk-color">*</span> :</Form.Label>
                            <Form.Control
                              as="select"
                              name="minFrequency"
                              value={protocol.minFrequency}
                              onChange={e => this.handleProtocolChange(e, key)}
                              required
                            >
                              <option value="">
                                {strings.selectMinFrequency}
                              </option>
                              {getNumberRangeOptions(
                                5,
                                protocol.maxFrequency
                                  ? protocol.maxFrequency - 1
                                  : 20
                              )}
                            </Form.Control>
                          </Form.Group>

                          <Form.Group as={Col} md={4}>
                            <Form.Label>{strings.maxFrequency} :</Form.Label>
                            <Form.Control
                              as="select"
                              name="maxFrequency"
                              value={protocol.maxFrequency}
                              onChange={e => this.handleProtocolChange(e, key)}
                              disabled={protocol.minFrequency === 20}
                            >
                              <option value="">
                                {strings.selectMaxFrequency}
                              </option>
                              {getNumberRangeOptions(
                                protocol.minFrequency
                                  ? protocol.minFrequency + 1
                                  : 6,
                                20
                              )}
                            </Form.Control>
                          </Form.Group>
                        </Form.Row>
                        <Form.Row>
                          {devicetype ===
                            constants.DEVICE_TYPE_CODE.VISIVEST ? (
                              <Form.Group as={Col} md={4}>
                                <Form.Label>{strings.minPressure} <span className="asterisk-color">*</span> :</Form.Label>
                                <Form.Control
                                  as="select"
                                  name="minPressure"
                                  value={protocol.minPressure}
                                  onChange={e =>
                                    this.handleProtocolChange(e, key)
                                  }
                                >
                                  <option value="">
                                    {strings.selectMinPressure}
                                  </option>
                                  {getNumberRangeOptions(
                                    1,
                                    protocol.maxPressure
                                      ? protocol.maxPressure - 1
                                      : 10
                                  )}
                                </Form.Control>
                              </Form.Group>
                            ) : (
                              <Form.Group as={Col} md={4}>
                                <Form.Label>
                                  {strings.minIntensity} <span className="asterisk-color">*</span> :
                                </Form.Label>
  
                                <Form.Control
                                  as="select"
                                  name="minIntensity"
                                  value={protocol.minIntensity}
                                  onChange={e =>
                                    this.handleProtocolChange(e, key)
                                  }
                                >
                                  <option value="">
                                    {strings.selectMinIntensity}
                                  </option>
                                  {getNumberRangeOptions(
                                    1,
                                    protocol.maxIntensity
                                      ? protocol.maxIntensity - 1
                                      : 10
                                  )}
                                </Form.Control>
                              </Form.Group>
                            )}

                          {devicetype ===
                            constants.DEVICE_TYPE_CODE.VISIVEST ? (
                              <Form.Group as={Col} md={4}>
                                <Form.Label>{strings.maxPressure} :</Form.Label>

                                <Form.Control
                                  as="select"
                                  name="maxPressure"
                                  value={protocol.maxPressure}
                                  onChange={e =>
                                    this.handleProtocolChange(e, key)
                                  }
                                  disabled={protocol.minPressure === 10}
                                >
                                  <option value="">
                                    {strings.selectMaxPressure}
                                  </option>
                                  {getNumberRangeOptions(
                                    protocol.minPressure
                                      ? protocol.minPressure + 1
                                      : 2,
                                    10
                                  )}
                                </Form.Control>
                              </Form.Group>
                            ) : (
                              <Form.Group as={Col} md={4}>
                                <Form.Label>{strings.maxIntensity} :</Form.Label>

                                <Form.Control
                                  as="select"
                                  name="maxIntensity"
                                  value={protocol.maxIntensity}
                                  onChange={e =>
                                    this.handleProtocolChange(e, key)
                                  }
                                  disabled={protocol.minIntensity === 10}
                                >
                                  <option value="">
                                    {strings.selectMaxIntensity}
                                  </option>
                                  {getNumberRangeOptions(
                                    protocol.minIntensity
                                      ? protocol.minIntensity + 1
                                      : 2,
                                    10
                                  )}
                                </Form.Control>
                              </Form.Group>
                            )}
                        </Form.Row>
                      </div>
                    );
                  })}
                </Form>
                <p className="text-danger" id="error">
                  {error}
                </p>
                {type === constants.PROTOCOL_TYPES.CUSTOM && (
                  <ButtonComponent
                    buttonClass=""
                    buttonAction={this.handleAddNewpoints}
                    icon="report-icon"
                    buttonText={strings.addNewPoint}
                  />
                )}
                <div className="d-flex flex-sm-row justify-content-end">
                  {!isEmpty(editProtocolData) && (
                    <ButtonComponent
                      buttonClass="ml-2 mt-3"
                      buttonAction={e => this.handleUpdateProtocol(e)}
                      icon="right-arrow"
                      buttonText={strings.update}
                    />
                  )}
                  <ButtonComponent
                    buttonClass="ml-2 mt-3"
                    buttonAction={this.handleCancelProtocol}
                    icon="cancel-icon"
                    buttonText={strings.cancel}
                  />
                </div>
              </div>
            )}
            {this.state.showUpdatePrescription && (
              <UpdatePrescription
                id={match.params.id}
                toggleScreen={this.toggleScreen.bind(this)}
                updatePrescription={this.updatePrescription.bind(this)}
                devicetype={match.params.devicetype}
                protocols={this.state.protocols}
              />
            )}
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { editProtocolReducer, breadcrumbsReducer } = state.app;
  const { match } = ownProps;
  const { protocolid } = match.params;
  return {
    editProtocolData:
      editProtocolReducer.editProtocolData[protocolid] ||
      initialState.editProtocolData,
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};
export default connect(mapStateToProps)(AddProtocol);
