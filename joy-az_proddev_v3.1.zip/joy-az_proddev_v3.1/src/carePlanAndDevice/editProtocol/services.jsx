import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function editProtocolDevice(patientID, deviceType, protocolID) {
  const url = API.EDITPROTOCOL.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}/${protocolID}?deviceType=${deviceType}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function checkPassword(data) {
  const url = API.CHECK_PASSWORD;
  return authRequest({
    url: `${url}`,
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: data,
    [constants.RETURNRESPONSE]: true
  });
}

function updateProtocolServiceMonarch(payload) {
  const patientID = payload.id;
  const url = API.UPDATEPROTOCOLMONARCH.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: payload.protocldata,
    [constants.RETURNRESPONSE]: true
  });
}

function updateProtocolServiceTitan(payload) {
  const patientID = payload.id;
  const url = API.UPDATEPROTOCOLTITAN.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: payload.protocldata,
    [constants.RETURNRESPONSE]: true
  });
}

function updateProtocolServiceVest(payload) {
  const patientID = payload.id;
  const url = API.UPDATEPROTOCOLVEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'PUT',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: payload.protocldata,
    [constants.RETURNRESPONSE]: true
  });
}

function addProtocolMonarchService(payload) {
  const patientID = payload.id;
  const url = API.ADDPROTOCOLMONARCH.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: {
      type: payload.type,
      treatmentsPerDay: payload.treatmentsPerDay,
      protocolEntries: payload.protocols
    },
    [constants.RETURNRESPONSE]: true
  });
}

function addProtocolTitanService(payload) {
  const patientID = payload.id;
  const url = API.ADDPROTOCOLTITAN.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: {
      type: payload.type,
      treatmentsPerDay: payload.treatmentsPerDay,
      protocolEntries: payload.protocols
    },
    [constants.RETURNRESPONSE]: true
  });
}

function addNewProtocolVestService(payload) {
  const patientID = payload.id;
  const url = API.ADDPROTOCOLVEST.replace('{PATIENTID}', patientID);
  return authRequest({
    url: `${url}`,
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    data: {
      type: payload.type,
      treatmentsPerDay: payload.treatmentsPerDay,
      protocolEntries: payload.protocols
    },
    [constants.RETURNRESPONSE]: true
  });
}

const EditProtocol = {
  editProtocolDevice,
  updateProtocolServiceMonarch,
  updateProtocolServiceTitan,
  updateProtocolServiceVest,
  addProtocolMonarchService,
  addProtocolTitanService,
  addNewProtocolVestService,
  checkPassword
};

export default EditProtocol;
