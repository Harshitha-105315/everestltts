import React, { Component } from 'react';
import strings from '../../localization/strings';
import visiVestLogo from 'assets/img/logo/visivest.png';
import monarchLogo from 'assets/img/logo/monarch.png';
import titanlogo from 'assets/img/logo/titanlogo.png';
import check from 'assets/img/check.png';
import unCheck from 'assets/img/unCheck.png';
import { connect } from 'react-redux';
import constants from 'constants.js';
import './UpdatePrescription.scss';
import moment from 'moment-timezone';
import { getUserData } from 'utils/helper';
import PopupScreen from './PopupScreen';
import { PDFDownloadLink } from '@react-pdf/renderer';
import Pdf from 'pdf-files/PrescriptionPdf';
import urls from '../../urls';
import { Link } from 'react-router-dom';
import { getProtocolTypeLabel } from 'patient/helper';

class UpdatePrescription extends Component {
  constructor(props) {
    super(props);
    this.state = {
      check: false,
      showPopup: false,
      downloadPdf: false,
      patientName: '',
      patientDob: '',
      prescriberName: ''
    };
  }
  saveFileAsPdf = blob => {
    this.setState({ downloadPdf: false });
    this.props.updatePrescription(blob);
  };
  protocolData() {
    const newProtocol = this.props.protocols;
    const deviceRef = {
      VEST: ['VisiVest', visiVestLogo, 'visivest'],
      MONARCH: ['Monarch', monarchLogo, 'monarch'],
      TITAN: ['Titan', titanlogo, 'titan']
    };
    if (newProtocol) {
      return newProtocol.map((newPro, index) => {
        return (
          <tr key={Number(index)}>
            {index === 0 && (
              <td
                rowSpan={newProtocol.length}
                className="protocol-table-row-span d-none d-sm-table-cell"
              >
                <img
                  src={deviceRef[newPro.deviceType][1]}
                  width="32"
                  height="32"
                  alt={deviceRef[newPro.deviceType][0]}
                />
              </td>
            )}
            <td className="align-middle">
              {getProtocolTypeLabel(newPro.type, newPro.treatmentLabel)}
            </td>
            {index === 0 && (
              <td rowSpan={newProtocol.length} className="rowspan">
                {newPro.treatmentsPerDay}
              </td>
            )}
            <td className="align-middle">{newPro.minMinutesPerTreatment}</td>
            <td className="align-middle">
              {newPro.minFrequency}
              {newPro.maxFrequency === newPro.minFrequency ||
              !newPro.maxFrequency
                ? ''
                : `-${newPro.maxFrequency}`}
            </td>
            {newPro.deviceType === 'VEST' ? (
              <td className="align-middle">
                {newPro.minPressure}
                {newPro.maxPressure === newPro.minPressure ||
                !newPro.maxPressure
                  ? ''
                  : `-${newPro.maxPressure}`}
              </td>
            ) : (
              <td className="align-middle">
                {newPro.minIntensity}
                {newPro.maxIntensity === newPro.minIntensity ||
                !newPro.maxIntensity
                  ? ''
                  : `-${newPro.maxIntensity}`}
              </td>
            )}
          </tr>
        );
      });
    }
  }

  showPopup = () => {
    if (this.state.check) this.setState({ showPopup: true });
  };
  componentWillReceiveProps(newProps) {
    const { patient } = newProps;
    let patientName = patient.firstName + ' ' + patient.lastName;
    this.setState({ patientName, patientDob: patient.dob });
  }
  componentDidMount() {
    const { dispatch } = this.props;
    const userDetail = getUserData();
    const { patient } = this.props;
    let prescriberName =
      userDetail.user.firstName + ' ' + userDetail.user.lastName;
    let patientName = patient.firstName + ' ' + patient.lastName;
    this.setState({ prescriberName, patientName, patientDob: patient.dob });
    dispatch({
      type: constants.PATIENT.FETCH_PATIENT_DATA,
      data: { id: this.props.id }
    });
  }
  generatePdf = () => {
    this.setState({ downloadPdf: true, showPopup: false });
  };
  checkClick = () => {
    this.setState({ check: !this.state.check });
  };
  closeUpdate = () => {
    this.props.toggleScreen();
  };
  close = () => {
    this.setState({ showPopup: false });
  };
  render() {
    let url = unCheck;
    if (this.state.check) {
      url = check;
    }
    return (
      <div className="updatedPrescription-container">
        {this.state.showPopup && (
          <PopupScreen
            close={this.close.bind(this)}
            generatePdf={this.generatePdf.bind(this)}
          />
        )}
        {this.state.downloadPdf && (
          <div style={{ display: 'none' }}>
            <PDFDownloadLink
              id="pdf-dowload"
              className="downloadlink text-uppercase"
              document={
                <Pdf
                  patientName={this.state.patientName}
                  patientDob={this.state.patientDob}
                  prescriberName={this.state.prescriberName}
                  protocols={this.props.protocols}
                  devicetype={this.props.devicetype}
                />
              }
              fileName="Prescription.pdf"
            >
              {({ blob, loading }) => (loading ? '' : this.saveFileAsPdf(blob))}
            </PDFDownloadLink>
          </div>
        )}
        <div className="prescription-heading">Updated Prescription Form</div>
        <div className="details-container">
          <div className="heading">Details</div>
          <div className="details-row">
            <div className="cell-container">
              <div className="content-label">PATIENT NAME</div>
              <div className="content">{this.state.patientName}</div>
            </div>
            <div className="cell-container">
              <div className="content-label">PATIENT DOB</div>
              <div className="content">{this.state.patientDob}</div>
            </div>
          </div>
          <div className="details-row">
            <div className="cell-container">
              <div className="content-label">PRESCRIBER NAME</div>
              <div className="content">{this.state.prescriberName}</div>
            </div>
            <div className="cell-container">
              <div className="content-label">DATE</div>
              <div className="content">{moment().format('DD/MM/YYYY')}</div>
            </div>
          </div>
        </div>
        <div className="newProtocol-container">
          <div className="heading">New Protocol</div>
          <div className="card mobile-full-width-table">
            <table className="table text-center">
              <thead>
                <tr>
                  <th>{strings.device}</th>
                  <th>{strings.type}</th>
                  <th>{strings.treatmentsPerDay}</th>
                  <th>{strings.minutesPerTreatment}</th>
                  <th>{strings.frequencyPerTreatment}</th>
                  <th>{strings.pressurePerTreatment}</th>
                </tr>
              </thead>
              <tbody>{this.protocolData()}</tbody>
            </table>
          </div>
        </div>
        <div className="terms-continer">
          <img
            src={url}
            className="checkbox"
            alt=""
            onClick={this.checkClick.bind(this)}
          />
          <div className="message">
            I agree and give my consent by clicking on “I Accept” button.
          </div>
          <Link to={urls.DISCLOSURES} target="_blank" className="link">
            (Read Electronic Sign Disclosure and Consent)
          </Link>
        </div>
        <div className="buttons-container">
          <div className="cancel-button" onClick={this.closeUpdate.bind(this)}>
            CANCEL
          </div>
          <div
            className={
              this.state.check ? 'accept-button show' : 'accept-button'
            }
            onClick={this.showPopup.bind(this)}
          >
            I ACCEPT
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { protocolReducer, patient } = state.app;
  return {
    protocol: protocolReducer.protocolData[ownProps.id] || {},
    patient: patient.pData[ownProps.id] || {}
  };
};

export default connect(mapStateToProps)(UpdatePrescription);
