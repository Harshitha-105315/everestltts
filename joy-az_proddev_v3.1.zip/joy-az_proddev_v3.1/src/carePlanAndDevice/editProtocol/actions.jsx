import { put, call } from 'redux-saga/effects';
import constants from 'constants.js';
import strings from 'localization/strings';
import EditProtocol from './services';
import { getIVSalt, createEncryptedData } from 'utils/utltity';
import { saveAs } from 'file-saver';
import { reverse } from 'named-urls';
import urls from 'urls';

var AesUtil = require('utils/AesUtil');

function* editProtocolDevice(action) {
  const patientID = action.data.id;
  const deviceType = action.data.devicetype;
  const protocolID = action.data.protocolid;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const device = yield call(
      EditProtocol.editProtocolDevice,
      patientID,
      deviceType,
      protocolID
    );
    if (device && (device.status === 200 || device.status === 201)) {
      yield put({
        type: constants.DEVICE.STORE_EDIT_PROTOCOL,
        data: device.data,
        key: protocolID
      });
    } else {
      throw Object({ custom_message: device.data.ERROR || device.data.error });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateProtocolRequestMonarch(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      EditProtocol.updateProtocolServiceMonarch,
      action.data
    );
    yield put({
      type: constants.DEVICE.UPDATE_PROTOCOL_MONARCH_SUCCESS,
      message: response.data.message
    });
    if (response.status === 200) {
      if (action.data.blob) {
        saveAs(action.data.blob, 'Prescription Report.pdf');
      }
      if (action.data.path !== '') {
        action.data.history.push(action.data.path);
      }
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.message
      });
      if (action.data.path === '') {
        const { id, protocldata } = action.data;
        const { deviceType, type } = protocldata[0];
        const { protocolKey } = response.data.protocol[0];
        const path = reverse(
          urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT,
          {
            id,
            protocolid: protocolKey,
            devicetype: deviceType,
            type
          }
        );
        yield put({
          type: constants.BREADCRUMBS.BREADCRUMBS_UPDATE,
          data: { path }
        });
      }
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateProtocolRequestTitan(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      EditProtocol.updateProtocolServiceTitan,
      action.data
    );
    yield put({
      type: constants.DEVICE.UPDATE_PROTOCOL_TITAN_SUCCESS,
      message: response.data.message
    });
    if (response.status === 200) {
      if (action.data.blob) {
        saveAs(action.data.blob, 'Prescription Report.pdf');
      }
      if (action.data.path !== '') {
        action.data.history.push(action.data.path);
      }
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.message
      });
      if (action.data.path === '') {
        const { id, protocldata } = action.data;
        const { deviceType, type } = protocldata[0];
        const { protocolKey } = response.data.protocol[0];
        const path = reverse(
          urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT,
          {
            id,
            protocolid: protocolKey,
            devicetype: deviceType,
            type
          }
        );
        yield put({
          type: constants.BREADCRUMBS.BREADCRUMBS_UPDATE,
          data: { path }
        });
      }
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateProtocolRequestVest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      EditProtocol.updateProtocolServiceVest,
      action.data
    );
    yield put({
      type: constants.DEVICE.UPDATE_PROTOCOL_VEST_SUCCESS,
      message: response.data.message
    });
    if (response.status === 200) {
      if (action.data.blob) {
        saveAs(action.data.blob, 'Prescription Report.pdf');
      }
      if (action.data.path !== '') {
        action.data.history.push(action.data.path);
      }
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.message
      });
      if (action.data.path === '') {
        const { id, protocldata } = action.data;
        const { deviceType, type } = protocldata[0];
        const { protocolKey } = response.data.protocol[0];
        const path = reverse(
          urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT,
          {
            id,
            protocolid: protocolKey,
            devicetype: deviceType,
            type
          }
        );
        yield put({
          type: constants.BREADCRUMBS.BREADCRUMBS_UPDATE,
          data: { path }
        });
      }
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
function* addNewProtocolMonarch(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { history, data, path } = action.allData;
    const response = yield call(EditProtocol.addProtocolMonarchService, data);
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
      yield put({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_MONARCH_SUCCESS,
        message: response.data.message
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
function* addNewProtocolTitan(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { history, data, path } = action.allData;
    const response = yield call(EditProtocol.addProtocolTitanService, data);
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
      yield put({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_TITAN_SUCCESS,
        message: response.data.message
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* addNewProtocolVest(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { history, data, path } = action.allData;
    const response = yield call(EditProtocol.addNewProtocolVestService, data);
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
      yield put({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_VEST_SUCCESS,
        message: response.data.message
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* checkPassword(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextUserName = aesUtil.encrypt(salt, iv, action.data.username),
      ciphertextPassword = aesUtil.encrypt(salt, iv, action.data.password),
      loginCredentials = createEncryptedData([
        iv,
        salt,
        ciphertextUserName,
        ciphertextPassword
      ]);
    const body = yield call(EditProtocol.checkPassword, loginCredentials);
    if (body.status === 200) {
      yield put({ type: constants.SHOW_LOADER, payload: false });
      yield put({ type: constants.STORE_CHECK_RESULT, data: body.data.status });
    }
  } catch (e) { }
}

const EditProtocolDevice = {
  editProtocolDevice,
  updateProtocolRequestMonarch,
  updateProtocolRequestTitan,
  updateProtocolRequestVest,
  addNewProtocolMonarch,
  addNewProtocolTitan,
  addNewProtocolVest,
  checkPassword
};

export default EditProtocolDevice;
