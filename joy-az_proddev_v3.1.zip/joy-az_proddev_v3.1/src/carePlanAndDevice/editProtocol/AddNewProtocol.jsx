import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import _ from 'lodash';
import constants from 'constants.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import NumberFormat from 'react-number-format';
import ConfirmationDialog from 'components/ConfirmationDialog';
import { Header, SideBar } from 'components/Navigation';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { FootNote } from 'components/FootNote';
import strings from '../../localization/strings';
import './editProtocol.scss';
import {
  addBreadCrumb,
  getBreadCrumb,
  removeBreadCrumb
} from '../../utils/utltity';
import ButtonComponent from 'components/ButtonComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { uid } from 'react-uid';
import { getNumberRangeOptions } from 'utils/helper';

class AddNewProtocol extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: constants.PROTOCOL_TYPES.NORMAL,
      error: '',
      treatmentsPerDay: '',
      deviceType: null,
      protocolEntries: [
        {
          minMinutesPerTreatment: '',
          minFrequency: '',
          minPressure: '',
          maxFrequency: '',
          maxPressure: '',
          minIntensity: '',
          maxIntensity: '',
          treatmentLabel: ''
        }
      ],
      selectedDeviceType: null,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          this.setState(prevState => {
            const clonedDialog = Object.assign({}, prevState.dialog);
            clonedDialog.show = false;
            return { dialog: clonedDialog };
          });
        }
      }
    };
    this.baseState = this.state;
    this.handleNameChange = this.handleNameChange.bind(this);
    this.handleProtocolsChange = this.handleProtocolsChange.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.handleChangeRadio = this.handleChangeRadio.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    const {
      match,
      PatientData: { deviceType }
    } = this.props;
    const { id } = match.params;
    dispatch({
      type: constants.DEVICE.FETCH_PROTOCOL_OVERVIEW,
      data: { deviceTypes: deviceType, id }
    });
  }

  componentDidMount() {
    this.addBreadCrumb({ title: strings.addProtocol });
  }

  componentWillReceiveProps(nextProps) {
    const { deviceType } = this.state;
    const { protocolData, PatientData } = nextProps;
    let selectedDeviceType;
    if (
      !_.isEmpty(protocolData) &&
      !_.isEmpty(PatientData) &&
      deviceType === null
    ) {
      if (PatientData.deviceType === constants.DEVICE_TYPE_CODE.ALL) {
        if (!_.isEmpty(protocolData.protocol)) {
          if (
            protocolData.protocol[0].deviceType ===
            constants.DEVICE_TYPE_CODE.MONARCH
          ) {
            selectedDeviceType = constants.DEVICE_TYPE_CODE.VISIVEST;
          } else {
            selectedDeviceType = constants.DEVICE_TYPE_CODE.MONARCH;
          }
        } else {
          selectedDeviceType = '';
        }
      } else {
        selectedDeviceType = PatientData.deviceType;
      }

      this.setState({ deviceType: selectedDeviceType, selectedDeviceType });
    }
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
    this.removeBreadCrumb();
  }

  handleChangeRadio = event => {
    const protocolEntries = [
      {
        minMinutesPerTreatment: '',
        minFrequency: '',
        minPressure: '',
        maxFrequency: '',
        maxPressure: '',
        minIntensity: '',
        maxIntensity: '',
        treatmentLabel: ''
      }
    ];
    this.setState({
      protocolEntries: protocolEntries,
      type: event.target.value
    });
  };

  handleNameChange = evt => {
    this.setState({ treatmentsPerDay: evt.target.value, isDirty: true });
  };

  handleSelectChange = event => {
    this.setState({ deviceType: event.target.value, isDirty: true });
  };

  handleOnRadioClick = e => {
    const { protocolEntries } = this.state;
    const type = e.target.value;
    if (type === constants.PROTOCOL_TYPES.NORMAL) {
      if (!_.isEmpty(protocolEntries)) {
        const protocol = {
          minMinutesPerTreatment: protocolEntries[0].minMinutesPerTreatment,
          minFrequency: protocolEntries[0].minFrequency,
          minPressure: protocolEntries[0].minPressure,
          maxFrequency: protocolEntries[0].maxFrequency,
          maxPressure: protocolEntries[0].maxPressure,
          minIntensity: protocolEntries[0].minIntensity,
          maxIntensity: protocolEntries[0].maxIntensity,
          treatmentLabel: ''
        };
        this.setState({
          protocolEntries: [protocol],
          isDirty: true
        });
      }
    } else {
      let protocolData = protocolEntries;
      protocolData = protocolData.map(protocol => {
        const data = { ...protocol };
        if (data.treatmentLabel === '') {
          data.treatmentLabel = 'point1';
        }
        return data;
      });
      this.setState({
        protocolEntries: protocolData,
        isDirty: true
      });
    }
  };

  handleProtocolsChange = (evt, idx) => {
    const { protocolEntries, type } = this.state;
    const sum = 1;
    const newProtocolEntries = protocolEntries.map((protocol, sidx) => {
      if (idx !== sidx) return protocol;
      if (type === constants.PROTOCOL_TYPES.CUSTOM) {
        return {
          ...protocol,
          [evt.target.name]: evt.target.value !== '' ? parseInt(evt.target.value) : '',
          treatmentLabel: `point${sum + sidx}`
        };
      } else {
        return {
          ...protocol,
          [evt.target.name]:
            evt.target.value !== '' ? parseInt(evt.target.value) : ''
        };
      }
    });

    this.setState({ protocolEntries: newProtocolEntries, isDirty: true });
  };

  handleAddNewPoints = () => {
    const { protocolEntries } = this.state;
    this.setState({
      protocolEntries: protocolEntries.concat([
        {
          minMinutesPerTreatment: '',
          minFrequency: '',
          maxFrequency: '',
          minIntensity: '',
          maxIntensity: '',
          minPressure: '',
          maxPressure: '',
          treatmentLabel: ''
        }
      ]),
      isDirty: true
    });
  };

  handleSaveProtocol = e => {
    const { treatmentsPerDay, protocolEntries, deviceType } = this.state;
    let device = deviceType;
    this.setState({ error: '' });
    let flag = true;
    protocolEntries.map(protocol => {
      if (device === constants.DEVICE_TYPE_CODE.MONARCH || device === constants.DEVICE_TYPE_CODE.TITAN) {
        if (
          protocol.maxIntensity !== '' &&
          protocol.maxIntensity !== false &&
          (protocol.maxIntensity < Number(protocol.minIntensity) ||
            protocol.maxIntensity > 10)
        ) {
          this.setState({
            error: this.placeholderText(
              protocol.minIntensity,
              1,
              10,
              'Maximum intensity',
              'Maximum intensity'
            )
          });
          flag = false;
        }
        if (protocol.minIntensity === '') {
          this.setState({ error: `${strings.minimumIntensityRequired}` });
          flag = false;
        } else if (protocol.minIntensity < 1 || protocol.minIntensity > 10) {
          this.setState({ error: `${strings.minimumIntensityBetween1to10}` });
          flag = false;
        }
      } else if (device === constants.DEVICE_TYPE_CODE.VISIVEST) {
        if (
          protocol.maxPressure !== '' &&
          protocol.maxPressure !== false &&
          (protocol.maxPressure < Number(protocol.minPressure) ||
            protocol.maxPressure > 10)
        ) {
          this.setState({
            error: this.placeholderText(
              protocol.minPressure,
              1,
              10,
              'Maximum pressure',
              'Maximum pressure'
            )
          });
          flag = false;
        }
        if (protocol.minPressure === '') {
          this.setState({ error: `${strings.minimumPressureRequired}` });
          flag = false;
        } else if (protocol.minPressure < 1 || protocol.minPressure > 10) {
          this.setState({ error: `${strings.minimumPressureBetween1to10}` });
          flag = false;
        }
      }
      if (
        protocol.maxFrequency !== '' &&
        protocol.maxFrequency !== false &&
        (protocol.maxFrequency < Number(protocol.minFrequency) ||
          protocol.maxFrequency > 20)
      ) {
        this.setState({
          error: this.placeholderText(
            protocol.minFrequency,
            5,
            20,
            'Maximum frequency',
            'Maximum frequency'
          )
        });
        flag = false;
      }
      if (protocol.minFrequency === '') {
        this.setState({ error: `${strings.minimumFrequencyRequired}` });
        flag = false;
      } else if (protocol.minFrequency < 5 || protocol.minFrequency > 20) {
        this.setState({ error: `${strings.minimumFrequencyBetween5to20}` });
        flag = false;
      }
      if (protocol.minMinutesPerTreatment === '') {
        this.setState({ error: `${strings.minimumMinutesRequired}` });
        flag = false;
      } else if (
        protocol.minMinutesPerTreatment < 1 ||
        protocol.minMinutesPerTreatment > 99
      ) {
        this.setState({ error: `${strings.minimumMinutesBetween1to99}` });
        flag = false;
      }
      return true;
    });
    if (treatmentsPerDay === '') {
      this.setState({ error: `${strings.protocolTreatmentRequired}` });
      flag = false;
    } else if (treatmentsPerDay < 1 || treatmentsPerDay > 9) {
      this.setState({ error: `${strings.protocolTreatmentBetween1to9}` });
      flag = false;
    }
    if (device === '') {
      this.setState({ error: `${strings.selectDeviceType}` });
      flag = false;
    }
    if (flag) {
      this.setState(prevState => {
        const clonedDialog = Object.assign({}, prevState.dialog);
        clonedDialog.show = true;
        clonedDialog.body = strings.addProtocolDialogBody;
        clonedDialog.title = strings.protocolAdd;
        clonedDialog.button = strings.save;
        clonedDialog.device = device;
        clonedDialog.confirmFunction = this.saveProtocolDispatch;
        return { dialog: clonedDialog };
      });
    }
  };

  handleDeletePoint = key => {
    const currentProtocols = this.state.protocolEntries;
    if (this.state.protocolEntries.length > 1) {
      currentProtocols.splice(key, 1);
    }
    this.setState({
      protocolEntries: currentProtocols
    });
  };

  saveProtocolDispatch = () => {
    const { dispatch, history, match } = this.props;
    const { id } = match.params;
    const { type, treatmentsPerDay, protocolEntries, dialog } = this.state;
    const deviceType = dialog.device;
    let protocols = protocolEntries;
    protocols = protocols.map(protocol => {
      const data = { ...protocol };
      if (data.maxFrequency === '') {
        data.maxFrequency = data.minFrequency;
      }
      if (deviceType === constants.DEVICE_TYPE_CODE.VISIVEST) {
        if (data.maxPressure === '') {
          data.maxPressure = data.minPressure;
        }
      } else if (deviceType === constants.DEVICE_TYPE_CODE.MONARCH || deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
        if (data.maxIntensity === '') {
          data.maxIntensity = data.minIntensity;
        }
      }
      return data;
    });
    const data = {
      id,
      type,
      treatmentsPerDay,
      deviceType,
      protocols
    };

    const allData = {
      path: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
      history,
      data
    };
    if (deviceType === constants.DEVICE_TYPE_CODE.MONARCH) {
      dispatch({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_MONARCH,
        allData
      });
    } else if (deviceType === constants.DEVICE_TYPE_CODE.TITAN) {
      dispatch({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_TITAN,
        allData
      });
    } else {
      dispatch({
        type: constants.DEVICE.ADD_NEW_PROTOCOL_REQUEST_VEST,
        allData
      });
    }

    this.setState(prevState => {
      const clonedDialog = Object.assign({}, prevState.dialog);
      clonedDialog.show = false;
      return { dialog: clonedDialog, isDirty: false };
    });
  };

  handleCancelProtocol = e => {
    const { history } = this.props;
    const { match } = this.props;
    const { id } = match.params;
    e.preventDefault();
    history.push(reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }));
  };

  placeholderText = (value, minValue, maxValue, valueText, rangeText) => {
    let text = '';
    if (value === maxValue) {
      text = `${valueText} should be ${maxValue}`;
    } else {
      text = `${rangeText} between ${value === ''
          ? minValue
          : value >= minValue && value <= maxValue
            ? Number(value)
            : minValue
          } to ${maxValue}`;
    }
    return text;
  };

  render() {
    const {
      treatmentsPerDay,
      deviceType,
      type,
      protocolEntries,
      error,
      dialog
    } = this.state;
    const { match, breadcrumbs, location, history } = this.props;
    const { id } = match.params;
    const sideBarData = {
      activeKey: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
      menu: [
        {
          href: reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id }),
          text: strings.overview
        },
        {
          href: reverse(urls.PATIENT.DETAIL.DETAIL, { id }),
          text: strings.patientDetails
        },
        {
          href: reverse(urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL, { id }),
          text: strings.carePlanAndDevice
        }
      ]
    };

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div>
              {this.getBreadCrumb(breadcrumbs)}
              <h2>{strings.addProtocol}</h2>

              <div>
                <Form.Row>
                  <Form.Group lg={4}>
                    <Form.Check
                      inline
                      custom
                      className="radio-button"
                      type="radio"
                      value="Normal"
                      onChange={this.handleChangeRadio}
                      name="type"
                      id="normal"
                      label={strings.Manual}
                      defaultChecked
                      onClick={this.handleOnRadioClick}
                    />
                  </Form.Group>
                  <Form.Group lg={4}>
                    <Form.Check
                      inline
                      custom
                      className="radio-button"
                      type="radio"
                      value="Custom"
                      label={strings.Program}
                      onChange={this.handleChangeRadio}
                      id="custom"
                      name="type"
                      onClick={this.handleOnRadioClick}
                    />
                  </Form.Group>
                </Form.Row>
              </div>

              <div>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.selectDevice} <span className="asterisk-color">*</span> :</Form.Label>
                    <Form.Control
                      className="custom-select"
                      as="select"
                      name="type"
                      value={deviceType}
                      onChange={this.handleSelectChange}
                      required=""
                    // disabled={this.state.selectedDeviceType}
                    >
                      <option value="">{strings.selectDevice}</option>
                      <option value="TITAN">{strings.titan}</option>
                      <option value="MONARCH">{strings.monarch}</option>
                      <option value="VEST">{strings.vest}</option>
                    </Form.Control>
                  </Form.Group>
                </Form.Row>

                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.treatmentsPerDay}</Form.Label>

                    <Form.Control
                      as="select"
                      name="treatmentsPerDay"
                      onChange={this.handleNameChange}
                      value={treatmentsPerDay}
                      required
                    >
                      <option value="">
                        {strings.selectTreatmentPerDay}
                      </option>
                      {getNumberRangeOptions(1, 9)}
                    </Form.Control>
                  </Form.Group>
                </Form.Row>
              </div>

              {protocolEntries.map((protocol, key) => (
                <div key={uid(key)}>
                  <Form>
                    <h4>
                      {type === constants.PROTOCOL_TYPES.CUSTOM
                        ? ` ${strings.point} ${Number(key) + 1}`
                        : ''}
                    </h4>
                    {type === constants.PROTOCOL_TYPES.CUSTOM && protocolEntries.length > 1 && (
                      <ButtonComponent
                        buttonAction={this.handleDeletePoint.bind(this, key)}
                        buttonText={strings.deletePoint}
                        style={{ marginBottom: '20px' }}
                      />
                    )}
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>
                          {strings.minMinutesPerTreatment} <span className="asterisk-color">*</span>
                        </Form.Label>

                        <NumberFormat
                          className="form-control"
                          name="minMinutesPerTreatment"
                          onChange={e => this.handleProtocolsChange(e, key)}
                          value={protocol.minMinutesPerTreatment}
                          placeholder="Range between 1 to 99"
                          isAllowed={(values) => {
                            const { formattedValue, floatValue } = values;
                            return formattedValue === "" || floatValue <= 99;
                          }}
                          required
                        />
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.minFrequency} <span className="asterisk-color">*</span></Form.Label>
                        <Form.Control
                          as="select"
                          name="minFrequency"
                          value={protocol.minFrequency}
                          onChange={e => this.handleProtocolsChange(e, key)}
                          required
                        >
                          <option value="">
                            {strings.selectMinFrequency}
                          </option>
                          {getNumberRangeOptions(5, protocol.maxFrequency ? protocol.maxFrequency - 1 : 20)}
                        </Form.Control>
                      </Form.Group>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.maxFrequency}</Form.Label>
                        <Form.Control
                          as="select"
                          name="maxFrequency"
                          value={protocol.maxFrequency}
                          onChange={e => this.handleProtocolsChange(e, key)}
                          disabled={protocol.minFrequency === 20}
                        >
                          <option value="">
                            {strings.selectMaxFrequency}
                          </option>
                          {getNumberRangeOptions(protocol.minFrequency ? protocol.minFrequency + 1 : 6, 20)}
                        </Form.Control>
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      {deviceType === constants.DEVICE_TYPE_CODE.VISIVEST ? (
                        <Form.Group as={Col} md={4}>
                          <Form.Label>{strings.minPressure} <span className="asterisk-color">*</span></Form.Label>

                          <Form.Control
                            as="select"
                            name="minPressure"
                            value={protocol.minPressure}
                            onChange={e => this.handleProtocolsChange(e, key)}
                            required
                          >
                            <option value="">
                              {strings.selectMinPressure}
                            </option>
                            {getNumberRangeOptions(1, protocol.maxPressure ? protocol.maxPressure - 1 : 10)}
                          </Form.Control>
                        </Form.Group>
                      ) : (
                        <Form.Group as={Col} md={4}>
                          <Form.Label>{strings.minIntensity} <span className="asterisk-color">*</span></Form.Label>

                            <Form.Control
                              as="select"
                              name="minIntensity"
                              value={protocol.minIntensity}
                              onChange={e => this.handleProtocolsChange(e, key)}
                              required
                            >
                              <option value="">
                                {strings.selectMinIntensity}
                              </option>
                              {getNumberRangeOptions(1, protocol.maxIntensity ? protocol.maxIntensity - 1 : 10)}
                            </Form.Control>
                          </Form.Group>
                        )}
                      {deviceType === constants.DEVICE_TYPE_CODE.VISIVEST ? (
                        <Form.Group as={Col} md={4}>
                          <Form.Label>{strings.maxPressure}</Form.Label>

                          <Form.Control
                            as="select"
                            name="maxPressure"
                            value={protocol.maxPressure}
                            onChange={e => this.handleProtocolsChange(e, key)}
                            disabled={protocol.minPressure === 10}
                          >
                            <option value="">
                              {strings.selectMaxPressure}
                            </option>
                            {getNumberRangeOptions(protocol.minPressure ? protocol.minPressure + 1 : 2, 10)}
                          </Form.Control>
                        </Form.Group>
                      ) : (
                          <Form.Group as={Col} md={4}>
                            <Form.Label>{strings.maxIntensity} </Form.Label>

                            <Form.Control
                              as="select"
                              name="maxIntensity"
                              value={protocol.maxIntensity}
                              onChange={e => this.handleProtocolsChange(e, key)}
                              disabled={protocol.minIntensity === 10}
                            >
                              <option value="">
                                {strings.selectMaxIntensity}
                              </option>
                              {getNumberRangeOptions(protocol.minIntensity ? protocol.minIntensity + 1 : 2, 10)}
                            </Form.Control>
                          </Form.Group>
                        )}
                    </Form.Row>
                  </Form>
                </div>
              ))}
              <p className="text-danger" id="error">
                {error}
              </p>

              {type === constants.PROTOCOL_TYPES.CUSTOM && (
                <ButtonComponent
                  buttonAction={this.handleAddNewPoints}
                  icon="report-icon"
                  buttonText={strings.addNewPoint}
                />
              )}
              <div className="d-flex flex-sm-row justify-content-end">
                <ButtonComponent
                  buttonClass="ml-2 mt-3"
                  buttonAction={this.handleCancelProtocol}
                  icon="cancel-icon"
                  buttonText={strings.cancel}
                />
                <ButtonComponent
                  buttonClass="ml-2 mt-3"
                  buttonAction={this.handleSaveProtocol}
                  icon="right-arrow"
                  buttonText={strings.save}
                />
              </div>
            </div>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const { breadcrumbsReducer, protocolReducer } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    protocolData: protocolReducer.protocolData[id] || {},
    PatientData: protocolReducer.PatientData[id] || {}
  };
};

export default connect(mapStateToProps)(AddNewProtocol);
