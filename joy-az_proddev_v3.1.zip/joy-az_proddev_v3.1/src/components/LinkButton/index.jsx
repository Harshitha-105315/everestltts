import React from 'react';

import './LinkButton.scss';

const LinkButton = ({ onClick, variant, label }) => {
	return (
		<button className={`link-button ${variant}`} onClick={(event) => { event.preventDefault(); onClick(event) }}>
			{label}
		</button>
	);
};

export default LinkButton;
