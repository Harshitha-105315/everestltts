import React from 'react';
import { Form, InputGroup } from 'react-bootstrap';

export default props => {
  const { searchString, fetchOnChange, modifierClass, showSearch, placeholder } = props;
  return (
    <div
      className={`search-container${modifierClass ? ` ${modifierClass}` : ''} ${
        showSearch === true ? '' : 'd-none'
        }`}
    >
      <span className="search-icon search-icon-desktop" />
      <Form.Control
        type="text"
        className="search-input  border-top-0 border-left-0 border-right-0 d-inline border-bottom"
        name="searchString"
        value={searchString}
        placeholder={placeholder}
        onChange={fetchOnChange}
      />
      <InputGroup className="mb-3 d-none mobile-search-input">
        <InputGroup.Prepend className="m-auto">
          <span className="search-icon" />
        </InputGroup.Prepend>
        <Form.Control
          type="text"
          className="border-top-0 border-left-0 border-right-0 d-inline border-bottom"
          name="searchString"
          value={searchString}
          placeholder={placeholder}
          onChange={fetchOnChange}
        />
      </InputGroup>
    </div>
  );
};
