import React from 'react';
import moment from 'moment-timezone';
import strings from 'localization/strings';

import MonthlyPicker from 'components/MonthPicker';
import { getLatestMonth, getMonthsAgoDate } from 'utils/helper';
import './RangeMonthPicker.scss';
import constants from 'constants.js';

export default class RangeMonthlyPicker extends React.Component {
  static defaultProps = {
    startDate: getMonthsAgoDate(constants.MAX_MONTH_RANGE),
    endDate: moment()
  };

  constructor(props) {
    super(props);
    const { min, max } = props;
    const minMonth = min ? getLatestMonth(moment(min), getMonthsAgoDate(constants.MAX_MONTH_RANGE)) : getMonthsAgoDate(constants.MAX_MONTH_RANGE);
    const maxMonth = max ? moment(max) : moment();
    this.state = {
      min: minMonth,
      max: maxMonth,
      startDate: null,
      endDate: null
    };
  }

  componentWillMount() {
    const { startDate, endDate } = this.props;
    this.setState({ startDate, endDate });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.startDate !== this.props.startDate) {
      this.setState({ startDate: nextProps.startDate });
    }
    if (nextProps.endDate !== this.props.endDate) {
      this.setState({ endDate: nextProps.endDate });
    }
    if (nextProps.min !== this.props.min) {
      const x = getMonthsAgoDate(constants.MAX_MONTH_RANGE);
      const minMonth = nextProps.min ? getLatestMonth(moment(nextProps.min), x) : x;
      this.setState({ min: minMonth });
    }
    if (nextProps.max !== this.props.max) {
      const maxMonth = nextProps.max ? moment(nextProps.max) : moment();
      this.setState({ min: maxMonth });
    }
  }

  handleChange = ({ start, end }) => {
    const { startDate, endDate } = this.state;
    const { onChange } = this.props;
    const from = start || startDate;
    let to = end || endDate;
    if (moment(from).isAfter(to)) {
      to = from;
    }
    this.setState({ startDate: from, endDate: to });
    onChange({ startDate: from, endDate: to });
  };

  handleChangeStart = start => {
    this.handleChange({ start });
  };

  handleChangeEnd = end => {
    this.handleChange({ end });
  };

  isSmallScreen = () => {
    if (window.innerWidth < 575) {
      return true;
    }
    return false;
  };

  isLargeScreen = () => {
    if (window.innerWidth >= 1920) {
      return true;
    }
    return false;
  };

  render() {
    const { min, max } = this.state;
    const { startDate, endDate } = this.state;
    return (
      <div
        className={`d-flex ${
          this.isSmallScreen() ? 'float-left' : 'float-right'
        } ${!this.isLargeScreen() && !this.isSmallScreen() ? 'ml-0' : ''}`}
      >
        <div className="justify-content-between pr-3 pl-sm-0">
          <MonthlyPicker
            alignment={`${this.isSmallScreen() ? 'mobile-left' : 'left'}`}
            min={min}
            max={max}
            initialValue={startDate}
            placeHolder=""
            onSelect={this.handleChangeStart}
          />
        </div>
        <div className="justify-content-between pl-0">
          <span className="custom-selection-seperator text-uppercase">
            {strings.to}
          </span>
        </div>
        <div className="justify-content-between pl-3">
          <MonthlyPicker
            alignment={`${this.isSmallScreen() ? 'mobile-right' : 'left'}`}
            min={startDate}
            max={max}
            placeHolder=""
            initialValue={endDate}
            onSelect={this.handleChangeEnd}
          />
        </div>
      </div>
    );
  }
}
