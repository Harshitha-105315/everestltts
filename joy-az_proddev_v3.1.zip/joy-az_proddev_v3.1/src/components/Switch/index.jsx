import React from 'react';
import 'components/Switch/switch.scss';

const Switch = props => {
  const { isChecked, handleChange, name, className } = props;
  return (
    <div className={className || 'switch-container'}>
      <input
        className="switch"
        checked={isChecked}
        onChange={handleChange}
        type="checkbox"
        value={isChecked}
        id={name}
      />
      <div
        id={name}
        value={isChecked}
        onClick={handleChange}
        onKeyPress={handleChange}
        role="button"
        tabIndex={0}
      >
        <div />
      </div>
    </div>
  );
};

export default Switch;
