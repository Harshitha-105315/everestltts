import constants from 'constants.js';

function LoaderReducer(state = 0, action) {
  switch (action.type) {
    case constants.SHOW_LOADER:
      if (action.payload) {
        state = state + 1;
      } else {
        if (state > 0) {
          state = state - 1;
        }
      }
      return state;
    default:
      return state;
  }
}

export default LoaderReducer;
