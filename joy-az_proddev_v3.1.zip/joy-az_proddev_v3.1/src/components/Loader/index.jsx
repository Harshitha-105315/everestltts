import React, { Component } from 'react';
import Lottie from 'react-lottie';
import LottieAnimation from './lottie-animation.js';

import './LoaderComponent.scss'

export default class loader extends Component {
  render() {
    const options = {
      loop: true,
      autoplay: true,
      animationData: LottieAnimation,
      rendererSettings: {
        preserveAspectRatio: 'xMidYMid slice'
      }
    };

    return (
      <div>
        <div className="overlay"></div>
        <div className='loader-container'>
          <Lottie options={options}
          />
        </div>
      </div>
    );
  }
}

