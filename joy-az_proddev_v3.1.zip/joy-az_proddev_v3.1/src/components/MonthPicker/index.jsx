import React from 'react';
import moment from 'moment-timezone';

import './MonthPicker.scss';

class MonthlyPicker extends React.PureComponent {
  static defaultProps = {
    initialValue: null,
    disabled: false,
    inputClass: 'input',
    placeHolder: '',
    alignment: '',
    selectedBackgroundColor: '#0d2457',
    monthLocale: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ],
    min: '',
    max: '',
    dateFormat: 'MMM, YYYY'
  };

  constructor(props) {
    super(props);
    this.state = {
      showMenu: false,
      year: moment().format('YYYY'),
      month: moment().format('MM'),
      selectedDate: null
    };
    this.currentRef = React.createRef();
    this.prevYear = this.prevYear.bind(this);
    this.nextYear = this.nextYear.bind(this);
    this.openMenu = this.openMenu.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);
  }

  componentWillMount() {
    document.addEventListener('mousedown', this.handleOutsideClick, false);
  }

  componentDidMount() {
    this.init();
  }

  componentWillReceiveProps(nextProps) {
    this.setValue(nextProps.initialValue);
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.handleOutsideClick, false);
  }

  getBackgroundColor(year, monthIdx) {
    const { selectedBackgroundColor } = this.props;
    if (this.isCurrentSelected(year, monthIdx)) {
      return selectedBackgroundColor;
    }
    return '';
  }

  setValue(val) {
    let value = val;
    if (typeof value === 'string') {
      value = moment(value);
    }
    if (value && value.isValid()) {
      this.setState({
        month: value.format('MM'),
        year: value.format('YYYY'),
        selectedDate: value
      });
    }
  }

  handleOutsideClick = e => {
    if (this.currentRef && this.currentRef.contains(e.target)) {
      return;
    }
    this.closeMenu();
  };

  menuStyle() {
    const { showMenu } = this.state;
    const { alignment } = this.props;
    let leftPercentage = '';
    let transformPercent = '';

    if (alignment === 'right') {
      leftPercentage = '100%';
      transformPercent = 'translate(-100%,0)';
    } else if (alignment === 'center') {
      leftPercentage = '70%';
      transformPercent = 'translate(-70%,0)';
    } else if (alignment === 'left') {
      leftPercentage = '0%';
      transformPercent = 'translate(-70%,0)';
    } else if (alignment === 'mobile-left') {
      leftPercentage = '0%';
      transformPercent = 'translate(0%,0)';
    } else if (alignment === 'mobile-right') {
      leftPercentage = '0%';
      transformPercent = 'translate(-50%,0)';
    }
    return {
      display: showMenu ? 'block' : 'none',
      left: leftPercentage,
      transform: transformPercent
    };
  }

  displayText() {
    const { selectedDate } = this.state;
    const { dateFormat, placeHolder } = this.props;
    if (selectedDate && selectedDate.isValid()) {
      return selectedDate.format(dateFormat);
    }
    return placeHolder;
  }

  canBack() {
    const { min } = this.props;
    if (!min) return true;
    const currentVal = this.internalMomentValue()
      .clone()
      .startOf('year');
    return min.isBefore(currentVal);
  }

  canNext() {
    const { max } = this.props;
    if (!max) return true;
    const currentVal = this.internalMomentValue()
      .clone()
      .endOf('year');
    return currentVal.isBefore(max);
  }

  internalMomentValue() {
    const { year, month } = this.state;
    const yrMonth = `${year}/${month}`;
    return moment(yrMonth, 'YYYY/MM');
  }

  init() {
    const { initialValue } = this.props;
    this.setValue(initialValue);
  }

  openMenu() {
    const { disabled } = this.props;
    if (!disabled) {
      this.setState({
        showMenu: true
      });
    }
  }

  closeMenu() {
    this.setState({
      showMenu: false
    });
  }

  prevYear() {
    const { year } = this.state;
    if (!this.canBack()) return;
    const newYear = parseInt(year, 10) - 1;
    this.setState({
      year: newYear.toString()
    });
  }

  nextYear() {
    const { year } = this.state;
    if (!this.canNext()) return;
    const newYear = parseInt(year, 10) + 1;
    this.setState({
      year: newYear.toString()
    });
  }

  selectMonth(idx) {
    const { year } = this.state;
    const monthIdx = parseInt(idx, 10) + 1;
    const selectedDate = moment(`${monthIdx}-1-${year}`, 'MM-DD-YYYY');
    this.setState({
      month: monthIdx.toString(),
      selectedDate
    });
    this.selectPicker(selectedDate);
    this.closeMenu();
  }

  selectPicker(selectedDate) {
    const { onSelect } = this.props;
    onSelect(selectedDate);
  }

  isActive(idx) {
    const { year } = this.state;
    const { min, max } = this.props;
    const realMonth = idx + 1;
    const yrMonth = `${year}/${realMonth < 10 ? `0${realMonth}` : realMonth}`;
    if (min && moment(yrMonth, 'YYYY/MM').isBefore(min, 'month')) {
      return false;
    }
    if (max && moment(yrMonth, 'YYYY/MM').isAfter(max, 'month')) {
      return false;
    }
    return true;
  }

  isCurrentSelected(year, monthIdx) {
    const { selectedDate } = this.state;
    const currentValue = selectedDate;
    if (!currentValue) {
      return false;
    }
    let checkValue = currentValue;
    if (typeof currentValue === 'string') {
      checkValue = moment(currentValue);
    }
    if (checkValue && checkValue.isValid()) {
      const currentMonth = checkValue.format('MM');
      const currentYear = checkValue.format('YYYY');
      return (
        Number(currentMonth) === Number(monthIdx + 1) &&
        Number(currentYear) === Number(year)
      );
    }
    return false;
  }

  renderPopElement() {
    const { showMenu, year } = this.state;
    const { monthLocale } = this.props;
    if (showMenu) {
      return (
        <div
          className={`date-popover ${!showMenu ? 'visible hidden' : ''}`}
          style={this.menuStyle()}
          tabIndex="-1"
        >
          <div className="picker" style={{ textAlign: 'center' }}>
            <div className="flexbox">
              <span
                onClick={this.prevYear}
                onKeyDown={this.prevYear}
                role="presentation"
                className={`prev ${!this.canBack() ? 'deactive' : ''}`}
              />
              <div className="year-head">{year}</div>
              <span
                onClick={this.nextYear}
                onKeyDown={this.nextYear}
                role="presentation"
                className={`next ${!this.canNext() ? 'deactive' : ''}`}
              />
            </div>
            <div className="flexbox monthItem">
              {monthLocale.map((month, idx) => {
                if (this.isActive(idx)) {
                  return (
                    <div
                      className={`item active ${
                        this.isCurrentSelected(year, idx) ? 'selected' : ''
                      }`}
                      style={{
                        backgroundColor: this.getBackgroundColor(year, idx)
                      }}
                      onClick={() => this.selectMonth(idx)}
                      onKeyDown={() => this.selectMonth(idx)}
                      key={month}
                      role="presentation"
                    >
                      {month}
                    </div>
                  );
                }
                return (
                  <div
                    className={`item deactive ${
                      this.isCurrentSelected(year, idx) ? 'selected' : ''
                    }`}
                    key={month}
                  >
                    {month}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      );
    }
    return <div />;
  }

  render() {
    const { showMenu } = this.state;
    const { disabled, alignment } = this.props;
    return (
      <div
        className="monthly-picker"
        ref={node => {
          this.currentRef = node;
        }}
      >
        <div
          className="month-year-label picker"
          type="text"
          autoComplete="off"
          onClick={this.openMenu}
          onKeyDown={this.openMenu}
          role="presentation"
        >
          <div
            style={{ width: 'max-content' }}
            onClick={this.openMenu}
            onKeyDown={this.openMenu}
            className="month-year-display"
            disabled={disabled}
            role="presentation"
          >
            <span
              className="display-text month-selection-text"
              style={{ textAlign: alignment }}
            >
              {this.displayText()}
            </span>
            <span
              className="ml-2 custom-dropdown-indicator"
              role="presentation"
            />
          </div>
        </div>
        <div
          className={`month-picker-wrapper ${showMenu ? 'active visible' : ''}`}
        >
          <div className="text" />
          {this.renderPopElement()}
        </div>
      </div>
    );
  }
}

export default MonthlyPicker;
