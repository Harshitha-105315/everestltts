import React from 'react';
import { connect } from 'react-redux';

import Loader from 'components/Loader';

function MainWrapper(props) {
  const { headerEnabled, children, showLoader } = props;
  return (
    <div
      id="yes"
      className={headerEnabled ? 'main-wrapper' : 'main-wrapper hide-display'}
    >
      {children}
      {showLoader > 0 ? <Loader /> : null}
    </div>
  );
}

const mapStateToProps = state => {
  const { userReducer, LoaderReducer } = state.app;
  return {
    response: userReducer.response,
    totalUsers: userReducer.totalUsers,
    headerEnabled: state.app.filterReducer.headerEnabled,
    showLoader: LoaderReducer
  };
};
export default connect(
  mapStateToProps,
  null
)(MainWrapper);
