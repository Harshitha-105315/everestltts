import React, { Fragment } from 'react';
import { components } from 'react-select';
import AsyncSelect from 'react-select/async';
import {
  every,
  isEmpty,
  pickBy,
  includes,
  filter,
  isObject,
  flatMap,
  remove
} from 'lodash';
import debounce from 'debounce-promise';
import constants from 'constants.js';
import { authRequest } from 'utils/axios_utils';
import trash from 'assets/icn-delete.svg';
import EditIcon from 'assets/edit.svg';
import Clear from 'assets/clear.svg';
import 'components/CustomSelect/customSelect.scss';

class CustomSelect extends React.PureComponent {
  constructor(props) {
    super(props);
    this.selectRef = React.createRef();
    this.getOptionsDebounced = debounce(this.getOptions.bind(this), 1000);
  }

  componentDidUpdate() {
    const { clearCurrentVal, afterClearCurrentValFn } = this.props;
    if (clearCurrentVal) {
      if (this.selectRef.select) {
        this.selectRef.select.select.clearValue();
      }
      afterClearCurrentValFn();
    }
  }

  async getOptions(input) {
    const {
      optionUrl,
      urlSymbol,
      searchParam,
      resAttr,
      filterOptions
    } = this.props;
    const response = await authRequest({
      url: `${optionUrl}${urlSymbol || '?'}${searchParam}=${encodeURIComponent(input)}`,
      method: 'GET'
    });

    if (response && response.status !== 500) {
      let res = response;
      if (resAttr) {
        res = response[resAttr];
      }
      let filteredRes = res;
      if (filterOptions) {
        let excludes = filterOptions.values;
        if (isObject(filterOptions.values)) {
          excludes = flatMap(filterOptions.values, filterOptions.key);
          excludes = remove(excludes, undefined);
        }
        filteredRes = filter(res, each => {
          return !includes(excludes, each[filterOptions.key]);
        });
      }
      return filteredRes.slice(0, 40);
    }
  };

  render() {
    const {
      onChange,
      onRemove,
      value,
      idx,
      len,
      minSearchChars,
      isDeleteAllow,
      displayAttr,
      seperator,
      isDisabled,
      clearable,
      className
    } = this.props;

    const IndicatorsContainer = props => {
      const clearHandler = () => {
        if (clearable) {
          props.clearValue();
        }
      };
      const allowRemove = len >= 1 && isDeleteAllow;
      if (len > 1 || allowRemove) {
        return (
          <div>
            <components.IndicatorsContainer {...props}>
              {!isDisabled ? (
                <Fragment>
                  <div
                    style={{
                      marginRight: '1rem',
                      width: '14px',
                      height: '14px'
                    }}
                  >
                    <img
                      src={EditIcon}
                      alt="Edit"
                      className="d-inline-block "
                      width="14px"
                      height="14px"
                    />
                  </div>
                  {onRemove && (
                    <div
                      role="presentation"
                      style={{
                        marginRight: '1rem',
                        width: '14px',
                        height: '14px'
                      }}
                      onClick={onRemove}
                      onKeyDown={onRemove}
                    >
                      <img
                        src={trash}
                        alt="Edit"
                        className="d-inline-block"
                        width="14px"
                        height="14px"
                      />
                    </div>
                  )}
                </Fragment>
              ) : null}
            </components.IndicatorsContainer>
          </div>
        );
      }
      return (
        <div>
          <components.IndicatorsContainer {...props}>
            {!isDisabled ? (
              <div
                style={{ marginRight: '1rem', width: '14px', height: '14px' }}
                role="presentation"
                onMouseUp={clearHandler}
              >
                <img
                  src={EditIcon}
                  alt="Edit"
                  className="d-inline-block "
                  width="14px"
                  height="14px"
                />
              </div>
            ) : null}
          </components.IndicatorsContainer>
        </div>
      );
    };

    const DropdownIndicator = props => {
      const clearHandler = () => {
        if (clearable) {
          props.clearValue();
        }
      };
      if (len < idx) {
        return (
          <div>
            <components.IndicatorsContainer {...props}>
              <div
                style={{ marginRight: '1rem', width: '14px', height: '14px' }}
              >
                <img
                  src={Clear}
                  alt="Edit"
                  className="d-inline-block"
                  width="10px"
                  height="10px"
                />
              </div>
              {onRemove && (
                <div
                  role="presentation"
                  style={{ marginRight: '1rem', width: '14px', height: '14px' }}
                  onClick={onRemove}
                  onKeyDown={onRemove}
                >
                  <img
                    src={trash}
                    alt="Edit"
                    className="d-inline-block"
                    width="14px"
                    height="14px"
                  />
                </div>
              )}
            </components.IndicatorsContainer>
          </div>
        );
      }
      return (
        <components.IndicatorsContainer {...props}>
          {!isDisabled ? (
            <div
              style={{
                marginRight: '0.5rem',
                width: '14px',
                height: '14px',
                marginTop: '-10px'
              }}
            >
              <img
                src={Clear}
                alt="Edit"
                className="d-inline-block"
                width="10px"
                height="10px"
                role="presentation"
                onMouseUp={clearHandler}
              />
            </div>
          ) : null}
        </components.IndicatorsContainer>
      );
    };

    const IndicatorSeparator = ({ innerProps }) => {
      return <span style={{ color: 'none' }} {...innerProps} />;
    };

    const hasValue = !every(value, isEmpty);
    return (
      <AsyncSelect
        cacheOptions={true}
        className={`custom-select-basic-single ${className ? className : ''}`}
        classNamePrefix="select"
        defaultValue={hasValue ? value : null}
        components={
          hasValue
            ? { IndicatorsContainer }
            : { DropdownIndicator, IndicatorSeparator }
        }
        ref={selectNode => {
          this.selectRef = selectNode;
        }}
        getOptionLabel={option => {
          return `${displayAttr
            .map(attr => `${option[attr]}`)
            .join(` ${seperator || ':'} `)}`;
        }}
        getOptionValue={option => {
          return pickBy(option, (v, key) => {
            return includes(displayAttr, key);
          });
        }}
        placeholder={`Type ${minSearchChars +
          1} or more characters to start searching`}
        loadOptions={this.getOptionsDebounced}
        onChange={onChange}
        onInputChange={val => {
          if (val.length <= constants.MIN_CUSTOM_SEARCH_CHARACTER) {
            return '';
          }
          return val;
        }}
        filterOption={() => true}
        openMenuOnFocus={false}
        isDisabled={isDisabled}
      />
    );
  }
}

export default CustomSelect;
