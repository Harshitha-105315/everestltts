import React from 'react';
import { Modal, Image } from 'react-bootstrap';
import './confirmationdialog.scss';
import Close from 'assets/img/ic-close-big-white.svg';
import strings from 'localization/strings';
import ButtonComponent from 'components/ButtonComponent';

const ConfirmationDialog = props => {
  const {
    show,
    handleClose,
    confirmFunction,
    body,
    title,
    button,
    className
  } = props;
  return (
    <Modal
      className={`modal-main ${className ? className : ''}`}
      centered
      show={show}
      onHide={handleClose}
    >
      <Modal.Header>
        <Modal.Title>{title}</Modal.Title>
        <Image
          src={Close}
          width="17"
          height="17"
          onClick={handleClose}
          className="d-inline-block"
          alt="Close"
        />
      </Modal.Header>
      <Modal.Body>{body}</Modal.Body>
      <Modal.Footer>
        <ButtonComponent
          buttonAction={handleClose}
          icon="cancel-icon"
          buttonText={strings.close}
          textClass="dialog-btn-text"
        />
        <ButtonComponent
          buttonAction={confirmFunction}
          icon="right-arrow"
          buttonClass="mt-auto"
          buttonText={button}
          textClass="dialog-btn-text"
        />
      </Modal.Footer>
    </Modal>
  );
};

export default ConfirmationDialog;
