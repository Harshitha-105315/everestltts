import React from 'react';
import './SimpleTopNav.scss';

function SimpleTopNav(props) {
  return (
    <div className="simple-top-nav">
      <div className="logo"><span className="logo icon-hill-rom-logo"></span></div>
      <div className="brand-text">Connex® Health Portal</div>
    </div>
  );
}
export default SimpleTopNav;
