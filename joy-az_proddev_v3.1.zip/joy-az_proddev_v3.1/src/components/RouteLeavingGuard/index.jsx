import React, { Component, Fragment } from 'react';
import { Prompt } from 'react-router-dom';
import ConfirmationDialog from 'components/ConfirmationDialog';
import strings from 'localization/strings';

import './RouteLeavingGuard.scss';

class RouteLeavingGuard extends Component {
	state = {
		modalVisible: false,
		lastLocation: null,
		confirmedNavigation: false,
	};

	showModal = (location) => {
		this.setState({
			modalVisible: true,
			lastLocation: location,
		});
	}

	closeModal = (callback) => this.setState({
		modalVisible: false
	}, callback);

	handleBlockedNavigation = (nextLocation) => {
		const { confirmedNavigation } = this.state;
		const { shouldBlockNavigation } = this.props;
		if (!confirmedNavigation && shouldBlockNavigation(nextLocation)) {
			this.showModal(nextLocation)
			return false;
		}

		return true;
	}

	handleConfirmNavigationClick = () => {
		this.closeModal(() => {
			const { navigate } = this.props;
			const { lastLocation } = this.state;
			if (lastLocation) {
				this.setState({
					confirmedNavigation: true
				}, () => {
					navigate(lastLocation.pathname)
				});
			}
		});
	};

	getWarningContent = () => {
		return (
			<div className="route-leaving-guard-warning-message">
				{strings.routeLeavingGuard.body}
			</div>
		);
	}

	render() {
		const { when } = this.props
		const { modalVisible } = this.state;
		return (
			<Fragment>
				<Prompt
					when={when}
					message={this.handleBlockedNavigation} />
				<ConfirmationDialog
					show={modalVisible}
					handleClose={() => this.closeModal(() => { })}
					confirmFunction={this.handleConfirmNavigationClick}
					title={strings.routeLeavingGuard.header}
					button={strings.routeLeavingGuard.yes}
					body={this.getWarningContent()}
				>
				</ConfirmationDialog>
			</Fragment>
		)
	}
}

export default RouteLeavingGuard;
