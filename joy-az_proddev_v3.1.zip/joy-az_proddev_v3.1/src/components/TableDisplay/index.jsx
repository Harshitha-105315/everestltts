import React, { Component } from 'react';
import { Table, Form, Image } from 'react-bootstrap';
import Pagination from 'react-js-pagination';
import { connect } from 'react-redux';
import Arrow from 'assets/arrow-left.svg';
import strings from 'localization/strings';
import { uid } from 'react-uid';
import { isEmpty, intersection } from 'lodash';

class TableDisplay extends Component {
  constructor() {
    super();
    this.state = {
      width: window.innerWidth
    };
    this.checkAll = this.checkAll.bind(this);
  }

  componentWillMount() {
    window.addEventListener('resize', this.handleWindowSizeChange);
  }

  componentWillReceiveProps(newProps) {
    const { checkBoxData } = newProps;
    const selectedLength = this.getSelectedLength(newProps);
    const headerCheckBox = document.getElementById('header-check-box');
    if (!isEmpty(checkBoxData) && !isEmpty(headerCheckBox)) {
      const { paginatedPatientIds } = checkBoxData;
      if (
        paginatedPatientIds.length !== 0 &&
        selectedLength === paginatedPatientIds.length
      ) {
        // If all checkboxes are selected, then checked symbol will be actvated
        headerCheckBox.indeterminate = false;
        headerCheckBox.checked = true;
      } else if (selectedLength === 0) {
        // If all checkboxes are deselected, then checked symbol will be deactivat
        headerCheckBox.indeterminate = false;
        headerCheckBox.checked = false;
      } else if (
        selectedLength < paginatedPatientIds.length &&
        selectedLength > 0
      ) {
        // If few checkboxes are selected in a page, then deselect symbol '-' will be activate.
        headerCheckBox.indeterminate = true;
      }
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleWindowSizeChange);
  }

  handleWindowSizeChange = () => {
    this.setState({ width: window.innerWidth });
  };

  getTableHeader = () => {
    const { heading } = this.props;
    const { handleSorting } = this.props;
    return heading.map(element => (
      <th
        key={uid(element)}
        className={element.mobile === false ? 'd-none d-sm-table-cell' : ''}
      >
        {element.text}
        <span
          className="sorting-toggle"
          role="button"
          onClick={handleSorting}
          onKeyDown={handleSorting}
          name={element.name}
          value={element.value}
          tabIndex={0}
        >
          {element.sortable ? (
            <Image
              id="sorting-arrow"
              name={element.name}
              value={element.value}
              src={Arrow}
              alt="Sorting Format"
            />
          ) : (
            ''
          )}
        </span>
      </th>
    ));
  };

  checkAll = e => {
    const { checkBoxData } = this.props;
    const {
      paginatedPatientIds,
      selectAllCheckBoxes,
      deselectCheckBoxes
    } = checkBoxData;
    const { checked } = e.target;
    const selectedLength = this.getSelectedLength(this.props);
    if (
      (selectedLength !== paginatedPatientIds.length && selectedLength !== 0) ||
      !checked
    ) {
      // Clicked on deselect symbol '-' or check symbol while all checkboxes were selected ,Respective page checkboxes will be deselect
      deselectCheckBoxes(paginatedPatientIds);
    } else if (checked) {
      // Clicked for select all checkboxes
      selectAllCheckBoxes(paginatedPatientIds);
    }
  };

  getSelectedLength = newProps => {
    const { checkBoxData } = newProps;
    let selectedLength = 0;
    const headerCheckBox = document.getElementById('header-check-box');
    if (!isEmpty(checkBoxData) && !isEmpty(headerCheckBox)) {
      const { paginatedPatientIds, selectedPatientIds } = checkBoxData;
      selectedLength = intersection(selectedPatientIds, paginatedPatientIds)
        .length;
    }
    return selectedLength;
  };

  render() {
    const {
      totalUsers,
      listing,
      countDisplay,
      handlePaginate,
      pagination,
      page,
      perPage,
      options,
      totalDisplayLabel,
      searchString,
      tableClass,
      checkBoxData,
      noResultFound
    } = this.props;
    const { width } = this.state;
    const isMobile = width <= 575;
    if (totalUsers === 0) {
      if (!searchString) {
        return (
          <div className="text-center text-secondary no-results-search">
            <p className="text-secondary break-word">
              {`${noResultFound || strings.noResultsFound}`}
            </p>
          </div>
        );
      }
      return (
        <div className="text-center text-secondary no-results-search">
          <p className="text-secondary break-word">
            {strings.noResultsSearchString
              .replace('{searchString}', searchString)
              .replace(
                '{totalDisplayLabel}',
                totalDisplayLabel.charAt(0).toUpperCase() +
                  totalDisplayLabel.slice(1)
              )}
          </p>
        </div>
      );
    }

    return (
      <div>
        {countDisplay ? (
          <p className="text-capitalize">{`${
            strings.searchResults
          } (${totalUsers || 0})`}</p>
        ) : (
          countDisplay
        )}
        <div className="user-list card maskContent">
          <Table hover className={tableClass}>
            <thead>
              <tr className="cursor">
                {!isMobile &&
                  !isEmpty(checkBoxData) &&
                  checkBoxData.isCheckBoxRequired && (
                    <td>
                      <Form.Check
                        defaultChecked={false}
                        id="header-check-box"
                        type="checkbox"
                        custom
                        label=""
                        onChange={event => this.checkAll(event)}
                      />
                    </td>
                  )}
                {this.getTableHeader()}
                {options ? <th>{strings.options}</th> : options}
              </tr>
            </thead>
            <tbody>{listing}</tbody>
          </Table>
        </div>
        {pagination ? (
          <div
            className={`listing-pagination d-flex ${
              isMobile ? 'justify-content-center' : 'justify-content-between'
            }`}
          >
            <h6 className="total-display d-none d-sm-inline text-capitalize">{`${totalUsers ||
              0} ${totalDisplayLabel}`}</h6>
            <nav aria-label="..." className="float-right">
              <Pagination
                activePage={page}
                prevPageText={strings.prev}
                nextPageText={strings.next}
                linkClass="page-link"
                activeLinkClass=""
                itemClass="page-item"
                itemsCountper_page={perPage}
                totalItemsCount={totalUsers}
                pageRangeDisplayed={isMobile ? 3 : 5}
                onChange={handlePaginate}
                firstPageText={strings.first}
                lastPageText={strings.last}
              />
            </nav>
          </div>
        ) : (
          ''
        )}
      </div>
    );
  }
}

export default connect()(TableDisplay);
