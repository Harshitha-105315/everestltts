import React from 'react';

const DatePickerDisabledInput = React.forwardRef((props, ref) => (
  <input
    className="form-control"
    onClick={props.onClick}
    value={props.value}
    type="text"
    readOnly={props.disabled}
    ref={ref}
  />
));

export default DatePickerDisabledInput;
