import React from 'react';
import carouselImage from 'assets/img/carousel/carousel_image_3.jpg';
import logoImage from 'assets/img/logo/hillrom-logo-black.png';
import accImage from 'assets/img/logo/acc_blue.png';
import './landing.scss';

function Landing() {
  return (
    <div id="landing-slider" className="col p-0 d-none d-sm-block">
      <div className="background-container"
        style={{
          backgroundImage: `url('${carouselImage}')`,
        }}>
        <img id="brand-logo" src={logoImage} alt="Hillrom Logo" />
        <img id="acc-image" src={accImage} alt="Advancing connect care" />
      </div>
    </div>
  );
}
export default Landing;
