import { put } from 'redux-saga/effects';
import constants from 'constants.js';

export function* toggleFilter(action) {
  yield put({
    type: constants.FILTER.EDIT_FILTER_ENABLED
  });
}

export function* toggleHeader(action) {
  yield put({
    type: constants.FILTER.EDIT_HEADER_ENABLED
  });
}
