import React, { Component } from 'react';
import { connect } from 'react-redux';
import strings from 'localization/strings';
import { getUserData } from 'utils/helper';
import { uid } from 'react-uid';
import { NavDropdown } from 'react-bootstrap';
import constants from 'constants.js';

class NotificationPopup extends Component {
  constructor() {
    super();
    this.state = {};
  }

  componentWillMount() {
    const { dispatch } = this.props;
    const userData = getUserData();
    dispatch({
      type: constants.NOTIFICATION_SETTING.FETCH_NOTIFICATION,
      payload: { userId: userData.id }
    });
  }

  render() {
    // const { notification } = this.props;
    const notification = [
      {
        id: 1,
        message: 'Your recommended therapy is missing 1 day'
      },
      {
        id: 2,
        message: 'Your session is deviated by 12 mins.'
      }
    ];
    return (
      <NavDropdown
        title={strings.notifications}
        className={`${
          notification && notification.length
            ? 'notification-popup-indication'
            : 'empty-notification-popup-indication'
        }`}
        alignRight
      >
        {notification && notification.length ? (
          notification.map(nData => (
            <NavDropdown.Item key={uid(nData)}>
              {nData.message}
            </NavDropdown.Item>
          ))
        ) : (
          <NavDropdown.Item>{strings.noNewNotification}</NavDropdown.Item>
        )}
      </NavDropdown>
    );
  }
}

const mapStateToProps = state => {
  const { notificationReducer } = state.app;
  return {
    notification: notificationReducer.userNotification
  };
};

export default connect(mapStateToProps)(NotificationPopup);
