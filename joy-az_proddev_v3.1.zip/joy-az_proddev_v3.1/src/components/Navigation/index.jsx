import React, { Component } from 'react';
import { connect } from 'react-redux';
import strings from 'localization/strings';
import logo from 'assets/img/logo/hillrom-logo.png';
import { uid } from 'react-uid';
import profileIcon from 'assets/img/profile-icon.svg';
import userIcon from 'assets/img/user-icon.svg';
import scriptIcon from 'assets/img/script-icon.svg';
import sandboxIcon from 'assets/img/sandbox-icon.svg';
import logoutIcon from 'assets/img/logout-icon.svg';
import { isEmpty, findIndex, at } from 'lodash';
import { Navbar, NavDropdown, Nav, Form } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import './Navigation.scss';
import urls from 'urls';
import headerValues from 'rolesData/headerValues.js';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData, getHelpTipsFlag } from 'utils/helper';
import { reverse } from 'named-urls';
import constants from 'constants.js';
import leftArrow from 'assets/img/arrow-left-new.svg';
import { withRouter } from 'react-router-dom';

const getHeader = (unreadAnnouncementCount, isMobile, handleHeaderToggle) => {
  const userData = getUserData();

  if (userData) {
    const { actualRole, userId } = userData;
    const searchAnnouncement = accessMatrix.SEARCH_ANNOUNCEMENTS[actualRole];
    return headerValues
      .filter(value => {
        const { tab } = value;
        const { read } = accessMatrix[tab][actualRole];
        return read ? true : false;
      })
      .map(value => {
        let { url, label, tab, hasParams } = value;
        if (hasParams) {
          url = reverse(url, { id: userId });
        }
        return (
          <LinkContainer to={url} key={uid(tab)}>
            <Nav.Link
              className={label + 'Tab-container text-uppercase'}
              active={false}
            >
              {isMobile && <span onClick={handleHeaderToggle}>{label}</span>}
              {!isMobile && label}{(label === 'announcements' && !searchAnnouncement.read && unreadAnnouncementCount > 0)
                ? <sup className="notification-sups">{unreadAnnouncementCount}</sup> : ""}
            </Nav.Link>
          </LinkContainer>
        );
      });
  }
  return null;
};

const goBack = (prevURL, history) => {
  if (window.history.state) {
    window.history.back();
  } else {
    history.push(prevURL);
  }
};

function MainHeader(props) {
  const {
    account,
    filterEnabled,
    headerEnabled,
    displayScrollBar,
    sideBarData,
    prevURL,
    history,
    showSearch,
    searchExitHandle,
    filterWithMenu,
    noSearch,
    announcementContents,
    announcementList
  } = props;
  let isMobile = false;
  if (window.innerWidth < 575) {
    isMobile = true;
  }
  let unreadAnnouncementCount = 0;
  let { showBack, showBrand, showToggle } = props;
  const userData = getUserData();

  if (announcementContents.length >= 1) {
    unreadAnnouncementCount = announcementContents.filter(e => !e.readStatus).length;
  } else if (announcementList !== undefined && announcementList.content !== undefined) {
    unreadAnnouncementCount = announcementList.content.filter(e => !e.readStatus).length;
  }

  showToggle = typeof showToggle === 'undefined' ? false : showToggle;
  showBack = typeof showBack === 'undefined' ? true : showBack;
  showBrand = typeof showBrand === 'undefined' ? true : showBrand;
  const { actualRole } = getUserData();
  const timsScript = accessMatrix.TIMS_SCRIPT[actualRole];
  const sandbox = accessMatrix.SANDBOX[actualRole];
  const prescribeDeviceInformation = accessMatrix.PRESCRIBE_DEVICE[actualRole];

  function handleHeaderToggle() {
    const { dispatch } = props;
    dispatch({
      type: constants.FILTER.TOGGLE_HEADER
    });
  }

  function handleFilterToggle() {
    const { dispatch } = props;
    dispatch({
      type: constants.FILTER.TOGGLE_FILTER
    });
  }
  let navItems;
  if (!isEmpty(sideBarData) && !isEmpty(sideBarData.menu)) {
    navItems = sideBarData.menu.map(link => (
      <LinkContainer exact to={link.href} key={uid(link)}>
        <Nav.Link className="text-capitalize col-auto">{link.text}</Nav.Link>
      </LinkContainer>
    ));
  }

  const style = {};

  if (displayScrollBar) {
    style.paddingTop = 0;
  }
  if (!headerEnabled) {
    style.minHeight = '100vh';
  }

  const headerDropDown = (
    <Nav
      style={style}
      className={headerEnabled ? 'hide-display ml-auto' : 'w-100'}
      defaultActiveKey="#home"
    >
      {!headerEnabled && (
        <div
          className="float-right cursor cross hide-icon"
          onClick={handleHeaderToggle}
          role="presentation"
        >
          <span className="cross-icon-white float-right" />
        </div>
      )}
      {getHeader(unreadAnnouncementCount, isMobile, handleHeaderToggle)}
      <NavDropdown
        id="resourse-link"
        title={strings.resources}
        alignRight
        className="resourcesContainer"
      >
        <NavDropdown.Item
          href="//respiratorycare.hill-rom.com/en/resources/video-library/"
          target="_blank"
        >
          {strings.videoLibrary}
        </NavDropdown.Item>
        <NavDropdown.Item
          href="//respiratorycare.hill-rom.com/en/resources/education-options/"
          target="_blank"
        >
          {strings.educationOptions}
        </NavDropdown.Item>
        <NavDropdown.Item
          href="//respiratorycare.hill-rom.com/en/resources/reimbursement-services/"
          target="_blank"
        >
          {strings.reimbursementServices}
        </NavDropdown.Item>
        <NavDropdown.Item
          href="//respiratorycare.hill-rom.com/en/resources/insurance-coverage/"
          target="_blank"
        >
          {strings.insuranceCoverage}
        </NavDropdown.Item>
        {prescribeDeviceInformation.read ? (
          <NavDropdown.Item
            href="//respiratorycare.hill-rom.com/en/healthcare-professionals/manage-my-patients/monarch"
            target="_blank"
          >
            {strings.prescribeDevice}
          </NavDropdown.Item>
        ) : null}
        <NavDropdown.Item
          href="//respiratorycare.hill-rom.com/en/resources/glossary-of-terms/"
          target="_blank"
        >
          {strings.glossaryTerms}
        </NavDropdown.Item>
        {userData.actualRole === constants.ROLES.SUPER_ADMIN &&
          <LinkContainer to={urls.THERAPYSETTING} activeClassName="">
            <NavDropdown.Item className="text-capitalize">
              {strings.therapySetting}
            </NavDropdown.Item>
          </LinkContainer>}
      </NavDropdown>
      <NavDropdown title={strings.help} alignRight className="helpContainer">
        {!isMobile && (
          <NavDropdown.Item>
            <span
              onClick={() => {
                const { dispatch } = props;
                if (
                  userData.actualRole &&
                  userData.actualRole !== strings.patientRole
                ) {
                  history.push('/' + strings.patients + '/');
                  let usersData = {
                    searchString: '',
                    page: 1,
                    perPage: 10,
                    sortBy: 'firstName',
                    asc: true,
                    filter: {
                      isActivated: 0,
                      isDeleted: 'all',
                      authority: 'all'
                    },
                    filterOn: false
                  };
                  let providerData = {
                    name: '',
                    asc: true,
                    page: 1,
                    perPage: 10,
                    sortBy: 'firstName',
                    country: constants.LOCATIONS[0],
                    state: null,
                    city: null,
                    providerSpeciality: null,
                    viewMore: '',
                    status: 'all',
                    filterOn: false
                  };
                  let clinicData = {
                    name: '',
                    page: 1,
                    perPage: 10,
                    sortBy: 'name',
                    asc: true,
                    clinicSpecialty: null,
                    country: constants.LOCATIONS[0],
                    state: null,
                    city: null,
                    status: 'all',
                    filterOn: false
                  };
                  dispatch({
                    type: constants.PROVIDER.PROVIDER_REQUEST,
                    payload: providerData
                  });
                  dispatch({
                    type: constants.CLINICS.CLINICS_SEARCH_REQUEST,
                    payload: clinicData
                  });
                  dispatch({
                    type: constants.USER.USER_SEARCH_REQUEST,
                    payload: usersData
                  });
                } else {
                  history.push('/');
                }
                dispatch({
                  type: constants.NAVIGATION.NAVIGATION_SHOW_HELP_TIP,
                  data: true
                });
              }}
            >
              {strings.startTour}
            </span>
          </NavDropdown.Item>
        )}
        <NavDropdown.Item href="mailto:ConnexSupport@Hillrom.com">
          {strings.emailId1}
          {strings.emailId2}
        </NavDropdown.Item>
        <NavDropdown.Item href={`tel:${strings.customerCareNumber}`}>
          {strings.customerCare}
          <br />
          {strings.customerCareNumber}
        </NavDropdown.Item>
      </NavDropdown>

      {
        isMobile && (
          <div className="dropdown nav-item d-flex">
            <span
              className="d-inline-block text-uppercase nav-link"
              id="profile-navbar"
            >
              <LinkContainer to={urls.PROFILE.ALL}>
                <span onClick={handleHeaderToggle}>
                  <img
                    src={profileIcon}
                    className="d-inline-block navprofile-icon align-left"
                    alt="profile icon"
                  />
                  <span>{account.firstName}</span>
                </span>
              </LinkContainer>
              <LinkContainer to={urls.LOGOUT}>
                <div
                  id="nav-logout"
                  className="float-right text-danger text-uppercase"
                >
                  {strings.logout}
                </div>
              </LinkContainer>
            </span>
          </div>
        )
      }

      {
        !isMobile && (
          <NavDropdown
            className="navprofile-dropdown"
            title={
              <span className="text-uppercase" id="profile-navbar">
                <img
                  src={profileIcon}
                  className="d-inline-block navprofile-icon align-left"
                  alt="profile icon"
                />
                {account.firstName}
              </span>
            }
          >
            <LinkContainer to={urls.PROFILE.ALL} activeClassName="">
              <NavDropdown.Item className="text-capitalize">
                <span>
                  <img
                    src={userIcon}
                    className="d-inline-block dropdown-item-icon"
                    alt="user icon"
                  />
                  {strings.myProfile}
                </span>
              </NavDropdown.Item>
            </LinkContainer>
            {timsScript.read && (
              <LinkContainer to={urls.TIMS.SCRIPT} activeClassName="">
                <NavDropdown.Item className="text-capitalize">
                  <span>
                    <img
                      src={scriptIcon}
                      className="d-inline-block dropdown-item-icon"
                      alt="script icon"
                    />
                    {strings.timsScript}
                  </span>
                </NavDropdown.Item>
              </LinkContainer>
            )}
            {sandbox.read && (
              <LinkContainer to={urls.SANDBOX} activeClassName="">
                <NavDropdown.Item className="text-capitalize">
                  <span>
                    <img
                      src={sandboxIcon}
                      className="d-inline-block dropdown-item-icon"
                      alt="sandbox icon"
                    />
                    {strings.sandBox}
                  </span>
                </NavDropdown.Item>
              </LinkContainer>
            )}
            <LinkContainer to={urls.LOGOUT} activeClassName="" id="logout">
              <NavDropdown.Item className="text-capitalize">
                <span style={{ color: '#fc2e2e' }}>
                  <img
                    src={logoutIcon}
                    className="d-inline-block dropdown-item-icon"
                    alt="logout icon"
                  />
                  {strings.logout}
                </span>
              </NavDropdown.Item>
            </LinkContainer>
          </NavDropdown>
        )
      }
    </Nav >
  );

  return (
    <Navbar
      variant="dark"
      bg="dark"
      expand="lg"
      id="main-navbar"
      className={filterEnabled ? '' : 'hide-display'}
      style={displayScrollBar && headerEnabled ? { paddingBottom: '0' } : {}}
    >
      {showSearch && (
        <div
          style={headerEnabled ? { display: 'contents' } : { display: 'none' }}
        >
          <div className="w-100">
            <Navbar.Brand className="d-inline-block ml-4">
              <h2 className="mobile-search-head text-capitalize">
                {strings.search}
              </h2>
            </Navbar.Brand>
            <div className="d-inline-block float-right">
              <button
                type="button"
                className="navbar-toggler mb-4"
                onKeyPress={() => {
                  const { dispatch } = props;
                  dispatch({
                    type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB
                  });
                  searchExitHandle();
                }}
                onClick={() => {
                  const { dispatch } = props;
                  dispatch({
                    type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB
                  });
                  searchExitHandle();
                }}
              >
                <span className="cross-icon icon-white" />
              </button>
            </div>
          </div>
        </div>
      )}
      {(!displayScrollBar || filterWithMenu) && !showSearch && headerEnabled && (
        <span
          style={headerEnabled ? { display: 'contents' } : { display: 'none' }}
        >
          {!filterWithMenu ? (
            <LinkContainer to={urls.LANDING}>
              <Navbar.Brand>
                <img
                  src={logo}
                  className="d-inline-block align-top"
                  alt="Hillrom logo"
                />
              </Navbar.Brand>
            </LinkContainer>
          ) : (
              <span role="presentation" onClick={() => goBack(prevURL, history)}>
                <Navbar.Brand>
                  <img
                    id="back-arrow"
                    src={leftArrow}
                    width="36"
                    height="36"
                    alt="go back"
                  />
                </Navbar.Brand>
              </span>
            )}
          <div>
            {!noSearch && (
              <button type="button" className="navbar-toggler search">
                <span
                  className="navbar-search-icon"
                  role="button"
                  tabIndex={0}
                  onKeyPress={() => {
                    const { dispatch } = props;
                    dispatch({
                      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB
                    });
                  }}
                  onClick={() => {
                    const { dispatch } = props;
                    dispatch({
                      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB
                    });
                  }}
                />
              </button>
            )}
            <button
              type="button"
              className="navbar-toggler filter"
              onClick={handleFilterToggle}
            >
              <span className="navbar-filter-icon" />
            </button>
            {!filterWithMenu && (
              <Navbar.Toggle
                onClick={handleHeaderToggle}
                aria-controls="basic-navbar-nav"
              />
            )}
          </div>
        </span>
      )}
      {displayScrollBar && !showToggle && !showBrand && !showBack && (
        <Navbar.Toggle
          className="ml-auto"
          style={headerEnabled ? {} : { display: 'none' }}
          onClick={handleHeaderToggle}
          aria-controls="basic-navbar-nav"
        />
      )}
      {displayScrollBar && headerEnabled && showBrand && !showBack && (
        <LinkContainer to={urls.LANDING}>
          <Navbar.Brand>
            <img
              src={logo}
              className="d-inline-block align-top"
              alt="Hillrom logo"
            />
          </Navbar.Brand>
        </LinkContainer>
      )}
      {displayScrollBar && headerEnabled && showBrand && !showBack && (
        <Navbar.Toggle
          id="profile-toggle"
          style={headerEnabled ? {} : { display: 'none' }}
          onClick={handleHeaderToggle}
          aria-controls="basic-navbar-nav"
        />
      )}
      {displayScrollBar && (
        <span>
          {showBack && !filterWithMenu && (
            <span role="presentation" onClick={() => goBack(prevURL, history)}>
              <Navbar.Brand>
                <img
                  id="back-arrow"
                  src={leftArrow}
                  width="36"
                  height="36"
                  alt="go back"
                />
              </Navbar.Brand>
            </span>
          )}
          {headerEnabled && (
            <div id="top-bar-mobile-view">
              {!isEmpty(sideBarData) &&
                !isEmpty(sideBarData.menu) &&
                sideBarData.menu.length > 1 && (
                  <div
                    className="row flex-row flex-nowrap flex-sm-wrap justify-content-space-between"
                    defaultActiveKey="#home"
                  >
                    {navItems}
                  </div>
                )}
            </div>
          )}
        </span>
      )}
      {headerDropDown}
    </Navbar>
  );
}

function viewMore(element, context, isExpanded, filters) {
  const currentFilterIndex = Object.keys(filters).indexOf(element);
  const isExpandedList = isExpanded;
  isExpandedList[currentFilterIndex] = true;
  context.setState({ isExpanded: isExpandedList });
}

const getFilters = d => {
  if (d.type === 'select') {
    if (d.optionType === 'object') {
      return (
        <Form.Control
          className="filter-select text-uppercase"
          as="select"
          id={`f-${d.value}-${d.name}`}
          name={d.name}
          value={d.value ? d.value : ''}
          onChange={d.onChangeFunction}
        >
          {d.allSelection ? <option value="">{strings.all}</option> : null}
          {d.options.map(element => {
            return (
              <option
                key={uid(element[d.optionValue.key])}
                value={element[d.optionValue.key]}
              >
                {at(element, d.optionValue.value).join(' ')}
              </option>
            );
          })}
        </Form.Control>
      );
    }
    return (
      <Form.Control
        className="filter-select text-capitalize"
        as="select"
        id={`f-${d.value}-${d.name}`}
        name={d.name}
        value={d.value ? d.value : ''}
        onChange={d.onChangeFunction}
      >
        {d.name === 'range' ? null : <option value={d.name}>{d.name}</option>}
        {d.options.map(element => {
          return (
            <option key={uid(element)} value={element}>
              {element}
            </option>
          );
        })}
      </Form.Control>
    );
  }
  return (
    <Form.Check
      custom
      className="filter-checkbox d-inline"
      type={d.type}
      id={`f-${d.value}-${d.name}`}
      name={d.name}
      value={d.value}
      label={d.title}
      onChange={d.onChangeFunction}
      inline
      checked={d.checked}
    />
  );
};

class MainSideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isExpanded: [],
      page: 1,
      perPage: 10,
      asc: false,
      sortBy: 'modifiedDate',
    };
  }

  componentDidMount() {
    let flag = getHelpTipsFlag();
    const userData = getUserData();
    const { dispatch } = this.props;
    if (!flag) {
      let providerData = {
        name: '',
        asc: true,
        page: 1,
        perPage: 10,
        sortBy: 'firstName',
        country: constants.LOCATIONS[0],
        state: null,
        city: null,
        providerSpeciality: null,
        viewMore: '',
        status: 'all',
        filterOn: false
      };
      let clinicData = {
        name: '',
        page: 1,
        perPage: 10,
        sortBy: 'name',
        asc: true,
        clinicSpecialty: null,
        country: constants.LOCATIONS[0],
        state: null,
        city: null,
        status: 'all',
        filterOn: false
      };
      let usersData = {
        searchString: '',
        page: 1,
        perPage: 10,
        sortBy: 'firstName',
        asc: true,
        filter: {
          isActivated: 0,
          isDeleted: 'all',
          authority: 'all'
        },
        filterOn: false
      };
      if (userData.actualRole && userData.actualRole !== strings.patientRole) {
        dispatch({
          type: constants.PROVIDER.PROVIDER_REQUEST,
          payload: providerData
        });
        dispatch({
          type: constants.CLINICS.CLINICS_SEARCH_REQUEST,
          payload: clinicData
        });
        dispatch({
          type: constants.USER.USER_SEARCH_REQUEST,
          payload: usersData
        });
      }
      dispatch({
        type: constants.NAVIGATION.NAVIGATION_SHOW_HELP_TIP,
        data: true
      });
    }
    if (userData.actualRole === constants.ROLES.PATIENT) {
      this.dispatchForPatientAnnouncement(userData);
    } else if (userData.actualRole !== constants.ROLES.SUPER_ADMIN) {
      this.dispatchForAnnouncement(userData);
    }
    if (!this.props.showHelpFlag)
      dispatch({
        type: constants.NAVIGATION.SHOW_HELP_FLAG,
        data: flag
      });
  }

  dispatchForAnnouncement = role => {
    const { dispatch } = this.props;
    const { perPage, page, asc, sortBy } = this.state;
    dispatch({
      type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT,
      payload: { perPage, page, asc, sortBy, role }
    });
  };

  dispatchForPatientAnnouncement = userData => {
    const { dispatch } = this.props;
    const { perPage, page, asc } = this.state;
    dispatch({
      type: constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH,
      payload: {
        perPage,
        page,
        asc,
        sortBy: 'modified_date',
        userData
      }
    });
  };

  render() {
    const { sideBarData, filters, hidden, filterOn } = this.props;
    const context = this;
    const { isExpanded } = this.state;
    const isExpandedList = isExpanded;
    const { filterEnabled, filterWithMenu } = this.props;
    const { dispatch } = this.props;
    function shownavbar() {
      dispatch({
        type: constants.FILTER.TOGGLE_FILTER
      });
    }
    function toggleTherapyOptions(isTherapy) {
      dispatch({
        type: constants.PATIENT.TOGGLE_THERAPY_OPTION,
        data: isTherapy
      });
    }

    let navItems;
    if (!isEmpty(sideBarData) && !isEmpty(sideBarData.menu)) {
      navItems = sideBarData.menu.map(link => (
        <React.Fragment>
          <LinkContainer to={link.href} key={uid(link)}>
            <Nav.Link
              active={false}
              className={
                link.text === 'clinic details'
                  ? 'text-capitalize maskContent'
                  : 'text-capitalize'
              }
            >
              {link.text}
            </Nav.Link>
          </LinkContainer>
          <ul className={'ul-pad'}>
            {link.options !== undefined && link.options.map((lis, idx) => (
              <li onClick={() => {
                toggleTherapyOptions(lis.isTherapyOption);
              }}
                className={`text-capitalize list-style-none ${lis.isTherapyshow
                  ? 'active-side-bar'
                  : 'inactive-side-bar'
                  } ${idx === link.options.length - 1 ? 'pad-top-10' : ''}
            `}>{lis.text}</li>
            ))}
          </ul>
        </React.Fragment>
      ));
    }
    if (filters) {
      if (Object.keys(filters).length !== 0) {
        const { resetFilter } = this.props;
        let currentFilterIndex;
        return (
          <Nav
            id="sidebar"
            variant="dark"
            bg="dark"
            className={`${filterEnabled
              ? 'flex-column hide-display'
              : 'flex-column d-sm-block'
              } ${hidden ? 'd-none' : ''}
            `}
          >
            {!isEmpty(sideBarData) &&
              !isEmpty(sideBarData.menu) &&
              !filterWithMenu ? (
                <div>
                  {navItems}
                  <hr />
                </div>
              ) : null}
            <div style={{ width: '100%' }}>
              <Form>
                <Form.Group className="filters d-flex justify-content-between align-items-center">
                  <Form.Label className="d-inline text-capitalize">
                    {strings.filters}
                  </Form.Label>
                  {
                    <Nav.Link
                      className={`${filterOn ? 'reset-button' : 'disabled'
                        } d-inline text-uppercase cursor`}
                      as="a"
                      onClick={() => {
                        resetFilter();
                      }}
                    >
                      {strings.reset}
                    </Nav.Link>
                  }

                  <div
                    className="float-right cursor hide-icon cross"
                    as="a"
                    onClick={() => {
                      shownavbar();
                    }}
                  >
                    <span className="cross-icon-white float-right" />
                  </div>
                </Form.Group>
                {Object.keys(filters).map(function filterName(element) {
                  const extendendFilterId = findIndex(
                    filters[element],
                    (mval, mkey) => {
                      return mval.checked && mkey > 2;
                    }
                  );
                  let count = 0;
                  currentFilterIndex = Object.keys(filters).indexOf(element);
                  return (
                    <div key={uid(element)}>
                      <Form.Label className="d-inline filter-para">
                        {element.replace(/_/g, ' ')}
                      </Form.Label>
                      <ul className="filter-val text-capitalize">
                        {filters[element].map(function filterParameters(d) {
                          if (
                            !isExpanded[currentFilterIndex] &&
                            extendendFilterId === -1
                          ) {
                            count += 1;
                            if (count < 4) {
                              return (
                                <li key={uid(d)}>
                                  <div className="row-filter">
                                    {getFilters(d)}
                                  </div>
                                </li>
                              );
                            }
                            if (count === 4) {
                              return (
                                <li key={uid(d)}>
                                  <span>
                                    <Nav.Link
                                      className="view-more d-inline text-capitalize"
                                      onClick={() =>
                                        viewMore(
                                          element,
                                          context,
                                          isExpandedList,
                                          filters
                                        )
                                      }
                                    >
                                      <p id="view-more">+ {strings.VIEWMORE}</p>
                                    </Nav.Link>
                                  </span>
                                </li>
                              );
                            }
                          } else if (
                            isExpanded[currentFilterIndex] ||
                            extendendFilterId !== -1
                          ) {
                            return (
                              <li key={uid(d)}>
                                <div className="row-filter">
                                  {getFilters(d)}
                                </div>
                              </li>
                            );
                          }
                          return null;
                        })}
                      </ul>
                    </div>
                  );
                })}
              </Form>
              <hr className="horizontal hide-icon" />

              {window.innerWidth <= 575 && (
                <div className="buttons-wrap text-center">
                  <Nav.Link
                    className="d-inline text-uppercase cursor topbottomleft filter-buttons"
                    as="a"
                    onClick={() => {
                      resetFilter();
                    }}
                  >
                    {strings.reset}
                  </Nav.Link>

                  <Nav.Link
                    className="d-inline text-uppercase cursor topbottomright filter-buttons"
                    as="a"
                    onClick={() => {
                      shownavbar();
                    }}
                  >
                    <span className="filter-font">{strings.apply}</span>
                  </Nav.Link>
                </div>
              )}
            </div>
          </Nav>
        );
      }
    }
    return (
      <Nav
        id="sidebar"
        variant="dark"
        bg="dark"
        {...(!isEmpty(sideBarData)
          ? { defaultActiveKey: sideBarData.activeKey }
          : {})}
        className={
          filterEnabled
            ? 'flex-column d-sm-block hide-display'
            : 'flex-column d-sm-block'
        }
      >
        <div id="sidebar-menu">
          <div
            className="float-right cursor cross hide-icon"
            onClick={() => {
              shownavbar();
            }}
            role="presentation"
          >
            <span className="cross-icon-white float-right" />
          </div>
          {navItems}
        </div>
      </Nav>
    );
  }
}

const mapStateToProps = state => {
  const { accountReducer } = state.app;
  return {
    filterEnabled: state.app.filterReducer.filterEnabled,
    headerEnabled: state.app.filterReducer.headerEnabled,
    showSearch: state.app.filterReducer.showSearch,
    account: accountReducer.response,
    showHelpTip: state.app.filterReducer.showHelpTip,
    showHelpFlag: state.app.filterReducer.showHelpFlag,
    announcementList: state.app.announcementReducer.announcementList,
    announcementContents: state.app.announcementReducer.announcementContents,
  };
};

const Header = connect(mapStateToProps)(withRouter(MainHeader));
const SideBar = connect(mapStateToProps)(MainSideBar);

export { SideBar, Header };
