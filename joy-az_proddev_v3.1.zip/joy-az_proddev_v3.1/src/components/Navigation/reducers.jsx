import constants from 'constants.js';

const intialState = {
  filterEnabled: true,
  showSearch: false,
  headerEnabled: true,
  isTourOpen: false
};

function filterReducer(state = intialState, action) {
  const tmpState = Object.assign({}, state);
  switch (action.type) {
    case constants.FILTER.EDIT_FILTER_ENABLED:
      if (state.filterEnabled === false)
        return Object.assign({}, state, {
          filterEnabled: true
        });
      return Object.assign({}, state, {
        filterEnabled: false
      });
    case constants.NAVIGATION.NAVIGATION_SHOW_HELP_TIP:
      tmpState.showHelpTip = action.data;
      return tmpState;
    case constants.NAVIGATION.SHOW_HELP_FLAG:
      tmpState.showHelpFlag = action.data;
      return tmpState;
    case constants.FILTER.EDIT_HEADER_ENABLED:
      if (state.headerEnabled === false) {
        return Object.assign({}, state, {
          headerEnabled: true
        });
      }
      return Object.assign({}, state, {
        headerEnabled: false
      });
    case constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB:
      if (action.toggleValue !== undefined) {
        tmpState.showSearch = action.toggleValue;
      } else {
        tmpState.showSearch = !tmpState.showSearch;
      }
      return tmpState;
    default:
      return state;
  }
}

export default filterReducer;
