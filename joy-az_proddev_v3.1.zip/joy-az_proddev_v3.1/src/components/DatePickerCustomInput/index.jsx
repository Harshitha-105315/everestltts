import React from 'react';
import './datepickercustominput.scss';

const DatePickerCustomInput = React.forwardRef((props, ref) => (
  <div
    ref={ref}
    readOnly
    className="datepicker-text"
    onClick={props.onClick}
    onKeyDown={props.onClick}
    role="presentation"
  >
    {props.value}
    <span className="custom-dropdown-indicator" role="button" />
  </div>
));

export default DatePickerCustomInput;
