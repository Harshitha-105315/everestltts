import React from 'react';
import { uid } from 'react-uid';
import './cardComponent.scss';

const getCardComponent = (a, state) => {
  const { active } = state;
  return a.map((element, index) => {
    return (
      <div
        id={`temp-${index + 1}`}
        className="d-block col-auto col-md-4 msg-wrapper card-outer"
        onClick={element.onClickHandle}
        onKeyDown={element.onClickHandle}
        tabIndex={0}
        role="button"
        key={uid(element)}
      >
        <div className={`d-flex flex-column flex-sm-row align-items-start align-items-sm-center card-inner ${active === `temp-${index + 1}` ? 'patient-filtercard-active' : ''}`}>
          <div className="value">
            {element.value === null ? 0 : element.value}
          </div>
          <div className="key">
            <span>{element.title}</span>
            <span ><img className='img1' src={element.logo} /></span>
            {element.sessionValues !== null ? (
              <div className={element.customClass || 'd-none'}>
                <p className="mb-0">{element.sessionValues}</p>
              </div>
            ) : null}
          </div>
          {element.filterIcon ? (
            <span
              className="filter-icon position-absolute"
              style={{ right: '2rem', top: '1rem' }}
            />
          ) : null}
        </div>
      </div>
    );
  });
};

export default getCardComponent;
