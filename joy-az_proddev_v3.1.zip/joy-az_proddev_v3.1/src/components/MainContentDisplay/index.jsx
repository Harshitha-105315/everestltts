import React from 'react';
import { connect } from 'react-redux';
import AlertMessage from 'components/AlertMessage';

function MainContent(props) {
  const { filterEnabled, children, styleClass } = props;
  return (
    <div id="wrapper-component">
      <AlertMessage />
      <div
        id="main-content"
        className={`${filterEnabled ? '' : 'hide-display'} ${styleClass || ''}`}
      >
        {children}
      </div>
    </div>
  );
}

const mapStateToProps = state => {
  const { userReducer } = state.app;
  return {
    response: userReducer.response,
    totalUsers: userReducer.totalUsers,
    filterEnabled: state.app.filterReducer.filterEnabled
  };
};
export default connect(
  mapStateToProps,
  null
)(MainContent);
