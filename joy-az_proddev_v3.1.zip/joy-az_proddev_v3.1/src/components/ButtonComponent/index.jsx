import React from 'react';

const ButtonComponent = props => {
  const {
    id,
    buttonClass,
    buttonAction,
    hidden,
    icon,
    buttonText,
    disabled,
    textClass,
    style,
    submit,
    noDefault
  } = props;

  let isMobile = false;
  if (window.innerWidth < 575) {
    isMobile = true;
  }

  return (
    // eslint-disable-next-line react/button-has-type
    <button
      {...(style ? { style } : {})}
      {...(id ? { id } : {})}
      className={`${hidden ? '' : 'd-inline-block'} ${
        noDefault ? '' : 'overview-button'
      } all-buttons pl-2 pr-2 ${buttonClass || ''}`}
      {...(buttonAction ? { onClick: buttonAction } : {})}
      {...(hidden ? { hidden } : {})}
      disabled={disabled || false}
      type={submit ? 'submit' : 'button'}
    >
      {icon && (
        <span
          className={`d-inline-block ${
            isMobile ? 'ml-2' : 'ml-3'
          } align-middle ${icon || ''}`}
        />
      )}
      <span
        className={`d-inline-block pl-3 ${
          isMobile ? 'mr-2' : 'mr-3'
        } ${textClass || ''}`}
      >
        {buttonText}
      </span>
    </button>
  );
};

export default ButtonComponent;
