import React, { Component } from 'react';
import { Form } from 'react-bootstrap';

import strings from 'localization/strings';
import './FormControlComponent.scss';

class FormControlComponent extends Component {
  state = {
    focus: false
  };

  onFocus = e => {
    this.setState({ focus: true });
    const { onFocus } = this.props;
    if (onFocus) onFocus(e);
  };

  onBlur = e => {
    this.setState({ focus: false });
    const { onBlur } = this.props;
    if (onBlur) onBlur(e);
  };

  render() {
    const { maxLength } = this.props;
    const { focus } = this.state;
    return (
      <div className="form-control-component">
        <Form.Control
          {...this.props}
          onFocus={e => this.onFocus(e)}
          onBlur={e => this.onBlur(e)}
        />
        {focus && maxLength ? (
          <span className="info-hint">
            {`${strings.maxCharLimit}: ${maxLength}`}
          </span>
        ) : null}
      </div>
    );
  }
}

export default FormControlComponent;
