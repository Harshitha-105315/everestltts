import React from 'react';
import Header from './Header';
import './Styles.scss';
import { FootNote } from 'components/FootNote';

const Disclosures = props => {
  return (
    <div className="pageContainer">
      <Header />
      <div className="pageContent">
        <div className="pageHeading">ESIGN DISCLOSURES AND CONSENT</div>
        <div className="para bold less">
          The company that provided the document update by you through this
          service is required to obtain your consent for the following:
        </div>
        <div className="para less">
          We are required by law to provide you with certain disclosures,
          documents and information about the products, services or account you
          may receive or access by doing business with us (‘Required
          Information’). With your consent, we can deliver Required Information
          you by a) displaying or delivering the Required Information
          electronically; and b) requesting that you print or download the
          Required Information and retail it for your records. Your consent also
          permits the general use of electronic records and electronic
          signatures in connection with the Required Information.
          <br />
          <br />
          You may request to receive Required Information on paper, but if you
          do not consent to its electronic delivery, we cannot proceed to do
          business with you in connection to the products, services or accounts.
          <br />
          <br />
          If you consent to electronic delivery of Required Information, you may
          withdraw that consent at any time by calling us. However, if you
          withdraw your consent we will not be able to continue to do business
          with you in connection to the products, services or account.
          <br />
          <br />
          If you consent to electronic disclosures, that consent applies to all
          Required Information we give you or receive from you in connection
          with our relationship and the associated notices, disclosures, and
          other documents.
          <br />
          <br />
          Even if you consent to receive the Required Information
          electronically, it may be necessary for certain Required Information
          or other communications to be delivered to or from you on paper to a
          specified address.
          <br />
          <br />
          You agree to download or print out Required Information when we advise
          you to do so and keep it for your records. If you are unable to print
          or download any Required Information, you may call us and request
          paper copies. If you need to update your email address or other
          contact information with us, you may do so by calling us and
          requesting the necessary updates.
        </div>
        <div className="para bold less">
          I have read the information about the use of electronic records,
          disclosures and notices, and consent to use of electronic records for
          the delivery of the Required Information in connection with our
          relationship. I also consent the use of electronic records and
          electronic signatures in place of the written documents and
          handwritten signatures. I have been able to use a computer, a tablet
          or mobile phone to view the information through web pages and email
          and acknowledge that I can also view information presented in PDF
          format file on those some devices.
        </div>
      </div>
      <div className="footerContainer">
        <FootNote />
      </div>
    </div>
  );
};

export default Disclosures;
