import React from 'react';
import Header from './Header';
import './Styles.scss';
import { FootNote } from 'components/FootNote';

const PrivacyPolicy = props => {
    return (
        <div className="pageContainer">
            <Header />
            <div className="pageContent">
                <div className="pageHeading">Hillrom<sub>®</sub> Privacy Policy</div>
                <div className="para">
                    Hill-Rom Holdings, Inc. ("Hillrom”) operates the Connex® app (the "app"), which is hosted in the United States. At Hillrom, we respect the privacy of our customers.  We want you to understand how we collect and use data about your app usage.  This Privacy Policy outlines what information the app collects, how we use that information, what choices you have concerning how such information is used, and how we protect your information. We encourage you to read our Privacy Policy carefully so you will understand our commitment to your privacy. By using this app, you agree to the terms of this Privacy Policy.  Whenever you submit information via this app, you consent to the collection, use, and disclosure of that information in accordance with this Privacy Policy and the Terms of Use.
            </div>
                <div className="paraHeading">Introduction</div>
                <div className="para">
                    The information we collect and how we use it depends on what you do when using our app. We collect
                    and use your non-personal information differently than your personal information.
                </div>
                <div className="paraHeading">What is Non-Personal Information?</div>
                <div className="para">
                    Non-personal information is information we collect through this app that is not
                    identifiable to you. As you navigate through this app, we may collect non-personal
                    information about you. This may include the operating system you use,
                    your country of origin, the date and time you access our app,
                    and features in the app you use.
                </div>
                <div className="paraHeading">
                    How Do We Use Non-Personal Information?
                </div>
                <div className="para">
                    Because non-personal information cannot identify you or other users of our app, there are no restrictions to the way Hillrom can use or share non-personal information. We will use non-personal information collected through the app to improve our app, and we may share this information with others.
                </div>
                <div className="paraHeading">What is Personal Information?</div>
                <div className="para">
                    Personal information is information that can be uniquely identified with you, such as your name, address, telephone number, fax number, company name, or e-mail address.  We will use and disclose this information in accordance with all applicable laws, including, but not limited to the Health Insurance Portability and Accountability Act of 1996 (“HIPAA”).
                </div>
                <div className="paraHeading">
                    How Do We Use Personal Information You Provide?
                </div>
                <div className="para">
                    We may use personal information you submit to us to communicate information to you, provide you with information we believe may be of interest to you, develop and improve programs, products, services, and content, and for marketing and research purposes. In the ordinary course of business, we will share some personal information with companies we hire to perform services or functions on our behalf, such as contractors or vendors we use to support our business. In all cases in which we share your personal information with a third party, we will not authorize them to use or disclose your information with others except for the purpose of providing the services we asked them to provide. We will not sell, exchange, or publish your personal information, except in conjunction with a corporate sale, merger, dissolution, or acquisition.  We also may disclose personal information in order to respond to a subpoena, court order, search warrant, a law enforcement agency's request, or as otherwise required by law or regulation.
                </div>
                <div className="paraHeading">Access and Correction</div>
                <div className="para">
                    To keep personal information you provide via this app accurate, current, and complete, please contact us at <a href="mailto:connexsupport@hillrom.com" style={{ color: "blue" }}>connexsupport@hillrom.com</a> or (800) 426-4224  and we will take appropriate steps to update or correct such information in our possession, or to delete you from our contact list.
                </div>
                <div className="paraHeading">Security</div>
                <div className="para">
                    We take reasonable steps to protect your personal information from loss, misuse, unauthorized access, disclosure, alteration, or destruction. We cannot, however, guarantee the security of any information that you disclose to us via our app.
               </div>
                <div className="paraHeading">Children</div>
                <div className="para">
                    This app is not intended for children under the age of 13. We do not knowingly collect information from app users in this age group, nor do we knowingly allow children under the age of 13 to register with us, order our products, communicate with us, or to use any of our online services. Any user of this app under the age of 13 should ask an adult to contact us rather than contacting us directly
                </div>
                <div className="paraHeading">Changes to this Privacy Policy</div>
                <div className="para">
                    We reserve the right to modify this Privacy Policy at any time. If this Privacy Policy changes, we will post the revised policy on this site. Any such change will be effective immediately upon posting. This Privacy Policy was last modified on September 7, 2020.
                </div>
                <div className="paraHeading">HIPAA</div>
                <div className="para">
                    Hillrom maintains a separate HIPAA Notice of Privacy Practices, which can be accessed here: <a href="https://connex.hillrom.com/hipaa" style={{ color: "blue" }}>https://connex.hillrom.com/hipaa</a>
                </div>
            </div>
            <div className="footerContainer">
                <FootNote />
            </div>
        </div>
    );
};

export default PrivacyPolicy;
