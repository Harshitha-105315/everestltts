import React from 'react';
import Header from './Header';
import './Styles.scss';
import { FootNote } from 'components/FootNote';

const TermsOfUSe = props => {
  return (
    <div className="pageContainer">
      <Header />
      <div className="pageContent">
        <div className="pageHeading">TERMS AND CONDITIONS</div>
        <div className="para">
          Welcome to Connex® Health Portal (“Connex” or “the Website”), a
          service offered to you by Hill-Rom Holdings, Inc. (“Hill-Rom”), which
          provides therapy information to patients and health care professionals
          regarding The Vest® System. You may have previously received
          information from Hill-Rom regarding the Website’s features. If you
          have not, you may request such information from Hill-Rom Respiratory
          Care Customer Support by calling (800) 426-4224 or by contacting
          Hill-Rom at the address provided at the end of this agreement. <br />
          <br />
          Your access and use of Connex is exclusively subject to the terms
          and conditions of use set forth below, legal notices that may be
          published on the Website from time to time, and the Hill-Rom Privacy
          Policy, which is incorporated herein by reference and accessible at
          http://www.hill-rom.com/usa/Privacy-Policy/ (collectively, the “Terms
          and Conditions.”). Please read the Terms and Conditions carefully
          before accessing or using the Website, as they govern the entire
          content of the Website, your use of the Website, and all information
          and services accessible and provided via the Website, including any
          correspondence between you, Hill-Rom, or its affiliates and any
          content accessed through links to third-party websites. <br />
          <br /> If you have any questions concerning the use of the Website or
          the Terms and Conditions, please contact us by using the contact
          information at the end of this agreement.
        </div>
        <div className="paraHeading">General</div>
        <div className="para">
          By accessing the Website, you represent and warrant that you have
          read, understand, and agree to all of the terms, conditions, and
          disclaimers provided in the Terms and Conditions, regardless of
          whether or not you choose to register with the Website. You further
          represent and warrant that you are of legal age to form a binding
          contract with Hill-Rom. If at any point you do not agree or do not
          accept the Terms and Conditions, you must immediately stop using
          Connex.
        </div>
        <div className="paraHeading">
          MODIFICATIONS TO THE TERMS AND CONDITIONS OR THE WEBSITE
        </div>
        <div className="para">
          Hill-Rom reserves the right to revise and update the Terms and
          Conditions at any time. Hill-Rom will implement any changes to the
          Terms and Conditions by updating the language of this agreement or the
          Hill-Rom Privacy Policy or by publishing legal notices on the Website
          from time to time. It is important that you review the Terms and
          Conditions regularly to check for any such changes, because your
          continued use of Connex will mean that you accept and agree to be
          bound by the modified Terms and Conditions. If you do not accept any
          modifications to the Terms and Conditions, your sole recourse will be
          to cease using the Website. <br /> We reserve the right, in our sole
          discretion and at any time, to modify or discontinue, temporarily or
          permanently, the Website (or any part thereof), with or without
          notice. You agree that we shall not be liable to you or any third
          party for any modification, suspension, or discontinuance of the
          Website.
        </div>
        <div className="paraHeading">NOT MEDICAL ADVICE</div>
        <div className="para">
          The Website is not intended to provide medical advice. The Website
          contains general medical information regarding The Vest® System for
          informational and educational purposes only, and it is not a
          substitute for medical judgment, advice, diagnosis, or treatment of
          any health condition or problem. The Website does not address all
          possible uses, actions, precautions, side effects, or interactions
          with other pharmaceutical products or medical devices. You should
          consult with a health care professional prior to making any decisions
          or undertaking (or not undertaking) any actions related to any health
          care decision, problem, or issue. If you have any questions about the
          risks or benefits of using The Vest® System or about a specific health
          condition, you should consult with a licensed health care
          professional. You should never disregard, avoid, or delay obtaining
          professional medical advice from a licensed health care professional
          based on any information you obtain through accessing the Website.
          <br />
          INFORMATION RECEIVED BY ACCESSING THE WEBSITE SHOULD NOT BE RELIED
          UPON FOR PERSONAL MEDICAL DECISIONS. YOU SHOULD CONSULT AN APPROPRIATE
          PROFESSIONAL FOR SPECIFIC ADVICE TAILORED TO YOUR MEDICAL OR HEALTH
          SITUATION. NO REPRESENTATION IS MADE REGARDING THE ACCURACY OR
          IMPORTANCE OF ANY INFORMATION CONVEYED ON OR INFERRED FROM THE
          WEBSITE. <br /> NO STATEMENTS MADE ON THE WEBSITE HAVE BEEN EVALUATED
          BY THE FOOD AND DRUG ADMINISTRATION. THE WEBSITE IS NOT INTENDED TO
          DIAGNOSE, TREAT, CURE, OR PREVENT ANY DISEASE. <br />
          Do not use Connex for medical emergency services. In the event of an
          emergency, call 911, your personal physician, a licensed health care
          provider, and/or your local emergency assistance number.
        </div>
        <div className="paraHeading">USE OF THE WEBSITE AND ELIGIBILITY</div>
        <div className="para">
          Use of the Website for any illegal purpose is strictly prohibited and
          a violation of the Terms and Conditions. You are required to comply
          with all applicable laws and regulations, and are not permitted to use
          the Website in any manner that violates any Federal, state, local, or
          international law, including, but not limited to, statutes,
          regulations, rules, orders, and treaties, in connection with your
          access to and use of the Website. Such restrictions are in addition to
          the additional limitations set forth in the Terms and Conditions and
          any subsequent modifications thereto. <br /> As a condition of your
          access and use of Connex, you represent and warrant that you will
          not use the Website for any purpose that is unlawful or prohibited by
          the Terms and Conditions. You further agree that, if you choose to
          access the Website from outside the United States, you do so on your
          own initiative, and you are solely responsible for compliance with the
          applicable laws in any foreign jurisdiction. In accessing and
          transmitting information through this website, you agree that we may
          process and store information, including personal information outside
          of the country in which you are located, including in the United
          States. The countries in which we process the information may not have
          the same data protection laws as the country in which you are located.
          <br /> You further agree that you will only access the Website through
          the interfaces we provide and that you will not violate or attempt to
          violate the security of the Website. You agree that you will not
          interfere with or disrupt the Website, or servers or networks
          connected to the Website, or interfere with, disrupt, or inhibit
          others’ use of the Website in any manner. Violations of system or
          network security may result in civil or criminal liability. In
          accordance with the Terms and Conditions, we will investigate and work
          with law enforcement authorities to prosecute users who are involved
          in such violations. <br /> Hill-Rom has the right to take any
          appropriate legal action, including, without limitation, referral to
          law enforcement, for any illegal or unauthorized use of the Website.
          Hill-Rom will not be liable for exercising this right, meaning you
          waive and hold harmless Hill-Rom and its affiliates from any claims
          resulting from any action taken as a result of an investigation by
          Hill-Rom or any law enforcement authority or agency. <br /> Hill-Rom
          reserves the right to restrict, suspend, or terminate your access to
          the Website without notice to you if we believe that you have violated
          any law or the Terms and Conditions.
        </div>
        <div className="paraHeading">CONTENT</div>
        <div className="para">
          Subject to your compliance with the Terms of Condition, Hill-Rom
          grants you a limited, non-exclusive, non-transferable,
          non-sub-licensable license to download, view, and display the Content
          solely in connection with your permitted use of the Website and solely
          for your personal and non-commercial purposes. Hill-ROM may at any
          time revoke your license to use the content on the Website. <br /> You
          understand and acknowledge that all content on the Website is
          proprietary to Hill-Rom, and you may not prepare derivative works of,
          modify, distribute, sell, lease, rent, sublicense, assign, export, or
          transfer in any other manner the services of the Website, or any
          underlying software, technology, or other information, including any
          printed materials of the same, unless expressly authorized hereunder.
          Any use of third-party software provided in connection with the
          Website will be governed by such third parties’ licenses and not by
          the Terms and Conditions. You agree to be responsible for any act or
          omission of any users who access Connex under your account or using
          your password (if you are a registered user) that, if undertaken by
          you, would be deemed a violation of these Terms and Conditions, and
          that such act or omission shall be deemed a violation of these Terms
          and Conditions by you.
        </div>
        <div className="paraHeading">INTELLECTUAL PROPERTY RIGHTS</div>
        <div className="para">
          All content of the Website is the property of or is licensed for use
          by Hill-Rom or other third parties and is protected by applicable
          legislation regarding intellectual property rights, including
          copyright and trademark laws. All intellectual property rights in or
          of Connex belong to Hill-Rom or one of its business partners. The
          content may not be used other than for your personal and
          non-commercial use with all copyright or other proprietary notices
          retained. No unauthorized use, modification, copy, reproduction, or
          retransmission of any part of the content is permitted without the
          express prior written approval of Hill-Rom. <br /> Any trademarks,
          service marks, trade names, or logos displayed on the Website or
          otherwise in connection with Connex are the property of Hill-Rom and
          protected worldwide. No use of any of these marks may be made without
          the prior written consent of Hill-Rom specific for each such use. Use
          of these marks as part of a link to or from any site is prohibited
          unless establishment of such a link is approved in advance by Hill-Rom
          in writing.
        </div>
        <div className="paraHeading">THIRD-PARTY WEBSITES AND CONTENT</div>
        <div className="para">
          To the extent that third-party content is available on or through the
          Website in any manner (e.g., banners or links), Hill-Rom does not
          operate, control, or endorse any third-party content, products, or
          services accessible through the Website in any way. Hill-Rom is not
          responsible for examining or evaluating, and Hill-Rom does not warrant
          the offerings of, any of these businesses or individuals or the
          content of their websites. Hill-Rom does not assume any responsibility
          or liability for the actions, products, or content of any third
          parties, and it is not responsible for any materials or content
          contained on or provided through such sites. Specifically, but without
          limitation, Hill-Rom is not responsible for the appropriateness,
          decency, legality, copyright compliance, accuracy, or any other aspect
          of such sites. Hill-Rom will not be liable for any loss or damage that
          may arise from your use of any third-party site. Should you choose to
          access third-party sites, you should carefully review their privacy
          states and other conditions of use.
        </div>
        <div className="paraHeading">SUBMISSION OF DATA</div>
        <div className="para">
          The Terms and Conditions cover only Connex's on-line privacy
          practices with respect to use and/or disclosure of information
          provided through the Website. For additional information on how
          Hill-Rom uses or discloses your individually identifiable health
          information, see Hill-Rom’s Privacy Policy and its Notice of Privacy
          Practices. The document entitled "Notice of Privacy Practices”, which
          is incorporated herein by reference, and was provided to you in your
          Welcome Packet. The Notice of Privacy Practices is also available upon
          request by contacting Hill-Rom using the contact information provided
          at the end of this agreement. <br />
          Hill-Rom requires you to provide certain personally identifiable
          information ("Personal Information") to use certain features and
          functions of Connex. The Personal Information you provide includes
          information provided during any registration process, including your
          name and date of birth, and any other identifying information
          (including health information) that you submit voluntarily while using
          Connex, such as the information you submit in any form. <br />
          Connex computer resources may be monitored for all lawful purposes,
          including to ensure that use is authorized, for system management, to
          facilitate protection against unauthorized access, and to verify
          security procedures, survivability, and operational security.
          Monitoring includes security testing by authorized entities to test or
          verify the security of this system.
        </div>
        <div className="paraHeading">
          REGISTRATION, ACCOUNT SECURITY, AND ELIGIBILITY
        </div>
        <div className="para">
          Individuals accessing the Website will only have access to certain
          information without registering with Hill-Rom through Connex. Full
          use of the Website is only available to those users who register and
          establish an account and password through Connex. Registered users
          are solely responsible for maintaining the confidentiality of their
          passwords. If you are a registered user, you agree not to share your
          password with anyone or allow anyone to use your account. You also
          agree to take full responsibility for any activity that occurs through
          the use of your account. If you become aware that any other person has
          accessed your account or has obtained your password, you agree to
          notify us immediately. Even if you notify us, you will be responsible
          for any damage caused by the breach of security, both before and after
          the notification. <br />
          Without limiting any rights that Hill-Rom may otherwise have, Hill-Rom
          reserves the right to take any and all action, as it deems necessary
          or reasonable, to ensure the security of the Website and your account,
          including , without limitation, terminating your account, changing
          your password, or requesting additional information to authorize the
          use of your account. Hill-Rom may rely on the authority of anyone
          accessing your account or using your password, and in no event and
          under no circumstances shall Hill-Rom be held liable to you for any
          liability or damages resulting from or arising out of (a) any action
          or inaction of Hill-Rom under this provision, (b) any compromise of
          the confidentiality of your account or password, or (c) any
          unauthorized access to your account or use of your password.
        </div>
        <div className="paraHeading">
          ACCURACY, PRIVACY, AND USE OF PERSONAL INFORMATION
        </div>
        <div className="para">
          Whenever we ask you to identify yourself or to provide any personal
          information, you agree to provide truthful, accurate, current, and
          complete information, and to keep this information current and
          accurate throughout the time you remain a user of the Website. You
          also represent and warrant that you have obtained all necessary
          consents, approvals, and authorizations to provide the information to
          us, and that you are not violating any laws, rules or regulations or
          the rights of any individual or entity, by providing such personal
          information. <br /> The Hill-Rom Privacy Policy and the Notice of
          Privacy Practices explain our handling of the personal information we
          maintain about you. By using the Website, you indicate that you
          understand and agree to the information collection, use, and
          disclosure practices described in these policies or any additional
          notices governing our online services, which are available at
          www.hill-rom.com. If you do not agree to have your information used in
          any of the ways described in these policies or notices, you must
          discontinue use of the Website and not provide us with any personal
          information. If you have questions about our privacy practices, please
          contact us.
        </div>
        <div className="paraHeading">NOT PROFESSIONAL ADVICE</div>
        <div className="para">
          Any information supplied by any employee or agent of Hill-Rom, whether
          by telephone, e-mail, letter, facsimile, or other form of
          communication, is intended solely as general guidance, and does not
          constitute legal, tax, medical, accounting, or other professional
          advice. In addition, the content provided on the Website, or the
          information generated by Hill-Rom from the User information, is
          intended as general educational information, not specific professional
          advice. You agree that you must evaluate and bear all risks associated
          with any use of the Website.
        </div>
        <div className="paraHeading">DISCLAIMER OF WARRANTIES</div>
        <div className="para">
          Our products and services, including the Website, any user
          information, and any links from the Website to any third-party
          websites, are provided AS IS, and we make NO REPRESENTATION OR
          WARRANTY OF ANY KIND with respect to them. <br />
          WE DISCLAIM, TO THE MAXIMUM EXTENT PERMITTED BY LAW, ANY AND ALL (a)
          WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE; (b)
          WARRANTIES AGAINST INFRINGEMENT OF ANY THIRD-PARTY INTELLECTUAL
          PROPERTY OR PROPRIETARY RIGHTS; (c) WARRANTIES RELATING TO THE
          TRANSMISSION OR DELIVERY OF THE WEBSITE; (d) WARRANTIES RELATING TO
          THE ACCURACY, RELIABILITY, CORRECTNESS, OR COMPLETENESS OF DATA MADE
          AVAILABLE ON THE WEBSITE OR OTHERWISE BY HILL-ROM; AND (e) WARRANTIES
          OTHERWISE RELATING TO PERFORMANCE, NONPERFORMANCE, OR OTHER ACTS OR
          OMISSIONS BY HILL-ROM OR ANY THIRD PARTY. FURTHER, THERE IS NO
          WARRANTY THAT THE WEBSITE WILL MEET YOUR NEEDS OR REQUIREMENTS OR THE
          NEEDS OR REQUIREMENTS OF ANY OTHER PERSON. <br /> WE MAKE NO
          WARRANTIES OR REPRESENTATIONS, EXPRESS OR IMPLIED, (a) THAT THE
          INFORMATION PROVIDED THROUGH THE WEBSITE WILL BE FREE FROM ERROR,
          OMISSION, INTERRUPTION, DEFECT, OR DELAY IN OPERATION, OR FROM
          TECHNICAL INACCURACIES OR TYPOGRAPHICAL ERRORS; (b) THAT THE WEBSITE
          WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION; (c) THAT DEFECTS
          OR ERRORS IN THE WEBSITE WILL BE CORRECTED; OR (d) THAT THE CONTENT ON
          THE WEBSITE WILL BE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. ANY
          INFORMATION ON THE WEBSITE IS SUBJECT TO CHANGE WITHOUT NOTICE, AND WE
          DISCLAIM ALL RESPONSIBILITY FOR THESE CHANGES
        </div>
        <div className="paraHeading">LIMITATION OF LIABILITY</div>
        <div className="para">
          YOUR SOLE AND EXCLUSIVE REMEDY FOR ANY CAUSE OF ACTION ARISING UNDER
          THE TERMS AND CONDITIONS IS YOUR RIGHT TO TERMINATE YOUR USE OF THE
          WEBSITE. YOU AGREE THAT WE WILL NOT BE LIABLE UNDER ANY CIRCUMSTANCES
          FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, SPECIAL, EXEMPLARY, PUNITIVE,
          OR OTHER DAMAGES, INCLUDING LOST PROFITS OR COSTS OR ATTORNEY'S FEES
          ARISING OUT OF OR RELATING TO YOUR USE OF THE WEBSITE OR THE PRODUCTS
          OR SERVICES GENERATED BY HILL-ROM FROM USER INFORMATION, INCLUDING BUT
          NOT LIMITED TO BREACH OF CONTRACT, BREACH OF WARRANTY, DEFAMATION,
          NEGLIGENCE, OR STRICT LIABILITY. <br /> Because some jurisdictions do
          not allow the exclusion or limitation of incidental or consequential
          damages, our liability in such jurisdictions shall be limited to the
          extent permitted by law, but the provisions of this section shall in
          any case be interpreted to limit our liability to the greatest extent
          permitted by law. <br />
          IN THE EVENT THAT YOU HAVE A DISPUTE WITH ANOTHER USER RELATED TO,
          ARISING FROM, OR IN ANY WAY CONNECTED WITH YOUR USE OF THE WEBSITE,
          YOU RELEASE HILL-ROM FROM ANY CLAIMS, DEMANDS, AND DAMAGES OF EVERY
          KIND AND NATURE ARISING OUT OF OR IN ANY WAY CONNECTED WITH SUCH A
          DISPUTE, AND AGREE TO HOLD HILL-ROM HARMLESS IN CONNECTION WITH ANY
          SUCH DISPUTE.
        </div>
        <div className="paraHeading">INDEMNIFICATION</div>
        <div className="para">
          YOU AGREE TO INDEMNIFY HILL-ROM, AND OUR OFFICERS, DIRECTORS, OWNERS,
          EMPLOYEES, AGENTS, INFORMATION PROVIDERS, AFFILIATES, PARTNERS, AND
          LICENSORS (THE "HILL-ROM PARTIES") AGAINST, AND HOLD THE HILL-ROM
          PARTIES HARMLESS FROM, CLAIMS, LIABILITY, LOSSES, COSTS, AND EXPENSES
          (INCLUDING REASONABLE ATTORNEYS' FEES) INCURRED AS A RESULT OF OR IN
          CONNECTION WITH YOUR USE OF THE WEBSITE.
        </div>
        <div className="paraHeading">TERMINATION</div>
        <div className="para">
          We reserve the right, in our sole discretion, to terminate, suspend,
          or limit your access to the Website, or any portion thereof, at any
          time without notice to you. If we do so, the provisions of the Terms
          and Conditions will survive such termination, except that you will not
          be permitted to use the Website to the extent that we terminate,
          suspend, or limit your access. You may also discontinue your own
          access to the Website by contacting us in writing to request that your
          account be terminated.
        </div>
        <div className="paraHeading">GOVERNING LAW AND INTEGRATION</div>
        <div className="para">
          You agree that any dispute between you and Hill-Rom will be governed
          by the law of the State of Illinois without regard to its conflict of
          law provisions, and that any legal action brought by one party against
          the other will be brought in the courts of Cook County, Illinois. You
          agree to accept service of process by mail and hereby waive any and
          all jurisdictional and venue defenses otherwise available. <br />
          Unless otherwise specified herein, the Terms and Conditions constitute
          the entire agreement between you and Hill-Rom with respect to your use
          of the Website and any materials or information generated by Hill-Rom
          from the User information obtained on the Website. The Terms and
          Conditions supersede any prior or contemporaneous communications and
          proposals in any form between you and Hill-Rom.
        </div>
        <div className="paraHeading">CONTACT INFORMATION</div>
        <div className="para">
          You may contact us as follows:
          <br /> Email: HCCSWEB@hill-rom.com <br /> Telephone: 1-800-426-4224
          <br />
          Fax: 1-800-870-8452 <br /> Mail: Hill-Rom <br /> 1020 County Road F
          West <br /> St. Paul, MN 55126
        </div>
      </div>
      <div className="footerContainer">
        <FootNote />
      </div>
    </div>
  );
};

export default TermsOfUSe;
