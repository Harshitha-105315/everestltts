import React from 'react';
import './Header.scss';
import logo from './../../assets/img/logo-new.svg';
const PrivacyPolicy = props => {
  return (
    <div className="headerContainer">
      <img src={logo} className="logo" alt="Hillrom logo" />
      <div className="detailsContent">
        <div className="visiView-text">Connex®</div>
        <div className="portal-text">Health Portal</div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
