import React from 'react';
import Header from './Header';
import './Styles.scss';
import { FootNote } from 'components/FootNote';

const HIPAA = props => {
  return (
    <div className="pageContainer">
      <Header />
      <div className="pageContent">
        <div className="pageHeading">NOTICE OF PRIVACY PRACTICES</div>
        <div className="para right">
          Original Effective Date: April 1, 2003 <br />
          Effective Date of Last Revision: July 15, 2013
        </div>
        <div className="para">
          THIS NOTICE DESCRIBES HOW MEDICAL INFORMATION ABOUT YOU MAY BE USED
          AND DISCLOSED AND HOW YOU CAN GET ACCESS TO THIS INFORMATION. PLEASE
          REVIEW IT CAREFULLY. If you have any questions about this Notice, or
          wish to make a request in accordance with your rights described below,
          please contact the Privacy Officer for Hill-Rom at (812) 931-2246 or
          at Privacy_Officer@hill-rom.com.
        </div>
        <div className="paraHeading">WHO WILL FOLLOW THIS NOTICE?</div>
        <div className="para">
          This Notice describes Hill-Rom’s practices regarding the use of your
          Protected Health Information, specifically including:
          <br /> <span class="dot"></span>
          <div className="dotLine">
            Any Hill-Rom employee or representative authorized to use
            information about you
          </div>
          <span class="dot"></span>
          <div className="dotLine">
            All subsidiaries (including Advanced Respiratory, Inc.), departments
            and units of Hill- Rom
          </div>
          <br /> “Protected Health Information” (“PHI”) is medical information
          about you, including demographic information, that may identify you
          and that relates to your past, present, or future physical or mental
          health or condition and related health services. We are required by
          law to protect the privacy of your PHI, to provide you with this
          Notice of our legal duties and privacy practices with respect to your
          PHI, to notify you following a breach of unsecured PHI, and to abide
          by the terms of this Notice as currently in effect. We reserve the
          right to revise, amend, interpret and administer our privacy practices
          and this Notice.
        </div>
        <div className="paraHeading">
          OUR PLEDGE REGARDING YOUR PROTECTED HEALTH INFORMATION
        </div>
        <div className="para">
          We understand that your Protected Health Information is personal. We
          are committed to protecting your PHI. We create a record of the
          products and services you receive from Hill- Rom. We need this record
          to provide you with quality care and to comply with certain legal
          requirements. This Notice applies to all of the records of products
          and services provided to you by Hill-Rom. Your other health care
          providers may have different policies or notices regarding their use
          and disclosure of your medical information created by them. This
          Notice sets forth different reasons for which we may use and disclose
          your PHI. We will limit our uses and disclosures to the minimum amount
          of PHI necessary to achieve the intended purpose of the use or
          disclosure to the extent required by law.
        </div>
        <div className="paraHeading">
          HOW WE MAY USE AND DISCLOSE YOUR PROTECTED HEALTH INFORMATION
        </div>
        <div className="para less">
          The following categories describe different circumstances in which we
          use and disclose your PHI. For each category of uses or disclosures we
          will explain what we mean and try to give some examples. Not every use
          or disclosure in a category will be listed. However, all of the ways
          we are permitted to use and disclose information will fall within one
          of the categories.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Treatment.</div>
        <div className="dotContent">
          We may use your PHI to provide you with medical treatment or services.
          We may disclose your PHI to doctors, nurses, home health agencies,
          hospital discharge planners, case managers and other medical and
          medical equipment providers who are involved in taking care of you.
          For example, a home health agency or hospital discharge planner
          responsible for your care may share PHI with us if the agency or
          planner believes that you have or are at risk for pressure ulcers (bed
          sores). Or, your physician or another medical service provider may
          share PHI with us if the physician or provider believes you may
          benefit from use of one of our products. We in turn may share that
          information with case managers, physicians and other medical equipment
          providers so that the product most appropriate for your condition may
          be provided. We also may share information with physicians and other
          medical providers who are responsible for oversight of your treatment.
          Different departments within Hill-Rom also may share your PHI in order
          to coordinate the products and services you may need.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Payment.</div>
        <div className="dotContent">
          We may use and disclose your PHI so that the treatment and services
          you receive from Hill-Rom may be billed to and payment may be
          collected from you, a hospital, a nursing home, Medicaid, Medicare, an
          insurance company or another third party. For example, we may need to
          give Medicare, Medicaid or an insurance company information about your
          medical condition so it will pay us or reimburse you. We also may use
          and disclose your PHI to determine your eligibility and/or obtain
          prior approval or to determine whether Medicare, Medicaid or your
          insurance company will cover the service or product.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Health Care Operations.</div>
        <div className="dotContent">
          We may use and disclose your PHI for Hill-Rom’s operations. These uses
          and disclosures are necessary to run our business and make sure that
          all of our patients receive quality care. For example, we may use PHI
          to review our treatment and services and to evaluate the performance
          of our employees in providing services to you. We also may combine the
          PHI of many Hill-Rom patients to decide what additional services or
          products we should offer, what services or products are not needed,
          and whether certain new services or products are effective. We also
          may disclose information to doctors, nurses, technicians, medical
          students, and other health care providers for review and learning
          purposes. We may remove information that identifies you from this set
          of medical information so others may use it to study health care and
          health care delivery without learning who you are.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Treatment Alternatives.</div>
        <div className="dotContent">
          We may use and disclose your PHI to tell you about or recommend
          possible treatment options or alternatives that may be of interest to
          you.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">
          Individuals Involved in Your Care or Payment for Your Care and
          Notification Purposes.
        </div>
        <div className="dotContent">
          We may disclose your PHI to a family member, other relative or close
          personal friend or any other person identified by you who is involved
          in your medical care or payment for your medical care, unless you
          object to such disclosure. If we make such disclosure, we will only
          provide the PHI that is directly related to such person’s involvement
          with your health care or payment for your health care. We also may
          make such a disclosure after your death, unless such disclosure is
          contrary to your expressed preference. We may use or disclose your PHI
          in order to notify or assist in notifying a family member, personal
          representative, close personal friend, or other person responsible for
          your care of your location, general condition or death. In addition,
          we may disclose your PHI to an entity assisting in a disaster relief
          effort so that your family can be notified about your condition,
          status and location.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Research.</div>
        <div className="dotContent">
          Under certain circumstances, we may use and disclose your PHI for
          research purposes. For example, a research project may involve
          comparing the health and recovery of all patients who received one
          product or service to those who received another, for the same
          condition. All research projects, however, are subject to a special
          approval process. This process evaluates a proposed research project
          and its use of PHI, trying to balance the research needs with
          patients’ need for privacy of their medical information. Before we use
          or disclose PHI for research, the project will have been approved
          through this research approval process. We will disclose your PHI for
          this purpose either upon receiving your specific permission or upon a
          waiver of such permission from the board that provides the project
          approval described above. We also may disclose your PHI to people
          preparing to conduct a research project, for example, to help them
          look for patients with specific medical needs, so long as the PHI they
          review does not leave Hill-Rom.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">As Required By Law.</div>
        <div className="dotContent">
          We may disclose your PHI when required or permitted to do so by
          federal, state or local law, to the extent that such disclosure is
          limited to the relevant requirements of such law.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">
          To Avert a Serious Threat to Health or Safety.
        </div>
        <div className="dotContent">
          We may use and disclose your PHI when necessary to prevent a serious
          threat to your health and safety or the health and safety of the
          public or another person. Any disclosure, however, would only be to
          someone able to help prevent the threat.
        </div>
        <div className="paraHeading">SPECIAL SITUATIONS</div>
        <span class="dot"></span>
        <div className="dotHeading">Military and Veterans.</div>
        <div className="dotContent">
          If you are a member of the armed forces, we may release your PHI as
          required by military command authorities. We also may release PHI
          about foreign military personnel to the appropriate foreign military
          authority.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Workers’ Compensation.</div>
        <div className="dotContent">
          We may release your PHI for workers’ compensation or similar programs.
          These programs provide benefits for work-related injuries or illness.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Public Health Risks.</div>
        <div className="dotContent less">
          We may disclose your PHI for public health activities. These
          activities generally include the following:
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To prevent or control disease, injury or disability;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">To report births and deaths;</div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To report child abuse or neglect;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To report reactions to medications or problems with products;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To notify people of recalls of products they may be using;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To notify a person who may have been exposed to a disease or may be at
          risk for contracting or spreading a disease or condition;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To notify the appropriate government authority if we believe a patient
          has been the victim of abuse, neglect or domestic violence. We will
          make this disclosure only if you agree or when required or authorized
          by law.
        </div>
        <br />
        <span class="dot"></span>
        <div className="dotHeading">Health Oversight Activities.</div>
        <div className="dotContent">
          We may disclose PHI to a health oversight agency for activities
          authorized by law. These oversight activities include, for example,
          audits, investigations, inspections, and licensure. These activities
          are necessary for the government to monitor the health care system,
          government programs and compliance with civil rights laws.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Lawsuits and Disputes.</div>
        <div className="dotContent">
          If you are involved in a lawsuit or a dispute, we may disclose your
          PHI in response to a court or administrative order. We also may
          disclose your PHI in response to a subpoena, discovery request or
          other lawful process by someone else involved in the dispute. It is
          our practice to make reasonable efforts to tell you about the request
          and/or to obtain an order protecting the information requested as
          confidential.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Law Enforcement.</div>
        <div className="dotContent less">
          We may release PHI if asked to do so by a law enforcement official:
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          In response to a court order, subpoena, warrant, summons or similar
          process;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          To identify or locate a suspect, fugitive, material witness or missing
          person;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          About the victim of a crime if, under certain limited circumstances,
          we are unable to obtain the person’s agreement;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          About a death we believe may be the result of criminal conduct;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          About criminal conduct at Hill-Rom;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          In emergency circumstances to report a crime; the location of the
          crime or victims; or the identity, description or location of the
          person who committed the crime.
        </div>
        <br />
        <span class="dot"></span>
        <div className="dotHeading">
          Coroners, Medical Examiners and Funeral Directors.
        </div>
        <div className="dotContent">
          We may release PHI to a coroner or medical examiner. This may be
          necessary, for example, to identify a deceased person or determine the
          cause of death. We also may release PHI of patients to funeral
          directors as necessary to carry out their duties.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">
          National Security and Intelligence Activities.
        </div>
        <div className="dotContent">
          We may release your PHI to authorized federal officials for
          intelligence, counterintelligence and other national security
          activities authorized by law.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">
          Protective Service for the President and Others.
        </div>
        <div className="dotContent">
          We may disclose your PHI to authorized federal officials so they may
          provide protection to the President, other authorized persons or
          foreign heads of state, or conduct special investigations.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Inmates.</div>
        <div className="dotContent">
          If you are an inmate of a correctional institution or under the
          custody of a law enforcement official, we may release your PHI to the
          correctional institution or law enforcement official. This release
          would be necessary (1) for the institution to provide you with health
          care; (2) to protect your health and safety or the health and safety
          of others; or (3) for the safety and security of the correctional
          institution.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Fundraising.</div>
        <div className="dotContent">
          We may use or disclose to certain third parties demographic
          information about you and limited information regarding your care for
          the purpose of raising funds for Hill-Rom. You have a right to opt out
          of receiving such communications. Your decision to opt out of such
          communications will not affect the care that we provide to you.
        </div>
        <div className="paraHeading">
          OTHER USES AND DISCLOSURES OF YOUR MEDICAL INFORMATION
        </div>
        <div className="para">
          Uses and disclosures of your PHI other than as described above will be
          made by us only with your written authorization. Your written
          authorization may be revoked at any time so long as you revoke your
          authorization in writing. We will honor your revocation except if we
          have taken action in reliance on your authorization, or your
          authorization was obtained as a condition of obtaining insurance
          coverage and other law provides the insurer with the right to contest
          a claim under the policy or to contest the policy itself. The types of
          uses and disclosures that require an authorization include:
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Psychotherapy Notes.</div>
        <div className="dotContent">
          We must obtain an authorization from you to use or disclose
          psychotherapy notes unless the disclosure is made (1) for certain
          enumerated treatment, payment or health care operations purposes; (2)
          as required by law; (3) for health oversight activities (with respect
          to the originator of the psychotherapy notes); (4) to a coroner or
          medical examiner for purposes of determining a cause of death; or (5)
          to prevent a serious threat to health or safety.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Marketing.</div>
        <div className="dotContent">
          We must obtain an authorization for any use or disclosure of your PHI
          to communicate with you about a product or service that encourages you
          to use or purchase the product or service unless the communication is
          either a face-to-face communication or a promotional gift of nominal
          value. This does not include reminder communications about
          prescriptions, information regarding your course of treatment, case
          management or care coordination, communications to describe a
          health-related product or service that we provide, or contacting you
          in connection with treatment alternatives. If the marketing involves
          financial compensation, we must notify you of such compensation.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Sale of PHI.</div>
        <div className="dotContent">
          We must obtain an authorization for any disclosure of your PHI which
          is a sale of PHI and such authorization must state that the disclosure
          will result in our receipt of financial remuneration.
        </div>
        <div className="paraHeading">
          YOUR RIGHTS REGARDING MEDICAL INFORMATION ABOUT YOU
        </div>
        <div className="para less">
          You have the following rights regarding medical information we
          maintain about you:
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Right to Inspect and Copy.</div>
        <div className="dotContent">
          You have the right to inspect and copy your PHI kept in a designated
          record set that may be used to make decisions about your care.
          Usually, this includes medical and billing records. If Hill-Rom uses
          or maintains an electronic health record with respect to your PHI, you
          have a right to obtain a copy of such information in an electronic
          format. If you have the right to the record in the electronic format,
          if you so choose, you may direct Hill-Rom to transmit that copy
          directly to another entity or person. To inspect and copy your PHI in
          a designated record set, you must submit your request in writing to
          the Privacy Officer. If you request a copy of the information, we may
          charge a fee for the costs of copying, mailing or other supplies
          associated with your request. We may deny your request to inspect and
          copy in certain very limited circumstances and will advise you in
          writing of the reason for such denial. If you are denied access to
          your PHI in a designated record set, you may request that the denial
          be reviewed. A licensed health care professional chosen by us will
          review your request and the denial. The person conducting the review
          will not be the person who denied your request. We will comply with
          the outcome of the review.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Right to Amend.</div>
        <div className="dotContent less">
          If you feel that your PHI is incorrect or incomplete, you may ask us
          to amend the information. You have the right to request an amendment
          for as long as the information is kept by or for us.
          <br /> To request an amendment, your request must be made in writing
          and submitted to the Privacy Officer. In addition, you must provide a
          reason that supports your request. We may deny your request for an
          amendment if it is not in writing or does not include a reason to
          support the request. In addition, we may deny your request if you ask
          us to amend PHI that:
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          Was not created by us, unless the person or entity that created the
          information is no longer available to make the amendment;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          Is not part of the PHI kept by or for us;
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">
          Is not part of the PHI which you would be permitted to inspect and
          copy; or
        </div>
        <span className="hollowDot"> </span>
        <div className="hollowDotContent">Is accurate and complete. </div>
        <br />
        <div className="dotContent">
          Even if we refuse to allow an amendment, however, you are permitted to
          include a patient statement about the information at issue in your
          medical record.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Right to an Accounting of Disclosures.</div>
        <div className="dotContent">
          You have the right to request an “accounting of disclosures.” This is
          a list of the disclosures we made of your PHI for certain purposes.
          You do not have the right to an accounting of disclosures which:
          Hill-Rom has made to you or pursuant to your authorization, are
          disclosures made to carry out treatment, payment and health care
          operations but are not part of an electronic health record, or are
          disclosures permitted or required by law. Beginning January 1, 2011,
          if you request an accounting of disclosures of your PHI, the
          accounting will include disclosures made to carry out Hill-Rom’s
          treatment or payment activities or health care operations through an
          electronic health record, if required by then-applicable regulations.
          To request this list or accounting of disclosures, you must submit
          your request in writing to the Privacy Officer. Your request must
          state the period of time for which you are seeking the accounting of
          disclosures, which may not begin more than six years before the date
          of your request for disclosures of PHI not from electronic health
          record or three years for disclosures of PHI from an electronic health
          record. Your request should indicate in what form you want the list
          (for example, on paper, electronically). The first list you request
          within a 12-month period will be free. For additional lists, we may
          charge you for the costs of providing the list. We will notify you of
          the estimated costs involved and you may choose to withdraw or modify
          your request at that time before any costs are incurred.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Right to Request Restrictions.</div>
        <div className="dotContent">
          You have the right to request a restriction or limitation on the PHI
          we use or disclose about you for treatment, payment, or health care
          operations. You also have the right to request a limit on the PHI we
          disclose about you to someone who is involved in your care or the
          payment for your care, like a family member or friend. For example,
          you could ask that we not use or disclose information about a surgery
          you had. We are not required to agree to your request, except if your
          requested restriction is to prevent disclosure of PHI to a health plan
          for purposes of carrying out payment or health care operations (and
          not for treatment) and the PHI pertains solely to a health care item
          or service for which you have already paid a health care provider
          out-of-pocket in full. If we do agree to your request, we will comply
          with your request unless the information is needed to provide you with
          emergency treatment. To request restrictions, you must make your
          request in writing to the Privacy Officer. In your request you must
          tell us (1) what information you want to limit; (2) whether you want
          to limit our use, disclosure or both; and (3) to whom you want the
          limits to apply, for example, disclosures to your spouse.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">
          Right to Request Confidential Communications.
        </div>
        <div className="dotContent">
          You have the right to request that we communicate with you about your
          personal health matters in a certain way or at a certain location. For
          example, you can ask that we only contact you at work or by mail. To
          request confidential communications, you must make your request in
          writing to the Privacy Officer. We will not ask you the reason for
          your request. We will attempt to accommodate all reasonable requests.
          Your request must specify how or where you wish to be contacted.
        </div>
        <span class="dot"></span>
        <div className="dotHeading">Right to a Paper Copy of This Notice.</div>
        <div className="dotContent">
          You have the right to a paper copy of this Notice. You may ask us to
          give you a copy of this Notice at any time. Even if you have agreed to
          receive this Notice electronically, you are still entitled to a paper
          copy of this Notice. You may obtain a copy of this Notice at our Web
          site, www.hill-rom.com. To obtain a paper copy of this Notice, contact
          the Privacy Officer.
        </div>

        <div className="paraHeading">CHANGES TO THIS NOTICE</div>
        <div className="para">
          We reserve the right to change this Notice. We reserve the right to
          make the revised or changed Notice effective for PHI we already have
          about you as well as any PHI we receive in the future. We will post a
          copy of the current Notice on our Web site. The Notice will contain on
          the first page, in the top right-hand corner, the effective date.
        </div>

        <div className="paraHeading">COMPLAINTS</div>
        <div className="para">
          If you believe your privacy rights have been violated, you may file a
          complaint with Hill-Rom or with the Secretary of the Department of
          Health and Human Services. To file a complaint with Hill-Rom, direct
          your correspondence to the Privacy Officer, 1069 State Route 46 East,
          Batesville, IN 47006. All complaints must be submitted in writing.
          General inquires in this regard may be directed to the Privacy Officer
          at (812) 931-2246.
        </div>
        <div className="paraHeading">
          You will not be penalized for filing a complaint.
        </div>
      </div>
      <div className="footerContainer">
        <FootNote />
      </div>
    </div>
  );
};

export default HIPAA;
