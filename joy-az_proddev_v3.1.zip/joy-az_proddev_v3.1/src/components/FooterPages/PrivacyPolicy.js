import React from 'react';
import Header from './Header';
import './Styles.scss';
import { FootNote } from 'components/FootNote';

const PrivacyPolicy = props => {
  return (
    <div className="pageContainer">
      <Header />
      <div className="pageContent">
        <div className="pageHeading">Hill-Rom Privacy Policy</div>
        <div className="para">
          Hill-Rom Holdings, Inc. ("Hill-Rom”) operates the Hill-Rom.com website
          (the "site"), which is hosted in the United States. At Hill-Rom, we
          respect the privacy of our customers and other visitors to this site.
          We want you to understand how we collect and use data about your site
          visit. This Privacy Policy outlines what information the site
          collects, how we use that information, what choices you have
          concerning how such information is used, and how we protect your
          information. We encourage you to read our Privacy Policy carefully so
          you will understand our commitment to your privacy. By using this
          site, you agree to the terms of this Privacy Policy. Whenever you
          submit information via this site, you consent to the collection, use,
          and disclosure of that information in accordance with this Privacy
          Policy and the Terms of Use.
        </div>
        <div className="paraHeading">Introduction</div>
        <div className="para">
          The information we collect and how we use it depends on what you do
          when visiting our site. We collect and use your non-personal
          information differently than your personal information.
        </div>
        <div className="paraHeading">What is Non-Personal Information?</div>
        <div className="para">
          Non-personal information is information we collect through this site
          that is not identifiable to you. As you navigate through this site, we
          may use various technologies to collect non-personal information about
          you. This may include the type of web browser software you use, the
          name of the domain from which you access the Internet, the address of
          the web site from which you visited prior to entering our site, the
          operating system you use, your country of origin, the date and time
          you access our site, which pages you have visited on our site, whether
          you use “flash” plug-ins, your screen resolution, the search terms you
          use, and the links on which you click. We may also place a small text
          file called a “cookie” in the browser files of your computer when you
          visit. We may use cookies either temporarily in connection with your
          Internet Protocol (IP) address, which will be deleted once you close
          your browser window, or more permanently on your computer’s hard
          drive.
        </div>
        <div className="paraHeading">
          How Do We Use Non-Personal Information?
        </div>
        <div className="para">
          Because non-personal information cannot identify you or other visitors
          to our site, there are no restrictions to the way Hill-Rom can use or
          share non-personal information. We will use non-personal information
          collected through the site to improve our site, and we may share this
          information with others.
        </div>
        <div className="paraHeading">What is Personal Information?</div>
        <div className="para">
          Personal information is information that can be uniquely identified
          with you, such as your name, address, telephone number, fax number,
          company name, or e-mail address. You may fill out a registration form,
          a survey, or an e-mail form, place an order for a product or service
          with us, or you may choose to receive educational and other
          information about our products and services. In these instances, if
          you choose not to provide certain information, you may not be able to
          gain access to certain parts of our site. Additionally, some places on
          our site are intended for our patients, their families, and caregivers
          who are using our products. In these places, you may choose to submit
          information to us about your use of our product, update your contact
          or insurance information, or complete a survey. We will use and
          disclose this information in accordance with all applicable laws,
          including, but not limited to the Health Insurance Portability and
          Accountability Act of 1996 (“HIPAA”).
        </div>
        <div className="paraHeading">
          How Do We Use Personal Information You Provide?
        </div>
        <div className="para">
          We may use personal information you submit to us to communicate
          information to you (if you have requested it), provide you with
          information we believe may be of interest to you, develop and improve
          programs, products, services, and content, and for marketing and
          research purposes. In the ordinary course of business, we will share
          some personal information with companies we hire to perform services
          or functions on our behalf, such as contractors or vendors we use to
          support our business. In all cases in which we share your personal
          information with a third party, we will not authorize them to use or
          disclose your information with others except for the purpose of
          providing the services we asked them to provide. We will not sell,
          exchange, or publish your personal information, except in conjunction
          with a corporate sale, merger, dissolution, or acquisition. We also
          may disclose personal information in order to respond to a subpoena,
          court order, search warrant, a law enforcement agency's request, or as
          otherwise required by law or regulation.
        </div>
        <div className="paraHeading">
          Submitting Feedback or Ideas through Our Site
        </div>
        <div className="para">
          When you submit an idea or proposal to us through the Hill-Rom Ideas
          Center web site, you expressly agree to the terms of our policy for
          accepting outside ideas or proposal as set forth in the Terms and
          Conditions for Submission of Ideas and Proposals. If you choose to
          provide or submit ideas, feedback, or suggestions to us in any other
          way through our site ("Unsolicited Information"), you agree that you
          are not disclosing any confidential information to us, that you are
          submitting such Unsolicited Information on a non-confidential basis,
          and that no confidential relationship or obligation of secrecy or
          nonuse is created or implied by the submission, irrespective of any
          statements in the Unsolicited Information. You agree that all rights
          and remedies regarding confidentiality, trade secret, and copyright
          are hereby waived by you with respect to the Unsolicited Information.
          You also agree that immediately upon submission of the Unsolicited
          Information, we have the unrestricted right to use, reproduce,
          distribute, exhibit, rearrange, adopt, modify, and distribute the
          Unsolicited Information to others without limitation, and make, use,
          sell, market, import, develop, or manufacture products incorporating
          such information, without compensation, except to the extent that such
          information is validly protected under the patent or trademark laws or
          under any written contract which may later be signed by an officer of
          our company. You further agree that we are under no obligation to
          review or use the Unsolicited Information, and that we are under no
          obligation to return any Unsolicited Information submitted by you or
          to reveal to you what if anything we have done in connection with such
          Unsolicited Information.
        </div>
        <div className="paraHeading">Other Websites</div>
        <div className="para">
          This site may contain links to other web sites. We are not responsible
          for the privacy policies of web sites to which our site links. If you
          provide any information to such third parties, different rules
          regarding the collection and use of your personal information may
          apply. We strongly suggest you review such third party's privacy
          policies before providing any data to them.
        </div>
        <div className="paraHeading">Access and Correction</div>
        <div className="para">
          To keep personal information you provide via this site accurate,
          current, and complete, please contact us as specified below and we
          will take appropriate steps to update or correct such information in
          our possession, or to delete you from our contact list.
        </div>
        <div className="paraHeading">Security</div>
        <div className="para">
          We take reasonable steps to protect your personal information from
          loss, misuse, unauthorized access, disclosure, alteration, or
          destruction. We cannot, however, guarantee the security of any
          information that you disclose to us via our site.
        </div>
        <div className="paraHeading">Children</div>
        <div className="para">
          This site is not intended for children under the age of 13. We do not
          knowingly collect information from site visitors in this age group,
          nor do we knowingly allow children under the age of 13 to register
          with us, order our products, communicate with us, or to use any of our
          online services. Any visitor to this site under the age of 13 should
          ask an adult to contact us rather than contacting us directly.
        </div>
        <div className="paraHeading">Changes to this Privacy Policy</div>
        <div className="para">
          We reserve the right to modify this Privacy Policy at any time. If
          this Privacy Policy changes, we will post the revised policy on this
          site. Any such change will be effective immediately upon posting. This
          Privacy Policy was last modified on December 3, 2012.
        </div>
        <div className="paraHeading">HIPAA</div>
        <div className="para">
          Hill-Rom maintains a separate HIPAA Notice of Privacy Practices, which
          can be accessed here.
        </div>
      </div>
      <div className="footerContainer">
        <FootNote />
      </div>
    </div>
  );
};

export default PrivacyPolicy;
