import React from 'react';
import './FootNote.scss';
import strings from 'localization/strings';
import { Nav } from 'react-bootstrap';
import urls from '../../urls';
function FootNote(props) {
  return (
    <div
      id="foot-note"
      className="d-flex flex-column flex-sm-row justify-content-between"
    >
      <div className="footer-left order-2 order-sm-1">
        <div dangerouslySetInnerHTML={{ __html: strings.copyright }} />
      </div>
      <div className="d-flex footer-right order-1 order-sm-2 justify-content-between justify-content-sm-start">
        <Nav className="flex-column flex-sm-row">
          <Nav.Item>
            <Nav.Link
              href="//respiratorycare.hill-rom.com/en/about-us/customer-service/"
              target="_blank"
            >
              {strings.contactUs}
            </Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link href="//www.hillrom.com/en/about-us/global-privacy-notice" target="_blank">
              {strings.privacyPolicy}
            </Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link href={urls.TERMSOFUSE} target="_blank">
              {strings.termsOfUse}
            </Nav.Link>
          </Nav.Item>
        </Nav>
        <Nav className="flex-column flex-sm-row">
          <Nav.Item>
            <Nav.Link href="//www.hillrom.com/content/dam/hillrom-aem/us/en/marketing/about/overview/privacy-notice/Notice-of-Privacy-Practices%20HIPAA%20280-007-7126-EN-r6-LR.pdf" target="_blank">
              {strings.hipaaNotice}
            </Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link href="//respiratorycare.hill-rom.com/" target="_blank">
              {strings.respiratoryCareSite}
            </Nav.Link>
          </Nav.Item>
        </Nav>
      </div>
    </div>
  );
}

export { FootNote };
