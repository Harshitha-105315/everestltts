import React from 'react';
import { connect } from 'react-redux';
import { Button } from 'react-bootstrap';
import constants from 'constants.js';
import strings from 'localization/strings';
import './AlertMessage.scss';

class AlertMessage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showMsg: false
    };
    this.closeMsg = this.closeMsg.bind(this);
  }

  componentWillReceiveProps(newProps) {
    const { status, response, isScrollNotRequired } = newProps;
    const { showMsg } = this.state;
    const scrollNotRequired =
      typeof isScrollNotRequired === 'undefined' ? false : isScrollNotRequired;
    const isAllowed =
      status === constants.ALERT.ADD_SUCCESS && showMsg ? false : showMsg;
    if (status && !isAllowed) {
      if (status === constants.ALERT.ADD_SUCCESS) {
        const { path, history } = response;
        if (path) {
          history.push(path);
        }
        if (path === false) {
          this.setState({ showMsg: true });
        }
      } else if (
        status === constants.ALERT.SUCCESS ||
        status === constants.ALERT.FAILURE ||
        status === constants.ALERT.RESET_SUCCESS ||
        status === constants.ALERT.DELETE_SUCCESS ||
        status === constants.ALERT.CUSTOM
      ) {
        this.setState({ showMsg: true });
      }
    }
    if (!scrollNotRequired) {
      window.scrollTo({
        behavior: 'smooth',
        left: 0,
        top: 0
      });
    }
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({ type: constants.ALERT.UPDATE_RESPONSE_STATUS });
  }

  closeMsg() {
    const { dispatch } = this.props;
    dispatch({ type: constants.ALERT.UPDATE_RESPONSE_STATUS });
    this.setState({ showMsg: false });
  }

  render() {
    const { status, response } = this.props;
    const responseType = {
      SUCCESS: {
        backgroundColor: '#739dd2',
        message: strings.updatedSuccessfully
      },
      FAILURE: {
        backgroundColor: '#fc2e2e',
        message: strings.internalServerError
      },
      RESET_SUCCESS: {
        backgroundColor: '#739dd2',
        message: strings.resetSuccesfully
      },
      DELETE_SUCCESS: {
        backgroundColor: '#739dd2',
        message: strings.deletedSuccessfully
      },
      ADD_SUCCESS: {
        backgroundColor: '#739dd2',
        message: strings.addedSuccessfully
      },
      CUSTOM: {
        backgroundColor: '#739dd2',
        message: response.message
      }
    };
    const { showMsg } = this.state;
    if (status === constants.ALERT.FAILURE && response) {
      responseType[status].message = response;
    }
    if (showMsg && responseType[status]) {
      return (
        <div
          style={{
            backgroundColor: responseType[status].backgroundColor
          }}
          id="custom-alert-message"
          onBlur={this.closeMsg}
        >
          <div className="row">
            <div className="alert-message m-auto col-10">
              {responseType[status].message}
            </div>
            <div className="m-auto col-2">
              <Button
                id="msg-close-button"
                className="float-right"
                onClick={this.closeMsg}
              >
                {strings.close}
              </Button>
            </div>
          </div>
        </div>
      );
    }
    return null;
  }
}

const mapStateToProps = state => {
  const { AlertMessageReducer } = state.app;
  return {
    status: AlertMessageReducer.status,
    response: AlertMessageReducer.response,
    isScrollNotRequired: AlertMessageReducer.isScrollNotRequired
  };
};
export default connect(
  mapStateToProps,
  null
)(AlertMessage);
