import constants from 'constants.js';
import { Object } from 'es6-shim';

const intialState = {
  status: '',
  response: '',
  isScrollNotRequired: false
};

function AlertMessageReducer(state = intialState, action) {
  switch (action.type) {
    case constants.ALERT.ADD_SUCCESS_RESPONSE: {
      const { history, path } = action.response;
      return Object.assign({}, state, {
        status: constants.ALERT.ADD_SUCCESS,
        response: {
          history,
          path
        }
      });
    }
    case constants.ALERT.UPDATE_SUCCESS_RESPONSE: {
      return Object.assign({}, state, {
        status: constants.ALERT.SUCCESS
      });
    }
    case constants.ALERT.FAILURE_RESPONSE: {
      let res = '';
      if (action.response) {
        if (action.response.message) {
          res = action.response.message;
        } else if (
          typeof action.response === 'string' ||
          action.response instanceof String
        ) {
          res = action.response;
        }
      }
      return Object.assign({}, state, {
        status: constants.ALERT.FAILURE,
        response: res,
        isScrollNotRequired: action.response
          ? action.response.isScrollNotRequired
          : false
      });
    }
    case constants.ALERT.UPDATE_RESPONSE_STATUS: {
      return Object.assign({}, state, {
        status: false
      });
    }
    case constants.ALERT.RESET_SUCCESS: {
      return Object.assign({}, state, {
        status: constants.ALERT.RESET_SUCCESS
      });
    }
    case constants.ALERT.DELETE_SUCCESS: {
      return Object.assign({}, state, {
        status: constants.ALERT.DELETE_SUCCESS
      });
    }
    case constants.ALERT.CUSTOM: {
      return Object.assign({}, state, {
        status: constants.ALERT.CUSTOM,
        response: action.response
      });
    }
    default: {
      return state;
    }
  }
}
export default AlertMessageReducer;
