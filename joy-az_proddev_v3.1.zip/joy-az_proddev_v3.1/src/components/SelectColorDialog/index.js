import React, { Component } from 'react';
import { Modal, Image, Form, Col } from 'react-bootstrap';
import Close from 'assets/img/ic-close-big-white.svg';
import strings from 'localization/strings';
import ColorPDF from 'assets/img/pdf_red_icon.svg';
import BnwPDF from 'assets/img/pdf_black_white_icon.svg';
import './SelectColorDialog.scss';

class SelectColorDialog extends Component {
	render() {
		const { show, handleClose, handleChange } = this.props;
		return (
			<Modal className={`color-select-modal-main`} centered show={show} onHide={handleClose}>
				<Modal.Header>
					<Modal.Title>{strings.selectPrintType}</Modal.Title>
					<Image
						src={Close}
						width="17"
						height="17"
						onClick={handleClose}
						className="d-inline-block"
						alt="Close"
					/>
				</Modal.Header>
				<Modal.Body className="my-4">
					<div className="row justify-content-around">
						<Form.Row className="color-section-item">
							<Form.Group as={Col} className="col-12 col-sm flex-column d-flex align-items-center color-select-option" onClick={() => handleChange(true)}>
								<Image
									src={BnwPDF}
									width="50"
									height="50"
									onClick={() => handleChange(true)}
									className="d-inline-block mx-2 my-3"
									alt="Blank and white pdf"

								/>
								<Form.Label>{strings.blackAndWhite}</Form.Label>
							</Form.Group>
						</Form.Row>
						<Form.Row className="color-section-item">
							<Form.Group as={Col} className="col-12 col-sm flex-column d-flex align-items-center color-select-option" onClick={() => handleChange(false)}>
								<Image
									src={ColorPDF}
									width="50"
									height="50"
									onClick={() => handleChange(false)}
									className="d-inline-block mx-2 my-3"
									alt="Color pdf"
								/>
								<Form.Label>{strings.color}</Form.Label>
							</Form.Group>
						</Form.Row>
					</div>
				</Modal.Body>
			</Modal >
		);
	}
};

export default SelectColorDialog;
