import React from 'react';
import { Nav } from 'react-bootstrap';
import logoImage from 'assets/img/logo/hillrom-logo.png';
import './LoginShell.scss';
import Landing from 'components/Landing';
import strings from 'localization/strings';
import urls from '../../urls';

function LoginShell(props) {
  return (
    <div className="container-fluid">
      <div id="login-wrapper" className="row">
        <Landing />
        <div
          id="login-mask"
          className="col-12 col-sm-auto p-0 d-flex flex-column"
        >
          <div id="login-form" className={props.modifierClass}>
            <img
              id="brand-logo-mobile"
              className="d-block d-sm-none"
              src={logoImage}
              alt="Hillrom logo"
            />
            <h1 className="text-white text-left visi-view d-none d-sm-block">
              Connex<sup className="registered">®</sup>
            </h1>
            <h2 className="text-white text-left health-portal d-none d-sm-block">
              Health Portal
            </h2>
            {props.children}
          </div>
          <div id="login_curve" />
          <div className="login-after-box flex-grow-1 d-flex align-items-center justify-content-center">
            {props.below_form_content}
          </div>
        </div>
        <div className="col-12 footer d-none d-sm-block">
          <div className="row justify-content-between">
            <div className="col-auto">
              <span
                className="copyright"
                dangerouslySetInnerHTML={{ __html: strings.copyright }}
              />
            </div>
            <div className="col-auto">
              <Nav>
                <Nav.Item>
                  <Nav.Link
                    href="//respiratorycare.hill-rom.com/en/about-us/customer-service/"
                    target="_blank"
                  >
                    {strings.contactUs}
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link href="//www.hillrom.com/en/about-us/global-privacy-notice" target="_blank">
                    {strings.privacyPolicy}
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link href={urls.TERMSOFUSE} target="_blank">
                    {strings.termsOfUse}
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link href="//www.hillrom.com/content/dam/hillrom-aem/us/en/marketing/about/overview/privacy-notice/Notice-of-Privacy-Practices%20HIPAA%20280-007-7126-EN-r6-LR.pdf" target="_blank">
                    {strings.hipaaNotice}
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link
                    href="//respiratorycare.hill-rom.com/"
                    target="_blank"
                  >
                    {strings.respiratoryCareSite}
                  </Nav.Link>
                </Nav.Item>
              </Nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default LoginShell;
