import './config.js';
import Bar from './Bar.jsx';
import Line from './Line.jsx';
import Chart from './chart';

import './chart.css';

export {
	Bar,
	Line,
	Chart
}