import React, { Component } from 'react';
import ChartComponent from './ChartComponent';

class Line extends Component {
    render() {
        return (
            <ChartComponent
                {...this.props}
                ref={ref => this.chartInstance = ref && ref.chartInstance}
                type='bar'
            />
        );
    }
};

export default Line;
