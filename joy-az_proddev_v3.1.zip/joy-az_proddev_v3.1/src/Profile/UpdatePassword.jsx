import React, { Component } from 'react';
import { connect } from 'react-redux';
import constants from 'constants.js';
import strings from 'localization/strings';
import { Header, SideBar } from 'components/Navigation';
import { Form, Col } from 'react-bootstrap';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import { getUserData } from 'utils/helper';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import SecurityQuestion from './SecurityQuestion';
import { setScreenSize } from '../utils/utltity';
import { decryptdata } from './../Cryptocode';

class UpdatePassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      oldPass: '',
      newPass: '',
      cPass: '',
      error: null,
      isMobile: false
    };
    this.setScreenSize = setScreenSize.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.PROFILE.PROFILE_REQUEST
    });
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillReceiveProps(newProps) {
    const { profile } = newProps;
    if (profile !== undefined) {
      this.setState(profile);
    }
  }

  checkPassword = password => {
    return /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(
      password
    );
  };

  handleChange = event => {
    const { error } = this.state;
    if (error !== null) {
      this.setState({ error: null });
    }
    this.setState({ [event.target.name]: event.target.value });
  };

  handleUpdate = e => {
    const details = JSON.parse(localStorage.getItem(constants.TOKEN));
    const currentUserIdentityPwd = decryptdata(details.currentuseridentity, 'Protected$9876');
    e.preventDefault();
    const { oldPass, newPass, cPass } = this.state;
    const { dispatch, history } = this.props;
    if (this.checkPassword(newPass)) {
      if (newPass !== cPass) {
        this.setState({ error: strings.passwordMismatch });
      }
      else if (oldPass === newPass) {
        if (oldPass === currentUserIdentityPwd)
          this.setState({ error: strings.oldnewpass })
        else
          this.setState({ error: strings.wrongcurrentpassword })
      }
      else {
        const payload = {
          password: oldPass,
          newPassword: newPass
        };
        dispatch({
          type: constants.PROFILE.UPDATEPASSWORD_REQUEST,
          allData: { history, payload, path: urls.LOGOUT }
        });
      }
    } else {
      this.setState({
        error: strings.passwordPolicyError
      });
    }
  };

  render() {
    const { oldPass, newPass, cPass, error, id, isMobile } = this.state;
    const { location } = this.props;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.PROFILE.ALL, text: strings.profileDetails },
        { href: urls.PROFILE.UPDATEPASSWORD, text: strings.updatePassword }
      ]
    };

    const userData = getUserData();
    return (
      <div>
        <Header
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          showBack={false}
          showToggle
          showBrand
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div id="reset_password">
              <ButtonComponent
                id="update-password-top"
                buttonClass="float-right"
                buttonAction={this.handleUpdate}
                icon="right-arrow"
                buttonText={strings.updatePassword}
                hidden={isMobile}
              />
              <h2 className="text-capitalize">{strings.updatePassword}</h2>

              <Form>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label className="text-uppercase">
                      {strings.currentPassword} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      type="password"
                      name="oldPass"
                      value={oldPass}
                      placeholder={strings.currentPassword}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label className="text-uppercase">
                      {strings.newPassword} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      type="password"
                      name="newPass"
                      value={newPass}
                      placeholder={strings.newPassword}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label className="text-uppercase">
                      {strings.confirmNewPassword} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      type="password"
                      name="cPass"
                      value={cPass}
                      placeholder={strings.confirmNewPassword}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                  {userData &&
                    userData.role !== constants.ROLES.PATIENT &&
                    !isMobile && (
                      <Form.Group as={Col} md={8} className="pt-4">
                        <ButtonComponent
                          id="update-password-bottom"
                          buttonClass="float-right"
                          buttonAction={this.handleUpdate}
                          icon="right-arrow"
                          submit
                          buttonText={strings.updatePassword}
                        />
                      </Form.Group>
                    )}
                  {isMobile && (
                    <Form.Group as={Col} md={4} className="pt-4">
                      <ButtonComponent
                        id="update-password-bottom"
                        buttonClass="float-right"
                        buttonAction={this.handleUpdate}
                        icon="right-arrow"
                        submit
                        buttonText={strings.updatePassword}
                      />
                    </Form.Group>
                  )}
                </Form.Row>

                {error && (
                  <p id="error" className="text-danger">
                    {error}
                  </p>
                )}
              </Form>
              <hr />
              {userData && userData.role === constants.ROLES.PATIENT && (
                <div>
                  <SecurityQuestion id={id} />
                  <hr />
                </div>
              )}
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}
const mapStateToProps = state => {
  const { accountReducer } = state.app;
  return {
    profile: state.app.profileReducer.profile,
    account: accountReducer.response
  };
};
export default connect(
  mapStateToProps,
  null
)(UpdatePassword);
