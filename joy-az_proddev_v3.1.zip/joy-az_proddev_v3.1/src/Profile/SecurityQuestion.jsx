import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import strings from 'localization/strings';
import constants from 'constants.js';
import ButtonComponent from 'components/ButtonComponent';

class SecurityQuestion extends Component {
  constructor(props) {
    super(props);
    this.state = {
      questionId: 0,
      answer: '',
      error: null
    };
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({ type: constants.ACTIVATE.SECURITYQUESTIONS });
  }

  getQuestionsElement = () => {
    const { questions } = this.props;
    return questions.map(function mapQuestions(element) {
      return (
        <option id={element.id} value={element.id}>
          {element.question}
        </option>
      );
    });
  };

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };

  handleUpdate = () => {
    const { id } = this.props;
    const { questionId, answer } = this.state;
    this.setState({ error: '' });
    if (questionId !== 0 && answer !== '') {
      const payload = {
        questionId,
        answer
      };
      const { dispatch } = this.props;
      dispatch({
        type: constants.PROFILE.CHANGE_SECURITY_QUESTION,
        payload,
        id
      });
    }
    if (questionId === 0) {
      this.setState({ error: strings.selectQuestion });
    } else if (answer === '') {
      this.setState({ error: strings.enterAnswer });
    }
  };

  render() {
    const { error } = this.state;
    return (
      <div>
        <h6>{strings.securityQuestions}</h6>
        <div>
          <Form>
            <Form.Row className="align-items-center">
              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.securityQuestion}</Form.Label>
                <select
                  name="questionId"
                  className="custom-select form-control"
                  onChange={event => {
                    this.setState({
                      [event.target.name]: event.target.value
                    });
                  }}
                >
                  <option id="0" value="0">
                    {strings.selectSecurityQues}
                  </option>
                  {this.getQuestionsElement()}
                </select>
              </Form.Group>

              <Form.Group as={Col} md={4}>
                <Form.Label>{strings.answer} <span className="asterisk-color">*</span></Form.Label>
                <Form.Control
                  className="input-field"
                  type="password"
                  name="answer"
                  onChange={this.handleChange}
                />
              </Form.Group>
              <Form.Group as={Col} md={4} className="pt-4 mt-2">
                <ButtonComponent
                  buttonClass="float-right"
                  buttonAction={this.handleUpdate}
                  icon="right-arrow"
                  buttonText={strings.update}
                />
              </Form.Group>
            </Form.Row>
          </Form>
        </div>
        <p id="error-message" className="text-danger">
          {error}
        </p>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    questions: state.app.activateReducer.question || []
  };
};

export default connect(
  mapStateToProps,
  null
)(SecurityQuestion);
