import constants from 'constants.js';

const intialState = {
  message: '',
  status: 0,
  profile: {},
  timeZones: {},
  clinics: []
};
function profileReducer(state = intialState, action) {
  switch (action.type) {
    case constants.PROFILE.UPDATEPASSWORD_SUCCESS:
      localStorage.removeItem(constants.TOKEN);
      return Object.assign({}, state, {
        message: action.message,
        status: action.status
      });
    case constants.PROFILE.UPDATEPASSWORD_FAILURE:
      return Object.assign({}, state, {
        message: action.message
      });
    case constants.PROFILE.PROFILE_REQUEST_SUCCESS:
      return Object.assign({}, state, {
        profile: action.profile
      });
    case constants.PROFILE.RESET_PROFILE_DATA:
      return Object.assign({}, state, {
        profile: {}
      });
    case constants.PROFILE.PROFILE_UPDATE_SUCCESS:
      return Object.assign({}, state, {
        message: action.message
      });
    case constants.PROFILE.CHANGE_QUESTION_SUCCESS:
      return Object.assign({}, state, {
        message: action.message
      });
    case constants.PROFILE.FETCH_TIMEZONES_SUCCESS:
      return Object.assign({}, state, {
        timeZones: action.timeZones,
        message: action.message
      });
    case constants.PROFILE.TIMEZONE_UPDATE_SUCCESS:
      return Object.assign({}, state, {
        profile: action.user
      });
    case constants.PROFILE.FETCH_CLINIC_SUCCESS:
      return Object.assign({}, state, {
        clinics: action.clinics
      });
    default:
      return state;
  }
}
export default profileReducer;
