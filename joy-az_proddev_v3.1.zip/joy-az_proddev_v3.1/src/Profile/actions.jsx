import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import strings from 'localization/strings';
import ProfileService from './services';
import { getIVSalt, createEncryptedData } from 'utils/utltity';
import { setUserStorage } from './helper.jsx';
import { getToken } from '../utils/helper';
import { decryptemail } from '../Cryptocode';

var AesUtil = require('../utils/AesUtil');

function* updatePasswordAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload, path, history } = action.allData;
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextPassword = aesUtil.encrypt(salt, iv, payload.password),
      ciphertextNewPassword = aesUtil.encrypt(salt, iv, payload.newPassword),
      rawPassword = createEncryptedData([
        iv,
        salt,
        ciphertextPassword,
        ciphertextNewPassword
      ]);
    const response = yield call(
      ProfileService.updatePasswordService,
      rawPassword
    );
    if (response.status === 400 || response.status === 401) {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    } else if (response.status === 200) {
      yield put({
        type: constants.LOGOUT.FLUSH_STORE_REQUEST
      });
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* profileRequestAction() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(ProfileService.profileRequestService);
    response.data.user.email = decryptemail(response.data.user.email)
    response.data.user.authorities[0].name = decryptemail(response.data.user.authorities[0].name)
    response.data.user.createdBy = decryptemail(response.data.user.createdBy)
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PROFILE.PROFILE_REQUEST_SUCCESS,
        profile: response.data.user
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* profileUpdateAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      ProfileService.profileUpdateService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.PROFILE.PROFILE_REQUEST
      });
      yield put({
        type: constants.ACCOUNT.ACCOUNT_REQUEST,
        payload: { token: getToken() }
      });
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE
      });
      yield put({
        type: constants.PROFILE.PROFILE_UPDATE_SUCCESS,
        message: response.data.message
      });
      setUserStorage(response.data.user);
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* profileResetAction() {
  yield put({
    type: constants.PROFILE.RESET_PROFILE_DATA
  });
}

function* changeSecurityQuestion(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextQuestionID = aesUtil.encrypt(
        salt,
        iv,
        action.payload.questionId
      ),
      ciphertextAnswer = aesUtil.encrypt(salt, iv, action.payload.answer),
      encryptedData = createEncryptedData([
        iv,
        salt,
        ciphertextQuestionID,
        ciphertextAnswer
      ]);
    const response = yield call(
      ProfileService.changeQuestionService,
      encryptedData,
      action.id
    );
    yield put({
      type: constants.PROFILE.CHANGE_QUESTION_SUCCESS,
      message: response.message
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchTimeZone() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(ProfileService.fetchTimeZoneService);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PROFILE.FETCH_TIMEZONES_SUCCESS,
        timeZones: response.data.timezones,
        message: response.data.message
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateTimeZone(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      ProfileService.updateTimezoneService,
      action.payload,
      action.id
    );
    if (response.message === "User updated successfully.") {
      yield put({
        type: constants.PROFILE.TIMEZONE_UPDATE_SUCCESS,
        user: response.user
      });
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: strings.timeZoneUpdateMsg, path: false }
      });
      setUserStorage(response.user);
    }
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getClinicAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(ProfileService.getClinicService, action.role);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.PROFILE.FETCH_CLINIC_SUCCESS,
        clinics: response.data.clinics
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const Profile = {
  updatePasswordAction,
  profileRequestAction,
  profileResetAction,
  profileUpdateAction,
  changeSecurityQuestion,
  fetchTimeZone,
  updateTimeZone,
  getClinicAction
};
export default Profile;
