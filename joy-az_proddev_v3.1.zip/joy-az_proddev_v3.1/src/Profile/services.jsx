/* eslint-disable no-param-reassign */
import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import { getUserId } from 'utils/helper';
import constants from 'constants.js';

function updatePasswordService(payload) {
  return authRequest({
    url: API.UPDATEPASSWORD.replace('{id}', getUserId()),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true,
    headers: { "Content-Type": "text/plain" }
  });
}

function profileRequestService() {
  return authRequest({
    url: API.PROFILE.replace('{id}', getUserId()),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function profileUpdateService(payload, id) {
  if (payload.authorities) {
    Object.assign(payload, { role: payload.authorities[0].name });
  }

  return authRequest({
    url: API.PROFILE.replace('{id}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function changeQuestionService(payload, id) {
  return authRequest({
    url: API.CHANGEQUESTION.replace('{id}', id),
    method: 'PUT',
    data: payload,
    headers: { "Content-Type": "text/plain" }
  });
}

function fetchTimeZoneService() {
  return authRequest({
    url: API.TIMEZONES,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function updateTimezoneService(payload, id) {
  if (payload.authorities) {
    delete Object.assign(payload, { role: payload.authorities[0].name })
      .authorities;
    delete payload.userPreferenceTimezone;
  }

  return authRequest({
    url: API.PROFILE.replace('{id}', id),
    method: 'PUT',
    data: payload
  });
}

function getClinicService(role) {
  let url = API.ASSOCIATEDCLINIC;
  if (role === constants.ROLES.CLINIC_ADMIN) {
    url = API.ASSOCIATEDCLINIC_ADMIN;
  }
  if (role === constants.ROLES.PROVIDER) {
    url = API.ASSOCIATEDCLINIC_HCP;
  }
  return authRequest({
    url: url.replace('{ID}', getUserId()),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

const ProfileService = {
  updatePasswordService,
  profileRequestService,
  profileUpdateService,
  changeQuestionService,
  fetchTimeZoneService,
  updateTimezoneService,
  getClinicService
};
export default ProfileService;
