import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import strings from 'localization/strings';
import { Header, SideBar } from 'components/Navigation';
import { FootNote } from 'components/FootNote';
import NumberFormat from 'react-number-format';
import { forEach, isEmpty } from 'lodash';
import constants from 'constants.js';
import {
  isValidMobile,
  getUserData,
  mapRoleValues,
  validateEmail
} from 'utils/helper';
import TableDisplay from 'components/TableDisplay';
import './profile.scss';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import ConfirmationDialog from 'components/ConfirmationDialog';
import {
  setScreenSize,
  getSpeciality,
  handleZipChange
} from '../utils/utltity';
import accessMatrix from 'rolesData/accessMatrix.js';
import { decryptemail } from '../Cryptocode';
// eslint-disable-next-line react/prefer-stateless-function

class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: '',
      hillromId: '',
      authorities: [],
      firstName: '',
      lastName: '',
      middleName: '',
      primaryPhone: '',
      email: '',
      role: '',
      state: '',
      city: '',
      zipcode: '',
      prevZipcode: '',
      timeZone: '',
      clinics: [],
      speciality: '',
      address: '',
      error: null,
      isMobile: false,
      isDirty: false,
      isTZDirty: false,
      isSaveBtnClicked: false,
      isZipCodeUpdated: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.setScreenSize = setScreenSize.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.handleZipChange = handleZipChange.bind(this);
    this.save = this.save.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    const { actualRole, role } = getUserData();
    const timezoneProfile = accessMatrix.TIMEZONE_PROFILE[actualRole];
    const clinicListProfile = accessMatrix.CLINIC_LIST_PROFILE[actualRole];

    dispatch({
      type: constants.PROFILE.PROFILE_REQUEST
    });
    if (timezoneProfile.write) {
      dispatch({
        type: constants.PROFILE.FETCH_TIMEZONES
      });
    }
    if (clinicListProfile.read) {
      dispatch({ type: constants.PROFILE.FETCH_CLINIC, role });
    }
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillReceiveProps(newProps) {
    const { clinics } = newProps;
    const { isSaveBtnClicked, isZipCodeUpdated } = this.state;
    if (!isEmpty(newProps.profile) && !isZipCodeUpdated) {
      if (this.state.email !== "" && isSaveBtnClicked && newProps.profile.email !== this.state.email) {
        this.setParms(newProps.profile);
      }
      this.setState({ prevZipcode: newProps.profile.zipcode });
      this.setState(newProps.profile);
    }

    if (clinics !== undefined) {
      this.setState({ clinics });
    }
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city,
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
  }

  async setParms(params) {
    const { dispatch } = this.props;
    await this.setState(params);
    alert("Activation link is sent to new email id, please activate and login with new email id");
    await dispatch({
      type: constants.LOGOUT.LOGOUT_REQUEST
    });
    await dispatch({
      type: constants.LOGOUT.FLUSH_STORE_REQUEST
    });
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.ZIP.CITYSTATEBYZIP_REQUEST,
      zip: this.state.prevZipcode
    });
    dispatch({
      type: constants.PROFILE.PROFILE_RESET
    });
  }

  getRoles() {
    const { authorities } = this.state;
    const { actualRole } = getUserData();
    const roleProfile = accessMatrix.ROLE_PROFILE[actualRole];
    if (authorities && authorities.length !== 0) {
      if (roleProfile.read)
        return (
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.role} <span className="asterisk-color">*</span></Form.Label>
            <Form.Control
              type="text"
              name="authorities"
              defaultValue={mapRoleValues(authorities[0].name)}
              disabled
            />
          </Form.Group>
        );
    }
    return '';
  }

  handleChange = event => {
    this.setState({ [event.target.name]: event.target.value, isDirty: true });
    if (event.target.name === "zipcode") {
      this.setState({ isZipCodeUpdated: true });
    }
  };

  handleSpecialtyChange = event => {
    this.setState({ speciality: event.target.value, isDirty: true });
  };

  handleUpdate = e => {
    e.stopPropagation();
    const { timeZone, id } = this.state;
    if (timeZone !== '' && timeZone !== null) {
      const { dispatch, profile, clinics } = this.props;
      const clinicList = clinics.map(clinic => ({ id: clinic.id }));
      dispatch({
        type: constants.PROFILE.TIMEZONE_UPDATE,
        payload: { ...profile, clinicList, timeZone },
        id
      });
      this.setState({ isTZDirty: false });
    }
  };

  listContent = () => {
    const { clinics } = this.state;
    if (!isEmpty(clinics)) {
      return clinics.map(c => (
        <tr key={c.id}>
          <td>{c.name}</td>
          <td>{c.address}</td>
          <td>{`${c.city}/${c.state}`}</td>
          <td>{c.hillromId}</td>
          <td>
            {c.deleted ? (
              <div>
                <div className=" red-inactive d-inline-block" />
                <span className="text-capitalize">{strings.inactive}</span>
              </div>
            ) : (
                <div>
                  <div className="green-active d-inline-block" />
                  <span className="text-capitalize">{strings.active}</span>
                </div>
              )}
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="5" className="text-center text-capitalize">
          {strings.noClinicAssociated}
        </td>
      </tr>
    );
  };

  handleSave = () => {
    const {
      primaryPhone,
      firstName,
      lastName,
      email,
      hillromId,
      address,
      zipcode,
      city,
      dialog
    } = this.state;
    const { role } = getUserData();
    this.setState({ error: '' });
    if (!isValidMobile(primaryPhone, 10, true)) {
      this.setState({ error: strings.phoneNumberisInvalid });
    } else if (!hillromId) {
      this.setState({ error: strings.pleaseEnterHillromID });
    } else if (firstName === '') {
      this.setState({ error: strings.pleaseEnterFirstName });
    } else if (lastName === '') {
      this.setState({ error: strings.pleaseSelectLastName });
    } else if (!validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    } else if (!address && role !== constants.ROLES.SUPER_ADMIN) {
      this.setState({ error: strings.pleaseEnterAddress });
    } else if (!zipcode && role !== constants.ROLES.SUPER_ADMIN) {
      this.setState({ error: strings.pleaseEnterZipcode });
    } else if (!city && role !== constants.ROLES.SUPER_ADMIN) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else {
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.updateProfileConfirm,
          title: strings.updateProfile,
          button: strings.update,
          confirmFunction: this.save,
          show: true
        })
      });
    }
  };

  async save() {
    await this.setState({ isSaveBtnClicked: true, isZipCodeUpdated: false });
    const { dispatch } = this.props;
    const { dialog, id } = this.state;
    const payload = Object.assign({}, this.state);
    ['isMobile', 'isDirty', 'isTZDirty', 'dialog'].forEach(element => {
      delete payload[element];
    });
    const { clinics } = this.props;
    const clinicList = clinics.map(clinic => ({ id: clinic.id }));
    payload.clinicList = clinicList;

    dispatch({
      type: constants.PROFILE.PROFILE_UPDATE_REQUEST,
      payload,
      id
    });
    this.setState({ isDirty: false, isTZDirty: false });
    dialog.handleClose();
  };

  render() {
    const { location, timeZones, history } = this.props;
    const {
      error,
      primaryPhone,
      firstName,
      middleName,
      lastName,
      email,
      hillromId,
      timeZone,
      state,
      city,
      zipcode,
      authorities,
      credentials,
      speciality,
      npiNumber,
      address,
      isMobile,
      dialog
    } = this.state;
    const { actualRole, role } = getUserData();
    const clinicListProfile = accessMatrix.CLINIC_LIST_PROFILE[actualRole];
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.PROFILE.ALL, text: strings.profileDetails },
        { href: urls.PROFILE.UPDATEPASSWORD, text: strings.updatePassword }
      ]
    };

    const timezoneOptions = [];
    if (!isEmpty(timeZones)) {
      forEach(timeZones, (val, idx) => {
        timezoneOptions.push(
          <option key={idx} value={idx}>
            {val}
          </option>
        );
      });
    }

    const tableHeading = [
      {
        text: strings.clinicName,
        name: 'clinicName',
        value: 'clinicName'
      },
      {
        text: strings.address,
        name: 'address',
        value: 'address',
        mobile: false
      },
      {
        text: `${strings.city}/${strings.state}`,
        name: 'city',
        value: 'city',
        mobile: false
      },
      {
        text: strings.hillromId,
        name: 'hillromId',
        value: 'hillromId',
        mobile: false
      },
      {
        text: strings.status,
        name: 'status',
        value: 'status'
      }
    ];

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty || this.state.isTZDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          showBack={false}
          showToggle
          showBrand
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div id="profile">
              <ButtonComponent
                buttonClass="float-right"
                buttonAction={this.handleSave}
                icon="avatar-icon"
                buttonText={strings.save}
              />
              <h2 className="text-capitalize">{strings.myProfile}</h2>
              <h6>{strings.userIdentifiers}</h6>
              <div>
                <Form>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.o_hillromId} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        placeholder={strings.o_hillromId}
                        className="text-capitalize"
                        value={hillromId || ''}
                        onChange={this.handleChange}
                        name="hillromId"
                        readOnly
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>{this.getRoles()}</Form.Row>
                  <hr />
                  <h6 className="text-capitalize">{strings.personalDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        placeholder={strings.firstName}
                        className="text-capitalize"
                        value={firstName || ''}
                        onChange={this.handleChange}
                        name="firstName"
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.middleName}</Form.Label>
                      <FormControlComponent
                        type="text"
                        placeholder={strings.middleName}
                        className="text-capitalize"
                        value={middleName || ''}
                        onChange={this.handleChange}
                        name="middleName"
                        maxLength="50"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        placeholder={strings.lastName}
                        className="text-capitalize"
                        value={lastName || ''}
                        onChange={this.handleChange}
                        name="lastName"
                        maxLength="50"
                      />
                    </Form.Group>
                  </Form.Row>
                  {authorities &&
                    authorities.length !== 0 &&
                    (authorities[0].name === constants.ROLES.PROVIDER ||
                      authorities[0].name === constants.ROLES.CLINIC_ADMIN) && (
                      <Form.Row>
                        <Form.Group as={Col} md={4}>
                          <Form.Label>{strings.credentials}</Form.Label>
                          <FormControlComponent
                            type="text"
                            value={credentials || ''}
                            onChange={this.handleChange}
                            name="credentials"
                          />
                        </Form.Group>
                        <Form.Group as={Col} md={4}>
                          <Form.Label htmlFor="reset">
                            {strings.specialityType}
                          </Form.Label>
                          <Form.Control
                            className="custom-select text-capitalize"
                            as="select"
                            name="speciality"
                            placeholder={strings.select}
                            value={speciality || ''}
                            onChange={this.handleSpecialtyChange}
                            required=""
                          >
                            <option value="">{strings.selectSpeciality}</option>
                            {this.getSpeciality()}
                          </Form.Control>
                        </Form.Group>
                        <Form.Group as={Col} md={4}>
                          <Form.Label>{strings.npiNumber}</Form.Label>
                          <FormControlComponent
                            type="text"
                            value={npiNumber || ''}
                            onChange={this.handleChange}
                            name="npiNumber"
                            maxLength="15"
                          />
                        </Form.Group>
                      </Form.Row>
                    )}
                  {role === constants.ROLES.SUPER_ADMIN && (
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                        <FormControlComponent
                          type="text"
                          placeholder={strings.email}
                          value={email || ''}
                          onChange={this.handleChange}
                          name="email"
                          maxLength="100"
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.primaryPhone}</Form.Label>

                        <NumberFormat
                          className="form-control"
                          placeholder="(___)-___-____"
                          format="(###)-###-####"
                          mask="_"
                          value={primaryPhone || ''}
                          onChange={this.handleChange}
                          name="primaryPhone"
                        />
                      </Form.Group>
                    </Form.Row>
                  )}
                  <p id="error_message" className="text-danger">
                    {error}
                  </p>
                  <hr />
                </Form>
              </div>

              <div>
                {role !== constants.ROLES.SUPER_ADMIN && (
                  <Form>
                    <h6 className="text-capitalize">
                      {strings.contactDetails}
                    </h6>
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.address} <span className="asterisk-color">*</span></Form.Label>
                        <FormControlComponent
                          type="text"
                          name="address"
                          placeholder={strings.address}
                          value={address || ''}
                          onChange={this.handleChange}
                          maxLength="100"
                        />
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                        <Form.Control
                          readOnly
                          type="text"
                          name="city"
                          placeholder={strings.city}
                          value={city || ''}
                          onChange={this.handleChange}
                        />
                      </Form.Group>

                      <Form.Group as={Col} md={2}>
                        <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                        <Form.Control
                          readOnly
                          type="text"
                          name="state"
                          value={state || ''}
                          onChange={this.handleChange}
                          placeholder={strings.state}
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={2}>
                        <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>
                        <FormControlComponent
                          type="text"
                          name="zipcode"
                          value={zipcode || ''}
                          onChange={this.handleChange}
                          onBlur={event => {
                            this.handleZipChange(event);
                          }}
                          placeholder={strings.zipcode}
                          maxLength="7"
                        />
                      </Form.Group>
                    </Form.Row>
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
                        <FormControlComponent
                          type="text"
                          name="email"
                          placeholder={strings.email}
                          value={email || ''}
                          onChange={this.handleChange}
                          maxLength="100"
                        />
                      </Form.Group>
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.primaryPhone}</Form.Label>

                        <NumberFormat
                          className="form-control"
                          placeholder="(___)-___-____"
                          format="(###)-###-####"
                          mask="_"
                          value={primaryPhone || ''}
                          onChange={this.handleChange}
                          name="primaryPhone"
                        />
                      </Form.Group>
                    </Form.Row>
                    <p id="error_message" className="text-danger">
                      {error}
                    </p>
                    <hr />
                  </Form>
                )}
              </div>

              {role !== constants.ROLES.SUPER_ADMIN && (
                <div>
                  <h6 className="text-capitalize">
                    {strings.preferredtimeZone}
                  </h6>

                  <Form>
                    <Form.Row className="align-items-center">
                      <Form.Group as={Col} md={4}>
                        <Form.Label>{strings.preferredtimeZone}</Form.Label>
                        <select
                          className="custom-select"
                          id="custom-select-zone"
                          value={timeZone || ''}
                          onChange={event => {
                            this.setState({
                              timeZone: event.target.value,
                              isTZDirty: true
                            });
                          }}
                        >
                          <option value="" />
                          {timezoneOptions}
                        </select>
                      </Form.Group>
                      <Form.Group as={Col} className="pt-4 mt-2">
                        <ButtonComponent
                          id="update-password-top"
                          buttonClass={isMobile ? 'float-right' : ''}
                          buttonAction={this.handleUpdate}
                          icon="right-arrow"
                          buttonText={strings.update}
                        />
                      </Form.Group>
                    </Form.Row>
                  </Form>

                  <hr />
                </div>
              )}
            </div>
            {clinicListProfile.read && (
              <div>
                <h6 className="text-capitalize">{strings.clinicInfo}</h6>

                <div>
                  <TableDisplay
                    heading={tableHeading}
                    listing={this.listContent()}
                  />
                </div>
              </div>
            )}

            <ButtonComponent
              buttonClass="float-right"
              buttonAction={this.handleSave}
              icon="avatar-icon"
              buttonText={strings.save}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { profileReducer, clinicsReducer, userReducer } = state.app;
  return {
    profile: profileReducer.profile,
    message: profileReducer.message,
    timeZones: profileReducer.timeZones,
    clinics: profileReducer.clinics || [],
    specialityList: clinicsReducer.speciality,
    cityStateByZip: userReducer.cityStateByZip
  };
};

export default connect(
  mapStateToProps,
  null
)(Profile);
