import constants from 'constants.js';
import moment from 'moment-timezone';
import { encryptdata } from '../Cryptocode';
import { decryptdata } from '../Cryptocode';
export function setUserStorage(user) {
	const tokenData = decryptdata(localStorage.getItem(constants.TOKEN), 'Protected$9876');
	const jsonSaved = JSON.parse(tokenData)
	const jsonToBeSaved = { ...jsonSaved, user };
	localStorage.setItem(constants.TOKEN, encryptdata(jsonToBeSaved, 'Protected$9876'));
	setMomentTimezone(user.timeZone);
}

export function setMomentTimezone(timeZone) {
	const timezone = timeZone && timeZone.split('#')[0];
	if (timezone) {
		moment.tz.setDefault(timezone);
	}
}