import constants from '../constants.js';

const initalState = {
  breadcrumbs: []
};
function updateBreadCrumbsState(breadcrumbs) {
  return breadcrumbs.map((element, index) => {
    if (index === breadcrumbs.length - 1) {
      return Object.assign({}, element, { active: true });
    }
    return Object.assign({}, element, { active: false });
  });
}
function breadcrumbsReducer(state = initalState, action) {
  const tmpState = Object.assign({}, state);
  if (action.type === constants.BREADCRUMBS.BREADCRUMBS_ADD) {
    if (
      tmpState.breadcrumbs.find(element => {
        return element.title === action.data.title;
      }) === undefined
    ) {
      tmpState.breadcrumbs.push(action.data);
      tmpState.breadcrumbs = updateBreadCrumbsState(tmpState.breadcrumbs);
    }
    return tmpState;
  }
  if (action.type === constants.BREADCRUMBS.BREADCRUMBS_REMOVE) {
    tmpState.breadcrumbs.pop();
    tmpState.breadcrumbs = updateBreadCrumbsState(tmpState.breadcrumbs);
    return tmpState;
  }
  if (action.type === constants.BREADCRUMBS.BREADCRUMBS_CLEAR) {
    tmpState.breadcrumbs = [];
    return tmpState;
  }
  if (action.type === constants.BREADCRUMBS.BREADCRUMBS_UPDATE) {
    const bLen = tmpState.breadcrumbs.length;
    let lastBreadcrumb = tmpState.breadcrumbs[bLen - 1];
    lastBreadcrumb = { ...lastBreadcrumb, ...action.data };
    tmpState.breadcrumbs[bLen - 1] = lastBreadcrumb;
    tmpState.breadcrumbs = updateBreadCrumbsState(tmpState.breadcrumbs);
    return tmpState;
  }
  return tmpState;
}
export default breadcrumbsReducer;
