const CryptoJS = require("crypto-js");
const AesUtil = require('utils/AesUtil');

export const encryptdata = (data, key) => CryptoJS.AES.encrypt(JSON.stringify(data), key).toString();
export const decryptdata = (cipher, key) => JSON.parse(CryptoJS.AES.decrypt(cipher, key).toString(CryptoJS.enc.Utf8));

export const decryptemail = (email) => {
    let iv = "3414c8b753d3a2959018b8c56e065a98", salt = "a0e1657e9c83dfd64bea056cc09f3450", aesUtil = new AesUtil(128, 1000)
    return aesUtil.decrypt(salt, iv, email);
}
