import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import urls from 'urls';
import constants from './constants';
import { getUserData, getToken } from './utils/helper';
import { setMomentTimezone } from 'Profile/helper';
import { encryptdata, decryptdata } from './Cryptocode';
class PrivateRoute extends Component {
  componentWillMount() {
    const { dispatch } = this.props;
    if (localStorage.getItem(constants.TOKEN) !== null) {
      dispatch({
        type: constants.ACCOUNT.ACCOUNT_REQUEST,
        payload: { token: getToken() }
      });
      const { timeZone } = getUserData();
      setMomentTimezone(timeZone);
    }
  }
  isAuthenticated = account => {
    const { dispatch } = this.props;
    const tokenData = JSON.parse(localStorage.getItem(constants.TOKEN));
    try {
      if (tokenData !== null && account.status !== 401) {
        return true;
      }
      if (tokenData !== null && account.status === 401) {
        dispatch({
          type: constants.LOGOUT.FLUSH_STORE_REQUEST
        });
        return false;
      }
      return false;
    } catch {
      return false;
    }
  };
  render() {
    const { component, account, currentLocation, ...rest } = this.props;
    const MainComponent = component;
    const token = JSON.parse(localStorage.getItem(constants.TOKEN));
    if (token && !account) {
      return null;
    }
    const authCheck = this.isAuthenticated(account);
    if (!authCheck) {
      return (
        <Redirect
          to={{
            pathname: urls.LOGIN,
            state: { next: currentLocation }
          }}
        />
      );
    }
    return <Route {...rest} render={props => <MainComponent {...props} />} />;

  }
}
const mapStateToProps = state => {
  return {
    account: state.app.accountReducer.response
  };
};
export default connect(
  mapStateToProps,
  null
)(PrivateRoute);