const Config = {
  PORT: 7770,
  BASE_URL: ""
}
module.exports = Config;
