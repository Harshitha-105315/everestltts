import React from 'react';
import { MemoryRouter, Route, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';

import PatientProfile from 'patient/PatientProfile';
import UserProfile from 'user-management/UserProfile';
import Clinics from 'clinics/Clinics';
import ClinicDetails from 'clinics/ClinicDetails';
import NewClinic from 'clinics/NewClinic';
import Patients from 'patient/Patients';
import ClinicInfo from 'clinics/ClinicInfo';
import Providers from 'provider/Providers';
import ProviderProfile from 'provider/ProviderProfile';
import NewProvider from 'provider/NewProvider';
import ForgotPassword from 'landing/forgotpassword/ForgotPassword';
import TherapySetting from 'landing/therapysetting/TherapySetting';
import Profile from 'Profile/Profile';
import UpdatePassword from 'Profile/UpdatePassword';
import User from 'user-management/User';
import CreateUser from 'user-management/CreateUser';
import HomePage from 'landing/home';
import ProtocolDevice from 'carePlanAndDevice/protocol/ProtocolDevice';
import EditProtocol from 'carePlanAndDevice/editProtocol/EditProtocol';
import AddNewProtocol from 'carePlanAndDevice/editProtocol/AddNewProtocol';
import EditDevice from 'carePlanAndDevice/addDevice/EditDevice';
import AddDevice from 'carePlanAndDevice/addDevice/AddDevice';
import Login from 'landing/login/Login';
import Logout from 'logout/Logout';
import PatientOverview from 'patient/PatientOverview';
import DetailReport from 'patient/DetailReport';
import PrivateRoute from 'privateroutes';
import urls from './urls';
import TimsScript from './timsScript/timsScript';
import ExecuteJob from './timsScript/executeJob';
import Charger from './sandbox/charger';
import Optimus from './sandbox/optimus';
import Titan from './sandbox/titan';
import Notifications from './notifications/Notifications';
import Announcements from './announcements/announcements';
import AddNewAnnouncement from './announcements/addAnnouncement';
import EditAnnouncement from './announcements/announcementEdit';
import PrivacyPolicy from './components/FooterPages/PrivacyPolicy';
import PrivacyPolicyMobile from './components/FooterPages/PrivacyPolicyMobile';
import TermsOfUse from './components/FooterPages/TermsOfUse';
import HIPAA from './components/FooterPages/HIPAA';
import Disclosures from './components/FooterPages/Disclosures';

import App from './App.jsx';

import store from 'store';

function Routes() {
  return (
    <Provider store={store}>
      <MemoryRouter
        initialEntries={[
          urls.LOGIN,
          urls.LOGOUT,
          urls.PATIENT.ALL,
          urls.PATIENT.DETAIL.OVERVIEW
        ]}
      >
        <App>
          <Switch>
            <Route
              exact
              path={urls.LOGIN}
              key={1}
              render={routeProps => <Login {...routeProps} register={false} />}
            />
            <Route
              exact
              path={urls.REGISTER}
              key={2}
              render={routeProps => <Login {...routeProps} register />}
            />
            <Route
              path={urls.AUTHENTICATE}
              key={3}
              render={routeProps => <Login {...routeProps} activation />}
            />
            <Route path={urls.LOGOUT} component={Logout} />
            <Route path={urls.HIPAA} component={HIPAA} />
            <Route path={urls.DISCLOSURES} component={Disclosures} />
            <Route path={urls.TERMSOFUSE} component={TermsOfUse} />
            <Route path={urls.PRIVACYPOLICY} component={PrivacyPolicy} />
            <Route path={urls.PRIVACYPOLICYMOBILE} component={PrivacyPolicyMobile} />
            <PrivateRoute
              exact
              path={urls.PROFILE.UPDATEPASSWORD}
              component={UpdatePassword}
            />
            <Route path={urls.RESETPASSWORD} component={ForgotPassword} />
            <Route path={urls.THERAPYSETTING} component={TherapySetting} />
            <PrivateRoute exact path={urls.PROFILE.ALL} component={Profile} />
            <PrivateRoute
              exact
              path={urls.PROFILE.NOTIFICATION}
              component={Notifications}
            />
            <PrivateRoute exact path={urls.USER.ALL} component={User} />
            <PrivateRoute path={urls.USER.ADD} component={CreateUser} />
            <PrivateRoute
              exact
              path={urls.USER.PROFILE}
              component={UserProfile}
            />
            <PrivateRoute exact path={urls.PATIENT.ALL} component={Patients} />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.DETAIL}
              component={PatientProfile}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.OVERVIEW.ALL}
              component={PatientOverview}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.CAREPLANDEVICE.ALL}
              component={ProtocolDevice}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.OVERVIEW.DETAILREPORT}
              component={DetailReport}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.CAREPLANDEVICE.DEVICE.EDIT}
              component={EditDevice}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.CAREPLANDEVICE.DEVICE.ADD}
              component={AddDevice}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.EDIT}
              component={EditProtocol}
            />
            <PrivateRoute
              exact
              path={urls.PATIENT.DETAIL.CAREPLANDEVICE.PROTOCOL.ADD}
              component={AddNewProtocol}
            />
            <PrivateRoute exact path={urls.CLINIC.ALL} component={Clinics} />
            <PrivateRoute exact path={urls.CLINIC.ADD} component={NewClinic} />
            <PrivateRoute
              exact
              path={urls.CLINIC.DETAIL.INFO}
              component={ClinicInfo}
            />
            <PrivateRoute
              exact
              path={urls.CLINIC.DETAIL.DETAILS}
              component={ClinicDetails}
            />
            <PrivateRoute
              exact
              path={urls.PROVIDER.ALL}
              component={Providers}
            />
            <PrivateRoute
              exact
              path={urls.PROVIDER.DETAIL}
              component={ProviderProfile}
            />
            <PrivateRoute
              exact
              path={urls.PROVIDER.ADD}
              component={NewProvider}
            />
            <PrivateRoute path={urls.TIMS.SCRIPT} component={TimsScript} />
            <PrivateRoute path={urls.TIMS.EXECUTE} component={ExecuteJob} />
            <PrivateRoute exact path={urls.SANDBOX} component={Charger} />
            <PrivateRoute exact path={urls.OPTIMUS} component={Optimus} />
            <PrivateRoute exact path={urls.TITAN} component={Titan} />
            <PrivateRoute
              exact
              path={urls.ANNOUNCEMENT.ALL}
              component={Announcements}
            />
            <PrivateRoute
              exact
              path={urls.ANNOUNCEMENT.EDIT}
              component={EditAnnouncement}
            />
            <PrivateRoute
              exact
              path={urls.ANNOUNCEMENT.ADD}
              component={AddNewAnnouncement}
            />
            <PrivateRoute path="*" component={HomePage} />
          </Switch>
        </App>
      </MemoryRouter>
    </Provider>
  );
}

export default Routes;
