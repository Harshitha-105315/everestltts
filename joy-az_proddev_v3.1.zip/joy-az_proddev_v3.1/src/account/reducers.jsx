import constants from 'constants.js';

const initalState = { response: '' };

function accountReducer(state = initalState, action) {
  switch (action.type) {
    case constants.ACCOUNT.ACCOUNT_SUCCESS:
      return Object.assign({}, state, { response: action.response });
    case constants.ACCOUNT.ACCOUNT_FAILURE:
      return Object.assign({}, state, { response: action.response });
    case constants.ACCOUNT.ACCOUNT_RESET:
      return Object.assign({}, state, { response: '' });
    default:
      return state;
  }
}
export default accountReducer;
