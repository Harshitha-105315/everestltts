import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';

function getAccountService(payload) {
  return authRequest({
    url: API.ACCOUNT,
    method: 'GET',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json',
      'x-auth-token': payload.token
    }
  });
}
export default getAccountService;
