import { call, put } from 'redux-saga/effects';
import getAccountService from './services';
import constants from 'constants.js';

function* getAccountAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getAccountService, action.payload);
    if (response.status === 401)
      yield put({ type: constants.ACCOUNT.ACCOUNT_FAILURE, response });
    else
      yield put({
        type: constants.ACCOUNT.ACCOUNT_SUCCESS,
        response
      });
  } catch (response) {
    yield put({ type: constants.ACCOUNT.ACCOUNT_FAILURE, response });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
export default getAccountAction;
