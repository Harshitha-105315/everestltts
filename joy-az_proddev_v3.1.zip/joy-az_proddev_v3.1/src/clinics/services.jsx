import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';
import PatientService from 'patient/services.jsx';
import { getUserData, getTimeZoneOffset } from 'utils/helper';

export function fetchSpecialityServices() {
  return authRequest({
    url: API.SPECIALITY,
    method: 'GET',
    'x-response': true
  });
}
export function clinicsSearchService(params) {
  return authRequest({
    url: `${API.CLINICSSEARCH}`,
    params,
    method: 'GET',
    'x-response': true
  });
}

export function fetchClinicsServices(searchUrl, payload) {
  return authRequest({
    url: API.CLINICSADVANCED + searchUrl,
    method: 'POST',
    data: payload,
    'x-response': true
  });
}

export function getClinicService(id) {
  return authRequest({
    url: API.CLINICBYID.replace('{ID}', id),
    method: 'GET',
    'x-response': true
  });
}

export function getClinicAdminsService(id) {
  return authRequest({
    url: API.CLINICADMINS.replace('{ID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

export function getClinicHcpService(id) {
  return authRequest({
    url: API.CLINICHCPS.replace('{ID}', id),
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

export function addClinicService(payload) {
  return authRequest({
    url: API.ADDCLINIC,
    method: 'POST',
    data: payload,
    'x-response': true,
    [constants.RETURNRESPONSE]: true
  });
}

export function associatedPatientsService(entity, id, params) {
  const timeZone = getTimeZoneOffset(getUserData().timeZone);
  params = { ...params, timeZone: timeZone };

  if (entity) {
    params = { ...params, clinicId: id };
    return PatientService.fetchPatientsService(params, entity);
  } else {
    return authRequest({
      url: API.ASSOCIATEDPATIENTSBYCLINIC.replace('{CLINICID}', id),
      params,
      method: 'GET',
      'x-response': true
    });
  }
}

export function getAllClinicsService() {
  return authRequest({
    url: API.CLINICSALL,
    method: 'GET',
    'x-response': true
  });
}

export function updateClinicService(payload, id) {
  return authRequest({
    url: API.CLINICBYID.replace('{ID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function associateProviderService(payload, id) {
  return authRequest({
    url: API.ASSOCIATEHCP.replace('{ENTITYID}', id).replace(
      '{ENTITY}',
      'clinics'
    ),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}
export function disAssociateProviderService(payload, id) {
  return authRequest({
    url: API.DIASSOCIATECLINICSPROVIDER.replace('{ID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function getClinicAllAdminsService(searchUrl) {
  return authRequest({
    url: API.USERALL + searchUrl,
    method: 'GET'
  });
}

export function associatedClinicAdminService(id, payload) {
  return authRequest({
    url: API.ASSOCIATECLINICADMIN.replace('{ID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function disassociateClinicAdminService(id, payload) {
  return authRequest({
    url: API.DISASSOCIATECLINICADMIN.replace('{ID}', id),
    method: 'PUT',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

export function getClinicsByUserService(id) {
  return authRequest({
    url: API.USERASSOCIATEDCLINICS.replace('{ID}', id),
    method: 'PUT'
  });
}

export function getAssociatedPatientCardsService(entity, payload) {
  let { id, params } = payload;
  const timeZone = getTimeZoneOffset(getUserData().timeZone);
  params = { ...params, timeZone: timeZone };
  if (entity) {
    params = { ...params, clinicId: id };
    return PatientService.getPatientCountsService(entity, params);
  }
  const url = API.ASSOCIATEDPATIENTSTATS.replace('{CLINICID}', id);
  return authRequest({
    url,
    method: 'GET',
    params,
    [constants.RETURNRESPONSE]: true
  });
}

export function flagClinicService(payload) {
  const { patientId, flagged, entity } = payload;
  return authRequest({
    url: API.PATIENTFLAG.replace('{ENTITY}', entity),
    method: 'POST',
    data: [
      {
        patientId,
        flag: flagged
      }
    ],
    [constants.RETURNRESPONSE]: true
  });
}

export function getClinicAccountExecutivesService(payload) {
  return authRequest({
    url: API.ACCOUNTEXECUTIVELIST.replace('{CLINICID}', payload),
    method: 'GET'
  });
}

export function diassociateAccountExecutiveService(payload) {
  const { clinicId, aeId } = payload;
  return authRequest({
    url: API.DIASSOCIATECLINICSACCOUNTEXECUTIVE.replace(
      '{CLINICID}',
      clinicId
    ).replace('{AEID}', aeId),
    method: 'DELETE'
  });
}

export function associateAccountExecutiveService(payload) {
  const { clinicId, aeId } = payload;
  return authRequest({
    url: API.ASSOCIATECLINICSACCOUNTEXECUTIVE.replace(
      '{CLINICID}',
      clinicId
    ).replace('{AEID}', aeId),
    method: 'POST'
  });
}

export function activateClinicService(payload) {
  const { id, data } = payload;
  return authRequest({
    url: API.ACTIVATECLINIC.replace(
      '{CLINICID}',
      id
    ),
    data,
    method: 'PUT'
  });
}

export function deactivateClinicService(payload) {
  const { id } = payload;
  return authRequest({
    url: API.ACTIVATECLINIC.replace(
      '{CLINICID}',
      id
    ),
    method: 'DELETE'
  });
}
