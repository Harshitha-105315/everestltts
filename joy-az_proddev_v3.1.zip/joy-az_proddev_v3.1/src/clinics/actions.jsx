import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import strings from 'localization/strings';
import {
  fetchSpecialityServices,
  clinicsSearchService,
  getClinicService,
  getClinicAdminsService,
  getClinicHcpService,
  addClinicService,
  associatedPatientsService,
  getAllClinicsService,
  updateClinicService,
  associateProviderService,
  disAssociateProviderService,
  getClinicAllAdminsService,
  associatedClinicAdminService,
  disassociateClinicAdminService,
  getAssociatedPatientCardsService,
  flagClinicService,
  getClinicAccountExecutivesService,
  diassociateAccountExecutiveService,
  associateAccountExecutiveService,
  activateClinicService,
  deactivateClinicService
} from './services';
import { filterOutFalsyValues } from 'utils/helper';

export function* fetchSpeciality() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(fetchSpecialityServices);
    if (response.status === 200) {
      yield put({
        type: constants.CLINICS.SPECIALITY_SUCCESS,
        response: response.data.typeCode
      });
    } else {
      yield put({
        type: constants.CLINICS.SPECIALITY_FAILURE,
        response
      });
    }
  } catch (response) {
    yield put({
      type: constants.CLINICS.SPECIALITY_FAILURE,
      response
    });
  }
  finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* clinicsSearch(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(clinicsSearchService, filterOutFalsyValues(action.payload));
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({ type: constants.CLINICS.CLINICS_SEARCH_SUCCESS, response });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  }
  finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getClinic(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getClinicService, action.id);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.CLINIC_BYID_SUCCESS,
        response: response.data.clinic,
        key: action.id
      });
    } else {
      yield put({
        type: constants.CLINICS.CLINIC_BYID_FAILURE,
        response,
        key: action.id
      });
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getClinicAdmins(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getClinicAdminsService, action.id);
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.CLINIC_ADMIN_SUCCESS,
        response: response.data.clinicAdmin,
        key: action.id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.CLINICS.CLINIC_ADMIN_FAILURE, key: action.id });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getClinicHcp(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getClinicHcpService, action.id);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.CLINIC_HCP_SUCCESS,
        response: response.data.hcpUsers,
        key: action.id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.CLINICS.CLINIC_HCP_FAILURE, key: action.id });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* addClinic(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { history, path, payload } = action.allData;
    const response = yield call(addClinicService, payload);
    if (Number(response.status) === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* associatedPatients(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      associatedPatientsService,
      action.entity,
      action.id,
      filterOutFalsyValues(action.payload)
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_SUCCESS,
        response,
        key: action.id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getAllClinics() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getAllClinicsService);
    yield put({ type: constants.CLINICS.CLINICS_ALL_SUCCESS, response });
  } catch (response) {
    yield put({ type: constants.CLINICS.CLINICS_ALL_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* updateClinic(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(updateClinicService, action.payload, action.id);
    if (response.status === 200) {
      yield put({
        type: constants.CLINICS.UPDATE_CLINIC_SUCCESS,
        response: response.data.Clinic,
        key: action.id
      });
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* associateProvider(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      associateProviderService,
      action.payload,
      action.id
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.CLINICS.ASSOCIATE_PROVIDER_SUCCESS,
        response: response.data,
        key: action.id
      });
      yield put({ type: constants.CLINICS.CLINIC_HCP_REQUEST, id: action.id });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.data.ERROR
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* disAssociateProvider(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, payload } = action;
    const response = yield call(disAssociateProviderService, payload, id);
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.CLINICS.CLINIC_HCP_REQUEST,
        id: payload[0].id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getClinicAllAdmins(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getClinicAllAdminsService, action.searchUrl);
    yield put({
      type: constants.CLINICS.CLINIC_ADMINS_SUCCESS,
      response: response.data.users
    });
  } catch (response) {
    yield put({ type: constants.CLINICS.CLINIC_ADMINS_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* associatedClinicAdmin(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      associatedClinicAdminService,
      action.id,
      action.payload
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history: false, path: false }
      });
      yield put({
        type: constants.CLINICS.CLINIC_ADMIN_REQUEST,
        id: action.id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* disassociateClinicAdmin(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      disassociateClinicAdminService,
      action.id,
      action.payload
    );
    if (response.status === 200) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      yield put({
        type: constants.CLINICS.CLINIC_ADMIN_REQUEST,
        id: action.id
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* getAssociatedPatientCards(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      getAssociatedPatientCardsService,
      action.entity,
      action.data
    );

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_SUCCESS,
        response: response.data,
        key: action.data.id
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({ type: constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* flagClinicAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(flagClinicService, action.data);
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.CLINICS.FLAG_CLINIC_SUCCESS,
        data: action.data
      });
      try {
        yield put({ type: constants.SHOW_LOADER, payload: true });
        const patientData = yield call(
          getAssociatedPatientCardsService,
          action.data.entity,
          action.data
        );
        if (
          patientData &&
          (patientData.status === 200 || patientData.status === 201)
        ) {
          yield put({
            type: constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_SUCCESS,
            response: patientData.data,
            key: action.data.id
          });
        } else {
          throw Object({
            custom_message: patientData.data.ERROR || patientData.data.error
          });
        }
      } finally {
        yield put({ type: constants.SHOW_LOADER, payload: false });
      }
    } else {
      throw Object({
        custom_message: response.data[0].response || response.data.ERROR
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
export function* getClinicAccountExecutives(action) {
  const id = action.payload;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(getClinicAccountExecutivesService, id);
    yield put({
      type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_SUCCESS,
      response,
      key: id
    });
  } catch (response) {
    yield put({ type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* diassociateAccountExecutive(action) {
  const { payload } = action;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    yield call(diassociateAccountExecutiveService, payload);
    yield put({
      type: constants.ALERT.DELETE_SUCCESS
    });
    yield put({
      type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_REQUEST,
      payload: payload.clinicId
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* associateAccountExecutive(action) {
  const { payload } = action;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    yield call(associateAccountExecutiveService, payload);
    yield put({
      type: constants.ALERT.ADD_SUCCESS_RESPONSE,
      response: { history: false, path: false }
    });
    yield put({
      type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_REQUEST,
      payload: payload.clinicId
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* activateClinic(action) {
  const { payload: { id } } = action;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(activateClinicService, { id, data: { deleted: false } });
    yield put({
      type: constants.CLINICS.UPDATE_CLINIC_INFO,
      key: id,
      response: { deleted: false }
    });
    yield put({
      type: constants.ALERT.CUSTOM,
      response: { message: response.message, path: false },
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* deactivateClinic(action) {
  const { payload: { id } } = action;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(deactivateClinicService, { id });
    yield put({
      type: constants.CLINICS.UPDATE_CLINIC_INFO,
      key: id,
      response: { deleted: true }
    });
    yield put({
      type: constants.ALERT.CUSTOM,
      response: { message: response.message, path: false },
    });
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
