import React from 'react';
import { isEmpty } from 'lodash';
import moment from 'moment-timezone';
import DeleteIcon from 'assets/icn-delete.svg';
import strings from 'localization/strings';
import constants from 'constants.js';
import { customSort } from 'utils/helper.js';
import { decryptemail } from '../Cryptocode';

export function getProviderByClinicList(providers) {
  const providerByClinics = [];
  if (providers !== []) {
    providers.forEach(function hcpByPatientClinicsIdName(a) {
      providerByClinics.push({
        value: a.id,
        label: `${a.firstName} ${a.lastName}`
      });
    });
  }
  return providerByClinics;
}

export function getAccountExecutives(flag, accountExecutives, handleDeleteAccountExecutive) {
  if (!isEmpty(accountExecutives)) {
    return customSort(accountExecutives, 'firstName', 'asc').map(ae => {
      const { id, emailID, lastLoggedInAt, firstName, lastName } = ae;
      const fullName = `${firstName} ${lastName}`;
      return (
        <tr key={id}>
          <td key={firstName}>
            {fullName}
            <p className="secondary-data d-sm-none">{emailID ? decryptemail(emailID) : emailID}</p>
          </td>
          <td key={emailID} className="d-none d-sm-table-cell">
            {emailID ? decryptemail(emailID) : emailID}
          </td>
          <td className="d-none d-sm-table-cell">
            {lastLoggedInAt
              ? moment(lastLoggedInAt).format('MMM DD, YYYY hh:mm A')
              : ''}
          </td>
          {flag && (
            <td>
              <img
                src={DeleteIcon}
                alt="Delete Account Executive"
                onClick={(event) => handleDeleteAccountExecutive(event, id, fullName)}
                onKeyDown={handleDeleteAccountExecutive}
                name={fullName}
                role="presentation"
              />
            </td>
          )}
        </tr>
      )
    });
  }
  return (
    <tr>
      <td colSpan={5} className="text-center">
        {strings.noAccountExecutiveAssociated}
      </td>
    </tr>
  );
}

export function getAccountExecutiveList(list) {
  if (!list) return [];
  return list.map(ae => {
    return Object.assign(ae, { id: ae.userId });
  });
}

export function getClinicAdminByClinicList(clinicAllAdmin) {
  const clinicAllAdminList = [];
  if (clinicAllAdmin !== []) {
    clinicAllAdmin.forEach(function hcpByPatientClinicsIdName(a) {
      clinicAllAdminList.push({
        value: a.id,
        label: `${a.firstName} ${a.lastName}`
      });
    });
  }
  return clinicAllAdminList;
}

export function getClinicAdminBody(
  flag,
  clinicAdmin,
  handleDeleteClinicAdmin
) {
  if (!isEmpty(clinicAdmin)) {
    return customSort(clinicAdmin, 'firstName', 'asc').map(element => (
      <tr key={element.id}>
        <td key={element.firstName}>
          {`${element.firstName} ${element.lastName}`}
          <p className="secondary-data d-sm-none">{element.email ? decryptemail(element.email) : element.email}</p>
        </td>
        <td key={element.email} className="d-none d-sm-table-cell">
          {element.email ? decryptemail(element.email) : element.email}
        </td>
        <td key={element.credentials} className="d-none d-sm-table-cell">
          {element.credentials}
        </td>
        <td className="d-none d-sm-table-cell">
          {element.lastLoggedInAt
            ? moment(element.lastLoggedInAt).format('MMM DD, YYYY hh:mm A')
            : ''}
        </td>
        {flag && (
          <td>
            <img
              src={DeleteIcon}
              alt="Delete Clinic"
              onClick={e =>
                handleDeleteClinicAdmin(
                  e,
                  element.id,
                  `${element.firstName} ${element.lastName}`
                )
              }
              onKeyDown={e =>
                handleDeleteClinicAdmin(
                  e,
                  element.id,
                  `${element.firstName} ${element.lastName}`
                )
              }
              name={element.id}
              role="presentation"
            />
          </td>
        )}
      </tr>
    ));
  }
  return (
    <tr>
      <td colSpan={5} className="text-center">
        {strings.noClinicAdminAssociated}
      </td>
    </tr>
  );
}

export function getClinicHcpBody(flag, clinicHcp, handleDeleteProvider) {
  if (!isEmpty(clinicHcp)) {
    return customSort(clinicHcp, 'firstName', 'asc').map(element => (
      <tr key={element.id}>
        <td key={element.firstName}>
          {`${element.firstName} ${element.lastName}`}
          <p className="secondary-data d-sm-none">{element.email ? decryptemail(element.email) : element.email}</p>
        </td>
        <td key={element.email} className="d-none d-sm-table-cell">
          {element.email ? decryptemail(element.email) : element.email}
        </td>
        <td key={element.credentials} className="d-none d-sm-table-cell">
          {element.credentials}
        </td>
        <td className="d-none d-sm-table-cell">
          {element.lastLoggedInAt
            ? moment(element.lastLoggedInAt).format('MMM DD, YYYY hh:mm A')
            : ''}
        </td>
        {flag && (
          <td>
            <img
              src={DeleteIcon}
              alt="Delete Clinic"
              onClick={e =>
                handleDeleteProvider(
                  e,
                  element.id,
                  `${element.firstName} ${element.lastName}`
                )
              }
              onKeyDown={e =>
                handleDeleteProvider(
                  e,
                  element.id,
                  `${element.firstName} ${element.lastName}`
                )
              }
              name={element.id}
              role="presentation"
            />
          </td>
        )}
      </tr>
    ));
  }
  return (
    <tr>
      <td colSpan={5} className="text-center">
        {strings.noProviderAssociated}
      </td>
    </tr>
  );
}

export function getFiltersForAssocatiedPatients({
  providerFilterList,
}) {
  const {
    patientSts,
    gender,
    deviceSts,
    transmission,
    ageRange,
    providerId
  } = this.state;
  const filters = {
    Provider_Name: [
      {
        title: strings.clinicName,
        type: constants.FILTER_TYPE.SELECT,
        name: constants.FILTER_NAME.PROVIDER_ID,
        value: providerId,
        onChangeFunction: this.handleFilter,
        options: providerFilterList ? providerFilterList || [] : [],
        optionType: 'object',
        optionValue: { key: 'id', value: ['firstName', 'lastName'] },
        allSelection: true
      }
    ],
    Patient_Level_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: this.handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: this.handleFilter,
        checked: patientSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.PATIENT_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: this.handleFilter,
        checked: patientSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ],
    Transmission: [
      {
        title: strings.transmitting,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.TRANSMITTING,
        onChangeFunction: this.handleFilter,
        checked: transmission === constants.FILTER_VALUES.TRANSMITTING ? true : null
      },
      {
        title: strings.neverTransmitted,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.NEVER,
        onChangeFunction: this.handleFilter,
        checked: transmission === constants.FILTER_VALUES.NEVER ? true : null
      },
      {
        title: strings.stoppedTranmission,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.STOPPED,
        onChangeFunction: this.handleFilter,
        checked: transmission === constants.FILTER_VALUES.STOPPED ? true : null
      },
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.TRANSMISSION,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: this.handleFilter,
        checked: transmission === constants.FILTER_VALUES.ALL ? true : null
      }
    ],
    Age: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: ageRange === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.age18,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE18,
        checked: ageRange === constants.FILTER_VALUES.AGE18 ? true : null
      },
      {
        title: strings.age35,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE35,
        checked: ageRange === constants.FILTER_VALUES.AGE35 ? true : null
      },
      {
        title: strings.age65,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65,
        checked: ageRange === constants.FILTER_VALUES.AGE65 ? true : null
      },
      {
        title: strings.age65plus,
        name: constants.FILTER_NAME.AGE_RANGE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.AGE65PLUS,
        checked: ageRange === constants.FILTER_VALUES.AGE65PLUS ? true : null
      }
    ],
    Gender: [
      {
        title: strings.all,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.ALL,
        checked: gender === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.male,
        name: constants.FILTER_NAME.GENDER,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        value: constants.FILTER_VALUES.MALE,
        checked: gender === constants.FILTER_VALUES.MALE ? true : null
      },
      {
        title: strings.female,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.FEMALE,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.FEMALE ? true : null
      },
      {
        title: strings.other,
        name: constants.FILTER_NAME.GENDER,
        value: constants.FILTER_VALUES.OTHERS,
        onChangeFunction: this.handleFilter,
        type: constants.FILTER_TYPE.RADIO,
        checked: gender === constants.FILTER_VALUES.OTHERS ? true : null
      }
    ],
    Device_Status: [
      {
        title: strings.all,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ALL,
        onChangeFunction: this.handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ALL ? true : null
      },
      {
        title: strings.active,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.ACTIVE,
        onChangeFunction: this.handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.ACTIVE ? true : null
      },
      {
        title: strings.inactive,
        type: constants.FILTER_TYPE.RADIO,
        name: constants.FILTER_NAME.DEVICE_STATUS,
        value: constants.FILTER_VALUES.INACTIVE,
        onChangeFunction: this.handleFilter,
        checked: deviceSts === constants.FILTER_VALUES.INACTIVE ? true : null
      }
    ]
  };
  return filters;
}
