import React, { Component, Fragment } from 'react';
import { Form, Col } from 'react-bootstrap';
import { Header, SideBar } from 'components/Navigation';
import { connect } from 'react-redux';
import NumberFormat from 'react-number-format';
import constants from 'constants.js';
import TableDisplay from 'components/TableDisplay';
import strings from 'localization/strings';
import CustomSelect from 'components/CustomSelect';
import ConfirmationDialog from 'components/ConfirmationDialog';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import API from 'api/api_config';
import { getUserData, isValidMobile } from 'utils/helper.js';
import accessMatrix from 'rolesData/accessMatrix.js';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import LinkButton from 'components/LinkButton';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import {
  getClinicAdminBody,
  getClinicHcpBody,
  getAccountExecutives
} from 'clinics/helper.jsx';
import { isEmpty, isEqual } from 'lodash';
import AssociateUser from './AssociateUser';
import {
  getSpeciality,
  getBreadCrumb,
  removeBreadCrumb,
  addBreadCrumb,
  handleZipChange
} from '../utils/utltity';

class ClinicInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      submitted: false,
      isMobile: false,
      name: '',
      address: '',
      address2: '',
      city: '',
      state: '',
      zipcode: '',
      phoneNumber: '',
      faxNumber: '',
      speciality: '',
      error: '',
      deleted: null,
      resetSelect: false,
      clinicHcp: [],
      clinicAdmin: [],
      isDirty: false,
      associateEntity: {
        clinicAdminRef: false,
        clinicExisting: false,
        addProvider: false,
        addNewProvider: false,
        addAccountExecutive: false,
      },
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: true,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleUpdate = this.handleUpdate.bind(this);
    this.handleAdditionProvider = this.handleAdditionProvider.bind(this);
    this.linkClinicAdminClinic = this.linkClinicAdminClinic.bind(this);
    this.handleDeleteProvider = this.handleDeleteProvider.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.handleZipChange = handleZipChange.bind(this);
    this.handleDeleteAccountExecutive = this.handleDeleteAccountExecutive.bind(
      this
    );
    this.deleteAccountExecutive = this.deleteAccountExecutive.bind(this);
    this.handleAdditionAccountExecutive = this.handleAdditionAccountExecutive.bind(
      this
    );
    this.additionAccountExecutive = this.additionAccountExecutive.bind(this);
  }

  componentWillMount() {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    dispatch({ type: constants.CLINICS.CLINIC_BYID_REQUEST, id });
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
    dispatch({ type: constants.CLINICS.CLINIC_ADMIN_REQUEST, id });
    dispatch({ type: constants.CLINICS.CLINIC_HCP_REQUEST, id });
    dispatch({
      type: constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_REQUEST,
      payload: id
    });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.clinicDetails });
  }

  async componentWillReceiveProps(newProps) {
    const { clinic } = this.props;
    const { name } = this.state;
    if (
      (isEmpty(clinic) && !isEmpty(newProps.clinic)) ||
      (isEqual(clinic, newProps.clinic) && name === '')
    ) {
      this.setState(newProps.clinic);
      await this.setState({
        error: '',
        clinicHcp: [],
        clinicAdmin: []
      });
    }
    if (clinic.deleted !== newProps.clinic.deleted) {
      this.setState({ deleted: newProps.clinic.deleted });
    }
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
    await this.setState({
      clinicHcp: newProps.clinicHcp,
      clinicAdmin: newProps.clinicAdmin
    });
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
  }

  deleteClinicAdmin = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { dialog } = this.state;
    const { clinicAdminId } = dialog;
    dispatch({
      type: constants.CLINICS.DISASSOCIATECLINICADMIN_REQUEST,
      id,
      payload: { id: clinicAdminId }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  handleDeleteClinicAdmin = (event, id, name) => {
    const clinicAdminId = id;
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        body: `Delete ${name} as clinic admin with the clinic?`,
        title: 'Remove Clinic Admin',
        button: 'Remove Clinic Admin',
        confirmFunction: this.deleteClinicAdmin,
        clinicAdminId,
        show: true
      })
    });
  };

  additionProvider = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { dialog, associateEntity } = this.state;
    const { tag } = dialog;
    dispatch({
      type: constants.CLINICS.ASSOCIATE_PROVIDER_REQUEST,
      payload: [{ id: tag.id }],
      id
    });
    this.setState({
      associateEntity: Object.assign(associateEntity, {
        addProvider: false
      })
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  deleteProvider = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { dialog } = this.state;
    const { providerId } = dialog;
    dispatch({
      type: constants.CLINICS.DISASSOCIATE_PROVIDER_REQUEST,
      id: providerId,
      payload: [{ id }]
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  handleAssociatingUser = (data, userRole) => {
    const {
      dispatch,
      match: {
        params: { id }
      },
      history
    } = this.props;
    const path = false;
    const payload = Object.assign({}, data, {
      clinicList: [{ id }],
      role: userRole
    });
    dispatch({
      type: constants.USER.USER_CREATE_REQUEST,
      allData: { payload, path, history, id, userRole }
    });
  };

  update = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const payload = Object.assign({}, this.state);
    [
      'error',
      'clinicAdmin',
      'associateEntity',
      'newClinicAdmin',
      'dialog',
      'isDirty'
    ].forEach(e => {
      delete payload[e];
    });
    dispatch({
      type: constants.CLINICS.UPDATE_CLINIC_REQUEST,
      payload,
      id
    });
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  handleChange = event => {
    if (event.target.name === 'speciality') {
      if (event.target.value === 'Select Speciality') {
        this.setState({ [event.target.name]: null });
      } else {
        this.setState({ [event.target.name]: event.target.value });
      }
    } else {
      this.setState({ [event.target.name]: event.target.value });
    }
    this.setState({ isDirty: true });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  addClinicAdminToClinic = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { dialog, associateEntity } = this.state;
    const { tag } = dialog;
    dispatch({
      type: constants.CLINICS.ASSOCIATECLINICADMIN_REQUEST,
      id,
      payload: { id: tag.id }
    });
    this.setState({
      associateEntity: Object.assign(associateEntity, {
        clinicExisting: false
      })
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  additionAccountExecutive = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { tag }
    } = this.state;
    dispatch({
      type: constants.CLINICS.ASSOCIATE_ACCOUNT_EXECUTIVE_REQUEST,
      payload: {
        clinicId: id,
        aeId: tag.id
      }
    });
    this.setState(prevState => ({
      associateEntity: Object.assign(prevState.associateEntity, {
        addAccountExecutive: false
      }),
      dialog: Object.assign(prevState.dialog, {
        show: false
      })
    }));
  };

  deleteAccountExecutive = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const {
      dialog: { aeId }
    } = this.state;
    dispatch({
      type: constants.CLINICS.DIASSOCIATE_ACCOUNT_EXECUTIVE_REQUEST,
      payload: {
        clinicId: id,
        aeId
      }
    });
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        show: false
      })
    }));
  };

  handleActivateClinic = () => {
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        body: strings.activateClinicWarning,
        title: strings.activateClinic,
        button: strings.activateClinic,
        confirmFunction: this.activateClinic,
        show: true
      })
    }));
  };

  activateClinic = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;

    dispatch({
      type: constants.CLINICS.ACTIVATE_CLINIC,
      payload: {
        id
      }
    });
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        show: false
      })
    }));
  };

  handleDeactivateClinic = () => {
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        body: strings.deactivateClinicWarning,
        title: strings.deactivateClinic,
        button: strings.deactivateClinic,
        confirmFunction: this.deactivateClinic,
        show: true
      })
    }));
  };

  deactivateClinic = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;

    dispatch({
      type: constants.CLINICS.DEACTIVATE_CLINIC,
      payload: {
        id
      }
    });
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        show: false
      })
    }));
  };

  async linkClinicAdminClinic(tag) {
    if (tag) {
      const { dialog } = this.state;
      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateClinicAdmin.replace(
            '{VALUE}',
            `${tag.firstName} ${tag.lastName}`
          ),
          title: strings.addClinicAdmin,
          button: strings.addClinicAdmin,
          confirmFunction: this.addClinicAdminToClinic,
          tag,
          show: true
        })
      });
    }
  }

  async handleUpdate() {
    const {
      hillromId,
      name,
      address,
      zipcode,
      phoneNumber,
      faxNumber,
      city
    } = this.state;
    this.setState({ error: '' });
    if (hillromId === '' || hillromId === null) {
      await this.setState({ error: strings.pleaseEnterHillromID });
    } else if (name === '' || name === null) {
      this.setState({ error: strings.pleaseEnterClinicName });
    } else if (address === '') {
      this.setState({ error: strings.pleaseEnterAddress });
    } else if (zipcode === '' || zipcode === null) {
      this.setState({ error: strings.pleaseEnterZipcode });
    } else if (city === '' || city === null) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else if (!isValidMobile(phoneNumber, 10, false)) {
      this.setState({ error: strings.phoneNumberisInvalid });
    } else if (!isValidMobile(faxNumber, 10, true)) {
      this.setState({ error: strings.faxNumberisInvalid });
    } else {
      const { dialog } = this.state;
      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.updateProfileMsg
            .replace('{VALUE}', name)
            .replace('{ENTITY}', 'clinic'),
          title: strings.updateClinic,
          button: strings.updateClinic,
          confirmFunction: this.update,
          show: true
        })
      });
    }
  }

  async handleAdditionProvider(tag) {
    if (tag) {
      const { dialog } = this.state;
      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateProvider
            .replace('{VALUE}', `${tag.firstName} ${tag.lastName}`)
            .replace('{ENTITY}', 'clinic'),
          title: strings.addProvider,
          button: strings.addProvider,
          confirmFunction: this.additionProvider,
          tag,
          show: true
        })
      });
    }
  }

  async handleDeleteProvider(event, id, name) {
    const providerId = id;
    const { dialog } = this.state;
    await this.setState({
      dialog: Object.assign(dialog, {
        body: strings.disassociateProvider
          .replace('{VALUE}', name)
          .replace('{ENTITY}', 'clinic'),
        title: strings.removeProvider,
        button: strings.removeProvider,
        confirmFunction: this.deleteProvider,
        providerId,
        show: true
      })
    });
  }

  async handleAdditionAccountExecutive(tag) {
    if (tag) {
      const { dialog } = this.state;
      await this.setState({
        dialog: Object.assign(dialog, {
          body: strings.associateAccountExecutive
            .replace('{VALUE}', `${tag.firstName} ${tag.lastName}`)
            .replace('{ENTITY}', 'clinic'),
          title: strings.addAccountExecutive,
          button: strings.addAccountExecutive,
          confirmFunction: this.additionAccountExecutive,
          tag,
          show: true
        })
      });
    }
  }

  async handleDeleteAccountExecutive(event, aeId, aeName) {
    this.setState(prevState => ({
      dialog: Object.assign(prevState.dialog, {
        body: strings.disassociateAccountExecutive
          .replace('{VALUE}', aeName)
          .replace('{ENTITY}', 'clinic'),
        title: strings.removeAccountExecutive,
        button: strings.removeAccountExecutive,
        confirmFunction: this.deleteAccountExecutive,
        aeId,
        show: true
      })
    }));
  }

  render() {
    const {
      name,
      address,
      address2,
      city,
      state,
      zipcode,
      phoneNumber,
      faxNumber,
      deleted,
      speciality,
      associateEntity,
      dialog,
      isMobile,
      error,
      clinicAdmin,
      clinicHcp,
      hillromId,
      resetSelect
    } = this.state;
    const { match, location, breadcrumbs, history, clinicAE } = this.props;
    const { id } = match.params;
    const { actualRole } = getUserData();
    const clinicInformation = accessMatrix.CLINIC_INFORMATION[actualRole];
    const clinicAdminInformation = accessMatrix.CLINIC_CLINIC_ADMIN[actualRole];
    const providerInformation = accessMatrix.CLINIC_PROVIDER[actualRole];
    const accountExecutiveInformation =
      accessMatrix.CLINIC_ACCOUNT_EXECUTIVE[actualRole];
    const modifyClinicAccount = accessMatrix.MODIFY_CLINIC_ACCOUNT[actualRole];
    const clinicTableHeading = [
      { text: strings.adminName, sortable: false },
      { text: strings.email, sortable: false, mobile: false },
      { text: strings.credentials, sortable: false, mobile: false },
      { text: strings.lastLogin, sortable: false, mobile: false }
    ];
    if (clinicAdminInformation.write) {
      clinicTableHeading.push({
        text: strings.options,
        name: 'options',
        value: 'options'
      });
    }

    const providerTableHeading = [
      { text: strings.providerName, sortable: false },
      { text: strings.email, sortable: false, mobile: false },
      { text: strings.credentials, sortable: false, mobile: false },
      { text: strings.lastLogin, sortable: false, mobile: false }
    ];
    if (providerInformation.write) {
      providerTableHeading.push({
        text: strings.options,
        name: 'options',
        value: 'options'
      });
    }

    const accountExecutiveTableHeading = [
      { text: strings.executiveName, sortable: false },
      { text: strings.email, sortable: false, mobile: false },
      { text: strings.lastLogin, sortable: false, mobile: false }
    ];

    if (accountExecutiveInformation.write) {
      accountExecutiveTableHeading.push({
        text: strings.options,
        name: 'options',
        value: 'options'
      });
    }

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.CLINIC.DETAIL.DETAILS, { id }),
          text: strings.associatedPatients
        },
        {
          href: reverse(urls.CLINIC.DETAIL.INFO, { id }),
          text: strings.clinicDetails
        }
      ]
    };
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.CLINIC.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <h1 className="d-inline-block text-capitalize">
                {strings.clinicDetails}
              </h1>
              {!isMobile && (
                <ButtonComponent
                  buttonClass="float-right"
                  buttonAction={this.handleUpdate}
                  hidden={!clinicInformation.write}
                  icon="right-arrow"
                  buttonText={strings.update}
                  id="clinicDetails-update"
                />
              )}
              <div
                style={isMobile ? { height: '2.25rem' } : {}}
                className="mb-3"
              >
                <h6
                  style={isMobile ? { verticalAlign: 'sub' } : {}}
                  className="text-capitalize d-inline"
                >
                  {strings.clinicIdentifiers}
                </h6>
                {isMobile && (
                  <ButtonComponent
                    buttonClass="float-right"
                    buttonAction={this.handleUpdate}
                    hidden={!clinicInformation.write}
                    icon="right-arrow"
                    buttonText={strings.update}
                  />
                )}
              </div>
              <p id="error_message" className="text-danger">
                {error}
              </p>
              <Form>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.hillromID} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      value={hillromId || ''}
                      name="hillromId"
                      required
                      onChange={this.handleChange}
                      readOnly={!clinicInformation.write}
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <div id="clinic-generalDetails">
                  <h6 className="text-capitalize">{strings.generalDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={8}>
                      <Form.Label>{strings.clinicName} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        value={name}
                        required
                        onChange={this.handleChange}
                        name="name"
                        readOnly={!clinicInformation.write}
                        maxLength="50"
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.speciality}</Form.Label>
                      <Form.Control
                        as="select"
                        value={speciality || ''}
                        name="speciality"
                        onChange={this.handleChange}
                        className="text-capitalize"
                        disabled={!clinicInformation.write}
                      >
                        <option defaultValue value="">
                          {strings.selectSpeciality}
                        </option>
                        {this.getSpeciality()}
                      </Form.Control>
                    </Form.Group>
                  </Form.Row>
                  <hr />
                </div>
                <div id="clinic-contactDetails">
                  <h6>{strings.contactDetails}</h6>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.addressLine1} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        type="text"
                        value={address || ''}
                        onChange={this.handleChange}
                        name="address"
                        readOnly={!clinicInformation.write}
                        maxLength="100"
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.addressLine2}</Form.Label>
                      <FormControlComponent
                        type="text"
                        name="address2"
                        value={address2 || ''}
                        onChange={this.handleChange}
                        readOnly={!clinicInformation.write}
                        maxLength="100"
                      />
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                      <FormControlComponent
                        readOnly
                        type="text"
                        value={city || ''}
                        onChange={this.handleChange}
                        name="city"
                      />
                    </Form.Group>
                    <Form.Group as={Col}>
                      <Form.Row>
                        <Form.Group as={Col} md={6}>
                          <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                          <FormControlComponent
                            readOnly
                            type="text"
                            value={state || ''}
                            onChange={this.handleChange}
                            name="state"
                          />
                        </Form.Group>
                        <Form.Group as={Col} md={6}>
                          <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>

                          <FormControlComponent
                            type="text"
                            name="zipcode"
                            value={zipcode || ''}
                            onChange={this.handleChange}
                            onBlur={event => {
                              this.handleZipChange(event);
                            }}
                            readOnly={!clinicInformation.write}
                            placeholder="Zipcode"
                            maxLength="7"
                            required
                          />
                        </Form.Group>
                      </Form.Row>
                    </Form.Group>
                  </Form.Row>
                  <Form.Row>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.clinicPhone} <span className="asterisk-color">*</span></Form.Label>
                      <NumberFormat
                        className="form-control"
                        placeholder={strings.numberPlaceholder}
                        format={strings.numberFormat}
                        mask="_"
                        value={phoneNumber || ''}
                        onChange={this.handleChange}
                        name="phoneNumber"
                        readOnly={!clinicInformation.write}
                      />
                    </Form.Group>
                    <Form.Group as={Col} md={4}>
                      <Form.Label>{strings.clinicFax}</Form.Label>
                      <NumberFormat
                        className="form-control"
                        placeholder={strings.numberPlaceholder}
                        format={strings.numberFormat}
                        mask="_"
                        value={faxNumber || ''}
                        onChange={this.handleChange}
                        name="faxNumber"
                        readOnly={!clinicInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                </div>
                <Form.Row />
                {clinicAdminInformation.read ? (
                  <Fragment>
                    <hr />
                    <h1 className="text-capitalize">{strings.clinicAdmin}</h1>
                    <TableDisplay
                      heading={clinicTableHeading}
                      listing={getClinicAdminBody(
                        clinicAdminInformation.write,
                        clinicAdmin,
                        this.handleDeleteClinicAdmin
                      )}
                      tableClass="clinic-info-clinic-admin-table"
                    />
                  </Fragment>
                ) : null}
                {associateEntity.clinicExisting && (
                  <div
                    className={
                      associateEntity.clinicExisting
                        ? 'add-existing-admin'
                        : 'd-none'
                    }
                    id="all-clinic-admin-tag"
                  >
                    <h4 className="text-capitalize">
                      {strings.addExistingAdmin}
                    </h4>
                    <Form.Label className="d-block form-label text-capitalize">
                      {strings.searchExistingAdmin}
                    </Form.Label>
                    <CustomSelect
                      clearable
                      len={-1}
                      minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                      className="d-inline-block"
                      clearCurrentVal={resetSelect}
                      afterClearCurrentValFn={() => {
                        this.setState({ resetSelect: false });
                      }}
                      seperator=" "
                      filterOptions={{ key: 'id', values: clinicAdmin }}
                      optionUrl={API.CLINICADMINSEARCH}
                      urlSymbol="&"
                      searchParam="searchString"
                      placeholder={strings.chooseClinicAdminPlaceholder}
                      displayAttr={['firstName', 'lastName']}
                      onChange={this.linkClinicAdminClinic}
                      isDisabled={!clinicAdminInformation.write}
                    />
                    <span
                      className="cross-icon d-inline-block align-middle"
                      onClick={async () => {
                        this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            clinicExisting: false
                          })
                        });
                      }}
                      onKeyPress={async () => {
                        this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            clinicExisting: false
                          })
                        });
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                )}
                {associateEntity.clinicAdminRef && (
                  <AssociateUser
                    location={location}
                    history={history}
                    userRole={constants.ROLES.CLINIC_ADMIN}
                    permission={clinicAdminInformation}
                    onCreate={this.handleAssociatingUser}
                    onClose={() =>
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          clinicAdminRef: false
                        })
                      })
                    }
                  />
                )}
                <div
                  className={
                    associateEntity.clinicAdminRef ||
                      associateEntity.clinicExisting
                      ? 'd-none'
                      : 'd-flex flex-column flex-sm-row align-items-start justify-content-end'
                  }
                  id="clinic-admin-details"
                >
                  <ButtonComponent
                    buttonAction={() => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          clinicAdminRef: true
                        })
                      });
                    }}
                    hidden={!clinicAdminInformation.write}
                    icon="add-icon"
                    buttonText={strings.addNewAdmin}
                  />
                  <ButtonComponent
                    buttonClass={isMobile ? 'mt-3' : 'ml-4'}
                    buttonAction={async () => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          clinicExisting: true
                        })
                      });
                    }}
                    hidden={!clinicAdminInformation.write}
                    icon="add-icon"
                    buttonText={strings.addExistingAdmin}
                  />
                </div>
                {providerInformation.read ? (
                  <Fragment>
                    <hr />
                    <h1 className="text-capitalize">{strings.providers}</h1>
                    <TableDisplay
                      heading={providerTableHeading}
                      listing={getClinicHcpBody(
                        providerInformation.write,
                        clinicHcp,
                        this.handleDeleteProvider
                      )}
                      tableClass="clinic-info-provider-table"
                    />
                  </Fragment>
                ) : null}
                {associateEntity.addProvider && (
                  <div
                    className={
                      associateEntity.addProvider
                        ? 'add-provider-clinic'
                        : 'd-none'
                    }
                    id="all-provider-tag"
                  >
                    <CustomSelect
                      clearable
                      len={-1}
                      minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                      className="d-inline-block"
                      clearCurrentVal={resetSelect}
                      afterClearCurrentValFn={() => {
                        this.setState({ resetSelect: false });
                      }}
                      filterOptions={{ key: 'id', values: clinicHcp }}
                      optionUrl={`${API.PROVIDERSEARCH}?page=1&per_page=100&sort_by=firstName&asc=true&status=activePending`}
                      seperator=" "
                      searchParam="name"
                      urlSymbol="&"
                      placeholder={strings.chooseProviderPlaceholder}
                      displayAttr={['firstName', 'lastName']}
                      onChange={this.handleAdditionProvider}
                      isDisabled={!providerInformation.write}
                    />
                    <span
                      className="cross-icon d-inline-block align-middle"
                      onClick={async () => {
                        await this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            addProvider: false
                          })
                        });
                      }}
                      onKeyPress={async () => {
                        await this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            addProvider: false
                          })
                        });
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                )}
                {associateEntity.addNewProvider && (
                  <AssociateUser
                    location={location}
                    history={history}
                    userRole={constants.ROLES.HCP}
                    permission={providerInformation}
                    onCreate={this.handleAssociatingUser}
                    onClose={() =>
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addNewProvider: false
                        })
                      })
                    }
                  />
                )}
                <div
                  className={
                    associateEntity.addNewProvider ||
                      associateEntity.addProvider
                      ? 'd-none'
                      : 'd-flex align-items-start flex-column flex-sm-row justify-content-end'
                  }
                >
                  <ButtonComponent
                    buttonAction={() => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addNewProvider: true
                        })
                      });
                    }}
                    hidden={!providerInformation.write}
                    icon="add-icon"
                    buttonText={strings.addNewProvider}
                  />
                  <ButtonComponent
                    buttonAction={async () => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addProvider: true
                        })
                      });
                    }}
                    buttonClass={isMobile ? 'mt-3' : 'ml-4'}
                    hidden={!providerInformation.write}
                    icon="add-icon"
                    buttonText={strings.addExistingProvider}
                  />
                </div>
                {accountExecutiveInformation.read ? (
                  <Fragment>
                    <hr />
                    <h1 className="text-capitalize">
                      {strings.accountExecutive}
                    </h1>
                    <TableDisplay
                      heading={accountExecutiveTableHeading}
                      listing={getAccountExecutives(
                        accountExecutiveInformation.write,
                        clinicAE,
                        this.handleDeleteAccountExecutive
                      )}
                      tableClass="clinic-info-accountexecutive-table"
                    />
                  </Fragment>
                ) : null}
                {associateEntity.addAccountExecutive && (
                  <div
                    className={
                      associateEntity.addAccountExecutive
                        ? 'add-account-executive-clinic'
                        : 'd-none'
                    }
                    id="all-account-executive-tag"
                  >
                    <CustomSelect
                      clearable
                      len={-1}
                      minSearchChars={constants.TYPEAHEAD_SEARCH_TEXT_LEN}
                      className="d-inline-block"
                      clearCurrentVal={resetSelect}
                      afterClearCurrentValFn={() => {
                        this.setState({ resetSelect: false });
                      }}
                      filterOptions={{ key: 'id', values: clinicAE }}
                      optionUrl={API.ACCOUNTEXECUTIVESEARCH}
                      seperator=" "
                      urlSymbol="&"
                      searchParam="searchString"
                      placeholder={strings.chooseAccountExecutivePlaceholder}
                      displayAttr={['firstName', 'lastName']}
                      onChange={this.handleAdditionAccountExecutive}
                      isDisabled={!accountExecutiveInformation.write}
                    />
                    <span
                      className="cross-icon d-inline-block align-middle"
                      onClick={async () => {
                        await this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            addAccountExecutive: false
                          })
                        });
                      }}
                      onKeyPress={async () => {
                        await this.setState({
                          associateEntity: Object.assign(associateEntity, {
                            addAccountExecutive: false
                          })
                        });
                      }}
                      tabIndex={0}
                      role="button"
                    />
                  </div>
                )}
                {/* {associateEntity.addNewAccountExecutive && (
                  <AssociateUser
                    location={location}
                    history={history}
                    userRole={constants.ROLES.ASSOCIATE_EXECUTIVE}
                    permission={accountExecutiveInformation}
                    onCreate={this.handleAssociatingUser}
                    onClose={() =>
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addNewAccountExecutive: false
                        })
                      })
                    }
                  />
                )} */}
                <div
                  className={
                    // associateEntity.addNewAccountExecutive ||
                    associateEntity.addAccountExecutive
                      ? 'd-none'
                      : 'd-flex align-items-start flex-column flex-sm-row justify-content-end'
                  }
                >
                  {/* <ButtonComponent
                    buttonAction={() => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addNewAccountExecutive: true
                        })
                      });
                    }}
                    hidden={!accountExecutiveInformation.write}
                    icon="add-icon"
                    buttonText={strings.addNewAccountExecutive}
                  /> */}
                  <ButtonComponent
                    buttonAction={async () => {
                      this.setState({
                        associateEntity: Object.assign(associateEntity, {
                          addAccountExecutive: true
                        })
                      });
                    }}
                    buttonClass={isMobile ? 'mt-3' : 'ml-4'}
                    hidden={!accountExecutiveInformation.write}
                    icon="add-icon"
                    buttonText={strings.addExistingAccountExecutive}
                  />
                </div>
                <hr />
                <div className="clinic-actions">
                  <div className="clinic-modify-actions">
                    {modifyClinicAccount.write ? (
                      deleted ? (
                        <LinkButton
                          label={strings.activateClinic}
                          onClick={this.handleActivateClinic}
                        />
                      ) : (
                          <LinkButton
                            label={strings.deactivateClinic}
                            variant="danger"
                            onClick={this.handleDeactivateClinic}
                          />
                        )
                    ) : null}
                  </div>
                  <ButtonComponent
                    id="save-clinic-bottom"
                    buttonAction={this.handleUpdate}
                    hidden={!clinicInformation.write}
                    icon="right-arrow"
                    buttonText={strings.update}
                  />
                </div>
              </Form>
              <p id="error_message" className="text-danger">
                {error}
              </p>
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
          className={
            associateEntity.addAccountExecutive
              ? 'account-executive-confirmation-dialog'
              : ''
          }
        />
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const {
    providerReducer,
    breadcrumbsReducer,
    clinicsReducer,
    userReducer
  } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    specialityList: clinicsReducer.speciality,
    clinic: clinicsReducer.clinic[id] || {},
    clinicAdmin: clinicsReducer.clinicAdmin[id],
    clinicHcp: clinicsReducer.clinicHcp[id],
    clinicAE: clinicsReducer.accountExecutive[id],
    providers: providerReducer.providers,
    clinicAllAdmin: clinicsReducer.clinicAllAdmin,
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    cityStateByZip: userReducer.cityStateByZip
  };
};

export default connect(
  mapStateToProps,
  null
)(ClinicInfo);
