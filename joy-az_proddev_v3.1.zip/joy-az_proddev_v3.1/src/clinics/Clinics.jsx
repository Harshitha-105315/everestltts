import React, { Component } from 'react';
import { connect } from 'react-redux';
import Search from 'components/Search';
import { Header, SideBar } from 'components/Navigation';
import TableDisplay from 'components/TableDisplay';
import strings from 'localization/strings';
import { FootNote } from 'components/FootNote';
import { getSearchString, getUserData } from 'utils/helper.js';
import accessMatrix from 'rolesData/accessMatrix.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import { uid } from 'react-uid';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { getCityByStateCountryList } from 'utils/helper.js';
import debounce from 'lodash/debounce';
import ButtonComponent from 'components/ButtonComponent';
import { isUndefined, isEmpty } from 'lodash';
import constants from '../constants.js';
import {
  updateUrl,
  clearBreadCrumb,
  addBreadCrumb,
  clearCustomPatientStoreValue
} from '../utils/utltity';
import './Clinics.scss';

class Clinics extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      page: 1,
      perPage: 10,
      sortBy: 'name',
      asc: true,
      clinicSpecialty: null,
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      status: 'all',
      filterOn: false
    };
    this.fetchClinics = this.fetchClinics.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.getSearchString = getSearchString.bind(this);
    this.updateUrl = updateUrl.bind(this);
    this.clearBreadCrumb = clearBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.clearCustomPatientStoreValue = clearCustomPatientStoreValue.bind(this);
    this.changeSearch = debounce(() => {
      this.dispatchForClinics();
      this.updateUrl(this.exempt);
    }, constants.SEARCH_DEBOUNCE_MS);
    this.exempt = ['filterOn'];
  }

  async componentWillMount() {
    const {
      dispatch
    } = this.props;
    this.clearCustomPatientStoreValue([
      'statesByCountry',
      'cityByStateCountry'
    ]);
    const newState = { ...this.state };
    if (
      newState.country !== null &&
      newState.country !== '' &&
      !isUndefined(newState.country)
    ) {
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [newState.country] }
      });
      if (
        newState.state !== null &&
        newState.state !== '' &&
        !isUndefined(newState.state)
      ) {
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [newState.country], state: [newState.state] }
        });
      }
    } else {
      newState.country = null;
      newState.state = null;
      newState.city = null;
    }
    this.filterCheck();
    this.dispatchForClinics();
    this.clearBreadCrumb();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.NAVIGATION.NAVIGATION_SHOW_SEARCH_MOB,
      toggleValue: false
    });
  }

  listClinics = () => {
    const { clinics, history } = this.props;
    if (!isEmpty(clinics)) {
      return clinics.map(d => (
        <tr
          key={uid(d)}
          className="listing"
          onClick={() => {
            this.addBreadCrumb({ title: strings.manageClinics });
            history.push(reverse(urls.CLINIC.DETAIL.DETAILS, { id: d.id }));
          }}
        >
          <td id="clinic-name-clinic" style={{ width: '20%' }}>
            {`${d.name}`}
            <p className="secondary-data d-sm-none">{d.hillromId}</p>
          </td>
          <td id="hillrom-id-clinic" className="d-none d-sm-table-cell" style={{ width: '15%' }}>
            {d.hillromId}
          </td>
          <td
            id="city-state-clinic"
            className="d-none d-sm-table-cell" style={{ width: '15%' }}
          >{`${d.city}/${d.state}`}</td>
          <td id="clinic-address-clinic" className="d-none d-sm-table-cell" style={{ width: '20%' }}>
            {d.address}
          </td>
          <td id="clinic-patient-count-clinic" className="d-none d-sm-table-cell" style={{ width: '15%' }}>
            {d.patientCount}
          </td>
          <td id="status-clinic" style={{ width: '20%' }}>
            {d.deleted ? (
              <div>
                <div className=" red-inactive d-inline-block" />
                <span className="text-capitalize">{strings.inactive}</span>
              </div>
            ) : (
                <div>
                  <div className="green-active d-inline-block" />
                  <span className="text-capitalize">{strings.active}</span>
                </div>
              )}
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="5" className="text-center text-capitalize">
          {strings.noClinicDataAvaliable}
        </td>
      </tr>
    );
  };

  dispatchForClinics() {
    const { dispatch } = this.props;
    const payload = Object.assign({}, this.state);
    this.exempt.forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.CLINICS.CLINICS_SEARCH_REQUEST,
      payload
    });
  }

  async fetchClinics(event) {
    const name = (event && event.target.value) || '';
    await this.resetFilter(true);
    await this.setState({ name });
    this.changeSearch();
  }

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
    this.updateUrl(this.exempt);
    this.dispatchForClinics();
  }

  async filterCheck() {
    const { country, status, state } = this.state;
    if (status !== constants.FILTER_VALUES.ALL || country !== constants.LOCATIONS[0] || state !== null) {
      await this.setState({ filterOn: true });
    } else {
      await this.setState({ filterOn: false });
    }
  }

  async handleFilter(event) {
    const { name, value } = event.target;
    const { dispatch } = this.props;
    if (name === 'country') {
      if (value === 'country') {
        await this.setState({ country: null });
        const { state, city } = this.state;
        if (state !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ state: null });
        }
        if (city !== null) {
          this.clearCustomPatientStoreValue([
            'statesByCountry',
            'cityByStateCountry'
          ]);
          await this.setState({ city: null });
        }
      } else {
        dispatch({
          type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
          payload: { country: [value] }
        });
        await this.setState({
          [name]: value,
          city: null,
          state: null,
          page: 1
        });
        this.clearCustomPatientStoreValue([
          'statesByCountry',
          'cityByStateCountry'
        ]);
      }
    } else if (name === 'state') {
      if (value === 'state') {
        await this.setState({ state: null, city: null });
        this.clearCustomPatientStoreValue(['cityByStateCountry']);
      } else {
        const { country } = this.state;
        dispatch({
          type: constants.PATIENT.CITYBYSTATECOUNTRY_REQUEST,
          payload: { country: [country], state: [value] }
        });
        await this.setState({ [name]: value, city: null, page: 1 });
      }
    } else if (name === 'city') {
      if (value === 'city') {
        await this.setState({ city: null });
      } else {
        await this.setState({ [name]: value, page: 1 });
      }
    } else {
      await this.setState({ [name]: value, page: 1 });
    }
    this.filterCheck();
    this.updateUrl(this.exempt);
    this.dispatchForClinics();
  }

  async handleSorting(event) {
    const { asc, sortBy } = this.state;
    const { name } = event.target;
    await this.setState({ page: 1 });
    if (sortBy !== name) {
      await this.setState({ sortBy: name, asc: true });
    } else {
      await this.setState({ asc: !asc });
    }
    this.updateUrl(this.exempt);
    this.dispatchForClinics();
  }

  async resetFilter(onlyReset) {
    const { dispatch } = this.props;
    if (this.state.country === constants.LOCATIONS[0]) {
      this.clearCustomPatientStoreValue([
        'cityByStateCountry'
      ]);
    } else {
      this.clearCustomPatientStoreValue([
        'statesByCountry',
        'cityByStateCountry'
      ]);
      dispatch({
        type: constants.PATIENT.STATEBYCOUNTRY_REQUEST,
        payload: { country: [constants.LOCATIONS[0]] }
      });
    }
    await this.setState({
      name: '',
      page: 1,
      country: constants.LOCATIONS[0],
      state: null,
      city: null,
      status: 'all',
      filterOn: false
    });
    if (!onlyReset) {
      this.updateUrl(this.exempt);
      this.dispatchForClinics();
    }
  }

  render() {
    const {
      name,
      page,
      perPage,
      status,
      country,
      state,
      city,
      filterOn
    } = this.state;
    const {
      history,
      totalClinics,
      showSearch,
      statesByCountry,
      cityByStateCountry
    } = this.props;
    const { actualRole } = getUserData();
    const createClinicInformation = accessMatrix.CREATE_CLINIC[actualRole];
    const searchClinics = accessMatrix.SEARCH_CLINICS[actualRole];
    const clinicStatusFilter = accessMatrix.CLINIC_STATUS_FILTER[actualRole];
    const cityByStateCountryList = getCityByStateCountryList(
      cityByStateCountry
    );
    let clinicFilters = {};
    if (clinicStatusFilter.read) {
      clinicFilters = {
        Clinic_Status: [
          {
            title: strings.all,
            onChangeFunction: this.handleFilter,
            name: constants.FILTER_NAME.STATUS,
            value: constants.FILTER_VALUES.ALL,
            type: constants.FILTER_TYPE.RADIO,
            checked: status === constants.FILTER_VALUES.ALL ? true : null
          },
          {
            title: strings.active,
            onChangeFunction: this.handleFilter,
            name: constants.FILTER_NAME.STATUS,
            value: constants.FILTER_VALUES.ACTIVE,
            type: constants.FILTER_TYPE.RADIO,
            checked: status === constants.FILTER_VALUES.ACTIVE ? true : null
          },
          {
            title: strings.inactive,
            onChangeFunction: this.handleFilter,
            name: constants.FILTER_NAME.STATUS,
            value: constants.FILTER_VALUES.INACTIVE,
            type: constants.FILTER_TYPE.RADIO,
            checked: status === constants.FILTER_VALUES.INACTIVE ? true : null
          }
        ]
      };
    }

    return (
      <div>
        <Header
          searchExitHandle={async () => {
            await this.setState({ name: '' });
            this.updateUrl(this.exempt);
            this.dispatchForClinics();
          }}
        />
        {searchClinics.read ? (
          <MainWrapper>
            <SideBar
              filters={{
                ...clinicFilters,
                Location: [
                  {
                    title: strings.country,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.COUNTRY,
                    value: country || '',
                    onChangeFunction: this.handleFilter,
                    options: constants.LOCATIONS
                  },
                  {
                    title: strings.state,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.STATE,
                    value: state || '',
                    onChangeFunction: this.handleFilter,
                    options: country ? statesByCountry : []
                  },
                  {
                    title: strings.city,
                    type: constants.FILTER_TYPE.SELECT,
                    name: constants.FILTER_NAME.CITY,
                    value: city || '',
                    onChangeFunction: this.handleFilter,
                    options: country ? cityByStateCountryList : []
                  }
                ]
              }}
              resetFilter={this.resetFilter}
              filterOn={filterOn}
              hidden={name === '' ? false : true}
            />
            <MainContent
              {...(name !== ''
                ? { styleClass: 'col-md-10 table-search-desktop' }
                : {})}
            >
              <div>
                <div className="table-header d-flex flex-wrap align-items-center">
                  <h1
                    className={`${showSearch === true
                      ? 'd-none'
                      : 'text-capitalize d-inline marginv-auto'
                      }`}
                  >
                    {name ? strings.searchClinics : strings.manageClinics}
                  </h1>
                  <Search
                    searchString={name}
                    fetchOnChange={this.fetchClinics}
                    modifierClass="d-sm-inline"
                    showSearch={showSearch}
                    placeholder={strings.clinicSearchPlaceholder}
                  />
                  <div className="breaker" />
                  <p
                    className={
                      totalClinics === 0 || name !== '' || showSearch
                        ? 'd-none'
                        : 'mobile-table-count d-sm-none text-capitalize'
                    }
                  >
                    {totalClinics} {strings.clinics}
                  </p>
                  <ButtonComponent
                    id="new-clinic"
                    buttonClass={`${showSearch === true ? 'd-none' : 'overview-button ml-auto'
                      }`}
                    hidden={
                      !createClinicInformation.write || showSearch || name
                    }
                    buttonAction={() => {
                      this.addBreadCrumb({ title: strings.manageClinics });
                      history.push(urls.CLINIC.ADD);
                    }}
                    icon="add-icon"
                    buttonText={strings.newClinic}
                  />
                  <span
                    className={`${name !== ''
                      ? 'table-search-exit cross-icon d-md-inline-block ml-auto'
                      : 'd-none'
                      }`}
                    onClick={async () => {
                      this.fetchClinics();
                    }}
                    onKeyPress={async () => {
                      this.fetchClinics();
                    }}
                    tabIndex={0}
                    role="button"
                  />
                </div>
                <div>
                  <h6
                    className={`${name === '' ? 'd-none' : 'text-capitalize show-search'
                      } `}
                  >{`${strings.searchResults} (${totalClinics || 0})`}</h6>
                  <h6
                    className={
                      name === '' && showSearch
                        ? 'd-sm-none table-description'
                        : 'd-none'
                    }
                  >
                    {totalClinics || 0} {strings.clinics}
                  </h6>
                  <TableDisplay
                    heading={[
                      {
                        text: strings.clinicName,
                        sortable: true,
                        name: 'name',
                        value: 'name'
                      },
                      {
                        text: strings.hillromID,
                        sortable: true,
                        name: 'hillromId',
                        value: 'hillromId',
                        mobile: false
                      },
                      {
                        text: `${strings.city}/${strings.state}`,
                        sortable: false,
                        mobile: false
                      },
                      {
                        text: strings.address,
                        sortable: false,
                        mobile: false
                      },
                      {
                        text: strings.patientCount,
                        sortable: true,
                        name: 'patientCount',
                        value: 'patientCount',
                        mobile: false
                      },
                      {
                        text: strings.status,
                        sortable: false,
                        name: 'is_deleted',
                        value: 'is_deleted'
                      }
                    ]}
                    totalUsers={totalClinics}
                    listing={this.listClinics()}
                    handleSorting={this.handleSorting}
                    getSearchString={this.getSearchString}
                    searchDisplay
                    pagination
                    handlePaginate={this.handlePaginate}
                    perPage={perPage}
                    page={page}
                    totalDisplayLabel={strings.clinics}
                    searchString={name}
                    noResultFound={strings.noClinicDataAvaliable}
                  />
                </div>
              </div>
              <FootNote />
            </MainContent>
          </MainWrapper>
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { clinicsReducer, filterReducer, patient } = state.app;
  return {
    clinics: clinicsReducer.clinics,
    totalClinics: clinicsReducer.totalClinics || null,
    showSearch: filterReducer.showSearch,
    statesByCountry: patient.statesByCountry,
    cityByStateCountry: patient.cityByStateCountry
  };
};

export default connect(
  mapStateToProps,
  null
)(Clinics);
