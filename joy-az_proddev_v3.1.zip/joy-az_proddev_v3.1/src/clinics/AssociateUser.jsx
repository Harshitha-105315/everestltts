import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import NumberFormat from 'react-number-format';

import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import constants from 'constants.js';
import strings from 'localization/strings';
import ConfirmationDialog from 'components/ConfirmationDialog';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { isValidMobile, validateEmail } from 'utils/helper.js';

const helperText = 'Add {firstName} {lastName} as the';

const userRoleDialog = {
  CLINIC_ADMIN: {
    body: `${helperText} ${strings.clinicAdmin}?`,
    title: strings.addNewClinicAdmin,
    button: strings.addClinicAdmin,
    create: strings.createAdmin
  },
  ASSOCIATE_EXECUTIVE: {
    body: `${helperText} ${strings.accountExecutive}?`,
    title: strings.addNewAccountExecutive,
    button: strings.addAccountExecutive,
    create: strings.createAE
  },
  HCP: {
    body: `${helperText} ${strings.Provider}?`,
    title: strings.addNewProvider,
    button: strings.addProvider,
    create: strings.createProvider
  }
};

class AssociateUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {
        email: '',
        firstName: '',
        lastName: '',
        middleName: '',
        mobilePhone: '',
        hillromId: ''
      },
      error: '',
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
  }

  handleCreate = () => {
    const { data, dialog } = this.state;
    const { firstName, lastName, email, mobilePhone, hillromId } = data;
    const { userRole } = this.props;
    this.setState({ error: '' });
    if (firstName === '' || firstName === null) {
      this.setState({ error: strings.pleaseEnterFirstName });
    } else if (lastName === '' || lastName === null) {
      this.setState({ error: strings.pleaseSelectLastName });
    } else if (!validateEmail(email)) {
      this.setState({ error: strings.pleaseEnterValidEmail });
    } else if (mobilePhone && !isValidMobile(mobilePhone, 10, true)) {
      this.setState({ error: strings.enterValidMobileNumber });
    } else if (
      (userRole === constants.ROLES.ASSOCIATE_EXECUTIVE && hillromId === '') ||
      hillromId === null
    ) {
      this.setState({ error: strings.pleaseEnterHillromID });
    } else {
      this.setState({
        dialog: Object.assign(dialog, {
          body: userRoleDialog[userRole].body
            .replace('{firstName}', firstName)
            .replace('{lastName}', lastName),
          title: userRoleDialog[userRole].title,
          button: userRoleDialog[userRole].button,
          confirmFunction: this.handleConfirmation,
          show: true
        })
      });
    }
  };

  handleConfirmation = () => {
    const { userRole, onClose, onCreate } = this.props;
    const { data, dialog } = this.state;
    onCreate(data, userRole);
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      data: {
        email: '',
        firstName: '',
        lastName: '',
        middleName: '',
        mobilePhone: ''
      }
    });
    onClose();
  };

  handleChange = e => {
    const { data } = this.state;
    this.setState({
      data: { ...data, [e.target.name]: e.target.value }, isDirty: true
    });
  };

  render() {
    const { userRole, permission, onClose, location, history } = this.props;
    const { data, error, dialog } = this.state;
    const {
      firstName,
      middleName,
      lastName,
      email,
      mobilePhone,
      hillromId
    } = data;
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <h4 className="text-capitalize">{userRoleDialog[userRole].title}</h4>
        <Form.Row>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.firstName} <span className="asterisk-color">*</span></Form.Label>
            <FormControlComponent
              type="text"
              name="firstName"
              value={firstName}
              onChange={this.handleChange}
              maxLength="50"
              readOnly={!permission.write}
            />
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.middleName}</Form.Label>
            <FormControlComponent
              type="text"
              name="middleName"
              value={middleName}
              onChange={this.handleChange}
              maxLength="50"
              readOnly={!permission.write}
            />
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.lastName} <span className="asterisk-color">*</span></Form.Label>
            <FormControlComponent
              type="text"
              name="lastName"
              value={lastName}
              onChange={this.handleChange}
              maxLength="50"
              readOnly={!permission.write}
            />
          </Form.Group>
        </Form.Row>
        <Form.Row>
          {userRole === constants.ROLES.ASSOCIATE_EXECUTIVE && (
            <Form.Group as={Col} md={4}>
              <Form.Label>{strings.hrid} <span className="asterisk-color">*</span></Form.Label>
              <FormControlComponent
                type="text"
                name="hillromId"
                value={hillromId}
                onChange={this.handleChange}
                readOnly={!permission.write}
              />
            </Form.Group>
          )}
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.email} <span className="asterisk-color">*</span></Form.Label>
            <FormControlComponent
              type="text"
              name="email"
              value={email || ''}
              onChange={this.handleChange}
              maxLength="100"
              readOnly={!permission.write}
            />
          </Form.Group>
          <Form.Group as={Col} md={4}>
            <Form.Label>{strings.primaryPhone}</Form.Label>
            <NumberFormat
              className="form-control"
              placeholder={strings.numberPlaceholder}
              format={strings.numberFormat}
              value={mobilePhone}
              onChange={this.handleChange}
              readOnly={!permission.write}
              name="mobilePhone"
            />
          </Form.Group>
        </Form.Row>
        <p id="error" className="text-danger">
          {error}
        </p>
        <div className="d-flex justify-content-end">
          <ButtonComponent
            buttonAction={onClose}
            icon="right-arrow"
            buttonText={strings.cancel}
            hidden={!permission.write}
          />
          <ButtonComponent
            icon="update-icon"
            buttonClass="ml-4"
            buttonAction={this.handleCreate}
            buttonText={userRoleDialog[userRole].create}
            hidden={!permission.write}
          />
        </div>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}

export default AssociateUser;
