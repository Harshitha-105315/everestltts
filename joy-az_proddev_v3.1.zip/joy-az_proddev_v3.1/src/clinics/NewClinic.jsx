import React, { Component } from 'react';
import { Form, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import constants from 'constants.js';
import { Header, SideBar } from 'components/Navigation';
import urls from 'urls';
import NumberFormat from 'react-number-format';
import { FootNote } from 'components/FootNote';
import { isValidMobile } from 'utils/helper';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import strings from 'localization/strings';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import ConfirmationDialog from 'components/ConfirmationDialog';
import { isEmpty } from 'lodash';
import {
  handleZipChange,
  getSpeciality,
  removeBreadCrumb,
  addBreadCrumb,
  getBreadCrumb,
  clearZipStoreValue
} from '../utils/utltity';
import RouteLeavingGuard from 'components/RouteLeavingGuard';

class NewClinic extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      hillromId: '',
      name: '',
      address: '',
      address2: '',
      city: '',
      state: '',
      zipcode: '',
      phoneNumber: '',
      faxNumber: '',
      speciality: '',
      isMessageOpted: false,
      makeChild: false,
      makeParent: true,
      parent: true,
      type: 'parent',
      error: null,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleZipChange = handleZipChange.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.clearZipStoreValue = clearZipStoreValue.bind(this);
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
    dispatch({ type: constants.CLINICS.CLEAR_ADD_CLINIC_STATUS });
    this.clearZipStoreValue();
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.addNewClinic });
  }

  componentWillReceiveProps(newProps) {
    const { cityStateByZip } = newProps;
    if (cityStateByZip !== undefined) {
      if (!isEmpty(cityStateByZip)) {
        this.setState({
          zipcode: cityStateByZip.zipCode,
          state: cityStateByZip.state,
          city: cityStateByZip.city
        });
      } else {
        this.setState({
          state: '',
          city: ''
        });
      }
    }
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
  }

  handleSubmit = () => {
    const {
      hillromId,
      name,
      address,
      zipcode,
      phoneNumber,
      faxNumber,
      city
    } = this.state;
    this.setState({ error: '' });
    if (hillromId === '') {
      this.setState({ error: strings.pleaseEnterHillromID });
    } else if (name === '') {
      this.setState({ error: strings.pleaseEnterClinicName });
    } else if (address === '') {
      this.setState({ error: strings.pleaseEnterAddress });
    } else if (zipcode === '' || zipcode === null) {
      this.setState({ error: strings.pleaseEnterZipcode });
    } else if (city === '' || city === null) {
      this.setState({ error: strings.pleaseEnterValidZipcode });
    } else if (!isValidMobile(phoneNumber, 10, false)) {
      this.setState({ error: strings.phoneNumberInvalid });
    } else if (!isValidMobile(faxNumber, 10, true)) {
      this.setState({ error: strings.faxNumberisInvalid });
    } else {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.createProfileMsg
            .replace('{VALUE}', name)
            .replace('{ENTITY}', 'clinic'),
          title: strings.createClinic,
          button: strings.createClinic,
          confirmFunction: this.save,
          show: true
        })
      });
    }
  };

  save = () => {
    const { dispatch, history } = this.props;
    const payload = Object.assign({}, this.state);
    ['isMobile', 'error', 'dialog', 'isDirty'].forEach(e => {
      delete payload[e];
    });
    dispatch({
      type: constants.CLINICS.ADD_CLINIC_REQUEST,
      allData: { history, payload, path: urls.CLINIC.ALL }
    });
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  async handleChange(event) {
    if (event.target.value === strings.selectSpeciality) {
      await this.setState({ [event.target.name]: null, isDirty: true });
    } else {
      await this.setState({
        [event.target.name]: event.target.value,
        isDirty: true
      });
    }
  }

  render() {
    const {
      hillromId,
      zipcode,
      city,
      state,
      name,
      address,
      address2,
      phoneNumber,
      faxNumber,
      speciality,
      error,
      isMobile,
      dialog
    } = this.state;
    const { breadcrumbs, history, location } = this.props;
    const sideBarData = {};
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.CLINIC.ALL}
        />
        <MainWrapper>
          <SideBar />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <h1 className="d-inline-block text-capitalize">
                {strings.addNewClinic}
              </h1>
              {!isMobile && (
                <ButtonComponent
                  buttonClass="float-right"
                  buttonAction={this.handleSubmit}
                  icon="report-detail-icon"
                  buttonText={strings.save}
                />
              )}
            </div>
            <div>
              <Form>
                <div
                  style={isMobile ? { height: '2.25rem' } : {}}
                  className="mb-3"
                >
                  <h6
                    style={isMobile ? { verticalAlign: 'sub' } : {}}
                    className="text-capitalize d-inline"
                  >
                    {strings.clinicIdentifiers}
                  </h6>
                  {isMobile && (
                    <ButtonComponent
                      buttonClass="float-right"
                      buttonAction={this.handleSubmit}
                      icon="report-detail-icon"
                      buttonText={strings.save}
                    />
                  )}
                </div>
                <p className="text-danger">{error}</p>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.hillromId} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      name="hillromId"
                      value={hillromId}
                      onChange={this.handleChange}
                      placeholder={strings.hillromId}
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <h6 className="text-capitalize">{strings.generalDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={8}>
                    <Form.Label>{strings.clinicName} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      name="name"
                      value={name}
                      onChange={this.handleChange}
                      maxLength="50"
                      placeholder={strings.clinicName}
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.speciality}</Form.Label>
                    <Form.Control
                      as="select"
                      name="speciality"
                      value={speciality}
                      onChange={this.handleChange}
                      className="text-capitalize"
                    >
                      <option>{strings.selectSpeciality}</option>
                      {this.getSpeciality()}
                    </Form.Control>
                  </Form.Group>
                </Form.Row>
                <hr />
                <h6 className="text-capitalize">{strings.contactDetails}</h6>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.addressLine1} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      type="text"
                      name="address"
                      value={address}
                      onChange={this.handleChange}
                      maxLength="100"
                      placeholder={strings.addressLine1}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.addressLine2}</Form.Label>
                    <FormControlComponent
                      type="text"
                      name="address2"
                      value={address2}
                      maxLength="100"
                      onChange={this.handleChange}
                      placeholder={strings.addressLine2}
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.city} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      readOnly
                      type="text"
                      name="city"
                      value={city}
                      onChange={this.handleChange}
                      placeholder={strings.city}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={2}>
                    <Form.Label>{strings.state} <span className="asterisk-color">*</span></Form.Label>
                    <FormControlComponent
                      readOnly
                      type="text"
                      name="state"
                      value={state}
                      onChange={this.handleChange}
                      placeholder={strings.state}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={2}>
                    <Form.Label>{strings.zip} <span className="asterisk-color">*</span></Form.Label>

                    <FormControlComponent
                      type="text"
                      name="zipcode"
                      value={zipcode}
                      onChange={this.handleChange}
                      onBlur={event => {
                        this.handleZipChange(event);
                      }}
                      placeholder={strings.c_zipcode}
                      maxLength="7"
                    />
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.clinicPhone} <span className="asterisk-color">*</span></Form.Label>

                    <NumberFormat
                      className="form-control"
                      placeholder="(code)-number"
                      format="(###)-###-####"
                      mask="_"
                      name="phoneNumber"
                      value={phoneNumber}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                  <Form.Group as={Col} md={4}>
                    <Form.Label>{strings.clinicFax}</Form.Label>
                    <NumberFormat
                      className="form-control"
                      placeholder="(code)-number"
                      format="(###)-###-####"
                      mask="_"
                      name="faxNumber"
                      value={faxNumber}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Form.Row>
                <hr />
                <ButtonComponent
                  id="add-clinic-bottom"
                  buttonClass="float-right"
                  buttonAction={this.handleSubmit}
                  icon="report-detail-icon"
                  buttonText={strings.save}
                />
              </Form>
              <p id="error_message" className="text-danger">
                {error}
              </p>
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  const { clinicsReducer, userReducer, breadcrumbsReducer } = state.app;
  return {
    specialityList: clinicsReducer.speciality,
    cityStateByZip: userReducer.cityStateByZip,
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};
export default connect(
  mapStateToProps,
  null
)(NewClinic);
