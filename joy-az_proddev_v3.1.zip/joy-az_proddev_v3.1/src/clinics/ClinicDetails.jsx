import React, { Component } from 'react';
import { connect } from 'react-redux';
import constants from 'constants.js';
import Search from 'components/Search';
import { Header, SideBar } from 'components/Navigation';
import urls from 'urls';
import { reverse as url_reverse } from 'named-urls';
import { getUserData, getEndDate } from 'utils/helper';
import TableDisplay from 'components/TableDisplay';
import moment from 'moment-timezone';
import getCardComponent from 'components/CardComponent';
import { FootNote } from 'components/FootNote';
import RangeMonthlyPicker from 'components/RangeMonthPicker';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { uid } from 'react-uid';
import ButtonComponent from 'components/ButtonComponent';
import { PDFDownloadLink } from '@react-pdf/renderer';
import { Form, ProgressBar, Modal, Button, Badge } from 'react-bootstrap';
import debounce from 'lodash/debounce';
import { isEmpty } from 'lodash';
import Pdf from '../pdf-files/Pdf';
import strings from '../localization/strings';
import searchKeyMap from 'rolesData/searchMapKey';
import { decryptemail } from '../Cryptocode';
import {
  addBreadCrumb,
  getBreadCrumb,
  removeBreadCrumb,
  updateUrl,
  clearAllSelectedCheckBoxes,
  selectAllCheckBoxes,
  deselectCheckBoxes,
  storeSelectedPatientIds
} from '../utils/utltity';
import {
  decode,
  customSort,
  getPaginatedUserIds,
  getTransmissionCell
} from '../utils/helper';
import { getEnhancedPatientsGroupData } from '../patient/utils/overview';
import {
  getSessionsField,
  getDeviceImage,
  getProviderField
} from '../patient/helper';

import SelectColorDialog from 'components/SelectColorDialog';
import { getFiltersForAssocatiedPatients } from './helper';
import { allowFlag } from '../rolesData/searchMapKey';
import accessMatrix from '../rolesData/accessMatrix';
import { saveAs } from 'file-saver';

class ClinicDetails extends Component {
  constructor(props) {
    const start = moment()
      .subtract(constants.DEFAULT_MONTH_RANGE, 'months')
      .startOf('month');
    const end = getEndDate();
    super(props);
    this.state = {
      type: constants.FILTER_VALUES.ALL,
      page: 1,
      perPage: 10,
      sortBy: '',
      order: 'desc',
      pattern: '',
      deviceSts: constants.FILTER_VALUES.ACTIVE,
      gender: constants.FILTER_VALUES.ALL,
      providerId: null,
      from: start.format('YYYY-MM-DD'),
      to: end.format('YYYY-MM-DD'),
      patientSts: constants.FILTER_VALUES.ACTIVE,
      transmission: constants.FILTER_VALUES.TRANSMITTING,
      ageRange: constants.FILTER_VALUES.ALL,
      session: null,
      active: 'temp-1',
      startDate: start,
      endDate: end,
      pdf: '',
      isBlackAndWhite: true,
      allUserData: [],
      barCharts: {},
      gaugeGraphs: {},
      isMobile: false,
      openPopup: false,
      sessionsCompleted: '',
      viewMore: '',
      filterOn: false,
      selectedCheckBoxIds: [],
      showDialog: false
    };
    this.getPatientsBody = this.getPatientsBody.bind(this);
    this.fetchAssociatedPatients = this.fetchAssociatedPatients.bind(this);
    this.getCardComponent = getCardComponent.bind(this);
    this.getSearchString = this.getSearchString.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.removeBreadCrumb = removeBreadCrumb.bind(this);
    this.generateBatchReport = this.generateBatchReport.bind(this);
    this.therapyMonthRange = this.therapyMonthRange.bind(this);
    this.handleRangeChange = this.handleRangeChange.bind(this);
    this.cancelDownload = this.cancelDownload.bind();
    this.closeWarnMsg = this.closeWarnMsg.bind();
    this.updateUrl = updateUrl.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
    this.handleCardChange = this.handleCardChange.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.filterCheck = this.filterCheck.bind(this);
    this.getProviderField = getProviderField.bind(this);
    this.getFiltersForAssocatiedPatients = getFiltersForAssocatiedPatients.bind(
      this
    );
    this.clearAllSelectedCheckBoxes = clearAllSelectedCheckBoxes.bind(this);
    this.storeSelectedPatientIds = storeSelectedPatientIds.bind(this);
    this.selectAllCheckBoxes = selectAllCheckBoxes.bind(this);
    this.deselectCheckBoxes = deselectCheckBoxes.bind(this);

    this.changeSearch = debounce(() => {
      const {
        dispatch,
        match: {
          params: { id }
        }
      } = this.props;
      const { actualRole } = getUserData();
      let payload = Object.assign({}, this.state);
      this.excempt.forEach(element => {
        delete payload[element];
      });
      let { pattern } = this.state;
      pattern = pattern.trim();
      payload = { ...payload, pattern };
      let { to, from, ...rest } = payload;
      payload = rest;
      dispatch({
        type: constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_REQUEST,
        id,
        payload,
        entity: searchKeyMap[actualRole]
      });
    }, constants.SEARCH_DEBOUNCE_MS);

    this.excempt = [
      'active',
      'isMobile',
      'startDate',
      'endDate',
      'pdf',
      'isDownloadable',
      'isBlackAndWhite',
      'allUserData',
      'barCharts',
      'gaugeGraphs',
      'isMobile',
      'openPopup',
      'sessionsCompleted',
      'initializeDownload',
      'pdfDownloadLink',
      'viewMore',
      'order',
      'filterOn',
      'sort_by',
      'selectedCheckBoxIds',
      'checkBoxData',
      'showDialog'
    ];
  }

  async componentWillMount() {
    const {
      dispatch,
      match: {
        params: { id }
      },
      location: { search }
    } = this.props;
    const payload = { ...this.state };
    if (search !== '') {
      const newState = decode(
        search
          .substring(1)
          .replace('sort_by', 'sortBy')
          .replace('per_page', 'perPage')
      );
      await this.setState(newState);
    }
    this.excempt.forEach(element => {
      delete payload[element];
    });
    this.filterCheck();
    dispatch({ type: constants.CLINICS.CLINIC_BYID_REQUEST, id });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.associatedPatients });
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    dispatch({ type: constants.CLINICS.CLINIC_HCP_REQUEST, id });
    dispatch({ type: constants.CLINICS.CLINIC_ADMIN_REQUEST, id });
    this.dispatchSearch();
  }

  componentWillUnmount() {
    this.removeBreadCrumb();
  }

  async getActiveCard() {
    const { active } = this.state;
    let type;
    switch (active) {
      case 'temp-1':
        type = 'all';
        break;
      case 'temp-2':
        type = 'session50';
        break;
      case 'temp-3':
        type = 'session80';
        break;
      case 'temp-4':
        type = 'session100';
        break;
      case 'temp-5':
        type = 'flagged';
        break;
      case 'temp-6':
        type = 'titan';
        break;
      case 'temp-7':
        type = 'monarch';
        break;
      case 'temp-8':
        type = 'vest';
        break;
      case 'temp-9':
        type = 'multi';
        break;
      default:
        type = 'all';
    }
    await this.setState({ type });
  }

  getActiveCardName = () => {
    const { active } = this.state;
    switch (active) {
      case 'temp-1':
        return strings.totalPatients;
      case 'temp-2':
        return `${strings.sessionsCompleted} ${strings.session1}`;
      case 'temp-3':
        return `${strings.sessionsCompleted} ${strings.session2}`;
      case 'temp-4':
        return `${strings.sessionsCompleted} ${strings.session3}`;
      case 'temp-5':
        return strings.flaggedPatients;
      case 'temp-6':
        return strings.titanPatients;
      case 'temp-7':
        return strings.monarchPatients;
      case 'temp-8':
        return strings.visiVestPatients;
      case 'temp-9':
        return strings.multiDevicePatients;
      default:
        return strings.totalPatients;
    }
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  getPatientsBody() {
    const {
      perPage,
      page,
      order,
      sortBy,
      isMobile,
      selectedCheckBoxIds
    } = this.state;
    const { associatedPatients, history } = this.props;
    const userData = getUserData();
    const flagPatient = accessMatrix.FLAG_PATIENT[userData.actualRole];
    const indexofLastItem = page * perPage;
    const indexOfFirstItem = indexofLastItem - perPage;
    let patientCopy = [...associatedPatients];
    if (sortBy) {
      patientCopy = customSort(patientCopy, sortBy, order);
    }
    const currentPatientList = patientCopy.slice(
      indexOfFirstItem,
      indexofLastItem
    );
    if (!isEmpty(currentPatientList)) {
      return currentPatientList.map(d => (
        <tr
          key={uid(d)}
          className="listing"
          onClick={event => {
            if (
              event.target.getAttribute('name') !==
              'view-more-provider-clinics' &&
              event.target.getAttribute('type') !== 'checkbox' &&
              event.target.getAttribute('name') !== 'flagged'
            ) {
              this.addBreadCrumb({ title: strings.patientDetails });
              history.push(
                url_reverse(urls.PATIENT.DETAIL.OVERVIEW.ALL, { id: d.userId })
              );
            }
          }}
        >
          {!isMobile && (
            <td className="align-middle">
              <div onClick={event => this.storeSelectedPatientIds(event, d.userId)}>
                <Form.Check
                  checked={
                    !isEmpty(selectedCheckBoxIds) &&
                    selectedCheckBoxIds.includes(d.userId)
                  }
                  custom
                  type="checkbox"
                  label=""
                  id={`check-box-${d.userId}`}
                />
              </div>
            </td>
          )}
          <td className="flagged align-middle">
            {flagPatient.read ? (
              <span
                name="flagged"
                className={`${flagPatient.write ? 'cursor' : 'no-cursor'
                  } d-inline-block ${d.flagged ? 'hr-flag' : 'disable-flag'}`}
                onClick={e => {
                  if (flagPatient.write) {
                    this.handleFlagged(
                      e,
                      d.flagged,
                      d.patientId,
                      allowFlag[userData.actualRole]
                    );
                  }
                }}
                role="presentation"
              />
            ) : null}
          </td>
          <td className="patient-name-cell align-middle">
            {`${d.firstName || ''} ${d.lastName || ''}`}
            {d.isNew ? (
              <div className="d-inline new-tag">
                <span className="text-uppercase">{strings.new}</span>
              </div>
            ) : (
              ''
            )}
            {!d.active ? (
              <div className="d-inline inactive-tag">
                <span className="text-uppercase">{strings.inactive}</span>
              </div>
            ) : (
              ''
            )}
            {!d.active ? (
              <div className="inactive-warning">
                <span className="text-capitalize ">{d.reason}</span>
              </div>
            ) : (
              ''
            )}
            <p className="secondary-data d-sm-none">{d.email ? decryptemail(d.email) : d.email}</p>
          </td>
          <td
            id="clinic-name-providers"
            className="d-none d-sm-table-cell align-middle"
          >
            {d.providerInfo === null || d.providerInfo.length === 0
              ? ''
              : this.getProviderField(
                currentPatientList.indexOf(d),
                d.providerInfo
              )}
          </td>
          <td className="d-none d-sm-table-cell align-middle">
            {getTransmissionCell(d)}
          </td>
          <td className="d-none d-sm-table-cell">
            {getDeviceImage(d.devices, d)}
          </td>
          <td className="patient-sessions-cell align-middle">
            {getSessionsField(d.sessionPercentage)}
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td
          colSpan={`${!isMobile ? '6' : '7'}`}
          className="text-center text-capitalize"
        >
          {strings.noPatientDataAvaliable}
        </td>
      </tr>
    );
  }

  handleFlagged = (e, flag, patientId, entity) => {
    const { dispatch, match } = this.props;
    const { id } = match.params;
    let payload = Object.assign({}, this.state);
    this.excempt.forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.CLINICS.CLINIC_FLAG,
      data: {
        patientId,
        flagged: !flag,
        id,
        params: payload,
        entity
      }
    });
  };

  handleRangeChange = ({ startDate, endDate }) => {
    this.setState({ startDate, endDate, page: 1 });
    const from = startDate
      .clone()
      .startOf('month')
      .format('YYYY-MM-DD');
    const to = getEndDate(endDate).format('YYYY-MM-DD');
    this.setState({ from, to });
    this.dispatchSearch(from, to);
  };

  saveFileAsPdf = blob => {
    const { dispatch } = this.props;
    dispatch({ type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD, data: false });
    saveAs(blob, 'Batch Report.pdf');
    dispatch({ type: constants.PATIENT.RESET_PROPS_VALUES });
  };

  therapyMonthRange = () => {
    const { startDate, endDate } = this.state;
    const startingDate = startDate.clone();
    const betweenMonths = [];

    while (
      endDate > startingDate ||
      startingDate.format('M') === endDate.format('M')
    ) {
      betweenMonths.push(startingDate.clone());
      getEndDate(startingDate.add(1, 'month'));
    }
    return betweenMonths;
  };

  cancelDownload = () => {
    window.location.reload();
  };

  closeWarnMsg = () => {
    this.setState({ openPopup: false });
  };

  dispatchSearch = (from, to) => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { actualRole } = getUserData();
    let payload = Object.assign({}, this.state);
    this.excempt.forEach(element => {
      delete payload[element];
    });
    if (from && to) {
      payload = { ...payload, from, to };
    }
    dispatch({
      type: constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_REQUEST,
      id,
      payload,
      entity: searchKeyMap[actualRole]
    });
    dispatch({
      type: constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_REQUEST,
      entity: searchKeyMap[actualRole],
      data: {
        id,
        params: payload
      }
    });
  };

  onCardChange = () => {
    const {
      dispatch,
      match: {
        params: { id }
      }
    } = this.props;
    const { actualRole } = getUserData();
    let payload = Object.assign({}, this.state);
    this.excempt.forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_REQUEST,
      id,
      payload,
      entity: searchKeyMap[actualRole]
    });
  };

  getSearchString = obj => {
    const parts = [];
    Object.keys(obj).forEach(function nestedObject(element) {
      if (
        obj[element] === null ||
        element === 'filterOn' ||
        element === 'viewMore' ||
        obj[element] === ''
      )
        return;
      if (typeof obj[element] === 'object') {
        let s = `${element}=`;
        Object.keys(obj[element]).forEach(function noObject(ele) {
          s += `${ele}:${obj[element][ele]};`;
        });
        parts.push(s);
      } else {
        parts.push(`${element}=${obj[element]}`);
      }
    });

    return parts.join('&');
  };

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
    this.updateUrl(this.excempt);
  }

  async handleSorting(event) {
    const { order, sortBy } = this.state;
    const { name } = event.target;
    const orderMap = {
      asc: 'desc',
      desc: 'asc'
    };
    await this.setState({ page: 1 });
    if (sortBy !== name) {
      await this.setState({ sortBy: name });
    }
    await this.setState({ order: orderMap[order] });
    this.updateUrl();
  }

  async handleFilter(event) {
    const { name, value } = event.target;
    await this.setState({ [name]: value ? value : null, page: 1 });
    this.filterCheck();
    this.dispatchSearch();
  }

  async filterCheck() {
    const {
      patientSts,
      gender,
      deviceSts,
      transmission,
      providerId,
      ageRange
    } = this.state;
    if (
      patientSts === constants.FILTER_VALUES.ACTIVE &&
      gender === constants.FILTER_VALUES.ALL &&
      deviceSts === constants.FILTER_VALUES.ACTIVE &&
      transmission === constants.FILTER_VALUES.TRANSMITTING &&
      ageRange === constants.FILTER_VALUES.ALL &&
      (providerId === '' || providerId === null)
    ) {
      await this.setState({ filterOn: false });
    } else {
      await this.setState({ filterOn: true });
    }
  }

  generateBatchReport = () => {
    this.setState({ showDialog: true });
  };

  handleColorChange = isBlackAndWhite => {
    this.setState({ isBlackAndWhite, showDialog: false });

    const { selectedCheckBoxIds } = this.state;
    this.setState({ openPopup: true });
    if (!isEmpty(selectedCheckBoxIds)) {
      const { dispatch } = this.props;
      const { startDate, endDate } = this.state;
      const { timeZone } = getUserData();
      dispatch({
        type: constants.PATIENT.FETCH_ENHANCED_PATIENTS_OVERVIEW,
        data: {
          patientIds: this.getPatientIdsWithLastTrans(selectedCheckBoxIds),
          start: startDate,
          end: getEndDate(endDate),
          timeZone,
          extendedInfo: false
        }
      });
      dispatch({ type: constants.PATIENT.STATUS_OF_PDF_DOWNLOAD, data: true });
      dispatch({
        type: constants.PATIENT.SET_TYPE_OF_PDF,
        data: { isBlackAndWhite }
      });
    }
  };

  getPatientIdsWithLastTrans = (ids) => {
    const { associatedPatients } = this.props;
    const list = [];
    associatedPatients.forEach(patient => {
      const { userId, firstTrans } = patient;
      if (ids.includes(userId)) {
        list.push({ id: userId, firstTrans });
      }
    });
    return list;
  }

  async fetchAssociatedPatients(event) {
    const { value } = event.target;
    if (!value) {
      this.resetFilter();
    } else {
      const { pattern } = this.state;
      await this.setState({
        viewMore: '',
        pattern: value,
        type: 'simple',
        pageNo: 1,
        perPage: 10,
        transmission: constants.FILTER_VALUES.ALL,
        patientSts: constants.FILTER_VALUES.ALL,
        deviceSts: constants.FILTER_VALUES.ALL,
        gender: constants.FILTER_VALUES.ALL,
        ageRange: constants.FILTER_VALUES.ALL
      });
      if (value.trim() !== pattern.trim()) {
        this.changeSearch();
      }
    }
  }

  async handleCardChange(obj) {
    const { dispatch } = this.props;
    dispatch({ type: constants.CLINICS.ASSOCIATEDPATIENTS_TABLE_CLEAR });
    await this.setState({ page: 1, ...obj });
    this.onCardChange();
    this.clearAllSelectedCheckBoxes();
  }

  async resetFilter() {
    await this.setState({
      gender: constants.FILTER_VALUES.ALL,
      transmission: constants.FILTER_VALUES.TRANSMITTING,
      patientSts: constants.FILTER_VALUES.ACTIVE,
      providerId: null,
      ageRange: constants.FILTER_VALUES.ALL,
      deviceSts: constants.FILTER_VALUES.ACTIVE,
      pattern: '',
      page: 1
    });
    this.filterCheck();
    this.handleAll();
  }

  handleAll = () => {
    this.getActiveCard();
    this.dispatchSearch();
  };

  componentWillReceiveProps(nextProps) {
    if (
      this.props.isAllowed === true &&
      this.state.openPopup === true &&
      nextProps.isAllowed === false
    ) {
      this.setState({ openPopup: false });
    }
  }

  render() {
    const {
      pattern,
      perPage,
      page,
      isMobile,
      isBlackAndWhite,
      openPopup,
      filterOn,
      active,
      selectedCheckBoxIds,
      from,
      to
    } = this.state;
    const showWarn = isEmpty(selectedCheckBoxIds);
    const {
      clinic,
      totalAssociatedPatients,
      associatedPatients,
      totalPatients,
      match: {
        params: { id }
      },
      titanPatients,
      monarchPatients,
      visiVestPatients,
      multiDevicePatients,
      location,
      breadcrumbs,
      showSearch,
      session50,
      session80,
      session100,
      flaggedPatients,
      enhancedPatientsGroupData,
      providerFilterList,
      history
    } = this.props;

    const {
      patientsData,
      minuteGaugeGraph,
      sessionGaugeGraph,
      barCharts
    } = enhancedPatientsGroupData;
    const multiProgressTime = this.props.multiProgressTime;
    const userData = getUserData();
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: url_reverse(urls.CLINIC.DETAIL.DETAILS, { id }),
          text: strings.associatedPatients
        },
        {
          href: url_reverse(urls.CLINIC.DETAIL.INFO, { id }),
          text: strings.clinicDetails
        }
      ]
    };
    const checkBoxData = !isMobile
      ? {
        paginatedPatientIds: getPaginatedUserIds(
          this.state,
          this.props,
          constants.CLINICS
        ),
        selectedPatientIds: selectedCheckBoxIds,
        isCheckBoxRequired: true,
        selectAllCheckBoxes: this.selectAllCheckBoxes,
        deselectCheckBoxes: this.deselectCheckBoxes
      }
      : {};
    return (
      <div>
        <Header
          searchExitHandle={async () => {
            await this.setState({ pattern: '' });
            this.updateUrl(this.excempt);
            this.dispatchSearch();
          }}
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.CLINIC.ALL}
          showBack
          showBrand
          showToggle
          filterWithMenu={isMobile}
        />
        <MainWrapper>
          <SideBar
            sideBarData={sideBarData}
            filters={this.getFiltersForAssocatiedPatients({
              providerFilterList,
              ignores:
                userData.role === constants.ROLES.PROVIDER
                  ? ['Provider_Name']
                  : []
            })}
            resetFilter={this.resetFilter}
            filterOn={filterOn}
            showSearch={showSearch}
            hidden={pattern === '' ? false : true}
            filterWithMenu={isMobile}
          />
          <MainContent
            {...(pattern !== ''
              ? { styleClass: 'col-md-10 table-search-desktop' }
              : {})}
          >
            {!isEmpty(barCharts) &&
              Object.keys(barCharts).length !== 0 &&
              Object.values(barCharts)}
            {!isEmpty(minuteGaugeGraph) &&
              Object.keys(minuteGaugeGraph).length !== 0 && (
                <div style={{ display: 'none' }}>
                  {Object.values(minuteGaugeGraph)}
                </div>
              )}
            {!isEmpty(sessionGaugeGraph) &&
              Object.keys(sessionGaugeGraph).length !== 0 && (
                <div style={{ display: 'none' }}>
                  {Object.values(sessionGaugeGraph)}
                </div>
              )}
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <div className="table-header d-flex flex-wrap align-items-center">
                <h1 className="d-none d-sm-block d-md-none break-word d-inline text-capitalize">
                  {clinic.name}
                </h1>
                <h6 className="d-none d-sm-block text-capitalize">
                  {clinic.name}
                </h6>

                <Search
                  searchString={pattern}
                  fetchOnChange={this.fetchAssociatedPatients}
                  modifierClass="d-sm-inline"
                  showSearch={showSearch}
                  placeholder={strings.associatedPatientSearchPlaceholder}
                />
                <span
                  className={`${pattern !== ''
                    ? 'table-search-exit cross-icon d-md-inline-block ml-auto'
                    : 'd-none'
                    }`}
                  onClick={this.fetchAssociatedPatients}
                  onKeyPress={this.fetchAssociatedPatients}
                  tabIndex={0}
                  role="button"
                />
                {pattern === '' && !isMobile && (
                  <ButtonComponent
                    buttonClass={`${showSearch === true ? 'd-none' : 'overview-button ml-auto'
                      }`}
                    buttonAction={() => this.generateBatchReport()}
                    icon="report-detail-icon"
                    buttonText={strings.batchReport}
                    id="clinic-batchReport"
                  />
                )}
              </div>
              <h6
                className={`${pattern === '' ? 'd-none' : 'text-capitalize show-search'
                  } `}
              >{`${strings.searchResults} (${totalPatients})`}</h6>
              {pattern === '' ? (
                <div
                  className="col-md-3 text-right float-right d-inline"
                  id="date-picker"
                >
                  <RangeMonthlyPicker
                    startDate={moment(from)}
                    endDate={moment(to)}
                    onChange={this.handleRangeChange}
                  />
                </div>
              ) : null}
            </div>
            {pattern === '' ? (
              <div id="manage-patients" className="container-fluid">
                <div
                  id="top-layer"
                  className="row flex-row flex-nowrap flex-sm-wrap justify-content-space-between"
                >
                  {this.getCardComponent(
                    [
                      {
                        title: strings.totalPatients,
                        value:
                          filterOn &&
                            active === 'temp-1' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : totalAssociatedPatients,
                        id: 1,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-1',
                            type: constants.FILTER_VALUES.ALL
                          });
                        },
                        filterIcon: filterOn
                      },
                      {
                        title: strings.sessionsCompleted,
                        value:
                          filterOn &&
                            active === 'temp-2' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : session50,
                        id: 2,
                        sessionValues: strings.session1,
                        customClass: 'red-inactive-card',
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-2',
                            type: 'session50'
                          });
                        },
                        filterIcon: filterOn
                      },
                      {
                        title: strings.sessionsCompleted,
                        value:
                          filterOn &&
                            active === 'temp-3' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : session80,
                        id: 3,
                        sessionValues: strings.session2,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-3',
                            type: 'session80'
                          });
                        },
                        customClass: 'yellow-session-card',
                        filterIcon: filterOn
                      },
                      {
                        title: strings.sessionsCompleted,
                        value:
                          filterOn &&
                            active === 'temp-4' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : session100,
                        id: 4,
                        sessionValues: strings.session3,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-4',
                            type: 'session100'
                          });
                        },
                        customClass: 'green-active-card',
                        filterIcon: filterOn
                      },
                      {
                        title: strings.flaggedPatients,
                        value:
                          filterOn &&
                            active === 'temp-5' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : flaggedPatients,
                        id: 5,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-5',
                            type: 'flagged'
                          });
                        },
                        filterIcon: filterOn
                      },
                      {
                        title: strings.titanPatients,
                        value:
                          filterOn &&
                            active === 'temp-6' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : titanPatients,
                        id: 6,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-6',
                            type: 'titan'
                          });
                        },
                        filterIcon: filterOn
                      },


                      {
                        title: strings.monarchPatients,
                        value:
                          filterOn &&
                            active === 'temp-7' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : monarchPatients,
                        id: 7,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-7',
                            type: 'monarch'
                          });
                        },
                        filterIcon: filterOn
                      },
                      {
                        title: strings.visiVestPatients,
                        value:
                          filterOn &&
                            active === 'temp-8' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : visiVestPatients,
                        id: 8,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-8',
                            type: 'vest'
                          });
                        },
                        filterIcon: filterOn
                      },
                      {
                        title: strings.multiDevicePatients,
                        value:
                          filterOn &&
                            active === 'temp-9' &&
                            associatedPatients !== null
                            ? totalPatients || 0
                            : multiDevicePatients,
                        id: 9,
                        onClickHandle: () => {
                          this.handleCardChange({
                            active: 'temp-9',
                            type: 'multi'
                          });
                        },
                        filterIcon: filterOn
                      },
                    ],
                    this.state
                  )}
                </div>
              </div>
            ) : null}
            <Modal show={openPopup} onHide={this.stayWithOpen} centered>
              <Modal.Header className="justify-content-center bg-white">
                <Modal.Title className="text-dark">
                  {showWarn ? strings.WARNING : strings.DOWNLOADING}
                </Modal.Title>
              </Modal.Header>
              <Modal.Body className="mt-4 mb-4 justify-content-center">
                {showWarn ? (
                  strings.warningMessage
                ) : (
                  <ProgressBar
                    striped
                    variant="dark"
                    role="progressbar"
                    animated
                    now={multiProgressTime}
                    label={`${multiProgressTime}%`}
                    style={{ height: '2rem' }}
                  />
                )}
              </Modal.Body>
              <Modal.Footer className="justify-content-center">
                {showWarn ? (
                  <Button variant="white" onClick={this.closeWarnMsg}>
                    {strings.ok}
                  </Button>
                ) : (
                  <Button variant="white" onClick={this.cancelDownload}>
                    {strings.cancel}
                  </Button>
                )}
              </Modal.Footer>
            </Modal>
            <div>
              {pattern === '' ? (
                <div
                  className="d-flex justify-content-between"
                  id="patients-table-header"
                >
                  <h6>{this.getActiveCardName()}</h6>
                  {!isMobile && !isEmpty(selectedCheckBoxIds) && (
                    <div>
                      <span className="pr-2 align-middle text-uppercase">
                        <Badge pill className="hr-badge">
                          {selectedCheckBoxIds.length}
                        </Badge>
                        <span className="align-middle">
                          {' '}
                          {strings.selected}
                        </span>
                      </span>
                      <ButtonComponent
                        buttonClass="btn btn-outline-info"
                        noDefault
                        buttonAction={() => this.clearAllSelectedCheckBoxes()}
                        buttonText={strings.resetAll}
                      />
                    </div>
                  )}
                </div>
              ) : null}
              <TableDisplay
                heading={[
                  {
                    text: '',
                    name: 'flagged',
                    value: 'flagged'
                  },
                  {
                    text: strings.patientName,
                    sortable: true,
                    name: 'firstName',
                    value: 'firstName'
                  },
                  {
                    text: strings.providerName,
                    sortable: false,
                    name: 'providerName',
                    value: 'providerName',
                    mobile: false
                  },
                  {
                    text: strings.lastTransmission,
                    sortable: true,
                    name: 'lastTrans',
                    value: 'lastTrans',
                    mobile: false
                  },
                  {
                    text: strings.device,
                    sortable: false,
                    name: 'device',
                    value: 'device',
                    mobile: false
                  },
                  {
                    text: strings.completedSessions,
                    sortable: true,
                    name: 'sessionPercentage',
                    value: 'sessionPercentage'
                  }
                ]}
                totalUsers={totalPatients || null}
                listing={this.getPatientsBody()}
                getSearchString={this.getSearchString}
                searchDisplay
                pagination
                handlePaginate={this.handlePaginate}
                perPage={perPage}
                handleSorting={this.handleSorting}
                page={page}
                totalDisplayLabel={strings.patients}
                tableClass="clinic-patients-table"
                searchString={pattern}
                checkBoxData={checkBoxData}
                noResultFound={strings.noPatientDataAvaliable}
              />
            </div>
            <FootNote />

            {!isEmpty(patientsData) && (
              <div style={{ dispatch: 'none' }}>
                <PDFDownloadLink
                  id="pdf-dowload"
                  className="downloadlink text-uppercase"
                  document={
                    <Pdf
                      data={patientsData}
                      isBlackAndWhite={isBlackAndWhite}
                      tableRequired={false}
                    />
                  }
                  fileName="Batch Report.pdf"
                >
                  {({ blob, loading }) =>
                    loading ? '' : this.saveFileAsPdf(blob)
                  }
                </PDFDownloadLink>
              </div>
            )}
          </MainContent>
        </MainWrapper>
        <SelectColorDialog
          show={this.state.showDialog}
          handleClose={() => this.setState({ showDialog: false })}
          handleChange={this.handleColorChange}
        />
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  const {
    clinicsReducer,
    breadcrumbsReducer,
    patient,
    filterReducer
  } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    clinicHcp: clinicsReducer.clinicHcp || {},
    clinic: clinicsReducer.clinic[id] || {},
    associatedPatients: clinicsReducer.associatedPatients[id] || [],
    totalAssociatedPatients: clinicsReducer.totalAssociatedPatients[id] || 0,
    titanPatients: clinicsReducer.titanPatients[id] || 0,
    monarchPatients: clinicsReducer.monarchPatients[id] || 0,
    visiVestPatients: clinicsReducer.visiVestPatients[id] || 0,
    multiDevicePatients: clinicsReducer.multiDevicePatients[id] || 0,
    flaggedPatients: clinicsReducer.flaggedPatients[id] || 0,
    session50: clinicsReducer.session50[id] || 0,
    session80: clinicsReducer.session80[id] || 0,
    session100: clinicsReducer.session100[id] || 0,
    totalPatients: clinicsReducer.totalPatients[id] || 0,
    providerFilterList: customSort(clinicsReducer.pProviders.concat(clinicsReducer.pClinicAdmins), 'firstName', 'asc'),
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    showSearch: filterReducer.showSearch,
    enhancedPatientsGroupData: state.app.patient.patientsEnhancedOverview
      ? getEnhancedPatientsGroupData(
        state.app.patient.patientsEnhancedOverview,
        state.app.patient.isBlackAndWhite,
        true
      )
      : {},
    multiProgressTime: patient.multiProgressTime,
    isAllowed: patient.isAllowed
  };
};

export default connect(
  mapStateToProps,
  null
)(ClinicDetails);