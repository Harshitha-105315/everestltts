import constants from 'constants.js';
import { Object } from 'es6-shim';
import { setStateByKey, pinnedSort } from 'utils/helper.js';
import { getAccountExecutiveList } from './helper.jsx';

const initalState = {
  clinics: [],
  speciality: [],
  totalClinics: 0,
  clinic: {},
  clinicAdmin: {},
  clinicHcp: {},
  associatedPatients: {},
  totalPatients: 0,
  totalAssociatedPatients: {},
  titanPatients: {},
  monarchPatients: {},
  visiVestPatients: {},
  multiDevicePatients: {},
  session50: {},
  session80: {},
  session100: {},
  flaggedPatients: {},
  clinicAllAdmin: [],
  allMonthsAdherenceData: {},
  allMonthsTherapyData: {},
  pData: {},
  pUserData: {},
  pClinicAdmins: [],
  pProviders: [],
  patients: [],
  addClinicStatus: 0,
  accountExecutive: {},
  clinicList: false
};
function clinicsReducer(state = initalState, action) {
  const tmpState = Object.assign({}, state);
  switch (action.type) {
    case constants.CLINICS.SPECIALITY_SUCCESS:
      return Object.assign({}, state, { speciality: action.response });
    case constants.CLINICS.SPECIALITY_FAILURE:
      return Object.assign({}, state, { speciality: [] });
    case constants.CLINICS.CLINICS_SEARCH_SUCCESS:
      return Object.assign({}, state, {
        clinics: action.response.data,
        totalClinics: Number(action.response.headers['x-total-count']),
        clinicList: true
      });
    case constants.CLINICS.CLINIC_BYID_SUCCESS:
      tmpState.clinic = setStateByKey(
        tmpState.clinic,
        action.key,
        action.response
      );
      return tmpState;
    case constants.CLINICS.CLINIC_BYID_FAILURE:
      tmpState.clinic = setStateByKey(tmpState.clinic, action.key, {});
      return tmpState;
    case constants.CLINICS.CLINIC_ADMIN_SUCCESS:
      tmpState.clinicAdmin = setStateByKey(
        tmpState.clinicAdmin,
        action.key,
        action.response
      );
      tmpState.pClinicAdmins = action.response;
      return tmpState;
    case constants.CLINICS.CLINIC_ADMIN_FAILURE:
      tmpState.clinicAdmin = setStateByKey(
        tmpState.clinicAdmin,
        action.key,
        []
      );
      return tmpState;
    case constants.CLINICS.CLINIC_HCP_SUCCESS:
      tmpState.clinicHcp = setStateByKey(
        tmpState.clinicHcp,
        action.key,
        action.response
      );
      tmpState.pProviders = action.response
      return tmpState;
    case constants.CLINICS.CLINIC_HCP_FAILURE:
      tmpState.clinicHcp = setStateByKey(tmpState.clinicHcp, action.key, []);
      return tmpState;
    case constants.CLINICS.ASSOCIATEDPATIENT_SEARCH_SUCCESS:
      if (action.response.data.results === null) {
        tmpState.associatedPatients = setStateByKey(
          tmpState.associatedPatients,
          action.key,
          []
        );
        tmpState.totalPatients = setStateByKey(
          tmpState.totalPatients,
          action.key,
          null
        );
        return tmpState;
      }
      tmpState.associatedPatients = setStateByKey(
        tmpState.associatedPatients,
        action.key,
        pinnedSort(
          action.response.data.results.map((element, index) => {
            return Object.assign({}, element.patientInfo, {
              providerInfo: element.providerInfo
            });
          })
        )
      );
      tmpState.totalPatients = setStateByKey(
        tmpState.totalPatients,
        action.key,
        action.response.data.totalCnt || null
      );
      return tmpState;
    case constants.CLINICS.CLINICS_ALL_SUCCESS:
      return Object.assign({}, state, {
        clinics: action.response.data,
        totalClinics: action.response.headers['x-total-count']
      });
    case constants.CLINICS.CLINICS_ALL_FAILURE:
      return Object.assign({}, state, {
        clinics: [],
        totalClinics: 0
      });
    case constants.CLINICS.ASSOCIATE_PROVIDER_SUCCESS:
      tmpState.clinicHcp = setStateByKey(
        tmpState.clinicHcp,
        action.key,
        action.response.hcpUsers
      );
      return tmpState;
    case constants.CLINICS.CLINIC_ADMINS_SUCCESS:
      return Object.assign({}, state, { clinicAllAdmin: action.response });
    case constants.CLINICS.CLINIC_ADMINS_FAILURE:
      return Object.assign({}, state, { clinicAllAdmin: [] });
    case constants.CLINICS.UPDATE_CLINIC_SUCCESS:
      tmpState.clinic = setStateByKey(
        tmpState.clinic,
        action.key,
        action.response
      );
      return tmpState;
    case constants.CLINICS.UPDATE_CLINIC_INFO:
      tmpState.clinic = {
        ...tmpState.clinic,
        [action.key]: {
          ...tmpState.clinic[action.key],
          ...action.response
        }
      };
      return tmpState;
    case constants.CLINICS.ASSOCIATEDPATIENTS_CARDS_SUCCESS:
      tmpState.flaggedPatients = setStateByKey(
        tmpState.flaggedPatients,
        action.key,
        action.response.flagged_patients.count
      );
      tmpState.titanPatients = setStateByKey(
        tmpState.titanPatients,
        action.key,
        action.response.titan_patients.count
      );
      tmpState.monarchPatients = setStateByKey(
        tmpState.monarchPatients,
        action.key,
        action.response.monarch_patients.count
      );
      tmpState.multiDevicePatients = setStateByKey(
        tmpState.multiDevicePatients,
        action.key,
        action.response.multi_device_patients.count
      );
      tmpState.totalAssociatedPatients = setStateByKey(
        tmpState.totalAssociatedPatients,
        action.key,
        action.response.total_patients.count
      );
      tmpState.visiVestPatients = setStateByKey(
        tmpState.visiVestPatients,
        action.key,
        action.response.vest_patients.count
      );
      tmpState.session50 = setStateByKey(
        tmpState.session50,
        action.key,
        action.response.session50.count
      );
      tmpState.session80 = setStateByKey(
        tmpState.session50,
        action.key,
        action.response.session80.count
      );
      tmpState.session100 = setStateByKey(
        tmpState.session100,
        action.key,
        action.response.session100.count
      );
      return tmpState;
    case constants.CLINICS.ASSOCIATEDPATIENTS_TABLE_CLEAR:
      tmpState.associatedPatients = {};
      return tmpState;
    case constants.CLINICS.FLAG_CLINIC_SUCCESS:
      tmpState.associatedPatients = setStateByKey(
        tmpState.associatedPatients,
        action.data.id,
        tmpState.associatedPatients[action.data.id].map(element => {
          const tempPatient = { ...element };
          if (tempPatient.patientId === action.data.patientId) {
            tempPatient.flagged = action.data.flagged;
          }
          return tempPatient;
        })
      );
      return tmpState;
    case constants.CLINICS.ACCOUNT_EXECUTIVE_LIST_SUCCESS:
      tmpState.accountExecutive = setStateByKey(
        tmpState.accountExecutive,
        action.key,
        getAccountExecutiveList(action.response)
      );
      return tmpState;
    default:
      return state;
  }
}
export default clinicsReducer;