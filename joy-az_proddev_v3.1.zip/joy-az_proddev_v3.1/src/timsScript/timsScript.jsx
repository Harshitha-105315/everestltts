/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Header, SideBar } from 'components/Navigation';
import DatePicker from 'react-datepicker';
import DatePickerCustomInput from 'components/DatePickerCustomInput';
import constants from 'constants.js';
import strings from 'localization/strings';
import TableDisplay from 'components/TableDisplay';
import { isEmpty } from 'lodash';
import { Form } from 'react-bootstrap';
import { uid } from 'react-uid';
import './timsScript.scss';
import { FootNote } from 'components/FootNote';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { getLastDate, selectPreviousMonth } from 'utils/helper';

class TimsScript extends Component {
  constructor(props) {
    super(props);
    this.state = {
      page: 1,
      perPage: 10,
      sortBy: 'date',
      asc: false,
      status: 'All',
      success: true,
      failed: true,
      timsContents: [],
      fromDate: selectPreviousMonth(new Date(), constants.DEFAULT_MONTH_RANGE),
      toDate: getLastDate(new Date())
    };
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleSorting = this.handleSorting.bind(this);
  }

  componentWillMount() {
    this.dispatchForTimsScript();
  }

  componentWillReceiveProps(newProps) {
    const { timsScriptContents } = newProps;
    if (timsScriptContents !== undefined) {
      this.setState({ timsContents: timsScriptContents });
    }
  }

  dispatchForTimsScript = () => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.TIMSSCRIPT.TIMSSCRIPT_REQUEST,
      payload: this.state
    });
  };

  handleChangeToDate = date => {
    this.setState({ toDate: date }, () => {
      this.dispatchForTimsScript();
    });
  };

  handleChangeFromDate = date => {
    this.setState({ fromDate: date }, () => {
      this.dispatchForTimsScript();
    });
  };

  handleSuccessClick = () => {
    const { success } = this.state;
    this.setState({ success: !success }, () => {
      this.handleSuccessFilter();
    });
  };

  handleSuccessFilter = () => {
    const { failed, success } = this.state;

    if (failed === true && success === false) {
      this.setState({ status: 'Failure' }, () => {
        this.dispatchForTimsScript();
      });
    } else if (failed === false && success === true) {
      this.setState({ status: 'Success' }, () => {
        this.dispatchForTimsScript();
      });
    } else {
      this.setState({ status: 'ALL' }, () => {
        this.dispatchForTimsScript();
      });
    }
  };

  handleFailedClick = () => {
    const { failed } = this.state;
    this.setState({ failed: !failed }, () => {
      this.handleFailureFilter();
    });
  };

  handleFailureFilter = () => {
    const { failed, success } = this.state;

    if (failed === true && success === false) {
      this.setState({ status: 'Failure' }, () => {
        this.dispatchForTimsScript();
      });
    } else if (failed === false && success === true) {
      this.setState({ status: 'Success' }, () => {
        this.dispatchForTimsScript();
      });
    } else {
      this.setState({ status: 'ALL' }, () => {
        this.dispatchForTimsScript();
      });
    }
  };

  getActiveDate = date => {
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    const activedate = new Date(date);
    const date1 = activedate.getDate();
    const month = monthNames[activedate.getMonth()];
    const year = activedate.getFullYear();
    return ` ${date1} ${month}, ${year}`;
  };

  downloadLogFile = (e, timsContent) => {
    e.preventDefault();
    const { dispatch } = this.props;
    dispatch({
      type: constants.TIMSSCRIPT.TIMSSCRIPT_LOG_DETAILS,
      data: timsContent.file
    });
  };

  listTimsContents = () => {
    const { timsContents } = this.state;
    if (!isEmpty(timsContents)) {
      return timsContents.map(s => (
        <tr key={uid(s)}>
          <td id="tims-script-date">{this.getActiveDate(s.lastMod)}</td>
          <td id="tims-script-status">{s.status}</td>
          <td id="tims-script-log">
            <span
              onClick={e => this.downloadLogFile(e, s)}
              className="text-dark"
            >
              {s.file}
            </span>
          </td>
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="3" className="text-center">
          {strings.noTimsScript}
        </td>
      </tr>
    );
  };

  paginationSet = (name, value) => {
    this.setState({ [name]: value });
  };

  async handlePaginate(pageNumber) {
    await this.paginationSet('page', pageNumber);
    this.dispatchForTimsScript();
  }

  async handleSorting() {
    const { asc } = this.state;
    await this.setState({ asc: !asc });
    this.dispatchForTimsScript();
  }

  render() {
    const { location, timsScripts } = this.props;
    const { page, perPage, failed, success, fromDate, toDate } = this.state;

    const listScript = this.listTimsContents();

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.TIMS.SCRIPT, text: strings.timsScript },
        { href: urls.TIMS.EXECUTE, text: strings.executeJob }
      ]
    };
    return (
      <div>
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div className="row tims-script">
              <div>
                <h2 className="text-capitalize">{strings.logInformation}</h2>
              </div>
              <div className="ml-auto">
                <div className="d-flex flex-row justify-content-end">
                  <div className="p-2">
                    <Form.Check
                      custom
                      type="checkbox"
                      label={strings.success}
                      id="checkbox-success"
                      checked={success}
                      name="success"
                      onChange={this.handleSuccessClick}
                      inline
                    />
                  </div>
                  <div className="p-2">
                    <Form.Check
                      custom
                      id="checkbox-failed"
                      type="checkbox"
                      label={strings.failed}
                      name="failed"
                      checked={failed}
                      onChange={this.handleFailedClick}
                      inline
                    />
                  </div>
                  <div className="py-2 pl-2 pr-0">
                    <div className="d-flex flex-row">
                      <div>
                        <DatePicker
                          customInput={<DatePickerCustomInput />}
                          name="adherenceStartDate"
                          maxDate={new Date()}
                          dateFormat="MMM d, yyyy"
                          selected={fromDate}
                          onChange={this.handleChangeFromDate}
                          placeholderText={strings.selectDate}
                        />
                      </div>
                      <div className="custom-selection-seperator px-2 text-uppercase">
                        {strings.to}
                      </div>
                      <div>
                        <DatePicker
                          customInput={<DatePickerCustomInput />}
                          name="adherenceEndDate"
                          minDate={fromDate}
                          maxDate={new Date()}
                          dateFormat="MMM d, yyyy"
                          popperPlacement="bottom"
                          popperModifiers={{
                            flip: {
                              behavior: ['bottom'] // don't allow it to flip to be above
                            },
                            preventOverflow: {
                              enabled: false
                            },
                            hide: {
                              enabled: false // turn off since needs preventOverflow to be enabled
                            }
                          }}
                          selected={toDate}
                          onChange={this.handleChangeToDate}
                          placeholderText={strings.selectDate}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <TableDisplay
                heading={[
                  {
                    text: strings.date,
                    sortable: true,
                    name: 'date',
                    value: 'date'
                  },
                  {
                    text: strings.logStatus,
                    name: 'logStatus',
                    value: 'logStatus'
                  },
                  {
                    text: strings.logLink,
                    name: 'logLink',
                    value: 'logLink'
                  }
                ]}
                listing={listScript}
                handlePaginate={this.handlePaginate}
                perPage={perPage}
                page={page}
                totalDisplayLabel={strings.logRecords}
                totalUsers={
                  timsScripts !== undefined && timsScripts.totalElements
                }
                handleSorting={this.handleSorting}
                pagination
              />
            </div>
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    timsScriptContents: state.app.TimsScriptReducer.timsScriptContents,
    timsScripts: state.app.TimsScriptReducer.timsScripts
  };
};

export default connect(
  mapStateToProps,
  null
)(TimsScript);
