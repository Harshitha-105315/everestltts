import constants from 'constants.js';

const intialState = {
  timsScriptContents: [],
  totalLog: 0,
  logDetails: {},
  message: ''
};
function TimsScriptReducer(state = intialState, action) {
  switch (action.type) {
    case constants.TIMSSCRIPT.TIMSSCRIPT_REQUEST_SUCCESS:
      return Object.assign({}, state, {
        timsScriptContents: action.contents,
        timsScripts: action.timsScripts
      });
    case constants.TIMSSCRIPT.TIMSSCRIPT_LOG_DETAILS_SUCCESS:
      return Object.assign({}, state, {
        logDetails: action.data
      });
    case constants.TIMSSCRIPT.TIMSSCRIPT_EXECUTE_JOB_SUCCESS:
      return Object.assign({}, state, {
        message: action.message
      });
    default:
      return state;
  }
}
export default TimsScriptReducer;
