import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function getTimsScriptService(payload) {
  const date = new Date(payload.fromDate);
  const fromDate = `${date.getMonth() +
    1}/${date.getDate()}/${date.getFullYear()}`;

  const toDate = `${payload.toDate.getMonth() +
    1}/${payload.toDate.getDate()}/${payload.toDate.getFullYear()}`;
  const url = API.TIMSSCRIPT;
  return authRequest({
    url: `${url}?page=${payload.page}&per_page=${payload.perPage}&sort_by=${
      payload.sortBy
      }&asc=${payload.asc}&status=${
      payload.status
      }&fromDate=${fromDate}&toDate=${toDate}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getTimsLogDetailsService(payload) {
  return authRequest({
    url: API.TIMSLOGDETAILS,
    method: 'POST',
    data: { logfilePath: `/usr/tomcat/apache-tomcat-8.0.28/TIMS/logs/${payload}` },
    [constants.RETURNRESPONSE]: true
  });
}

function executeJobService(payload) {
  return authRequest({
    url: API.EXECUTEJOB,
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

const TimsScriptService = {
  getTimsScriptService,
  getTimsLogDetailsService,
  executeJobService
};
export default TimsScriptService;
