import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Form } from 'react-bootstrap';
import { Header, SideBar } from 'components/Navigation';
import { FootNote } from 'components/FootNote';
import ConfirmationDialog from 'components/ConfirmationDialog';
import strings from 'localization/strings';
import constants from 'constants.js';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import ButtonComponent from 'components/ButtonComponent';
import MainWrapper from 'components/MainWrapperDisplay';

class ExecuteJob extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        },
        formDataVal: null
      }
    };
    this.handleContinue = this.handleContinue.bind(this);
  }

  handleContinue = () => {
    const { dispatch } = this.props;
    const { dialog, formDataVal } = this.state;
    dispatch({
      type: constants.TIMSSCRIPT.TIMSSCRIPT_EXECUTE_JOB,
      payload: formDataVal
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  executeJob = () => {
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        title: strings.timsScriptExecution,
        body: strings.executeJobProcess,
        button: strings.execute,
        show: true,
        confirmFunction: this.handleContinue
      })
    });
  };

  selectCSVFile = event => {
    const formDataVal = new FormData();
    formDataVal.append(
      'uploadfile',
      event.target.files[0],
      event.target.files[0].name
    );
    this.setState({ formDataVal });
  };

  clearCSVFile = event => {
    event.target.value = '';
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.message) {
      this.setState({ formDataVal: null });
    }
  }

  render() {
    const { location } = this.props;
    const { dialog, formDataVal } = this.state;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.TIMS.SCRIPT, text: strings.timsScript },
        { href: urls.TIMS.EXECUTE, text: strings.executeJob }
      ]
    };

    const file = formDataVal && formDataVal.get('uploadfile');
    const filename = file && file.name;

    return (
      <div>
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div>
              <h2 className="text-capitalize">{strings.executeJob}</h2>
              <Form>
                <Form.Row className="align-items-center">
                  <Form.Group>
                    <Form.Label
                      htmlFor="tim-script-file-upload"
                      id="tim-script-file-upload-label"
                    >
                      <ButtonComponent
                        icon="report-detail-icon"
                        buttonText={strings.selectCSVFile}
                      />
                    </Form.Label>

                    <input
                      type="file"
                      id="tim-script-file-upload"
                      ref={input => {
                        this.filesInput = input;
                      }}
                      placeholder={strings.onlyCSV}
                      accept=".csv"
                      name="upload-csv-file"
                      onChange={this.selectCSVFile}
                      onClick={this.clearCSVFile}
                    />
                    <span>{filename}</span>
                  </Form.Group>
                </Form.Row>
              </Form>
              {formDataVal ? (
                <Fragment>
                  <p>{strings.executeTims}</p>
                  <div>
                    <ButtonComponent
                      id="execute-continue"
                      buttonClass="float-left"
                      buttonAction={() => this.executeJob()}
                      icon="report-detail-icon"
                      buttonText={strings.continue}
                    />
                  </div>
                </Fragment>
              ) : null}
            </div>
            <FootNote />
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.app.TimsScriptReducer.message
  };
};

export default connect(
  mapStateToProps,
  null
)(ExecuteJob);
