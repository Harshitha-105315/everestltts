import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Header, SideBar } from 'components/Navigation';
import strings from 'localization/strings';
import { filter } from 'lodash';
import constants from 'constants.js';
import { Form } from 'react-bootstrap';
import urls from 'urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';

class TimsLogDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      logFileContent: ''
    };
  }

  componentWillMount() {
    this.getLogDetails();
  }

  componentWillReceiveProps(newProps) {
    const { logDetails } = newProps;
    if (logDetails !== undefined) {
      this.setState({ logFileContent: logDetails.logFileContent });
    }
  }

  getLogDetails() {
    const { match, location, dispatch } = this.props;
    const { file } = match.params;
    const timsContentsList = location.state.timsContents;
    const timsContent = filter(timsContentsList, ['file', file]);

    if (timsContent !== undefined) {
      dispatch({
        type: constants.TIMSSCRIPT.TIMSSCRIPT_LOG_DETAILS,
        data: timsContent[0].path
      });
    }
  }

  render() {
    const { location, logDetails } = this.props;
    const { logFileContent } = this.state;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        { href: urls.TIMS.SCRIPT, text: strings.timsScript },
        { href: urls.TIMS.EXECUTE, text: strings.executeJob }
      ]
    };
    return (
      <div>
        <Header />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            <div>
              <h2 className="text-capitalize">{strings.timScriptLogDetails}</h2>
              <div>
                {logDetails !== undefined && (
                  <Form.Control
                    as="textarea"
                    readOnly
                    value={logFileContent}
                    rows="20"
                  />
                )}
              </div>
            </div>
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    logDetails: state.app.TimsScriptReducer.logDetails
  };
};

export default connect(
  mapStateToProps,
  null
)(TimsLogDetails);
