import { saveAs } from 'file-saver';

export function downloadFile(name, content) {
	const file = new Blob([content], { type: 'text/plain' });
	saveAs(file, name);
}
