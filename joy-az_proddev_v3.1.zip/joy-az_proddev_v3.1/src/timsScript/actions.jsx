import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import TimsScriptService from './services';
import { downloadFile } from './helper';

function* getTimsScript(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      TimsScriptService.getTimsScriptService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.TIMSSCRIPT.TIMSSCRIPT_REQUEST_SUCCESS,
        contents: response.data.content,
        timsScripts: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getTimsLogDetails(action) {
  try {
    const { data } = action;
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      TimsScriptService.getTimsLogDetailsService,
      data
    );
    if (response && (response.status === 200 || response.status === 201)) {
      downloadFile(data, response.data.logFileContent);
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* executeJob(action) {
  try {
    const { payload } = action;
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(TimsScriptService.executeJobService, payload);
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.ALERT.CUSTOM,
        response: { message: response.data.timsMsg, path: false },
      });
      yield put({
        type: constants.TIMSSCRIPT.TIMSSCRIPT_EXECUTE_JOB_SUCCESS,
        message: response.data.timsMsg
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const TimsScriptAction = {
  getTimsScript,
  getTimsLogDetails,
  executeJob
};
export default TimsScriptAction;
