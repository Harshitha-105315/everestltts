import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function getTherapySettingData() {
    return authRequest({
        url: API.THERAPYSETTINGDATA,
        method: 'POST',
        data: { body: 'device_model_type=Hillrom_Titan&devSN=W999VA0001&request_id=1&command=TITAN_GET_THERAPY_SETTINGS&command_param=0&crc=1234' },
        [constants.RETURNRESPONSE]: true
    });
}

function updateTherapySettingData(payload, id) {
    return authRequest({
        url: API.UPDATETHERAPYSETTING,
        method: 'PUT',
        data: payload,
        [constants.RETURNRESPONSE]: true
    });
}

const TherapySettingService = {
    getTherapySettingData,
    updateTherapySettingData
}
export default TherapySettingService;
