import React, { Component } from 'react';
import { Header, SideBar } from 'components/Navigation';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import strings from 'localization/strings';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { reverse } from 'named-urls';
import constants from 'constants.js';
import { isEmpty, findLastIndex } from 'lodash';
import urls from 'urls';
import ConfirmationDialog from 'components/ConfirmationDialog';

class TherapySetting extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      therapySettingData: {
        therapySetting: '',
        result:'',
        requestId:'',
        recordId:'',
      },
      updateRequest:false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            resetSelect: true,
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    }
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this)
    this.handleSetCheckBox = this.handleSetCheckBox.bind(this);
  };

  componentWillMount() {
    const { dispatch } = this.props;
    // const { actualRole, role } = getUserData();
    // const timezoneProfile = accessMatrix.TIMEZONE_PROFILE[actualRole];
    // const clinicListProfile = accessMatrix.CLINIC_LIST_PROFILE[actualRole];

    dispatch({
      type: constants.THERAPY_SETTING
    });
  }

  componentWillReceiveProps(newProps) {
    if (!isEmpty(newProps.therapySetting)) {
      this.setState({ therapySettingData: newProps.therapySetting });
    }
  }

  submit = () => {
    const { match, dispatch } = this.props;
    const { id } = match.params;
    const { dialog } = this.state;
    const payload = Object.assign({}, this.state.therapySettingData);
    ['error', 'isDirty'].forEach(element => {
      delete payload[element];
    });
    dispatch({
      type: constants.UPDATE_THERAPY_SETTING,
      payload
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      }),
      isDirty: false
    });
  };

  handleSubmit() {
    const {
      // reqid,
      // recordId,
      // therapySetting,
      dialog
    } = this.state;
    this.setState({ submitted: true });
    if (this.state.therapySettingData.requestId === '' || this.state.therapySettingData.requestId === null) {
      this.setState({ error: "Pealse enter REQUEST ID" });
    } else if (this.state.therapySettingData.recordId === '' || this.state.therapySettingData.recordId === null) {
      this.setState({ error: "Please enter Record Id" });
    } else if (this.state.therapySettingData.therapySetting === '' || this.state.therapySettingData.therapySetting === null) {
      this.setState({ error: "Please enter Therapy Setting" });
    } else {
      this.setState({
        dialog: Object.assign(dialog, {
          body: "Update therapy setting details?",
          title: "Update Therapy Setting",
          button: "UPDATE THERAPY SETTING",
          confirmFunction: this.submit,
          show: true
        })
      });
    }
  }

  handleChange = event => {
    let data = {...this.state.therapySettingData};
    if(event.target.name === "requestId"){
      this.state.therapySettingData.requestId = event.target.value;
    }else if(event.target.name === "result"){
      this.state.therapySettingData.result = event.target.value;
    }else if(event.target.name === "recordId"){
      this.state.therapySettingData.recordId = event.target.value;
    }else{
      this.state.therapySettingData.therapySetting= event.target.value;
    }
    this.setState({data});
  };

  handleSetCheckBox(event){
    if(event.target.checked === true){
      this.setState({ updateRequest: true });
    } else{
      this.setState({ updateRequest: false });
    }    
  }

  render() {
    const { location } = this.props;
    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.THERAPYSETTING),
          text: 'Therapy Setting'
        }
      ]
    };

    const { isMobile, dialog } = this.state;
    const { therapySetting, result, requestId, recordId} = this.state.therapySettingData;

    return (
      <div>
        <Header
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          showBack={false}
          showToggle
          showBrand
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>

            <Form style={{ marginBottom: '1.85rem' }}>               
              <Form.Group as={Col} md={12} style={{ marginBottom: '0.75rem' }}>
                <Form.Label>REQUEST ID <span className="asterisk-color"></span></Form.Label>
                <FormControlComponent
                  className="request_input"
                  type="text"
                  value={requestId}
                  name="requestId"
                  onChange={this.handleChange}
                  readOnly= {!this.state.updateRequest}
                />
              </Form.Group>
              <Form.Check
                custom
                className="filter-checkbox"
                id="request_checkbox"
                type="checkbox"                
                name="requestCheckbox"
                value="request_checkbox"                
                onChange={this.handleSetCheckBox}
                inline
                label="Enable to edit"
              />              
            </Form>
            <Form>
              <Form.Group as={Col} md={12}>
                <Form.Label>RESULT</Form.Label>
                <FormControlComponent
                  type="text"
                  value={result}
                  name="result"                  
                  isEditable="true"
                  onChange={this.handleChange}                
                />
              </Form.Group>
            </Form>
            <Form>
              <Form.Group as={Col} md={12}>
                <Form.Label>RECORD ID</Form.Label>
                <FormControlComponent
                  type="text"
                  value={recordId}
                  name="recordId"
                  // onChange={this.handleChange}
                  readOnly="true"
                  isEditable="true"
                />
              </Form.Group>
            </Form>

            <Form className="therapy-setting-input" style={{ minHeight: '90px !important' }} >
              <Form.Group as={Col} md={12}>
                <Form.Label>THERAPY SETTING</Form.Label>
                <Form.Control
                  name="therapySetting"
                  as="textarea"
                  value={therapySetting}
                  rows="2"
                  onChange={this.handleChange}
                  isEditable="true"                
                />
              </Form.Group>
            </Form>

            <ButtonComponent
              id="save-therapy-setting-bottom"
              buttonClass="float-right mb-5"
              buttonAction={this.handleSubmit}
              icon="update-icon"
              buttonText="Update"
            />

          </MainContent>

        </MainWrapper>


        <ConfirmationDialog
          show={dialog.show}
          handleClose={dialog.handleClose}
          body={dialog.body}
          title={dialog.title}
          button={dialog.button}
          confirmFunction={dialog.confirmFunction}
        />

      </div >

    );
  }
}
const mapStateToProps = state => {
  const { therapySettingReducer } = state.app;
  return {
    therapySetting: therapySettingReducer.therapySettingData,
  };
};

export default connect(
  mapStateToProps,
  null
)(TherapySetting);

