import constants from 'constants.js';

const initialState = {
    therapySettingData: {},
}

function therapySettingReducer(state = initialState, action) {
    const tmpState = Object.assign({}, state);
    if (action.type === constants.THERAPYSETTING_SUCCESS) {
        tmpState.therapySettingData = action.response;
        return tmpState;
    }
    return state;
}

export default therapySettingReducer;
