import { put, call } from 'redux-saga/effects';
import constants from 'constants.js';
import TherapySettingService from './services';
import strings from 'localization/strings';

export function* fetchTherapySetting(action) {
    try {
        yield put({ type: constants.SHOW_LOADER, payload: true });
        const response = yield call(
            TherapySettingService.getTherapySettingData
        );
        if (response && (response.status === 200 || response.status === 201)) {
            yield put({
                type: constants.THERAPYSETTING_SUCCESS,
                response: response.data
            });
        } else {
            throw Object({
                custom_message: response.data.ERROR || response.data.error
            });
        }
    } catch (response) {
        yield put({
            type: constants.ALERT.FAILURE_RESPONSE,
            response: { message: response.custom_message, isScrollNotRequired: true }
        });
        yield put({ type: constants.THERAPYSETTING_FAILURE });
    } finally {
        yield put({ type: constants.SHOW_LOADER, payload: false });
    }
}

export function* updateTherapySetting(action) {
    try {
        yield put({ type: constants.SHOW_LOADER, payload: true });
        const response = yield call(
            TherapySettingService.updateTherapySettingData,
            action.payload,
            action.id
        );
        if (response.status === 200) {
            yield put({
              type: constants.ALERT.UPDATE_SUCCESS_RESPONSE
            });
            const response = yield call(
                TherapySettingService.getTherapySettingData
            );
          } else {
            yield put({
              type: constants.ALERT.FAILURE_RESPONSE,
              response: response.data.ERROR
            });
        }
    } catch (response) {
        yield put({
          type: constants.ALERT.FAILURE_RESPONSE,
          response: strings.internalServerError
        });
      } finally {
        yield put({ type: constants.SHOW_LOADER, payload: false });
      }
}

export default fetchTherapySetting;
