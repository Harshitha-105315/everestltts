import constants from 'constants.js';

const intialState = {
  response: '',
  toRegister: false,
  loggedin: false,
  error: ''
};
function loginReducer(state = intialState, action) {
  switch (action.type) {
    case constants.LOGIN.LOGIN_SUCCESS:
      return Object.assign({}, state, {
        response: action.response,
        toRegister: false,
        loggedin: true,
        error: ''
      });
    case constants.LOGIN.LOGIN_FAILURE:
      return Object.assign({}, state, {
        response: action.response,
        toRegister: false,
        loggedin: false,
        error: action.response.Error
      });
    case constants.LOGIN.REGISTER_REQUEST:
      return Object.assign({}, state, {
        response: action.response,
        toRegister: true,
        loggedin: false,
        error: action.response.Error
      });
    case constants.LOGIN.REGISTER_CLEAR:
      return Object.assign({}, state, {
        toRegister: false,
        loggedin: false,
        error: ''
      });
    case constants.LOGIN.LOGIN_CLEAR:
      return Object.assign({}, state, { loggedin: false, error: '' });
    case constants.LOGIN.RESET_ERROR:
      return Object.assign({}, state, { error: '' });
    default:
      return state;
  }
}
export default loginReducer;
