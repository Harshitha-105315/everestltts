import React, { Component } from 'react';
import { Redirect, Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { Form, Button } from 'react-bootstrap';
import constants from 'constants.js';
import LoginShell from 'components/LoginShell';
import strings from 'localization/strings';
import reportValidity from 'report-validity';
import Activation from '../activation/Activation';
import SecurityQuestions from '../activation/SecurityQuestions';
import { getToken } from 'utils/helper';
import './login.scss';
import urls from 'urls';

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      submitted: false,
      error: '',
      clicks: 0,
    };
    this.form = React.createRef();
  }

  componentWillReceiveProps(newProps) {
    const { error } = this.state;
    this.setState({ clicks: newProps.response.Attempts });
    if (error !== newProps.error) {
      this.setState({ error: newProps.error });
    }
  }

  resetError = () => {
    const { dispatch } = this.props;
    dispatch({
      type: constants.LOGIN.RESET_ERROR
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.setState({ clicks: this.state.clicks + 1, submitted: true });
    if (this.validate()) {
      const { dispatch } = this.props;
      const { email, password } = this.state;
      dispatch({
        type: constants.LOGIN.LOGIN_REQUEST,
        payload: { username: email, password }
      });
    }
  };

  handleChange = event => {
    const { error } = this.state;
    if (error !== '') {
      this.setState({ error: '' });
    }
    this.setState({ [event.target.name]: event.target.value });
  };

  validate = () => {
    return reportValidity(this.form.current);
  };

  render() {
    const {
      toRegister,
      loggedin,
      register,
      location: { pathname },
      response: { token, ERROR, Attempts },
      APP_CODE,
      dispatch,
      history,
      questions,
      registered,
      activateMessage
    } = this.props;
    const { email, password, submitted, error } = this.state;
    if (constants.STATIC_PAGES.includes(window.location.pathname)) {
      return <Redirect to={window.location.pathname} />;
    }
    if (
      toRegister ||
      (window.location.search &&
        (window.location.pathname === urls.AUTHENTICATE ||
          window.location.pathname === urls.RESETPASSWORD))
    ) {
      return (
        <Activation
          response={{ authToken: token, email }}
          dispatch={dispatch}
          APP_CODE={APP_CODE}
          history={history}
          activateReducer={{ questions, registered, activateMessage }}
          location={window.location}
        ></Activation>
      );
    } else {
      if (loggedin || getToken()) {
        return <Redirect from={pathname} to={urls.LANDING} />;
      }
      return (
        <LoginShell
          below_form_content={
            <div id="links-block">
              <div className="secondary-link text-center">
                <p>
                  {register
                    ? strings.alreadyRegistered
                    : strings.dontHaveAccount}
                </p>
              </div>
              <div className="primary-link text-center" id="register-link">
                {register ? (
                  <Link
                    to={urls.LANDING}
                    onClick={() => {
                      this.setState({ error: '' });
                    }}
                  >
                    {strings.loginWith}
                  </Link>
                ) : (
                  <Link
                    to={urls.REGISTER}
                    onClick={() => {
                      this.setState({ error: '' });
                    }}
                  >
                    {strings.registerWith}
                  </Link>
                )}
              </div>
            </div>
          }
        >
          <h1 className="text-white text-left">
            {register ? strings.register : strings.login}
          </h1>
          <Form
            className={`form-inverse${submitted ? ' submitted' : ''}`}
            method="POST"
            onSubmit={this.handleSubmit}
            ref={this.form}
          >
            <Form.Group>
              <Form.Label className="text-light">
                {strings.hillromIDEmail}
              </Form.Label>
              <Form.Control
                className="input-field"
                type="text"
                name="email"
                value={email}
                required
                onChange={this.handleChange}
                disabled={this.state.clicks === 5 && Attempts === 5 ? true : false}
              />
            </Form.Group>
            <Form.Group className="password">
              <Form.Label className="text-light">{strings.password}</Form.Label>
              <Form.Control
                className="input-field"
                type="password"
                name="password"
                required
                value={password}
                onChange={this.handleChange}
                disabled={this.state.clicks === 5 && Attempts === 5 ? true : false}
              />
            </Form.Group>
            <p id="error" className={`landing-error ${this.state.clicks === 5 ? 'attempts_reach' : ''}`}>{ERROR}</p>
            {register || (
              <div id="forgot">
                <Link id="forgot-password" to="/reset-password">
                  {strings.forgotPassword}
                </Link>
              </div>
            )}
            <Button
              id="login-button"
              className="mx-auto"
              variant="primary"
              size="lg"
              type="submit"
              onClick={this.handleSubmit}
              block
              disabled={this.state.clicks === 5 && Attempts === 5 ? true : false}
            >
              {register ? strings.continue : strings.login}
            </Button>
          </Form>
        </LoginShell>
      );
    }
  }
}
const mapStateToProps = state => {
  const { loginReducer, activateReducer } = state.app;
  return {
    response: loginReducer.response,
    message: loginReducer.message,
    toRegister: loginReducer.toRegister,
    loggedin: loginReducer.loggedin,
    error: loginReducer.error,
    APP_CODE: loginReducer.response.APP_CODE,
    questions: activateReducer.question,
    registered: activateReducer.registered,
    activateMessage: activateReducer.message
  };
};
export default connect(
  mapStateToProps,
  null
)(Login, Activation, SecurityQuestions);
