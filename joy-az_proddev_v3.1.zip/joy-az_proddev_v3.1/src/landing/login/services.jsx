import { request } from 'utils/axios_utils';
import API from 'api/api_config';

function loginResponse(payload) {
  return request({
    url: API.AUTHENTICATE,
    method: 'POST',
    data: payload,
    'x-response': true,
    headers: { "Content-Type": "text/plain" }
  });
}
export default loginResponse;
