import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import roleMap from 'rolesData/roleMapping';
import loginResponse from './services';
import { getIVSalt, createEncryptedData } from 'utils/utltity';
import strings from 'localization/strings';
import { decryptdata, encryptdata, decryptemail } from '../../Cryptocode';

var AesUtil = require('utils/AesUtil');

function* loginUser(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextUserName = aesUtil.encrypt(salt, iv, action.payload.username),
      ciphertextPassword = aesUtil.encrypt(salt, iv, action.payload.password),
      loginCredentials = createEncryptedData([iv, salt, ciphertextUserName, ciphertextPassword]);
    const body = yield call(loginResponse, loginCredentials);
    if (body.status === 200) {
      const { data } = body;
      data.user.authorities[0].name = decryptemail(data.user.authorities[0].name)
      const mappedRole = roleMap[data.user.authorities[0].name];
      localStorage.setItem(
        constants.TOKEN,
        JSON.stringify({
          token: data.id,
          currentuseridentity: encryptdata(action.payload.password, strings.loginIdentitypwd),
          userId: encryptdata(data.user.id, strings.loginIdentitypwd),
          email: encryptdata(data.user.email, strings.loginIdentitypwd),
          hillromId: data.user.hillromId,
          role: encryptdata(mappedRole, strings.loginIdentitypwd),
          actualRole: encryptdata(data.user.authorities[0].name, strings.loginIdentitypwd),
          user: data.user,
          name: `${data.user.title ? `${data.user.title} ` : ''}${data.user.firstName ? `${data.user.firstName} ` : ''}${data.user.lastName ? `${data.user.lastName}` : ''}`
        })
      );
      yield put({
        type: constants.ACCOUNT.ACCOUNT_RESET
      });
      yield put({
        type: constants.LOGIN.LOGIN_SUCCESS,
        response: body.data
      });
    } else if (
      (body.data.APP_CODE === 'EMAIL_PASSWORD_RESET' ||
        body.data.APP_CODE === 'PASSWORD_RESET') &&
      body.status === 401
    ) {
      yield put({
        type: constants.LOGIN.REGISTER_REQUEST,
        response: body.data
      });
    } else {
      yield put({
        type: constants.LOGIN.LOGIN_FAILURE,
        response: body.data
      });
    }
  } catch (body) {
    yield put({
      type: constants.LOGIN.LOGIN_FAILURE,
      response: { Error: 'Please try again' }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }

}
export default loginUser;