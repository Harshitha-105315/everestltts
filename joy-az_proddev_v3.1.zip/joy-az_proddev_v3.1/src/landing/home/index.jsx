import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import { getUserData } from 'utils/helper';
import landingUrls from 'rolesData/landing';
import { reverse } from 'named-urls';
import urls from 'urls';

class HomePage extends Component {
  getUserBaseUrl = () => {
    const userData = getUserData();
    if (userData) {
      if (landingUrls[userData.role].pattern) {
        return reverse(landingUrls[userData.role].to, { id: userData.userId });
      }
      return landingUrls[userData.role].to;
    }
  };

  render() {
    const rootUrl = this.getUserBaseUrl();
    if (rootUrl) {
      return <Redirect to={rootUrl} />;
    } else {
      return <Redirect to={urls.LOGIN} />;
    }
  }
}

export default HomePage;
