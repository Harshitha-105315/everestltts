import constants from 'constants.js';

const initialState = {
  message: '',
  registered: false,
  question: []
};
function activateReducer(state = initialState, action) {
  switch (action.type) {
    case constants.ACTIVATE.FETCH_SUCCESS:
      return Object.assign({}, state, { question: action.ques, message: '' });
    case constants.ACTIVATE.ACTIVATION_SUCCESS:
      return Object.assign({}, state, {
        message: '',
        registered: true
      });
    case constants.ACTIVATE.ACTIVATION_FAILURE:
      return Object.assign({}, state, {
        message: action.response,
        registered: false
      });
    default:
      return state;
  }
}
export default activateReducer;
