import React, { Component } from 'react';
import { Form, Button, Col, Nav } from 'react-bootstrap';
import { Redirect, Link } from 'react-router-dom';
import { isEmpty } from 'lodash';
import constants from 'constants.js';
import back from 'assets/back.svg';
import LoginShell from 'components/LoginShell';
import strings from 'localization/strings';
import './securityquestions.scss';
import reportValidity from 'report-validity';
import urls from 'urls';

export default class SecurityQuestions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toAccept: false,
      questionId: 'default',
      answer: '',
      error: '',
      submitted: false,
      isMobile: false
    };
    this.form = React.createRef();
    this.setScreenSize = this.setScreenSize.bind(this);
  }

  componentWillMount() {
    const { response } = this.props;
    if (response === undefined) {
      const { history } = this.props;
      history.push(urls.LANDING);
    }
    const { dispatch } = this.props;
    dispatch({ type: constants.ACTIVATE.SECURITYQUESTIONS });
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillReceiveProps(newProps) {
    const { error } = this.state;
    const { activateMessage } = newProps.activateReducer;
    if (error !== activateMessage) {
      this.setState({ error: activateMessage });
    }
  }

  getQuestionsElement = () => {
    const { questions } = this.props.activateReducer;
    return questions.map(function mapQuestions(element, key) {
      return <option key={key} value={element.id}>{element.question}</option>;
    });
  };

  handleChangeRadio = event => {
    this.setState({
      questionId: event.target.value
    });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (document.documentElement.clientWidth <= 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  validate = () => {
    return reportValidity(this.form.current);
  };

  handleSubmit = () => {
    this.setState({ error: '', submitted: true });
    if (this.validate()) {
      const { toAccept, questionId, answer } = this.state;
      const { history } = this.props;
      const {
        response,
        dispatch,
        APP_CODE,
        activationKey
      } = this.props;
      if (questionId !== 'default') {
        dispatch({
          type: constants.ACTIVATE.ACTIVATE_ACCOUNT,
          payload: {
            toAccept,
            questionId,
            answer,
            email: response.email,
            password: response.password,
            token: response.token,
            APP_CODE,
            activationKey,
            history
          }
        });
      } else {
        this.setState({
          error: strings.selectQuestionError
        });
      }
    }
  };

  handleResetPassword = () => {
    this.setState({ error: '', submitted: true });
    if (this.validate()) {
      const { questionId, answer } = this.state;
      const { history } = this.props;
      const {
        response,
        dispatch,
        activationKey
      } = this.props;
      if (questionId !== 'default') {
        dispatch({
          type: constants.ACTIVATE.RESET_PASSWORD,
          payload: {
            questionId,
            answer,
            password: response.password,
            activationKey,
            history
          }
        });
      } else {
        this.setState({
          error: strings.selectQuestionError
        });
      }
    }
  };

  render() {
    const { toAccept, error, submitted } = this.state;
    const {
      loggedin,
      history,
      location,
      response,
      activateReducer: { questions, registered },
    } = this.props;
    if (registered && loggedin) {
      return (
        <Redirect
          to={urls.PROFILE.ALL}
          from={urls.REGISTER}
        />
      );
    }
    let isResetPassword = location.pathname === urls.RESETPASSWORD;
    return (
      <LoginShell
        below_form_content={
          <div>
            <div className="secondary-link text-center">
              <p>{strings.alreadyRegistered}</p>
            </div>
            <div className="primary-link text-center">
              <Link onClick={() => window.location.replace(urls.LANDING)}>{strings.loginWith}</Link>
            </div>
          </div>
        }
      >
        <div>
          <h1 className="text-left text-white">
            <img
              id="back"
              src={back}
              alt="back"
              role="presentation"
              onClick={() => {
                history.push({
                  pathname: urls.ACTIVATION,
                  response: { authToken: response.token },
                  state: {
                    email: response.email,
                    password: response.password,
                    cpassword: '',
                    match: false,
                    valid: false,
                    error: '',
                    submitted: false
                  }
                });
              }}
              onMouseDown={() => {
                history.push({
                  pathname: urls.ACTIVATION,
                  response: { authToken: response.token },
                  state: {
                    email: response.email,
                    password: response.password,
                    cpassword: '',
                    match: false,
                    valid: false,
                    error: '',
                    submitted: false
                  }
                });
              }}
            />
            {strings.securityQuestions}
          </h1>
        </div>
        <Form
          className={`form-inverse security-question-form${submitted ? ' submitted' : ''
            }`}
          ref={this.form}
        >
          <Form.Group className="d-none d-sm-block">
            <select
              name="questionId"
              className="custom-select"
              onChange={event => {
                this.setState({
                  error: null,
                  questionId: event.target.value
                });
              }}
              required
            >
              <option value="default">{strings.selectSecurityQues} <span className="asterisk-color">*</span></option>
              {this.getQuestionsElement()}
            </select>
          </Form.Group>
          <div className="security-question-mobile d-block d-sm-none">
            {!isEmpty(questions) &&
              questions.map(q => (
                <div className="questions-mobile">
                  <Form.Row
                    as={Col}
                    className="d-inline-block justify-content-start security-question"
                  >
                    <Form.Label as={Col} className="security-question-label">
                      <Form.Check
                        className="d-inline-block filter-radio"
                        type="radio"
                        value={q.id}
                        onChange={event => this.handleChangeRadio(event)}
                        name="questionId"
                        id="questionId"
                      />
                      {q.question}
                    </Form.Label>
                  </Form.Row>

                  <hr className="security-question-hr" />
                </div>
              ))}
          </div>
          <Form.Group>
            <Form.Label className="text-light">
              {strings.enterYourAnswer}
            </Form.Label>
            <Form.Control
              className="input-field"
              type="text"
              name="answer"
              onChange={event => {
                this.setState({ error: null });
                this.setState({ [event.target.name]: event.target.value });
              }}
              required
            />
          </Form.Group>
          {
            !isResetPassword ?
              <Form.Group>
                <div className="custom-control custom-checkbox">
                  <input
                    id="t-and-c-checkbox"
                    className="custom-control-input"
                    type="checkbox"
                    name="toAccept"
                    value={toAccept}
                    onChange={event => {
                      this.setState({ [event.target.name]: !toAccept });
                    }}
                    required
                  />
                  <Form.Label
                    className="text-white form-check-label t-and-c-label custom-control-label"
                    htmlFor="t-and-c-checkbox"
                  >
                    <span className="font-weight-light">{strings.iAgree} </span>
                    <Nav.Link href={urls.TERMSOFUSE} target="_blank" className="t-and-c-inline-link">
                      <span className="font-weight-bold">{strings.termsCond}</span>
                    </Nav.Link>
                  </Form.Label>
                </div>
              </Form.Group>
              :
              null
          }
          <p id="error" className="landing-error">{error}</p>
          {
            isResetPassword ?
              <Button
                id="security-questions-button"
                className="btn-lg btn-primary mx-auto"
                onClick={this.handleResetPassword}
                block
              >
                {strings.reset_password}
              </Button>
              :
              <Button
                id="security-questions-button"
                className="btn-lg btn-primary mx-auto"
                onClick={this.handleSubmit}
                block
              >
                {strings.register}
              </Button>
          }
        </Form>
      </LoginShell>
    );
  }
}
