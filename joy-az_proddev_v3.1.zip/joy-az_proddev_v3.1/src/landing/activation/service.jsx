import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';

function loadSecurityQuestions() {
  return authRequest({
    url: API.SECURITYQUESTIONS,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function activateAccount({ payload, token, activationKey }) {
  return authRequest({
    url: activationKey ? API.ACTIVATEACCOUNTWITHKEY : API.ACTIVATEACCOUNTWITHEMAIL,
    method: 'PUT',
    data: payload,
    headers: {
      'x-auth-token': activationKey ? null : token,
      "Content-Type": "text/plain"
    },
    [constants.RETURNRESPONSE]: true
  });
}

function activateAccountWithKey(params) {
  return authRequest({
    url: API.ACTIVATEUSERACCOUNTWITHKEY,
    method: 'GET',
    params,
    headers: {
      "Content-Type": "text/plain"
    },
    [constants.RETURNRESPONSE]: true
  });
}

function resetUserPassword({ payload, params }) {
  return authRequest({
    url: API.FORGOTPASSWORDFINISH,
    method: 'POST',
    data: payload,
    params,
    headers: {
      "Content-Type": "text/plain"
    },
    [constants.RETURNRESPONSE]: true
  });
}



const activateAccountServices = { loadSecurityQuestions, activateAccount, activateAccountWithKey, resetUserPassword };
export default activateAccountServices;
