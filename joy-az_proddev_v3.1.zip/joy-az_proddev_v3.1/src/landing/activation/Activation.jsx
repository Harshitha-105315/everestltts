import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Form, Button } from 'react-bootstrap';
import strings from 'localization/strings';
import './activation.scss';
import LoginShell from 'components/LoginShell';
import SecurityQuestions from '../activation/SecurityQuestions';
import reportValidity from 'report-validity';
import urls from 'urls';

export default class Activation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      cpassword: '',
      match: false,
      valid: false,
      error: '',
      submitted: false,
      activationKey: null,
      authToken: null
    };
    this.handlePassword = this.handlePassword.bind(this);
    this.handleConfirmedPasswordCheck = this.handleConfirmedPasswordCheck.bind(
      this
    );
    this.form = React.createRef();
  }

  componentWillMount() {
    const { APP_CODE, history, response, location } = this.props;
    let search = new URLSearchParams(location.search);
    const key = search.get('key');

    if (key && APP_CODE === undefined) {
      this.setState({ activationKey: key });
      return;
    }

    if (response === undefined) {
      history.push(urls.LANDING);
    } else if (APP_CODE === 'PASSWORD_RESET') {
      this.setState({ email: response.email });
    }
  }

  handleChange = event => {
    const { error } = this.state;
    if (error !== '') {
      this.setState({ error: '' });
    }
    this.setState({ [event.target.name]: event.target.value });
  };

  handleNewPassword = value => {
    this.setState({ password: value });
  };

  handleConfirmedPassword = value => {
    this.setState({ cpassword: value });
  };

  checkPassword = password => {
    return /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(
      password
    );
  };

  validate = () => {
    return reportValidity(this.form.current);
  };

  handleSubmit = () => {
    const { match, password, activationKey } = this.state;
    const { response } = this.props;
    this.setState({ error: '', submitted: true });
    if (this.validate()) {
      if ((response && response.authToken) || activationKey) {
        if (this.checkPassword(password)) {
          if (!match) {
            this.setState({ error: strings.passwordMismatch });
          } else {
            this.setState({ valid: true });
          }
        } else {
          this.setState({
            error: strings.passwordPolicyError
          });
        }
      } else {
        this.setState({ error: strings.activationError });
        this.setState({ valid: false });
      }
    }
  };

  async handleConfirmedPasswordCheck(event) {
    const { password } = this.state;
    this.handleConfirmedPassword(event.target.value);
    if (event.target.value !== '' && event.target.value !== password) {
      await this.setState({ error: strings.passwordMismatch });
      await this.setState({ match: false });
    } else {
      await this.setState({ error: '' });
      await this.setState({ match: true });
    }
  }

  async handlePassword(event) {
    await this.handleNewPassword(event.target.value);
    // eslint-disable-next-line react/destructuring-assignment
    if (this.state.cpassword !== '') {
      // eslint-disable-next-line react/destructuring-assignment
      if (this.state.password !== this.state.cpassword) {
        await this.setState({ error: strings.passwordMismatch });
        await this.setState({ match: false });
      } else {
        await this.setState({ error: '' });
        await this.setState({ match: true });
      }
    }
  }

  render() {
    const { email, password, cpassword, valid, error, submitted, activationKey } = this.state;
    const {
      response,
      APP_CODE,
      dispatch,
      history,
      location,
      activateReducer
    } = this.props;
    if (valid)
      return (
        <SecurityQuestions response={{ token: response.authToken || this.state.authToken, email, password }} dispatch={dispatch} APP_CODE={APP_CODE} history={history} activateReducer={activateReducer} activationKey={activationKey} location={location}></SecurityQuestions>
      );

    const { pathname } = location;
    const title = pathname === urls.RESETPASSWORD ? strings.reset_password : strings.register;
    return (
      <LoginShell
        below_form_content={
          <div>
            <div className="secondary-link text-center">
              <p>{strings.alreadyRegistered}</p>
            </div>
            <div className="primary-link text-center">
              <Link onClick={() => window.location.replace(urls.LANDING)}>{strings.loginWith}</Link>
            </div>
          </div>
        }
      >
        <h1 className="text-left text-white">{title}</h1>
        <Form
          className={`form-inverse registration-form${
            submitted ? ' submitted' : ''
            }`}
          ref={this.form}
        >
          {APP_CODE === 'EMAIL_PASSWORD_RESET' && !activationKey ? (
            < Form.Group >
              <Form.Label className="text-light text-capitalize">
                {strings.email}
              </Form.Label>
              <Form.Control
                className="input-field"
                type="email"
                name="email"
                value={email}
                onChange={this.handleChange}
                required
              />
            </Form.Group>
          ) : null}
          <Form.Group>
            <Form.Label className="text-light">{strings.password}</Form.Label>
            <Form.Control
              className="input-field"
              type="password"
              name="password"
              value={password}
              onChange={this.handlePassword}
              required
            />
          </Form.Group>
          <Form.Group>
            <Form.Label className="text-light">
              {strings.confirmPassword}
            </Form.Label>
            <Form.Control
              className="input-field"
              type="password"
              name="cpassword"
              value={cpassword}
              onChange={this.handleConfirmedPasswordCheck}
              required
            />
          </Form.Group>
          <p id="error" className="landing-error">{error}</p>
          <Button
            id="register-button"
            className="btn-primary btn-lg mx-auto"
            onClick={this.handleSubmit}
            block
          >
            {strings.continue}
          </Button>
        </Form>
      </LoginShell>
    );
  }
}
