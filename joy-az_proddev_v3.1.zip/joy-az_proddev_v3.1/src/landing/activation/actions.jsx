import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import activateAccountServices from './service';
import { getIVSalt, createEncryptedData } from 'utils/utltity';
import urls from 'urls';

var AesUtil = require('utils/AesUtil');

export function* securityQuestionsAction() {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(activateAccountServices.loadSecurityQuestions);

    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.ACTIVATE.FETCH_SUCCESS,
        ques: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* finishResetPassword(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { password, answer, questionId, activationKey } = action.payload;
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextPassword = aesUtil.encrypt(salt, iv, password),
      ciphertextQuestionId = aesUtil.encrypt(salt, iv, questionId),
      ciphertextAnswer = aesUtil.encrypt(salt, iv, answer),
      activationCredentials = [];
    activationCredentials.push(iv, salt, ciphertextPassword, ciphertextQuestionId, ciphertextAnswer);

    const encryptedData = createEncryptedData(activationCredentials);

    const response = yield call(
      activateAccountServices.resetUserPassword,
      { payload: encryptedData, params: { key: activationKey } }
    );
    if (response.status === 200) {
      window.location.replace(urls.LANDING);
    }
    if ('ERROR' in response.data) {
      yield put({
        type: constants.ACTIVATE.ACTIVATION_FAILURE,
        response: response.data.ERROR
      });
    }
    if ('error' in response.data) {
      yield put({
        type: constants.ACTIVATE.ACTIVATION_FAILURE,
        response: response.data.error
      });
    }
  } catch (error) {
    yield put({
      type: constants.ACTIVATE.ACTIVATION_FAILURE,
      response: 'Please try again'
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

export function* firstTimeActivation(action) {
  try {
    const { email, password, answer, questionId, toAccept, APP_CODE, token, activationKey } = action.payload;
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextemailID = (APP_CODE === constants.EMAIL_PASSWORD_RESET || APP_CODE === constants.PASSWORD_RESET) ? aesUtil.encrypt(salt, iv, email) : aesUtil.encrypt(salt, iv, activationKey),
      ciphertextPassword = aesUtil.encrypt(salt, iv, password),
      ciphertextQuestionId = aesUtil.encrypt(salt, iv, questionId),
      ciphertextAnswer = aesUtil.encrypt(salt, iv, answer),
      ciphertextTnC = aesUtil.encrypt(salt, iv, String(toAccept)),
      activationCredentials = [];
    activationCredentials.push(iv, salt, ciphertextPassword, ciphertextQuestionId, ciphertextAnswer, ciphertextTnC);
    if (ciphertextemailID) {
      activationCredentials.splice(2, 0, ciphertextemailID);
    }
    const encryptedData = createEncryptedData(activationCredentials);

    if (activationKey) {
      yield call(
        activateAccountServices.activateAccountWithKey,
        { key: activationKey }
      );
    }
    const response = yield call(
      activateAccountServices.activateAccount,
      { payload: encryptedData, token, activationKey }
    );
    try {
      if ('ERROR' in response.data) {
        yield put({
          type: constants.ACTIVATE.ACTIVATION_FAILURE,
          response: response.data.ERROR
        });
      }
      if ('error' in response.data) {
        yield put({
          type: constants.ACTIVATE.ACTIVATION_FAILURE,
          response: response.data.error
        });
      }
    } catch {
      if (response.status === 200) {
        yield put({ type: constants.LOGIN.REGISTER_CLEAR });
        yield put({ type: constants.ACTIVATE.ACTIVATION_SUCCESS });
        if (APP_CODE) {
          yield put({
            type: constants.LOGIN.LOGIN_REQUEST,
            payload: {
              username: action.payload.email,
              password: action.payload.password
            }
          });
        } else {
          window.location.replace(urls.LANDING);
        }
      } else {
        yield put({
          type: constants.ACTIVATE.ACTIVATION_FAILURE,
          response: 'Please try again'
        });
      }
    }
  } catch (response) {
    yield put({
      type: constants.ACTIVATE.ACTIVATION_FAILURE,
      response: 'Please try again'
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
