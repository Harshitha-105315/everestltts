import constants from 'constants.js';

const initialState = { message: '', error: '' };

function forgotPasswordReducer(state = initialState, action) {
  switch (action.type) {
    case constants.FORGOTPASSWORD.FORGOT_PASS_SUCCESS:
      return Object.assign({}, state, { message: action.response, error: '' });
    case constants.FORGOTPASSWORD.FORGOT_PASS_FAILURE:
      return Object.assign({}, state, {
        error: action.response,
        message: ''
      });
    default:
      return state;
  }
}
export default forgotPasswordReducer;
