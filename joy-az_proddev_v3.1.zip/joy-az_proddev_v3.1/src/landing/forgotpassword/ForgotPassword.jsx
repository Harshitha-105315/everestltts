import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Form, Button } from 'react-bootstrap';
import constants from 'constants.js';
import LoginShell from 'components/LoginShell';
import strings from 'localization/strings';
import './forgotpassword.scss';
import reportValidity from 'report-validity';
import urls from 'urls';

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = { email: '', submitted: false };
    this.form = React.createRef();
  }

  handleSubmit = () => {
    this.setState({ submitted: true });
    if (this.validate()) {
      const { dispatch } = this.props;
      const { email } = this.state;
      dispatch({
        type: constants.FORGOTPASSWORD.FORGOT_PASS_REQUEST,
        payload: { username: email }
      });
    }
  };

  validate = () => {
    return reportValidity(this.form.current);
  };

  render() {
    const { email } = this.state;
    const { message, error } = this.props;
    return (
      <LoginShell
        below_form_content={
          <div className="primary-link text-center">
            <Link to={urls.LOGIN}>{strings.backToLogin}</Link>
          </div>
        }
        modifierClass="password-reset"
      >
        <h1 className="text-white text-left">{strings.resetPassword}</h1>
        <Form
          className={`form-inverse password-reset-form${
            this.state.submitted ? ' submitted' : ''
            }`}
          ref={this.form}
        >
          <p className="instructions text-white text-left">
            {strings.pleaseEnterYourEmail}
          </p>
          <Form.Group className="">
            <Form.Label className="text-light">
              {strings.yourEmailAddress}
            </Form.Label>
            <Form.Control
              className="input-field"
              type="email"
              name="email"
              value={email}
              onChange={event => {
                this.setState({ [event.target.name]: event.target.value });
              }}
              required
            />
          </Form.Group>
          {message && <p className="text-success">{message}</p>}
          <p id="error" className="landing-error">{error}</p>
          <Button
            id="send-reset-button"
            className="btn-block btn-lg mx-auto"
            onClick={this.handleSubmit}
            block
          >
            {strings.sendResetLink}
          </Button>
        </Form>
      </LoginShell>
    );
  }
}
const mapStateToProps = state => {
  return {
    message: state.app.forgotPasswordReducer.message,
    error: state.app.forgotPasswordReducer.error
  };
};
export default connect(
  mapStateToProps,
  null
)(ForgotPassword);
