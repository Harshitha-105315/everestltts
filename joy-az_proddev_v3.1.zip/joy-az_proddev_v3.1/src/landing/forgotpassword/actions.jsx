import { put, call } from 'redux-saga/effects';
import forgotPasswordService from './services';
import constants from 'constants.js';
import { getIVSalt, createEncryptedData } from 'utils/utltity';

const AesUtil = require('utils/AesUtil');

function* forgotPasswordAction(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    let iv = getIVSalt(),
      salt = getIVSalt(),
      aesUtil = new AesUtil(128, 1000),
      ciphertextUserName = aesUtil.encrypt(salt, iv, action.payload.username),
      encryptedEmailId = createEncryptedData([iv, salt, ciphertextUserName])
    const response = yield call(forgotPasswordService, encryptedEmailId);
    if (response.status === 400) {
      yield put({
        type: constants.FORGOTPASSWORD.FORGOT_PASS_FAILURE,
        response: response.data.message
      });
    } else {
      yield put({
        type: constants.FORGOTPASSWORD.FORGOT_PASS_SUCCESS,
        response: response.data.message
      });
    }
  } catch (error) {
    yield put({
      type: constants.FORGOTPASSWORD.FORGOT_PASS_FAILURE,
      response: 'INTERNAL SERVER ERROR'
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}
export default forgotPasswordAction;
