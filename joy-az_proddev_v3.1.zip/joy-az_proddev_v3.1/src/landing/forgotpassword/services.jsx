import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';

function forgotPasswordService(payload) {
  return authRequest({
    url: API.FORGOTPASSWORDINIT,
    method: 'POST',
    data: payload,
    'x-response': true,
    headers: { "Content-Type": "text/plain" }
  });
}
export default forgotPasswordService;
