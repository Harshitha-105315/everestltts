import { createStore, combineReducers, applyMiddleware, compose } from 'redux';
import createSagaMiddleware from 'redux-saga';
import { routerReducer } from 'react-router-redux';

import reducers from 'reducers';
import RootSaga from 'sagas';
import { loadState, saveState } from 'utils/helper';


const sagaMiddleware = createSagaMiddleware();
// Redux dev plugin mode.
// compose in redux is redux dev plugin req.
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const persistedState = loadState();

const store = createStore(
    combineReducers(
        {
            app: reducers,
            routing: routerReducer
        },
        window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    ),
    { app: { ...persistedState } },
    composeEnhancers(applyMiddleware(sagaMiddleware))
);

sagaMiddleware.run(RootSaga);

store.subscribe(() => {
    const {
        app: { breadcrumbsReducer }
    } = store.getState();

    saveState({
        breadcrumbsReducer
    });
});

export default store;