import { call, put } from 'redux-saga/effects';
import constants from 'constants.js';
import PatientService from 'patient/services';
import strings from 'localization/strings';
import AnnouncementService from './services';

function* getAnnouncement(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.getAnnouncementService,
      action.payload
    );
    if (response.status === 200 || response.status === 201) {
      yield put({
        type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_SUCCESS,
        announcement: response.data.Announcement_List,
        announcementContents: response.data.Announcement_List.content
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getAnnouncementPatientType() {
  const response = yield call(
    AnnouncementService.getAnnouncementPatientService
  );
  yield put({
    type: constants.ANNOUNCEMENT.ANNOUNCEMENT_PATIENT_TYPE_SUCCESS,
    patientType: response
  });
}

function* uploadAnnouncementPDF(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.uploadAnnouncementPDFService,
      action.payload
    );
    if (response.status === 201) {
      yield put({
        type: constants.ANNOUNCEMENT.ANNOUNCEMENT_UPLOAD_PDF_SUCCESS,
        filepath: response.data.filepath
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* fetchAnnouncementById(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.fetchAnnouncementByIdService,
      action.payload
    );
    if (response && (response.status === 200 || response.status === 201)) {
      yield put({
        type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_BY_ID_SUCCESS,
        Announcement: response.data.Announcement,
        key: action.payload
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateAnnouncement(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.updateAnnouncementService,
      action.payload
    );
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.UPDATE_SUCCESS_RESPONSE,
        response: response.data.user
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* createAnnouncement(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { payload, history, path } = action.allData;
    const response = yield call(
      AnnouncementService.createAnnouncementService,
      payload
    );
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.ADD_SUCCESS_RESPONSE,
        response: { history, path }
      });
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: strings.internalServerError
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* deleteAnnouncement(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const { id, userData, asc, perPage, page, sortBy } = action.allData;
    const role = userData;
    const payload = id;
    const response = yield call(
      AnnouncementService.deleteAnnouncementService,
      payload
    );
    if (response.status === 201) {
      yield put({
        type: constants.ALERT.DELETE_SUCCESS
      });
      if (role.actualRole === constants.ROLES.SUPER_ADMIN) {
        yield put({
          type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT,
          payload: { perPage, page, asc, sortBy, role }
        });
      } else {
        yield put({
          type: constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH,
          payload: {
            perPage,
            page,
            asc,
            sortBy: 'modified_date',
            userData
          }
        });
      }
    } else {
      yield put({
        type: constants.ALERT.FAILURE_RESPONSE,
        response: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({ type: constants.ANNOUNCEMENT.DELETE_ANNOUNCEMENT_FAILURE });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* getPatientAnnouncement(action) {
  const { payload } = action;
  const patientID = payload.userData.userId;
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const patientData = yield call(PatientService.getPatientData, patientID);
    payload.patientId = patientData.data.patient_id;
    if (patientData.status === 200 || patientData.status === 201) {
      try {
        yield put({ type: constants.SHOW_LOADER, payload: true });
        const response = yield call(
          AnnouncementService.getPatientAnnouncementService,
          payload
        );
        if (response.status === 200 || response.status === 201) {
          yield put({
            type: constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH_SUCCESS,
            announcementList: response.data.Announcement_List
          });
        } else {
          throw Object({
            custom_message: response.data.ERROR || response.data.error
          });
        }
      } finally {
        yield put({ type: constants.SHOW_LOADER, payload: false });
      }
    } else {
      throw Object({
        custom_message: patientData.data.ERROR || patientData.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: { message: response.custom_message, isScrollNotRequired: true }
    });
    yield put({
      type: constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH_SUCCESS,
      announcementList: response
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* viewAnnouncementPDF(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.viewPDFService,
      action.payload
    );
    if (response.status === 200 || response.status === 201) {
      yield put({
        type: constants.ANNOUNCEMENT.VIEW_ANNOUNCEMENT_PDF_SUCCESS,
        message: response.data
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

function* updateAnnouncementReadStatus(action) {
  try {
    yield put({ type: constants.SHOW_LOADER, payload: true });
    const response = yield call(
      AnnouncementService.updateReadStatusService,
      action.payload
    );
    if (response.status === 200 || response.status === 201) {
      yield put({
        type: constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT_READ_STATUS_SUCCESS,
        message: response.data.statusMsg
      });
    } else {
      throw Object({
        custom_message: response.data.ERROR || response.data.error
      });
    }
  } catch (response) {
    yield put({
      type: constants.ALERT.FAILURE_RESPONSE,
      response: response.custom_message
    });
  } finally {
    yield put({ type: constants.SHOW_LOADER, payload: false });
  }
}

const AnnouncementAction = {
  getAnnouncement,
  getAnnouncementPatientType,

  uploadAnnouncementPDF,
  fetchAnnouncementById,
  updateAnnouncement,
  createAnnouncement,
  deleteAnnouncement,
  getPatientAnnouncement,
  viewAnnouncementPDF,
  updateAnnouncementReadStatus
};
export default AnnouncementAction;
