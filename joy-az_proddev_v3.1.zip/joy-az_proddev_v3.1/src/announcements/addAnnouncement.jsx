/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import moment from 'moment-timezone';
import { Form, Col } from 'react-bootstrap';
import { Header, SideBar } from 'components/Navigation';
import DatePicker from 'react-datepicker';
import strings from 'localization/strings';
import constants from 'constants.js';
import urls from 'urls';
import { reverse } from 'named-urls';
import { FootNote } from 'components/FootNote';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import ConfirmationDialog from 'components/ConfirmationDialog';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { getUserData } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getBreadCrumb, addBreadCrumb, getSpeciality } from '../utils/utltity';

class AddNewAnnouncement extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: '',
      name: '',
      subject: '',
      startDate: new Date(),
      endDate: new Date(),
      sendTo: '',
      clinicType: '',
      clinicSpecialty: 'Specialty',
      pdfFilePath: '',
      patientType: '',
      videoPath: '',
      radioType: 'PDF',
      error: null,
      isMobile: false,
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      },
      sizeExceeded: false
    };

    this.handleSpecialtyChange = this.handleSpecialtyChange.bind(this);
    this.handleSetCheckBox = this.handleSetCheckBox.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.validateYouTubeUrl = this.validateYouTubeUrl.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.handleDispatchPostYoutubeAnnouncement = this.handleDispatchPostYoutubeAnnouncement.bind(
      this
    );
    this.handleDispatchPostPDFAnnouncement = this.handleDispatchPostPDFAnnouncement.bind(
      this
    );
  }

  componentWillMount() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.ANNOUNCEMENT_PATIENT_TYPE
    });
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
    dispatch({ type: constants.ANNOUNCEMENT.CLEAR_ANNOUNCEMENT_STATUS });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.newAnnouncement });
  }

  componentWillReceiveProps(newProps) {
    const { filepath } = newProps;
    if (filepath !== undefined) {
      this.setState({ pdfFilePath: filepath });
    }
  }

  handleSetStartDate = date => {
    const { endDate } = this.state;
    const from = moment(date);
    this.setState({ startDate: from });
    if (moment(from).isAfter(endDate)) {
      this.setState({ endDate: from });
    }
    this.setState({ isDirty: true });
  };

  handleSetEndDate = date => {
    this.setState({ endDate: moment(date), isDirty: true });
  };

  handleSpecialtyChange = event => {
    this.setState({ clinicType: event.target.value, isDirty: true });
  };

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value,
      clinicSpecialty: 'Specialty',
      isDirty: true
    });
  };

  handleChangeRadio = event => {
    this.setState({ radioType: event.target.value, isDirty: true });
  };

  dateConvert = date => {
    const newDate = new Date(date);
    return `${newDate.getFullYear()}-${newDate.getMonth() +
      1}-${newDate.getDate()}`;
  };

  handlePostAnnouncement = e => {
    const {
      name,
      subject,
      sendTo,
      patientType,
      pdfFilePath,
      clinicType,
      videoPath,
      radioType
    } = this.state;
    let { startDate, endDate } = this.state;
    startDate = this.dateConvert(startDate);
    endDate = this.dateConvert(endDate);
    this.setState({ error: '' });
    if (name === '') {
      this.setState({ error: strings.announcementTitleRequired });
    } else if (subject === '') {
      this.setState({ error: strings.announcementSubjectRequired });
    } else if (startDate === '') {
      this.setState({ error: strings.announcementStartDateRequired });
    } else if (endDate === '') {
      this.setState({ error: strings.announcementEndDateRequired });
    } else if (sendTo === '') {
      this.setState({ error: strings.sendToRequired });
    } else if (sendTo === 'Clinic' && clinicType === '') {
      this.setState({ error: strings.clinicTypeRequired });
    } else if (sendTo === 'Clinic' && clinicType === 'Specialty') {
      this.setState({ error: strings.specialtyTypeRequired });
    } else if (sendTo === 'Patient' && patientType === '') {
      this.setState({ error: strings.patientTypeRequired });
    } else if (sendTo === 'All' && clinicType === '') {
      this.setState({ error: strings.clinicTypeRequired });
    } else if (sendTo === 'All' && patientType === '') {
      this.setState({ error: strings.patientTypeRequired });
    } else if (radioType === 'PDF' && pdfFilePath === '') {
      this.setState({ error: strings.fileRequired });
    } else if (radioType === 'Video' && videoPath === '') {
      this.setState({ error: strings.videoPathRequired });
    } else if (this.state.sizeExceeded) {
      this.setState({ error: strings.fileSize });
    } else if (radioType === 'PDF') {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.postAnnouncementDialogBody,
          title: strings.postAnnouncement,
          button: strings.postAnnouncement,
          show: true,
          confirmFunction: () => this.handleDispatchPostPDFAnnouncement(e)
        })
      });
    } else {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.postAnnouncementDialogBody,
          title: strings.postAnnouncement,
          button: strings.postAnnouncement,
          show: true,
          confirmFunction: this.handleDispatchPostYoutubeAnnouncement
        })
      });
    }
  };

  async handleDispatchPostPDFAnnouncement(e) {
    const {
      name,
      subject,
      sendTo,
      patientType,
      pdfFilePath,
      clinicType,
      dialog
    } = this.state;
    let { startDate, endDate } = this.state;
    const { dispatch, history } = this.props;
    startDate = this.dateConvert(startDate);
    endDate = this.dateConvert(endDate);
    const payload = {
      name,
      subject,
      startDate,
      endDate,
      sentTo: sendTo,
      patientType,
      pdfFilePath,
      clicicType: clinicType
    };
    dispatch({
      type: constants.ANNOUNCEMENT.CREATE_ANNOUNCEMENT,
      allData: { history, payload, path: reverse(urls.ANNOUNCEMENT.ALL) }
    });
    dispatch({
      type: constants.ANNOUNCEMENT.RESET_ANNOUNCEMENT_FILEPATH
    });
    e.preventDefault();
    dialog.handleClose();
    await this.setState({ isDirty: false });
  }

  async handleDispatchPostYoutubeAnnouncement() {
    const {
      name,
      subject,
      sendTo,
      patientType,
      clinicType,
      videoPath,
      dialog
    } = this.state;
    let { startDate, endDate } = this.state;
    const { dispatch, history } = this.props;
    startDate = this.dateConvert(startDate);
    endDate = this.dateConvert(endDate);
    const payload = {
      name,
      subject,
      startDate,
      endDate,
      sentTo: sendTo,
      patientType,
      clicicType: clinicType,
      videoPath
    };
    dispatch({
      type: constants.ANNOUNCEMENT.CREATE_ANNOUNCEMENT,
      allData: { history, payload, path: reverse(urls.ANNOUNCEMENT.ALL) }
    });
    dialog.handleClose();
    await this.setState({ isDirty: false });
  }

  uploadPDFFIle = event => {
    const { dispatch } = this.props;
    const formDataVal = new FormData();
    if (event.target.files[0].size < 10485760) {
      formDataVal.append(
        'uploadfile',
        event.target.files[0],
        event.target.files[0].name
      );
      dispatch({
        type: constants.ANNOUNCEMENT.ANNOUNCEMENT_UPLOAD_PDF,
        payload: formDataVal
      });
      this.setState({ isDirty: true, sizeExceeded: false });
    } else {
      this.setState({ sizeExceeded: true });
    }
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  async handleSetCheckBox(event) {
    const { sendTo } = this.state;
    if (sendTo !== 'All') {
      if (sendTo !== event.target.value && sendTo !== '') {
        this.setState({ sendTo: 'All' });
        if (this.state.patientType === '') {
          this.setState({ patientType: 'All' });
        }
        if (this.state.clinicType === '') {
          this.setState({ clinicType: 'All' });
        }
      } else if (sendTo !== event.target.value) {
        this.setState({ sendTo: event.target.value });
        if (event.target.value === 'Clinic') {
          this.setState({ clinicType: 'All' });
        } else if (event.target.value === 'Patient') {
          this.setState({ patientType: 'All' });
        }
      } else {
        await this.setState({ sendTo: '', clinicType: '', patientType: '' });
      }
    } else if (event.target.value === 'Clinic') {
      await this.setState({
        sendTo: 'Patient',
        clinicType: '',
        clinicSpecialty: ''
      });
    } else if (event.target.value === 'Patient') {
      await this.setState({ sendTo: 'Clinic', patientType: '' });
    }
  }

  async validateYouTubeUrl(event) {
    const expression = /^(http(s)??:\/\/)?(www\.)?((youtube\.com\/embed\/))([a-zA-Z0-9\-_])+/;
    const regex = new RegExp(expression);
    const path = event.target.value;
    if (path.match(regex)) {
      await this.setState({ videoPath: path, isDirty: true });
    } else {
      await this.setState({ error: strings.youTubeURLNotValid, videoPath: '' });
    }
  }

  render() {
    const { location, patientTypes, breadcrumbs, history } = this.props;
    const {
      name,
      subject,
      startDate,
      endDate,
      sendTo,
      patientType,
      pdfFilePath,
      clinicSpecialty,
      clinicType,
      videoPath,
      radioType,
      error,
      isMobile,
      dialog
    } = this.state;

    const sideBarData = {
      activeKey: location.pathname,
      menu: [{ href: urls.ANNOUNCEMENT.ADD, text: strings.newAnnouncement }]
    };

    const { actualRole } = getUserData();
    const createAnnouncement = accessMatrix.CREATE_ANNOUNCEMENT[actualRole];

    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.ANNOUNCEMENT.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}
            <div>
              <ButtonComponent
                id="add-announcement-top"
                buttonClass="float-right"
                buttonAction={this.handlePostAnnouncement}
                icon="report-icon"
                buttonText={strings.postAnnouncement}
                hidden={!createAnnouncement.write}
              />
            </div>
            <h2 className="text-capitalize">{strings.addNewAnnouncement}</h2>
            <h6 className="text-capitalize">{strings.announcementDetail}</h6>

            <Form>
              <p className="text-danger">{error}</p>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.announcementTitle} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <FormControlComponent
                    type="text"
                    name="name"
                    onChange={this.handleChange}
                    defaultValue={name || ''}
                    required=""
                  />
                </Form.Group>
              </Form.Row>

              <Form.Row>
                <Form.Group as={Col} md={8}>
                  <Form.Label htmlFor="reset">{strings.subject} <span className="asterisk-color">*</span></Form.Label>

                  <Form.Control
                    name="subject"
                    as="textarea"
                    value={subject || ''}
                    onChange={this.handleChange}
                    required=""
                    rows="5"
                  />
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">{strings.startDate} <span className="asterisk-color">*</span></Form.Label>
                  <br />
                  <DatePicker
                    className="custom-select"
                    name="startDate"
                    minDate={new Date()}
                    dateFormat="MMM d, yyyy"
                    selected={new Date(Date.parse(moment(startDate)))}
                    onChange={this.handleSetStartDate}
                  />
                </Form.Group>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">{strings.endDate} <span className="asterisk-color">*</span></Form.Label>
                  <br />
                  <DatePicker
                    className="custom-select"
                    name="endDate"
                    minDate={new Date(Date.parse(moment(startDate)))}
                    dateFormat="MMM d, yyyy"
                    selected={new Date(Date.parse(moment(endDate)))}
                    onChange={this.handleSetEndDate}
                  />
                </Form.Group>
              </Form.Row>
              <hr />
              <h6 className="text-capitalize">{strings.sendTo}</h6>
              <Form.Row className="send-to align-items-center">
                <Form.Check
                  custom
                  className="filter-checkbox"
                  id="Clinic"
                  type="checkbox"
                  label={strings.clinic}
                  name="sendTo"
                  value="Clinic"
                  checked={sendTo === 'Clinic' || sendTo === 'All'}
                  onChange={this.handleSetCheckBox}
                  inline
                />

                <Form.Group as={Col} md={4}>
                  <Form.Label>{strings.clinicType} <span className="asterisk-color">*</span></Form.Label>
                  <Form.Control
                    className="custom-select"
                    as="select"
                    name="clinicType"
                    value={
                      clinicType === 'All' && clinicType !== ''
                        ? clinicType || ''
                        : clinicType !== '' && clinicSpecialty
                    }
                    disabled={sendTo === '' || sendTo === 'Patient'}
                    onChange={this.handleChange}
                    required=""
                  >
                    <option value="" disabled>
                      {strings.all}
                    </option>
                    <option value="All" label="All">
                      {strings.all}
                    </option>
                    <option value="Specialty" label="Specialty">
                      {strings.specialty}
                    </option>
                  </Form.Control>
                </Form.Group>

                {clinicType !== 'All' && clinicType !== '' && (
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="reset">
                      {strings.specialityType} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      className="custom-select text-capitalize"
                      as="select"
                      name="clinicType"
                      placeholder={strings.select}
                      value={clinicType || ''}
                      onChange={this.handleSpecialtyChange}
                      required=""
                    >
                      <option value="">{strings.selectSpeciality}</option>
                      {this.getSpeciality()}
                    </Form.Control>
                  </Form.Group>
                )}
              </Form.Row>
              <Form.Row className=" send-to align-items-center">
                <Form.Check
                  custom
                  className="filter-checkbox"
                  id="Patient"
                  type="checkbox"
                  label={strings.patient}
                  name="sendTo"
                  value="Patient"
                  checked={sendTo === 'Patient' || sendTo === 'All'}
                  onChange={this.handleSetCheckBox}
                  inline
                />

                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.patientType} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <Form.Control
                    className="custom-select"
                    as="select"
                    name="patientType"
                    disabled={sendTo === '' || sendTo === 'Clinic'}
                    value={patientType}
                    onChange={this.handleChange}
                    required=""
                  >
                    <option value="" disabled>
                      {strings.all.charAt(0).toUpperCase() +
                        strings.all.slice(1)}
                    </option>
                    {patientTypes.typeCode !== undefined &&
                      patientTypes.typeCode.map(patient => (
                        <option key={patient.id} value={patient.type_code}>
                          {patient.type_code_value}
                        </option>
                      ))}
                  </Form.Control>
                </Form.Group>
              </Form.Row>
              <hr />
              <h6 className="text-capitalize">{strings.uploadAttachments}</h6>
              <Form.Row className="align-items-center">
                <Form.Group id="upload-pdf-block">
                  <Form.Check
                    inline
                    custom
                    className="filter-checkbox"
                    id="PDF"
                    type="radio"
                    value="PDF"
                    label={strings.PDF}
                    name="PDF"
                    checked={radioType === 'PDF'}
                    onChange={this.handleChangeRadio}
                  />

                  <Form.Label id="upload-pdf-label" htmlFor="file-upload">
                    <ButtonComponent
                      buttonClass="float-right"
                      disabled={radioType !== 'PDF'}
                      icon="report-detail-icon"
                      buttonText={strings.uploadPDFFIle}
                      hidden={!createAnnouncement.write}
                    />
                  </Form.Label>

                  <input
                    type="file"
                    id="file-upload"
                    ref={input => {
                      this.filesInput = input;
                    }}
                    placeholder={strings.onlyPDF}
                    accept=".pdf"
                    name="uploadfile"
                    onChange={this.uploadPDFFIle}
                    disabled={radioType !== 'PDF'}
                  />
                  {this.state.sizeExceeded ? strings.fileSize : pdfFilePath}
                </Form.Group>
              </Form.Row>

              <Form.Row className="align-items-center" id="upload-video-block">
                <Form.Check
                  custom
                  className="filter-checkbox"
                  id="Video"
                  type="radio"
                  value="Video"
                  label={strings.video}
                  name="Video"
                  onChange={this.handleChangeRadio}
                  checked={radioType === 'Video'}
                  inline
                />

                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">{strings.videoURL}</Form.Label>
                  <FormControlComponent
                    type="text"
                    name="videoPath"
                    placeholder={strings.pasteVideoURL}
                    onChange={this.validateYouTubeUrl}
                    defaultValue={videoPath || ''}
                    disabled={radioType !== 'Video'}
                  />
                </Form.Group>
              </Form.Row>
              <hr />
              <p className="text-danger" id="error-message">
                {error}
              </p>
              <div>
                <ButtonComponent
                  id="add-announcement-bottom"
                  buttonClass="float-right"
                  buttonAction={this.handlePostAnnouncement}
                  icon="report-icon"
                  buttonText={strings.postAnnouncement}
                  hidden={!createAnnouncement.write}
                />
              </div>
            </Form>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  const { announcementReducer, breadcrumbsReducer, clinicsReducer } = state.app;
  return {
    patientTypes: announcementReducer.patientType,
    specialityList: clinicsReducer.speciality,
    filepath: announcementReducer.filepath,
    message: announcementReducer.message,
    breadcrumbs: breadcrumbsReducer.breadcrumbs
  };
};

export default connect(
  mapStateToProps,
  null
)(AddNewAnnouncement);
