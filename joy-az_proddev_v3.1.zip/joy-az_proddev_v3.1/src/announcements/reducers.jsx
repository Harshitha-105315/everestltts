import constants from 'constants.js';
import { setStateByKey } from 'utils/helper.js';

const intialState = {
  announcement: {},
  announcementContents: [],
  patientType: {},
  Announcement: {},
  filepath: '',
  pdfFile: '',
  addAnnouncementStatus: 0,
  showLoader: false,
  updateReadStatusResponse: ''
};
function announcementReducer(state = intialState, action) {
  const tmpState = Object.assign({}, state);
  switch (action.type) {
    case constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_SUCCESS:
      return Object.assign({}, state, {
        announcement: action.announcement,
        announcementContents: action.announcementContents
      });
    case constants.ANNOUNCEMENT.ANNOUNCEMENT_PATIENT_TYPE_SUCCESS:
      return Object.assign({}, state, {
        patientType: action.patientType
      });
    case constants.ANNOUNCEMENT.ANNOUNCEMENT_UPLOAD_PDF_SUCCESS:
      return Object.assign({}, state, {
        filepath: action.filepath
      });
    case constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_BY_ID_SUCCESS:
      tmpState.Announcement = setStateByKey(
        tmpState.Announcement,
        action.key,
        action.Announcement
      );
      return tmpState;
    case constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH_SUCCESS:
      return Object.assign({}, state, {
        announcementList: action.announcementList
      });
    case constants.ANNOUNCEMENT.VIEW_ANNOUNCEMENT_PDF_SUCCESS:
      return Object.assign({}, state, {
        pdfFile: action.message
      });
    case constants.ANNOUNCEMENT.RESET_ANNOUNCEMENT_MESSAGE:
      return Object.assign({}, state, {
        pdfFile: undefined
      });
    case constants.ANNOUNCEMENT.RESET_READ_STATUS_MESSAGE:
      return Object.assign({}, state, {
        updateReadStatusResponse: ""
      });
    case constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT_READ_STATUS_SUCCESS:
      return Object.assign({}, state, {
        updateReadStatusResponse: action.message
      });
    case constants.ANNOUNCEMENT.RESET_ANNOUNCEMENT_FILEPATH:
      return Object.assign({}, state, { filepath: undefined });
    case constants.ANNOUNCEMENT.CLEAR_ANNOUNCEMENT_STATUS:
      return Object.assign({}, state, { addAnnouncementStatus: 0 });
    default:
      return state;
  }
}
export default announcementReducer;
