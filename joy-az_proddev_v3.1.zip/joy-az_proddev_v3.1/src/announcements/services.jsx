
import { authRequest } from 'utils/axios_utils';
import API from 'api/api_config';
import constants from 'constants.js';
import { encryptdata } from 'Cryptocode';

import { getIVSalt, createEncryptedData } from 'utils/utltity';
var AesUtil = require('utils/AesUtil');
function getAnnouncementService(payload) {
  const api = API.GETANNOUNCEMENT;
  let url = '';
  let iv = getIVSalt(),
    salt = getIVSalt(),
    aesUtil = new AesUtil(128, 1000),
    cipheractualRole = aesUtil.encrypt(salt, iv, payload.role.actualRole),
    cipherrole = createEncryptedData([iv, salt, cipheractualRole])

  if (payload.role.actualRole === constants.ROLES.SUPER_ADMIN) {
    url = `${api}?sort_by=${payload.sortBy}&asc=${payload.asc}&userType=${cipherrole
      }`;
  } else {
    url = `${api}?sort_by=${payload.sortBy}&asc=${payload.asc}&userType=${cipherrole

      }&userTypeId=${payload.role.userId}`;
  }
  return authRequest({
    url,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function getAnnouncementPatientService() {
  return authRequest({
    url: API.ANNOUNCEMENTPATIENTTYPE,
    method: 'GET'
  });
}

function uploadAnnouncementPDFService(payload) {
  return authRequest({
    url: API.UPLOADANNOUNCEMENT,
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data'
    },

    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function fetchAnnouncementByIdService(payload) {
  const url = API.ANNOUNCEMENTBYID.replace('{ID}', payload);
  return authRequest({
    url: `${url}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });
}

function updateAnnouncementService(payload) {
  return authRequest({
    url: API.UPDATEANNOUNCEMENT,
    method: 'POST',
    data: payload,
    [constants.RETURNRESPONSE]: true
  });
}

function createAnnouncementService(payload) {
  return authRequest({
    url: API.CREATEANNOUNCEMENT,
    method: 'POST',
    data: payload,
    'x-response': true,
    [constants.RETURNRESPONSE]: true
  });
}

function deleteAnnouncementService(payload) {
  return authRequest({
    url: API.DELETEANNOUNCEMENT.replace('{ID}', payload),
    method: 'POST',
    [constants.RETURNRESPONSE]: true
  });
}

function getPatientAnnouncementService(payload) {
  const { patientId } = payload;
  const url = API.PATIENTANNOUNCEMENT;
  let iv = getIVSalt(),
    salt = getIVSalt(),
    aesUtil = new AesUtil(128, 1000),
    cipheractualRole = aesUtil.encrypt(salt, iv, payload.userData.actualRole),
    cipherrole = createEncryptedData([iv, salt, cipheractualRole])

  return authRequest({
    url: `${url}?sort_by=${payload.sortBy}&asc=${payload.asc}&userType=${cipherrole}&patientId=${patientId}`,
    method: 'GET',
    [constants.RETURNRESPONSE]: true
  });

}

function viewPDFService(payload) {
  return authRequest({
    url: `${API.VIEWPDF}/${payload}`,
    method: 'GET',
    responseType: 'arraybuffer',
    [constants.RETURNRESPONSE]: true
  });
}

function updateReadStatusService(payload) {
  return authRequest({
    url: `${API.UPDATEREADCOUNT}?announcementId=${payload}`,
    method: 'POST',
    [constants.RETURNRESPONSE]: true
  });
}

const AnnouncementService = {
  getAnnouncementService,
  getAnnouncementPatientService,
  uploadAnnouncementPDFService,
  fetchAnnouncementByIdService,
  updateAnnouncementService,
  createAnnouncementService,
  deleteAnnouncementService,
  getPatientAnnouncementService,
  viewPDFService,
  updateReadStatusService
};

export default AnnouncementService;
