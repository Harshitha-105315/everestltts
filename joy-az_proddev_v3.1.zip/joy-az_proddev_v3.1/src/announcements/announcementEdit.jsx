/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Form, Col } from 'react-bootstrap';
import { FootNote } from 'components/FootNote';
import { Header, SideBar } from 'components/Navigation';
import DatePicker from 'react-datepicker';
import moment from 'moment-timezone';
import ConfirmationDialog from 'components/ConfirmationDialog';
import strings from 'localization/strings';
import constants from 'constants.js';
import urls from 'urls';
import accessMatrix from 'rolesData/accessMatrix.js';
import { getUserData } from 'utils/helper';
import { reverse } from 'named-urls';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import ButtonComponent from 'components/ButtonComponent';
import FormControlComponent from 'components/FormControlComponent';
import RouteLeavingGuard from 'components/RouteLeavingGuard';
import { getBreadCrumb, addBreadCrumb, getSpeciality } from '../utils/utltity';

class EditAnnouncement extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      id: '',
      name: '',
      subject: '',
      startDate: '',
      endDate: '',
      sendTo: '',
      clinicType: '',
      clinicSpecialty: 'Specialty',
      pdfFilePath: '',
      patientType: '',
      videoPath: '',
      radioType: 'PDF',
      error: null,
      pdfFile: '',
      isDirty: false,
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleSetCheckBox = this.handleSetCheckBox.bind(this);
    this.validateYouTubeUrl = this.validateYouTubeUrl.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.getBreadCrumb = getBreadCrumb.bind(this);
    this.getSpeciality = getSpeciality.bind(this);
    this.handleDispatchUpdateAnnouncement = this.handleDispatchUpdateAnnouncement.bind(
      this
    );
  }

  componentWillMount() {
    const { dispatch, match } = this.props;
    const { id } = match.params;
    dispatch({
      type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT_BY_ID,
      payload: id
    });
    dispatch({
      type: constants.ANNOUNCEMENT.ANNOUNCEMENT_PATIENT_TYPE
    });
    dispatch({
      type: constants.CLINICS.SPECIALITY_REQUEST
    });
  }

  componentDidMount() {
    this.setScreenSize();
    this.addBreadCrumb({ title: strings.editAnnouncement });
  }

  componentWillReceiveProps(newProps) {
    const { announcement, pdfFile } = newProps;
    this.setState(announcement, () => {
      if (
        announcement.pdfFilePath === '' ||
        announcement.pdfFilePath === null
      ) {
        this.setState({ radioType: 'Video' });
      }
    });
    const { filepath } = newProps;
    if (filepath !== undefined && filepath !== '') {
      this.setState({ pdfFilePath: filepath });
    }
    if (pdfFile !== undefined) {
      this.setState({ pdfFile }, () => {
        if (pdfFile) {
          this.showFile(pdfFile);
          this.dispatchResetAccouncementMsg();
        }
      });
    }
  }

  handleSetStartDate = date => {
    const { endDate } = this.state;
    const from = moment(date);
    this.setState({ startDate: from });
    if (moment(from).isAfter(endDate)) {
      this.setState({ endDate: from });
    }
    this.setState({ isDirty: true });
  };

  handleSetEndDate = date => {
    // this.setState({ endDate: moment(date).format('L'), isDirty: true });
    this.setState({ endDate: moment(date), isDirty: true });
  };

  handleSpecialtyChange = event => {
    this.setState({ clinicType: event.target.value, isDirty: true });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (window.innerWidth < 575) {
        this.setState({ isMobile: true });
        // this.setState({ mobileFlag: true });
      }
    }
  };

  handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value,
      clinicSpecialty: 'Specialty',
      isDirty: true
    });
  };

  handleChangeRadio = event => {
    this.setState({ radioType: event.target.value, isDirty: true });
  };

  uploadPDFFIle = event => {
    const { dispatch } = this.props;

    const formDataVal = new FormData();

    formDataVal.append(
      'uploadfile',
      event.target.files[0],
      event.target.files[0].name
    );

    dispatch({
      type: constants.ANNOUNCEMENT.ANNOUNCEMENT_UPLOAD_PDF,
      payload: formDataVal
    });
    this.setState({ isDirty: true });
  };

  dateConvert = date => {
    const newDate = new Date(date);
    return `${newDate.getFullYear()}-${newDate.getMonth() +
      1}-${newDate.getDate()}`;
  };

  showFile = blob => {
    const newBlob = new Blob([blob], { type: 'application/pdf' });

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(newBlob);
      return;
    }

    const data = window.URL.createObjectURL(newBlob);
    const link = document.createElement('a');
    link.href = data;
    link.target = '_blank';
    link.click();
  };

  handleViewPDF = (event, pdfFilePath) => {
    let splitPath = '';
    splitPath = pdfFilePath.split('/');
    const names = splitPath[splitPath.length - 1];
    const fileName = names.split('.pdf');

    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.VIEW_ANNOUNCEMENT_PDF,
      payload: fileName[0]
    });
  };

  handleUpdateAnnouncement = () => {
    const {
      name,
      subject,
      sendTo,
      patientType,
      pdfFilePath,
      clinicType,
      videoPath,
      radioType
    } = this.state;
    let { startDate, endDate } = this.state;
    startDate = this.dateConvert(startDate);
    endDate = this.dateConvert(endDate);
    this.setState({ error: '' });
    if (name === '') {
      this.setState({ error: strings.announcementTitleRequired });
    } else if (subject === '') {
      this.setState({ error: strings.announcementSubjectRequired });
    } else if (startDate === '') {
      this.setState({ error: strings.announcementStartDateRequired });
    } else if (endDate === '') {
      this.setState({ error: strings.announcementEndDateRequired });
    } else if (sendTo === '') {
      this.setState({ error: strings.sendToRequired });
    } else if (sendTo === 'Clinic' && clinicType === '') {
      this.setState({ error: strings.clinicTypeRequired });
    } else if (sendTo === 'Clinic' && clinicType === 'Specialty') {
      this.setState({ error: strings.specialtyTypeRequired });
    } else if (sendTo === 'Patient' && patientType === '') {
      this.setState({ error: strings.patientTypeRequired });
    } else if (sendTo === 'All' && clinicType === '') {
      this.setState({ error: strings.clinicTypeRequired });
    } else if (sendTo === 'All' && patientType === '') {
      this.setState({ error: strings.patientTypeRequired });
    } else if (
      radioType === 'PDF' &&
      (pdfFilePath === '' || pdfFilePath === null)
    ) {
      this.setState({ error: strings.fileRequired });
    } else if (
      radioType === 'Video' &&
      (videoPath === '' || videoPath === null)
    ) {
      this.setState({ error: strings.videoPathRequired });
    } else {
      const { dialog } = this.state;
      this.setState({
        dialog: Object.assign(dialog, {
          body: strings.updateAnnouncementDialogBody,
          title: strings.updateAnnouncement,
          button: strings.update,
          show: true,
          confirmFunction: this.handleDispatchUpdateAnnouncement
        })
      });
    }
  };

  async handleDispatchUpdateAnnouncement() {
    const { dispatch } = this.props;
    const {
      id,
      name,
      subject,
      sendTo,
      patientType,
      pdfFilePath,
      clinicType,
      videoPath,
      radioType
    } = this.state;
    const {
      dialog: { handleClose }
    } = this.state;
    let { startDate, endDate } = this.state;
    startDate = this.dateConvert(startDate);
    endDate = this.dateConvert(endDate);
    if (radioType === 'PDF') {
      dispatch({
        type: constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT,
        payload: {
          id,
          name,
          subject,
          startDate,
          endDate,
          sentTo: sendTo,
          patientType,
          pdfFilePath,
          clicicType: clinicType
        }
      });
    } else {
      dispatch({
        type: constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT,
        payload: {
          id,
          name,
          subject,
          startDate,
          endDate,
          sentTo: sendTo,
          patientType,
          clicicType: clinicType,
          videoPath
        }
      });
    }
    handleClose();
    await this.setState({ isDirty: false });
  }

  dispatchResetAccouncementMsg() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.RESET_ANNOUNCEMENT_MESSAGE
    });
  }

  async handleSetCheckBox(event) {
    const { sendTo } = this.state;
    if (sendTo !== 'All') {
      if (sendTo !== event.target.value && sendTo !== '') {
        this.setState({ sendTo: 'All' });
      } else if (sendTo !== event.target.value) {
        this.setState({ sendTo: event.target.value });
      } else {
        await this.setState({ sendTo: '' });
        await this.setState({ clinicType: '', patientType: '' });
      }
    } else if (event.target.value === 'Clinic') {
      await this.setState({ sendTo: 'Patient' });
      await this.setState({ clinicType: '', clinicSpecialty: '' });
    } else if (event.target.value === 'Patient') {
      await this.setState({ sendTo: 'Clinic' });
      await this.setState({ patientType: '' });
    }
    this.setState({ isDirty: true });
  }

  async validateYouTubeUrl(event) {
    const expression = /^(http(s)??:\/\/)?(www\.)?((youtube\.com\/embed\/))([a-zA-Z0-9\-_])+/;
    const regex = new RegExp(expression);
    const path = event.target.value;
    if (path.match(regex)) {
      await this.setState({ error: '' });
      await this.setState({ videoPath: path, isDirty: true });
    } else {
      await this.setState({ error: strings.youTubeURLNotValid });
      await this.setState({ videoPath: '' });
    }
  }

  render() {
    const { location, patientTypes, match, breadcrumbs, history } = this.props;
    const { id } = match.params;
    const {
      name,
      subject,
      startDate,
      endDate,
      sendTo,
      patientType,
      pdfFilePath,
      clinicSpecialty,
      clinicType,
      videoPath,
      radioType,
      error,
      dialog,
      isMobile
    } = this.state;
    const { actualRole } = getUserData();
    const announcementInformation =
      accessMatrix.ANNOUNCEMENT_INFORMATION[actualRole];

    const sideBarData = {
      activeKey: location.pathname,
      menu: [
        {
          href: reverse(urls.ANNOUNCEMENT.EDIT, { id }),
          text: strings.editAnnouncement
        }
      ]
    };
    return (
      <div>
        <RouteLeavingGuard
          when={this.state.isDirty}
          navigate={path => history.push(path)}
          shouldBlockNavigation={nextLocation => {
            return location.pathname !== nextLocation.pathname;
          }}
        />
        <Header
          history={history}
          displayScrollBar={isMobile}
          sideBarData={sideBarData}
          prevURL={urls.ANNOUNCEMENT.ALL}
        />
        <MainWrapper>
          <SideBar sideBarData={sideBarData} />
          <MainContent>
            {!isMobile && this.getBreadCrumb(breadcrumbs)}

            <div>
              <ButtonComponent
                id="update-announcement-top"
                buttonClass="float-right"
                buttonAction={this.handleUpdateAnnouncement}
                hidden={!announcementInformation.write || isMobile}
                icon="report-icon"
                buttonText={strings.updateAnnouncement}
              />
            </div>
            <div className="d-flex flex-wrap">
              <h1 className="d-none d-sm-block text-capitalize">
                {strings.editAnnouncement}
              </h1>
              <h1 className="d-none d-sm-block d-md-none d-inline text-capitalize">
                {strings.announcementDetail}
              </h1>
            </div>
            <h6 className="d-none d-sm-block text-capitalize">
              {strings.announcementDetail}
            </h6>
            <p className="text-danger">{error}</p>
            <Form>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.announcementTitle} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <Form.Control
                    type="text"
                    className="text-capitalize"
                    placeholder={strings.announcementTitle}
                    name="name"
                    onChange={this.handleChange}
                    defaultValue={name || ''}
                    required=""
                    readOnly={!announcementInformation.write || isMobile}
                  />
                </Form.Group>
              </Form.Row>

              <Form.Row>
                <Form.Group as={Col} md={8}>
                  <Form.Label htmlFor="reset">{strings.subject} <span className="asterisk-color">*</span></Form.Label>

                  <Form.Control
                    name="subject"
                    as="textarea"
                    value={subject || ''}
                    className="text-capitalize"
                    placeholder={strings.subject}
                    onChange={this.handleChange}
                    required=""
                    rows="5"
                    readOnly={!announcementInformation.write || isMobile}
                  />
                </Form.Group>
              </Form.Row>
              <Form.Row>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">{strings.startDate} <span className="asterisk-color">*</span></Form.Label>
                  <br />
                  {startDate && (
                    <DatePicker
                      className="custom-select"
                      name="startDate"
                      minDate={new Date()}
                      dateFormat="MMM d, yyyy"
                      selected={new Date(Date.parse(moment(startDate)))}
                      onChange={this.handleSetStartDate}
                      disabled={!announcementInformation.write || isMobile}
                    />
                  )}
                </Form.Group>
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">{strings.endDate} <span className="asterisk-color">*</span></Form.Label>
                  <br />
                  {endDate && (
                    <DatePicker
                      className="custom-select"
                      name="endDate"
                      minDate={new Date(Date.parse(moment(startDate)))}
                      dateFormat="MMM d, yyyy"
                      selected={new Date(Date.parse(moment(endDate)))}
                      onChange={this.handleSetEndDate}
                      disabled={!announcementInformation.write || isMobile}
                    />
                  )}
                </Form.Group>
              </Form.Row>
              <hr />
              <h6 className="text-capitalize">{strings.sendTo}</h6>
              {isMobile && (
                <p className="text-capitalize mobile-announcement-view">
                  {strings.clinic}
                </p>
              )}
              <Form.Row className="send-to align-items-center">
                <Form.Check
                  custom
                  className="filter-checkbox d-none d-sm-block"
                  id="Clinic"
                  type="checkbox"
                  label={strings.clinic}
                  name="sendTo"
                  value="Clinic"
                  checked={sendTo === 'Clinic' || sendTo === 'All'}
                  onChange={this.handleSetCheckBox}
                  inline
                  disabled={!announcementInformation.write}
                />
                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.clinicType} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <Form.Control
                    className="custom-select"
                    as="select"
                    name="clinicType"
                    value={
                      clinicType !== '' &&
                        clinicType !== null &&
                        clinicType === 'All'
                        ? clinicType || ''
                        : clinicType !== '' &&
                        clinicType !== null &&
                        clinicSpecialty
                    }
                    disabled={
                      sendTo === '' ||
                      sendTo === 'Patient' ||
                      isMobile ||
                      !announcementInformation.write
                    }
                    onChange={this.handleChange}
                    required=""
                  >
                    <option value="" />
                    <option value="All" label="All">
                      {strings.all}
                    </option>
                    <option value="Specialty" label="Specialty">
                      {strings.specialty}
                    </option>
                  </Form.Control>
                </Form.Group>

                {clinicType !== 'All' && clinicType !== '' && (
                  <Form.Group as={Col} md={4}>
                    <Form.Label htmlFor="reset">
                      {strings.specialityType} <span className="asterisk-color">*</span>
                    </Form.Label>
                    <Form.Control
                      className="custom-select"
                      as="select"
                      name="clinicType"
                      placeholder={strings.select}
                      value={clinicType || ''}
                      onChange={this.handleSpecialtyChange}
                      required=""
                      disabled={!announcementInformation.write || isMobile}
                    >
                      <option value="">{strings.selectSpeciality}</option>
                      {this.getSpeciality()}
                    </Form.Control>
                  </Form.Group>
                )}
              </Form.Row>
              {isMobile && (
                <p className="text-capitalize mobile-announcement-view">
                  {strings.patient}
                </p>
              )}
              <Form.Row className="send-to align-items-center">
                <Form.Check
                  custom
                  className="filter-checkbox d-none d-sm-block"
                  id="Patient"
                  type="checkbox"
                  label={strings.patient}
                  name="sendTo"
                  value="Patient"
                  checked={sendTo === 'Patient' || sendTo === 'All'}
                  onChange={this.handleSetCheckBox}
                  inline
                  disabled={!announcementInformation.write}
                />

                <Form.Group as={Col} md={4}>
                  <Form.Label htmlFor="reset">
                    {strings.patientType} <span className="asterisk-color">*</span>
                  </Form.Label>
                  <Form.Control
                    className="custom-select"
                    as="select"
                    name="patientType"
                    placeholder={strings.select}
                    disabled={
                      sendTo === '' ||
                      sendTo === 'Clinic' ||
                      isMobile ||
                      !announcementInformation.write
                    }
                    value={patientType}
                    onChange={this.handleChange}
                    required=""
                  >
                    <option value="" />
                    {patientTypes &&
                      patientTypes.typeCode !== undefined &&
                      patientTypes.typeCode.map(patient => (
                        <option key={patient.id} value={patient.type_code}>
                          {patient.type_code_value}
                        </option>
                      ))}
                  </Form.Control>
                </Form.Group>
              </Form.Row>
              <hr />
              {!isMobile && (
                <div>
                  <h6 className="text-capitalize">
                    {strings.uploadAttachments}
                  </h6>
                  <Form.Row className="align-items-center">
                    <Form.Group id="upload-pdf-block">
                      <Form.Check
                        inline
                        custom
                        className="filter-checkbox"
                        type="radio"
                        value="PDF"
                        label={strings.PDF}
                        checked={radioType === 'PDF'}
                        onChange={this.handleChangeRadio}
                        name="PDF"
                        id="PDF"
                        disabled={!announcementInformation.write}
                      />
                      <Form.Label id="upload-pdf-label" htmlFor="file-upload">
                        <ButtonComponent
                          buttonClass="float-right"
                          disabled={radioType !== 'PDF'}
                          icon="report-detail-icon"
                          buttonText={strings.uploadPDFFIle}
                        />
                      </Form.Label>

                      <input
                        type="file"
                        id="file-upload"
                        ref={input => {
                          this.filesInput = input;
                        }}
                        placeholder={strings.onlyPDF}
                        accept=".pdf"
                        name="uploadfile"
                        onChange={this.uploadPDFFIle}
                        disabled={
                          !announcementInformation.write || radioType !== 'PDF'
                        }
                      />
                      {pdfFilePath}
                    </Form.Group>
                  </Form.Row>
                  <Form.Row
                    className="align-items-center"
                    id="upload-video-block"
                  >
                    <Form.Check
                      inline
                      custom
                      className="filter-checkbox"
                      id="Video"
                      type="radio"
                      value="Video"
                      label={strings.video}
                      onChange={this.handleChangeRadio}
                      name="Video"
                      checked={radioType === 'Video'}
                      disabled={!announcementInformation.write}
                    />

                    <Form.Group as={Col} md={4}>
                      <Form.Label htmlFor="reset">
                        {strings.videoURL}
                      </Form.Label>
                      <FormControlComponent
                        type="text"
                        name="videoPath"
                        placeholder={strings.pasteVideoURL}
                        onChange={this.validateYouTubeUrl}
                        defaultValue={videoPath || ''}
                        disabled={radioType !== 'Video'}
                        readOnly={!announcementInformation.write}
                      />
                    </Form.Group>
                  </Form.Row>
                </div>
              )}
              {isMobile && (
                <div>
                  <h6 className="text-capitalize section-heading">
                    {strings.attachments}
                  </h6>

                  <div className="mobile-view-pdf">
                    <p className="text-uppercase mobile-announcement-view">
                      {strings.PDF}
                    </p>
                    <ButtonComponent
                      id="view-pdf"
                      buttonClass="view-pdf-button"
                      buttonAction={e => this.handleViewPDF(e, pdfFilePath)}
                      disabled={pdfFilePath === '' || pdfFilePath === null}
                      icon="view-pdf-mobile"
                      buttonText={strings.viewPDFFile}
                    />
                  </div>
                  <div>
                    <p className="text-capitalize mobile-announcement-view">
                      {strings.video}
                    </p>
                    <Form.Row>
                      <Form.Group as={Col} md={4}>
                        <Form.Label htmlFor="reset">
                          {strings.videoURL}
                        </Form.Label>
                        <FormControlComponent
                          type="text"
                          name="videoPath"
                          placeholder={strings.pasteVideoURL}
                          onChange={this.validateYouTubeUrl}
                          defaultValue={videoPath || ''}
                          disabled={radioType !== 'Video'}
                          readOnly={!announcementInformation.write || isMobile}
                        />
                      </Form.Group>
                    </Form.Row>
                  </div>
                </div>
              )}
              <hr />
              <p className="text-danger" id="error-message">
                {error}
              </p>
              <div>
                <ButtonComponent
                  id="update-announcement-top"
                  buttonClass="float-right"
                  buttonAction={this.handleUpdateAnnouncement}
                  hidden={!announcementInformation.write || isMobile}
                  icon="report-icon"
                  buttonText={strings.updateAnnouncement}
                />
              </div>
            </Form>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const { announcementReducer, breadcrumbsReducer, clinicsReducer } = state.app;
  const { match } = ownProps;
  const { id } = match.params;
  return {
    patientTypes: announcementReducer.patientType,
    specialityList: clinicsReducer.speciality,
    announcement: announcementReducer.Announcement[id] || {},
    filepath: announcementReducer.filepath,
    breadcrumbs: breadcrumbsReducer.breadcrumbs,
    pdfFile: state.app.announcementReducer.pdfFile
  };
};

export default connect(
  mapStateToProps,
  null
)(EditAnnouncement);
