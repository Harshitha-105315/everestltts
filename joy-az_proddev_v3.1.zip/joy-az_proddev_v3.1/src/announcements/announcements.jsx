/* eslint-disable jsx-a11y/iframe-has-title */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import moment from 'moment-timezone';
import { Modal, Row, Col, Image } from 'react-bootstrap';
import Pagination from 'react-js-pagination';
import { reverse } from 'named-urls';
import urls from 'urls';
import { isEmpty } from 'lodash';
import { Header, SideBar } from 'components/Navigation';
import TableDisplay from 'components/TableDisplay';
import strings from 'localization/strings';
import { getUserData } from 'utils/helper';
import accessMatrix from 'rolesData/accessMatrix.js';
import Close from 'assets/img/ic-close-big-white.svg';
import constants from 'constants.js';
import ConfirmationDialog from 'components/ConfirmationDialog';
import trash from 'assets/icn-delete.svg';
import edit from 'assets/edit.svg';
import view from 'assets/view.svg';
import { FootNote } from 'components/FootNote';
import { uid } from 'react-uid';
import MainContent from 'components/MainContentDisplay';
import MainWrapper from 'components/MainWrapperDisplay';
import { addBreadCrumb, clearBreadCrumb } from '../utils/utltity';
import './announcement.scss';
import ButtonComponent from 'components/ButtonComponent';

class Announcements extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMobile: false,
      page: 1,
      perPage: 10,
      asc: true,
      sortBy: 'modifiedDate',
      contents: [],
      announcement: {},
      announcementListContents: [],
      announcementList: {},
      pdfFile: '',
      updateReadStatusResponse: '',
      filterOn: false,
      show: false,
      videoUrl: '',
      announcementStatus: 'all',
      viewAsUser: false,
      role: '',
      dialog: {
        show: false,
        body: '',
        title: '',
        button: '',
        handleClose: () => {
          const { dialog } = this.state;
          this.setState({
            dialog: Object.assign(dialog, {
              show: false
            })
          });
        }
      }
    };
    this.handleSorting = this.handleSorting.bind(this);
    this.handlePaginate = this.handlePaginate.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.filterCheck = this.filterCheck.bind(this);
    this.resetFilter = this.resetFilter.bind(this);
    this.addBreadCrumb = addBreadCrumb.bind(this);
    this.clearBreadCrumb = clearBreadCrumb.bind(this);
  }

  componentWillMount() {
    const userData = getUserData();
    if (userData.actualRole === constants.ROLES.PATIENT) {
      this.dispatchForPatientAnnouncement(userData);
    } else {
      this.dispatchForAnnouncement(userData);
    }
    this.clearBreadCrumb();
  }

  componentDidMount() {
    this.setScreenSize();
  }

  componentWillReceiveProps(newProps) {
    const {
      announcementContents,
      announcement,
      announcementList,
      pdfFile,
      updateReadStatusResponse
    } = newProps;
    const userData = getUserData();
    this.setState({ role: userData.role });
    if (updateReadStatusResponse !== '' && updateReadStatusResponse !== undefined) {
      if (userData.actualRole === constants.ROLES.PATIENT) {
        this.dispatchForPatientAnnouncement(userData);
      } else {
        this.dispatchForAnnouncement(userData);
      }
      this.dispatchResetReadStatusMsg();
    }
    if (announcementContents !== undefined) {
      if (
        userData.actualRole !== constants.ROLES.PATIENT &&
        userData.actualRole !== constants.ROLES.SUPER_ADMIN &&
        userData.actualRole !== constants.ROLES.CUSTOMER_SERVICES
      ) {
        const contents = Object.keys(announcementContents).map(key => {
          return announcementContents[key];
        });
        this.setState({ announcementListContents: contents });
      } else {
        this.setState({ contents: announcementContents });
      }
    }
    if (announcement !== undefined) {
      this.setState({ announcement });
    }
    if (announcementList !== undefined) {
      this.setState({ announcementListContents: announcementList.content });
    }
    if (announcementList !== undefined) {
      this.setState({ announcementList });
    }
    if (pdfFile !== undefined) {
      this.setState({ pdfFile }, () => {
        if (pdfFile) {
          this.showFile(pdfFile);
          this.dispatchResetAccouncementMsg();
        }
      });
    }
  }

  dispatchForAnnouncement = role => {
    const { dispatch } = this.props;
    const { perPage, page, asc, sortBy } = this.state;
    dispatch({
      type: constants.ANNOUNCEMENT.FETCH_ANNOUNCEMENT,
      payload: { perPage, page, asc, sortBy, role }
    });
  };

  dispatchForPatientAnnouncement = userData => {
    const { dispatch } = this.props;
    const { perPage, page } = this.state;
    dispatch({
      type: constants.ANNOUNCEMENT.PATIENT_ANNOUNCEMENT_FETCH,
      payload: {
        perPage,
        page,
        asc: false,
        sortBy: 'modified_date',
        userData
      }
    });
  };

  getActiveDate = date => {
    return moment(date).format('DD MMM, YYYY');
  };

  handleRemoveAnnouncement = (e, id) => {
    const { dialog } = this.state;
    this.setState({
      dialog: Object.assign(dialog, {
        show: true,
        body: strings.deleteAnnouncementDialogBody,
        title: strings.deleteAnnouncement,
        button: strings.delete,
        id,
        confirmFunction: this.handleDeleteAnnouncement
      })
    });
  };

  handleDeleteAnnouncement = () => {
    const { dispatch } = this.props;
    const { dialog } = this.state;
    const { id } = dialog;
    const userData = getUserData();
    const { asc, perPage, page, sortBy } = this.state;
    dispatch({
      type: constants.ANNOUNCEMENT.DELETE_ANNOUNCEMENT,
      allData: { id, userData, asc, perPage, page, sortBy }
    });
    this.setState({
      dialog: Object.assign(dialog, {
        show: false
      })
    });
  };

  handleWatchVideo = (event, videoPath, id, isUpdateReadStatus) => {
    const { dispatch } = this.props;
    this.setState({ show: true, videoUrl: videoPath });
    if (isUpdateReadStatus) {
      dispatch({
        type: constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT_READ_STATUS,
        payload: id
      });
    }
  };

  showFile = blob => {
    const newBlob = new Blob([blob], { type: 'application/pdf' });

    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(newBlob);
      return;
    }

    const data = window.URL.createObjectURL(newBlob);
    const link = document.createElement('a');
    link.href = data;
    link.target = '_blank';
    link.click();
  };

  async handleViewAsUser() {
    this.setState({ viewAsUser: !this.state.viewAsUser });
    await this.setState({ page: 1 });
  }

  viewAsUserContents = () => {
    const { page, perPage } = this.state;
    const indexOfLastAnnouncement = page * perPage;
    const indexOfFirstAnnouncement = indexOfLastAnnouncement - perPage;
    const contentList = this.contentFilter().slice(
      indexOfFirstAnnouncement,
      indexOfLastAnnouncement
    );
    return contentList;
  }

  handleViewPDF = (event, pdfFilePath, id, isUpdateReadStatus) => {
    let splitPath = '';
    splitPath = pdfFilePath.split('/');
    const names = splitPath[splitPath.length - 1];
    const fileName = names.split('.pdf');

    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.VIEW_ANNOUNCEMENT_PDF,
      payload: fileName[0]
    });
    if (isUpdateReadStatus) {
      dispatch({
        type: constants.ANNOUNCEMENT.UPDATE_ANNOUNCEMENT_READ_STATUS,
        payload: id
      });
    }
  };

  dateChecker = modifiedDate => {
    const lastDate = new Date(modifiedDate);
    const newDate = new Date();
    return (
      lastDate.getFullYear() === newDate.getFullYear() &&
      lastDate.getMonth() === newDate.getMonth() &&
      lastDate.getDate() === newDate.getDate()
    );
  };

  handleClose = () => {
    this.setState({ show: false });
  };

  setScreenSize = () => {
    const { isMobile } = this.state;
    if (!isMobile) {
      if (document.documentElement.clientWidth <= 575) {
        this.setState({ isMobile: true });
      }
    }
  };

  contentFilter = () => {
    const { contents } = this.state;
    let contentFilters = contents;
    const { announcementStatus } = this.state;
    if (announcementStatus === constants.FILTER_VALUES.EXPIRED) {
      contentFilters = contentFilters.filter(function filterExpired(obj) {
        return new Date() > new Date(obj.announcement.endDate);
      });
    }
    if (announcementStatus === constants.FILTER_VALUES.ONGOING) {
      contentFilters = contentFilters.filter(function filterOngoing(obj) {
        return (
          new Date() > new Date(obj.announcement.startDate) &&
          new Date() < new Date(obj.announcement.endDate)
        );
      });
    }
    // return contentFilters.sort((a, b) => a.announcement.modifiedDate < b.announcement.modifiedDate ? 1 : -1);
    return contentFilters;
  };

  listContent = flag => {
    const { page, perPage, isMobile } = this.state;
    const indexOfLastAnnouncement = page * perPage;
    const indexOfFirstAnnouncement = indexOfLastAnnouncement - perPage;
    const contentList = this.contentFilter().slice(
      indexOfFirstAnnouncement,
      indexOfLastAnnouncement
    );
    const { history } = this.props;
    if (!isEmpty(contentList)) {
      return contentList.map((content, key) => (
        <tr
          key={uid(content)}
          onClick={() => {
            if (isMobile) {
              history.push(reverse(urls.ANNOUNCEMENT.EDIT, { id: content.announcement.id }));
            }
          }}
        >
          <td id="name-announcement">
            {content.announcement.name}
            <p className="secondary-data d-sm-none">{content.announcement.subject}</p>
          </td>
          <td id="subject-announcement" className="d-none d-sm-table-cell">
            {content.announcement.subject}
          </td>
          <td id="start-date-announcement" className="d-none d-sm-table-cell">
            {this.getActiveDate(content.announcement.startDate)}
          </td>
          <td id="end-date-announcement" className="d-none d-sm-table-cell">
            {this.getActiveDate(content.announcement.endDate)}
          </td>
          <td id="view-count-announcement" className="d-none d-sm-table-cell" style={{ width: '100%' }}>
            {content.viewCount}
          </td>

          {
            <td id="icon-announcement" className="d-none d-sm-table-cell">
              <Link
                id="edit-icon"
                to={reverse(urls.ANNOUNCEMENT.EDIT, { id: content.announcement.id })}
                onClick={() => {
                  this.addBreadCrumb({ title: strings.manageAnnouncements });
                }}
              >
                {
                  flag ?
                    <input
                      type="image"
                      src={edit}
                      style={{ marginRight: '0.3rem' }}
                      width="12"
                      height="12"
                      className="d-inline-block"
                      alt="edit"
                    />
                    :
                    <input
                      type="image"
                      src={view}
                      style={{ marginRight: '0.3rem' }}
                      width="12"
                      height="12"
                      className="d-inline-block"
                      alt="view"
                    />
                }
              </Link>
              {flag && (
                <input
                  type="image"
                  src={trash}
                  style={{ marginRight: '0.3rem' }}
                  width="14"
                  height="14"
                  alt="delete"
                  onClick={e => this.handleRemoveAnnouncement(e, content.announcement.id)}
                />
              )}
            </td>
          }
        </tr>
      ));
    }
    return (
      <tr>
        <td colSpan="5" className="text-center">
          {strings.noAnnouncement}
        </td>
      </tr>
    );
  };

  announcementListContentFilter = () => {
    let { announcementListContents } = this.state;
    const { announcementStatus } = this.state;
    const newDate = new Date();
    if (announcementStatus === constants.FILTER_VALUES.NEW) {
      announcementListContents = announcementListContents.filter(
        function filterNew(obj) {
          const lastDate = new Date(obj.announcement.modifiedDate);
          return (
            lastDate.getFullYear() === newDate.getFullYear() &&
            lastDate.getMonth() === newDate.getMonth() &&
            lastDate.getDate() === newDate.getDate()
          );
        }
      );
    }
    // return announcementListContents.sort((a, b) => a.announcement.startDate < b.announcement.startDate ? 1 : -1) || [];
    return announcementListContents || [];
  };

  announcementContentList = () => {
    const { page, perPage } = this.state;
    const indexOfLastAnnouncement = page * perPage;
    const indexOfFirstAnnouncement = indexOfLastAnnouncement - perPage;
    const contentList = this.announcementListContentFilter().slice(
      indexOfFirstAnnouncement,
      indexOfLastAnnouncement
    );
    return contentList;
  };

  async resetFilter() {
    await this.setState({ announcementStatus: 'all', filterOn: false });
  }

  async filterCheck() {
    const { announcementStatus } = this.state;
    if (announcementStatus !== constants.FILTER_VALUES.ALL) {
      await this.setState({ filterOn: true });
    } else if (
      announcementStatus === constants.FILTER_VALUES.ALL ||
      announcementStatus === null
    ) {
      await this.setState({ filterOn: false });
    }
  }

  async handleFilter(event) {
    await this.setState({
      [event.target.name]: event.target.value,
      page: 1
    });
    this.filterCheck();
  }

  dispatchResetAccouncementMsg() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.RESET_ANNOUNCEMENT_MESSAGE
    });
  }

  dispatchResetReadStatusMsg() {
    const { dispatch } = this.props;
    dispatch({
      type: constants.ANNOUNCEMENT.RESET_READ_STATUS_MESSAGE
    });
  }

  async handlePaginate(pageNumber) {
    await this.setState({ page: pageNumber });
  }

  async handleSorting(event) {
    const { asc, sortBy } = this.state;
    const { name } = event.target;
    await this.setState({ page: 1 });
    if (sortBy !== name) {
      await this.setState({ sortBy: name });
      await this.setState({ asc: true });
    } else {
      await this.setState({ asc: !asc });
    }
    const userData = getUserData();
    this.dispatchForAnnouncement(userData);
  }

  render() {
    const {
      page,
      perPage,
      show,
      videoUrl,
      announcementStatus,
      dialog,
      isMobile,
      filterOn,
      viewAsUser
    } = this.state;
    const { history } = this.props;
    const { actualRole } = getUserData();
    const createAnnouncement = accessMatrix.CREATE_ANNOUNCEMENT[actualRole];
    const announcementInformation =
      accessMatrix.ANNOUNCEMENT_INFORMATION[actualRole];
    const searchAnnouncement = accessMatrix.SEARCH_ANNOUNCEMENTS[actualRole];
    const tableHeading = [
      {
        text: strings.title,
        sortable: true,
        name: 'name',
        value: 'name'
      },
      {
        text: strings.subject,
        sortable: true,
        name: 'subject',
        value: 'subject',
        mobile: false
      },
      {
        text: strings.startsOn,
        sortable: true,
        name: 'startDate',
        value: 'startDate',
        mobile: false
      },
      {
        text: strings.endsOn,
        sortable: true,
        name: 'endDate',
        value: 'endDate',
        mobile: false
      },
      {
        text: strings.views,
        // sortable: true,
        name: 'viewCount',
        value: 'viewCount',
        mobile: false
      }
    ];

    if (announcementInformation.read) {
      tableHeading.push({
        text: strings.options,
        name: 'options',
        value: 'options',
        mobile: false
      });
    }

    return (
      <div>
        <Header noSearch />
        <MainWrapper>
          <SideBar
            filters={
              searchAnnouncement.read
                ? {
                  Status: [
                    {
                      title: strings.all,
                      name: constants.FILTER_NAME.ANNOUNCEMENT_STATUS,
                      value: constants.FILTER_VALUES.ALL,
                      type: constants.FILTER_TYPE.RADIO,
                      onChangeFunction: this.handleFilter,
                      checked:
                        announcementStatus === constants.FILTER_VALUES.ALL
                          ? true
                          : null
                    },
                    {
                      title: strings.ongoing,
                      name: constants.FILTER_NAME.ANNOUNCEMENT_STATUS,
                      value: constants.FILTER_VALUES.ONGOING,
                      type: constants.FILTER_TYPE.RADIO,
                      onChangeFunction: this.handleFilter,
                      checked:
                        announcementStatus === constants.FILTER_VALUES.ONGOING
                          ? true
                          : null
                    },
                    {
                      title: strings.expired,
                      name: constants.FILTER_NAME.ANNOUNCEMENT_STATUS,
                      value: constants.FILTER_VALUES.EXPIRED,
                      type: constants.FILTER_TYPE.RADIO,
                      onChangeFunction: this.handleFilter,
                      checked:
                        announcementStatus === constants.FILTER_VALUES.EXPIRED
                          ? true
                          : null
                    }
                  ]
                }
                : {
                  Status: [
                    {
                      title: strings.all,
                      name: constants.FILTER_NAME.ANNOUNCEMENT_STATUS,
                      value: constants.FILTER_VALUES.ALL,
                      type: constants.FILTER_TYPE.RADIO,
                      onChangeFunction: this.handleFilter,
                      checked:
                        announcementStatus === constants.FILTER_VALUES.ALL
                          ? true
                          : null,
                      defaultValue: true
                    },
                    {
                      title: strings.new,
                      name: constants.FILTER_NAME.ANNOUNCEMENT_STATUS,
                      value: constants.FILTER_VALUES.NEW,
                      type: constants.FILTER_TYPE.RADIO,
                      onChangeFunction: this.handleFilter,
                      checked:
                        announcementStatus === constants.FILTER_VALUES.NEW
                          ? true
                          : null
                    }
                  ]
                }
            }
            resetFilter={this.resetFilter}
            filterOn={filterOn}
          />
          <MainContent>
            {searchAnnouncement.read && (
              <div className="d-flex flex-wrap">
                {viewAsUser ?
                  <h1 className="text-capitalize">
                    {strings.announcements}
                  </h1>
                  :
                  <h1 className="text-capitalize">
                    {strings.manageAnnouncements}
                  </h1>
                }
                <div className="breaker" />
                <p className="mobile-table-count d-sm-none text-capitalize">
                  {this.contentFilter().length} {strings.announcements}
                </p>
                {!isMobile && viewAsUser && (
                  <ButtonComponent
                    id="new-announcement-top"
                    buttonClass={`d-none ${createAnnouncement.write ? 'd-sm-block' : ''
                      } float-right ml-auto overview-button`}
                    buttonAction={() => {
                      this.handleViewAsUser();
                    }}
                    icon="report-user-icon"
                    buttonText={strings.viewAsAdmin}
                    hidden={!createAnnouncement.write}
                  />)}
                {!isMobile && !viewAsUser && (<ButtonComponent
                  id="new-announcement-top"
                  buttonClass={`d-none ${createAnnouncement.write ? 'd-sm-block' : ''
                    } float-right view-as-user-alignment overview-button`}
                  buttonAction={() => {
                    this.handleViewAsUser();
                  }}
                  icon="report-user-icon"
                  buttonText={strings.viewAsUser}
                  hidden={!createAnnouncement.write}
                />
                )}
                {!isMobile && !viewAsUser && (
                  <ButtonComponent
                    id="new-announcement-top"
                    buttonClass={`d-none ${createAnnouncement.write ? 'd-sm-block' : ''
                      } float-right ml-auto overview-button`}
                    buttonAction={() => {
                      this.addBreadCrumb({
                        title: strings.manageAnnouncements
                      });
                      history.push(urls.ANNOUNCEMENT.ADD);
                    }}
                    icon="report-icon"
                    buttonText={strings.newAnnouncement}
                    hidden={!createAnnouncement.write}
                  />
                )}
              </div>
            )}

            {searchAnnouncement.read && !viewAsUser && (
              <div>
                <TableDisplay
                  heading={tableHeading}
                  listing={this.listContent(createAnnouncement.write)}
                  handleSorting={this.handleSorting}
                  handlePaginate={this.handlePaginate}
                  perPage={perPage}
                  page={page}
                  totalDisplayLabel={strings.announcements}
                  totalUsers={this.contentFilter().length}
                  pagination
                />
              </div>
            )}

            {searchAnnouncement.read && viewAsUser &&
              this.viewAsUserContents().map((s, key) => (
                <div key={uid(s)} className="user-list card announcement-box unread-highlight">
                  <div className="content">
                    {!isMobile && (
                      <div>
                        <Row as={Col}>
                          {this.dateChecker(s.announcement.modifiedDate) ? (
                            <div
                              id="check-color"
                              className="green-active d-inline-block"
                            />
                          ) : (
                              <div className="blank-dot" />
                            )}
                          <h6 className="text-capitalize">
                            {s.announcement.name}
                          </h6>
                        </Row>
                        <div className="announcement-table-subject">
                          {s.announcement.subject}
                        </div>
                      </div>
                    )}

                    {isMobile && (
                      <div className="mobile-content">
                        <Row as={Col}>
                          {this.dateChecker(s.announcement.modifiedDate) && (
                            <div
                              id="check-color"
                              className="green-active d-inline-block"
                            />
                          )}
                          <div className="text-capitalize announcement-mobile-title">
                            {s.announcement.name}
                          </div>
                        </Row>
                        <div className="announcement-mobile-subject">
                          {s.announcement.subject}
                        </div>
                      </div>
                    )}

                    <div className="justify-content-end">
                      {s.announcement.pdfFilePath !== '' && s.announcement.pdfFilePath !== null ? (
                        <ButtonComponent
                          id="view-pdf"
                          buttonClass={`float-right ${!s.readStatus
                            ? 'read-status-btn'
                            : ''
                            }`}
                          buttonAction={e =>
                            this.handleViewPDF(e, s.announcement.pdfFilePath, s.announcement.id, false)
                          }
                          icon="view-pdf"
                          buttonText={strings.viewPDFFile}
                        />
                      ) : (
                          <ButtonComponent
                            id="watch-video"
                            buttonClass={`float-right ${!s.readStatus
                              ? 'read-status-btn'
                              : ''
                              }`}
                            buttonAction={e =>
                              this.handleWatchVideo(e, s.announcement.videoPath, s.announcement.id, false)
                            }
                            icon="watch-video"
                            buttonText={strings.watchVideo}
                          />
                        )}
                    </div>
                  </div>
                  {isMobile && <hr className="mobile-bottom-hr" />}
                </div>
              ))
            }

            {searchAnnouncement.read && viewAsUser && (
              <div
                className={`listing-pagination d-flex ${isMobile
                  ? 'justify-content-center'
                  : 'justify-content-between'
                  }`}
              >
                {!isMobile && (
                  <h6 className="d-inline text-capitalize">
                    {`${this.contentFilter().length || 0}
                  ${strings.announcements}`}
                  </h6>
                )}

                <nav aria-label="..." className="float-right">
                  <Pagination
                    activePage={page}
                    prevPageText="PREV"
                    nextPageText="NEXT"
                    linkClass="page-link"
                    activeLinkClass=""
                    itemClass="page-item"
                    itemsCountPerPage={perPage}
                    totalItemsCount={
                      this.contentFilter().length
                    }
                    pageRangeDisplayed={3}
                    onChange={this.handlePaginate}
                    firstPageText="FIRST"
                    lastPageText="LAST"
                  />
                </nav>
              </div>
            )}

            {!searchAnnouncement.read && (
              <div>
                <div className="d-flex flex-wrap">
                  <h1 className="text-capitalize">{strings.announcements}</h1>
                  <div className="breaker" />
                  <p className="mobile-table-count d-sm-none text-capitalize">
                    {` ${this.announcementListContentFilter().length}${' '}
                      ${strings.announcements}`}
                  </p>
                </div>
                {isMobile && <hr />}
              </div>
            )}

            {!searchAnnouncement.read &&
              this.announcementContentList().map((s, key) => (
                <div key={uid(s)} className={`user-list card announcement-box ${!s.readStatus
                  ? 'unread-highlight'
                  : ''
                  }`}>
                  <div className="content">
                    {!isMobile && (
                      <div>
                        <Row as={Col}>
                          {this.dateChecker(s.announcement.modifiedDate) ? (
                            <div
                              id="check-color"
                              className="green-active d-inline-block"
                            />
                          ) : (
                              <div className="blank-dot" />
                            )}
                          <h6 className="text-capitalize">
                            {s.announcement.name}
                          </h6>
                        </Row>
                        <div className="announcement-table-subject">
                          {s.announcement.subject}
                        </div>
                      </div>
                    )}

                    {isMobile && (
                      <div className="mobile-content">
                        <Row as={Col}>
                          {this.dateChecker(s.announcement.modifiedDate) && (
                            <div
                              id="check-color"
                              className="green-active d-inline-block"
                            />
                          )}
                          <div className="text-capitalize announcement-mobile-title">
                            {s.announcement.name}
                          </div>
                        </Row>
                        <div className="announcement-mobile-subject">
                          {s.announcement.subject}
                        </div>
                      </div>
                    )}

                    <div className="justify-content-end">
                      {s.announcement.pdfFilePath !== '' && s.announcement.pdfFilePath !== null ? (
                        <ButtonComponent
                          id="view-pdf"
                          buttonClass={`float-right ${!s.readStatus
                            ? 'read-status-btn'
                            : ''
                            }`}
                          buttonAction={e =>
                            this.handleViewPDF(e, s.announcement.pdfFilePath, s.announcement.id, !s.readStatus)
                          }
                          icon="view-pdf"
                          buttonText={strings.viewPDFFile}
                        />
                      ) : (
                          <ButtonComponent
                            id="watch-video"
                            buttonClass={`float-right ${!s.readStatus
                              ? 'read-status-btn'
                              : ''
                              }`}
                            buttonAction={e =>
                              this.handleWatchVideo(e, s.announcement.videoPath, s.announcement.id, !s.readStatus)
                            }
                            icon="watch-video"
                            buttonText={strings.watchVideo}
                          />
                        )}
                    </div>
                  </div>
                  {isMobile && <hr className="mobile-bottom-hr" />}
                </div>
              ))}
            {!searchAnnouncement.read && (
              <div
                className={`listing-pagination d-flex ${isMobile
                  ? 'justify-content-center'
                  : 'justify-content-between'
                  }`}
              >
                {!isMobile && (
                  <h6 className="d-inline text-capitalize">
                    {`${this.announcementListContentFilter().length || 0}
                  ${strings.announcements}`}
                  </h6>
                )}

                <nav aria-label="..." className="float-right">
                  <Pagination
                    activePage={page}
                    prevPageText="PREV"
                    nextPageText="NEXT"
                    linkClass="page-link"
                    activeLinkClass=""
                    itemClass="page-item"
                    itemsCountPerPage={perPage}
                    totalItemsCount={
                      this.announcementListContentFilter().length
                    }
                    pageRangeDisplayed={3}
                    onChange={this.handlePaginate}
                    firstPageText="FIRST"
                    lastPageText="LAST"
                  />
                </nav>
              </div>
            )}
            <Modal
              show={show}
              onHide={this.handleClose}
              size="md"
              aria-labelledby="contained-modal-title-vcenter"
              centered
              className="announcement-video model-content"
            >
              <Modal.Header>
                <Modal.Title className="text-capitalize">
                  {strings.video}
                </Modal.Title>
                <Image
                  src={Close}
                  width="17"
                  height="17"
                  onClick={e => this.handleClose(e)}
                  className="d-inline-block"
                  alt="Report Detail Icon"
                />
              </Modal.Header>
              <div className="video-player">
                <iframe
                  id="youtube"
                  width="500"
                  height="320"
                  frameBorder="0"
                  allowFullScreen
                  src={videoUrl}
                />
              </div>
            </Modal>
            <ConfirmationDialog
              show={dialog.show}
              handleClose={dialog.handleClose}
              body={dialog.body}
              title={dialog.title}
              button={dialog.button}
              confirmFunction={dialog.confirmFunction}
            />
            <FootNote />
          </MainContent>
        </MainWrapper>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    announcement: state.app.announcementReducer.announcement,
    announcementContents: state.app.announcementReducer.announcementContents,
    message: state.app.announcementReducer.message,
    announcementList: state.app.announcementReducer.announcementList,
    pdfFile: state.app.announcementReducer.pdfFile,
    updateReadStatusResponse: state.app.announcementReducer.updateReadStatusResponse
  };
};

export default connect(
  mapStateToProps,
  null
)(Announcements);
