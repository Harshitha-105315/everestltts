import { createMemoryHistory } from 'history';

export default createMemoryHistory();
