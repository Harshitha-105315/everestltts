UI designs in Invision/Zeplin were based on a screen layout of 1920px width. We need to adapt the font sizes, element widths, padding and margin to smaller screen layouts proportionately. This project uses Bootstrap 4 as the base for styling and layout. We have customized the break points in Bootstrap. The following break points are used in the project:

Heading and text sizes used in the project for the xxl layout:
* Login screen:
  * Logo height 32 px (2 rem)
  * Product name (Visiview): 38 px (2.375 rem)
  * Product subhead (Health Portal): 20px (1.25 rem)
  * Form head (Login): 32 px (2 rem) (H1)
  * Field label: 12px (0.75 rem)
  * Link button (Forgot password): 16px (1 rem)
  * Button (Login): 20 px (1.25 rem)
  * Highlighted link button: 18 px (1.125 rem)
  * Form input text: 16 px (1 rem)
  * Form help text: 16 px (1 rem) Line height: 22px (1.375 rem)
  * Terms and conditions agree check: 16px (1 rem). Line height: 20px (1.25 rem)
  * Choice field text: 16 px (1 rem). Line height: 24 px (1.5 rem)
* Footer
  * Copyright: 12 px (0.75 rem)
  * Links: 13 px (0.8125 rem)
* Header (height 100px: 6.25 rem)
  * Links: 14px (0.875 rem) margin: 64 px (4rem)
  * Link section margin: 128 px (8 rem)
  * Logo: left margin 58/60px ()
  *
* Left navigation (width: 300px 18.75 rem)
  * Left padding: 60px (3.75 rem)
  * Link: 16 px (1 rem)
  * Top and bottom padding: 22px ()
* Content pane
  * Left padding: 60px (3.75 rem)
  * Top padding: 44px (2.75 rem)
* Bread crumbs
  * Text/Links: 16px (1 rem)
  * Margin bottom: 25 px (1.5625 rem)
* Page heading
  * Text: 32 px (2 rem) (H1)
* Form
  * Section heading: 18 px
  * Label: 12 px, letter spacing: 1.2px, margin-bottom: 10px
  * Inputs: 16 px (1 rem)
  * Buttons: 12 px, height 42 px
* Tables
  * Heading: 12 px (0.75 rem) letter spacing 1.2 px
  * TR: height 80px
  * TD: padding-left: 48 px (4 rem)
  * Body text: 14 px (0.875 rem)
* Pagination

