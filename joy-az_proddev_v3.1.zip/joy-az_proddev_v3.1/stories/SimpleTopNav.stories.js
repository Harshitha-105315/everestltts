import React from 'react';

import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { linkTo } from '@storybook/addon-links';

import SimpleTopNav from 'src/components/SimpleTopNav';
import 'src/styles/index.scss';

storiesOf('SimpleTopNav', module).add('simple top navigation', () => (
  <SimpleTopNav />
));
