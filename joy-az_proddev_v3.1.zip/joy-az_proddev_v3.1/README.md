# Setup

Add src/config/config.js(excluded from repo) with below sample content:

```sh
const config = {
  BASE_URL: 'http://serverurl.com'
};
export default config;
```

...More to come, right after this.....

# Linter setup for vscode

Eslint, Airbnb style guide(https://github.com/airbnb/javascript/tree/master/react) configuration and it’s required packages.

```sh
$ npm i -D eslint eslint-config-airbnb eslint-plugin-import eslint-plugin-jsx-a11y eslint-plugin-react
```

Prettier, it’s configuration to avoid conflict with Eslint and it’s required packages.

```sh
$ npm i -D prettier eslint-config-prettier eslint-plugin-prettier
```

Stop before commit.

```sh
$ npm i -D husky lint-staged pretty-quick
```

husky: Will run npm script before the committing the code.
lint-staged: Will run custom script on the filtered files by the extensions like .js or .jsx
pretty-quick: Will prettify your code.

Add below scripts in package.json:

```sh
"precommit": "NODE_ENV=production lint-staged"
```

```sh
"lint-staged": {
  "*.{js,jsx}": [
    "pretty-quick --staged",
    "eslint src/ --fix",
    "git add"
  ]
}
```

## Eslint

For eslint create .eslintrc file on the root use this(https://gitlab.com/snippets/1836338/raw) raw file.

## Prettier

For Prettier create .prettierrc file on the root use code below.

```sh
{
  "singleQuote": true
}
```

### VScode Plugins

| Plugin   | README                                                                     |
| -------- | -------------------------------------------------------------------------- |
| Eslint   | https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint |
| Prettier | https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode |

Vscode extension settings:

```sh
{
  "files.autoSave": "onFocusChange",
  "editor.formatOnSave": true,
  "editor.formatOnType": true,
  "eslint.autoFixOnSave": true,
  "eslint.enable": true,
  "prettier.singleQuote": true,
}
```
