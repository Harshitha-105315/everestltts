package com.hillrom.optimus.repository;



import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.optimus.domain.OptimusData;



/**
 * Spring Data JPA repository for the OptimusData entity.
 */
public interface OptimusDataRepository extends JpaRepository<OptimusData,String> {
	Page<OptimusData> findByCreatedTimeBetweenOrderByIdDesc(DateTime from, DateTime to, Pageable pageable);
	

	
	Page<OptimusData> findBySerialNumberAndCreatedTimeBetweenOrderByIdDesc(String serialNumber, DateTime from, DateTime to, Pageable pageable);	
	
}
