package com.hillrom.vest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.ClinicUserAssoc;
import com.hillrom.vest.domain.ClinicUserAssocPK;

public interface ClinicUserRepository extends JpaRepository<ClinicUserAssoc, ClinicUserAssocPK> {
	@Query("from ClinicUserAssoc eua where eua.clinicUserAssocPK.user.id = ?1")
	List<ClinicUserAssoc> findByUserId(Long Id);
}