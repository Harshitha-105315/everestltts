package com.hillrom.vest.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.util.CustomLocalDateSerializer;
import com.hillrom.vest.domain.util.ISO8601LocalDateDeserializer;
import com.hillrom.vest.web.rest.dto.BenchmarkResultVO;


@Entity
@Table(name="PATIENT_COMPLIANCE_TITAN")
public class PatientComplianceTitan extends AbstractAuditingEntity implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="compliance_score")
	private Integer score;
	
	@Column
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate date;
	
	@ManyToOne(optional=false,targetEntity=PatientInfo.class)
	@JoinColumn(name="patient_id",referencedColumnName="id")
	private PatientInfo patient;
	
	@ManyToOne(optional=false,targetEntity=User.class)
	@JoinColumn(name="user_id",referencedColumnName="id")
	private User patientUser;
	
	@Column(name="hmr_run_rate")
	private Integer hmrRunRate = 0;
	
	@Column(name="is_settings_deviated")
	private boolean isSettingsDeviated = false;
	
	@Column(name="is_hmr_compliant")
	private boolean isHmrCompliant = true;
	
	@Column(name="missed_therapy_count")
	private int missedTherapyCount;

	@Column(name="last_therapy_session_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate latestTherapyDate;
	
	private Double hmr = 0.0d;
	

	@Column(name="hmr_vest")
	private Double hmrVest = 0.0d;	

	@Column(name="settings_deviated_days_count")
	private int settingsDeviatedDaysCount  = 0;
	
	@Column(name="global_missed_therapy_days_count")
	private int globalMissedTherapyCounter;
	
	@Column(name="global_hmr_non_adherence_count")
	private int globalHMRNonAdherenceCounter;
	
	@Column(name="global_settings_deviated_count")
	private int globalSettingsDeviationCounter;
	
	public PatientComplianceTitan() {
		super();
	}

	public PatientComplianceTitan(Integer score, LocalDate date,
			PatientInfo patient, User patientUser,Integer hmrRunRate,Boolean isHMRCompliant,
			Boolean isSettingsDeviated,double hmr) {
		super();
		this.score = score;
		this.date = date;
		this.patient = patient;
		this.patientUser = patientUser;
		this.hmrRunRate = hmrRunRate;
		this.isHmrCompliant = isHMRCompliant;
		this.isSettingsDeviated = isSettingsDeviated;
		this.missedTherapyCount = 0;
		this.latestTherapyDate = date;
		this.hmr = hmr;
	}

	public PatientComplianceTitan(LocalDate date,
			PatientInfo patient, User patientUser,Integer hmrRunRate,Integer missedTherapyCount,
			LocalDate lastTherapySessionDate,double hmr) {
		this.date = date;
		this.patient = patient;
		this.patientUser = patientUser;
		this.hmrRunRate = hmrRunRate;
		this.missedTherapyCount = missedTherapyCount;
		this.latestTherapyDate = lastTherapySessionDate;
		this.hmr = hmr;
	}

	public PatientComplianceTitan(Integer score, LocalDate date,
			PatientInfo patient, User patientUser,Integer hmrRunRate,Boolean isHMRCompliant,
			Boolean isSettingsDeviated,Integer missedTherapyCount,
			LocalDate lastTherapySessionDate,double hmr) {
		super();
		this.score = score;
		this.date = date;
		this.patient = patient;
		this.patientUser = patientUser;
		this.hmrRunRate = hmrRunRate;
		this.isHmrCompliant = isHMRCompliant;
		this.isSettingsDeviated = isSettingsDeviated;
		this.missedTherapyCount = 0;
		this.latestTherapyDate = date;
		this.hmr = hmr;
	}
	
	public PatientComplianceTitan(Integer score, LocalDate date,
			PatientInfo patient, User patientUser,Integer hmrRunRate,double hmr, Boolean isHMRCompliant,
			Boolean isSettingsDeviated,Integer missedTherapyCount,LocalDate latestTherapyDate,			
			Integer settingsDeviatedDaysCount,Integer globalHMRNonAdherenceCounter, 

			Integer globalSettingsDeviationCounter, Integer globalMissedTherapyCounter, double hmrVest) {

		super();
		this.score = score;
		this.date = date;
		this.patient = patient;
		this.patientUser = patientUser;
		this.hmrRunRate = hmrRunRate;
		this.hmr = hmr;
		this.isHmrCompliant = isHMRCompliant;
		this.isSettingsDeviated = isSettingsDeviated;
		this.missedTherapyCount = missedTherapyCount;
		this.latestTherapyDate = latestTherapyDate;		
		this.settingsDeviatedDaysCount = settingsDeviatedDaysCount;
		this.globalHMRNonAdherenceCounter = globalHMRNonAdherenceCounter;
		this.globalSettingsDeviationCounter = globalSettingsDeviationCounter;
		this.globalMissedTherapyCounter = globalMissedTherapyCounter;

		this.hmrVest = hmrVest;

	}
	
	public PatientComplianceTitan(Integer score, LocalDate date, PatientInfo patient, User patientUser,
			int missedTherapyCount, LocalDate latestTherapyDate) {
		super();
		this.score = score;
		this.date = date;
		this.patient = patient;
		this.patientUser = patientUser;
		this.missedTherapyCount = missedTherapyCount;
		this.latestTherapyDate = latestTherapyDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public PatientInfo getPatient() {
		return patient;
	}

	public void setPatient(PatientInfo patient) {
		this.patient = patient;
	}

	public User getPatientUser() {
		return patientUser;
	}

	public void setPatientUser(User patientUser) {
		this.patientUser = patientUser;
	}

	public Integer getHmrRunRate() {
		return hmrRunRate;
	}

	public void setHmrRunRate(Integer hmrRunRate) {
		this.hmrRunRate = hmrRunRate;
	}

	public boolean isSettingsDeviated() {
		return isSettingsDeviated;
	}

	public void setSettingsDeviated(boolean isSettingsDeviated) {
		this.isSettingsDeviated = isSettingsDeviated;
	}

	public boolean isHmrCompliant() {
		return isHmrCompliant;
	}

	public void setHmrCompliant(boolean isHmrCompliant) {
		this.isHmrCompliant = isHmrCompliant;
	}

	public int getMissedTherapyCount() {
		return missedTherapyCount;
	}

	public void setMissedTherapyCount(int missedTherapyCount) {
		this.missedTherapyCount = missedTherapyCount;
	}

	public LocalDate getLatestTherapyDate() {
		return latestTherapyDate;
	}

	public void setLatestTherapyDate(LocalDate latestTherapyDate) {
		this.latestTherapyDate = latestTherapyDate;
	}

	@JsonIgnore
	public int getDayOfTheWeek(){
		return this.date.getDayOfWeek();
	}
	
	@JsonIgnore
	public int getWeekOfWeekyear(){
		return this.date.getWeekOfWeekyear();
	}
	
	@JsonIgnore
	public int getMonthOfTheYear(){
		return this.date.getMonthOfYear();
	}

	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}	
	
	/**
	 * @return the hmrVest
	 */
	public Double getHmrVest() {
		return hmrVest;
	}

	/**
	 * @param hmrVest the hmrVest to set
	 */
	public void setHmrVest(Double hmrVest) {
		this.hmrVest = hmrVest;
	}

	public int getSettingsDeviatedDaysCount() {
		return settingsDeviatedDaysCount;
	}

	public void setSettingsDeviatedDaysCount(int settingsDeviatedDaysCount) {
		this.settingsDeviatedDaysCount = settingsDeviatedDaysCount;
	}

	public int getGlobalMissedTherapyCounter() {
		return globalMissedTherapyCounter;
	}

	public void setGlobalMissedTherapyCounter(int globalMissedTherapyCounter) {
		this.globalMissedTherapyCounter = globalMissedTherapyCounter;
	}

	public int getGlobalHMRNonAdherenceCounter() {
		return globalHMRNonAdherenceCounter;
	}

	public void setGlobalHMRNonAdherenceCounter(int globalHMRNonAdherenceCounter) {
		this.globalHMRNonAdherenceCounter = globalHMRNonAdherenceCounter;
	}

	public int getGlobalSettingsDeviationCounter() {
		return globalSettingsDeviationCounter;
	}

	public void setGlobalSettingsDeviationCounter(int globalSettingsDeviationCounter) {
		this.globalSettingsDeviationCounter = globalSettingsDeviationCounter;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientComplianceTitan other = (PatientComplianceTitan) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PatientComplianceTitan [id=" + id + ", score=" + score + ", date=" + date + ", patient=" + patient
				+ ", patientUser=" + patientUser + ", hmrRunRate=" + hmrRunRate + ", isSettingsDeviated="
				+ isSettingsDeviated + ", isHmrCompliant=" + isHmrCompliant + ", missedTherapyCount="
				+ missedTherapyCount + ", latestTherapyDate=" + latestTherapyDate + ", hmr=" + hmr
				+ ", settingsDeviatedDaysCount=" + settingsDeviatedDaysCount + ", globalMissedTherapyCounter="
				+ globalMissedTherapyCounter + ", globalHMRNonAdherenceCounter=" + globalHMRNonAdherenceCounter
				+ ", globalSettingsDeviationCounter=" + globalSettingsDeviationCounter + "]";
	}
	
	@Override
	public String getCreatedBy() {
		return patientUser.getEmail();
	}
	
	
}
