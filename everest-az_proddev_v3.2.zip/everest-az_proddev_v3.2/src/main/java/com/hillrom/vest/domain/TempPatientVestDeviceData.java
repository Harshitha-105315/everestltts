package com.hillrom.vest.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PATIENT_VEST_DEVICE_DATA_TEMP")
public class TempPatientVestDeviceData implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "sequence_number")
	private Integer sequenceNumber;

	@Column(name = "serial_number")
	private String serialNumber;
	
	@Column(name="hub_id")
	private String hubId;

	private Double hmr;
	
	private Integer frequency;
	
	private Integer pressure;
	
	private Integer duration;

	private Integer checksum;

	@EmbeddedId 
	private PatientVestDeviceDataPK patientVestDeviceDataPK;
	
	@JsonIgnore
	@ManyToOne(optional=false,targetEntity=User.class)
	@JoinColumn(name="user_id",referencedColumnName="id")
	private User patientUser;
	
	
	public PatientVestDeviceDataPK getPatientVestDeviceDataPK() {
		return patientVestDeviceDataPK;
	}

	public void setPatientVestDeviceDataPK(PatientVestDeviceDataPK patientVestDeviceDataPK) {
		this.patientVestDeviceDataPK = patientVestDeviceDataPK;
	}

	public Long getTimestamp() {
		return this.getPatientVestDeviceDataPK().getTimestamp();
	}

	public void setTimestamp(Long timestamp) {
		this.getPatientVestDeviceDataPK().setTimestamp(timestamp);
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getBluetoothId() {
		return this.getPatientVestDeviceDataPK().getBluetoothId();
	}

	public void setBluetoothId(String bluetoothId) {
		this.getPatientVestDeviceDataPK().setBluetoothId(bluetoothId);
	}

	public String getHubId() {
		return hubId;
	}

	public void setHubId(String hubId) {
		this.hubId = hubId;
	}

	public String getEventId() {
		return this.getPatientVestDeviceDataPK().getEventId();
	}

	public void setEventId(String eventId) {
		this.getPatientVestDeviceDataPK().setEventId(eventId);
	}
	
	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Integer getPressure() {
		return pressure;
	}

	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getChecksum() {
		return checksum;
	}

	public void setChecksum(Integer checksum) {
		this.checksum = checksum;
	}

	public User getPatientUser() {
		return patientUser;
	}

	public void setPatientUser(User patientUser) {
		this.patientUser = patientUser;
	}

	
	@JsonIgnore
	public LocalDate getDate(){
		return LocalDate.fromDateFields(new Date(this.getPatientVestDeviceDataPK().getTimestamp()));
	}
	
	@JsonIgnore
	public double getHmrInMinutes(){
		return this.hmr/60;
	}	

	
		
}
