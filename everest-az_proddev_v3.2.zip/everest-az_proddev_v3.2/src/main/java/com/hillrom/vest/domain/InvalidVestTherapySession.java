package com.hillrom.vest.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.util.CustomLocalDateSerializer;
import com.hillrom.vest.domain.util.ISO8601LocalDateDeserializer;

@Entity
@Table(name="PATIENT_VEST_THERAPY_INVALID_DATA")
public class InvalidVestTherapySession implements Comparable<InvalidVestTherapySession>{
	
	@JsonIgnore
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@JsonIgnore
	@Column(name="patient_id")
	private String patient_id;
	
	@JsonIgnore
	@ManyToOne(optional=false,targetEntity=User.class)
	@JoinColumn(name="user_id",referencedColumnName="id")
	private User patientUser;
	
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate date;
	
	@Column(name="session_no")
	private Integer sessionNo;
	
	@Column(name="session_type")
	private String sessionType;
	
	@Column(name="start_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate startTime;
	
	@Column(name="end_time")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate endTime;
	
	@Column(name="frequency")
	private Integer frequency;
	
	@Column(name="pressure")
	private Integer pressure;
	
	@Column(name="duration_in_minutes")
	private int durationInMinutes;
	
	@Column(name="hmr")
	private Double hmr;
	
	@Column(name="serial_number")
	private String serialNumber;
	
	@Column(name="hillromId")
	private String hillromId;
	
	@NotNull
    @Column(name = "hub_receive_time", nullable = false)
    private String hubReceiveTime;
	
    public InvalidVestTherapySession() {
		super();
    }

	public InvalidVestTherapySession(Long id, String patient_id,
			User patientUser, LocalDate date, Integer sessionNo,
			String sessionType, LocalDate startTime, LocalDate endTime,
			Integer frequency, Integer pressure, int durationInMinutes,
			Double hmr, String serialNumber) {
		super();
		this.id = id;
		this.patient_id = patient_id;
		this.patientUser = patientUser;
		this.date = date;
		this.sessionNo = sessionNo;
		this.sessionType = sessionType;
		this.startTime = startTime;
		this.endTime = endTime;
		this.frequency = frequency;
		this.pressure = pressure;
		this.durationInMinutes = durationInMinutes;
		this.hmr = hmr;
		this.serialNumber = serialNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPatient_id() {
		return patient_id;
	}

	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}

	public User getPatientUser() {
		return patientUser;
	}
	
	public LocalDate getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDate startTime) {
		this.startTime = startTime;
	}

	public LocalDate getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDate endTime) {
		this.endTime = endTime;
	}

	public void setPatientUser(User patientUser) {
		this.patientUser = patientUser;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Integer getSessionNo() {
		return sessionNo;
	}

	public void setSessionNo(Integer sessionNo) {
		this.sessionNo = sessionNo;
	}

	public String getSessionType() {
		return sessionType;
	}

	public void setSessionType(String sessionType) {
		this.sessionType = sessionType;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Integer getPressure() {
		return pressure;
	}

	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}

	public int getDurationInMinutes() {
		return durationInMinutes;
	}

	public void setDurationInMinutes(int durationInMinutes) {
		this.durationInMinutes = durationInMinutes;
	}

	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getHubReceiveTime() {
		return hubReceiveTime;
	}

	public void setHubReceiveTime(String hubReceiveTime) {
		this.hubReceiveTime = hubReceiveTime;
	}

	public String getHillromId() {
		return hillromId;
	}

	public void setHillromId(String hillromId) {
		this.hillromId = hillromId;
	}

	
	@Override
	public String toString() {
		return "InvalidVestTherapySession [id=" + id + ", patient_id="
				+ patient_id + ", patientUser=" + patientUser + ", date="
				+ date + ", sessionNo=" + sessionNo + ", sessionType="
				+ sessionType + ", startTime=" + startTime + ", endTime="
				+ endTime + ", frequency=" + frequency + ", pressure="
				+ pressure + ", durationInMinutes=" + durationInMinutes
				+ ", hmr=" + hmr + ", serialNumber=" + serialNumber
				+ ", hillromId=" + hillromId + ", hubReceiveTime="
				+ hubReceiveTime + "]";
	}

	@Override
	public int compareTo(InvalidVestTherapySession o) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
