package com.hillrom.vest.repository;

import org.joda.time.LocalDate;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.web.rest.dto.PatientTestResultVO;


@Repository
public class PatientTestResultsRepository {
	
	@Inject
	private EntityManager entityManager;
	
	public List<Object[]> getPatientTestResultAvgByUserIdTillDate(Long pid, LocalDate from, LocalDate to) {
		
		String testResultQuery = QueryConstants.QUERY_PATIENT_TEST_RESULT;
		
		String queryForTranEver = testResultQuery +"'"+pid+"' and patientTestResult.test_result_date >= '2017' GROUP BY resDate";
			
		Query queryCombined = entityManager.createNativeQuery(queryForTranEver);
		List<Object[]> resultsForCombined = queryCombined.getResultList();
		
		
		return resultsForCombined;
		
	}
	
	
	public List<Object[]> getPatientTestResultAvgByUserId(Long pid, LocalDate from, LocalDate to) {
		
		String testResultQuery = QueryConstants.QUERY_PATIENT_TEST_RESULT;
		String combinedQuery = testResultQuery+"'"+pid+"' and patientTestResult.test_result_date between '" +from+"' and '"+to+"' GROUP BY resDate";
		
		Query query = entityManager.createNativeQuery(combinedQuery);
		
		List<Object[]> results = query.getResultList();
		
		return results;
	}

}
