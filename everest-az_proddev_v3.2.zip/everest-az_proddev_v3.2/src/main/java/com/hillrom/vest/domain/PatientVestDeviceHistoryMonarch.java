package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Transient;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.util.DecimalNumberSerializer;


@Entity
@Table(name = "PATIENT_VEST_DEVICE_HISTORY_MONARCH")
@EntityListeners(AuditingEntityListener.class)
@AssociationOverrides({
    @AssociationOverride(name = "patientVestDevicePK.patient",
        joinColumns = @JoinColumn(name = "PATIENT_ID", referencedColumnName="id")) })
public class PatientVestDeviceHistoryMonarch implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private PatientVestDevicePK patientVestDevicePK;

	@Column(name = "bluetooth_id")
	private String bluetoothId;
	
	@Column(name = "dev_wifi")
	private String wifiId;
	
	@Column(name = "dev_lte")
	private String lteId;
	
	@Column(name = "dev_bt")
	private String devBt;
	
	@Column(name="hub_id")
	private String hubId;
	
	@Column(name="is_active")
	private Boolean active = false;
	
	@Column(name="is_pending")
	private Boolean pending = false;
	
	@CreatedBy
    @NotNull
    @Column(name = "created_by", nullable = false, length = 50, updatable = false)
    private String createdBy;

    @CreatedDate
    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "created_date", nullable = false)
    private DateTime createdDate = DateTime.now();

    @LastModifiedBy
    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @LastModifiedDate
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "last_modified_date")
    private DateTime lastModifiedDate = DateTime.now();
    
    @Column(name="hmr")
	private Double hmr = 0d; // default value for HMR
    
    @Transient
	private String deviceType;

    @Column(name="garment_type")
	private String garmentType;
    
    @Column(name="garment_size")
	private String garmentSize;
    
    @Column(name="garment_color")
	private String garmentColor;
    
    @NotNull
    @Column(name ="is_byod")
    private Boolean isByod = false;
    
    @NotNull
    @Column(name ="is_dnd")
    private Boolean isDnd = false;
    
    @Column(name = "dnd_device_identifier")
    private String dndIdentifier;
    
    @Column(name ="byod_state")
    private String byodState;
    
    @Column(name="byod_last_updated")
    private Long byodLastUpdated;
    
    @Column(name="byod_device_identifier")
    private String byodDeviceIdentifier;
    
    @Column(name="opt_out_requested_date")
    private Long optOutRequestedDate;
    
    @Column(name="opt_out_device_identifier")
    private String optOutDeviceIdentifier;
    
    @Column(name="opt_out_agreed_date")
    private Long optOutAgreedDate;
    
    @Column(name="opt_out_reason")
    private String optOutReason;

    @Column(name="opt_out_feedback")
    private String optOutFeedback;

	public PatientVestDeviceHistoryMonarch() {
		super();
	}

	public PatientVestDeviceHistoryMonarch(PatientVestDevicePK patientVestDevicePK,
			String wifiId, String hubId, Boolean active) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.wifiId = wifiId;
		this.hubId = hubId;
		this.active = active;
		this.deviceType = "MONARCH";
	}
	
	public PatientVestDeviceHistoryMonarch(PatientVestDevicePK patientVestDevicePK,
			String wifiId, String hubId, Boolean active, Boolean byod) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.wifiId = wifiId;
		this.hubId = hubId;
		this.active = active;
		this.deviceType = "MONARCH";
		this.isByod = byod;
	}

	public PatientVestDeviceHistoryMonarch(PatientVestDevicePK patientVestDevicePK, String wifiId, String devBt,
			String hubId, Boolean active, String createdBy) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.wifiId = wifiId;
		this.devBt = devBt;
		this.hubId = hubId;
		this.active = active;
		this.createdBy = createdBy;
		this.deviceType = "MOANRCH";
	}
	public PatientVestDevicePK getPatientVestDevicePK() {
		return patientVestDevicePK;
	}

	public void setPatientVestDevicePK(PatientVestDevicePK patientVestDevicePK) {
		this.patientVestDevicePK = patientVestDevicePK;
	}

	public PatientInfo getPatient() {
		return getPatientVestDevicePK().getPatient();
	}

	public void setPatient(PatientInfo patient) {
		getPatientVestDevicePK().setPatient(patient);
	}

	public String getSerialNumber() {
		return getPatientVestDevicePK().getSerialNumber();
	}

	public void setSerialNumber(String serialNumber) {
		getPatientVestDevicePK().setSerialNumber(serialNumber);
	}
	
	public String getDevBt() {
		return devBt;
	}

	public void setDevBt(String devBt) {
		this.devBt = devBt;
	}
	
	public String getWifiId() {
		return wifiId;
	}

	public void setWifiId(String wifiId) {
		this.wifiId = wifiId;
	}
	
	public String getLteId() {
		return lteId;
	}

	public void setLteId(String lteId) {
		this.lteId = lteId;
	}

	public String getHubId() {
		return hubId;
	}

	public void setHubId(String hubId) {
		this.hubId = hubId;
	}

	public Boolean isActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}
	
	public Boolean isPending() {
		return pending;
	}

	public void setPending(Boolean pending) {
		this.pending = pending;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public DateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(DateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	@Transient
	public String getDeviceType() {
		return deviceType;
	}

    @Transient
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	
	@JsonIgnore
	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}

	/**
	 * @return the garmentType
	 */
	public String getGarmentType() {
		return garmentType;
	}

	/**
	 * @param garmentType the garmentType to set
	 */
	public void setGarmentType(String garmentType) {
		this.garmentType = garmentType;
	}

	/**
	 * @return the garmentSize
	 */
	public String getGarmentSize() {
		return garmentSize;
	}

	/**
	 * @param garmentSize the garmentSize to set
	 */
	public void setGarmentSize(String garmentSize) {
		this.garmentSize = garmentSize;
	}

	/**
	 * @return the garmentColor
	 */
	public String getGarmentColor() {
		return garmentColor;
	}

	/**
	 * @param garmentColor the garmentColor to set
	 */
	public void setGarmentColor(String garmentColor) {
		this.garmentColor = garmentColor;
	}

	// This is used for sending hmr in Minutes
	@JsonProperty(value="hmr")
	@JsonSerialize(using=DecimalNumberSerializer.class)
	public Double getHmrInMinutes(){
		return hmr/(60);
	}

	public Boolean getIsByod() {
		return isByod;
	}

	public void setIsByod(Boolean isByod) {
		this.isByod = isByod;
	}

	public Boolean getIsDnd() {
		return isDnd;
	}

	public void setIsDnd(Boolean isDnd) {
		this.isDnd = isDnd;
	}

	public String getDndIdentifier() {
		return dndIdentifier;
	}

	public void setDndIdentifier(String dndIdentifier) {
		this.dndIdentifier = dndIdentifier;
	}

	public String getByodState() {
		return byodState;
	}

	public void setByodState(String byodState) {
		this.byodState = byodState;
	}

	public Long getByodLastUpdated() {
		return byodLastUpdated;
	}

	public void setByodLastUpdated(Long byodLastUpdated) {
		this.byodLastUpdated = byodLastUpdated;
	}

	public String getByodDeviceIdentifier() {
		return byodDeviceIdentifier;
	}

	public void setByodDeviceIdentifier(String byodDeviceIdentifier) {
		this.byodDeviceIdentifier = byodDeviceIdentifier;
	}

	public Long getOptOutRequestedDate() {
		return optOutRequestedDate;
	}

	public void setOptOutRequestedDate(Long optOutRequestedDate) {
		this.optOutRequestedDate = optOutRequestedDate;
	}

	public String getOptOutDeviceIdentifier() {
		return optOutDeviceIdentifier;
	}

	public void setOptOutDeviceIdentifier(String optOutDeviceIdentifier) {
		this.optOutDeviceIdentifier = optOutDeviceIdentifier;
	}

	public Long getOptOutAgreedDate() {
		return optOutAgreedDate;
	}

	public void setOptOutAgreedDate(Long optOutAgreedDate) {
		this.optOutAgreedDate = optOutAgreedDate;
	}

	public String getOptOutReason() {
		return optOutReason;
	}

	public void setOptOutReason(String optOutReason) {
		this.optOutReason = optOutReason;
	}

	public String getOptOutFeedback() {
		return optOutFeedback;
	}

	public void setOptOutFeedback(String optOutFeedback) {
		this.optOutFeedback = optOutFeedback;
	}

	public String getBluetoothId() {
		return bluetoothId;
	}

	public void setBluetoothId(String bluetoothId) {
		this.bluetoothId = bluetoothId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((active == null) ? 0 : active.hashCode());
		result = prime * result + ((bluetoothId == null) ? 0 : bluetoothId.hashCode());
		result = prime * result + ((byodDeviceIdentifier == null) ? 0 : byodDeviceIdentifier.hashCode());
		result = prime * result + ((byodLastUpdated == null) ? 0 : byodLastUpdated.hashCode());
		result = prime * result + ((byodState == null) ? 0 : byodState.hashCode());
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result + ((devBt == null) ? 0 : devBt.hashCode());
		result = prime * result + ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + ((dndIdentifier == null) ? 0 : dndIdentifier.hashCode());
		result = prime * result + ((garmentColor == null) ? 0 : garmentColor.hashCode());
		result = prime * result + ((garmentSize == null) ? 0 : garmentSize.hashCode());
		result = prime * result + ((garmentType == null) ? 0 : garmentType.hashCode());
		result = prime * result + ((hmr == null) ? 0 : hmr.hashCode());
		result = prime * result + ((hubId == null) ? 0 : hubId.hashCode());
		result = prime * result + ((isByod == null) ? 0 : isByod.hashCode());
		result = prime * result + ((isDnd == null) ? 0 : isDnd.hashCode());
		result = prime * result + ((lastModifiedBy == null) ? 0 : lastModifiedBy.hashCode());
		result = prime * result + ((lastModifiedDate == null) ? 0 : lastModifiedDate.hashCode());
		result = prime * result + ((lteId == null) ? 0 : lteId.hashCode());
		result = prime * result + ((optOutAgreedDate == null) ? 0 : optOutAgreedDate.hashCode());
		result = prime * result + ((optOutDeviceIdentifier == null) ? 0 : optOutDeviceIdentifier.hashCode());
		result = prime * result + ((optOutFeedback == null) ? 0 : optOutFeedback.hashCode());
		result = prime * result + ((optOutReason == null) ? 0 : optOutReason.hashCode());
		result = prime * result + ((optOutRequestedDate == null) ? 0 : optOutRequestedDate.hashCode());
		result = prime * result + ((patientVestDevicePK == null) ? 0 : patientVestDevicePK.hashCode());
		result = prime * result + ((pending == null) ? 0 : pending.hashCode());
		result = prime * result + ((wifiId == null) ? 0 : wifiId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientVestDeviceHistoryMonarch other = (PatientVestDeviceHistoryMonarch) obj;
		if (active == null) {
			if (other.active != null)
				return false;
		} else if (!active.equals(other.active))
			return false;
		if (bluetoothId == null) {
			if (other.bluetoothId != null)
				return false;
		} else if (!bluetoothId.equals(other.bluetoothId))
			return false;
		if (byodDeviceIdentifier == null) {
			if (other.byodDeviceIdentifier != null)
				return false;
		} else if (!byodDeviceIdentifier.equals(other.byodDeviceIdentifier))
			return false;
		if (byodLastUpdated == null) {
			if (other.byodLastUpdated != null)
				return false;
		} else if (!byodLastUpdated.equals(other.byodLastUpdated))
			return false;
		if (byodState == null) {
			if (other.byodState != null)
				return false;
		} else if (!byodState.equals(other.byodState))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (devBt == null) {
			if (other.devBt != null)
				return false;
		} else if (!devBt.equals(other.devBt))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (dndIdentifier == null) {
			if (other.dndIdentifier != null)
				return false;
		} else if (!dndIdentifier.equals(other.dndIdentifier))
			return false;
		if (garmentColor == null) {
			if (other.garmentColor != null)
				return false;
		} else if (!garmentColor.equals(other.garmentColor))
			return false;
		if (garmentSize == null) {
			if (other.garmentSize != null)
				return false;
		} else if (!garmentSize.equals(other.garmentSize))
			return false;
		if (garmentType == null) {
			if (other.garmentType != null)
				return false;
		} else if (!garmentType.equals(other.garmentType))
			return false;
		if (hmr == null) {
			if (other.hmr != null)
				return false;
		} else if (!hmr.equals(other.hmr))
			return false;
		if (hubId == null) {
			if (other.hubId != null)
				return false;
		} else if (!hubId.equals(other.hubId))
			return false;
		if (isByod == null) {
			if (other.isByod != null)
				return false;
		} else if (!isByod.equals(other.isByod))
			return false;
		if (isDnd == null) {
			if (other.isDnd != null)
				return false;
		} else if (!isDnd.equals(other.isDnd))
			return false;
		if (lastModifiedBy == null) {
			if (other.lastModifiedBy != null)
				return false;
		} else if (!lastModifiedBy.equals(other.lastModifiedBy))
			return false;
		if (lastModifiedDate == null) {
			if (other.lastModifiedDate != null)
				return false;
		} else if (!lastModifiedDate.equals(other.lastModifiedDate))
			return false;
		if (lteId == null) {
			if (other.lteId != null)
				return false;
		} else if (!lteId.equals(other.lteId))
			return false;
		if (optOutAgreedDate == null) {
			if (other.optOutAgreedDate != null)
				return false;
		} else if (!optOutAgreedDate.equals(other.optOutAgreedDate))
			return false;
		if (optOutDeviceIdentifier == null) {
			if (other.optOutDeviceIdentifier != null)
				return false;
		} else if (!optOutDeviceIdentifier.equals(other.optOutDeviceIdentifier))
			return false;
		if (optOutFeedback == null) {
			if (other.optOutFeedback != null)
				return false;
		} else if (!optOutFeedback.equals(other.optOutFeedback))
			return false;
		if (optOutReason == null) {
			if (other.optOutReason != null)
				return false;
		} else if (!optOutReason.equals(other.optOutReason))
			return false;
		if (optOutRequestedDate == null) {
			if (other.optOutRequestedDate != null)
				return false;
		} else if (!optOutRequestedDate.equals(other.optOutRequestedDate))
			return false;
		if (patientVestDevicePK == null) {
			if (other.patientVestDevicePK != null)
				return false;
		} else if (!patientVestDevicePK.equals(other.patientVestDevicePK))
			return false;
		if (pending == null) {
			if (other.pending != null)
				return false;
		} else if (!pending.equals(other.pending))
			return false;
		if (wifiId == null) {
			if (other.wifiId != null)
				return false;
		} else if (!wifiId.equals(other.wifiId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PatientVestDeviceHistoryMonarch [patientVestDevicePK=" + patientVestDevicePK + ", wifiId=" + wifiId
				+ ", lteId=" + lteId + ", devBt=" + devBt + ", hubId=" + hubId + ", active=" + active + ", pending="
				+ pending + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedDate=" + lastModifiedDate + ", hmr=" + hmr + ", deviceType="
				+ deviceType + ", garmentType=" + garmentType + ", garmentSize=" + garmentSize + ", garmentColor="
				+ garmentColor + ", isByod=" + isByod + ", isDnd=" + isDnd + ", dndIdentifier=" + dndIdentifier
				+ ", byodState=" + byodState + ", byodLastUpdated=" + byodLastUpdated + ", byodDeviceIdentifier="
				+ byodDeviceIdentifier + ", optOutRequestedDate=" + optOutRequestedDate + ", optOutDeviceIdentifier="
				+ optOutDeviceIdentifier + ", optOutAgreedDate=" + optOutAgreedDate + ", optOutReason=" + optOutReason
				+ ", optOutFeedback=" + optOutFeedback + "]";
	}}
