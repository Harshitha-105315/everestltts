package com.hillrom.vest.dto;

public class PatientProtocolDataForEmail {

	private String type;
	private int treatmentsPerDay;
	private String treatmentLabel;
	private int minutesPerTreatment;
	private String frequencyRange;
	private String pressureRange;
	private String deviceType;

	public PatientProtocolDataForEmail() {
		super();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getTreatmentsPerDay() {
		return treatmentsPerDay;
	}

	public void setTreatmentsPerDay(int treatmentsPerDay) {
		this.treatmentsPerDay = treatmentsPerDay;
	}

	public String getTreatmentLabel() {
		return treatmentLabel;
	}

	public void setTreatmentLabel(String treatmentLabel) {
		this.treatmentLabel = treatmentLabel;
	}

	public int getMinutesPerTreatment() {
		return minutesPerTreatment;
	}

	public void setMinutesPerTreatment(int minutesPerTreatment) {

		this.minutesPerTreatment = minutesPerTreatment;
	}

	public String getFrequencyRange() {
		return frequencyRange;
	}

	public void setFrequencyRange(String frequencyRange) {
		this.frequencyRange = frequencyRange;
	}

	public String getPressureRange() {
		return pressureRange;
	}

	public void setPressureRange(String pressureRange) {
		this.pressureRange = pressureRange;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

}