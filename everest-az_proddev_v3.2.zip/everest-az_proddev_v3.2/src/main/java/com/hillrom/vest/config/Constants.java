package com.hillrom.vest.config;




/**
 * Application constants.
 */
public final class Constants {

	private Constants() {
	}

	// Spring profile for development, production and "fast", see
	// http://jhipster.github.io/profiles.html
	public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
	public static final String SPRING_PROFILE_PRODUCTION = "prod";
	public static final String SPRING_PROFILE_FAST = "fast";
	public static final String SPRING_PROFILE_MIRROR = "mirror";
	// Spring profile used when deploying with Spring Cloud (used when deploying
	// to CloudFoundry)
	public static final String SPRING_PROFILE_CLOUD = "cloud";
	// Spring profile used when deploying to Heroku
	public static final String SPRING_PROFILE_HEROKU = "heroku";

	public static final String SYSTEM_ACCOUNT = "system";
	

	public static final String DATEFORMAT_MMddyyyy = "MMddyyyy";

	public static final int NO_OF_CHARACTERS_TO_BE_EXTRACTED = 4;

	public static final int MAX_NO_OF_CAREGIVERS = 5;

	public static final String TREATMENTS_PER_DAY = "treatmentsPerDay";

	public static final String MINUTES_PER_TREATMENT = "minutesPerTreatment";

	public static final String FREQUENCIES = "frequencies";

	public static final String MIN_MINUTES_PER_DAY = "minimumMinutesOfUsePerDay";

	public static final String CUSTOM_PROTOCOL = "Custom";

	public static final String NORMAL_PROTOCOL = "Normal";

	public static final String ALL = "All";

	public static final String PROGRAMMED_CAUGH_PAUSES = "ProgrammedCaughPauses";

	public static final String DURATION_IN_MINUTES = "DurationInMinutes";

	public static final String END_TIME = "EndTime";

	public static final String START_TIME = "StartTime";

	public static final String SESSION_TYPE2 = "SessionType";

	public static final String SESSION_NO = "SessionNo";

	public static final String NORMAL_CAUGH_PAUSES = "NormalCaughPauses";

	public static final String CAUGH_PAUSE_DURATION = "CaughPauseDuration";

	public static final String NORMAL_COUGH_PAUSES = "Normal Cough Pauses";

	public static final String COUGH_PAUSE_DURATION = "Cough Pause Duration";

	public static final String PROGRAMMED_COUGH_PAUSES = "Programmed Cough Pauses";

	public static final String MINUTES = "Duration";

	public static final String PRESSURE = "Pressure";

	public static final String FREQUENCY = "Frequency";

	public static final String FINISH = "Finish";

	public static final String START = "Start";

	public static final String SESSION_TYPE = "Session Type";

	public static final String DAILY_TREATMENT_NUMBER = "Daily Treatment Number";

	public static final String DATE = "Date";

	public static final String HMR_IN_HOURS = "hmrInHours";

	public static final String DURATION = "Duration";
	
	public static final String DURATION_MONARCH="Therapy Duration";
	
	public static final String HMR_MONARCH="Total Therapy Hours";

	public static final String HUB_ID = "hubId";

	public static final String BLUETOOTH_ID = "bluetoothId";

	public static final String SERIAL_NUMBER = "serialNumber";

	public static final String EVENT_ID = "eventId";

	public static final String SEQUENCE_NUMBER = "sequenceNumber";

	public static final String HMR = "Total Therapy Hours";

	public static final String DURATION_TITAN="Therapy Duration";
	
	public static final String HMR_TITAN="Total Therapy Hours";


	public static final String HUB_ADDRESS = "Hub Id";

	public static final String DEVICE_ADDRESS = "Device Address";

	public static final String SERIAL_NO = "Serial Number";

	public static final String SEQUENCE_NO = "Sequence No";

	public static final String EVENT = "Event";

	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	
	public static final String NON_HMR_COMPLIANCE = "non_hmr_compliance";

	public static final String MISSED_THERAPY = "missed_therapy";

	public static final String SETTING_DEVIATION = "setting_deviation";

	public static final String NO_EVENT = "no_event";

	public static final String YEAR = "year";
	
	public static final String MONTH = "month";
	
	public static final String WEEK = "week";
	
	public static final String ACTIVE = "active";
	
	public static final String INACTIVE = "inactive";
	
	public static final String EXPIRED = "expired";
	
	public static final String TIME = "Time";
	
	public static final String PATIENT_ID = "Patient Id";
	
	public static final String FIRST_NAME= "First Name";
	
	public static final String LAST_NAME = "Last Name";
	
	public static final String DEVICE_TYPE = "Device Type";
	
	public static final String ACTIVE_SERIAL_NUMBER = "Active Serial Number";
	
	public static final String REPORT_DATE = "Report Date";
	
	public static final String FROM_DATE = "From";
	
	public static final String TO_DATE = "To";
	
	public static final String PEDS = "Peds";
	
	public static final String HILLROM_ID = "Tims Id";
	
	public static final String WIFIorLTE_SERIAL_NO= "WIFI/LTE Serial Number";
	
	public static final String PATIENT_BLUETOOTH_ADDRESS = "patientBlueToothAddress";
	
	public static final String DAY = "day";
	
	public static final String CUSTOM = "custom";
	
	public static final String MMddyyyy = "MM/dd/yyyy";
	
	public static final String WEEK_SEPERATOR = " - ";
	
	public static final String XAXIS_TYPE_CATEGORIES = "categories";
	
	public static final String XAXIS_TYPE_DATETIME = "datetime";
	//hill-1847
	public static final String XAXIS_TYPE_DATE = "date";
	//hill-1847
	public static final String LA_DAYVIEW_LABEL = "No.of Logins";
	
	public static final String UNABLE_TO_ASSESS = "Unable to assess";
	public static final String STRONGLY_AGREE = "Strongly agree";
	public static final String SOMEWHAT_AGREE= "Somewhat agree";
	public static final String NEUTRAL = "Neutral";
	public static final String SOMEWHAT_DISAGREE  = "Somewhat disagree";
	public static final String STRONGLY_DISAGREE = "Strongly disagree";
	
	// 5days Survey question ids
	public static final String FIVE_DAYS_SURVEY_QIDS = "6,7,8,9,10,11,12";
	
	// 30 days Survey question ids
	public static final String THIRTY_DAYS_SURVEY_QIDS = "27,28,29,30,31,32,33";
	
	public static final Long FIVE_DAYS_SURVEY_ID = 1L;
	
	public static final Long THIRTY_DAYS_SURVEY_ID = 2L;
	
	// Survey Graph Constants
	public static final String KEY_COUNT = "count";
	public static final String Q_PREFIX = "Q-";
	public static final String NO = "No";
	public static final String YES = "Yes";
	public static final String KEY_THIRTY_DAYS_SURVEY_REPORT = "thirtyDaysSurveyReport";
	public static final String KEY_FIVE_DAYS_SURVEY_REPORT = "fiveDaysSurveyReport";

	//Column name to be checked in Patient search
	public static final String ADHERENCE = "adherence";
	
	// HMR Graph Date Formats
	public static final String MMddyyyyHHmm = "MM/dd/yyyy (HH:mm a)";
	public static final String HHMM = "HH:MM a";
	public static final String MMddyyyyHHmmss = "MM/dd/yyyy HH:mm:ss";
	
	//HMR Graph Y-axis labels
	public static final String MINUTES_LABEL = "Minutes";
	public static final String HMR_LABEL = "Total Therapy Hours";
	
	//HMR Graph tooltip labels
	public static final String KEY_NOTE_TEXT = "noteText";
	public static final String KEY_COUGH_PAUSES = "coughPauses";
	public static final String KEY_MISSED_THERAPY = "missedTherapy";
	public static final String KEY_FREQUENCY = "frequency";
	public static final String KEY_DURATION = "duration";
	public static final String KEY_PRESSURE = "pressure";
	public static final String KEY_INTENSITY = "intensity";
	public static final String KEY_SESSION_NO = "sessionNo";
	
	//Monarch tooltip labels
	public static final String KEY_START_BATTERY_LEVEL = "startBatteryLevel";
	public static final String KEY_END_BATTERY_LEVEL = "endBatteryLevel";
	public static final String KEY_ERROR_CODES = "errorCodes";
	public static final String KEY_BT_CHANGE_EVENTS = "btChangeEvents";
	public static final String KEY_POWER_CHANGE_EVENTS = "powerChangeEvents";
	
	//hill-1847
	//AdherenceTrend Graph Y-axis labels
	public static final String ADHERENCE_SCORE_LABEL = "Adherence Score";
		
	//AdherenceTrend Graph tooltip labels	
	public static final String RESET_SCORE = "scoreReset";
    //hill-1847
	
	//Gimp-14
	public static final String TEST_RESULTS="TestResults";
	public static final String FVC_P = "Avg FVC% Predicted";
	public static final String FEV1_P = "Avg FEV1% Predicted";
	//Gimp-14
	
	// Compliance Graph 
	public static final String KEY_MAX = "max";
	public static final String KEY_MIN = "min";
	public static final String KEY_THERAPY_DATA = "therapyData";
	public static final String KEY_PROTOCOL = "protocol";
	public static final String PRESSURE_LABEL = "Avg Pressure/Intensity";
	public static final String INTENSITY_LABEL = "Avg Pressure/Intensity";
	public static final String FREQUENCY_LABEL = "Avg Frequency";
	public static final String DURATION_LABEL = "Avg Duration";
	
	// Cumulative Stats Graph 
	public static final String HMR_NON_ADHERENCE_LABEL = "Patients Below Therapy Minutes";
	public static final String SETTING_DEVIATION_LABEL = "Patients Below Frequency Setting";
	public static final String MISSED_THERAPY_DAYS_LABEL = "Patients with Missed Therapy Day(s)";
	public static final String NO_TRANSMISSION_RECORDED_LABEL = "Patients No Transmission Recorded";

	// Treatment Stats Graph
	public static final String AVERAGE_LENGTH_OF_TREATMENT_LABEL = "Average Length of Treatment";
	public static final String AVERAGE_TREATMENTS_PER_DAY_LABEL = "Average Treatments Per Day";

	// Bench Mark Parameter
	public static final String BM_PARAM_SETTING_DEVIATION = "settingdeviation";
	public static final String BM_PARAM_HMR_DEVIATION = "hmrdeviation";
	public static final String BM_PARAM_MISSED_THERAPY_DAYS = "missedtherapy";
	public static final String BM_PARAM_ADHERENCE_SCORE = "adherencescore";
	public static final String BM_PARAM_HMR_RUNRATE = "hmrrunrate";

	public static final String KEY_TOTAL_PATIENTS = "totalPatients";

	// Constants used for calculating time-period between days
	public static final String DAY_STRING = "Day";
	public static final String MONTH_STRING = "Month";
	public static final String YEAR_STRING = "Year";
	
	public static final String BM_TYPE_AVERAGE = "average";
	public static final String BM_TYPE_MEDIAN = "median";
	public static final String BM_TYPE_PERCENTILE = "percentile";
	
	public static final String AGE_GROUP = "agegroup";
	public static final String CLINIC_SIZE = "clinicsize";

	public static final String KEY_RANGE_LABELS = "rangeLabels";
	public static final String KEY_BENCH_MARK_DATA = "benchMarkData";
	
	// BenchMark Axis Labels
	public static final String BM_PARAM_SETTING_DEVIATION_LABEL = "Cumulative Frequency Deviation Days";
	public static final String BM_PARAM_HMR_DEVIATION_LABEL = "HMR Non Adherence";
	public static final String BM_PARAM_MISSED_THERAPY_DAYS_LABEL = "Cumulative Missed Days";
	public static final String BM_PARAM_ADHERENCE_SCORE_LABEL = "Adherence Score";
	public static final String BM_PARAM_HMR_RUNRATE_LABEL = " Average Session Minutes";

	public static final String AGE_GROUP_LABEL = "Age Group";
	public static final String CLINIC_SIZE_LABEL = "Clinic Size";
	
	// BenchMark Filter Constants
	public static final String RANGE_SEPARATOR = "-";
	public static final String AGE_RANGE_0_TO_5 = "0"+RANGE_SEPARATOR+"5";
	public static final String AGE_RANGE_6_TO_10 = "6"+RANGE_SEPARATOR+"10";
	public static final String AGE_RANGE_11_TO_15 = "11"+RANGE_SEPARATOR+"15";
	public static final String AGE_RANGE_16_TO_20 = "16"+RANGE_SEPARATOR+"20";
	public static final String AGE_RANGE_21_TO_25 = "21"+RANGE_SEPARATOR+"25";
	public static final String AGE_RANGE_26_TO_30 = "26"+RANGE_SEPARATOR+"30";
	public static final String AGE_RANGE_31_TO_35 = "31"+RANGE_SEPARATOR+"35";
	public static final String AGE_RANGE_36_TO_40 = "36"+RANGE_SEPARATOR+"40";
	public static final String AGE_RANGE_41_TO_45 = "41"+RANGE_SEPARATOR+"45";
	public static final String AGE_RANGE_46_TO_50 = "46"+RANGE_SEPARATOR+"50";
	public static final String AGE_RANGE_51_TO_55 = "51"+RANGE_SEPARATOR+"55";
	public static final String AGE_RANGE_56_TO_60 = "56"+RANGE_SEPARATOR+"60";
	public static final String AGE_RANGE_61_TO_65 = "61"+RANGE_SEPARATOR+"65";
	public static final String AGE_RANGE_66_TO_70 = "66"+RANGE_SEPARATOR+"70";
	public static final String AGE_RANGE_71_TO_75 = "71"+RANGE_SEPARATOR+"75";
	public static final String AGE_RANGE_76_TO_80 = "76"+RANGE_SEPARATOR+"80";
	public static final String AGE_RANGE_81_AND_ABOVE = "81"+RANGE_SEPARATOR+"above";

	
	public static final String CLINIC_SIZE_RANGE_1_TO_25 = "1"+RANGE_SEPARATOR+"25";
	public static final String CLINIC_SIZE_RANGE_26_TO_50 = "26"+RANGE_SEPARATOR+"50";
	public static final String CLINIC_SIZE_RANGE_51_TO_75 = "51"+RANGE_SEPARATOR+"75";
	public static final String CLINIC_SIZE_RANGE_76_TO_100 = "76"+RANGE_SEPARATOR+"100";
	public static final String CLINIC_SIZE_RANGE_101_TO_150 = "101"+RANGE_SEPARATOR+"150";
	public static final String CLINIC_SIZE_RANGE_151_TO_200 = "151"+RANGE_SEPARATOR+"200";
	public static final String CLINIC_SIZE_RANGE_201_TO_250 = "201"+RANGE_SEPARATOR+"250";
	public static final String CLINIC_SIZE_RANGE_251_TO_300 = "251"+RANGE_SEPARATOR+"300";
	public static final String CLINIC_SIZE_RANGE_301_TO_350 = "301"+RANGE_SEPARATOR+"350";
	public static final String CLINIC_SIZE_RANGE_351_TO_400 = "351"+RANGE_SEPARATOR+"400";
	public static final String CLINIC_SIZE_RANGE_401_AND_ABOVE = "401"+RANGE_SEPARATOR+"above";
	
	public static final String BENCHMARK_DATA_SELF = "self";
	
	public static final String BENCHMARK_DATA_CLINIC = "clinicLevel";
	
	public static final String RELATION_LABEL_SELF = "Self";

	// Clinic And Disease benchmarking
	public static final String BOTH = "both";
	
	public static final String[] AGE_RANGE_LABELS = new String[]{
		AGE_RANGE_0_TO_5,AGE_RANGE_6_TO_10,AGE_RANGE_11_TO_15,
		AGE_RANGE_16_TO_20,AGE_RANGE_21_TO_25,AGE_RANGE_26_TO_30,AGE_RANGE_31_TO_35,
		AGE_RANGE_36_TO_40,AGE_RANGE_41_TO_45,AGE_RANGE_46_TO_50,AGE_RANGE_51_TO_55,
		AGE_RANGE_56_TO_60,AGE_RANGE_61_TO_65,AGE_RANGE_66_TO_70,AGE_RANGE_71_TO_75,
		AGE_RANGE_76_TO_80,AGE_RANGE_81_AND_ABOVE
	};
	
	public static final String[] CLINIC_SIZE_RANGE_LABELS = new String[]{
		CLINIC_SIZE_RANGE_1_TO_25,CLINIC_SIZE_RANGE_26_TO_50,
		CLINIC_SIZE_RANGE_51_TO_75,CLINIC_SIZE_RANGE_76_TO_100,CLINIC_SIZE_RANGE_101_TO_150,
		CLINIC_SIZE_RANGE_151_TO_200,CLINIC_SIZE_RANGE_201_TO_250,CLINIC_SIZE_RANGE_251_TO_300,
		CLINIC_SIZE_RANGE_301_TO_350,CLINIC_SIZE_RANGE_351_TO_400,CLINIC_SIZE_RANGE_401_AND_ABOVE
	};
	
	// HCP and Clinic Admin Bench Marking
	public static final String KEY_MY_CLINIC = "myClinic";
	public static final String KEY_OTHER_CLINIC = "otherClinics";
	public static final String BM_TYPE_AVERAGE_LABEL = "Avg.";
	public static final String BM_TYPE_MEDIAN_LABEL = "Med.";
	public static final String BM_TYPE_PERCENTILE_LABEL = "Percentile.";
	
	//start:announcement changes
		public static final String ANNOUNCEMENT_FILE_PATH = "/opt/visiview-files/";
	//end:announcement changes
		
	    public static final String TIMS_CSV_FILE_PATH = "/home/TIMs/flat_file_script/";
	    public static final String TIMS_CSV_FILE_PATH_MANUAL = "/home/TIMs/flat_file_script/manual";
		public static final String CREATED_BY_TIMS = "TIMS Java App";
		public static final String TIMS_LOG_LOCATION = "/usr/tomcat/apache-tomcat-8.0.28/TIMS/logs/";
		
		public static final String UPLOAD_FILE_PATH ="/opt/mobile-files/";
		public static final String PROFILE_FILE_PATH ="/mobile-files/";
		public static final String CERTIFICATE_DIR ="security/";
		public static final String EMAIL_IMAGES = "public/email-images/";
		public static final String PDF_DIR ="/opt/pdf-dir/";
		
	//Device Type
	public static final String VEST = "VEST";
	public static final String MONARCH = "MONARCH";
	public static final String TITAN = "TITAN";
	
	public static final String INTENSITY = "Intensity";
	
	public enum CONNECTIONTYPE {devWIFI, devLTE, devBT}	
	
	public static final String LOG_DIRECTORY = "/usr/tomcat/apache-tomcat-8.0.28/TIMS/logs/";
	public static final String FAILURE_STRING = "Failure";
	
	public static final String THERAPY_SESSION_TOTAL = "THERAPY SESSION TOTAL";
	public static final String DATE_RANGE_REPORT = "Date Range of Report";
	
	public static final String MONARCH_EVENT_CODES = "monarch_event_codes";
	public static final String MONARCH_ERROR_CODES = "monarch_error_codes";

	public static final String TITAN_EVENT_CODES = "titan_event_codes";
	public static final String TITAN_ERROR_CODES = "titan_error_codes";
	
	public static final String EVENT_ERROR_CODE = "22";
	
	// For test results graph
	public static final String NOT_IN_RANGE="No test results available for the date(s) selected";	
	public static final String NEVER_DONE="No test results have been entered";
	public static final String RESULT="result";	
	public static final String EMAILCHECK_TIMS_CREATE="New patient created with new device \\ Duplicate email ID for patient";
	public static final String EMAILCHECK_TIMS_UPDATE="Device assigned to patient \\ Duplicate email ID for patient";
	
	public static final String EMAILCHECK_TIMS_CREATE_MONARCH="Monarch patient updated \\ Duplicate email ID for patient";
	
	public static final int MAX_FREQUENCY = 20;
	public static final int MIN_FREQUENCY = 5;
	public static final int MAX_INTESITY = 10;
	public static final int MIN_INTESITY = 1;
	public static final int MAX_DURATION = 60;
	public static final int MIN_DURATION = 1;
    public static final int DEFAULT_FREQUENCY=20;
    public static final int DEFAULT_PRESSURE=10;
    public static final int MAX_PRESSURE = 10;
    public static final int MIN_PRESSURE = 1;

	
	public static final String SUCCESS_ACTIVE_STATUS="MED_ISACTIVE_SUCCESS";
	public static final String FAILURE_ACTIVE_STATUS="MED_ISACTIVE_FAIL";
	
	public static final String SUCCESS_ARCHIVE_STATUS="MED_ARCHIEVE_UPDATE_SUCCESS";
	public static final String FAILURE_ARCHIVE_STATUS="MED_ARCHIEVE_UPDATE_FAIL";
	
	public static final String MED_TAKEN_SUCCESS="MED_IS_TAKEN_SUCCESS";
	public static final String MED_NOT_TAKEN_SUCCESS="MED_IS_NOT_TAKEN_SUCCESS";
	public static final String MED_FAILURE="PatientId/MedicationId/ReminderId is not valid";
	
	
	
	public static final String SUCCESS_UPDATE_MESSAGE="Patient medication updated successfully";
	
	public static final String NO_RETRIEVE="No Medication for the day";
	public static final String NO_PATIENTID="PatientId/Date is wrong";
	
	public static final Long Goal_Total_Id =  72053L;
	public static final int Goal_Completed =  100;
	public static final Long Nutrition_Goal = 72052L;
	
	/**
	 * creating version number for mobile APIs
	 */
	public static final String ApiVersion = "v1.0";
	
	 /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Sunday.
     */
    public final static int SUNDAY = 1;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Monday.
     */
    public final static int MONDAY = 2;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Tuesday.
     */
    public final static int TUESDAY = 3;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Wednesday.
     */
    public final static int WEDNESDAY = 4;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Thursday.
     */
    public final static int THURSDAY = 5;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Friday.
     */
    public final static int FRIDAY = 6;

    /**
     * Value of the {@link #DAY_OF_WEEK} field indicating
     * Saturday.
     */
    public final static int SATURDAY = 7;
    public static final String ENV_SPRING_AUTHENTICATE = "authenticate.";
    public static final String TOKEN_KEY = "c2VjdXJlVG9rZW5HZW5lcmF0b3I=";
    
    public final static String BYOD_NOT_PAIRED = "NOT_PAIRED";
    public static final String BYOD_PAIRED = "PAIRED";
    public static final String BYOD_OPT_OUT_REQUESTED = "OPT_OUT_REQUESTED";
    public static final String BYOD_OPTED_OUT= "OPTED_OUT";
    
    public static final String UTC_MINUS12 = "#UTC-12:00";		
    public static final String UTC_MINUS11 = "#UTC-11:00";
    public static final String UTC_MINUS10 = "#UTC-10:00";
    public static final String UTC_MINUS9 = "#UTC-09:00";
    public static final String UTC_MINUS8 = "#UTC-08:00";
    public static final String UTC_MINUS7 = "#UTC-07:00";
    public static final String UTC_MINUS6 = "#UTC-06:00";
    public static final String UTC_MINUS5 = "#UTC-05:00";
    public static final String UTC_MINUS4 = "#UTC-04:00";
    public static final String UTC_NST = "#UTC-03:30";
    public static final String UTC_NDT = "#UTC-02:30";
    public static final String UTC_PLUS10 = "#UTC+10:00";
    
    public static final String IDLW = "IDLW"+Constants.UTC_MINUS12;
    public static final String SST = "SST"+Constants.UTC_MINUS11;
    public static final String HST = "HST"+Constants.UTC_MINUS10;
    public static final String AKST = "AKST"+Constants.UTC_MINUS9;
    public static final String AKDT = "AKDT"+Constants.UTC_MINUS8;
    public static final String PST = "PST"+Constants.UTC_MINUS8;
    public static final String PDT = "PDT"+Constants.UTC_MINUS7;
    public static final String MST = "MST"+Constants.UTC_MINUS7;
    public static final String MDT = "MDT"+Constants.UTC_MINUS6;
    public static final String CST = "CST"+Constants.UTC_MINUS6;
    public static final String CDT = "CDT"+Constants.UTC_MINUS5;
    public static final String EST = "EST"+Constants.UTC_MINUS5;
    public static final String EDT = "EDT"+Constants.UTC_MINUS4;
    public static final String ATZ = "ATZ"+Constants.UTC_MINUS4;
    public static final String NST = "NST"+Constants.UTC_NST;
    public static final String NDT = "NDT"+Constants.UTC_NDT;
    public static final String ChST = "ChST"+Constants.UTC_PLUS10;
    
    // bcc recipients size
    public static final int BCC_BATCH_SIZE = 100;
    
	// DST
    public static final String CST_STR = "America/Chicago";
    public static final Long ANDROID_DST_OFFSET = 21600000L;
    public static final Long ANDROID_NON_DST_OFFSET = 18000000L;
    public static final Long IOS_DST_OFFSET = (-3600000L); // Reduce 1 hrs from EDT to CDT
    public static final Long IOS_NON_DST_OFFSET = (-3600000L); // Reduce 1 hrs from EST to CST
    
    public static final int DELTA_DAYS = 60; 
    
    public static final String ANDROID = "android";
    public static final String IOS = "ios";
    
    public static final int PUSH_NOTIFICATION_HMR_DEVIATION=9;    
    public static final int PUSH_NOTIFICATION_MISSED_THERAPY_DEVIATION=8;
	public static final int PUSH_NOTIFICATION_ALL_PARAMETERS_DEVIATED = 7;
	public static final int PUSH_NOTIFICATION_DURATION_FREQENCY_DEVIATED = 6;
	public static final int PUSH_NOTIFICATION_DURATION_PRESSURE_DEVIATED = 5;
	public static final int PUSH_NOTIFICATION_DURATION_DEVIATED = 4;
	public static final int PUSH_NOTIFICATION_FREQUENCY_PRESSURE_DEVIATED = 3;
	public static final int PUSH_NOTIFICATION_FREQUENCY_DEVIATED = 2;
    public static final int PUSH_NOTIFICATION_PRESSURE_DEVIATED=1;
    public static final int PUSH_NOTIFICATION_NO_DEVIATION=0;
	public static final int INCORRECT_PWD_TRY = 5;
    public static final String APP_BUNDLE_ID = "com.myvisiview.ios";
    public static final long LOCK_TIME_DURATION= 30 *  60 * 1000 ;
    
    public static final String FAIL = "FAIL";
    public static final String OK = "OK";
}

