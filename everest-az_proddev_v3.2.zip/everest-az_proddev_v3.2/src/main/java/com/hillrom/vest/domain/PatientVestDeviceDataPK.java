package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Embeddable
public class PatientVestDeviceDataPK implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "timestamp")
	private Long timestamp;
	
	@Column(name = "bluetooth_id")
	private String bluetoothId;
	
	@Column(name="event_id")
	private String eventId;
	
	@ManyToOne(optional=false,targetEntity=PatientInfo.class,cascade={CascadeType.ALL})
	@JoinColumn(name="patient_id",referencedColumnName="id")
	private PatientInfo patient;

	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bluetoothId == null) ? 0 : bluetoothId.hashCode());
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		result = prime * result + ((patient == null) ? 0 : patient.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientVestDeviceDataPK other = (PatientVestDeviceDataPK) obj;
		if (bluetoothId == null) {
			if (other.bluetoothId != null)
				return false;
		} else if (!bluetoothId.equals(other.bluetoothId))
			return false;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} else if (!eventId.equals(other.eventId))
			return false;
		if (patient == null) {
			if (other.patient != null)
				return false;
		} else if (!patient.equals(other.patient))
			return false;
		if (timestamp == null) {
			if (other.timestamp != null)
				return false;
		} else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PatientVestDeviceDataPK [timestamp=" + timestamp + ", bluetoothId=" + bluetoothId + ", eventId="
				+ eventId + ", patient=" + patient + "]";
	}

	/**
	 * @return the timestamp
	 */
	public Long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the bluetoothId
	 */
	public String getBluetoothId() {
		return bluetoothId;
	}

	/**
	 * @param bluetoothId the bluetoothId to set
	 */
	public void setBluetoothId(String bluetoothId) {
		this.bluetoothId = bluetoothId;
	}

	/**
	 * @return the eventId
	 */
	public String getEventId() {
		return eventId;
	}

	/**
	 * @param eventId the eventId to set
	 */
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	/**
	 * @return the patient
	 */
	public PatientInfo getPatient() {
		return patient;
	}

	/**
	 * @param patient the patient to set
	 */
	public void setPatient(PatientInfo patient) {
		this.patient = patient;
	}

	public PatientVestDeviceDataPK() {
		super();
	}
	public PatientVestDeviceDataPK(Long timestamp, String bluetoothId, String eventId, PatientInfo patient) {
		super();
		this.timestamp = timestamp;
		this.bluetoothId = bluetoothId;
		this.eventId = eventId;
		this.patient = patient;
	}	
	
}
