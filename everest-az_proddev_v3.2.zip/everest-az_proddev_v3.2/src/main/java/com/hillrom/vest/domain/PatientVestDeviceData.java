package com.hillrom.vest.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PATIENT_VEST_DEVICE_DATA")
public class PatientVestDeviceData implements Serializable,Comparable<PatientVestDeviceData>,Cloneable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "sequence_number")
	private Integer sequenceNumber;

	@Column(name = "serial_number")
	private String serialNumber;
	
	@Column(name="hub_id")
	private String hubId;
	
	@EmbeddedId
	private PatientVestDeviceDataPK patientVestDeviceDataPK;
	
	private Double hmr;
	
	private Integer frequency;
	
	private Integer pressure;
	
	private Integer duration;


	private Integer checksum;
	
	@JsonIgnore
	@ManyToOne(optional=false,targetEntity=User.class)
	@JoinColumn(name="user_id",referencedColumnName="id")
	private User patientUser;
	
	
	public PatientVestDeviceDataPK getPatientVestDeviceDataPK() {
		return patientVestDeviceDataPK;
	}

	public void setPatientVestDeviceDataPK(PatientVestDeviceDataPK patientVestDeviceDataPK) {
		this.patientVestDeviceDataPK = patientVestDeviceDataPK;
	}

	public Long getTimestamp() {
		return this.getPatientVestDeviceDataPK().getTimestamp();
	}

	public void setTimestamp(Long timestamp) {
		this.getPatientVestDeviceDataPK().setTimestamp(timestamp);
	}

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getBluetoothId() {
		return this.getPatientVestDeviceDataPK().getBluetoothId();
	}

	public void setBluetoothId(String bluetoothId) {
		this.getPatientVestDeviceDataPK().setBluetoothId(bluetoothId);
	}

	public String getHubId() {
		return hubId;
	}

	public void setHubId(String hubId) {
		this.hubId = hubId;
	}

	public String getEventId() {
		return this.getPatientVestDeviceDataPK().getEventId();
	}

	public void setEventId(String eventId) {
		this.getPatientVestDeviceDataPK().setEventId(eventId);
	}
	
	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Integer getPressure() {
		return pressure;
	}

	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public PatientInfo getPatient() {
		return this.getPatientVestDeviceDataPK().getPatient();
	}

	public void setPatient(PatientInfo patient) {
		this.getPatientVestDeviceDataPK().setPatient(patient);
	}

	public Integer getChecksum() {
		return checksum;
	}

	public void setChecksum(Integer checksum) {
		this.checksum = checksum;
	}

	public User getPatientUser() {
		return patientUser;
	}

	public void setPatientUser(User patientUser) {
		this.patientUser = patientUser;
	}



	/*@Override
	public String toString() {
		return "PatientVestDeviceData [sequenceNumber=" + sequenceNumber + ", serialNumber=" + serialNumber + ", hubId="
				+ hubId + ", hmr=" + hmr + ", frequency="
				+ frequency + ", pressure=" + pressure + ", duration=" + duration + ", checksum=" + checksum
				+ ", patientUser=" + patientUser + "]";
	}*/

	@JsonIgnore
	public DateTime getDate(){
		return new DateTime(this.getPatientVestDeviceDataPK().getTimestamp());
	}
	
	@JsonIgnore
	public double getHmrInHours(){
		if(Objects.nonNull(hmr))
			return new BigDecimal(this.hmr/(60*60) ).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		else
			return 0;
	}
	
	@JsonIgnore
	public String getPatientBlueToothAddress(){
		return "PAT_ID:BT:"+this.getPatientVestDeviceDataPK().getBluetoothId();
	}

	@Override
	public int compareTo(PatientVestDeviceData o) {
		return this.getTimestamp().compareTo(o.getTimestamp());
	}
	
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
	}


	public PatientVestDeviceData(Integer sequenceNumber, String serialNumber, String hubId,
			PatientVestDeviceDataPK patientVestDeviceDataPK, Double hmr, Integer frequency, Integer pressure,
			Integer duration, Integer checksum, User patientUser) {
		super();
		this.sequenceNumber = sequenceNumber;
		this.serialNumber = serialNumber;
		this.hubId = hubId;
		this.patientVestDeviceDataPK = patientVestDeviceDataPK;
		this.hmr = hmr;
		this.frequency = frequency;
		this.pressure = pressure;
		this.duration = duration;
		this.checksum = checksum;
		this.patientUser = patientUser;
	}

	public PatientVestDeviceData() {
		// TODO Auto-generated constructor stub
	}

	public static Comparator<PatientVestDeviceData> vestDateAscComparator = new Comparator<PatientVestDeviceData>() {	
 		public int compare(PatientVestDeviceData obj1, PatientVestDeviceData obj2) {	
			DateTime sortByDate1 = obj1.getDate();	
			DateTime sortByDate2 = obj2.getDate();	
			// ascending order	
			return sortByDate1.compareTo(sortByDate2);	
		}	
	};
	public PatientVestDeviceData(Integer sequenceNumber, String serialNumber, String hubId,
			PatientVestDeviceDataPK patientVestDeviceDataPK, Double hmr, Integer frequency, Integer pressure,
			Integer duration, User patientUser) {
		super();
		this.sequenceNumber = sequenceNumber;
		this.serialNumber = serialNumber;
		this.hubId = hubId;
		this.patientVestDeviceDataPK = patientVestDeviceDataPK;
		this.hmr = hmr;
		this.frequency = frequency;
		this.pressure = pressure;
		this.duration = duration;
		this.patientUser = patientUser;
	}
}
