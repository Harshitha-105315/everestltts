/**
 * JPA domain objects.
 */
package com.hillrom.vest.domain;
