package com.hillrom.vest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.CorruptedMonarchDeviceDataEvents;

public interface CorruptedMonarchDeviceDataEventsRepository extends
			JpaRepository<CorruptedMonarchDeviceDataEvents, Long> {

	@Query("from CorruptedMonarchDeviceDataEvents cmdde where cmdde.serialNumber IS NOT NULL")
	List<CorruptedMonarchDeviceDataEvents> findAllWithSerialNumber();
}
