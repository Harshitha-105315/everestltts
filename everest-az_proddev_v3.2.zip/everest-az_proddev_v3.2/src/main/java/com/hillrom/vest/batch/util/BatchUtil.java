package com.hillrom.vest.batch.util;

public class BatchUtil {
	
	public static boolean flag;
	
}
