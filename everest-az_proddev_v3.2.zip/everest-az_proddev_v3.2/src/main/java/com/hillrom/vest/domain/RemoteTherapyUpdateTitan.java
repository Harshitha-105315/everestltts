package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="REMOTE_THERAPY_UPDATE_TITAN")
@SQLDelete(sql="UPDATE REMOTE_THERAPY_UPDATE_TITAN SET is_deleted = 1 WHERE id = ?")
public class RemoteTherapyUpdateTitan implements Serializable ,Comparable<RemoteTherapyUpdateTitan>{
	
    private static final long serialVersionUID = 1L;

	@JsonIgnore
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name = "patient_id")
	private String patientId;
	
	/*@JsonIgnore
	@ManyToOne(optional=false,targetEntity=User.class,fetch=FetchType.LAZY)
	@JoinColumn(name="user_id",referencedColumnName="id")
	private User patientUser;*/
	
	@Column(name="create_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createDate;
	
	@Column(name="update_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime updateDate;
	
	@Column(name="therapy_name")
	private String therapyName;
	
	@Column(name="therapy_type")
	private Integer therapyType;
	
	@Column(name="device_type")
	private String deviceType;
	
	@Column(name="step")
	private Integer step;
	
	@Column(name="frequency")
	private Integer frequency;
	
	@Column(name="intensity")
	private Integer intensity;
	
	@Column(name="duration_in_minutes")
	private Integer duration;
	
	@Column(name="caugh_pause_duration")
	private Integer caughPauseDuration;
	
	@Column(name="caugh_pause_enable")
	private Integer caughPauseEnable;
	
	@Column(name="caugh_interval_mode")
	private Integer caughIntervalMode;
	
	@Column(name="caugh_auto_enable")
	private Integer caughAutoEnable;
	
	@Column(name="caugh_pause_interval")
	private Integer caughPauseInterval;
	
	@Column(name="status")
	private String status;
	
	@Column(name="email_id")
    private String emailId;
	
	@Column(name="is_deleted")
    @JsonIgnore
    private boolean deleted = false;
	
	@Column(name="is_accepted")
	@JsonIgnore
	private boolean accepted=false;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public DateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(DateTime createDate) {
		this.createDate = createDate;
	}
	
	public DateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(DateTime updateDate) {
		this.updateDate = updateDate;
	}
	
	public String getTherapyName() {
		return therapyName;
	}

	public void setTherapyName(String therapyName) {
		this.therapyName = therapyName;
	}

	public Integer getTherapyType() {
		return therapyType;
	}

	public void setTherapyType(Integer therapyType) {
		this.therapyType = therapyType;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public Integer getStep() {
		return step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Integer getIntensity() {
		return intensity;
	}

	public void setIntensity(Integer intensity) {
		this.intensity = intensity;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getCaughPauseDuration() {
		return caughPauseDuration;
	}

	public void setCaughPauseDuration(Integer caughPauseDuration) {
		this.caughPauseDuration = caughPauseDuration;
	}

	public Integer getCaughPauseEnable() {
		return caughPauseEnable;
	}

	public void setCaughPauseEnable(Integer caughPauseEnable) {
		this.caughPauseEnable = caughPauseEnable;
	}

	public Integer getCaughIntervalMode() {
		return caughIntervalMode;
	}

	public void setCaughIntervalMode(Integer caughIntervalMode) {
		this.caughIntervalMode = caughIntervalMode;
	}

	public Integer getCaughAutoEnable() {
		return caughAutoEnable;
	}

	public void setCaughAutoEnable(Integer caughAutoEnable) {
		this.caughAutoEnable = caughAutoEnable;
	}

	public Integer getCaughPauseInterval() {
		return caughPauseInterval;
	}

	public void setCaughPauseInterval(Integer caughPauseInterval) {
		this.caughPauseInterval = caughPauseInterval;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public boolean isAccepted() {
		return accepted;
	}

	public void setAccepted(boolean accepted) {
		this.accepted = accepted;
	}

	@Override
	public String toString() {
		return "RemoteTherapyUpdateTitan [id=" + id + ", patientId=" + patientId + ", createDate=" + createDate
				+ ", updateDate=" + updateDate + ", therapyName=" + therapyName + ", therapyType=" + therapyType
				+ ", deviceType=" + deviceType + ", step=" + step + ", frequency=" + frequency + ", intensity="
				+ intensity + ", duration=" + duration + ", caughPauseDuration=" + caughPauseDuration
				+ ", caughPauseEnable=" + caughPauseEnable + ", caughIntervalMode=" + caughIntervalMode
				+ ", caughAutoEnable=" + caughAutoEnable + ", caughPauseInterval=" + caughPauseInterval + ", status="
				+ status + ", emailId=" + emailId + ", deleted=" + deleted + ", accepted=" + accepted + "]";
	}

	@Override
	public int compareTo(RemoteTherapyUpdateTitan rtut) {
		return (int) (this.id - rtut.getId());
	}
}