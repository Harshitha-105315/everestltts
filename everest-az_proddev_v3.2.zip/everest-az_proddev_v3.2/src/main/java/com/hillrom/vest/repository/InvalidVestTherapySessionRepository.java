package com.hillrom.vest.repository;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.InvalidVestTherapySession;
import com.hillrom.vest.domain.TherapySession;

public interface InvalidVestTherapySessionRepository extends
		JpaRepository<InvalidVestTherapySession, Long> {

	public InvalidVestTherapySession findTop1ByPatientUserIdOrderByEndTimeDesc(Long patientUserId);

	@Query("from InvalidVestTherapySession tps where tps.patientUser.id =?1 and tps.date between ?2 and ?3")
	public List<InvalidVestTherapySession> findByPatientUserIdAndDateRange(Long patientUserId, LocalDate fromTimestamp,
			LocalDate toTimestamp);

	@Query("from InvalidVestTherapySession tps where tps.patientUser.id =?1 and tps.date = ?2")
	public List<InvalidVestTherapySession> findByPatientUserIdAndDate(Long patientUserId,
			LocalDate dateTime);
	
	public InvalidVestTherapySession findTop1ByPatientUserIdOrderByDateAsc(Long patientUserId);
	
	public List<InvalidVestTherapySession> findTop1ByPatientUserIdInOrderByEndTimeDesc(List<Long> patientUserIds);

	public List<InvalidVestTherapySession> findByDateBetweenAndPatientUserIdIn(LocalDate fromTimestamp,
			LocalDate toTimestamp,List<Long> patientUserIds);
	
	public List<InvalidVestTherapySession> findByDateBetweenAndPatientUserId(LocalDate fromTimestamp,
			LocalDate toTimestamp,Long patientUserId);
	
	public InvalidVestTherapySession findTop1ByPatientUserIdAndDateBeforeOrderByEndTimeDesc(Long patientUserId,LocalDate from);

	public InvalidVestTherapySession findByPatientUserId(Long patientUserId);
	
	@Query("from InvalidVestTherapySession tps where tps.patient_id =?1")
	public InvalidVestTherapySession findByPatientId(String patientId);
	
	@Query("from InvalidVestTherapySession tps where tps.patient_id IS NOT NULL")
	List<InvalidVestTherapySession> findAllWithPatientIds();
	
	@Query("from InvalidVestTherapySession tps where tps.serialNumber IS NOT NULL")
	List<InvalidVestTherapySession> findAllWithSerialNumber();
}
