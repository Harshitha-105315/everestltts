package com.hillrom.vest.config;

import javax.inject.Inject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.data.repository.query.SecurityEvaluationContextExtension;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.security.Http401UnauthorizedEntryPoint;
import com.hillrom.vest.security.RestExceptionTranslationFilter;
import com.hillrom.vest.security.xauth.XAuthTokenConfigurer;
import com.hillrom.vest.service.UserLoginTokenService;
import com.hillrom.vest.service.UserService;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Inject
    private Http401UnauthorizedEntryPoint authenticationEntryPoint;

    @Inject
    private UserDetailsService userDetailsService;

    @Inject
    private UserLoginTokenService authTokenService;
    

    @Inject
    private UserService userService;
    
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public AuthenticationProvider getAuthenticationProvider(){
    	return new com.hillrom.vest.security.AuthenticationProvider(passwordEncoder(),userService);
    }
    
    @Inject
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(getAuthenticationProvider());
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers("/scripts/**/*.{js,html}")
            .antMatchers("/bower_components/**")
            .antMatchers("/i18n/**")
            .antMatchers("/assets/**")
            .antMatchers("/test/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
        	.cors().and()
            .exceptionHandling()
            .authenticationEntryPoint(authenticationEntryPoint)
        .and()
            .csrf()
            .disable()
            .headers()
            .frameOptions()
            .disable()
        .and()
            .sessionManagement()
            .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
            .authorizeRequests()
            .antMatchers("/api/register").permitAll()
            .antMatchers("/api/getEncryptionString").permitAll()
            .antMatchers("/api/activate").permitAll()
            .antMatchers("/api/authenticate").permitAll()
            .antMatchers("/api/v1.0/authenticate").permitAll()
            .antMatchers("/api/account/reset_password/init").permitAll()
            .antMatchers("/api/v1.0/account/reset_password/init").permitAll()
            .antMatchers("/api/account/reset_password/finish").permitAll()
            .antMatchers("/api/v1.0/account/reset_password/finish").permitAll()
            .antMatchers("/api/recaptcha").permitAll()
            .antMatchers("/api/securityQuestions").permitAll()
            .antMatchers("/api/account/update_passwordsecurityquestion").permitAll()
            .antMatchers("/api/v1.0/account/update_passwordsecurityquestion").permitAll()
            .antMatchers("/api/receiveData").permitAll()
            .antMatchers("/api/receiveDataCharger").permitAll()
            .antMatchers("/api/receiveDataOptimus").permitAll()
            .antMatchers("/api/receiveDataTitan").permitAll()
            .antMatchers("/api/titanDevice").permitAll()
            .antMatchers("/api/titan/therapySetting").permitAll()
            .antMatchers("/api/rtuHistory/{patientId}").permitAll() 
            .antMatchers("/api/getRtuHistory/{patientId}").permitAll() 
            .antMatchers("/api/uploadRTU").permitAll()
            .antMatchers("/api/patient/{id}/vestdevicedata").permitAll()
            .antMatchers("/api/vestdevicedata").permitAll()
            .antMatchers("/api/chargerdevicedata").permitAll()
            .antMatchers("/api/chargerdevicedatalist").permitAll()
            .antMatchers("/api/chargerdevicedata/{id}").permitAll() 
            .antMatchers("/api/optimusdevicedata").permitAll()
            .antMatchers("/api/optimusDeviceData/{id}").permitAll()
            .antMatchers("/api/optimusdevicedatalist").permitAll()
            .antMatchers("/api/validateActivationKey").permitAll()
            .antMatchers("/api/validateResetKey").permitAll()
            .antMatchers("/api/account/re_register").permitAll()
            .antMatchers("/api/v1.0/account/re_register").permitAll()
	        .antMatchers("/api/patient/v1.0/profile/retrieveForceUpgrade/{version}/{deviceType}").permitAll()
             //FOTA API
            .antMatchers("/api/FOTA").permitAll()
            //Adherence cronjob
            .antMatchers("/api/testingAdherenceTraningDateCron").permitAll()
            .antMatchers("/mobile-images/**").authenticated()
            .antMatchers("/email-images/**").permitAll()
            .antMatchers("/api/users/{id}/exportVestDeviceData").authenticated()
            .antMatchers("/api/users/{id}/exportVestDeviceDataCSV").authenticated()
            .antMatchers("/api/users/{id}/exportTherapyData").authenticated()
            .antMatchers("/api/users/{id}/exportTherapyDataCSV").authenticated()
            .antMatchers("/api/users/{id}/therapyData").authenticated()
            .antMatchers("/api/logs/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/api/**").authenticated()
            .antMatchers("/api/account/**").authenticated()
            .antMatchers("/api/notes/**").authenticated()
            .antMatchers("/api/users/{id}/notes/**").authenticated()
            .antMatchers("/api/patients/{id}/notes/**").authenticated()
            .antMatchers("/metrics/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/health/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/trace/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/dump/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/shutdown/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/beans/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/configprops/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/info/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/autoconfig/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/env/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/trace/**").hasAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/api-docs/**").hasAuthority(AuthoritiesConstants.ADMIN)
             //hill-1845
            .antMatchers("/api/clinics/**").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            //hill-1845
            .antMatchers("/api/hillromteamuser/**").hasAnyAuthority(AuthoritiesConstants.ADMIN)
            .antMatchers("/protected/**").authenticated()
            .antMatchers("/api/user/{id}/changeSecurityQuestion").authenticated()
            .antMatchers("/api/v1.0/user/{id}/changeSecurityQuestion").authenticated()
            //hill-1845
            .antMatchers("/api/user/**").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            //hill-1845
            .antMatchers("/api/patient/**").hasAnyAuthority(AuthoritiesConstants.ADMIN)
	    // MOBILE API
	    //.antMatchers("/api/patient/v1.0/**").authenticated()
	    .antMatchers("/api/cityStateZipValuesByCity").authenticated()
            .antMatchers("/api/cityStateZipValuesBystate").authenticated()
            .antMatchers("/api/cityStateZipValuesByZipCode").authenticated()
            .antMatchers("/api/survey/**").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.PATIENT, AuthoritiesConstants.CUSTOMER_SERVICES)
            //hill-1845
            .antMatchers("/api/validateCredentials").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            .antMatchers("/api/v1.0/validateCredentials").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            .antMatchers("/api/loginAnalytics").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            .antMatchers("/api/survey/{id}/graph").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
            //hill-1845
            .antMatchers("/api/survey/{id}/graph").authenticated()      
            .antMatchers("/api/retrieveLogData/logs").permitAll()
            .antMatchers("/api/executeTIMSJob").hasAuthority(AuthoritiesConstants.ADMIN)
	     	// Goal API	
	     	.antMatchers("/api/patient/v1.0/**").permitAll()		
	     .antMatchers("/api/v1.0/devicedata/**").hasAnyAuthority(AuthoritiesConstants.ADMIN, AuthoritiesConstants.CUSTOMER_SERVICES)
        .and()
            .apply(securityConfigurerAdapter());

    }

    private XAuthTokenConfigurer securityConfigurerAdapter() {
      return new XAuthTokenConfigurer(userDetailsService, authTokenService);
    }

    @Bean
    public SecurityEvaluationContextExtension securityEvaluationContextExtension() {
        return new SecurityEvaluationContextExtension();
    }
    
    @Bean
    public ExceptionTranslationFilter exceptionTranslationFilter() {
	    RestExceptionTranslationFilter exceptionTranslationFilter = new  RestExceptionTranslationFilter(authenticationEntryPoint);
	    exceptionTranslationFilter.afterPropertiesSet();
	    return exceptionTranslationFilter;
    }
    
   
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS").allowedOrigins("*")
                    .allowedHeaders("*").exposedHeaders("x-total-count");
            }
        };
    }

}
