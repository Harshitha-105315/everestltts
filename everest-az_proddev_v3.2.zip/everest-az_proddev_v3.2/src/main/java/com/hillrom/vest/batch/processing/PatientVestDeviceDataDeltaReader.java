package com.hillrom.vest.batch.processing;

import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.config.Constants.MONARCH;
import static com.hillrom.vest.config.Constants.VEST;
import static com.hillrom.vest.security.AuthoritiesConstants.PATIENT;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Isolation;

import com.hillrom.mobile.service.AwardsAndBadgesCalculatorService;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientVestDeviceData;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.PatientVestDeviceRawLog;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.domain.UserPatientAssocPK;
import com.hillrom.vest.repository.AuthorityRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientVestDeviceDataRepository;
import com.hillrom.vest.repository.PatientVestDeviceRawLogRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.AdvanceAdherenceCalculationService;
import com.hillrom.vest.service.DeviceLogParser;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.PatientComplianceService;
import com.hillrom.vest.service.PatientInfoService;
import com.hillrom.vest.service.PatientNoEventService;
import com.hillrom.vest.service.PatientVestDeviceDataService;
import com.hillrom.vest.service.TherapySessionService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil;
import com.hillrom.vest.util.RelationshipLabelConstants;

public class PatientVestDeviceDataDeltaReader implements ItemReader<List<PatientVestDeviceData>> {

	private final Logger log = LoggerFactory.getLogger(PatientVestDeviceDataDeltaReader.class);
	
	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject
	private UserExtensionRepository userExtensionRepository;

	@Inject
	private AuthorityRepository authorityRepository;

	@Inject
	private DeviceLogParser deviceLogParser;

	@Inject
	private PatientNoEventService noEventService;

	@Inject
	private TherapySessionService therapySessionService;

	@Inject
	private PatientComplianceService complianceService;
	
	@Inject
	private PatientVestDeviceRawLogRepository deviceRawLogRepository;
	
	@Inject
	private PatientVestDeviceDataRepository vestDeviceDataRepository;

	@Inject
    private PatientVestDeviceRepository patientVestDeviceRepository;
	
	@Inject
    private PatientInfoService patientInfoService;
	
	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;
	
	@Inject
	private PatientVestDeviceDataService patientVestDeviceDataService;
	
	@Inject
	private AwardsAndBadgesCalculatorService awardsAndBadgesCalculatorService;
	
	@Inject
	private AdvanceAdherenceCalculationService advanceAdherenceCalculationService;
	
	private String patientDeviceRawData;
	
	private boolean isReadComplete;

	@Value("#{jobParameters['rawData']}")
	public void setRawData(final String rawData) {
		this.patientDeviceRawData = rawData;
		this.isReadComplete = false;
	}
	
	@Transactional(isolation=Isolation.SERIALIZABLE)
	private synchronized List<PatientVestDeviceData> parseRawData() throws Exception{
		log.debug("Parsing started rawData : ",patientDeviceRawData);
		PatientVestDeviceHistory latestDevice = null;
		PatientVestDeviceRawLog deviceRawLog = null;
		List<PatientVestDeviceData> patientVestDeviceEvents = null;
		final List<PatientVestDeviceData> patientVestDeviceValidEvents = new ArrayList<PatientVestDeviceData>();
        final List<PatientVestDeviceData> patientVestDeviceInvalidEvents = new ArrayList<PatientVestDeviceData>();
        
		Calendar cal = Calendar.getInstance();
        Timestamp timestamp = new Timestamp(DateUtil.getEndOfDay(new Date()).getTime());
        Timestamp timestampMinus6mths;
        cal.add(Calendar.DAY_OF_MONTH, -365);
        timestampMinus6mths = new Timestamp(cal.getTime().getTime());

		deviceRawLog = deviceLogParser.parseBase64StringToPatientVestDeviceRawLog(patientDeviceRawData);
		
		deviceRawLogRepository.save(deviceRawLog);
		
		patientVestDeviceEvents = deviceLogParser
				.parseBase64StringToPatientVestDeviceLogEntry(deviceRawLog.getDeviceData());
		
		
        patientVestDeviceEvents.forEach(patientVestDeviceEvent -> {
        	if(patientVestDeviceEvent.getTimestamp() <= timestamp.getTime() && patientVestDeviceEvent.getTimestamp() >= timestampMinus6mths.getTime()){
        		patientVestDeviceValidEvents.add(patientVestDeviceEvent);
        	}
        	else {
        		patientVestDeviceInvalidEvents.add(patientVestDeviceEvent);
        	}
        });
  
        long hubReceiveTime = deviceRawLog.getHubReceiveTime();
        String  hubReceiveDate = DateUtil.dateTime(hubReceiveTime);
       
       
		String deviceSerialNumber = deviceRawLog.getDeviceSerialNumber();
				
		if(!patientVestDeviceValidEvents.isEmpty())
		{
		UserPatientAssoc userPatientAssoc = createPatientUserIfNotExists(deviceRawLog, deviceSerialNumber);
		assignDefaultValuesToVestDeviceDataTemp(deviceRawLog, patientVestDeviceValidEvents, userPatientAssoc);
		}
		
		Optional<PatientDevicesAssoc> patientDetails = patientDevicesAssocRepository.findOneBySerialNumber(deviceSerialNumber);
		if(patientDetails.isPresent()){
			String patient_id = patientDetails.get().getPatientId();	
			latestDevice = patientVestDeviceRepository.findLatestInActiveDeviceByPatientId(patient_id,false);			
		}		
		if(patientDetails.isPresent() && !patientVestDeviceInvalidEvents.isEmpty()){
			patientVestDeviceDataService.invalidDataRequest(patientVestDeviceInvalidEvents,patientDetails,latestDevice,hubReceiveDate);
		}
		return patientVestDeviceValidEvents;
	}

	@Override
	public List<PatientVestDeviceData> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		log.debug("ItemReader started");
		if (isReadComplete)
			return null;

		List<PatientVestDeviceData> patientVestDeviceEvents = parseRawData();
		Long patientUserId = 0l, from,to;
		String serialNumber = "";
		String patientId = "";
		if(Objects.isNull(patientVestDeviceEvents) || patientVestDeviceEvents.isEmpty()){
		// this is required to let reader to know there is nothing to be read further
			isReadComplete = true;  
			return patientVestDeviceEvents; // spring batch reader to skip reading
		}else{
			patientUserId = patientVestDeviceEvents.get(0).getPatientUser().getId();
			patientId = patientVestDeviceEvents.get(0).getPatient().getId();
			Collections.sort(patientVestDeviceEvents);
			from = patientVestDeviceEvents.get(0).getTimestamp();
			to = patientVestDeviceEvents.get(patientVestDeviceEvents.size()-1).getTimestamp();
			serialNumber = patientVestDeviceEvents.get(0).getSerialNumber();
		}
		List<PatientVestDeviceData> existingEvents = vestDeviceDataRepository.findByPatientUserIdAndTimestampBetween(patientUserId, from, to);

		log.debug("Calculating the Delta ");
		List<PatientVestDeviceData> patientVestDeviceRecords = getDelta(existingEvents, patientVestDeviceEvents);
		
		// If no new events available , return empty list
		if(patientVestDeviceRecords.isEmpty()){
			log.debug("NO NEW EVENTS FOUND");
			return patientVestDeviceRecords;
		}
		
		log.debug("New Events found to be inserted ");
		PatientVestDeviceHistory latestInActiveDevice = patientVestDeviceRepository.findLatestInActiveDeviceByPatientId(patientId, false);
		List<TherapySession> therapySessions = PatientVestDeviceTherapyUtil
				.prepareTherapySessionFromDeviceData(patientVestDeviceRecords,latestInActiveDevice);

		if(therapySessions.isEmpty()){
			log.debug("Could not make session out of the events received, discarding to get delta");
			isReadComplete = true;  
			return new LinkedList<PatientVestDeviceData>();
		}
		
		//therapySessionService.saveOrUpdate(therapySessions);
		advanceAdherenceCalculationService.saveOrUpdate(therapySessions, false);
		awardsAndBadgesCalculatorService.vestLogMetrics(patientId);

		PatientInfo patient = patientVestDeviceEvents.get(0).getPatient();		
		patient.setLastVest(therapySessionService.getLatestEndTime(patientId));
		patientInfoRepository.saveAndFlush(patient);
		return patientVestDeviceRecords;
	}

	private synchronized void assignDefaultValuesToVestDeviceDataTemp(PatientVestDeviceRawLog deviceRawLog,
			List<PatientVestDeviceData> patientVestDeviceRecords, UserPatientAssoc userPatientAssoc) throws Exception{
		patientVestDeviceRecords.stream().forEach(deviceData -> {
			deviceData.setHubId(deviceRawLog.getHubId());
			deviceData.setSerialNumber(deviceRawLog.getDeviceSerialNumber());
			deviceData.setPatient(userPatientAssoc.getPatient());
			deviceData.setPatientUser(userPatientAssoc.getUser());
			deviceData.setBluetoothId(deviceRawLog.getDeviceAddress());
		});
	}

	@javax.transaction.Transactional
	private synchronized UserPatientAssoc createPatientUserIfNotExists(PatientVestDeviceRawLog deviceRawLog,
			String deviceSerialNumber) throws Exception{
		
		Optional<PatientDevicesAssoc> patientDevicesFromDB = patientDevicesAssocRepository.findOneBySerialNumber(deviceSerialNumber);
		PatientInfo patientInfo = null;

		List<PatientVestDeviceHistory> patientVestDeviceHistoryList = new LinkedList<>();
		patientVestDeviceHistoryList = patientVestDeviceRepository.findBySerialNumber(deviceSerialNumber);		
		
		if (patientDevicesFromDB.isPresent()) {
			
			if(!patientVestDeviceHistoryList.isEmpty()){
				for(PatientVestDeviceHistory patientVestDevicePatient : patientVestDeviceHistoryList){
					if(Objects.nonNull(patientVestDevicePatient) && patientVestDevicePatient.isPending() 
							&& deviceSerialNumber.equalsIgnoreCase(patientVestDevicePatient.getSerialNumber())){
						patientVestDevicePatient.setPending(false);
						patientVestDeviceRepository.save(patientVestDevicePatient);
					}
				}
			}
			
			return retrieveUserPatientAssoc(patientDevicesFromDB.get().getPatientId());
			
		} else {
			if(!patientVestDeviceHistoryList.isEmpty()){
				
				PatientVestDeviceHistory patientVestDevicePatient = patientVestDeviceHistoryList.get(0);
				
				Optional<PatientVestDeviceHistory> patientVestDeviceHistory = patientVestDeviceRepository.findOneByPatientIdAndPendingStatus(patientVestDevicePatient.getPatient().getId(), true);
				
				if (patientVestDeviceHistory.isPresent()){
					return retrieveUserPatientAssoc(patientVestDevicePatient.getPatient().getId());
				}
			}
			patientInfo = new PatientInfo();
			// Assigns the next hillromId for the patient
			String hillromId = patientInfoRepository.id();
			patientInfo.setId(hillromId);
			patientInfo.setHillromId(hillromId);
			patientInfo.setBluetoothId(deviceRawLog.getDeviceAddress());
			patientInfo.setHubId(deviceRawLog.getHubId());
			patientInfo.setSerialNumber(deviceRawLog.getDeviceSerialNumber());
			patientInfo.setDeviceAssocDate(new DateTime());
			String customerName = deviceRawLog.getCustomerName();
			setNameToPatient(patientInfo, customerName);
			patientInfo = patientInfoRepository.save(patientInfo);

			UserExtension userExtension = new UserExtension();
			userExtension.setHillromId(patientInfo.getHillromId());
			userExtension.setActivated(true);
			userExtension.setDeleted(false);
			userExtension.setFirstName(patientInfo.getFirstName());
			userExtension.setLastName(patientInfo.getLastName());
			userExtension.setMiddleName(patientInfo.getMiddleName());
			userExtension.getAuthorities().add(authorityRepository.findOne(PATIENT));
			userExtensionRepository.save(userExtension);

			UserPatientAssoc userPatientAssoc = new UserPatientAssoc(new UserPatientAssocPK(patientInfo, userExtension),
					AuthoritiesConstants.PATIENT, RelationshipLabelConstants.SELF);

			userPatientRepository.save(userPatientAssoc);

			userExtension.getUserPatientAssoc().add(userPatientAssoc);
			patientInfo.getUserPatientAssoc().add(userPatientAssoc);

			userExtensionRepository.save(userExtension);
			patientInfoRepository.save(patientInfo);
			LocalDate createdOrTransmittedDate = userExtension.getCreatedDate().toLocalDate();
			noEventService.createIfNotExists(
					new PatientNoEvent(createdOrTransmittedDate, createdOrTransmittedDate, patientInfo, userExtension));
			PatientCompliance compliance = new PatientCompliance();
			compliance.setPatient(patientInfo);
			compliance.setPatientUser(userExtension);
			compliance.setDate(userExtension.getCreatedDate().toLocalDate());
			compliance.setScore(DEFAULT_COMPLIANCE_SCORE);
			compliance.setLatestTherapyDate(createdOrTransmittedDate);
			complianceService.createOrUpdate(compliance);
			
			// Create Patient Device History
			PatientVestDeviceHistory deviceHistory = new PatientVestDeviceHistory(new PatientVestDevicePK(patientInfo, patientInfo.getSerialNumber()),
					patientInfo.getBluetoothId(), patientInfo.getHubId(), true, DateTime.now());
			patientVestDeviceRepository.save(deviceHistory);
			
			PatientDevicesAssoc deviceAssoc = new PatientDevicesAssoc(patientInfo.getId(), "VEST", true, deviceSerialNumber);
			patientDevicesAssocRepository.save(deviceAssoc);
			
			return userPatientAssoc;
		}
	}
	
	public UserPatientAssoc retrieveUserPatientAssoc(String patientId){
		PatientInfo patientInfo = patientInfoService.findOneById(patientId);
		List<UserPatientAssoc> associations = new ArrayList<UserPatientAssoc> (patientInfo.getUserPatientAssoc());
		
		List<UserPatientAssoc> userPatientAssociations = associations.stream()
				.filter(assoc -> RelationshipLabelConstants.SELF.equalsIgnoreCase(assoc.getRelationshipLabel()))
				.collect(Collectors.toList());
		return userPatientAssociations.get(0);
	}
	
	private void setNameToPatient(PatientInfo patientInfo, String customerName) {
		String names[] = customerName.split(" ");
		if (names.length == 2) {
			assignNameToPatient(patientInfo, names[1], names[0], null);
		}
		if (names.length == 3) {
			assignNameToPatient(patientInfo, names[2], names[1], names[0]);
		}
		if (names.length == 1) {
			assignNameToPatient(patientInfo, names[0], null, null);
		}
	}

	private void assignNameToPatient(PatientInfo patientInfo, String firstName, String lastName, String middleName) {
		patientInfo.setFirstName(firstName);
		patientInfo.setLastName(lastName);
		patientInfo.setMiddleName(middleName);
	}

	private List<PatientVestDeviceData> getDelta(List<PatientVestDeviceData> existingEvents, List<PatientVestDeviceData> newEvents){
		isReadComplete = true;
		if(Objects.isNull(existingEvents) || existingEvents.isEmpty())
			return newEvents;
		else{
			Iterator<PatientVestDeviceData> itr = newEvents.iterator();
			while(itr.hasNext()){
				PatientVestDeviceData newEvent = itr.next();
				for(PatientVestDeviceData existingData : existingEvents){
					if(newEvent.getTimestamp().equals(existingData.getTimestamp()) &&
					   newEvent.getBluetoothId().equals(existingData.getBluetoothId()) && 
					   newEvent.getEventId().equals(existingData.getEventId())){
						itr.remove();
						break;
					}
				}
			}
			Collections.sort(newEvents);
			return newEvents;
		}
	}
}
