package com.hillrom.vest.repository;

  import com.hillrom.vest.domain.DiagnosisTypeCodes;

  import java.util.List;

  import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

  public interface DiagnosisTypeCodeRepository extends JpaRepository<DiagnosisTypeCodes, Long> {

  	@Query(nativeQuery=true,
			value="select * from DIAGNOSIS_TYPE_CODE_VALUES "
            + "where (lower(type_code) like lower(?1) OR lower(type_code_value) like lower(?1))")
    public List<DiagnosisTypeCodes> findDiagnosisTypeCode(String searchString);

 	@Query("from DiagnosisTypeCodes where (lower(type_code) like lower(?1))")
    public DiagnosisTypeCodes findOneByTypeCode(String typeCode);

 }