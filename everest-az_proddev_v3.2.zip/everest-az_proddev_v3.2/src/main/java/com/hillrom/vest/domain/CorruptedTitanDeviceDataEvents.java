package com.hillrom.vest.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

@Entity
@Table(name="PATIENT_TITAN_DATA_CORRUPTED_EVENTS")
public class CorruptedTitanDeviceDataEvents implements Comparable<InvalidVestTherapySession>{
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="serial_number")
	private String serialNumber;

	@Column(name="date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime rawLogDate;
	
	@Column(name="device_raw_Logs_id")
	private Long deviceRawLogId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public DateTime getRawLogDate() {
		return rawLogDate;
	}

	public void setRawLogDate(DateTime localDate) {
		this.rawLogDate = localDate;
	}

	public Long getDeviceRawLogId() {
		return deviceRawLogId;
	}

	public void setDeviceRawLogId(Long deviceRawLogId) {
		this.deviceRawLogId = deviceRawLogId;
	}

	public CorruptedTitanDeviceDataEvents(Long id, String serialNumber, DateTime rawLogDate,
			Long deviceRawLogId) {
		super();
		this.id = id;
		this.serialNumber = serialNumber;
		this.rawLogDate = rawLogDate;
		this.deviceRawLogId = deviceRawLogId;
	}

	public CorruptedTitanDeviceDataEvents() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CorruptedTitanDeviceDataEvents [id=" + id + ", serialNumber=" + serialNumber + ", rawLogDate="
				+ rawLogDate + ", deviceRawLogId=" + deviceRawLogId + "]";
	}

	@Override
	public int compareTo(InvalidVestTherapySession o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
