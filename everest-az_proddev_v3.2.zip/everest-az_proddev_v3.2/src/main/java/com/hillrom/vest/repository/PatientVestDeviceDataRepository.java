package com.hillrom.vest.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hillrom.vest.domain.PatientVestDeviceData;
import com.hillrom.vest.domain.PatientVestDeviceDataPK;

@Repository
public interface PatientVestDeviceDataRepository extends
		JpaRepository<PatientVestDeviceData, PatientVestDeviceDataPK> {

	@Query("Select pvdd from PatientVestDeviceData pvdd where pvdd.patientVestDeviceDataPK.patient.id = :patientId order by patientVestDeviceDataPK.timestamp desc ")
	public Page<PatientVestDeviceData> findLatest(@Param("patientId")String patientId,Pageable pageable);
	
	@Query("Select pvdd from PatientVestDeviceData pvdd where patientUser.id = ?1 and patientVestDeviceDataPK.timestamp between ?2 and ?3")
	public List<PatientVestDeviceData> findByPatientUserIdAndTimestampBetween(Long id,Long from,Long to);
	
	public PatientVestDeviceData findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(Long id,String serialNumber);
	
	@Query("Select pvdd from PatientVestDeviceData pvdd where patientVestDeviceDataPK.patient.id = ?1 and patientVestDeviceDataPK.timestamp between ?2 and ?3")
	public List<PatientVestDeviceData> findByPatientIdAndTimestampBetween(String patientId,Long from,Long to);
	
	//public List<PatientVestDeviceData> findByPatientId(String id);
	
	//public PatientVestDeviceData findByPatientUserIdAndTimestamp(Long id,Long date);
	@Query(nativeQuery=true,value="SELECT * FROM PATIENT_VEST_DEVICE_DATA pvdd WHERE pvdd.patient_id = ?1 AND pvdd.timestamp >= ?2 AND pvdd.timestamp <= ?3 ORDER BY pvdd.timestamp ASC")
	public List<PatientVestDeviceData> findByPatientIdAndTimestampBetweenOrderByTimestampAsc(String patient_id,
			long from, long to);
}
