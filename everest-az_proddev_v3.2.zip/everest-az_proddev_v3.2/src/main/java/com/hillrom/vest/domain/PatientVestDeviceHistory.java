package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.util.DecimalNumberSerializer;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "PATIENT_VEST_DEVICE_HISTORY")
@EntityListeners(AuditingEntityListener.class)
@AssociationOverrides({
    @AssociationOverride(name = "patientVestDevicePK.patient",
        joinColumns = @JoinColumn(name = "PATIENT_ID", referencedColumnName="id")) })
public class PatientVestDeviceHistory implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private PatientVestDevicePK patientVestDevicePK;

	@Column(name = "bluetooth_id")
	private String bluetoothId;
	
	@Column(name="hub_id")
	private String hubId;
	
	@Column(name="is_active")
	private Boolean active = false;
	
	@Column(name="is_pending")
	private Boolean pending = false;
	
	@CreatedBy
    @NotNull
    @Column(name = "created_by", nullable = false, length = 50, updatable = false)
    private String createdBy;

    @CreatedDate
    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "created_date", nullable = false)
    private DateTime createdDate = DateTime.now();

    @LastModifiedBy
    @Column(name = "last_modified_by", length = 50)
    private String lastModifiedBy;

    @LastModifiedDate
    @org.springframework.data.annotation.Transient
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "last_modified_date")
    private DateTime lastModifiedDate;
    
    @Column(name="hmr")
	private Double hmr = 0d; // default value for HMR
    
    @Transient
   	private String deviceType;

    @NotNull
    @Column(name ="is_byod")
    private Boolean isByod = false;
    
    @NotNull
    @Column(name ="is_dnd")
    private Boolean isDnd = false;
    
    @Column(name = "dnd_device_identifier")
    private String dndIdentifier;
    
    @Column(name ="byod_state")
    private String byodState;
    
    @Column(name="byod_last_updated")
    private Long byodLastUpdated;
    
    @Column(name="byod_device_identifier")
    private String byodDeviceIdentifier;
    
    @Column(name="opt_out_requested_date")
    private Long optOutRequestedDate;
    
    @Column(name="opt_out_device_identifier")
    private String optOutDeviceIdentifier;
    
    @Column(name="opt_out_agreed_date")
    private Long optOutAgreedDate;
    
    @Column(name="opt_out_reason")
    private String optOutReason;

    @Column(name="opt_out_feedback")
    private String optOutFeedback;
    
    @Column(name = "name")
	private String name;
    
    @Column(name = "is_manual")
	private Boolean isManual = false;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getIsManual() {
		return isManual;
	}

	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}

	public PatientVestDeviceHistory() {
		super();
	}

	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK,
			String bluetoothId, String hubId, Boolean active) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.bluetoothId = bluetoothId;
		this.hubId = hubId;
		this.active = active;
		this.deviceType = "VEST";
	}

	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK,
			String bluetoothId, String hubId, Boolean active, Boolean byod) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.bluetoothId = bluetoothId;
		this.hubId = hubId;
		this.active = active;
		this.deviceType = "VEST";
		this.isByod = byod;
	}

	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK,
			String bluetoothId, String hubId, Boolean active, DateTime ModifiedDate) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.bluetoothId = bluetoothId;
		this.hubId = hubId;
		this.active = active;
		this.lastModifiedDate = ModifiedDate;
		this.deviceType = "VEST";
	}

	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK,DateTime ModifiedDate) {
		this.patientVestDevicePK = patientVestDevicePK;
		this.lastModifiedDate = ModifiedDate;
		this.deviceType = "VEST";
	}
	
	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK, Boolean active, DateTime ModifiedDate) {
		this.patientVestDevicePK = patientVestDevicePK;
		this.active = active;
		this.lastModifiedDate = ModifiedDate;
		this.deviceType = "VEST";
	}

	public PatientVestDeviceHistory(PatientVestDevicePK patientVestDevicePK, String bluetoothId, String hubId,
			Boolean active, String createdBy, DateTime ModifiedDate) {
		super();
		this.patientVestDevicePK = patientVestDevicePK;
		this.bluetoothId = bluetoothId;
		this.hubId = hubId;
		this.active = active;
		this.createdBy = createdBy;
		this.hmr = hmr;
		this.deviceType = "VEST";
	}
	public PatientVestDevicePK getPatientVestDevicePK() {
		return patientVestDevicePK;
	}

	public void setPatientVestDevicePK(PatientVestDevicePK patientVestDevicePK) {
		this.patientVestDevicePK = patientVestDevicePK;
	}

	public PatientInfo getPatient() {
		return getPatientVestDevicePK().getPatient();
	}

	public void setPatient(PatientInfo patient) {
		getPatientVestDevicePK().setPatient(patient);
	}

	public String getSerialNumber() {
		return getPatientVestDevicePK().getSerialNumber();
	}

	public void setSerialNumber(String serialNumber) {
		getPatientVestDevicePK().setSerialNumber(serialNumber);
	}
	
	public String getBluetoothId() {
		return bluetoothId;
	}

	public void setBluetoothId(String bluetoothId) {
		this.bluetoothId = bluetoothId;
	}

	public String getHubId() {
		return hubId;
	}

	public void setHubId(String hubId) {
		this.hubId = hubId;
	}

	public Boolean isActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}
	
	public Boolean isPending() {
		return pending;
	}

	public void setPending(Boolean pending) {
		this.pending = pending;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public DateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(DateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	@Transient
	public String getDeviceType() {
		return deviceType;
	}

    @Transient
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	
	@JsonIgnore
	public Double getHmr() {
		return hmr;
	}

	public void setHmr(Double hmr) {
		this.hmr = hmr;
	}

	// This is used for sending hmr in Minutes
	@JsonProperty(value="hmr")
	@JsonSerialize(using=DecimalNumberSerializer.class)
	public Double getHmrInMinutes(){
		return hmr/(60);
	}
	
	
	public Boolean getIsByod() {
		return isByod;
	}

	public void setIsByod(Boolean isByod) {
		this.isByod = isByod;
	}

	public Boolean getIsDnd() {
		return isDnd;
	}

	public void setIsDnd(Boolean isDnd) {
		this.isDnd = isDnd;
	}

	public String getDndIdentifier() {
		return dndIdentifier;
	}

	public void setDndIdentifier(String dndIdentifier) {
		this.dndIdentifier = dndIdentifier;
	}

	public String getByodState() {
		return byodState;
	}

	public void setByodState(String byodState) {
		this.byodState = byodState;
	}

	public Long getByodLastUpdated() {
		return byodLastUpdated;
	}

	public void setByodLastUpdated(Long byodLastUpdated) {
		this.byodLastUpdated = byodLastUpdated;
	}

	public String getByodDeviceIdentifier() {
		return byodDeviceIdentifier;
	}

	public void setByodDeviceIdentifier(String byodDeviceIdentifier) {
		this.byodDeviceIdentifier = byodDeviceIdentifier;
	}

	public Long getOptOutRequestedDate() {
		return optOutRequestedDate;
	}

	public void setOptOutRequestedDate(Long optOutRequestedDate) {
		this.optOutRequestedDate = optOutRequestedDate;
	}

	public String getOptOutDeviceIdentifier() {
		return optOutDeviceIdentifier;
	}

	public void setOptOutDeviceIdentifier(String optOutDeviceIdentifier) {
		this.optOutDeviceIdentifier = optOutDeviceIdentifier;
	}

	public Long getOptOutAgreedDate() {
		return optOutAgreedDate;
	}

	public void setOptOutAgreedDate(Long optOutAgreedDate) {
		this.optOutAgreedDate = optOutAgreedDate;
	}

	public String getOptOutReason() {
		return optOutReason;
	}

	public void setOptOutReason(String optOutReason) {
		this.optOutReason = optOutReason;
	}

	public String getOptOutFeedback() {
		return optOutFeedback;
	}

	public void setOptOutFeedback(String optOutFeedback) {
		this.optOutFeedback = optOutFeedback;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((active == null) ? 0 : active.hashCode());
		result = prime * result
				+ ((bluetoothId == null) ? 0 : bluetoothId.hashCode());
		result = prime * result + ((hubId == null) ? 0 : hubId.hashCode());
		result = prime
				* result
				+ ((patientVestDevicePK == null) ? 0 : patientVestDevicePK
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientVestDeviceHistory other = (PatientVestDeviceHistory) obj;
		if (active == null) {
			if (other.active != null)
				return false;
		} else if (!active.equals(other.active))
			return false;
		if (bluetoothId == null) {
			if (other.bluetoothId != null)
				return false;
		} else if (!bluetoothId.equals(other.bluetoothId))
			return false;
		if (hubId == null) {
			if (other.hubId != null)
				return false;
		} else if (!hubId.equals(other.hubId))
			return false;
		if (patientVestDevicePK == null) {
			if (other.patientVestDevicePK != null)
				return false;
		} else if (!patientVestDevicePK.equals(other.patientVestDevicePK))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PatientVestDeviceHistory [patientVestDevicePK="
				+ patientVestDevicePK + ", bluetoothId=" + bluetoothId
				+ ", hubId=" + hubId + ", active=" + active + "]";
	}
}
