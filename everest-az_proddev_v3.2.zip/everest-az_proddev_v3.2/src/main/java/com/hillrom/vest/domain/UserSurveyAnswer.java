package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.joda.time.DateTime;

import com.hillrom.vest.config.Constants;
import com.hillrom.vest.web.rest.dto.FiveDaySurveyReportVO;
import com.hillrom.vest.web.rest.dto.SurveyAnswerResultSetVO;
import com.hillrom.vest.web.rest.dto.ThirtyDaySurveyReportVO;

@Entity
@Audited
@Table(name = "USER_SURVEY_ANSWERS")
@NamedNativeQueries({
		@NamedNativeQuery(name = "fiveDaySurveyReport", query = "select ques.id as id, ques.question_text as questionText, ROUND (( "
				+ "LENGTH(group_concat(answer_value_1)) "
				+ "- LENGTH( REPLACE ( group_concat(answer_value_1), '"+Constants.YES+"', '') ) " + ") / LENGTH('"+Constants.YES+"')) AS yesCount,"
				+ "ROUND((LENGTH(group_concat(answer_value_1)) "
				+ "- LENGTH( REPLACE ( group_concat(answer_value_1), '"+Constants.NO+"', '')) "
				+ ") / LENGTH('"+Constants.NO+"')) AS noCount , compl_date as compDate "
				+ "from QUESTIONS ques left outer join USER_SURVEY_ANSWERS usa "
				+ "on ques.id = usa.question_id and usa.survey_id = 1 " + "and DATE(usa.compl_date) between (:from) and (:to) "
				+ "where ques.id in (:questionIds)  "
				+ "group by ques.id ", resultSetMapping = "fiveDaySurveyReportMapping"),

		@NamedNativeQuery(name = "thirtyDaySurveyReport", query = "select ques.id as id, ques.question_text as questionText,"
				+ "ROUND (( LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.STRONGLY_DISAGREE+"', '') ) ) / LENGTH('"+Constants.STRONGLY_DISAGREE+"')) AS stronglyDisagreeCount, "
				+ "ROUND((LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.SOMEWHAT_DISAGREE+"', '')) ) / LENGTH('"+Constants.SOMEWHAT_DISAGREE+"')) AS somewhatDisagreeCount , "
				+ "ROUND((LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.NEUTRAL+"', '')) ) / LENGTH('"+Constants.NEUTRAL+"')) AS neutralCount , "
				+ "ROUND((LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.SOMEWHAT_AGREE+"', '')) ) / LENGTH('"+Constants.SOMEWHAT_AGREE+"')) AS somewhatAgreeCount,"
				+ "ROUND (( LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.STRONGLY_AGREE+"', '') ) ) / LENGTH('"+Constants.STRONGLY_AGREE+"')) AS stronglyAgreeCount,  "
				+ "ROUND (( LENGTH(group_concat(answer_value_1)) - LENGTH( REPLACE ( group_concat(answer_value_1),  "
				+ "'"+Constants.UNABLE_TO_ASSESS+"', '') ) ) / LENGTH('"+Constants.UNABLE_TO_ASSESS+"')) AS unableToAccessCount, "
				+ "compl_date as compDate from QUESTIONS ques left outer join USER_SURVEY_ANSWERS usa "
				+ "on ques.id = usa.question_id and usa.survey_id = 2 and DATE(usa.compl_date) between (:from) and (:to) "
				+ "where ques.id in (:questionIds)  "
				+ "group by ques.id  ", resultSetMapping = "thirtyDaySurveyReportMapping"),
		@NamedNativeQuery(name = "nintyDaySurveyReport", query = "select usa.user_id as userId, usa.question_id as questionId, "
				+ "ques.question_text as questionText, usa.answer_value_1 as answerValue1, usa.answer_value_2 as answerValue2 "
				+ "from USER_SURVEY_ANSWERS usa left outer join  QUESTIONS ques on ques.id = usa.question_id "
				+ "where usa.survey_id = 3 AND usa.question_id in (41,42,43,49,50,51) and  DATE(usa.compl_date) between ? and ? "
				+ "group by usa.user_id,usa.question_id", resultSetMapping = "surveyAnswerReportMapping"),
		@NamedNativeQuery(name = "fiveDaySurveyReportView", query = "select usa.user_id as userId, usa.question_id as questionId, "
				+ "ques.question_text as questionText, usa.answer_value_1 as answerValue1, usa.answer_value_2 as answerValue2  "
				+ "from USER_SURVEY_ANSWERS usa left outer join  QUESTIONS ques on ques.id = usa.question_id "
				+ "where usa.survey_id = 1 AND usa.question_id in (1,4,5,?) and DATE(usa.compl_date) between ? and ? "
				+ "group by usa.user_id,usa.question_id", resultSetMapping = "surveyAnswerReportMapping") })
@SqlResultSetMappings({
		@SqlResultSetMapping(name = "fiveDaySurveyReportMapping", classes = @ConstructorResult(targetClass = FiveDaySurveyReportVO.class, columns = {
				@ColumnResult(name = "id", type = Long.class), @ColumnResult(name = "questionText"),
				@ColumnResult(name = "yesCount", type = Integer.class),
				@ColumnResult(name = "noCount", type = Integer.class) }) ),
		@SqlResultSetMapping(name = "thirtyDaySurveyReportMapping", classes = @ConstructorResult(targetClass = ThirtyDaySurveyReportVO.class, columns = {
				@ColumnResult(name = "id", type = Long.class), @ColumnResult(name = "questionText"),
				@ColumnResult(name = "stronglyDisagreeCount", type = Integer.class),
				@ColumnResult(name = "somewhatDisagreeCount", type = Integer.class),
				@ColumnResult(name = "neutralCount", type = Integer.class),
				@ColumnResult(name = "somewhatAgreeCount", type = Integer.class),
				@ColumnResult(name = "stronglyAgreeCount", type = Integer.class),
				@ColumnResult(name = "unableToAccessCount", type = Integer.class), }) ),
		@SqlResultSetMapping(name = "surveyAnswerReportMapping", classes = @ConstructorResult(targetClass = SurveyAnswerResultSetVO.class, columns = {
				@ColumnResult(name = "userId", type = Long.class),
				@ColumnResult(name = "questionId", type = Long.class),
				@ColumnResult(name = "questionText", type = String.class),
				@ColumnResult(name = "answerValue1", type = String.class),
				@ColumnResult(name = "answerValue2", type = String.class)}))
		})

public class UserSurveyAnswer implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "survey_id")
	private Survey survey;

	@ManyToOne
	@JoinColumn(name = "question_id")
	private SurveyQuestion surveyQuestion;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@Column(name = "answer_value_1")
	private String answerValue1;

	@Column(name = "answer_value_2")
	private String answerValue2;

	@Column(name = "answer_value_3")
	private String answerValue3;

	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@Column(name = "compl_date")
	private DateTime completionDate = DateTime.now();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Survey getSurvey() {
		return survey;
	}

	public void setSurvey(Survey survey) {
		this.survey = survey;
	}

	public SurveyQuestion getSurveyQuestion() {
		return surveyQuestion;
	}

	public void setSurveyQuestion(SurveyQuestion surveyQuestion) {
		this.surveyQuestion = surveyQuestion;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAnswerValue1() {
		return answerValue1;
	}

	public void setAnswerValue1(String answerValue1) {
		this.answerValue1 = answerValue1;
	}

	public String getAnswerValue2() {
		return answerValue2;
	}

	public void setAnswerValue2(String answerValue2) {
		this.answerValue2 = answerValue2;
	}

	public String getAnswerValue3() {
		return answerValue3;
	}

	public void setAnswerValue3(String answerValue3) {
		this.answerValue3 = answerValue3;
	}

	public DateTime getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(DateTime completionDate) {
		this.completionDate = completionDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((survey == null) ? 0 : survey.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserSurveyAnswer other = (UserSurveyAnswer) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (survey == null) {
			if (other.survey != null)
				return false;
		} else if (!survey.equals(other.survey))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserSurveyAnswer [id=" + id + ", survey=" + survey + ", surveyQuestion=" + surveyQuestion + ", user="
				+ user + ", answerValue1=" + answerValue1 + ", answerValue2=" + answerValue2 + ", answerValue3="
				+ answerValue3 + ", completionDate=" + completionDate + "]";
	}
}
