package com.hillrom.vest.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Embeddable
public class PatientVestDeviceDataTitanPK implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "timestamp")
	private Long timestamp;

	@Column(name="event_code")
	private String eventCode;

	@Column(name = "bluetooth_id")
	private String bluetoothId;
	
	@JsonIgnore
	@ManyToOne(optional=false,targetEntity=PatientInfo.class,cascade={CascadeType.ALL})
	@JoinColumn(name="patient_id",referencedColumnName="id")
	private PatientInfo patient;

  
	/**
	 * @return the timestamp
	 */
	public Long getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	/**
	 * @return the eventCode
	 */
	public String getEventCode() {
		return eventCode;
	}
	/**
	 * @param eventCode the eventCode to set
	 */
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bluetoothId == null) ? 0 : bluetoothId.hashCode());
		result = prime * result + ((eventCode == null) ? 0 : eventCode.hashCode());
		result = prime * result + ((patient == null) ? 0 : patient.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientVestDeviceDataTitanPK other = (PatientVestDeviceDataTitanPK) obj;
		if (bluetoothId == null) {
			if (other.bluetoothId != null)
				return false;
		} else if (!bluetoothId.equals(other.bluetoothId))
			return false;
		if (eventCode == null) {
			if (other.eventCode != null)
				return false;
		} else if (!eventCode.equals(other.eventCode))
			return false;
		if (patient == null) {
			if (other.patient != null)
				return false;
		} else if (!patient.equals(other.patient))
			return false;
		if (timestamp == null) {
			if (other.timestamp != null)
				return false;
		} else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PatientVestDeviceDataTitanPK [timestamp=" + timestamp + ", eventCode=" + eventCode + ", bluetoothId="
				+ bluetoothId + ", patient=" + patient + "]";
	}
	
	
    /**
	 * @return the bluetoothId
	 */
	public String getBluetoothId() {
		return bluetoothId;
	}
	/**
	 * @param bluetoothId the bluetoothId to set
	 */
	public void setBluetoothId(String bluetoothId) {
		this.bluetoothId = bluetoothId;
	}
	/**
	 * @return the patient
	 */
	public PatientInfo getPatient() {
		return patient;
	}
	/**
	 * @param patient the patient to set
	 */
	public void setPatient(PatientInfo patient) {
		this.patient = patient;
	}

	public PatientVestDeviceDataTitanPK() {

		super();
	}
	public PatientVestDeviceDataTitanPK(Long timestamp, String eventCode, String bluetoothId, PatientInfo patient) {
		super();
		this.timestamp = timestamp;
		this.eventCode = eventCode;
		this.bluetoothId = bluetoothId;
		this.patient = patient;
	}
	
}
