package com.hillrom.portal.patientview.constant;

public class HillromConstants {

	public static final String UTILITY_CLASS = "utility class, cannot be instantiated";

	private HillromConstants() {

		throw new IllegalStateException(UTILITY_CLASS);
	}

	public static final String VEST = "VEST";
	public static final String MONARCH = "MONARCH";
	public static final String TITAN = "TITAN";
	public static final String ACTIVE = "Active";
	public static final String IN_ACTIVE = "Inactive";
	public static final String STATUS = "Status :";
	public static final String DOB = "DOB :";
	public static final String HILLROM_ID = "Hillrom ID :";
	public static final String DIAGNOSIS_CODE = "Diagnosis Codes :";
	public static final String CLINIC_ID = "Clinic ID :";
	public static final String CLINIC = "Clinic :";
	public static final String PROVIDER = "Provider :";
	public static final String DATE = "DATE";
	public static final String TIME = "TIME";
	public static final String SESSION_DURATION = "SESSION DURATION";
	public static final String EVENT = "EVENT";
	public static final String FREQUENCY = "FREQUENCY";
	public static final String PRESSURE = "PRESSURE";
	public static final String DEVICE = "DEVICE";
	public static final String DATE_FORMAT = "MMM dd";
	public static final String TIME_FORMAT = "hh:mm a";
	public static final String SORT_ORDER = "DESC";
	public static final String PATH_FOR_VEST = "/public/mobile-images/visivestBlackAndWhite.png";
	public static final String PATH_FOR_MONARCH = "/public/mobile-images/monarchBlackAndWhite.png";
	public static final String PATH_FOR_TITAN = "/public/mobile-images/titanBlackAndWhite.png";
	public static final String PATH_FOR_MANUAL_VEST = "/public/mobile-images/vest_nonconnected_BlackAndWhite.png";
	public static final String PATH_FOR_FLAG = "/public/mobile-images/flag.png";
	public static final String PATH_FOR_HILLROM = "/public/mobile-images/hillRom.png";

}
