package com.hillrom.portal.patientview.service;

import static com.hillrom.vest.config.Constants.MONARCH;
import static com.hillrom.vest.config.Constants.VEST;
import static com.hillrom.vest.config.Constants.TITAN;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang.mutable.MutableBoolean;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.portal.patientinformation.service.PatientSessionCompletedService;
import com.hillrom.portal.patientview.dto.DaySessionsVO;
import com.hillrom.portal.patientview.dto.DeviceEventsVO;
import com.hillrom.portal.patientview.dto.DeviceSessionsVO;
import com.hillrom.portal.patientview.dto.PatientSessionStatsVO;
import com.hillrom.portal.patientview.dto.TherapySessionByDayVO;
import com.hillrom.titan.repository.PatientComplianceTitanRepository;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.repository.PatientComplianceRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.security.AuthoritiesConstants;

@Service
@Transactional
public class PatientSessionStatsService {

	private static final Logger log = LoggerFactory.getLogger(PatientSessionStatsService.class);

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject
	private PatientSessionCompletedService patientSessionCompletedRepository;
	
	@Inject
	private PatientComplianceMonarchRepository patientComplianceMonarchRepository;
	
	@Inject
	private PatientComplianceTitanRepository patientComplianceTitanRepository;

	@Inject
	private PatientComplianceRepository patientComplianceRepository;
  
	@Inject
	private EntityManager entityManager;
	
	@Inject
	private UserPatientRepository userPatientRepository;

	public PatientSessionStatsVO getPatientWiseSessionStats(Long userId, LocalDate from, LocalDate to,String timeZone) {
		PatientSessionStatsVO pssVO = new PatientSessionStatsVO();
		List<UserPatientAssoc> userPatientAssocList = userPatientRepository.findByUserIdAndUserRole(userId, AuthoritiesConstants.PATIENT);
		
		if(userPatientAssocList.isEmpty() || userPatientAssocList.size()>1) {
			return null;
		}
		
		String patient_id = userPatientAssocList.get(0).getPatient().getId();
		
		try {
			patientSessionCompletedRepository.getCompletedMetrics(userId, patient_id, from, to, pssVO,timeZone);
			pssVO.setMyScore(getCurrentComplianceScore(userId, patient_id, from, to));
			pssVO.setMyScoreDiff(getScoreDiff(userId, patient_id, from, to));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return pssVO;
	}

	private int getScoreDiff(Long userId, String patient_id, LocalDate from, LocalDate to) {
		int scoreDiff = 0;
		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient_id);
		if (activeDevices.size() == 1 && Objects.nonNull(activeDevices.get(0)) && activeDevices.get(0).getDeviceType().equalsIgnoreCase("VEST")) {	
			PatientCompliance currentCompliance = patientComplianceRepository.returnLatestDayScore(userId);
			PatientCompliance prevCompliance = patientComplianceRepository.returnPrevDayScore(currentCompliance.getDate().toString(),userId);
			if(Objects.nonNull(prevCompliance)) {
				scoreDiff = currentCompliance.getScore() - prevCompliance.getScore();
			}
		} else if (activeDevices.size() == 1  && Objects.nonNull(activeDevices.get(0)) && activeDevices.get(0).getDeviceType().equalsIgnoreCase("MONARCH")) {
			PatientComplianceMonarch currentCompliance = patientComplianceMonarchRepository.returnLatestDayScore(userId);
			PatientComplianceMonarch prevCompliance = patientComplianceMonarchRepository.returnPrevDayScore(currentCompliance.getDate().toString(),userId);
			if(Objects.nonNull(prevCompliance)) {
				scoreDiff = currentCompliance.getScore() - prevCompliance.getScore();
			}
		}else {
			PatientComplianceTitan currentCompliance = patientComplianceTitanRepository.returnLatestDayScore(userId);
			PatientComplianceTitan prevCompliance = patientComplianceTitanRepository.returnPrevDayScore(currentCompliance.getDate().toString(),userId);
			if(Objects.nonNull(prevCompliance)) {
				scoreDiff = currentCompliance.getScore() - prevCompliance.getScore();
			}
		}
		return scoreDiff;
	}

	private int getCurrentComplianceScore(Long userId, String patient_id, LocalDate from, LocalDate to) {
		int currentComplianceScore = 0;
		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient_id);
		if(activeDevices.size() == 1 && Objects.nonNull(activeDevices.get(0))  && activeDevices.get(0).getDeviceType().equalsIgnoreCase("VEST")) {
			PatientCompliance currentCompliance = patientComplianceRepository.returnLatestDayScore(userId);
			currentComplianceScore = currentCompliance .getScore();
		} else if(activeDevices.size() == 1 && Objects.nonNull(activeDevices.get(0))  && activeDevices.get(0).getDeviceType().equalsIgnoreCase("MONARCH")) {
			PatientComplianceMonarch currentCompliance = patientComplianceMonarchRepository.returnLatestDayScore(userId);
			currentComplianceScore = currentCompliance .getScore();	
		}else {
			PatientComplianceTitan currentCompliance = patientComplianceTitanRepository.returnLatestDayScore(userId);
			currentComplianceScore = currentCompliance .getScore();	
		}
		return currentComplianceScore;
	}
	
	public Page<DaySessionsVO> getSessionWiseDeviceDetails(Long userId,Long startDate,Long endDate,String timeZone ,Pageable pageable,String sortOrder) throws Exception {
		try {
			Map<Long, DaySessionsVO> daySessionMap = new LinkedHashMap<Long, DaySessionsVO>();
			String finalQuery = "select \n" + 
					"    patient_id, \n" + 
					"    type, \n" + 
					"	 unix_timestamp(date)*1000 as date, \n" +
					"    unix_timestamp(start_time)*1000 as start_time, \n" + 
					"    unix_timestamp(end_time)*1000 as end_time, \n" + 
					"    duration_in_minutes \n" + 
					"from\n" + 
					"(\n" + 
					"	(select \n" + 
					"		date, \n" + 
					"        patient_id, \n" + 
					"        '$$MONARCH$$' as type, \n" + 
					"        start_time, \n" + 
					"        end_time, \n" + 
					"        duration_in_minutes \n" + 
					"	from \n" + 
					"		PATIENT_VEST_THERAPY_DATA_MONARCH \n" + 
					"    where \n" + 
					"		patient_id='$$PATIENT_ID$$' \n" + 
					"        AND start_time >= from_unixtime($$START_TIME$$/1000) \n" + 
					"        AND end_time <= from_unixtime($$END_TIME$$/1000)\n" +
					"		 AND duration_in_minutes > 0 )"+
					"UNION\n" + 
					"	(select \n" + 
					"		date, \n" + 
					"        patient_id, \n" + 
					"        '$$VEST$$' as type, \n" + 
					"        start_time, \n" + 
					"        end_time, \n" + 
					"        duration_in_minutes \n" + 
					"	from \n" + 
					"		PATIENT_VEST_THERAPY_DATA \n" + 
					"	where \n" + 
					"		patient_id='$$PATIENT_ID$$' \n" + 
					"        and start_time >= from_unixtime($$START_TIME$$/1000) \n" + 
					"        AND end_time <= from_unixtime($$END_TIME$$/1000)\n" +
					"		 AND duration_in_minutes > 0 )"+
					"UNION\n" + 
					"	(select \n" + 
					"		date, \n" + 
					"        patient_id, \n" + 
					"        '$$TITAN$$' as type, \n" + 
					"        start_time, \n" + 
					"        end_time, \n" + 
					"        duration_in_minutes \n" + 
					"	from \n" + 
					"		PATIENT_VEST_THERAPY_DATA_TITAN \n" + 
					"	where \n" + 
					"		patient_id='$$PATIENT_ID$$' \n" + 
					"        and start_time >= from_unixtime($$START_TIME$$/1000) \n" + 
					"        AND end_time <= from_unixtime($$END_TIME$$/1000)\n" +
					"		 AND duration_in_minutes > 0 )"+
					"	)x order by start_time $$SORT_ORDER$$";
			
			List<UserPatientAssoc> userPatientAssocList = userPatientRepository.findByUserIdAndUserRole(userId, AuthoritiesConstants.PATIENT);
			
			if(userPatientAssocList.isEmpty() || userPatientAssocList.size()>1) {
				return null;
			}

			String patient_id = userPatientAssocList.get(0).getPatient().getId();

			finalQuery = finalQuery.replace("$$MONARCH$$", MONARCH);
			finalQuery = finalQuery.replace("$$VEST$$", VEST);
			finalQuery = finalQuery.replace("$$TITAN$$", TITAN);
			finalQuery = finalQuery.replace("$$PATIENT_ID$$", patient_id);
			finalQuery = finalQuery.replace("$$START_TIME$$", startDate.toString());
			finalQuery = finalQuery.replace("$$END_TIME$$", endDate.toString());
			
			if (Objects.isNull(sortOrder)) {
				sortOrder = "ASC";
			}

			finalQuery = finalQuery.replace("$$SORT_ORDER$$", sortOrder);

			String countQuery= "select count(*) from (" + finalQuery + ") countResult;";
			log.debug(countQuery);
			Query count = entityManager.createNativeQuery(countQuery);
			BigInteger resCount = (BigInteger)count.getSingleResult();
			log.debug(resCount.toString());
			
			
			finalQuery += " LIMIT $PAGE_SIZE$ OFFSET $OFFSET$;";
			finalQuery = finalQuery.replace("$PAGE_SIZE$", Integer.toString(pageable.getPageSize()));
			int offset = (pageable.getPageSize()*(pageable.getPageNumber()));
			finalQuery = finalQuery.replace("$OFFSET$", Integer.toString(offset));
			
			Query query = entityManager.createNativeQuery(finalQuery, "TheapySesionByDayMapping");
			@SuppressWarnings("unchecked")
			List<TherapySessionByDayVO> resultsMapping = (List<TherapySessionByDayVO>) query.getResultList();
						
			MutableBoolean isEventValid =new MutableBoolean(false);
			MutableBoolean isFrequency =new MutableBoolean(false);
			MutableBoolean isPressure =new MutableBoolean(false);
			
			if(Objects.nonNull(resultsMapping) && !resultsMapping.isEmpty()){
				for (TherapySessionByDayVO therapySession : resultsMapping) {
					DaySessionsVO daySession = daySessionMap.get(therapySession.getDate());
					
					if(Objects.isNull(daySession)) {
						daySession = new DaySessionsVO();
						daySession.setDate(new LocalDate(therapySession.getDate()).toString("MMM dd"));
					}
					
					List<DeviceSessionsVO> deviceSessionList = daySession.getSessions();
					
					if(Objects.isNull(deviceSessionList)) {
						deviceSessionList = new ArrayList<DeviceSessionsVO>();
					}
					
					DeviceSessionsVO deviceSession = new DeviceSessionsVO();
					
					if (therapySession.getType().equals(MONARCH))
					{
						deviceSession.setDevice("MONARCH");
						deviceSession.setManual(false);
						deviceSession.setDuration(therapySession.getDuration_in_minutes());
		
						String DEVICE_DATA_QUERY="select  		\r\n" + 
								"		convert_tz(from_unixtime(timestamp/1000), '+00:00', ':TIMEZONE') as timestamp,\r\n" + 
								"        event_code,\r\n" + 
								"        frequency,\r\n" + 
								"        intensity,\r\n" + 
								"        duration\r\n" + 
								"	from\r\n" + 
								"		PATIENT_VEST_DEVICE_DATA_MONARCH where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";
						
						String deviceQuery = DEVICE_DATA_QUERY;
						deviceQuery = deviceQuery.replace(":PATIENT_ID", patient_id);
						deviceQuery = deviceQuery.replace(":START_TIME", therapySession.getStart_time().toString());
						deviceQuery = deviceQuery.replace(":END_TIME", therapySession.getEnd_time().toString());
						deviceQuery = deviceQuery.replace(":TIMEZONE", timeZone);
						log.debug(deviceQuery);
						query = entityManager.createNativeQuery(deviceQuery);
						@SuppressWarnings("unchecked")
						List<Object[]> results = query.getResultList();

						if(results.size() > 0) {
							List<DeviceEventsVO> deviceEventsList = new ArrayList<>();
							for(Object[] record : results){
								String eventCodeStr = getEventCodeStringMonarch(record[1].toString(),isEventValid, isFrequency, isPressure);
								if((Boolean)isEventValid.getValue()) {
									DeviceEventsVO deviceEvents = new DeviceEventsVO();
									deviceEvents.setName(eventCodeStr);
									deviceEvents.setTime(new DateTime(record[0]).toString("hh:mm a"));
									deviceEvents.setDuration(record[4].toString());
									if((Boolean)isFrequency.getValue()) {
										deviceEvents.setFrequency(record[2].toString());
									}else {
										deviceEvents.setFrequency(null);
									}
									if((Boolean)isPressure.getValue()) {
										deviceEvents.setPressure(record[3].toString());
									}else {
										deviceEvents.setPressure(null);
									}
									deviceEventsList.add(deviceEvents);
							 	}
							}
							deviceSession.setEvents(deviceEventsList);
						}
					}else if (therapySession.getType().equals(VEST)) {
						
						List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findAllByPatientIdAndDeviceType(therapySession.getPatient_id(), therapySession.getType());
						
						deviceSession.setDevice("VEST");
						deviceSession.setManual((Objects.nonNull(activeDevices) && activeDevices.size() > 0) ? (Objects.nonNull(activeDevices.get(0).getIsManual()) ? activeDevices.get(0).getIsManual() : null) : null);
						deviceSession.setDuration(therapySession.getDuration_in_minutes());

						String DEVICE_DATA_QUERY="select  		\r\n" + 
								"		convert_tz(from_unixtime(timestamp/1000), '-06:00', ':TIMEZONE') as timestamp,\r\n" + 
								"        event_id,\r\n" + 
								"        frequency,\r\n" + 
								"        pressure,\r\n" + 
								"        duration\r\n" + 
								"	from\r\n" + 
								"		PATIENT_VEST_DEVICE_DATA where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";

						String deviceQuery = DEVICE_DATA_QUERY;
						deviceQuery = deviceQuery.replace(":PATIENT_ID", patient_id);
						deviceQuery = deviceQuery.replace(":START_TIME", therapySession.getStart_time().toString());
						deviceQuery = deviceQuery.replace(":END_TIME", therapySession.getEnd_time().toString());
						deviceQuery = deviceQuery.replace(":TIMEZONE", timeZone);
						log.debug(deviceQuery);
						query = entityManager.createNativeQuery(deviceQuery);
						@SuppressWarnings("unchecked")
						List<Object[]> results = query.getResultList();

						
						if(results.size() > 0) {
							List<DeviceEventsVO> deviceEventsList = new ArrayList<>();
							for(Object[] record : results){
								String eventCodeStr = getEventCodeStringVest(record[1].toString(),isEventValid, isFrequency, isPressure);
								if((Boolean)isEventValid.getValue()) {
									DeviceEventsVO deviceEvents = new DeviceEventsVO();
									deviceEvents.setName(eventCodeStr);
									deviceEvents.setTime(new DateTime(record[0]).toString("hh:mm a"));
									deviceEvents.setDuration(record[4].toString());
									if((Boolean)isFrequency.getValue()) {
										deviceEvents.setFrequency(record[2].toString());
									}else {
										deviceEvents.setFrequency(null);
									}
									if((Boolean)isPressure.getValue()) {
										deviceEvents.setPressure(record[3].toString());
									}else {
										deviceEvents.setPressure(null);
									}
									
									deviceEventsList.add(deviceEvents);
								}
							}
							deviceSession.setEvents(deviceEventsList);
						}
					}else if (therapySession.getType().equals(TITAN))
					{
						deviceSession.setDevice("TITAN");
						deviceSession.setManual(false);
						deviceSession.setDuration(therapySession.getDuration_in_minutes());
	
						String DEVICE_DATA_QUERY="select  		\r\n" + 
								"		convert_tz(from_unixtime(timestamp/1000), '+00:00', ':TIMEZONE') as timestamp,\r\n" + 
								"        event_code,\r\n" + 
								"        frequency,\r\n" + 
								"        intensity,\r\n" + 
								"        duration\r\n" + 
								"	from\r\n" + 
								"		PATIENT_VEST_DEVICE_DATA_TITAN where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";
	
						String deviceQuery = DEVICE_DATA_QUERY;
						deviceQuery = deviceQuery.replace(":PATIENT_ID", patient_id);
						deviceQuery = deviceQuery.replace(":START_TIME", therapySession.getStart_time().toString());
						deviceQuery = deviceQuery.replace(":END_TIME", therapySession.getEnd_time().toString());
						deviceQuery = deviceQuery.replace(":TIMEZONE", timeZone);
						log.debug(deviceQuery);
						query = entityManager.createNativeQuery(deviceQuery);
						@SuppressWarnings("unchecked")
						List<Object[]> results = query.getResultList();
	
						if(results.size() > 0) {
							List<DeviceEventsVO> deviceEventsList = new ArrayList<>();
							for(Object[] record : results){
								String eventCodeStr = getEventCodeStringTitan(record[1].toString(),isEventValid, isFrequency, isPressure);
								if((Boolean)isEventValid.getValue()) {
									DeviceEventsVO deviceEvents = new DeviceEventsVO();
									deviceEvents.setName(eventCodeStr);
									deviceEvents.setTime(new DateTime(record[0]).toString("hh:mm a"));
									deviceEvents.setDuration(record[4].toString());
									if((Boolean)isFrequency.getValue()) {
										deviceEvents.setFrequency(record[2].toString());
									}else {
										deviceEvents.setFrequency(null);
									}
									if((Boolean)isPressure.getValue()) {
										deviceEvents.setPressure(record[3].toString());
									}else {
										deviceEvents.setPressure(null);
									}
									deviceEventsList.add(deviceEvents);
								}
							}
							deviceSession.setEvents(deviceEventsList);
						}
					}
					
					
					deviceSessionList.add(deviceSession);
					daySession.setSessions(deviceSessionList);
					daySessionMap.put(therapySession.getDate(), daySession);
				}
			}
			List<DaySessionsVO>sessionList = new ArrayList<DaySessionsVO>(daySessionMap.values());
			Page<DaySessionsVO> page  = new PageImpl<DaySessionsVO>(sessionList, pageable, resCount.longValue());
			return page;
		}catch(Exception e) {
			e.printStackTrace();
			log.debug(e.getMessage());
			log.debug(e.getStackTrace().toString());
			return null;
		}	
	}

	private String getEventCodeStringMonarch(String eventCodeStr, MutableBoolean isEventValid, MutableBoolean isFrequency,
			MutableBoolean isPressure) {
		String retVal = "Test";
		Integer eventCode = Integer.parseInt(eventCodeStr);
		Boolean isValid = true;
		Boolean isFreqValid = true;
		Boolean isIntValid = true;	

		switch(eventCode) {
			case 1:
				retVal = "Manual Therapy Started";
				break;
			case 2:
			case 19:
				retVal = "Manual Setting Change";
				break;
			case 3:
			case 15:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Completed";
				break;
			case 4:
			case 16:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Incomplete";
				break;
			case 5:
			case 17:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Manual Pause";
				break;
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
				retVal = "Program Pt " + (eventCode-7+1) +" Start";
				break;
			default:
				isValid = false;
				break;
		}

		isEventValid.setValue(isValid);
		isFrequency.setValue(isFreqValid);
		isPressure.setValue(isIntValid);

		return retVal;
	}

	private String getEventCodeStringTitan(String eventCodeStr, MutableBoolean isEventValid, MutableBoolean isFrequency,
			MutableBoolean isPressure) {
		String retVal = "Test";
		Integer eventCode = Integer.parseInt(eventCodeStr);
		Boolean isValid = true;
		Boolean isFreqValid = true;
		Boolean isIntValid = true;	

		switch(eventCode) {
			case 1:
				retVal = "Manual Therapy Started";
				break;
			case 2:
			case 19:
				retVal = "Manual Setting Change";
				break;
			case 3:
			case 15:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Completed";
				break;
			case 4:
			case 16:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Incomplete";
				break;
			case 5:
			case 17:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Manual Pause";
				break;
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
				retVal = "Program Pt " + (eventCode-7+1) +" Start";
				break;
			default:
				isValid = false;
				break;
		}

		isEventValid.setValue(isValid);
		isFrequency.setValue(isFreqValid);
		isPressure.setValue(isIntValid);

		return retVal;
	}

	private String getEventCodeStringVest(String eventCodeStr, MutableBoolean isEventValid, MutableBoolean isFrequency,
			MutableBoolean isPressure) {
		String retVal = null;
		
		eventCodeStr =eventCodeStr.substring(0,eventCodeStr.indexOf(":"));
		
		Integer eventCode = Integer.parseInt(eventCodeStr);
		Boolean isValid = true;
		Boolean isFreqValid = true;
		Boolean isIntValid = true;	

		switch(eventCode) {
			case 1:
				retVal = "Normal Therapy Started";
				break;
			case 2:
			case 15:
				retVal = "Manual Setting Change";
				break;
			case 3:
			case 16:
			case 25:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Completed";
				break;
			case 4:
			case 17:
			case 26:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Session Incomplete";
				break;
			case 5:
			case 28:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Manual Pause";
				break;
			case 18:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Cough Pause";
				break;				
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
				retVal = "Program Pt " + (eventCode-7+1) +" Start";
				break;
			case 20:
				retVal = "Ramp Therapy Started";
				break;
			case 21:
				retVal = "Ramp Therapy Paused";
				;
				break;
			case 22:
				retVal = "Ramp Therapy Reached";				
				break;
			case 23:
				retVal = "Ramp reached setting changed";
				break;
			case 24:
				isFreqValid = false;
				isIntValid = false;
				retVal = "Ramp reached paused";
				break;
			default:
				isValid = false;
				break;
		}
		
		isEventValid.setValue(isValid);
		isFrequency.setValue(isFreqValid);
		isPressure.setValue(isIntValid);

		return retVal;
	}
}
