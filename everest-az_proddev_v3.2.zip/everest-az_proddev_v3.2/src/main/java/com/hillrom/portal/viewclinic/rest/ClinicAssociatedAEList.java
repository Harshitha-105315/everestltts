package com.hillrom.portal.viewclinic.rest;

import static com.hillrom.vest.security.AuthoritiesConstants.ADMIN;
import static com.hillrom.vest.security.AuthoritiesConstants.ASSOCIATE_EXECUTIVE;
import static com.hillrom.vest.security.AuthoritiesConstants.CUSTOMER_SERVICES;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.portal.viewclinic.dto.AEListVO;
import com.hillrom.portal.viewclinic.service.ClinicAssociatedAEListService;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.service.ClinicService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.util.MessageConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Clinic Associated Roles fetch", description = "Fetch roles asscoated with clinic : Implemented", tags = { "Manage Clinic" })
public class ClinicAssociatedAEList {
	@Inject
	ClinicAssociatedAEListService clinicAssociatedAEListService;
	
	@Inject
	ClinicService clinicService; 
	
	@Inject
	UserService userService;
	@ApiOperation(httpMethod = "GET", value = "retrieve associated AE's", response = AEListVO.class, responseContainer = "List")
	@RequestMapping(value = "/clinics/{clinicId}/aes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES,ASSOCIATE_EXECUTIVE})
	public ResponseEntity<?> listAssociatedAE(@ApiParam(value = "clinicId", required = true, example = "12345") @PathVariable String clinicId){
		Set<AEListVO> aeList =  new HashSet<AEListVO>();
		if(Objects.nonNull(clinicId)) {
			aeList = clinicAssociatedAEListService.listAE(clinicId);
		}
		if(Objects.nonNull(aeList)) {
			aeList.forEach(x->x.setEmailID(userService.encryptData(x.getEmailID())));
		}
		return new ResponseEntity<>(aeList,HttpStatus.OK);
	}
	@ApiOperation(httpMethod = "POST", value = "Add associated AE's")
	@RequestMapping(value = "/clinics/{clinicId}/aes/{aeId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES,ASSOCIATE_EXECUTIVE})
	public ResponseEntity<?> addAssociatedAE(@ApiParam(value = "clinicId", required = true, example = "12345") @PathVariable String clinicId, 
			@ApiParam(value = "aeId", required = true, example = "12345") @PathVariable Long aeId){
		
		JSONObject jsonObject = new JSONObject();
		try {
			User user = clinicAssociatedAEListService.associateAssocExecutive(clinicId, aeId);
			if (Objects.isNull(user)) {
				jsonObject.put("message", MessageConstants.HR_202);
	        	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        } else {
	            jsonObject.put("message", MessageConstants.HR_202);
                return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
	        }
		} catch (HillromException e) {
			jsonObject.put("ERROR", e.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
		
	}
	@ApiOperation(httpMethod = "DELETE", value = "Delete associated AE")
	@RequestMapping(value = "/clinics/{clinicId}/aes/{aeId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES,ASSOCIATE_EXECUTIVE})
	public ResponseEntity<?> deleteAssociatedAE(@ApiParam(value = "clinicId", required = true, example = "12345") @PathVariable String clinicId,
			@ApiParam(value = "aeId", required = true, example = "12345") @PathVariable Long aeId){
		JSONObject jsonObject = new JSONObject();
		try {
			String message = clinicAssociatedAEListService.dissociateAssoExe(clinicId, aeId);
			jsonObject.put("message", message);
            return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		} catch (HillromException e) {
			jsonObject.put("ERROR", e.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
}
