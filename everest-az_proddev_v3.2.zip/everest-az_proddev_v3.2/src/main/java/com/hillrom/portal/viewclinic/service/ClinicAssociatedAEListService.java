package com.hillrom.portal.viewclinic.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.portal.viewclinic.dto.AEListVO;
import com.hillrom.vest.domain.Authority;
import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.ClinicRepository;
import com.hillrom.vest.repository.EntityUserRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.territory.domain.TerritoryAEAssoc;
import com.hillrom.vest.territory.domain.TerritoryZipcode;
import com.hillrom.vest.territory.repository.TerritoryAEAssocRepository;
import com.hillrom.vest.territory.repository.TerritoryZipCodeRepository;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;
import com.hillrom.vest.web.rest.dto.ClinicVO;
import com.hillrom.vest.web.rest.util.ClinicVOBuilder;


@Service
@Transactional
public class ClinicAssociatedAEListService {
	@Inject
	EntityUserRepository entityUserRepository;
	
	@Inject
	private ClinicRepository clinicRepository; 
	
	@Inject
	private TerritoryZipCodeRepository territoryZipCodeRepository;
	
	@Inject
	private TerritoryAEAssocRepository territoryAEAssocRepository;
	
	@Inject
	private UserExtensionRepository userExtensionRepository;
	
	@Inject
	private UserRepository userRepository;
	
	private final Logger log = LoggerFactory.getLogger(ClinicAssociatedAEListService.class);
	
	public Set<AEListVO> listAE(String clinicId)
	{
		Set<AEListVO> aeList =  null;
		Clinic clinic = clinicRepository.findOne(clinicId);
		if (Objects.nonNull(clinic) && StringUtils.isNotBlank(clinic.getZipcode())) {
			List<TerritoryZipcode>  tzList = territoryZipCodeRepository.findByZipcode(clinic.getZipcode());
			for (TerritoryZipcode tz : tzList) {
				List<TerritoryAEAssoc> taeList = territoryAEAssocRepository.findActiveAEByTerritoryId(tz.getTerritoryId());
				
				if(Objects.nonNull(taeList) && taeList.size() > 0)
					aeList = new HashSet<AEListVO>();
				
				for (TerritoryAEAssoc tae : taeList) {
					AEListVO ae =  new AEListVO();
					ae.setEmailID(tae.getPatientUser().getEmail());
					ae.setFirstName(tae.getPatientUser().getFirstName());
					ae.setLastName(tae.getPatientUser().getLastName());
					ae.setMiddleName(tae.getPatientUser().getMiddleName());
					ae.setLastLoggedInAt(tae.getPatientUser().getLastLoggedInAt());
					ae.setUserId(tae.getPatientUser().getId());
					aeList.add(ae);
				}
			}
		}
		
		return aeList;
	}

	public String dissociateAssoExe(String clinicId, Long aeId) throws HillromException{
		Clinic clinic = clinicRepository.findOne(clinicId);
		
		if (Objects.nonNull(clinic)) {
			UserExtension clinicAEUser = userExtensionRepository.findOne(aeId);
			TerritoryAEAssoc taeUser = null;
			List<TerritoryZipcode> tzList = territoryZipCodeRepository.findByZipcode(clinic.getZipcode());
			if(Objects.nonNull(tzList) && tzList.size() > 0) {
				taeUser = territoryAEAssocRepository.findActiveAEByUserIdAndTerritoryId(aeId,tzList.get(0).getTerritoryId());
				if (Objects.isNull(taeUser))
					throw new HillromException(ExceptionConstants.HR_550);
			}
			
			if (Objects.nonNull(clinicAEUser)) {
				taeUser.setIsActive(false);
				territoryAEAssocRepository.save(taeUser);
				return MessageConstants.HR_317;
			} else {
				throw new HillromException(ExceptionConstants.HR_727);
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_548);
		}
	}

	public User associateAssocExecutive(String clinicId, Long aeId) throws HillromException {
		Clinic clinic = clinicRepository.findOne(clinicId);
		if(Objects.isNull(clinic)) {
	      	throw new HillromException(ExceptionConstants.HR_548);
		} else {
        	User clinicAEUser = userRepository.findOne(aeId); 
        	if(Objects.isNull(clinicAEUser)  || (Objects.nonNull(clinicAEUser) && !clinicAEUser.getAuthorities().contains(new Authority(AuthoritiesConstants.ASSOCIATE_EXECUTIVE)))) {
        		throw new HillromException(ExceptionConstants.HR_727);
        	} else {
        		List<TerritoryZipcode>  tzList = territoryZipCodeRepository.findByZipcode(clinic.getZipcode());
        		if (Objects.isNull(tzList) || tzList.isEmpty())
        			throw new HillromException(ExceptionConstants.HR_713);
        		
        		TerritoryAEAssoc taeUser = territoryAEAssocRepository.findAEByUserIdAndTerritoryId(aeId,tzList.get(0).getTerritoryId());
				if (Objects.nonNull(taeUser)) {
					taeUser.setIsActive(true);
					territoryAEAssocRepository.saveAndFlush(taeUser);
				   	return clinicAEUser;
				}
				
				TerritoryAEAssoc newTaeUser = new TerritoryAEAssoc( tzList.get(0).getTerritoryId(), clinicAEUser, true);
				territoryAEAssocRepository.saveAndFlush(newTaeUser);
				return clinicAEUser;      	
	        }
		}
    }
	
	public Set<ClinicVO> getAssociatedClinicsForAssoExe(Long assocExeId) throws HillromException {
		UserExtension AssocExeUser = userExtensionRepository.findOne(assocExeId);
		Set<ClinicVO> clinics = new HashSet<>();
	    if(Objects.isNull(AssocExeUser)){
	    	throw new HillromException(ExceptionConstants.HR_512);
	    } else {
	    	List<TerritoryAEAssoc> taeList = territoryAEAssocRepository.findAllByUserId(assocExeId);
			if (Objects.nonNull(taeList) && taeList.size() > 0) {
				for(TerritoryAEAssoc tae : taeList) {
					List<TerritoryZipcode> tzList =  territoryZipCodeRepository.findByTerritoryId(tae.getTerritoryId());
					if (Objects.nonNull(tzList) && tzList.size() > 0) {
						for (TerritoryZipcode tz :  tzList) {
							List<Clinic> clinList = clinicRepository.findByZipCode(tz.getZipcode());
							if (Objects.nonNull(clinList) && clinList.size() > 0) {
								clinList.forEach((clin)-> clinics.add(ClinicVOBuilder.build(clin)));								
							}
						}
					}
				}
			}
			
			List<ClinicVO> clinicList = new ArrayList<>(clinics) ;
			Collections.sort(clinicList, (a, b) -> a.getName().compareTo(b.getName()));
			return new LinkedHashSet<>(clinicList);
	    }
    }
}
