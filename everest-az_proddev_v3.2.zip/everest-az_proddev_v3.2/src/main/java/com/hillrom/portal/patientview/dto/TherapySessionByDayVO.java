package com.hillrom.portal.patientview.dto;

public class TherapySessionByDayVO {

	private String patient_id;
	private String type;
	private Long date;
	private Long start_time;
	private Long end_time;
	private Integer duration_in_minutes;
	/**
	 * @return the patient_id
	 */
	public String getPatient_id() {
		return patient_id;
	}
	/**
	 * @param patient_id the patient_id to set
	 */
	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the date
	 */
	public Long getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Long date) {
		this.date = date;
	}
	/**
	 * @return the start_time
	 */
	public Long getStart_time() {
		return start_time;
	}
	/**
	 * @param start_time the start_time to set
	 */
	public void setStart_time(Long start_time) {
		this.start_time = start_time;
	}
	/**
	 * @return the end_time
	 */
	public Long getEnd_time() {
		return end_time;
	}
	/**
	 * @param end_time the end_time to set
	 */
	public void setEnd_time(Long end_time) {
		this.end_time = end_time;
	}
	/**
	 * @return the duration_in_minutes
	 */
	public Integer getDuration_in_minutes() {
		return duration_in_minutes;
	}
	/**
	 * @param duration_in_minutes the duration_in_minutes to set
	 */
	public void setDuration_in_minutes(Integer duration_in_minutes) {
		this.duration_in_minutes = duration_in_minutes;
	}
	public TherapySessionByDayVO(String patient_id, String type, Long date, Long start_time, Long end_time,
			Integer duration_in_minutes) {
		super();
		this.patient_id = patient_id;
		this.type = type;
		this.date = date;
		this.start_time = start_time;
		this.end_time = end_time;
		this.duration_in_minutes = duration_in_minutes;
	}
	
	
}
