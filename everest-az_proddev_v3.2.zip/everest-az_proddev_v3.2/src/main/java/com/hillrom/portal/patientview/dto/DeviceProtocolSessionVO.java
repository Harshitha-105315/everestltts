package com.hillrom.portal.patientview.dto;

import java.util.List;

public class DeviceProtocolSessionVO {
	List<TherapySessionVO> sessions;

	public List<TherapySessionVO> getSessions() {
		return sessions;
	}

	public void setSessions(List<TherapySessionVO> sessions) {
		this.sessions = sessions;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sessions == null) ? 0 : sessions.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DeviceProtocolSessionVO other = (DeviceProtocolSessionVO) obj;
		if (sessions == null) {
			if (other.sessions != null)
				return false;
		} else if (!sessions.equals(other.sessions))
			return false;
		return true;
	}

	public DeviceProtocolSessionVO(List<TherapySessionVO> sessions) {
		super();
		this.sessions = sessions;
	}

	public DeviceProtocolSessionVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "DeviceProtocolSessionVO [sessions=" + sessions + "]";
	}
	
}
