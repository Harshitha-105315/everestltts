package com.hillrom.portal.deploy.dto;

public class PortalDeployProtocolAssocDTO {
	private String TimsId;
	private String devicetype;
	private String protocoltype;
	private int treatments_per_day;
	private int p1_minimum_minutes_per_treatment;
	private int p1_minimum_frequency;
	private int p1_maximum_frequency;
	private int p1_minimum_pressure;
	private int p1_maximum_pressure;
	private int p2_minimum_minutes_per_treatment;
	private int p2_minimum_frequency;
	private int p2_maximum_frequency;
	private int p2_minimum_pressure;
	private int p2_maximum_pressure;
	private int p3_minimum_minutes_per_treatment;
	private int p3_minimum_frequency;
	private int p3_maximum_frequency;
	private int p3_minimum_pressure;
	private int p3_maximum_pressure;
	private int p4_minimum_minutes_per_treatment;
	private int p4_minimum_frequency;
	private int p4_maximum_frequency;
	private int p4_minimum_pressure;
	private int p4_maximum_pressure;
	private int p5_minimum_minutes_per_treatment;
	private int p5_minimum_frequency;
	private int p5_maximum_frequency;
	private int p5_minimum_pressure;
	private int p5_maximum_pressure;
	private int p6_minimum_minutes_per_treatment;
	private int p6_minimum_frequency;
	private int p6_maximum_frequency;
	private int p6_minimum_pressure;
	private int p6_maximum_pressure;
	private int p7_minimum_minutes_per_treatment;
	private int p7_minimum_frequency;
	private int p7_maximum_frequency;
	private int p7_minimum_pressure;
	private int p7_maximum_pressure;
	private int p8_minimum_minutes_per_treatment;
	private int p8_minimum_frequency;
	private int p8_maximum_frequency;
	private int p8_minimum_pressure;
	private int p8_maximum_pressure;
	public String getTimsId() {
		return TimsId;
	}
	public void setTimsId(String timsId) {
		TimsId = timsId;
	}
	public String getDevicetype() {
		return devicetype;
	}
	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}
	public String getProtocoltype() {
		return protocoltype;
	}
	public void setProtocoltype(String protocoltype) {
		this.protocoltype = protocoltype;
	}
	public int getTreatments_per_day() {
		return treatments_per_day;
	}
	public void setTreatments_per_day(int treatments_per_day) {
		this.treatments_per_day = treatments_per_day;
	}
	public int getP1_minimum_minutes_per_treatment() {
		return p1_minimum_minutes_per_treatment;
	}
	public void setP1_minimum_minutes_per_treatment(int p1_minimum_minutes_per_treatment) {
		this.p1_minimum_minutes_per_treatment = p1_minimum_minutes_per_treatment;
	}
	public int getP1_minimum_frequency() {
		return p1_minimum_frequency;
	}
	public void setP1_minimum_frequency(int p1_minimum_frequency) {
		this.p1_minimum_frequency = p1_minimum_frequency;
	}
	public int getP1_maximum_frequency() {
		return p1_maximum_frequency;
	}
	public void setP1_maximum_frequency(int p1_maximum_frequency) {
		this.p1_maximum_frequency = p1_maximum_frequency;
	}
	public int getP1_minimum_pressure() {
		return p1_minimum_pressure;
	}
	public void setP1_minimum_pressure(int p1_minimum_pressure) {
		this.p1_minimum_pressure = p1_minimum_pressure;
	}
	public int getP1_maximum_pressure() {
		return p1_maximum_pressure;
	}
	public void setP1_maximum_pressure(int p1_maximum_pressure) {
		this.p1_maximum_pressure = p1_maximum_pressure;
	}
	public int getP2_minimum_minutes_per_treatment() {
		return p2_minimum_minutes_per_treatment;
	}
	public void setP2_minimum_minutes_per_treatment(int p2_minimum_minutes_per_treatment) {
		this.p2_minimum_minutes_per_treatment = p2_minimum_minutes_per_treatment;
	}
	public int getP2_minimum_frequency() {
		return p2_minimum_frequency;
	}
	public void setP2_minimum_frequency(int p2_minimum_frequency) {
		this.p2_minimum_frequency = p2_minimum_frequency;
	}
	public int getP2_maximum_frequency() {
		return p2_maximum_frequency;
	}
	public void setP2_maximum_frequency(int p2_maximum_frequency) {
		this.p2_maximum_frequency = p2_maximum_frequency;
	}
	public int getP2_minimum_pressure() {
		return p2_minimum_pressure;
	}
	public void setP2_minimum_pressure(int p2_minimum_pressure) {
		this.p2_minimum_pressure = p2_minimum_pressure;
	}
	public int getP2_maximum_pressure() {
		return p2_maximum_pressure;
	}
	public void setP2_maximum_pressure(int p2_maximum_pressure) {
		this.p2_maximum_pressure = p2_maximum_pressure;
	}
	public int getP3_minimum_minutes_per_treatment() {
		return p3_minimum_minutes_per_treatment;
	}
	public void setP3_minimum_minutes_per_treatment(int p3_minimum_minutes_per_treatment) {
		this.p3_minimum_minutes_per_treatment = p3_minimum_minutes_per_treatment;
	}
	public int getP3_minimum_frequency() {
		return p3_minimum_frequency;
	}
	public void setP3_minimum_frequency(int p3_minimum_frequency) {
		this.p3_minimum_frequency = p3_minimum_frequency;
	}
	public int getP3_maximum_frequency() {
		return p3_maximum_frequency;
	}
	public void setP3_maximum_frequency(int p3_maximum_frequency) {
		this.p3_maximum_frequency = p3_maximum_frequency;
	}
	public int getP3_minimum_pressure() {
		return p3_minimum_pressure;
	}
	public void setP3_minimum_pressure(int p3_minimum_pressure) {
		this.p3_minimum_pressure = p3_minimum_pressure;
	}
	public int getP3_maximum_pressure() {
		return p3_maximum_pressure;
	}
	public void setP3_maximum_pressure(int p3_maximum_pressure) {
		this.p3_maximum_pressure = p3_maximum_pressure;
	}
	public int getP4_minimum_minutes_per_treatment() {
		return p4_minimum_minutes_per_treatment;
	}
	public void setP4_minimum_minutes_per_treatment(int p4_minimum_minutes_per_treatment) {
		this.p4_minimum_minutes_per_treatment = p4_minimum_minutes_per_treatment;
	}
	public int getP4_minimum_frequency() {
		return p4_minimum_frequency;
	}
	public void setP4_minimum_frequency(int p4_minimum_frequency) {
		this.p4_minimum_frequency = p4_minimum_frequency;
	}
	public int getP4_maximum_frequency() {
		return p4_maximum_frequency;
	}
	public void setP4_maximum_frequency(int p4_maximum_frequency) {
		this.p4_maximum_frequency = p4_maximum_frequency;
	}
	public int getP4_minimum_pressure() {
		return p4_minimum_pressure;
	}
	public void setP4_minimum_pressure(int p4_minimum_pressure) {
		this.p4_minimum_pressure = p4_minimum_pressure;
	}
	public int getP4_maximum_pressure() {
		return p4_maximum_pressure;
	}
	public void setP4_maximum_pressure(int p4_maximum_pressure) {
		this.p4_maximum_pressure = p4_maximum_pressure;
	}
	public int getP5_minimum_minutes_per_treatment() {
		return p5_minimum_minutes_per_treatment;
	}
	public void setP5_minimum_minutes_per_treatment(int p5_minimum_minutes_per_treatment) {
		this.p5_minimum_minutes_per_treatment = p5_minimum_minutes_per_treatment;
	}
	public int getP5_minimum_frequency() {
		return p5_minimum_frequency;
	}
	public void setP5_minimum_frequency(int p5_minimum_frequency) {
		this.p5_minimum_frequency = p5_minimum_frequency;
	}
	public int getP5_maximum_frequency() {
		return p5_maximum_frequency;
	}
	public void setP5_maximum_frequency(int p5_maximum_frequency) {
		this.p5_maximum_frequency = p5_maximum_frequency;
	}
	public int getP5_minimum_pressure() {
		return p5_minimum_pressure;
	}
	public void setP5_minimum_pressure(int p5_minimum_pressure) {
		this.p5_minimum_pressure = p5_minimum_pressure;
	}
	public int getP5_maximum_pressure() {
		return p5_maximum_pressure;
	}
	public void setP5_maximum_pressure(int p5_maximum_pressure) {
		this.p5_maximum_pressure = p5_maximum_pressure;
	}
	public int getP6_minimum_minutes_per_treatment() {
		return p6_minimum_minutes_per_treatment;
	}
	public void setP6_minimum_minutes_per_treatment(int p6_minimum_minutes_per_treatment) {
		this.p6_minimum_minutes_per_treatment = p6_minimum_minutes_per_treatment;
	}
	public int getP6_minimum_frequency() {
		return p6_minimum_frequency;
	}
	public void setP6_minimum_frequency(int p6_minimum_frequency) {
		this.p6_minimum_frequency = p6_minimum_frequency;
	}
	public int getP6_maximum_frequency() {
		return p6_maximum_frequency;
	}
	public void setP6_maximum_frequency(int p6_maximum_frequency) {
		this.p6_maximum_frequency = p6_maximum_frequency;
	}
	public int getP6_minimum_pressure() {
		return p6_minimum_pressure;
	}
	public void setP6_minimum_pressure(int p6_minimum_pressure) {
		this.p6_minimum_pressure = p6_minimum_pressure;
	}
	public int getP6_maximum_pressure() {
		return p6_maximum_pressure;
	}
	public void setP6_maximum_pressure(int p6_maximum_pressure) {
		this.p6_maximum_pressure = p6_maximum_pressure;
	}
	public int getP7_minimum_minutes_per_treatment() {
		return p7_minimum_minutes_per_treatment;
	}
	public void setP7_minimum_minutes_per_treatment(int p7_minimum_minutes_per_treatment) {
		this.p7_minimum_minutes_per_treatment = p7_minimum_minutes_per_treatment;
	}
	public int getP7_minimum_frequency() {
		return p7_minimum_frequency;
	}
	public void setP7_minimum_frequency(int p7_minimum_frequency) {
		this.p7_minimum_frequency = p7_minimum_frequency;
	}
	public int getP7_maximum_frequency() {
		return p7_maximum_frequency;
	}
	public void setP7_maximum_frequency(int p7_maximum_frequency) {
		this.p7_maximum_frequency = p7_maximum_frequency;
	}
	public int getP7_minimum_pressure() {
		return p7_minimum_pressure;
	}
	public void setP7_minimum_pressure(int p7_minimum_pressure) {
		this.p7_minimum_pressure = p7_minimum_pressure;
	}
	public int getP7_maximum_pressure() {
		return p7_maximum_pressure;
	}
	public void setP7_maximum_pressure(int p7_maximum_pressure) {
		this.p7_maximum_pressure = p7_maximum_pressure;
	}
	public int getP8_minimum_minutes_per_treatment() {
		return p8_minimum_minutes_per_treatment;
	}
	public void setP8_minimum_minutes_per_treatment(int p8_minimum_minutes_per_treatment) {
		this.p8_minimum_minutes_per_treatment = p8_minimum_minutes_per_treatment;
	}
	public int getP8_minimum_frequency() {
		return p8_minimum_frequency;
	}
	public void setP8_minimum_frequency(int p8_minimum_frequency) {
		this.p8_minimum_frequency = p8_minimum_frequency;
	}
	public int getP8_maximum_frequency() {
		return p8_maximum_frequency;
	}
	public void setP8_maximum_frequency(int p8_maximum_frequency) {
		this.p8_maximum_frequency = p8_maximum_frequency;
	}
	public int getP8_minimum_pressure() {
		return p8_minimum_pressure;
	}
	public void setP8_minimum_pressure(int p8_minimum_pressure) {
		this.p8_minimum_pressure = p8_minimum_pressure;
	}
	public int getP8_maximum_pressure() {
		return p8_maximum_pressure;
	}
	public void setP8_maximum_pressure(int p8_maximum_pressure) {
		this.p8_maximum_pressure = p8_maximum_pressure;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((TimsId == null) ? 0 : TimsId.hashCode());
		result = prime * result + ((devicetype == null) ? 0 : devicetype.hashCode());
		result = prime * result + p1_maximum_frequency;
		result = prime * result + p1_maximum_pressure;
		result = prime * result + p1_minimum_frequency;
		result = prime * result + p1_minimum_minutes_per_treatment;
		result = prime * result + p1_minimum_pressure;
		result = prime * result + p2_maximum_frequency;
		result = prime * result + p2_maximum_pressure;
		result = prime * result + p2_minimum_frequency;
		result = prime * result + p2_minimum_minutes_per_treatment;
		result = prime * result + p2_minimum_pressure;
		result = prime * result + p3_maximum_frequency;
		result = prime * result + p3_maximum_pressure;
		result = prime * result + p3_minimum_frequency;
		result = prime * result + p3_minimum_minutes_per_treatment;
		result = prime * result + p3_minimum_pressure;
		result = prime * result + p4_maximum_frequency;
		result = prime * result + p4_maximum_pressure;
		result = prime * result + p4_minimum_frequency;
		result = prime * result + p4_minimum_minutes_per_treatment;
		result = prime * result + p4_minimum_pressure;
		result = prime * result + p5_maximum_frequency;
		result = prime * result + p5_maximum_pressure;
		result = prime * result + p5_minimum_frequency;
		result = prime * result + p5_minimum_minutes_per_treatment;
		result = prime * result + p5_minimum_pressure;
		result = prime * result + p6_maximum_frequency;
		result = prime * result + p6_maximum_pressure;
		result = prime * result + p6_minimum_frequency;
		result = prime * result + p6_minimum_minutes_per_treatment;
		result = prime * result + p6_minimum_pressure;
		result = prime * result + p7_maximum_frequency;
		result = prime * result + p7_maximum_pressure;
		result = prime * result + p7_minimum_frequency;
		result = prime * result + p7_minimum_minutes_per_treatment;
		result = prime * result + p7_minimum_pressure;
		result = prime * result + p8_maximum_frequency;
		result = prime * result + p8_maximum_pressure;
		result = prime * result + p8_minimum_frequency;
		result = prime * result + p8_minimum_minutes_per_treatment;
		result = prime * result + p8_minimum_pressure;
		result = prime * result + ((protocoltype == null) ? 0 : protocoltype.hashCode());
		result = prime * result + treatments_per_day;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortalDeployProtocolAssocDTO other = (PortalDeployProtocolAssocDTO) obj;
		if (TimsId == null) {
			if (other.TimsId != null)
				return false;
		} else if (!TimsId.equals(other.TimsId))
			return false;
		if (devicetype == null) {
			if (other.devicetype != null)
				return false;
		} else if (!devicetype.equals(other.devicetype))
			return false;
		if (p1_maximum_frequency != other.p1_maximum_frequency)
			return false;
		if (p1_maximum_pressure != other.p1_maximum_pressure)
			return false;
		if (p1_minimum_frequency != other.p1_minimum_frequency)
			return false;
		if (p1_minimum_minutes_per_treatment != other.p1_minimum_minutes_per_treatment)
			return false;
		if (p1_minimum_pressure != other.p1_minimum_pressure)
			return false;
		if (p2_maximum_frequency != other.p2_maximum_frequency)
			return false;
		if (p2_maximum_pressure != other.p2_maximum_pressure)
			return false;
		if (p2_minimum_frequency != other.p2_minimum_frequency)
			return false;
		if (p2_minimum_minutes_per_treatment != other.p2_minimum_minutes_per_treatment)
			return false;
		if (p2_minimum_pressure != other.p2_minimum_pressure)
			return false;
		if (p3_maximum_frequency != other.p3_maximum_frequency)
			return false;
		if (p3_maximum_pressure != other.p3_maximum_pressure)
			return false;
		if (p3_minimum_frequency != other.p3_minimum_frequency)
			return false;
		if (p3_minimum_minutes_per_treatment != other.p3_minimum_minutes_per_treatment)
			return false;
		if (p3_minimum_pressure != other.p3_minimum_pressure)
			return false;
		if (p4_maximum_frequency != other.p4_maximum_frequency)
			return false;
		if (p4_maximum_pressure != other.p4_maximum_pressure)
			return false;
		if (p4_minimum_frequency != other.p4_minimum_frequency)
			return false;
		if (p4_minimum_minutes_per_treatment != other.p4_minimum_minutes_per_treatment)
			return false;
		if (p4_minimum_pressure != other.p4_minimum_pressure)
			return false;
		if (p5_maximum_frequency != other.p5_maximum_frequency)
			return false;
		if (p5_maximum_pressure != other.p5_maximum_pressure)
			return false;
		if (p5_minimum_frequency != other.p5_minimum_frequency)
			return false;
		if (p5_minimum_minutes_per_treatment != other.p5_minimum_minutes_per_treatment)
			return false;
		if (p5_minimum_pressure != other.p5_minimum_pressure)
			return false;
		if (p6_maximum_frequency != other.p6_maximum_frequency)
			return false;
		if (p6_maximum_pressure != other.p6_maximum_pressure)
			return false;
		if (p6_minimum_frequency != other.p6_minimum_frequency)
			return false;
		if (p6_minimum_minutes_per_treatment != other.p6_minimum_minutes_per_treatment)
			return false;
		if (p6_minimum_pressure != other.p6_minimum_pressure)
			return false;
		if (p7_maximum_frequency != other.p7_maximum_frequency)
			return false;
		if (p7_maximum_pressure != other.p7_maximum_pressure)
			return false;
		if (p7_minimum_frequency != other.p7_minimum_frequency)
			return false;
		if (p7_minimum_minutes_per_treatment != other.p7_minimum_minutes_per_treatment)
			return false;
		if (p7_minimum_pressure != other.p7_minimum_pressure)
			return false;
		if (p8_maximum_frequency != other.p8_maximum_frequency)
			return false;
		if (p8_maximum_pressure != other.p8_maximum_pressure)
			return false;
		if (p8_minimum_frequency != other.p8_minimum_frequency)
			return false;
		if (p8_minimum_minutes_per_treatment != other.p8_minimum_minutes_per_treatment)
			return false;
		if (p8_minimum_pressure != other.p8_minimum_pressure)
			return false;
		if (protocoltype == null) {
			if (other.protocoltype != null)
				return false;
		} else if (!protocoltype.equals(other.protocoltype))
			return false;
		if (treatments_per_day != other.treatments_per_day)
			return false;
		return true;
	}
	public PortalDeployProtocolAssocDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
