package com.hillrom.portal.managepatients.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.portal.managepatients.domain.UserPatientFlagAssoc;

public interface UserPatientFlagAssocRepository extends JpaRepository<UserPatientFlagAssoc,Long>{
	@Query(nativeQuery=true,value=" SELECT * from USER_PATIENT_FLAG_ASSOC upfa where upfa.patient_id = ?1 and upfa.user_id = ?2 limit 1")
	Optional<UserPatientFlagAssoc> findOneByPatientIdAndUserId(String patientId, Long userId);
	@Query(nativeQuery=true,value=" SELECT * from USER_PATIENT_FLAG_ASSOC upfa where upfa.patient_id = ?1 and upfa.flagged = 1 limit 1")
	Optional<UserPatientFlagAssoc> findOneByPatientIdAndFlagged(String patientId);
}
