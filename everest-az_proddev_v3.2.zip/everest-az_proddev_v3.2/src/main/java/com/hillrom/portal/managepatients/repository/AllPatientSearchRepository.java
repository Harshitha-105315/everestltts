package com.hillrom.portal.managepatients.repository;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.hillrom.portal.managepatients.dto.AllPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AllPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AllPatientSearchVO;
import com.hillrom.portal.patientview.service.PortalSearchUtil;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.PatientInfoService;


@Repository
public class AllPatientSearchRepository {
	
	private final Logger log = LoggerFactory
			.getLogger(AllPatientSearchRepository.class);

	@Inject
	private EntityManager entityManager;

	@Inject
	private PatientInfoService patientInfoService;

	static String PATIENT_SEARCH_BASE_QUERY = "select \r\n" + 
			"	firstName, \r\n" + 
			"    middleName, \r\n" + 
			"    lastName, \r\n" + 
			"    hrID, \r\n" + 
			"    userID, \r\n" + 
			"    patientID, \r\n" + 
			"    clinics, \r\n" + 
			"    isNew, \r\n" + 
			"    if(lastTransn=0,NULL,lastTransn) as lastTrans, \r\n" + 
			"    if(lastTransn=0,1,0) as never, \r\n" + 
			"    if(lastTransn=0,0,if(lastTransn<unix_timestamp(DATE_SUB(curdate(), INTERVAL 30 DAY))*1000, 1, 0)) as stop, \r\n" +
			"    if(deleted=0,1,0) as active, \r\n" +
			"    reason\r\n" +			
			"from ( \r\n" + 
			"	select \r\n" + 
			"	u.first_name as firstName, \r\n" + 
			"	u.middle_name as middleName, \r\n" + 
			"	u.last_name as lastName, \r\n" + 
			"	u.hillrom_id as hrID, \r\n" + 
			"	u.id as userID, \r\n" +
			"	u.is_deleted as deleted, \r\n" +
			"	uex.deactivation_reason as reason, \r\n" +			
			"	pi.id as patientID, \r\n" +
			"	group_concat(distinct concat(cl.name,'#',cl.id) separator '|') as clinics,\r\n" + 
			"	IF(DATEDIFF(curdate(),u.created_date)<15,1,0) as isNew,\r\n" +
			"		GREATEST(\r\n" + 
			"		COALESCE(pi.last_transmission_vest, 0),\r\n" + 
			"		COALESCE(pi.last_transmission_monarch, 0),\r\n" + 
			"		COALESCE(pi.last_transmission_titan, 0)\r\n" + 
			"		)AS lastTransn \r\n" + 
			"from USER u\r\n" + 
			"	LEFT JOIN USER_PATIENT_ASSOC upa on upa.user_id=u.id\r\n" +
			"	LEFT JOIN USER_EXTENSION uex on uex.user_id=u.id\r\n" +
			"	LEFT JOIN CITY_STATE_ZIP_MAP cszm on cszm.zip = u.zipcode\r\n" +
			"   LEFT JOIN PATIENT_INFO pi on upa.patient_id=pi.id\r\n" + 
			"   LEFT JOIN CLINIC_PATIENT_ASSOC cpa on cpa.patient_id=pi.id	\r\n" + 
			"   LEFT JOIN CLINIC cl on cpa.clinic_id=cl.id\r\n" + 
			"	LEFT JOIN PATIENT_DEVICES_ASSOC pda on pda.patient_id=pi.id\r\n" + 
			"where upa.user_role='"+AuthoritiesConstants.PATIENT+"' "
			+ "$USER_PATTERN_FILTER$ "
			+ "$USER_ACTIVE_STATUS$ "
			+ "$USER_CREATED_DATE$ "
			+ "$USER_GENDER$ "
			+ "$USER_COUNTRY$ "
			+ "$USER_STATE$ "
			+ "$USER_CITY$ "
			+ "$DEVICE_ACTIVE_STATUS$ "
			+ "$DEVICE_TYPE$ "
			+ "$PATIENT_TYPE$ "
			+ "$CLINIC_STATUS$"
			+ "$PATIENT_AGE$\r\n"+
			"group by u.id )x $WHERE_CONDITION$ $GROUP_OPEN$ $PATIENT_NOTRANS$ $TRANS_STOP_OPTION$ $PATIENT_STOP_TRANS$ $TRANS_RANGE_OPTION$ $PATIENT_TRANS_RANGE$ $GROUP_CLOSE$ $SORT_BY$ $SORT_ORDER$ ";

	private String setPatientWhereCondition(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$WHERE_CONDITION$","");
		}else {
			queryStr = queryStr.replace("$WHERE_CONDITION$", "where");
		}
		return queryStr;		
	}
	
	private String setGroupOpen(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$GROUP_OPEN$","");
		}else {
			queryStr = queryStr.replace("$GROUP_OPEN$", "(");
		}
		return queryStr;		
	}
	
	private String setGroupClose(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$GROUP_CLOSE$","");
		}else {
			queryStr = queryStr.replace("$GROUP_CLOSE$", ")");
		}
		return queryStr;		
	}
	
	private String setTransStopOption(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$TRANS_STOP_OPTION$","");
		}else {
			queryStr = queryStr.replace("$TRANS_STOP_OPTION$", "or");
		}
		return queryStr;		
	}
	
	private String setTransRangeOption(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$TRANS_RANGE_OPTION$","");
		}else {
			queryStr = queryStr.replace("$TRANS_RANGE_OPTION$", "and");
		}
		return queryStr;		
	}
	
	private String setPatientNoTrans(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$PATIENT_NOTRANS$","");
		}else {
			queryStr = queryStr.replace("$PATIENT_NOTRANS$", "(lastTransn=0)");
		}
		return queryStr;
	}

	private String setPatientStopTrans(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$PATIENT_STOP_TRANS$","");
		}else {
			queryStr = queryStr.replace("$PATIENT_STOP_TRANS$", "(lastTransn <> 0 and lastTransn<unix_timestamp(DATE_SUB(curdate(), INTERVAL 30 DAY))*1000)");
		}
		return queryStr;
	}

	private String setPatientTransRange(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$PATIENT_TRANS_RANGE$","");
		}else {
			queryStr = queryStr.replace("$PATIENT_TRANS_RANGE$", "( lastTransn <> 0 and DATEDIFF(curdate(),from_unixtime(lastTransn/1000)) <" + value + " )");
		}
		return queryStr;
	}

	private String setClinicStatus(String queryStr, boolean enable, String activeSts)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$CLINIC_STATUS$","");
		}else {
			if (activeSts.equals("active")) {
				queryStr = queryStr.replace("$CLINIC_STATUS$", "and cl.id is not null and cl.is_deleted=0");
			}else if (activeSts.equals("inactive")) {
				queryStr = queryStr.replace("$CLINIC_STATUS$", "and ( cl.id is null or cl.is_deleted=1 )");
			}else {
				queryStr = queryStr.replace("$CLINIC_STATUS$","");
			}				
		}
		return queryStr;
	}

//	$PATIENT_TYPE$
	private String setDeviceAssocPatientType(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$PATIENT_TYPE$","");
		}else {
			queryStr = queryStr.replace("$PATIENT_TYPE$", "and pda.patient_type='CD'");
		}
		return queryStr;
	}

	private String setDeviceAssocDeviceType(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$DEVICE_TYPE$","");
		}else {
			if(value.equals("VEST")) {
				queryStr = queryStr.replace("$DEVICE_TYPE$", "and (pda.device_type='VEST')");
			}else if (value.equals("MONARCH")) {
				queryStr = queryStr.replace("$DEVICE_TYPE$", "and (pda.device_type='MONARCH')");
			}else if (value.equals("TITAN")) {
				queryStr = queryStr.replace("$DEVICE_TYPE$", "and (pda.device_type='TITAN')");
			}else {
				queryStr = queryStr.replace("$DEVICE_TYPE$","");
			}
		}
		return queryStr;
	}

//	$DEVICE_ACTIVE_STATUS$
	private String setDeviceAssocDeviceStatus(String queryStr, boolean enable, String activeSts)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$","");
		}else {
			if (activeSts.equals("active")) {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$", "and pda.is_active=1");
			}else if (activeSts.equals("inactive")) {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$", "and pda.is_active=0");
			}else {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$","");
			}				
		}
		return queryStr;
	}
	
//	$USER_PATTERN_FILTER$ 
	private String setUserPattern(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_PATTERN_FILTER$","");
		}else {
			String valueName =PortalSearchUtil.updatebaseString(value);
			value = PortalSearchUtil.updatebaseStringWith(value, "%");
			valueName = Arrays.asList(valueName.split("\\s+")).stream().map(c -> "+" + c.toLowerCase() + "*").collect(Collectors.joining(" "));
					
			queryStr = queryStr.replace("$USER_PATTERN_FILTER$", " and (MATCH(u.first_name,u.last_name,u.middle_name) AGAINST ('" + valueName + "' IN BOOLEAN MODE) or u.hillrom_id like '%"+value+ "%' or u.email like '%" +value + "%' or pda.serial_number like '%" + value + "%' )");
		}
		return queryStr;
	}

//	$USER_ACTIVE_STATUS$ 
	private String setUserActiveStatus(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_ACTIVE_STATUS$","");
		}else {
			if(value.equals("active")) {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$", "and u.is_deleted=0 and u.expired=0");
			}else if(value.equals("inactive")) {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$", "and ( u.is_deleted=1 or u.expired=1 )");
			}else {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$","");
			}
		}
		return queryStr;
	}

//	$USER_CREATED_DATE$ 
	private String setUserCreatedDate(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_CREATED_DATE$","");
		}else {
			queryStr = queryStr.replace("$USER_CREATED_DATE$", "and DATEDIFF(curdate(),u.created_date)<15");
		}
		return queryStr;
	}

//	$USER_GENDER$
	private String setUserGender(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_GENDER$","");
		}else {
			if(value.equals("male")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( u.gender='Male' or u.gender='M' )");
			}else if (value.equals("female")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( u.gender='Female' or u.gender='F' )");
			}
			else if (value.equals("other")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( u.gender not in ('male', 'M', 'Female', 'F') or u.gender is null )");
			}else {
				queryStr = queryStr.replace("$USER_GENDER$","");
			}
		}
		return queryStr;
	}
	
//	$USER_COUNTRY$
	private String setUserCountry(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_COUNTRY$","");
		}else {
			if(value.equals("US")) {
				queryStr = queryStr.replace("$USER_COUNTRY$", "and cszm.country='US'");
			}else if (value.equals("CANADA")) {
				queryStr = queryStr.replace("$USER_COUNTRY$", "and cszm.country='CANADA'");
			}else {
				queryStr = queryStr.replace("$USER_COUNTRY$","");
			}
		}
		return queryStr;
	}

//	$USER_STATE$
	private String setUserState(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_STATE$","");
		}else {
			queryStr = queryStr.replace("$USER_STATE$", "and uex.state='" + value + "'");
		}
		return queryStr;
	}
	
//	$USER_CITY$
	private String setUserCity(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_CITY$","");
		}else {
			queryStr = queryStr.replace("$USER_CITY$", "and uex.city='" + value + "'");
		}
		return queryStr;
	}	
	
	private String setSortBy(String queryStr, String value) {
		if(Objects.isNull(value)) {
			queryStr= queryStr.replace("$SORT_BY$", "");
		}else {			
			queryStr= queryStr.replace("$SORT_BY$", "order by ISNULL("+ value +"), "+value);
		}
		return queryStr;
	}

	private String setSortOrder(String queryStr, String value) {
		if(Objects.nonNull(value)) {
			if(!value.equals("ASC") && !value.equals("DESC")) {
				value = "ASC";
			}
			queryStr= queryStr.replace("$SORT_ORDER$", value);
		}else {
			queryStr= queryStr.replace("$SORT_ORDER$", "");
		}
		return queryStr;
	}
	
	private String setUserAge(String queryStr, boolean enable, String ageRange)
	{
		if(!enable) {
			queryStr = queryStr.replace("$PATIENT_AGE$","");
		}else {
			if (ageRange.equals("all"))
			{
				queryStr = queryStr.replace("$PATIENT_AGE$","");
			}else if (ageRange.equals("18")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(u.dob,curdate()), curdate()) <= 17");
			}else if (ageRange.equals("35")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(u.dob,curdate()), curdate()) >= 18 and TIMESTAMPDIFF(YEAR, u.dob, curdate()) <= 35");
			}else if (ageRange.equals("65")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(u.dob,curdate()), curdate()) >= 36 and TIMESTAMPDIFF(YEAR, u.dob, curdate()) <= 64");
			}else if (ageRange.equals("above65")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(u.dob,curdate()), curdate()) >= 65");
			}
		}
	
		return queryStr;
	}
	
	private AllPatientSearchResultVO generateFinalResult(String queryStr, AllPatientSearchDTO dto)
	{
		int pageSz = dto.getPageSize();
		int pageNo = dto.getPageNo();

		if(Objects.nonNull(dto.getSortBy())) {
			if(dto.getSortBy().equals("hrID")) {				
			}else if(dto.getSortBy().equals("clinicName")) {
				dto.setSortBy("clinics");
			}else if(dto.getSortBy().equals("lastTrans")) {				
			}else {
				dto.setSortBy("firstName");
			}
			queryStr = setSortBy(queryStr, dto.getSortBy());
		}else {
			queryStr = setSortBy(queryStr, "firstName");
		}
		
		if(Objects.nonNull(dto.getSortOrder())) {
			queryStr = setSortOrder(queryStr, dto.getSortOrder());
		}else {
			if(Objects.isNull(dto.getPattern())) {
				queryStr = setSortOrder(queryStr, "ASC");
			}else {
				queryStr = setSortOrder(queryStr, null);
			}
		}
		
		AllPatientSearchResultVO result = new AllPatientSearchResultVO();
		String countQuery= "select count(*) from (" + queryStr + ") countResult;";
		log.debug(countQuery);
		Query count = entityManager.createNativeQuery(countQuery);
		BigInteger resCount = (BigInteger)count.getSingleResult();
		log.debug(resCount.toString());

		if (dto.isCountOnly())
		{
			result.setTotalCnt(resCount.longValue());
			return result;
		}
		
		queryStr += "LIMIT $PAGE_SIZE$ OFFSET $OFFSET$;";
		queryStr = queryStr.replace("$PAGE_SIZE$", Integer.toString(pageSz));
		int offset = (pageSz*(pageNo-1));
		queryStr = queryStr.replace("$OFFSET$", Integer.toString(offset));
		long totalPage = resCount.longValue()/pageSz;
		long reminder = resCount.longValue()%pageSz;
		if(reminder>0) {
			totalPage +=1;
		}
		
		result.setTotalCnt(resCount.longValue());
		result.setTotalPage(totalPage);
		result.setCurrPage(pageNo);
		
		if(pageNo<=totalPage) {
			log.debug(queryStr);
			Query query = entityManager.createNativeQuery(queryStr, "ManagePatientSearchResultMapping");
			@SuppressWarnings("unchecked")
			List<AllPatientSearchVO> results = (List<AllPatientSearchVO>) query.getResultList();
			
			for (AllPatientSearchVO allPatientSearchVO : results) {
				allPatientSearchVO.setFirstTrans(patientInfoService.getFirstTransmission(allPatientSearchVO.getPatientID()));
			}
			result.setCurrPageSz(results.size());
			if(results.size()>0) {
				result.setResult(results);			
			}
		}
		
		return result;		
	}
	
	public String setTransmissionValues(String queryStr, AllPatientSearchDTO dto)
	{
		if(Objects.nonNull(dto) && Objects.nonNull(dto.getTransmission()) && Objects.nonNull(dto.getRange())) {
			Boolean condition =false;			

			if(dto.getTransmission().equals("never")) {
				condition = true;
				queryStr =setPatientNoTrans(queryStr,true);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,false);
				if(dto.getRange().equalsIgnoreCase("all")){
					queryStr = setTransRangeOption(queryStr,false);
					queryStr = setPatientTransRange(queryStr,false,null);
				}else {
					if(condition) {
						queryStr =setTransRangeOption(queryStr,true);
					}else {
						queryStr =setTransRangeOption(queryStr,false);
					}
					condition = true;
					queryStr =setPatientTransRange(queryStr,true,dto.getRange());
				}
			}else if(dto.getTransmission().equals("stopped")) {
				condition = true;
				queryStr =setPatientNoTrans(queryStr,false);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,true);
				if(dto.getRange().equalsIgnoreCase("all")){
					queryStr = setTransRangeOption(queryStr,false);
					queryStr = setPatientTransRange(queryStr,false,null);
				}else {
					if(condition) {
						queryStr =setTransRangeOption(queryStr,true);
					}else {
						queryStr =setTransRangeOption(queryStr,false);
					}
					condition = true;
					queryStr =setPatientTransRange(queryStr,true,dto.getRange());
				}
			}else{
				queryStr =setPatientNoTrans(queryStr,false);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,false);
				if(dto.getRange().equalsIgnoreCase("all")){
					queryStr = setTransRangeOption(queryStr,false);
					queryStr = setPatientTransRange(queryStr,false,null);
				}else {
					if(condition) {
						queryStr =setTransRangeOption(queryStr,true);
					}else {
						queryStr =setTransRangeOption(queryStr,false);
					}
					condition = true;
					queryStr =setPatientTransRange(queryStr,true,dto.getRange());
				}
			}

			if(condition) {
				queryStr =setPatientWhereCondition(queryStr,true);
				queryStr =setGroupOpen(queryStr,true);
				queryStr =setGroupClose(queryStr,true);
			}else {
				queryStr =setPatientWhereCondition(queryStr,false);
				queryStr =setGroupOpen(queryStr,false);
				queryStr =setGroupClose(queryStr,false);				
			}
		}else if(Objects.nonNull(dto) && Objects.nonNull(dto.getTransmission())) {
			Boolean condition =false;			
			queryStr =setTransRangeOption(queryStr,false);
			queryStr =setPatientTransRange(queryStr,false,null);

			if(dto.getTransmission().equals("never")) {
				condition = true;
				queryStr =setPatientNoTrans(queryStr,true);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,false);
				
			}else if(dto.getTransmission().equals("stopped")) {
				condition = true;
				queryStr =setPatientNoTrans(queryStr,false);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,true);

			}else{
				queryStr =setPatientNoTrans(queryStr,false);
				queryStr =setTransStopOption(queryStr,false);
				queryStr =setPatientStopTrans(queryStr,false);
			}
			
			if(condition) {
				queryStr =setPatientWhereCondition(queryStr,true);
				queryStr =setGroupOpen(queryStr,true);
				queryStr =setGroupClose(queryStr,true);
			}else {
				queryStr =setPatientWhereCondition(queryStr,false);
				queryStr =setGroupOpen(queryStr,false);
				queryStr =setGroupClose(queryStr,false);				
			}
			
		}else if (Objects.nonNull(dto) && Objects.nonNull(dto.getRange())){
			Boolean condition =false;
			if(dto.getRange().equalsIgnoreCase("all")){
				queryStr =setTransRangeOption(queryStr,false);
				queryStr =setPatientTransRange(queryStr,false,null);
			}else {
				condition = true;
				queryStr =setTransRangeOption(queryStr,false);
				queryStr =setPatientTransRange(queryStr,true,dto.getRange());
			}
			queryStr =setPatientNoTrans(queryStr,false);
			queryStr =setTransStopOption(queryStr,false);
			queryStr =setPatientStopTrans(queryStr,false);
			if(condition) {
				queryStr =setPatientWhereCondition(queryStr,true);
				queryStr =setGroupOpen(queryStr,true);
				queryStr =setGroupClose(queryStr,true);
			}else {
				queryStr =setPatientWhereCondition(queryStr,false);
				queryStr =setGroupOpen(queryStr,false);
				queryStr =setGroupClose(queryStr,false);				
			}
		}else {
			queryStr =setTransRangeOption(queryStr,false);
			queryStr =setPatientTransRange(queryStr,false,null);
			queryStr =setPatientNoTrans(queryStr,false);
			queryStr =setTransStopOption(queryStr,false);
			queryStr =setPatientStopTrans(queryStr,false);
			queryStr =setPatientWhereCondition(queryStr,false);
			queryStr =setGroupOpen(queryStr,false);
			queryStr =setGroupClose(queryStr,false);				
		}
		return queryStr;
	}
	
	public AllPatientSearchResultVO searchPatientSimple(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,false,null);
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,false,null);
		queryStr=setUserPattern(queryStr,Objects.nonNull(dto.getPattern()),dto.getPattern());
		queryStr=setUserActiveStatus(queryStr,false,null);
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,false, null);
		queryStr=setUserCountry(queryStr,false, null);
		queryStr=setUserState(queryStr,false, null);
		queryStr=setUserCity(queryStr,false, null);		
		queryStr=setUserAge(queryStr,false, null);
		return generateFinalResult(queryStr, dto);
	}
	
	public AllPatientSearchResultVO searchPatientAll(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}

	public AllPatientSearchResultVO searchPatientVest(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"VEST");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}

	public AllPatientSearchResultVO searchPatientMonarch(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"MONARCH");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}
	public AllPatientSearchResultVO searchPatientTitan(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"TITAN");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}


	public AllPatientSearchResultVO searchPatientMulti(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,true);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}

	public AllPatientSearchResultVO searchPatientNew(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,true);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}

	public AllPatientSearchResultVO searchPatientStop(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}

	public AllPatientSearchResultVO searchPatientNever(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}
	
	public AllPatientSearchResultVO searchPatientInactive(AllPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setTransmissionValues(queryStr, dto);
		queryStr=setClinicStatus(queryStr,Objects.nonNull(dto.getClinicSts()),dto.getClinicSts());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,true,"inactive");
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setUserCountry(queryStr,Objects.nonNull(dto.getCountry()), dto.getCountry());
		queryStr=setUserState(queryStr,Objects.nonNull(dto.getState()), dto.getState());
		queryStr=setUserCity(queryStr,Objects.nonNull(dto.getCity()), dto.getCity());		
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateFinalResult(queryStr, dto);
	}
}
