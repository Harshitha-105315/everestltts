package com.hillrom.portal.managepatients.dto;

import java.util.List;

public class AllPatientSearchResultVO {
	long totalCnt;
	long totalPage;
	long currPage;
	long currPageSz;
	List<AllPatientSearchVO> result;
	public long getTotalCnt() {
		return totalCnt;
	}
	public void setTotalCnt(long totalCnt) {
		this.totalCnt = totalCnt;
	}
	public long getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(long totalPage) {
		this.totalPage = totalPage;
	}
	public long getCurrPage() {
		return currPage;
	}
	public void setCurrPage(long currPage) {
		this.currPage = currPage;
	}
	public long getCurrPageSz() {
		return currPageSz;
	}
	public void setCurrPageSz(long currPageSz) {
		this.currPageSz = currPageSz;
	}
	public List<AllPatientSearchVO> getResult() {
		return result;
	}
	public void setResult(List<AllPatientSearchVO> result) {
		this.result = result;
	}
}
