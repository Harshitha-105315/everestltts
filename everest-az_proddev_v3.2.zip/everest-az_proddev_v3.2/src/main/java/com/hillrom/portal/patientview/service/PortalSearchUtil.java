package com.hillrom.portal.patientview.service;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PortalSearchUtil {
	public static final String updatebaseString(String baseString) {
		if(Objects.isNull(baseString)) {
			return "";
		}
        Pattern pt = Pattern.compile("[^a-zA-Z0-9 ]");
        Matcher match= pt.matcher(baseString);
        while(match.find())
        {
            String s= match.group();
            baseString=baseString.replaceAll("\\"+s, "");
        }
		return baseString;
	}

	public static final String updatebaseStringWith(String baseString, String replaceChar) {
		if(Objects.isNull(baseString)) {
			return "";
		}
        Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
        Matcher match= pt.matcher(baseString);
        while(match.find())
        {
            String s= match.group();
            baseString=baseString.replaceAll("\\"+s, replaceChar);
        }
		return baseString;
	}

}
