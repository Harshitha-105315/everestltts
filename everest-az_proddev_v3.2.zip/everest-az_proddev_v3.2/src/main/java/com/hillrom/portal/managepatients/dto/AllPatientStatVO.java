package com.hillrom.portal.managepatients.dto;

public class AllPatientStatVO {
	long all;
	long vest;
	long monarch;
	long titan;
	long multi;
	long newPatients;
	long never;
	long stop;
	long inactive;
	public long getAll() {
		return all;
	}
	public void setAll(long all) {
		this.all = all;
	}
	public long getVest() {
		return vest;
	}
	public void setVest(long vest) {
		this.vest = vest;
	}
	public long getMonarch() {
		return monarch;
	}
	public void setMonarch(long monarch) {
		this.monarch = monarch;
	}
	public long getMulti() {
		return multi;
	}
	public void setMulti(long multi) {
		this.multi = multi;
	}
	public long getNewPatients() {
		return newPatients;
	}
	public void setNewPatients(long newPatients) {
		this.newPatients = newPatients;
	}
	public long getNever() {
		return never;
	}
	public void setNever(long never) {
		this.never = never;
	}
	public long getStop() {
		return stop;
	}
	public void setStop(long stop) {
		this.stop = stop;
	}
	public long getInactive() {
		return inactive;
	}
	public void setInactive(long inactive) {
		this.inactive = inactive;
	}	
	public long getTitan() {
		return titan;
	}
	public void setTitan(long titan) {
		this.titan = titan;
	}
}
