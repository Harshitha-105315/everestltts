package com.hillrom.portal.patientview.dto;

public class ClinicsVO {
	private String name;
	private String hillromId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHillromId() {
		return hillromId;
	}
	public void setHillromId(String hillromId) {
		this.hillromId = hillromId;
	}
}
