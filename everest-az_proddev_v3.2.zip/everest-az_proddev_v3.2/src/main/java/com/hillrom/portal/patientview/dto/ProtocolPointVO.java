package com.hillrom.portal.patientview.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ProtocolPointVO {
	private String id;
	private int treatmentsPerDay;
	private int minMinutesPerTreatment;
	private Integer minFrequency;
	private Integer maxFrequency;
	private String type;
	private String treatmentLable;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer minPressure;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer maxPressure;
    
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer minIntensity;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer maxIntensity;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getTreatmentsPerDay() {
		return treatmentsPerDay;
	}

	public void setTreatmentsPerDay(int treatmentsPerDay) {
		this.treatmentsPerDay = treatmentsPerDay;
	}

	public int getMinMinutesPerTreatment() {
		return minMinutesPerTreatment;
	}

	public void setMinMinutesPerTreatment(int minMinutesPerTreatment) {
		this.minMinutesPerTreatment = minMinutesPerTreatment;
	}

	public Integer getMinFrequency() {
		return minFrequency;
	}

	public void setMinFrequency(Integer minFrequency) {
		this.minFrequency = minFrequency;
	}

	public Integer getMaxFrequency() {
		return maxFrequency;
	}

	public void setMaxFrequency(Integer maxFrequency) {
		this.maxFrequency = maxFrequency;
	}

	public Integer getMinPressure() {
		return minPressure;
	}

	public void setMinPressure(Integer minPressure) {
		this.minPressure = minPressure;
	}

	public Integer getMaxPressure() {
		return maxPressure;
	}

	public void setMaxPressure(Integer maxPressure) {
		this.maxPressure = maxPressure;
	}

	public Integer getMinIntensity() {
		return minIntensity;
	}

	public void setMinIntensity(Integer minIntensity) {
		this.minIntensity = minIntensity;
	}

	public Integer getMaxIntensity() {
		return maxIntensity;
	}

	public void setMaxIntensity(Integer maxIntensity) {
		this.maxIntensity = maxIntensity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getTreatmentLable() {
		return treatmentLable;
	}

	public void setTreatmentLable(String treatmentLable) {
		this.treatmentLable = treatmentLable;
	}

	// Vest
	public ProtocolPointVO(String id, int treatmentsPerDay, int minMinutesPerTreatment, Integer minFrequency,
			Integer maxFrequency, String type, String treatmentLable, Integer minPressure, Integer maxPressure, Integer minIntensity, Integer maxIntensity) {
		super();
		this.id = id;
		this.treatmentsPerDay = treatmentsPerDay;
		this.minMinutesPerTreatment = minMinutesPerTreatment;
		this.minFrequency = minFrequency;
		this.maxFrequency = maxFrequency;
		this.type = type;
		this.treatmentLable = treatmentLable;
		this.minPressure = minPressure;
		this.maxPressure = maxPressure;
	}

	// Monarch
	public ProtocolPointVO(String id, int treatmentsPerDay, int minMinutesPerTreatment, Integer minFrequency,
			Integer maxFrequency, String type, String treatmentLable, Integer minIntensity, Integer maxIntensity) {
		super();
		this.id = id;
		this.treatmentsPerDay = treatmentsPerDay;
		this.minMinutesPerTreatment = minMinutesPerTreatment;
		this.minFrequency = minFrequency;
		this.maxFrequency = maxFrequency;
		this.type = type;
		this.treatmentLable = treatmentLable;
		this.minIntensity = minIntensity;
		this.maxIntensity = maxIntensity;
	}

}
