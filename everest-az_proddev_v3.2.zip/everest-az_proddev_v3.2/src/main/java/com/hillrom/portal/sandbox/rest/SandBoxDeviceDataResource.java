package com.hillrom.portal.sandbox.rest;

import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.LocalDate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.monarch.service.PatientVestDeviceRawLogsMonarchService;
import com.hillrom.optimus.domain.OptimusData;
import com.hillrom.optimus.service.OptimusDataService;
import com.hillrom.titan.domain.TitanData;
import com.hillrom.titan.service.TitanDataService;
import com.hillrom.vest.domain.PatientVestDeviceRawLogMonarch;
import com.hillrom.vest.domain.PatientVestDeviceRawLogTitan;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Sandbox device data", description = "Sandbox device data search : Implemented", tags = { "Sandbox device data" })
public class SandBoxDeviceDataResource {

	@Inject 
	OptimusDataService optimusDataService;
	
	@Inject
	TitanDataService titanDataService;
	
	@Inject
	PatientVestDeviceRawLogsMonarchService patientVestDeviceRawLogsMonarchService;
	
	@ApiOperation(httpMethod = "GET", value = "retrieve monarch device data by serial no")
	@RequestMapping(value = "/devicedata/monarch",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<PatientVestDeviceRawLogMonarch> findMonarchLatestDataBySerialNumber(
			@RequestParam(value="serialNo",required=false) String serial_no,
			@RequestParam(value="pageNo",required=true) int pageNo,
    		@RequestParam(value="pageSz",required=true) int pageSz,
			@RequestParam(value="from",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to			) {
		Page<PatientVestDeviceRawLogMonarch> chargerDataList = null;
		
		if (Objects.isNull(serial_no)) {
			chargerDataList = patientVestDeviceRawLogsMonarchService.findAll(new PageRequest(pageNo, pageSz), from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());
		}else {
			chargerDataList = patientVestDeviceRawLogsMonarchService.findBySNo(new PageRequest(pageNo, pageSz), serial_no,from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());			
		}
		return chargerDataList;

	}
	
	@ApiOperation(httpMethod = "GET", value = "retrieve optimus device data by serial no")
	@RequestMapping(value = "/devicedata/optimus",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<OptimusData> findOptimusLatestDataBySerialNumber(
			@RequestParam(value="serialNo",required=false) String serial_no,
			@RequestParam(value="pageNo",required=true) int pageNo,
    		@RequestParam(value="pageSz",required=true) int pageSz,			
			@RequestParam(value="from",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    	) {
			Page<OptimusData> optimusDataList = null;
			
			if (Objects.isNull(serial_no)) {
				optimusDataList = optimusDataService.findAll(new PageRequest(pageNo, pageSz), from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());
			}else {
				optimusDataList = optimusDataService.findBySNo(new PageRequest(pageNo, pageSz), serial_no,from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());			
			}
			return optimusDataList;
	}
	
	@ApiOperation(httpMethod = "GET", value = "retrieve titan device data by serial no")
	@RequestMapping(value = "/devicedata/titan",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
	public Page<PatientVestDeviceRawLogTitan> findTitanLatestDataBySerialNumber(
			@RequestParam(value="serialNo",required=false) String serial_no,
			@RequestParam(value="pageNo",required=true) int pageNo,
    		@RequestParam(value="pageSz",required=true) int pageSz,			
			@RequestParam(value="from",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    	) {
			Page<PatientVestDeviceRawLogTitan> titanDataList = null;
			
			if (Objects.isNull(serial_no)) {
				titanDataList = titanDataService.findAll(new PageRequest(pageNo, pageSz), from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());
			}else {
				titanDataList = titanDataService.findBySNo(new PageRequest(pageNo, pageSz), serial_no,from.toDateTimeAtStartOfDay(), to.plusDays(1).toDateTimeAtStartOfDay());			
			}
			return titanDataList;
	}

}
