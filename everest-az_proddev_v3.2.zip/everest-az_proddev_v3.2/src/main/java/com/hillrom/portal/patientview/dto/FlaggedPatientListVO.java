package com.hillrom.portal.patientview.dto;

public class FlaggedPatientListVO {
	private Long clinicAdminId;
	private String ClinicId;
	public Long getClinicAdminId() {
		return clinicAdminId;
	}
	public void setClinicAdminId(Long clinicAdminId) {
		this.clinicAdminId = clinicAdminId;
	}
	public String getClinicId() {
		return ClinicId;
	}
	public void setClinicId(String clinicId) {
		ClinicId = clinicId;
	}

}
