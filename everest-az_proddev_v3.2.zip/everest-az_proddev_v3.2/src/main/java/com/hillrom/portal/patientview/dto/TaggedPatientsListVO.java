package com.hillrom.portal.patientview.dto;

import org.joda.time.DateTime;

public class TaggedPatientsListVO {

	private String patientId;
	private Long taggedUserId;
	private String firstName;
	private String lastName;
	private String middleName;
	private Long providerUserId;
	private String providerFirstName;
	private String providerLastName;
	private String providerMiddleName;
	private String providerUserRole;
	private DateTime lastTransmission;
	private int completedSessions;
	private String deviceType;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Long getTaggedUserId() {
		return taggedUserId;
	}

	public void setTaggedUserId(Long taggedUserId) {
		this.taggedUserId = taggedUserId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Long getProviderUserId() {
		return providerUserId;
	}

	public void setProviderUserId(Long providerUserId) {
		this.providerUserId = providerUserId;
	}

	public String getProviderFirstName() {
		return providerFirstName;
	}

	public void setProviderFirstName(String providerFirstName) {
		this.providerFirstName = providerFirstName;
	}

	public String getProviderLastName() {
		return providerLastName;
	}

	public void setProviderLastName(String providerLastName) {
		this.providerLastName = providerLastName;
	}

	public String getProviderMiddleName() {
		return providerMiddleName;
	}

	public void setProviderMiddleName(String providerMiddleName) {
		this.providerMiddleName = providerMiddleName;
	}

	public String getProviderUserRole() {
		return providerUserRole;
	}

	public void setProviderUserRole(String providerUserRole) {
		this.providerUserRole = providerUserRole;
	}

	public DateTime getLastTransmission() {
		return lastTransmission;
	}

	public void setLastTransmission(DateTime lastTransmission) {
		this.lastTransmission = lastTransmission;
	}

	public int getCompletedSessions() {
		return completedSessions;
	}

	public void setCompletedSessions(int completedSessions) {
		this.completedSessions = completedSessions;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

}
