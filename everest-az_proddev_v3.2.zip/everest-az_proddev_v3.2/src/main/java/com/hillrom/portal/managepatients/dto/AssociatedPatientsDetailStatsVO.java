package com.hillrom.portal.managepatients.dto;

import java.util.List;

public class AssociatedPatientsDetailStatsVO {
	Long count;
	List<AssociatedPatientSearchClinicInfo> clinicInfo;
	List<AssociatedPatientSearchProviderInfo> providerInfo;
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	public List<AssociatedPatientSearchClinicInfo> getClinicInfo() {
		return clinicInfo;
	}
	public void setClinicInfo(List<AssociatedPatientSearchClinicInfo> clinicInfo) {
		this.clinicInfo = clinicInfo;
	}
	public List<AssociatedPatientSearchProviderInfo> getProviderInfo() {
		return providerInfo;
	}
	public void setProviderInfo(List<AssociatedPatientSearchProviderInfo> providerInfo) {
		this.providerInfo = providerInfo;
	}	
}
