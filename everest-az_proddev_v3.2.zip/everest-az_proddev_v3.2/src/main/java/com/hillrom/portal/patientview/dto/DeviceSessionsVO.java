package com.hillrom.portal.patientview.dto;

import java.util.List;

public class DeviceSessionsVO {
	private String device;
	private boolean isManual;
	private int duration;
	private List<DeviceEventsVO> events;
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public List<DeviceEventsVO> getEvents() {
		return events;
	}
	public void setEvents(List<DeviceEventsVO> events) {
		this.events = events;
	}
	public boolean isManual() {
		return isManual;
	}
	public void setManual(boolean isManual) {
		this.isManual = isManual;
	}
	@Override
	public String toString() {
		return "DeviceSessionsVO [device=" + device + ", isManual=" + isManual + ", duration=" + duration + ", events="
				+ events + "]";
	}

}
