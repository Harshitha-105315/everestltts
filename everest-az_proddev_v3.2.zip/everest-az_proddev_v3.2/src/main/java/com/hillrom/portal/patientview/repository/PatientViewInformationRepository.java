package com.hillrom.portal.patientview.repository;

import static com.hillrom.vest.config.Constants.MONARCH;
import static com.hillrom.vest.config.Constants.VEST;
import static com.hillrom.vest.config.Constants.TITAN;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableLong;
import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.hillrom.monarch.repository.PatientMonarchDeviceRepository;
import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.repository.ProtocolConstantsMonarchRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch;
import com.hillrom.portal.patientview.dto.DeviceProtocolSessionVO;
import com.hillrom.portal.patientview.dto.PatientViewInfoTherapyDataVO;
import com.hillrom.portal.patientview.dto.TherapyEventVO;
import com.hillrom.portal.patientview.dto.TherapySessionVO;
import com.hillrom.titan.repository.PatientProtocolTitanRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.titan.repository.ProtocolConstantsTitanRepository;
import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.titan.service.PatientProtocolTitanService;
import com.hillrom.titan.service.util.PatientVestDeviceTherapyUtilTitan;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.PatientProtocolDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.ProtocolConstantsRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.service.PatientProtocolService;


@Repository
public class PatientViewInformationRepository {
	private final Logger log = LoggerFactory
			.getLogger(PatientViewInformationRepository.class);

	@Inject
	private TherapySessionRepository therapySessionRepository;
	
	@Inject
	private TherapySessionMonarchRepository therapySessionMonarchRepository;
	
	@Inject
	private TherapySessionTitanRepository therapySessionTitanRepository;

	@Inject
	private PatientMonarchDeviceRepository patientMonarchDeviceRepository;
	
	@Inject 
	private PatientVestDeviceRepository patientVestDeviceRepository;
	
	@Inject
	private PatientTitanDeviceRepository patientTitanDeviceRepository;
	
	@Inject
	private PatientProtocolTitanRepository patientProtocolTitanRepository;
	
	@Inject
	private ProtocolConstantsTitanRepository protocolConstantsTitanRepository;
	
	static String PATIENT_THERAPY_DATA_QUERY = 
			"select * from (select\r\n" + 
					"    type,\r\n" + 
					"    duration,\r\n" +
					"	startTime,\r\n" + 
					"    CAST(startTime as date) as therapyDate,\r\n" +
					"    unix_timestamp(originalStartTime),\r\n" +
					"    unix_timestamp(originalEndTime),\r\n" +
					"	 hmr,\r\n" + 
					"	 sno\r\n" + 
					"from (select \r\n" + 
					"	                unionTbl.type,    \r\n" + 
					"                    unionTbl.duration_in_minutes as duration, \r\n" +
					"                    unionTbl.start_time as originalStartTime, \r\n" +
					"                    unionTbl.end_time as originalEndTime, \r\n" +
					"                    unionTbl.hmr as hmr, \r\n" +
					"                    unionTbl.serial_number as sno, \r\n" +
					"                    if(unionTbl.type='VEST',convert_tz(unionTbl.start_time, '-06:00', ':VEST_TIMEZONE'),if(unionTbl.type='MONARCH',convert_tz(unionTbl.start_time, '+00:00', ':MONARCH_TIMEZONE'),convert_tz(unionTbl.start_time, '+00:00', ':TITAN_TIMEZONE'))) as startTime\r\n" + 
					"	  from (		(select date, patient_id, 'MONARCH' as type, serial_number, start_time, end_time, duration_in_minutes,hmr from PATIENT_VEST_THERAPY_DATA_MONARCH where duration_in_minutes > 0 and patient_id=':PATIENT_ID')\r\n" + 
					"					UNION\r\n" + 
					"					(select date, patient_id, 'VEST' as type,serial_number, start_time, end_time, duration_in_minutes, hmr from PATIENT_VEST_THERAPY_DATA where duration_in_minutes > 0 and patient_id=':PATIENT_ID')\r\n" + 
					"					UNION\r\n" + 
					"					(select date, patient_id, 'TITAN' as type,serial_number, start_time, end_time, duration_in_minutes, hmr from PATIENT_VEST_THERAPY_DATA_TITAN where duration_in_minutes > 0 and patient_id=':PATIENT_ID')\r\n" + 
					"	 ) unionTbl\r\n" + 
					")cast )final where final.therapyDate between ':FROM' and ':TO' order by final.startTime";

	@Inject
	private EntityManager entityManager;
	
	@Inject
	private PatientProtocolRepository patientProtocolRepository;

	@Inject
	private PatientProtocolService patientProtocolService;

	@Inject
	private PatientProtocolMonarchRepository patientProtocolMonarchRepository;

	@Inject
	private PatientProtocolMonarchService patientProtocolMonarchService;
	
	@Inject
	private ProtocolConstantsRepository  protocolConstantsRepository;
	@Inject
	private ProtocolConstantsMonarchRepository protocolConstantsMonarchRepository;
	
	@Inject
	private PatientProtocolTitanService patientProtocolTitanService;
	
	@Value( "${portal.application.database.lag}" )
    private String isDBLag;
	
	private Boolean isDeviated(Integer current, Integer min, Integer max)
	{
		if(min == max) {
			return !(current==max);
		}
		return !(current >=min && current<=max);
	}
	
	public DeviceProtocolSessionVO getProtocolSessionDetailsVest(String patientId, Long startTime, Long endTime, String timeZone, List<PatientProtocolData>  protocolList, ProtocolConstants pc, MutableBoolean flag, MutableLong hmr, MutableLong duration) {		
		DeviceProtocolSessionVO dpsVO = new DeviceProtocolSessionVO();
		String DEVICE_DATA_QUERY="select  		\r\n" + 
				"		convert_tz(from_unixtime(timestamp/1000), '-06:00', ':TIMEZONE'),\r\n" + 
				"        event_id,\r\n" + 
				"        frequency,\r\n" + 
				"        pressure,\r\n" + 
				"        duration,\r\n" + 
				"        hmr\r\n" +
				"	from\r\n" + 
				"		PATIENT_VEST_DEVICE_DATA where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";
		
		//Protocol data
		List<PatientProtocolData> ppdDefault = new ArrayList<>();
		List<PatientProtocolData> protocolToCompare = new ArrayList<>();
		PatientProtocolData ppdDefaultValue = new PatientProtocolData();
		ppdDefaultValue.setMinPressure(pc.getMinPressure());
		ppdDefaultValue.setMaxPressure(pc.getMaxPressure());
		ppdDefaultValue.setMinFrequency(pc.getMinFrequency());
		ppdDefaultValue.setMaxFrequency(pc.getMaxFrequency());
		ppdDefaultValue.setMinMinutesPerTreatment(pc.getMinMinutesPerTreatment());
		ppdDefault.add(ppdDefaultValue);
		
		// Device Data
		List<TherapySessionVO> tsVOList = dpsVO.getSessions();
		if(Objects.isNull(tsVOList)) {
			tsVOList = new ArrayList<>();
		}
		
		boolean protocolFound = false;
		for (PatientProtocolData ppd : protocolList) {
			if (patientProtocolService.isProtocolValidForDate(ppd, startTime)) { 
				if (ppd.getType().equals("Custom")) {
					protocolToCompare.clear();
					protocolFound = true;
					protocolToCompare.addAll(patientProtocolRepository.findByProtocolKey(ppd.getProtocolKey()));
					break;
				} else if(ppd.getType().equals("Normal")) {
					protocolToCompare.clear();
					protocolToCompare.addAll(patientProtocolRepository.findByProtocolKey(ppd.getProtocolKey()));
					protocolFound = true;
					break;
				}
			}
		}
			
		if(!protocolFound) {
			protocolToCompare.addAll(ppdDefault);
		}
		
		if(isDBLag.equalsIgnoreCase("true")) { 
			 startTime = startTime - 3600000L;
			 endTime = endTime - 3600000L; 
		}

		String finalQuery = DEVICE_DATA_QUERY;
		finalQuery = finalQuery.replace(":PATIENT_ID", patientId);
		finalQuery = finalQuery.replace(":START_TIME", startTime.toString());
		finalQuery = finalQuery.replace(":END_TIME", endTime.toString());
		finalQuery = finalQuery.replace(":TIMEZONE", timeZone);
		log.debug(finalQuery);
		Query query = entityManager.createNativeQuery(finalQuery);
		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();

	
		if(results.size() > 0) {
			Object[] res = results.get(0);
			TherapySessionVO tsVO = new TherapySessionVO();
				
			String eventCodeStr = res[1].toString();
			if (StringUtils.isNotBlank(eventCodeStr) && (eventCodeStr.contains("SessionEventCodeNormalStarted") || eventCodeStr.contains("SessionEventCodeProgramPt")))
			{
				List<TherapyEventVO> therapyEventsList = new ArrayList<>();
				boolean frequencyDeviated = false;
				boolean pressureDeviated = false;
				int totalDuration = 0;
				int protocolPoint = 0;
				int eventPoint = 0;
				long prevMillis = 0;
				long currMillis = 0;
				boolean timeSet = false;
				for (Object[] record : results) {
					if(!timeSet) {
						timeSet = true;
						tsVO.setTime(new DateTime(record[0]).toString("hh:mm a"));
					}
					eventCodeStr = record[1].toString();
					hmr.setValue(((BigDecimal)record[5]).longValue());
					if (StringUtils.isNotBlank(eventCodeStr) && (eventCodeStr.contains("SessionEventCodeNormalStarted") || eventCodeStr.contains("SessionEventCodeProgramPt")))
					{
						TherapyEventVO teVO = new TherapyEventVO();
						teVO.setFrequency((Integer)record[2]);	// Freq
						teVO.setDuration((Integer)record[4]);	// Duration
						teVO.setPressure((Integer)record[3]);	// Pressure
						currMillis = ((BigDecimal)record[5]).longValue();
	
						if (Objects.nonNull(protocolToCompare) && protocolPoint < protocolToCompare.size() && Objects.nonNull(protocolToCompare.get(protocolPoint))) {
							teVO.setFreq_deviated(isDeviated(teVO.getFrequency(),protocolToCompare.get(protocolPoint).getMinFrequency(),protocolToCompare.get(protocolPoint).getMaxFrequency()));
							teVO.setDur_deviated(teVO.getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
							teVO.setPress_deviated(isDeviated(teVO.getPressure(),protocolToCompare.get(protocolPoint).getMinPressure(),protocolToCompare.get(protocolPoint).getMaxPressure()));
							frequencyDeviated |= teVO.isFreq_deviated();
							pressureDeviated |= teVO.isPress_deviated();
						}else {
							teVO.setFreq_deviated(false);
							teVO.setDur_deviated(false);
							teVO.setFreq_deviated(false);
							frequencyDeviated |= teVO.isFreq_deviated();
							pressureDeviated |= teVO.isPress_deviated();										
						}

						if(eventPoint > 0) {
							long tmpDuration = Math.round((currMillis-prevMillis)/60);
							totalDuration += tmpDuration;
							therapyEventsList.get(eventPoint-1).setDuration(tmpDuration);
							if ( protocolPoint < protocolToCompare.size() ) {
								if(protocolPoint != 0) {
									therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint-1).getMinMinutesPerTreatment() ? false : true);
								}
								else {
									therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
								}
							}
						}
						therapyEventsList.add(teVO);
						prevMillis = currMillis;
						if(protocolPoint+1 < protocolToCompare.size()) {
							protocolPoint++;
						}
						eventPoint++;
					}else {					
						if (StringUtils.isNotBlank(eventCodeStr) && (
								eventCodeStr.contains("SessionEventCodeCompleted") 
								|| eventCodeStr.contains("SessionEventCodeNormalIncomplete")
								|| eventCodeStr.contains("SessionEventCodeProgramCompleted")
								|| eventCodeStr.contains("SessionEventCodeProgramIncomplete")
							)) {
							currMillis = ((BigDecimal)record[5]).longValue();
							if(eventPoint > 0) {
								long tmpDuration = Math.round((currMillis-prevMillis)/60);
								totalDuration += tmpDuration;
								therapyEventsList.get(eventPoint-1).setDuration(tmpDuration);
								if ( protocolPoint < protocolToCompare.size() ) {
									if(protocolPoint != 0) {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint-1).getMinMinutesPerTreatment() ? false : true);
									}
									else {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
									}
								}
							}
						}
					}
				}
				
				int ppdListDuration = 0;
				for (PatientProtocolData ppdDur : protocolToCompare) {
					ppdListDuration += ppdDur.getMinMinutesPerTreatment();
				}
				
				if(frequencyDeviated || pressureDeviated)
				{
					flag.setValue(false);
				}
				
				if(totalDuration < ppdListDuration) {
					flag.setValue(false);
					tsVO.setDeviated(true);
				}

				duration.setValue(totalDuration);
				tsVO.setTherapyEvents(therapyEventsList);
				tsVO.setDuration(totalDuration);
				tsVO.setDevice(VEST);
			}
			tsVOList.add(tsVO);
			dpsVO.setSessions(tsVOList);
		}
		return dpsVO;
	}
	
	public DeviceProtocolSessionVO getProtocolSessionDetailsMonarch(String patientId, Long startTime, Long endTime, String timeZone, List<PatientProtocolDataMonarch>  protocolList,ProtocolConstantsMonarch pc, MutableBoolean flag, MutableLong hmr, MutableLong duration) {		
		DeviceProtocolSessionVO dpsVO = new DeviceProtocolSessionVO();
		String DEVICE_DATA_QUERY="select  		\r\n" + 
				"		convert_tz(from_unixtime(timestamp/1000), '-00:00', ':TIMEZONE'),\r\n" + 
				"        event_code,\r\n" + 
				"        frequency,\r\n" + 
				"        intensity,\r\n" + 
				"        duration,\r\n" +
				"        hmr,\r\n" +
				"        timestamp\r\n" +
				"	from\r\n" + 
				"		PATIENT_VEST_DEVICE_DATA_MONARCH where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";
		
		//Protocol data
		List<PatientProtocolDataMonarch> ppdDefault = new ArrayList<>();
		List<PatientProtocolDataMonarch> protocolToCompare = new ArrayList<>();
		PatientProtocolDataMonarch ppdDefaultValue = new PatientProtocolDataMonarch();
		ppdDefaultValue.setMinIntensity(pc.getMinIntensity());
		ppdDefaultValue.setMaxIntensity(pc.getMaxIntensity());
		ppdDefaultValue.setMinFrequency(pc.getMinFrequency());
		ppdDefaultValue.setMaxFrequency(pc.getMaxFrequency());
		ppdDefaultValue.setMinMinutesPerTreatment(pc.getMinMinutesPerTreatment());
		ppdDefault.add(ppdDefaultValue);
		
		// Device Data
		List<TherapySessionVO> tsVOList = dpsVO.getSessions();
		if(Objects.isNull(tsVOList)) {
			tsVOList = new ArrayList<>();
		}
		
		boolean protocolFound = false;
		for (PatientProtocolDataMonarch ppd : protocolList) {
			if (patientProtocolMonarchService.isProtocolValidForDate(ppd, startTime)) { 
				if (ppd.getType().equals("Custom")) {
					protocolToCompare.clear();
					protocolFound = true;
					protocolToCompare.addAll(patientProtocolMonarchRepository.findByProtocolKey(ppd.getProtocolKey()));
					break;
				} else if(ppd.getType().equals("Normal")) {
					protocolToCompare.clear();
					protocolToCompare.addAll(patientProtocolMonarchRepository.findByProtocolKey(ppd.getProtocolKey()));
					protocolFound = true;
					break;
				}
			}
		}
			
		if(!protocolFound) {
			protocolToCompare.addAll(ppdDefault);
		}

		if(isDBLag.equalsIgnoreCase("true")) {
			startTime = startTime - 3600000L;
			endTime = endTime - 3600000L;
		}
		
		String finalQuery = DEVICE_DATA_QUERY;
		finalQuery = finalQuery.replace(":PATIENT_ID", patientId);
		finalQuery = finalQuery.replace(":START_TIME", startTime.toString());
		finalQuery = finalQuery.replace(":END_TIME", endTime.toString());
		finalQuery = finalQuery.replace(":TIMEZONE", "+00:00");
		log.debug(finalQuery);
		Query query = entityManager.createNativeQuery(finalQuery);
		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();

	
		if(results.size() > 0) {
			Object[] res = results.get(0);
			TherapySessionVO tsVO = new TherapySessionVO();
			String eventCodeStr = PatientVestDeviceTherapyUtilMonarch.getEventStringByEventCode(res[1].toString());
			if (eventCodeStr.equalsIgnoreCase("Started"))
			{
				List<TherapyEventVO> therapyEventsList = new ArrayList<>();
				boolean frequencyDeviated = false;
				boolean pressureDeviated = false;
				int totalDuration = 0;
				int protocolPoint = 0;
				int eventPoint = 0;
				long prevMillis = 0;
				long currMillis = 0;

				boolean manualPauseStart = false;
				long manualPauseStartMills = 0;
				long manualDurMillis = 0;
				
				boolean programPauseStart = false;				
				long programPauseStartMills = 0;
				long programDurMillis = 0;
				
				boolean coughPauseStart = false;				
				long coughPauseStartMills = 0;
				long coughDurMillis = 0;

				
				boolean timeSet = false;
				for (Object[] record : results) {
					eventCodeStr = PatientVestDeviceTherapyUtilMonarch.getEventStringByEventCode(record[1].toString());
					hmr.setValue(((BigDecimal)record[5]).longValue());	
					if(!timeSet) {
						timeSet = true;
						tsVO.setTime(new DateTime(record[0]).toString("hh:mm a"));
					}

					if (StringUtils.isNotBlank(eventCodeStr) ) {
						if ( eventCodeStr.equalsIgnoreCase("Started"))
						{							
							coughDurMillis = 0;
							TherapyEventVO teVO = new TherapyEventVO();
							teVO.setFrequency((Integer)record[2]);	// Freq
							teVO.setDuration((Integer)record[4]);	// Duration
							teVO.setPressure((Integer)record[3]);	// Pressure
							currMillis = ((BigInteger)record[6]).longValue();
		
							totalDuration += teVO.getDuration();
							
							if (Objects.nonNull(protocolToCompare) && protocolPoint < protocolToCompare.size() && Objects.nonNull(protocolToCompare.get(protocolPoint))) {
								teVO.setFreq_deviated(isDeviated(teVO.getFrequency(),protocolToCompare.get(protocolPoint).getMinFrequency(),protocolToCompare.get(protocolPoint).getMaxFrequency()));
								teVO.setDur_deviated(teVO.getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
								teVO.setPress_deviated(isDeviated(teVO.getPressure(),protocolToCompare.get(protocolPoint).getMinIntensity(),protocolToCompare.get(protocolPoint).getMaxIntensity()));
								frequencyDeviated |= teVO.isFreq_deviated();
								pressureDeviated |= teVO.isPress_deviated();
							}else {
								teVO.setFreq_deviated(false);
								teVO.setDur_deviated(false);
								teVO.setFreq_deviated(false);
								frequencyDeviated |= teVO.isFreq_deviated();
								pressureDeviated |= teVO.isPress_deviated();										
							}
							therapyEventsList.add(teVO);
							prevMillis = currMillis;
							manualDurMillis = 0;
							programDurMillis = 0;
							coughDurMillis = 0;
							if(protocolPoint+1 < protocolToCompare.size()) {
								protocolPoint++;
							}
							eventPoint++;
						}else if(eventCodeStr.equalsIgnoreCase("ManualPause")){
							currMillis = ((BigInteger)record[6]).longValue();
							manualPauseStartMills = currMillis;
							manualPauseStart = true;
						}else if(eventCodeStr.equalsIgnoreCase("ManualResume")){
							if(manualPauseStart) {
								currMillis = ((BigInteger)record[6]).longValue();
								manualDurMillis += currMillis - manualPauseStartMills;
								manualPauseStart = false;
							}
						}else if(eventCodeStr.equalsIgnoreCase("ProgramPause")){
							currMillis = ((BigInteger)record[6]).longValue();
							programPauseStartMills = currMillis;
							programPauseStart = true;
						}else if(eventCodeStr.equalsIgnoreCase("ProgramResume")){
							if(programPauseStart) {
								currMillis = ((BigInteger)record[6]).longValue();
								programDurMillis += currMillis - programPauseStartMills;
								programPauseStart = false;
							}
						}else if(eventCodeStr.equalsIgnoreCase("CoughPause")){
							currMillis = ((BigInteger)record[6]).longValue();
							coughPauseStartMills = currMillis;
							coughPauseStart = true;
						}else if(eventCodeStr.equalsIgnoreCase("CoughResume")){
							if(coughPauseStart) {
								currMillis = ((BigInteger)record[6]).longValue();
								coughDurMillis += currMillis - coughPauseStartMills;
								coughPauseStart = false;
							}
						}else if (eventCodeStr.equalsIgnoreCase("Completed") || eventCodeStr.equalsIgnoreCase("Incomplete")) {
							currMillis = ((BigInteger)record[6]).longValue();
							
							if(coughPauseStart) {
								coughDurMillis += (currMillis-coughPauseStartMills);
							}
							
							if(manualPauseStart) {
								manualDurMillis += (currMillis-manualPauseStartMills);
							}
							
							if(programPauseStart) {
								programDurMillis += (currMillis-programPauseStartMills);
							}
							if(eventPoint > 0) {
								long tmpDuration = ((currMillis-prevMillis)-coughDurMillis-programDurMillis-manualDurMillis)/60000;
								tmpDuration += ((((currMillis-prevMillis)-coughDurMillis-programDurMillis-manualDurMillis)%60000)>50000)?1:0;
								totalDuration += (tmpDuration - therapyEventsList.get(eventPoint-1).getDuration());
								therapyEventsList.get(eventPoint-1).setDuration(tmpDuration);
								if ( protocolPoint < protocolToCompare.size() ) {
									if(protocolPoint != 0) {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint-1).getMinMinutesPerTreatment() ? false : true);
									}
									else {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
									}
								}
							}
						}
					}
				}
				
				int ppdListDuration = 0;
				for (PatientProtocolDataMonarch ppdDur : protocolToCompare) {
					ppdListDuration += ppdDur.getMinMinutesPerTreatment();
				}
				
				if(frequencyDeviated || pressureDeviated)
				{
					flag.setValue(false);
				}
				
				if(totalDuration < ppdListDuration) {
					flag.setValue(false);
					tsVO.setDeviated(true);
				}
				duration.setValue(totalDuration);
				tsVO.setTherapyEvents(therapyEventsList);
				tsVO.setDuration(totalDuration);
				tsVO.setDevice(MONARCH);
			}
			tsVOList.add(tsVO);
			dpsVO.setSessions(tsVOList);
		}
		return dpsVO;
	}

	public DeviceProtocolSessionVO getProtocolSessionDetailsTitan(String patientId, Long startTime, Long endTime, String timeZone, List<PatientProtocolDataTitan>  protocolList,ProtocolConstantsTitan pc, MutableBoolean flag, MutableLong hmr, int duration) {		
		DeviceProtocolSessionVO dpsVO = new DeviceProtocolSessionVO();
		String DEVICE_DATA_QUERY="select  		\r\n" + 
				"		convert_tz(from_unixtime(timestamp/1000), '-00:00', ':TIMEZONE'),\r\n" + 
				"        event_code,\r\n" + 
				"        frequency,\r\n" + 
				"        intensity,\r\n" + 
				"        duration,\r\n" +
				"        hmr,\r\n" +
				"        timestamp\r\n" +
				"	from\r\n" + 
				"		PATIENT_VEST_DEVICE_DATA_TITAN where patient_id=':PATIENT_ID' and timestamp >= :START_TIME and timestamp <= :END_TIME";
		
		//Protocol data
		List<PatientProtocolDataTitan> ppdDefault = new ArrayList<>();
		List<PatientProtocolDataTitan> protocolToCompare = new ArrayList<>();
		PatientProtocolDataTitan ppdDefaultValue = new PatientProtocolDataTitan();
		ppdDefaultValue.setMinIntensity(pc.getMinIntensity());
		ppdDefaultValue.setMaxIntensity(pc.getMaxIntensity());
		ppdDefaultValue.setMinFrequency(pc.getMinFrequency());
		ppdDefaultValue.setMaxFrequency(pc.getMaxFrequency());
		ppdDefaultValue.setMinMinutesPerTreatment(pc.getMinMinutesPerTreatment());
		ppdDefault.add(ppdDefaultValue);
		
		// Device Data
		List<TherapySessionVO> tsVOList = dpsVO.getSessions();
		if(Objects.isNull(tsVOList)) {
			tsVOList = new ArrayList<>();
		}
		
		boolean protocolFound = false;
		for (PatientProtocolDataTitan ppd : protocolList) {
			if (patientProtocolTitanService.isProtocolValidForDate(ppd, startTime)) { 
				if (ppd.getType().equals("Custom")) {
					protocolToCompare.clear();
					protocolFound = true;
					protocolToCompare.addAll(patientProtocolTitanRepository.findByProtocolKey(ppd.getProtocolKey()));
					break;
				} else if(ppd.getType().equals("Normal")) {
					protocolToCompare.clear();
					protocolToCompare.addAll(patientProtocolTitanRepository.findByProtocolKey(ppd.getProtocolKey()));
					protocolFound = true;
					break;
				}
			}
		}
			
		if(!protocolFound) {
			protocolToCompare.addAll(ppdDefault);
		}

		if(isDBLag.equalsIgnoreCase("true")) {
			startTime = startTime - 3600000L;
			endTime = endTime - 3600000L;
		}
		
		String finalQuery = DEVICE_DATA_QUERY;
		finalQuery = finalQuery.replace(":PATIENT_ID", patientId);
		finalQuery = finalQuery.replace(":START_TIME", startTime.toString());
		finalQuery = finalQuery.replace(":END_TIME", endTime.toString());
		finalQuery = finalQuery.replace(":TIMEZONE", "+00:00");
		log.debug(finalQuery);
		Query query = entityManager.createNativeQuery(finalQuery);
		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();

	
		if(results.size() > 0) {
			Object[] res = results.get(0);
			TherapySessionVO tsVO = new TherapySessionVO();
			String eventCodeStr = PatientVestDeviceTherapyUtilTitan.getEventStringByEventCode(res[1].toString());
			if (eventCodeStr.equalsIgnoreCase("User starts therapy"))
			{
				List<TherapyEventVO> therapyEventsList = new ArrayList<>();
				boolean frequencyDeviated = false;
				boolean intensityDeviated = false;
				int totalDuration = 0;
				int protocolPoint = 0;
				int eventPoint = 0;
				long prevMillis = 0;
				long currMillis = 0;
				
				boolean PauseStart = false;				
				long PauseStartMills = 0;
				long DurMillis = 0;
				
				boolean coughPauseStart = false;				
				long coughPauseStartMills = 0;
				long coughDurMillis = 0;

				
				boolean timeSet = false;
				for (Object[] record : results) {
					eventCodeStr = PatientVestDeviceTherapyUtilTitan.getEventStringByEventCode(record[1].toString());
					hmr.setValue(((BigDecimal)record[5]).longValue());	
					if(!timeSet) {
						timeSet = true;
						tsVO.setTime(new DateTime(record[0]).toString("hh:mm a"));
					}

					if (StringUtils.isNotBlank(eventCodeStr) ) {
						if ( eventCodeStr.equalsIgnoreCase("User starts therapy"))
						{							
							coughDurMillis = 0;
							TherapyEventVO teVO = new TherapyEventVO();
							teVO.setFrequency((Integer)record[2]);	// Freq
							teVO.setDuration(duration);	// Duration
							teVO.setIntensity((Integer)record[3]);	// Intensity
							currMillis = ((BigInteger)record[6]).longValue();
							
							totalDuration += teVO.getDuration();
							log.debug("totalDuration titan:"+totalDuration);
							
							if (Objects.nonNull(protocolToCompare) && protocolPoint < protocolToCompare.size() && Objects.nonNull(protocolToCompare.get(protocolPoint))) {
								teVO.setFreq_deviated(isDeviated(teVO.getFrequency(),protocolToCompare.get(protocolPoint).getMinFrequency(),protocolToCompare.get(protocolPoint).getMaxFrequency()));
								teVO.setDur_deviated(teVO.getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
								teVO.setIntensity_deviated(isDeviated(teVO.getIntensity(),protocolToCompare.get(protocolPoint).getMinIntensity(),protocolToCompare.get(protocolPoint).getMaxIntensity()));
								frequencyDeviated |= teVO.isFreq_deviated();
								intensityDeviated |= teVO.isIntensity_deviated();
							}else {
								teVO.setFreq_deviated(false);
								teVO.setDur_deviated(false);
								teVO.setFreq_deviated(false);
								frequencyDeviated |= teVO.isFreq_deviated();
								intensityDeviated |= teVO.isIntensity_deviated();										
							}
							therapyEventsList.add(teVO);
							prevMillis = currMillis;
							coughDurMillis = 0;
							if(protocolPoint+1 < protocolToCompare.size()) {
								protocolPoint++;
							}
							eventPoint++;
						}else if(eventCodeStr.equalsIgnoreCase("User pauses the therapy")){
							currMillis = ((BigInteger)record[6]).longValue();
							PauseStartMills = currMillis;
							PauseStart = true;
						}else if(eventCodeStr.equalsIgnoreCase("User resumes the therapy")){
							if(PauseStart) {
								currMillis = ((BigInteger)record[6]).longValue();
								DurMillis += currMillis - PauseStartMills;
								PauseStart = false;
							}
						}else if(eventCodeStr.equalsIgnoreCase("Cough Pause done. Therapy Pause activated")){
							currMillis = ((BigInteger)record[6]).longValue();
							coughPauseStartMills = currMillis;
							coughPauseStart = true;
						}else if(eventCodeStr.equalsIgnoreCase("Cough Pause is activated")){
							if(coughPauseStart) {
								currMillis = ((BigInteger)record[6]).longValue();
								coughDurMillis += currMillis - coughPauseStartMills;
								coughPauseStart = false;
							}
						}else if (eventCodeStr.equalsIgnoreCase("Therapy completed") || eventCodeStr.equalsIgnoreCase("Error was triggered. Therapy cancelled")) {
							currMillis = ((BigInteger)record[6]).longValue();
							
							if(coughPauseStart) {
								coughDurMillis += (currMillis-coughPauseStartMills);
							}
							
							if(PauseStart) {
								DurMillis += (currMillis-PauseStartMills);
							}
							if(eventPoint > 0) {
								long tmpDuration = ((currMillis-prevMillis)-coughDurMillis-DurMillis)/60000;
								tmpDuration += ((((currMillis-prevMillis)-coughDurMillis-DurMillis)%60000)>50000)?1:0;
								totalDuration += (tmpDuration - therapyEventsList.get(eventPoint-1).getDuration());
								therapyEventsList.get(eventPoint-1).setDuration(tmpDuration);
								if ( protocolPoint < protocolToCompare.size() ) {
									if(protocolPoint != 0) {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint-1).getMinMinutesPerTreatment() ? false : true);
									}
									else {
										therapyEventsList.get(eventPoint-1).setDur_deviated(therapyEventsList.get(eventPoint-1).getDuration() >= protocolToCompare.get(protocolPoint).getMinMinutesPerTreatment() ? false : true);
									}
								}
							}
						}
					}
				}
				
				int ppdListDuration = 0;
				for (PatientProtocolDataTitan ppdDur : protocolToCompare) {
					ppdListDuration += ppdDur.getMinMinutesPerTreatment();
				}
				
				if(frequencyDeviated || intensityDeviated)
				{
					flag.setValue(false);
				}
				
				if(totalDuration < ppdListDuration) {
					flag.setValue(false);
					tsVO.setDeviated(true);
				}
				tsVO.setTherapyEvents(therapyEventsList);
				tsVO.setDuration(totalDuration);
				tsVO.setDevice(TITAN);
			}
			tsVOList.add(tsVO);
			dpsVO.setSessions(tsVOList);
		}
		return dpsVO;
	}
	
	public List<PatientViewInfoTherapyDataVO> getTherapy(String patientId, String timeZone, LocalDate from, LocalDate to, Boolean extendedInfo)
	{

		List<PatientViewInfoTherapyDataVO> patientTherapy = new ArrayList<PatientViewInfoTherapyDataVO>();
		
		String finalQuery = PATIENT_THERAPY_DATA_QUERY;
		finalQuery = finalQuery.replace(":PATIENT_ID", patientId);
		if(Objects.nonNull(timeZone)) {
			finalQuery = finalQuery.replace(":VEST_TIMEZONE", timeZone);
			finalQuery = finalQuery.replace(":MONARCH_TIMEZONE", "+00:00");
			finalQuery = finalQuery.replace(":TITAN_TIMEZONE", "+00:00");
		}else {
			finalQuery = finalQuery.replace(":VEST_TIMEZONE", "-06:00");
			finalQuery = finalQuery.replace(":MONARCH_TIMEZONE", "+00:00");	
			finalQuery = finalQuery.replace(":TITAN_TIMEZONE", "+00:00");			
		}
		finalQuery = finalQuery.replace(":FROM", from.toString());
		finalQuery = finalQuery.replace(":TO", to.toString());
		log.debug(finalQuery);
		Query query = entityManager.createNativeQuery(finalQuery);
		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();

		MutableBoolean flag = new MutableBoolean(false);
		MutableLong hmrFromDev = new MutableLong(0);
		MutableLong durFromDev = new MutableLong(0);

		to = to.plusDays(1);
		LocalDate currDate = from;
		Map<LocalDate, List<PatientViewInfoTherapyDataVO>> monarchTherapyList = null;
		Map<LocalDate, List<PatientViewInfoTherapyDataVO>> vestTherapyList = null;
		Map<LocalDate, List<PatientViewInfoTherapyDataVO>> titanTherapyList = null; 
		
		// Get List of Devices
		List<PatientVestDeviceHistory> vestDevices = patientVestDeviceRepository.findByPatientId(patientId);
		List<PatientVestDeviceHistoryMonarch> monarchDevices = patientMonarchDeviceRepository.findByPatientId(patientId);		
		List<PatientVestDeviceHistoryTitan> titanDevices = patientTitanDeviceRepository.findByPatientId(patientId);		
		
		List<PatientProtocolData>  protocolListVest = patientProtocolRepository.findByPatientIdOrderByCreatedDateAsc(patientId);
		ProtocolConstants pcVest = protocolConstantsRepository.findOne(1L);

		List<PatientProtocolDataMonarch>  protocolListMonarch = patientProtocolMonarchRepository.findByPatientIdOrderByCreatedDateAsc(patientId);
		ProtocolConstantsMonarch pcMonarch = protocolConstantsMonarchRepository.findOne(1L);

		List<PatientProtocolDataTitan>  protocolListTitan = patientProtocolTitanRepository.findByPatientIdOrderByCreatedDateAsc(patientId);
		ProtocolConstantsTitan pcTitan = protocolConstantsTitanRepository.findOne(1L);

		String deviceType = "";
		DeviceProtocolSessionVO deviceProtocolSessionVO = null;
		
		while(currDate.isBefore(to)) {
			if(Objects.nonNull(vestDevices) && vestDevices.size() > 0) {
				if(Objects.isNull(vestTherapyList)) {
					vestTherapyList = new HashMap<LocalDate,List<PatientViewInfoTherapyDataVO>>();
				}
				vestTherapyList.put(currDate,null);
			}
			
			if(Objects.nonNull(monarchDevices) && monarchDevices.size() > 0) {
				if(Objects.isNull(monarchTherapyList)) {
					monarchTherapyList = new HashMap<LocalDate,List<PatientViewInfoTherapyDataVO>>();
				}
				monarchTherapyList.put(currDate,null);

			}if(Objects.nonNull(titanDevices) && titanDevices.size() > 0) {
				if(Objects.isNull(titanTherapyList)) {
					titanTherapyList = new HashMap<LocalDate,List<PatientViewInfoTherapyDataVO>>();
				}
				titanTherapyList.put(currDate,null);

			}
			currDate = currDate.plusDays(1);
		}
		
		for (Object[] record : results) {
			deviceType = record[0].toString();
			Integer duration = ((BigInteger)record[1]).intValue();
			log.debug("duration from query----->"+duration);
			String dateTime = new DateTime(record[2]).toString("HH:mm:ss");
			String date = record[3].toString();
			currDate = new LocalDate(record[3]);
			String serialNo = record[7].toString();
			flag.setValue(true);
			if(extendedInfo) {
				if(deviceType.equals(Constants.VEST)) {
					deviceProtocolSessionVO = getProtocolSessionDetailsVest(patientId, ((BigInteger)record[4]).longValue()*1000, ((BigInteger)record[5]).longValue()*1000, timeZone, protocolListVest, pcVest, flag, hmrFromDev, durFromDev);
				}else if(deviceType.equals(Constants.MONARCH)) {
					deviceProtocolSessionVO = getProtocolSessionDetailsMonarch(patientId, ((BigInteger)record[4]).longValue()*1000, ((BigInteger)record[5]).longValue()*1000, timeZone,protocolListMonarch, pcMonarch, flag, hmrFromDev, durFromDev);
					log.debug("deviceProtocolSessionVO monarch :"+deviceProtocolSessionVO);
				}else if(deviceType.equals(Constants.TITAN)) {
					deviceProtocolSessionVO = getProtocolSessionDetailsTitan(patientId, ((BigInteger)record[4]).longValue()*1000, ((BigInteger)record[5]).longValue()*1000, timeZone,protocolListTitan, pcTitan, flag, hmrFromDev, duration);
					log.debug("deviceProtocolSessionVO titan :"+deviceProtocolSessionVO);
				}
			}
			Long hmr = hmrFromDev.getValue().longValue();
			duration = durFromDev.getValue().intValue() > 0 ? durFromDev.getValue().intValue() : duration.intValue();
			if(deviceType.equals(Constants.TITAN)) {
				duration = ((BigInteger)record[1]).intValue();
			}
			log.debug("duration ----->"+duration);
			String hmrInHrs = hmr/3600 + " Hrs " + (hmr/60)%60 + " Mins";
			PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(duration, deviceType, date, dateTime, false, hmrInHrs, serialNo, deviceProtocolSessionVO);
			therapyData.setIsCompliant((Boolean) flag.getValue());
			
			if(deviceType.equals(Constants.VEST)) {
				if(Objects.nonNull(vestTherapyList) ) {
					if (Objects.isNull(vestTherapyList.get(currDate))) {
						vestTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
					}
					vestTherapyList.get(currDate).add(therapyData);					
				}
			}else if(deviceType.equals(Constants.MONARCH)) {
				if(Objects.nonNull(monarchTherapyList) ) { 
					if ( Objects.isNull(monarchTherapyList.get(currDate))) {
						monarchTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
					}
				
					monarchTherapyList.get(currDate).add(therapyData);
				}
			}else {
				if(Objects.nonNull(titanTherapyList) ) { 
					if ( Objects.isNull(titanTherapyList.get(currDate))) {
						titanTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
					}
				
					titanTherapyList.get(currDate).add(therapyData);
				}
			}
		};

		// Check Vest Data first
		String hmrString = "";
		String serialNo = "";
		if(Objects.nonNull(vestTherapyList) ) {
			currDate = from;
			while(currDate.isBefore(to)) {
				List<PatientViewInfoTherapyDataVO> therapyListForDay = vestTherapyList.get(currDate);
				
				if(Objects.isNull(therapyListForDay)) {
					for(PatientVestDeviceHistory vestDevice: vestDevices) {
						LocalDate tempFrom = currDate;
						LocalDate tempTo = currDate.plusDays(1);
						Boolean match = false;
						if(vestDevice.isActive())
						{
							// From Created date to resDate
							if(Objects.nonNull(vestDevice.getCreatedDate())) {
								if( vestDevice.getCreatedDate().toLocalDate().isBefore(tempTo)) {
									match = true;
								}
							}
						}
						else {
							Interval interval = new Interval(vestDevice.getCreatedDate().toLocalDate().toDateTimeAtStartOfDay(), vestDevice.getLastModifiedDate().toLocalDate().plusDays(1).toDateTimeAtStartOfDay());
							if(interval.contains(tempFrom.toDateTimeAtStartOfDay())) {
								// From currDate till LastModifiedDate
								match = true;
							}
						}
						
						if(match) {
							if(serialNo.equals(vestDevice.getSerialNumber())) {
								PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.VEST, tempFrom.toString(), null, false, hmrString, vestDevice.getSerialNumber(), null);
								vestTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
								vestTherapyList.get(currDate).add(therapyData);
							}else {
							
								Optional<TherapySession> hmrTherapy = therapySessionRepository.findByPatientIdAndSerialNumberBeforeDate(patientId, vestDevice.getSerialNumber(), tempTo.toString(), timeZone);
								
								if(hmrTherapy.isPresent())
								{
									TherapySession session = hmrTherapy.get();
									hmrFromDev.setValue(0);
									deviceProtocolSessionVO = getProtocolSessionDetailsVest(patientId, session.getStartTime().getMillis(), session.getEndTime().getMillis(), timeZone, protocolListVest, pcVest, flag, hmrFromDev, durFromDev);
									String hmrInHrsTemp = hmrFromDev.getValue()/3600 + " Hrs " + (hmrFromDev.getValue()/60)%60 + " Mins";
									PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.VEST, tempFrom.toString(), null, false, hmrInHrsTemp, vestDevice.getSerialNumber(), null);
									vestTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
									vestTherapyList.get(currDate).add(therapyData);
									hmrString = hmrInHrsTemp;
									serialNo = vestDevice.getSerialNumber();
								}
							}
							break;
						}
					}
				}else {
					PatientViewInfoTherapyDataVO therapy = therapyListForDay.get(therapyListForDay.size()-1);
					hmrString = therapy.getHmr();
					serialNo = therapy.getSerialNo();
				}
				
				currDate = currDate.plusDays(1);
			}
		}

		// Check Monarch Data first
		hmrString = "";
		serialNo = "";
		if(Objects.nonNull(monarchTherapyList) ) {
			currDate = from;
			while(currDate.isBefore(to)) {
				List<PatientViewInfoTherapyDataVO> therapyListForDay = monarchTherapyList.get(currDate);
				
				if(Objects.isNull(therapyListForDay)) {
					for(PatientVestDeviceHistoryMonarch monarchDevice: monarchDevices) {
						LocalDate tempFrom = currDate;
						LocalDate tempTo = currDate.plusDays(1);
						Boolean match = false;
						if(monarchDevice.isActive())
						{
							// From Created date to resDate
							if(Objects.nonNull(monarchDevice.getCreatedDate())) {
								if( monarchDevice.getCreatedDate().toLocalDate().isBefore(tempTo)) {
									match = true;
								}
							}
						}
						else {
							Interval interval = new Interval(monarchDevice.getCreatedDate().toLocalDate().toDateTimeAtStartOfDay(), monarchDevice.getLastModifiedDate().toLocalDate().plusDays(1).toDateTimeAtStartOfDay());
							if(interval.contains(tempFrom.toDateTimeAtStartOfDay())) {
								// From currDate till LastModifiedDate
								match = true;
							}
						}
						
						if(match) {
							if(serialNo.equals(monarchDevice.getSerialNumber())) {
								PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.MONARCH, tempFrom.toString(), null, false, hmrString, monarchDevice.getSerialNumber(), null);
								monarchTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
								monarchTherapyList.get(currDate).add(therapyData);
							}else {

								Optional<TherapySessionMonarch> hmrTherapy = therapySessionMonarchRepository.findByPatientIdAndSerialNumberBeforeDate(patientId, monarchDevice.getSerialNumber(), tempTo.toString(), timeZone);
								
								if(hmrTherapy.isPresent())
								{
									TherapySessionMonarch session = hmrTherapy.get();
									hmrFromDev.setValue(0);
									deviceProtocolSessionVO = getProtocolSessionDetailsMonarch(patientId, session.getStartTime().getMillis(), session.getEndTime().getMillis(), timeZone, protocolListMonarch, pcMonarch, flag, hmrFromDev, durFromDev);
									String hmrInHrsTemp = hmrFromDev.getValue()/3600 + " Hrs " + (hmrFromDev.getValue()/60)%60 + " Mins";
									PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.MONARCH, tempFrom.toString(), null, false, hmrInHrsTemp, monarchDevice.getSerialNumber(), null);
									monarchTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
									monarchTherapyList.get(currDate).add(therapyData);
									hmrString = hmrInHrsTemp;
									serialNo = monarchDevice.getSerialNumber();
								}
							}
							break;								
						}
					}
				}else {
					PatientViewInfoTherapyDataVO therapy = therapyListForDay.get(therapyListForDay.size()-1);
					log.debug("monarch therapy :"+therapy);

					hmrString = therapy.getHmr();
					serialNo = therapy.getSerialNo();
				}
				
				currDate = currDate.plusDays(1);
			}
		}
		// Check Titan Data first
		hmrString = "";
		serialNo = "";
		if(Objects.nonNull(titanTherapyList) ) {
			currDate = from;
			while(currDate.isBefore(to)) {
				List<PatientViewInfoTherapyDataVO> therapyListForDay =titanTherapyList.get(currDate);

				if(Objects.isNull(therapyListForDay)) {
					for(PatientVestDeviceHistoryTitan titanDevice: titanDevices) {
						LocalDate tempFrom = currDate;
						LocalDate tempTo = currDate.plusDays(1);
						Boolean match = false;
						if(titanDevice.isActive())
						{
							// From Created date to resDate
							if(Objects.nonNull(titanDevice.getCreatedDate())) {
								if( titanDevice.getCreatedDate().toLocalDate().isBefore(tempTo)) {
									match = true;
								}
							}
						}
						else {
							Interval interval = new Interval(titanDevice.getCreatedDate().toLocalDate().toDateTimeAtStartOfDay(), titanDevice.getLastModifiedDate().toLocalDate().plusDays(1).toDateTimeAtStartOfDay());
							if(interval.contains(tempFrom.toDateTimeAtStartOfDay())) {
								// From currDate till LastModifiedDate
								match = true;
							}
						}

						if(match) {
							if(serialNo.equals(titanDevice.getSerialNumber())) {
								PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.TITAN, tempFrom.toString(), null, false, hmrString, titanDevice.getSerialNumber(), null);
								titanTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
								titanTherapyList.get(currDate).add(therapyData);
							}else {

								Optional<TherapySessionTitan> hmrTherapy = therapySessionTitanRepository.findByPatientIdAndSerialNumberBeforeDate(patientId, titanDevice.getSerialNumber(), tempTo.toString(), timeZone);

								if(hmrTherapy.isPresent())
								{
									TherapySessionTitan session = hmrTherapy.get();
									hmrFromDev.setValue(0);
									String hmrInHrsTemp = hmrFromDev.getValue()/3600 + " Hrs " + (hmrFromDev.getValue()/60)%60 + " Mins";
									PatientViewInfoTherapyDataVO therapyData = new PatientViewInfoTherapyDataVO(0, Constants.TITAN, tempFrom.toString(), null, false, hmrInHrsTemp, titanDevice.getSerialNumber(), null);
									titanTherapyList.put(currDate,new ArrayList<PatientViewInfoTherapyDataVO>());
									titanTherapyList.get(currDate).add(therapyData);
									hmrString = hmrInHrsTemp;
									serialNo = titanDevice.getSerialNumber();
								}
							}
							break;								
						}
					}
				}else {
					PatientViewInfoTherapyDataVO therapy = therapyListForDay.get(therapyListForDay.size()-1);
					log.debug("titan therapy :"+therapy);

					hmrString = therapy.getHmr();
					serialNo = therapy.getSerialNo();
				}

				currDate = currDate.plusDays(1);
			}
		}
		// Merge Both
		currDate = from;
		while(currDate.isBefore(to)) {
			if(Objects.nonNull(vestTherapyList) && Objects.nonNull(vestTherapyList.get(currDate))){
				patientTherapy.addAll(vestTherapyList.get(currDate));
			}
			
			if(Objects.nonNull(monarchTherapyList) && Objects.nonNull(monarchTherapyList.get(currDate))){
				patientTherapy.addAll(monarchTherapyList.get(currDate));
				log.debug("monarch final patientTherapy -->"+patientTherapy);
			}
			if(Objects.nonNull(titanTherapyList) && Objects.nonNull(titanTherapyList.get(currDate))){
				patientTherapy.addAll(titanTherapyList.get(currDate));
				log.debug("titan final patientTherapy -->"+patientTherapy);

			}
			currDate = currDate.plusDays(1);
		}
		return patientTherapy;	
	}
}
