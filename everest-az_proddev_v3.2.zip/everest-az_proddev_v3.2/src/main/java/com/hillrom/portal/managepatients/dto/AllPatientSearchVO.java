package com.hillrom.portal.managepatients.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AllPatientSearchVO{
	String firstName;
	String middleName;
	String lastName;
	String hrID;
	String userID;
	String patientID;
	@JsonIgnore
	String clinics;
	List<String> clinicName;
	boolean isNew;
	Long lastTrans;
	Long firstTrans;
	boolean never;
	boolean stop;
	boolean active;
	String reason;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getHrID() {
		return hrID;
	}
	public void setHrID(String hrID) {
		this.hrID = hrID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getPatientID() {
		return patientID;
	}
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}
	public List<String> getClinicName() {
		return clinicName;
	}
	public void setClinicName(List<String> clinicName) {
		this.clinicName = clinicName;
	}
	public String getClinics() {
		return clinics;
	}
	public void setClinics(String clinics) {
		this.clinics = clinics;
	}
	public boolean isNew() {
		return isNew;
	}
	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}
	public Long getLastTrans() {
		return lastTrans;
	}
	public void setLastTrans(Long lastTrans) {
		this.lastTrans = lastTrans;
	}
	public boolean isNever() {
		return never;
	}
	public void setNever(boolean never) {
		this.never = never;
	}
	public boolean isStop() {
		return stop;
	}
	public void setStop(boolean stop) {
		this.stop = stop;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean isActive) {
		this.active = isActive;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Long getFirstTrans() {
		return firstTrans;
	}
	public void setFirstTrans(Long firstTrans) {
		this.firstTrans = firstTrans;
	}
	public AllPatientSearchVO(String firstName, String middleName, String lastName, String hrID, String userID,
			String patientID, String clinics, boolean isNew, Long lastTrans, boolean never,
			boolean stop,boolean isActive, String reason) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.hrID = hrID;
		this.userID = userID;
		this.patientID = patientID;
		this.clinics= clinics;
		if(Objects.nonNull(clinics)) {
			List<String> temp = Arrays.asList(clinics.split("\\|"));
			this.clinicName = new ArrayList<String>();
			for (String string : temp) {
				this.clinicName.add(Arrays.asList(string.split("#")).get(0));
			}			 
		}else {
			this.clinicName=null;
		}
		this.isNew = isNew;
		this.lastTrans = lastTrans;
		this.never = never;
		this.stop = stop;
		this.active = isActive;
		this.reason = reason;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result + ((clinicName == null) ? 0 : clinicName.hashCode());
		result = prime * result + ((clinics == null) ? 0 : clinics.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((firstTrans == null) ? 0 : firstTrans.hashCode());
		result = prime * result + ((hrID == null) ? 0 : hrID.hashCode());
		result = prime * result + (isNew ? 1231 : 1237);
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((lastTrans == null) ? 0 : lastTrans.hashCode());
		result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result + (never ? 1231 : 1237);
		result = prime * result + ((patientID == null) ? 0 : patientID.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + (stop ? 1231 : 1237);
		result = prime * result + ((userID == null) ? 0 : userID.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AllPatientSearchVO other = (AllPatientSearchVO) obj;
		if (active != other.active)
			return false;
		if (clinicName == null) {
			if (other.clinicName != null)
				return false;
		} else if (!clinicName.equals(other.clinicName))
			return false;
		if (clinics == null) {
			if (other.clinics != null)
				return false;
		} else if (!clinics.equals(other.clinics))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (firstTrans == null) {
			if (other.firstTrans != null)
				return false;
		} else if (!firstTrans.equals(other.firstTrans))
			return false;
		if (hrID == null) {
			if (other.hrID != null)
				return false;
		} else if (!hrID.equals(other.hrID))
			return false;
		if (isNew != other.isNew)
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (lastTrans == null) {
			if (other.lastTrans != null)
				return false;
		} else if (!lastTrans.equals(other.lastTrans))
			return false;
		if (middleName == null) {
			if (other.middleName != null)
				return false;
		} else if (!middleName.equals(other.middleName))
			return false;
		if (never != other.never)
			return false;
		if (patientID == null) {
			if (other.patientID != null)
				return false;
		} else if (!patientID.equals(other.patientID))
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (stop != other.stop)
			return false;
		if (userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		return true;
	}
}