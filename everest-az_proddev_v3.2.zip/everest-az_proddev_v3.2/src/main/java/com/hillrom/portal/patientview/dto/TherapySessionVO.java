package com.hillrom.portal.patientview.dto;

import java.util.List;

public class TherapySessionVO {
	private List<TherapyEventVO> therapyEvents;
	private String device;
	private String time;
	private long duration;
	private boolean deviated;
	/**
	 * @return the therapyEvents
	 */
	public List<TherapyEventVO> getTherapyEvents() {
		return therapyEvents;
	}
	/**
	 * @param therapyEvents the therapyEvents to set
	 */
	public void setTherapyEvents(List<TherapyEventVO> therapyEvents) {
		this.therapyEvents = therapyEvents;
	}
	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}
	/**
	 * @param device the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the duration
	 */
	public long getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(long duration) {
		this.duration = duration;
	}
	/**
	 * @return the deviated
	 */
	public boolean isDeviated() {
		return deviated;
	}
	/**
	 * @param deviated the deviated to set
	 */
	public void setDeviated(boolean deviated) {
		this.deviated = deviated;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (deviated ? 1231 : 1237);
		result = prime * result + ((device == null) ? 0 : device.hashCode());
		result = prime * result + (int) (duration ^ (duration >>> 32));
		result = prime * result + ((therapyEvents == null) ? 0 : therapyEvents.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TherapySessionVO other = (TherapySessionVO) obj;
		if (deviated != other.deviated)
			return false;
		if (device == null) {
			if (other.device != null)
				return false;
		} else if (!device.equals(other.device))
			return false;
		if (duration != other.duration)
			return false;
		if (therapyEvents == null) {
			if (other.therapyEvents != null)
				return false;
		} else if (!therapyEvents.equals(other.therapyEvents))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TherapySessionVO [therapyEvents=" + therapyEvents + ", device=" + device + ", time=" + time
				+ ", duration=" + duration + ", deviated=" + deviated + "]";
	}

}
