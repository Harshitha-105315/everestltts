package com.hillrom.portal.patientview.rest;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.httpclient.URIException;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.portal.patientview.dto.DaySessionsVO;
import com.hillrom.portal.patientview.dto.DeviceProtocolSessionVO;
import com.hillrom.portal.patientview.dto.DeviceProtocolsVO;
import com.hillrom.portal.patientview.dto.PatientDetailsVO;
import com.hillrom.portal.patientview.dto.PatientSessionStatsVO;
import com.hillrom.portal.patientview.service.PatientSessionStatsService;
import com.hillrom.portal.patientview.service.PatientViewInfoService;
import com.hillrom.portal.patientview.service.PdfConvertorService;
import com.hillrom.vest.security.xauth.TokenProvider;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.web.rest.dto.PatientUserVO;
import com.hillrom.vest.web.rest.util.PaginationUtil;
import com.itextpdf.text.DocumentException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Patient information", description = "Details assoicated to patient: Implemented", tags = { "Patient" })
public class PatientViewInformationResource {
	@Autowired
	PdfConvertorService pdfConvertorService;

	private final Logger log = LoggerFactory.getLogger(PatientViewInformationResource.class);
	
	@Inject
	private PatientSessionStatsService patientSessionStatsService;
	@Inject
	private PatientViewInfoService patientViewInfoService;
	
	@Inject 
	TokenProvider tokenProvider;
	
	@ApiOperation(httpMethod = "GET", value = "patient session wise statistics", response = PatientSessionStatsVO.class)
	@RequestMapping(value = "/patient/view/stats/{user_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getPatientWiseSessionStats(@ApiParam(value = "user_id", required = true, example = "12345") @PathVariable Long user_id,
			@RequestHeader(value="x-auth-token",required=true)String authToken,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to,
    		@RequestParam(value="timeZone",required=false)String timeZone) {
		PatientSessionStatsVO pssVO = null;
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		try {
			pssVO =  patientSessionStatsService.getPatientWiseSessionStats(user_id,from,to, timeZone);
		} catch (Exception e) {
			log.debug(" Exception in getPatientWiseSessionStats " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(pssVO,HttpStatus.OK);
	}
	

	@PostMapping(value = "/patient/view/session_detail/report", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<byte[]> getSessionWiseDeviceDetails(@RequestParam("userId") String userId,
			@RequestParam("startDate") @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from, 
			@RequestParam("endDate") @DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to,
			@RequestParam(value = "timeZone", required = false) String timeZone,
			@Validated @RequestBody PatientDetailsVO patientDetailsVO) throws IOException, ParseException, DocumentException {
		HttpHeaders headers = new HttpHeaders();
		String filename = "daySession.pdf";
		if(Objects.isNull(timeZone)) {
			timeZone = "+05:00";
		}
		headers.setContentDispositionFormData(filename, filename);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		headers.setContentType(MediaType.APPLICATION_PDF);

		byte[] byteArray = pdfConvertorService.createPdf(userId, from, to,timeZone, patientDetailsVO);
		
		return ResponseEntity.ok().headers(headers).body(byteArray);

	}

	@ApiOperation(httpMethod = "GET", value = "get session wise device event details", response = DaySessionsVO.class)
	@RequestMapping(value = "/patient/view/session_detail/{user_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getSessionWiseDeviceDetails(@ApiParam(value = "user_id", required = true, example = "12345") @PathVariable Long user_id,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to,
    		@RequestParam(value = "timeZone", required = false) String timeZone,
			@RequestParam(value = "pageSz", required = true) Integer pageSize,
			@RequestParam(value = "pageNo", required = true) Integer pageNumber,
			@RequestParam(value = "sortOrder", required = true) String sortOrder) {
		Page<DaySessionsVO> page = null;
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		
		if(Objects.isNull(timeZone)) {
			timeZone = "-05:00";
		}

		Long timeFrom = from.toDateTimeAtStartOfDay().withZone(DateTimeZone.forID(timeZone)).getMillis();
		Long timeTo = to.plusDays(1).toDateTimeAtStartOfDay().withZone(DateTimeZone.forID(timeZone)).getMillis();
		
		try {
			page =  patientSessionStatsService.getSessionWiseDeviceDetails(user_id,timeFrom,timeTo,timeZone,PaginationUtil.generatePageRequest(pageNumber, pageSize),sortOrder);
		} catch (Exception e) {
			log.debug(" Exception in getSessionWiseDeviceDetails " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(page,HttpStatus.OK);
	}
	
	@ApiOperation(httpMethod = "GET", value = "get session wise device event details", response = DaySessionsVO.class)
	@RequestMapping(value = "/patient/view/info/{patientUserId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getPatientInfo(@ApiParam(value = "patientUserId", required = true, example = "12345") @PathVariable Long patientUserId,
			@RequestHeader(value="x-auth-token",required=true)String authToken) {
		log.debug("REST request to get PatientUser : {}", patientUserId);
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		Optional<PatientUserVO> patientUser = patientViewInfoService.getPatientUser(patientUserId, userId);
		if(patientUser.isPresent()){
			return new ResponseEntity<>(patientUser.get(),
					HttpStatus.OK);
		}
		else{
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("ERROR",ExceptionConstants.HR_523);
			return new ResponseEntity<>(jsonObject,HttpStatus.NOT_FOUND);
		}
	}	

	@ApiOperation(httpMethod = "GET", value = "get therapy details", response = DaySessionsVO.class)
	@RequestMapping(value = "/patient/view/therapy/{patientUserId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public JSONObject getTherapy(
			@ApiParam(value = "patientUserId", required = true, example = "12345") @PathVariable Long patientUserId,
			@RequestParam(value = "timeZone", required = false) String timeZone,
    		@RequestParam(value="from",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=true)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to,
    		@RequestParam(value="extendedInfo",required=true)Boolean extendedInfo
			) {
		log.debug("REST request to get PatientUser : {}", patientUserId);
		JSONObject object = patientViewInfoService.getTherapy(patientUserId, timeZone, from, to, extendedInfo);
		return object;
	}	

	@ApiOperation(httpMethod = "GET", value = "get patient protocol details", response = DeviceProtocolSessionVO.class)
	@RequestMapping(value = "/patient/view/protocols/{user_id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getPatientProtocols(@ApiParam(value = "user_id", required = true, example = "12345") @PathVariable Long user_id) {
		List<DeviceProtocolsVO> deviceProtocolList = null;
		try {
			deviceProtocolList = patientViewInfoService.getPatientProtocols(user_id);
		} catch (Exception e) {
			e.printStackTrace();
			log.debug(" Exception in getPatientProtocols " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(deviceProtocolList, HttpStatus.OK);
	}
}
