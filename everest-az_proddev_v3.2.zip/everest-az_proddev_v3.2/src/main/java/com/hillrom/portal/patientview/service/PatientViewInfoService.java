package com.hillrom.portal.patientview.service;

import static com.hillrom.vest.config.Constants.MONARCH;
import static com.hillrom.vest.config.Constants.VEST;
import static com.hillrom.vest.config.Constants.TITAN;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.repository.ProtocolConstantsMonarchRepository;
import com.hillrom.monarch.service.PatientComplianceMonarchService;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.portal.managepatients.domain.UserPatientFlagAssoc;
import com.hillrom.portal.managepatients.repository.UserPatientFlagAssocRepository;
import com.hillrom.portal.patientview.dto.DeviceProtocolsVO;
import com.hillrom.portal.patientview.dto.PatientViewInfoTherapyDataVO;
import com.hillrom.portal.patientview.dto.ProtocolPointVO;
import com.hillrom.portal.patientview.dto.ProtocolVO;
import com.hillrom.portal.patientview.repository.PatientViewInformationRepository;
import com.hillrom.titan.repository.PatientProtocolTitanRepository;
import com.hillrom.titan.repository.ProtocolConstantsTitanRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.ClinicPatientAssoc;
import com.hillrom.vest.domain.ClinicUserAssoc;
import com.hillrom.vest.domain.EntityUserAssoc;
import com.hillrom.vest.domain.Note;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.PatientProtocolDataTitan;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.repository.ClinicPatientRepository;
import com.hillrom.vest.repository.ClinicUserRepository;
import com.hillrom.vest.repository.EntityUserRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.ProtocolConstantsRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.NoteService;
import com.hillrom.vest.service.PatientComplianceService;
import com.hillrom.vest.service.PatientInfoService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.PatientVestDeviceService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.util.RelationshipLabelConstants;
import com.hillrom.vest.web.rest.dto.HillromTypeCodeFormatDTO;
import com.hillrom.vest.web.rest.dto.PatientUserVO;
import com.hillrom.titan.service.PatientComplianceTitanService;
import com.hillrom.titan.service.PatientProtocolTitanService;

import net.minidev.json.JSONObject;

@Service
@Transactional
public class PatientViewInfoService {
	@Inject
	UserExtensionRepository userExtensionRepository;
	
	@Inject
	PatientDevicesAssocRepository patientDevicesAssocRepository;
	
	@Inject
	NoteService noteService;
	
	@Inject
	PatientVestDeviceService patientVestDeviceService;
	
    @Inject
	private PatientComplianceService complianceService;
    
    @Inject
    private PatientComplianceMonarchService complianceMonarchService;

	@Inject
    private PatientComplianceTitanService complianceTitanService;
    
    @Inject
    private ClinicPatientRepository clinicPatientRepository;

    @Inject
	private EntityManager entityManager;
    
    @Inject
    UserPatientFlagAssocRepository userPatientFlagAssocRepository;
    
    @Inject
    private EntityUserRepository entityUserRepository;

    @Inject
    private ClinicUserRepository clinicUserRepository;

    @Inject
    private PatientViewInformationRepository patientViewInformationRepository;

	@Inject
	private PatientProtocolService patientProtocolService;

	@Inject
	private PatientProtocolMonarchService patientProtocolMonarchService;
	
	@Inject
	 private PatientProtocolTitanService  patientProtocolTitanService ;
	
    @Inject
    private PatientInfoService patientInfoService;
    
    @Inject
    private UserPatientRepository userPatientRepository;
    
    @Inject
    private PatientProtocolRepository patientProtocolRepository;
    
    @Inject
    private PatientProtocolTitanRepository patientProtocolTitanRepository;
    
    @Inject
    private PatientProtocolMonarchRepository patientProtocolMonarchRepository;

    @Inject
    private ProtocolConstantsRepository protocolConstantsRepository;
    
    @Inject
    private ProtocolConstantsMonarchRepository protocolConstantsMonarchRepository;
    
    @Inject
    private ProtocolConstantsTitanRepository  protocolConstantsTitanRepository;
    
    @Inject
    private UserService userService;

    private static final Logger log = LoggerFactory.getLogger(PatientViewInfoService.class);
    
	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for(UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()){
			if(RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())){
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}
	
	public Optional<PatientUserVO> getPatientUser(Long patientUserId, Long user_id){
		UserExtension user = userExtensionRepository.findOne(patientUserId);
		if(Objects.isNull(user)) {
			return Optional.empty();
		}
		
		PatientInfo patientInfo = getPatientInfoObjFromPatientUser(user);
		if(Objects.isNull(patientInfo)) {
			return Optional.empty();
		}
		
		// Garment changes : Repository call for patient device info 
		List<PatientDevicesAssoc> patientDevicesAssocList = patientDevicesAssocRepository
				.findByPatientIdWithOutActiveStatus(patientInfo.getId());
			
		String deviceType = patientVestDeviceService.getDeviceType(user);
		PatientCompliance compliance =null;
		PatientComplianceMonarch complianceMonarch = null;
		PatientComplianceTitan complianceTitan = null;
		Note memoNote = null;
		memoNote = noteService.findMemoNotesForPatientId(patientUserId, patientInfo.getId());
		

		// Added Objects.isNull(deviceType) for patient before device associated
		if((Objects.nonNull(deviceType) && deviceType.equals(VEST)) || Objects.isNull(deviceType)){
			compliance = complianceService.findLatestComplianceByPatientUserId(patientUserId);
		} else if((Objects.nonNull(deviceType) && deviceType.equals(TITAN))){
			complianceTitan = complianceTitanService.findLatestComplianceByPatientUserId(patientUserId);
		} else {
			complianceMonarch = complianceMonarchService.findLatestComplianceByPatientUserId(patientUserId);
		}
		List<ClinicPatientAssoc> clinicPatientAssocList = null;
		List<EntityUserAssoc> entityUserAssocList = null;
		List<ClinicUserAssoc> clinicUserAssocList = null;
		
		if(SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.CLINIC_ADMIN))) {
			
			entityUserAssocList = entityUserRepository.findByUserIdAndUserRole(user_id, AuthoritiesConstants.CLINIC_ADMIN);
		}else if(SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.ASSOCIATE_EXECUTIVE))){
			entityUserAssocList = entityUserRepository.findByUserIdAndUserRole(user_id, AuthoritiesConstants.ASSOCIATE_EXECUTIVE);
		}else if(SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.HCP))) {
			clinicUserAssocList = clinicUserRepository.findByUserId(user_id);
		}else {
			clinicPatientAssocList = clinicPatientRepository.findOneByPatientId(patientInfo.getId());
		}
		
		if(Objects.isNull(clinicPatientAssocList)) {
			if(Objects.nonNull(entityUserAssocList)) {
				clinicPatientAssocList = new ArrayList<>();
				for (EntityUserAssoc entityUserAssoc : entityUserAssocList) {
					if(Objects.nonNull(entityUserAssoc.getClinic())){
						Optional<ClinicPatientAssoc> tmpClinicPatientAssoc = clinicPatientRepository.findOneByClinicIdAndPatientId(entityUserAssoc.getClinic().getId(), patientInfo.getId());
						
						if(tmpClinicPatientAssoc.isPresent()) {
							clinicPatientAssocList.add(tmpClinicPatientAssoc.get());
						}
					}
				}
			}
			
			if(Objects.nonNull(clinicUserAssocList)) {
				clinicPatientAssocList = new ArrayList<>();
				for (ClinicUserAssoc clinicUserAssoc : clinicUserAssocList) {
					Optional<ClinicPatientAssoc> tmpClinicPatientAssoc = clinicPatientRepository.findOneByClinicIdAndPatientId(clinicUserAssoc.getClinic().getId(), patientInfo.getId());
					
					if(tmpClinicPatientAssoc.isPresent()) {
						clinicPatientAssocList.add(tmpClinicPatientAssoc.get());
					}
				}
			}
		}
		
		PatientUserVO patientUserVO;
		if(Objects.nonNull(deviceType)){
			patientUserVO =  new PatientUserVO(user,patientInfo,deviceType);
			patientUserVO.setEmail(userService.encryptData(patientUserVO.getEmail()));
			// Garment Changes :Looping through the patient devices
			for (PatientDevicesAssoc device : patientDevicesAssocList) {
				List <String> diagnosisList = new ArrayList<String>();
				if(!StringUtils.isEmpty(device.getDiagnosis1()))
					diagnosisList.add(device.getDiagnosis1());
				if(!StringUtils.isEmpty(device.getDiagnosis2()))
					diagnosisList.add(device.getDiagnosis2());
				if(!StringUtils.isEmpty(device.getDiagnosis3()))
					diagnosisList.add(device.getDiagnosis3());
				if(!StringUtils.isEmpty(device.getDiagnosis4()))
					diagnosisList.add(device.getDiagnosis4());
				String  typeCodeDescription ="'" + String.join("','", diagnosisList)+"'";
				String query = QueryConstants.QUERY_PATIENTINFO_DIAGNOSIS_VALUES;
				String orderingOfTypeCodes = "ORDER BY field"+"("+"type_code"+","+typeCodeDescription+")";
				String finalQuery = query +"("+ typeCodeDescription +")"+ orderingOfTypeCodes;
				
				Query nativeQuery = entityManager.createNativeQuery(finalQuery);
				
				List<HillromTypeCodeFormatDTO> codeFormatList = new ArrayList<>();
				@SuppressWarnings("unchecked")
				List<Object[]> results = nativeQuery.getResultList();
				results.stream().forEach((record) -> {
					String type_code = ((String) record[1]);
					String type_code_value = (String) record[2];
					HillromTypeCodeFormatDTO typeCodeListDTO = new HillromTypeCodeFormatDTO(type_code,type_code_value);
					codeFormatList.add(typeCodeListDTO);
				});
				
				if (device.getDeviceType().equals(VEST)) {
					patientUserVO.setVestGarmentColor(device.getGarmentColor());
					patientUserVO.setVestGarmentSize(device.getGarmentSize());
					patientUserVO.setVestGarmentType(device.getGarmentType());
					patientUserVO.setIsManual(device.getIsManual());
					patientUserVO.setDeviceName(device.getName());
					patientUserVO.setVestTypeCodeList(codeFormatList);

					if(Objects.nonNull(compliance) && Objects.nonNull(compliance.getLatestTherapyDate())){
						patientUserVO.setLastTransmissionDate(compliance.getLatestTherapyDate().toDate());
					}
				} else if (device.getDeviceType().equals(MONARCH)) {
					patientUserVO.setMonarchGarmentColor(device
							.getGarmentColor());
					patientUserVO
							.setMonarchGarmentSize(device.getGarmentSize());
					patientUserVO
							.setMonarchGarmentType(device.getGarmentType());
					patientUserVO.setMonrachTypeCodeList(codeFormatList);
					patientUserVO.setIsManual(false);
					patientUserVO.setDeviceName(null);
					 if(Objects.nonNull(complianceMonarch) && Objects.nonNull(complianceMonarch.getLatestTherapyDate())){
						patientUserVO.setLastTransmissionDate(complianceMonarch.getLatestTherapyDate().toDate());
					}
				} else if (device.getDeviceType().equals(TITAN)) {
					patientUserVO.setTitanGarmentColor(device.getGarmentColor());
					patientUserVO.setTitanGarmentSize(device.getGarmentSize());
					patientUserVO.setTitanGarmentType(device.getGarmentType());
					patientUserVO.setIsManual(device.getIsManual());
					patientUserVO.setDeviceName(device.getName());
					patientUserVO.setTitanTypeCodeList(codeFormatList);
					if(Objects.nonNull(complianceTitan) && Objects.nonNull(complianceTitan.getLatestTherapyDate())){
						patientUserVO.setLastTransmissionDate(complianceTitan.getLatestTherapyDate().toDate());
					}
				}
			}
		} else {
			patientUserVO = new PatientUserVO(user, patientInfo);
		}


		patientUserVO.setFirstTrans(patientInfoService.getFirstTransmission(patientInfo.getId()));
		
		if(Objects.nonNull(deviceType) && deviceType.equals(VEST)){
			if(Objects.nonNull(compliance)) {
				patientUserVO.setHoursOfUsage((compliance.getHmr()/(60*60)));
			}
		}
		else if(Objects.nonNull(deviceType)){
			if(Objects.nonNull(complianceMonarch)) {
				patientUserVO.setHoursOfUsage((complianceMonarch.getHmr()/(60*60)));
			}
		}

		String mrnId;
		java.util.Iterator<ClinicPatientAssoc> cpaIterator = clinicPatientAssocList.iterator();
		while(cpaIterator.hasNext()){
			ClinicPatientAssoc clinicPatientAssoc  = cpaIterator.next();
			if(Objects.nonNull(clinicPatientAssoc)){
				Map<String,Object> clinicMRNId = new HashMap<>();
				clinicMRNId.put("clinicId", clinicPatientAssoc.getClinic().getId());
				clinicMRNId.put("mrnId", clinicPatientAssoc.getMrnId());
				clinicMRNId.put("memoNote", (null == memoNote) ? "" : memoNote.getNote());
				if(clinicPatientAssoc.getExpired()){
					clinicMRNId.put("status", Constants.EXPIRED);
				} else if(clinicPatientAssoc.getActive()){
					clinicMRNId.put("status", Constants.ACTIVE);
				} else {
					clinicMRNId.put("status", Constants.INACTIVE);
				}
				mrnId = clinicPatientAssoc.getMrnId(); 
				patientUserVO.setMrnId(mrnId);
				patientUserVO.setClinicMRNId(clinicMRNId);
			}
		}
		
		patientUserVO.setPatient_id(patientInfo.getId());
		if(SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.CLINIC_ADMIN))
				|| SecurityContextHolder.getContext().getAuthentication().getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.HCP))) 
		{
			Optional<UserPatientFlagAssoc> userPatientFlagAssoc = userPatientFlagAssocRepository
					.findOneByPatientIdAndUserId(patientInfo.getId(),user_id);
			if (userPatientFlagAssoc.isPresent()) {
				patientUserVO.setFlagged(userPatientFlagAssoc.get().getFlagged());
			} else {
				patientUserVO.setFlagged(false);
			}
			
		}else {
			Optional<UserPatientFlagAssoc> userPatientFlagAssoc = userPatientFlagAssocRepository
					.findOneByPatientIdAndFlagged(patientInfo.getId());
			if (userPatientFlagAssoc.isPresent()) {
				patientUserVO.setFlagged(true);
			} else {
				patientUserVO.setFlagged(false);
			}
		}
		return Optional.of(patientUserVO);
	}
	
	public JSONObject getTherapy(Long patientUserId, String timeZone,LocalDate from, LocalDate to, Boolean extendedInfo) {
		UserExtension user = userExtensionRepository.findOne(patientUserId);
		if(Objects.isNull(user)) {
			return null;
		}
		
		PatientInfo patientInfo = getPatientInfoObjFromPatientUser(user);
		
		if(Objects.isNull(patientInfo)) {
			return null;
		}
		
		int totalMinutes = 0;
		
		try {
			List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patientInfo.getId());
			if(activeDevices.size()>1) {
				ProtocolConstants vestProtocol = patientProtocolService.getProtocolForPatientUserId(patientUserId);
				ProtocolConstantsMonarch monarchProtocol = patientProtocolMonarchService.getProtocolForPatientUserId(patientUserId);
				ProtocolConstantsTitan titanProtocol = patientProtocolTitanService.getProtocolForPatientUserId(patientUserId);

				int minHMRReading = Objects.nonNull(monarchProtocol
						.getMinDuration()) ? monarchProtocol.getMinDuration()
								: monarchProtocol.getTreatmentsPerDay()
								* monarchProtocol.getMinMinutesPerTreatment();

						// Getting the minimum reading from the vest protocol             
						int minHMRReadingVest = Objects.nonNull(vestProtocol
								.getMinDuration()) ? vestProtocol.getMinDuration()
										: vestProtocol.getTreatmentsPerDay()
										* vestProtocol.getMinMinutesPerTreatment();
								
								int minHMRReadingTitan = Objects.nonNull(titanProtocol
										.getMinDuration()) ? titanProtocol.getMinDuration()
												: titanProtocol.getTreatmentsPerDay()
												* titanProtocol.getMinMinutesPerTreatment();

								// Take the least from both the protocols minimum HMR from Vest and Monarch
								if(minHMRReading > minHMRReadingVest){
									if(minHMRReadingTitan > minHMRReadingVest)
									totalMinutes = vestProtocol.getTreatmentsPerDay() * vestProtocol.getMinMinutesPerTreatment();
								}  else if(minHMRReadingVest > minHMRReading){
									if(minHMRReadingTitan > minHMRReading)
									totalMinutes = monarchProtocol.getTreatmentsPerDay() * monarchProtocol.getMinMinutesPerTreatment();
								}else {
									totalMinutes = titanProtocol.getTreatmentsPerDay() * titanProtocol.getMinMinutesPerTreatment();
									
								}
			} else if(!activeDevices.isEmpty() && activeDevices.get(0).getDeviceType().equalsIgnoreCase("VEST")){
				ProtocolConstants vestProtocol = patientProtocolService.getProtocolForPatientUserId(patientUserId);
				totalMinutes = vestProtocol.getTreatmentsPerDay() * vestProtocol.getMinMinutesPerTreatment();
				
			} else if (!activeDevices.isEmpty() && activeDevices.get(0).getDeviceType().equalsIgnoreCase("MONARCH")){
				ProtocolConstantsMonarch monarchProtocol = patientProtocolMonarchService.getProtocolForPatientUserId(patientUserId);
				totalMinutes = monarchProtocol.getTreatmentsPerDay() * monarchProtocol.getMinMinutesPerTreatment();				
			} else {
				ProtocolConstantsTitan titanProtocol = patientProtocolTitanService.getProtocolForPatientUserId(patientUserId);
				totalMinutes = titanProtocol.getTreatmentsPerDay() * titanProtocol.getMinMinutesPerTreatment();				
			}
		} catch(Exception e) {

		}
	
		JSONObject object = new JSONObject();
		object.put("protocolDuration", totalMinutes);
		List<PatientViewInfoTherapyDataVO> therapy = patientViewInformationRepository.getTherapy(patientInfo.getId(), timeZone, from, to, extendedInfo);
		object.put("therapyData", therapy);

		return object;
	}
	
	public List<DeviceProtocolsVO> getPatientProtocols(Long userId) {
		
		List<DeviceProtocolsVO> deviceProtocols = null;
		List<UserPatientAssoc> upaList = userPatientRepository.findByUserIdAndUserRole(userId, AuthoritiesConstants.PATIENT);
		if(upaList.isEmpty() || upaList.size()>1) {
			return null;
		}
		String treatmentLabel = "";

		// Vest Protocols
		List<PatientProtocolData> ppdList = patientProtocolRepository.findByPatientIdOrderByCreatedDateAsc(upaList.get(0).getPatient().getId());
		if( Objects.nonNull(ppdList) && ppdList.size() > 0) {
			if(Objects.isNull(deviceProtocols))
				deviceProtocols = new ArrayList<>();
			
			DeviceProtocolsVO dpVO = new DeviceProtocolsVO();
			dpVO.setDeviceType(Constants.VEST);
			ProtocolConstants pcc = protocolConstantsRepository.findOne(1L);
			if(Objects.nonNull(pcc)) {
				List<ProtocolPointVO> defaultProtocol = new ArrayList<>();
				defaultProtocol.add(new ProtocolPointVO(pcc.getId().toString(),pcc.getTreatmentsPerDay(),pcc.getMinMinutesPerTreatment(),pcc.getMinFrequency(),
						pcc.getMaxFrequency(),"Normal" ,"Manual" ,pcc.getMinPressure(), pcc.getMaxPressure(), null, null));
				dpVO.setDefaultProtocol(defaultProtocol);
			}
			
			List<ProtocolVO> protocolList = new ArrayList<>();
			
			Map<String,ProtocolVO> protocolMap = new LinkedHashMap<>();
			for (PatientProtocolData ppd : ppdList) {
				ProtocolVO protocol = protocolMap.get(ppd.getProtocolKey());
				if(StringUtils.isNotBlank(ppd.getTreatmentLabel())) {
					treatmentLabel = ppd.getTreatmentLabel();
				} else {
					treatmentLabel = "Manual";
				}
				if (Objects.nonNull(protocol)) {
					List<ProtocolPointVO> protocolPoints = protocol.getPoints();
					protocolPoints.add(new ProtocolPointVO(ppd.getId(),ppd.getTreatmentsPerDay(),ppd.getMinMinutesPerTreatment(),ppd.getMinFrequency(),
							ppd.getMaxFrequency(),ppd.getType(),treatmentLabel,ppd.getMinPressure(), ppd.getMaxPressure(), null, null));
				} else {
					protocol = new ProtocolVO(ppd.getProtocolKey(), !ppd.isDeleted(), ppd.getCreatedDate(), ppd.getLastModifiedDate());
					List<ProtocolPointVO> protocolPoints = new ArrayList<>();
					protocolPoints.add(new ProtocolPointVO(ppd.getId(),ppd.getTreatmentsPerDay(),ppd.getMinMinutesPerTreatment(),ppd.getMinFrequency(),
							ppd.getMaxFrequency(),ppd.getType(), treatmentLabel,ppd.getMinPressure(), ppd.getMaxPressure(), null, null));
					protocol.setPoints(protocolPoints);
					protocolMap.put(protocol.getKey(), protocol);
				}					
			}
			protocolList.addAll(alignProtocolDuration(protocolMap));
			dpVO.setProtocolList(protocolList);
			deviceProtocols.add(dpVO);
		}
		
		//Monarch protocols
		List<PatientProtocolDataMonarch> ppdmList = patientProtocolMonarchRepository.findByPatientIdOrderByCreatedDateAsc(upaList.get(0).getPatient().getId());
		if( Objects.nonNull(ppdmList) && ppdmList.size() > 0) {
			if(Objects.isNull(deviceProtocols))
				deviceProtocols = new ArrayList<>();

			DeviceProtocolsVO dpmVO = new DeviceProtocolsVO();
			dpmVO.setDeviceType(Constants.MONARCH);
			ProtocolConstantsMonarch pccm =  protocolConstantsMonarchRepository.findOne(1L);
			if(Objects.nonNull(pccm)) {
				List<ProtocolPointVO> defaultProtocol = new ArrayList<>();
				defaultProtocol.add(new ProtocolPointVO(pccm.getId().toString(),pccm.getTreatmentsPerDay(),pccm.getMinMinutesPerTreatment(),pccm.getMinFrequency(),
						pccm.getMaxFrequency(),"Normal","Manual",pccm.getMinIntensity(), pccm.getMaxIntensity(), null, null));
				dpmVO.setDefaultProtocol(defaultProtocol);
			}
					
			List<ProtocolVO> protocolList = new ArrayList<>();
			Map<String,ProtocolVO> protocolMap = new LinkedHashMap<>();
			for (PatientProtocolDataMonarch ppdm : ppdmList) {
				ProtocolVO protocol = protocolMap.get(ppdm.getProtocolKey());
				if(StringUtils.isNotBlank(ppdm.getTreatmentLabel())) {
					treatmentLabel = ppdm.getTreatmentLabel();
				} else {
					treatmentLabel = "Manual";
				}
				if (Objects.nonNull(protocol)) {
					List<ProtocolPointVO> protocolPoints = protocol.getPoints();
					protocolPoints.add(new ProtocolPointVO(ppdm.getId(),ppdm.getTreatmentsPerDay(),ppdm.getMinMinutesPerTreatment(),ppdm.getMinFrequency(),
							ppdm.getMaxFrequency(),ppdm.getType(),treatmentLabel,ppdm.getMinIntensity(), ppdm.getMaxIntensity()));
				} else {
					protocol = new ProtocolVO(ppdm.getProtocolKey(), !ppdm.isDeleted(), ppdm.getCreatedDate(), ppdm.getLastModifiedDate());
					List<ProtocolPointVO> protocolPoints = new ArrayList<>();
					protocolPoints.add(new ProtocolPointVO(ppdm.getId(),ppdm.getTreatmentsPerDay(),ppdm.getMinMinutesPerTreatment(),ppdm.getMinFrequency(),
							ppdm.getMaxFrequency(),ppdm.getType(),treatmentLabel,ppdm.getMinIntensity(), ppdm.getMaxIntensity()));
					protocol.setPoints(protocolPoints);
					protocolMap.put(protocol.getKey(), protocol);
				}					
			}
			protocolList.addAll(alignProtocolDuration(protocolMap));
			dpmVO.setProtocolList(protocolList);
			deviceProtocols.add(dpmVO);
		}

		//Titan 
		List<PatientProtocolDataTitan> ppdtList = patientProtocolTitanRepository.findByPatientIdOrderByCreatedDateAsc(upaList.get(0).getPatient().getId());
		if( Objects.nonNull(ppdtList) && ppdtList.size() > 0) {
			if(Objects.isNull(deviceProtocols))
				deviceProtocols = new ArrayList<>();

			DeviceProtocolsVO dptVO = new DeviceProtocolsVO();
			dptVO.setDeviceType(Constants.TITAN);
			ProtocolConstantsTitan pcct =  protocolConstantsTitanRepository.findOne(1L);
			if(Objects.nonNull(pcct)) {
				List<ProtocolPointVO> defaultProtocol = new ArrayList<>();
				defaultProtocol.add(new ProtocolPointVO(pcct.getId().toString(),pcct.getTreatmentsPerDay(),pcct.getMinMinutesPerTreatment(),pcct.getMinFrequency(),
						pcct.getMaxFrequency(),"Normal","Manual",pcct.getMinIntensity(), pcct.getMaxIntensity(), null, null));
				dptVO.setDefaultProtocol(defaultProtocol);
			}
					
			List<ProtocolVO> protocolList = new ArrayList<>();
			Map<String,ProtocolVO> protocolMap = new LinkedHashMap<>();
			for (PatientProtocolDataTitan ppdt : ppdtList) {
				ProtocolVO protocol = protocolMap.get(ppdt.getProtocolKey());
				if(StringUtils.isNotBlank(ppdt.getTreatmentLabel())) {
					treatmentLabel = ppdt.getTreatmentLabel();
				} else {
					treatmentLabel = "Manual";
				}
				if (Objects.nonNull(protocol)) {
					List<ProtocolPointVO> protocolPoints = protocol.getPoints();
					protocolPoints.add(new ProtocolPointVO(ppdt.getId(),ppdt.getTreatmentsPerDay(),ppdt.getMinMinutesPerTreatment(),ppdt.getMinFrequency(),
							ppdt.getMaxFrequency(),ppdt.getType(),treatmentLabel,ppdt.getMinIntensity(), ppdt.getMaxIntensity()));
				} else {
					protocol = new ProtocolVO(ppdt.getProtocolKey(), !ppdt.isDeleted(), ppdt.getCreatedDate(), ppdt.getLastModifiedDate());
					List<ProtocolPointVO> protocolPoints = new ArrayList<>();
					protocolPoints.add(new ProtocolPointVO(ppdt.getId(),ppdt.getTreatmentsPerDay(),ppdt.getMinMinutesPerTreatment(),ppdt.getMinFrequency(),
							ppdt.getMaxFrequency(),ppdt.getType(),treatmentLabel,ppdt.getMinIntensity(), ppdt.getMaxIntensity()));
					protocol.setPoints(protocolPoints);
					protocolMap.put(protocol.getKey(), protocol);
				}					
			}
			protocolList.addAll(alignProtocolDuration(protocolMap));
			dptVO.setProtocolList(protocolList);
			deviceProtocols.add(dptVO);
		}
				
		return deviceProtocols;
	}
		
	public List<ProtocolVO> alignProtocolDuration(Map<String, ProtocolVO> protocolMap) {
		if (Objects.nonNull(protocolMap) && protocolMap.size() > 1) {
			boolean firstProtocol = true;
			Map<String, ProtocolVO> dayWiseUniqueProtocolMap = new HashMap<>();
			for (ProtocolVO protocol : protocolMap.values()) {
				//log.debug("date : " + protocol.getFrom().getYear() + "-" + protocol.getFrom().getMonthOfYear() + "-" + protocol.getFrom().getDayOfMonth() );
				if (firstProtocol) {
					dayWiseUniqueProtocolMap.put(protocol.getFrom().getYear() + "-" + protocol.getFrom().getMonthOfYear() + "-" + protocol.getFrom().getDayOfMonth(), protocol);
					firstProtocol = false;
				} else {
					protocol.setFrom(protocol.getFrom().plusDays(1));
					dayWiseUniqueProtocolMap.put(protocol.getFrom().getYear() + "-" + protocol.getFrom().getMonthOfYear() + "-" + protocol.getFrom().getDayOfMonth(), protocol);
				}
			}
			return new ArrayList<ProtocolVO>(dayWiseUniqueProtocolMap.values());
		} else {
			return new ArrayList<ProtocolVO>(protocolMap.values());
		}
		
	}
}
