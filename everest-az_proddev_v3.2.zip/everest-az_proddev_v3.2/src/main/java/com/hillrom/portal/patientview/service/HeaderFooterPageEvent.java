package com.hillrom.portal.patientview.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.hillrom.portal.patientview.constant.HillromConstants;
import com.hillrom.portal.patientview.dto.PatientDetailsVO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

public class HeaderFooterPageEvent extends PdfPageEventHelper {

	@Autowired
	PatientDetailsVO patientDetailsVO;

	final Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
	final Font pageFont = FontFactory.getFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);

	private String startDate;

	private String endDate;

	public HeaderFooterPageEvent(PatientDetailsVO patientDetailsVO, String startDate, String endDate) {
		this.patientDetailsVO = patientDetailsVO;
		this.startDate = startDate;
		this.endDate = endDate;

	}

	@Override
	public void onStartPage(PdfWriter writer, Document document) {
		String img = HillromConstants.PATH_FOR_HILLROM;
		Image image;
		try {
			image = Image.getInstance("classpath:" + img);
			image.setAlignment(Element.ALIGN_LEFT);
			image.setAbsolutePosition(56, 800);
			image.scaleAbsolute(66, 25);
			writer.getDirectContent().addImage(image, false);

			if (document.getPageNumber() > 1) {
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(patientDetailsVO.getFirstName() + " " + patientDetailsVO.getLastName(), titleFont),
						445, 820, 0);
				ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
						new Phrase(startDate + " " + "to" + " " + endDate, titleFont), 445, 810, 0);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onEndPage(PdfWriter writer, Document document) {

		if (document.getPageNumber() > 1) {
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
					new Phrase(patientDetailsVO.getReportRequester(), titleFont), 55, 40, 0);
			ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_LEFT,
					new Phrase(patientDetailsVO.getReportRanDate(), titleFont), 55, 30, 0);
		}
	}
}