package com.hillrom.portal.patientview.dto;

import java.util.Map;

public class PatientViewInfoTherapyDataVO {
	private Integer duration;
	private String deviceType;
	private String date;
	private String dateTime;	
	private Boolean isCompliant;
	private String hmr;
	private String serialNo;
	private DeviceProtocolSessionVO protocolSession;
	
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getHmr() {
		return hmr;
	}
	public void setHmr(String hmr) {
		this.hmr = hmr;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public DeviceProtocolSessionVO getProtocolSession() {
		return protocolSession;
	}
	public void setProtocolSession(DeviceProtocolSessionVO protocolSession) {
		this.protocolSession = protocolSession;
	}
	public Boolean getIsCompliant() {
		return isCompliant;
	}
	public void setIsCompliant(Boolean isCompliant) {
		this.isCompliant = isCompliant;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((dateTime == null) ? 0 : dateTime.hashCode());
		result = prime * result + ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + ((duration == null) ? 0 : duration.hashCode());
		result = prime * result + ((hmr == null) ? 0 : hmr.hashCode());
		result = prime * result + ((isCompliant == null) ? 0 : isCompliant.hashCode());
		result = prime * result + ((protocolSession == null) ? 0 : protocolSession.hashCode());
		result = prime * result + ((serialNo == null) ? 0 : serialNo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientViewInfoTherapyDataVO other = (PatientViewInfoTherapyDataVO) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (dateTime == null) {
			if (other.dateTime != null)
				return false;
		} else if (!dateTime.equals(other.dateTime))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (duration == null) {
			if (other.duration != null)
				return false;
		} else if (!duration.equals(other.duration))
			return false;
		if (hmr == null) {
			if (other.hmr != null)
				return false;
		} else if (!hmr.equals(other.hmr))
			return false;
		if (isCompliant == null) {
			if (other.isCompliant != null)
				return false;
		} else if (!isCompliant.equals(other.isCompliant))
			return false;
		if (protocolSession == null) {
			if (other.protocolSession != null)
				return false;
		} else if (!protocolSession.equals(other.protocolSession))
			return false;
		if (serialNo == null) {
			if (other.serialNo != null)
				return false;
		} else if (!serialNo.equals(other.serialNo))
			return false;
		return true;
	}
	public PatientViewInfoTherapyDataVO(Integer duration, String deviceType, String date, String dateTime,
			Boolean isCompliant, String hmr, String serialNo, DeviceProtocolSessionVO protocolSession) {
		super();
		this.duration = duration;
		this.deviceType = deviceType;
		this.date = date;
		this.dateTime = dateTime;
		this.isCompliant = isCompliant;
		this.hmr = hmr;
		this.serialNo = serialNo;
		this.protocolSession = protocolSession;
	}
	public PatientViewInfoTherapyDataVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PatientViewInfoTherapyDataVO [duration=" + duration + ", deviceType=" + deviceType + ", date=" + date
				+ ", dateTime=" + dateTime + ", isCompliant=" + isCompliant + ", hmr=" + hmr + ", serialNo=" + serialNo
				+ ", protocolSession=" + protocolSession + "]";
	}
	
}
