package com.hillrom.portal.manageclinics.rest;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.security.xauth.TokenProvider;
import com.hillrom.vest.service.AdvancedSearchService;
import com.hillrom.vest.web.rest.dto.AdvancedClinicDTO;
import com.hillrom.vest.web.rest.dto.ClinicVO;
import com.hillrom.vest.web.rest.util.PaginationUtil;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Manage Clinic", description = "Search Clinic : Implemented", tags = { "Manage Clinic" })
public class SearchClinic {
	@Inject
	private AdvancedSearchService advancedSearchService;
	
	@Inject 
	private TokenProvider tokenProvider;	
	//@ApiOperation(httpMethod = "GET", value = "retrieve tagged patients", response = ClinicVO.class, responseContainer = "List")
	@RequestMapping(value = "/clinics/advanced/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ClinicVO>> searchClinics(
    			 @RequestHeader(value="x-auth-token",required=true)String authToken,
    			 @RequestParam(value = "country", required = false) String country,
    		 	 @RequestParam(value = "name", required = false) String clinicName,
                 @RequestParam(value = "state", required = false) String state,
                 @RequestParam(value = "city", required = false) String city,
                 @RequestParam(value = "clinicSpeciality", required = false) String clinicSpecialty,
                 @RequestParam(value = "page", required = false) Integer offset,
                 @RequestParam(value = "per_page", required = false) Integer limit,
                 @RequestParam(value = "sort_by", required = false) String sortBy,
                 @RequestParam(value = "status", required = false) String clinicStatus,
                 @RequestParam(value = "asc", required = false) Boolean isAscending)
                 throws URISyntaxException, HillromException {
                  AdvancedClinicDTO advancedClinicDTO = new AdvancedClinicDTO();
                  
            Long userId = tokenProvider.getUserIdFromToken(authToken);
            Map<String,Boolean> sortOrder = new HashMap<>();
            if(sortBy != null  && !sortBy.equals("")) {
                   isAscending =  (isAscending != null)?  isAscending : true;
                   sortOrder.put(sortBy, isAscending);
            }
			List<String> countryList = null;
			List<String> stateList = null;
			List<String> cityList = null;
			if(Objects.isNull(clinicName)) {
			if(Objects.nonNull(country)) {
				countryList = new ArrayList<String>();
				countryList.add(country);
			}
			
			if(Objects.nonNull(state)) {
				stateList = new ArrayList<String>();
				stateList.add(state);
			}
			
			if(Objects.nonNull(city)) {
				cityList = new ArrayList<String>();			
				cityList.add(city);
			}
			}
			advancedClinicDTO.setUserId(userId);
			advancedClinicDTO.setClinicStatus(clinicStatus);
			advancedClinicDTO.setClinicName(clinicName);
			advancedClinicDTO.setCountry(countryList);
			advancedClinicDTO.setState(stateList);
			advancedClinicDTO.setCity(cityList);
			advancedClinicDTO.setClinicSpecialty(clinicSpecialty);
			Page<ClinicVO> page = advancedSearchService.advancedSearchClinics(advancedClinicDTO,
					PaginationUtil.generatePageRequest(offset, limit), sortOrder);
			HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/clinics/advanced/search", offset,
					limit);
			return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

}
