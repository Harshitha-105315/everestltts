package com.hillrom.portal.patientinformation.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.hillrom.monarch.repository.PatientMonarchDeviceRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.monarch.service.PatientNoEventMonarchService;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.monarch.service.TherapySessionServiceMonarch;
import com.hillrom.portal.patientview.dto.PatientSessionStatsVO;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.titan.service.PatientNoEventTitanService;
import com.hillrom.titan.service.PatientProtocolTitanService;
import com.hillrom.titan.service.TherapySessionServiceTitan;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.service.PatientNoEventService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.TherapySessionService;

@Repository
public class PatientSessionCompletedService {
	private static final Logger log = LoggerFactory.getLogger(PatientSessionCompletedService.class);

	@Inject
    private TherapySessionService therapySessionService;

    @Inject
    private TherapySessionServiceMonarch therapySessionServiceMonarch;
    
    @Inject
    TherapySessionServiceTitan therapySessionServiceTitan;

    @Inject
    private PatientProtocolService patientProtocolService;
  
    @Inject
    private PatientProtocolMonarchService patientProtocolMonarchService;
    
    @Inject
    private PatientProtocolTitanService patientProtocolTitanService;

	@Inject
	private PatientMonarchDeviceRepository patientMonarchDeviceRepository;
	
	@Inject
	private PatientTitanDeviceRepository  patientTitanDeviceRepository;
	
	@Inject 
	private PatientVestDeviceRepository patientVestDeviceRepository;

    @Inject
    private PatientNoEventService patientNoEventService;
    
    @Inject
    private PatientNoEventMonarchService patientNoEventMonarchService;
    
    @Inject
    private PatientNoEventTitanService patientNoEventTitanService;
    
    @Inject
	TherapySessionTitanRepository therapySessionTitanRepository;

	@Inject
	TherapySessionMonarchRepository therapySessionMonarchRepository;

	@Inject
	TherapySessionRepository therapySessionRepository;
    
	public long getSessionCompletedPercentage(Long userId, String patientId, LocalDate startDate, LocalDate endDate,String timeZone){
        return getCompletedMetrics(userId, patientId, startDate, endDate, null, timeZone);
	}

	public long getCompletedMetrics(Long userId, String patientId, LocalDate startDate, LocalDate endDate, PatientSessionStatsVO pssVO, String timeZone){
        long finalCompletedPercentage = 0;

		try {
			endDate = endDate.plusDays(1);
			LocalDate currDate = startDate;

			Map<LocalDate, List<Integer>> actualVestSessionByDate = null;
			Map<LocalDate, List<Integer>> actualMonarchSessionByDate = null;
			Map<LocalDate, List<Integer>> actualTitanSessionByDate = null;
			Map<LocalDate, Boolean> vestDevicePresentByDate = null;
			Map<LocalDate, Boolean> monarchDevicePresentByDate = null;
			Map<LocalDate, Boolean> titanDevicePresentByDate = null;
			Map<LocalDate, Map<String, Integer>> vestProtocolByDate = null;
			Map<LocalDate, Map<String, Integer>>monarchProtocolByDate = null;
			Map<LocalDate, Map<String, Integer>> titanProtocolByDate = null;
			// Get List of Devices
			
			List<PatientVestDeviceHistory> vestDevices = patientVestDeviceRepository.findByPatientIdWithinRange(patientId, startDate.toDateTimeAtStartOfDay());
			List<PatientVestDeviceHistoryMonarch> monarchDevices = patientMonarchDeviceRepository.findByPatientIdWithinRange(patientId, startDate.toDateTimeAtStartOfDay());		
			List<PatientVestDeviceHistoryTitan> titanDevices = patientTitanDeviceRepository.findByPatientIdWithinRange(patientId, startDate.toDateTimeAtStartOfDay());		

			LocalDate firstTransmissionDateVest = LocalDate.now();
			LocalDate firstTransmissionDateMonarch = LocalDate.now();
			LocalDate firstTransmissionDateTitan = LocalDate.now();
			LocalDate firstTrans = LocalDate.now();
			if(vestDevices.size()>0) {
				firstTransmissionDateVest  = patientNoEventService.getPatientFirstTransmittedDate(userId);
				if(Objects.isNull(firstTransmissionDateVest)) {
					Long firstTransDateVest= therapySessionRepository.findMinDateByPatientId(patientId);
					firstTransmissionDateVest=new LocalDate(firstTransDateVest);
				}
				vestDevicePresentByDate = new HashMap<LocalDate,Boolean>();
				vestProtocolByDate = patientProtocolService.getProtocolDurationAndTreatmentsByDate(patientId, startDate, endDate);
				actualVestSessionByDate = therapySessionService.getTherapyDurationAndTreatmentsByDate(patientId, startDate, endDate, timeZone);
				
				for(PatientVestDeviceHistory vestDevice: vestDevices) {
					currDate = startDate;				
					LocalDate to = endDate;
					
					if(currDate.isBefore(vestDevice.getCreatedDate().toLocalDate())) {
						currDate = vestDevice.getCreatedDate().toLocalDate();
					}
					
					if(!vestDevice.isActive() && to.isAfter(vestDevice.getLastModifiedDate().toLocalDate())) {
						to = vestDevice.getLastModifiedDate().toLocalDate();
					}
					
					while(currDate.isBefore(to)) {
						vestDevicePresentByDate.put(currDate, true);
						currDate = currDate.plusDays(1);
					}
				}
			}
			

			if(monarchDevices.size()>0) {
				firstTransmissionDateMonarch  = patientNoEventMonarchService.getPatientFirstTransmittedDate(userId);
				if(Objects.isNull(firstTransmissionDateMonarch)) {
					Long firstTransDateMonarch= therapySessionMonarchRepository.findMinDateByPatientId(patientId);
					firstTransmissionDateMonarch=new LocalDate(firstTransDateMonarch);
				}
				monarchDevicePresentByDate = new HashMap<LocalDate,Boolean>();
				monarchProtocolByDate = patientProtocolMonarchService.getProtocolDurationAndTreatmentsByDate(patientId, startDate, endDate);
				actualMonarchSessionByDate = therapySessionServiceMonarch.getTherapyDurationAndTreatmentsByDate(patientId, startDate, endDate, timeZone);

				for(PatientVestDeviceHistoryMonarch monDevice: monarchDevices) {
					currDate = startDate;
					LocalDate to = endDate;
					
					if(currDate.isBefore(monDevice.getCreatedDate().toLocalDate())) {
						currDate = monDevice.getCreatedDate().toLocalDate();
					}
					
					if(!monDevice.isActive() && to.isAfter(monDevice.getLastModifiedDate().toLocalDate())) {
						to = monDevice.getLastModifiedDate().toLocalDate();
					}
					
					while(currDate.isBefore(to)) {
						monarchDevicePresentByDate.put(currDate, true);
						currDate = currDate.plusDays(1);
					}
				}
			}
			
			if(titanDevices.size()>0) {
				firstTransmissionDateTitan = patientNoEventTitanService.getPatientFirstTransmittedDate(userId);
				if(Objects.isNull(firstTransmissionDateTitan)) {
					Long firstTransDateTitan= therapySessionTitanRepository.findMinDateByPatientId(patientId);
					firstTransmissionDateTitan=new LocalDate(firstTransDateTitan);
				}
				titanDevicePresentByDate = new HashMap<LocalDate,Boolean>();
				titanProtocolByDate = patientProtocolTitanService.getProtocolDurationAndTreatmentsByDate(patientId, startDate, endDate);
				actualTitanSessionByDate = therapySessionServiceTitan.getTherapyDurationAndTreatmentsByDate(patientId, startDate, endDate, timeZone);

				for(PatientVestDeviceHistoryTitan titDevice: titanDevices) {
					currDate = startDate;
					LocalDate to = endDate;
					
					if(currDate.isBefore(titDevice.getCreatedDate().toLocalDate())) {
						currDate =titDevice.getCreatedDate().toLocalDate();
					}
					
					if(!titDevice.isActive() && to.isAfter(titDevice.getLastModifiedDate().toLocalDate())) {
						to =titDevice.getLastModifiedDate().toLocalDate();
					}
					
					while(currDate.isBefore(to)) {
						titanDevicePresentByDate.put(currDate, true);
						currDate = currDate.plusDays(1);
					}
				}
			}
			if(firstTransmissionDateMonarch.isBefore(firstTransmissionDateVest)&&firstTransmissionDateMonarch.isBefore(firstTransmissionDateTitan)) {
				firstTrans = firstTransmissionDateMonarch;
			}else if( firstTransmissionDateVest.isBefore(firstTransmissionDateMonarch)&&firstTransmissionDateVest.isBefore(firstTransmissionDateTitan)) {
				firstTrans = firstTransmissionDateVest;
			}else {
				firstTrans = firstTransmissionDateTitan;
			}
			log.debug("first transmission date============="+firstTrans);
			if(firstTrans==null) {
				startDate= LocalDate.now();
			}
			else if(firstTrans.isAfter(startDate)) {
				startDate = firstTrans;
			}
			
			long totalSessionVest = 0;
			long totalSessionMonarch = 0;
			long totalSessionTitan = 0;
			long totalMinutesVest = 0;
			long totalMinutesMonarch = 0;
			long totalMinutesTitan = 0;
			long actualSessionVest = 0;
			long actualSessionMonarch = 0;
			long actualSessionTitan = 0;
			long actualMinutesVest = 0;
			long actualMinutesMonarch = 0;
			long actualMinutesTitan = 0;
			long completedSessionMonarch = 0;
			long completedSessionVest = 0;
			long completedSessionTitan = 0;

			
			currDate = startDate;
			while(currDate.isBefore(endDate)) {
				if((vestDevices.size() > 0) && Objects.nonNull(vestDevicePresentByDate.get(currDate))) {
					long totalSesionForDay = 0;
					long actualSessionForDay = 0;
					Integer durationPerSession = 0;
					Map<String, Integer> totalForDay = vestProtocolByDate.get(currDate);
					if(Objects.nonNull(totalForDay)) {
						totalSesionForDay = totalForDay.get(Constants.TREATMENTS_PER_DAY);
						totalSessionVest += totalSesionForDay;
						durationPerSession =  totalForDay.get(Constants.DURATION);
						totalMinutesVest += durationPerSession*totalSesionForDay;
					}
					
					if(Objects.nonNull(actualVestSessionByDate)) {
						List<Integer> actualForDay = actualVestSessionByDate.get(currDate);
						actualSessionForDay = 0;
						Integer totalDurationForDay = 0;
						if(Objects.nonNull(actualForDay)) {
							for (Integer duration : actualForDay) {

								if(duration >= durationPerSession) {
									actualSessionForDay++;
								}
								totalDurationForDay += duration;
							}
						}
							completedSessionVest += (actualSessionForDay>totalSesionForDay)?totalSesionForDay:actualSessionForDay;
							actualSessionVest += actualSessionForDay;
							actualMinutesVest += totalDurationForDay;
						}
					}
				
				if((monarchDevices.size() > 0) && Objects.nonNull(monarchDevicePresentByDate.get(currDate))) {
					long totalSesionForDay = 0;
					long actualSessionForDay = 0;
					Integer durationPerSession = 0;

					Map<String, Integer> totalForDay = monarchProtocolByDate.get(currDate);
					if(Objects.nonNull(totalForDay)) {
						totalSesionForDay = totalForDay.get(Constants.TREATMENTS_PER_DAY);
						totalSessionMonarch += totalSesionForDay;
						durationPerSession = totalForDay.get(Constants.DURATION);
						totalMinutesMonarch += durationPerSession*totalSesionForDay;
					}
					if(Objects.nonNull(actualMonarchSessionByDate)) {
						List<Integer> actualForDay = actualMonarchSessionByDate.get(currDate);
						actualSessionForDay = 0;
						Integer totalDurationForDay = 0;
						if(Objects.nonNull(actualForDay)) {
							for (Integer duration : actualForDay) {

								if(duration >= durationPerSession) {
									actualSessionForDay++;
								}
								totalDurationForDay += duration;
							}
						}
							completedSessionMonarch += (actualSessionForDay>totalSesionForDay)?totalSesionForDay:actualSessionForDay;
							actualSessionMonarch += actualSessionForDay; 
							actualMinutesMonarch += totalDurationForDay;
						}
					}
				
				if((titanDevices.size() > 0) && Objects.nonNull(titanDevicePresentByDate.get(currDate))) {
					long totalSesionForDay = 0;
					long actualSessionForDay = 0;
					Integer durationPerSession = 0;

					Map<String, Integer> totalForDay = titanProtocolByDate.get(currDate);
					if(Objects.nonNull(totalForDay)) {
						totalSesionForDay = totalForDay.get(Constants.TREATMENTS_PER_DAY);
						totalSessionTitan += totalSesionForDay;
						durationPerSession = totalForDay.get(Constants.DURATION);
						totalMinutesTitan += durationPerSession*totalSesionForDay;
					}
					if(Objects.nonNull(actualTitanSessionByDate)) {
						List<Integer> actualForDay = actualTitanSessionByDate.get(currDate);
						actualSessionForDay = 0;
						Integer totalDurationForDay = 0;
						if(Objects.nonNull(actualForDay)) {
							for (Integer duration : actualForDay) {

								if(duration >= durationPerSession) {
									actualSessionForDay++;
								}
								totalDurationForDay += duration;
							}
						}
	
							completedSessionTitan += (actualSessionForDay>totalSesionForDay)?totalSesionForDay:actualSessionForDay;
							actualSessionTitan += actualSessionForDay; 
							actualMinutesTitan += totalDurationForDay;
						}
					}
				
				currDate = currDate.plusDays(1);
			}
			
			long total_performed_sessions = actualSessionMonarch +actualSessionVest+actualSessionTitan;
			long total_sessions = totalSessionMonarch+totalSessionVest+totalSessionTitan;
			long total_completed_sessions = completedSessionMonarch +completedSessionVest+completedSessionTitan;
			long completed_sessions_percentage = (total_sessions > 0)?((total_completed_sessions*100) / total_sessions):0;
			
			completed_sessions_percentage = (completed_sessions_percentage > 100)?100:completed_sessions_percentage;
			
			long missed_sessions = total_sessions-total_completed_sessions;
			long total_minutes = totalMinutesMonarch + totalMinutesVest+totalMinutesTitan;

			long total_completed_minutes = actualMinutesMonarch+actualMinutesVest+actualMinutesTitan;
			long completed_minutes_percentage = (total_minutes > 0)?(total_completed_minutes*100) / total_minutes:0;
			completed_minutes_percentage = (completed_minutes_percentage>100)?100:completed_minutes_percentage;
			finalCompletedPercentage = (completed_sessions_percentage<0)?0:completed_sessions_percentage;
			if(Objects.nonNull(pssVO)) {
				pssVO.setTotal_performed_sessions((total_performed_sessions<0)?0:total_performed_sessions);
				pssVO.setCompleted_sessions_percentage(finalCompletedPercentage);
				pssVO.setCompleted_minutes_percentage((completed_minutes_percentage<0)?0:completed_minutes_percentage);
				pssVO.setMissed_sessions((missed_sessions<0)?0:missed_sessions);
				pssVO.setVest_sessions((actualSessionVest<0)?0:actualSessionVest);
				pssVO.setVest_minutes(actualMinutesVest);
				pssVO.setMonarch_sessions(actualSessionMonarch);
				pssVO.setMonarch_minutes(actualMinutesMonarch);
				pssVO.setTitan_sessions(actualSessionTitan);
				pssVO.setTitan_minutes(actualMinutesTitan);
				pssVO.setTotal_sessions(total_sessions);
				pssVO.setTotal_minutes(total_minutes);
				pssVO.setTotal_completed_sessions(total_completed_sessions);
				pssVO.setTotal_completed_minutes(total_completed_minutes);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		log.debug("User ID" + userId + " Patient Id: " + patientId + " From : " + startDate.toString() + " To: " + endDate.toString() + " % : " + finalCompletedPercentage);
        return finalCompletedPercentage;
	}

}