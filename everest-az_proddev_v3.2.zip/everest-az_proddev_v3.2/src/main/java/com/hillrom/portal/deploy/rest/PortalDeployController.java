package com.hillrom.portal.deploy.rest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hillrom.portal.deploy.service.PortalDeployService;
import com.hillrom.vest.config.Constants;

import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api/v1.0")
public class PortalDeployController {
	@Inject
	PortalDeployService portalDeployService;
	
	@RequestMapping(value = "/executeDeployJob", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> TimsFlatFileUpload(
			@RequestParam(value = "uploadfile", required = true) MultipartFile uploadfile,
			@RequestParam(value = "type", required = false) String type) {

		JSONObject jsonObject = new JSONObject();

		try {

			if (!Objects.isNull(uploadfile)) {
				// Get the filename and build the local file path
				String filename = DateTime.now().toString("yyyy_MM_dd_hh_mm_ss").toString().replace(" ", "_")
						.replaceAll(":", "_") + "_" + uploadfile.getOriginalFilename();
				String directory = Constants.TIMS_CSV_FILE_PATH_MANUAL;
				File dir = new File(Constants.TIMS_CSV_FILE_PATH_MANUAL);

				if (!dir.exists()) {
					dir.mkdirs();
				}
				String filepath = Paths.get(directory, filename).toString();

				// Save the file locally
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(uploadfile.getBytes());
				stream.close();

				try {
					if(type.equalsIgnoreCase("AE")) {
						portalDeployService.createAEUser(filepath);
					}else if(type.equalsIgnoreCase("PROTOCOL")) {
						portalDeployService.udpatePatientProtocol(filepath);
					}else if(type.equalsIgnoreCase("LINKPATIENT")) {
						portalDeployService.linkPatientProviderClinic(filepath);
					}
					jsonObject.put("timsMsg", "Deployed successfully");
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} catch (Exception ex) {

					jsonObject.put("timsMsg", "TIMSJob NOT Executed Successfully");
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} else {
				jsonObject.put("ERROR", "File not found");
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} catch (FileNotFoundException ex) {
			jsonObject.put("ERROR", "The system cannot find the path/Directory specified");
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			jsonObject.put("ERROR", ex.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

}
