package com.hillrom.portal.managepatients.dto;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"firstName",
"lastName",
"middleName",
"patientId",
"userId",
"flagged",
"sessionPercentage",
"isNew",
"lastTrans",
"never",
"stop",
"devices",
"isManual",
"active",
"reason"
})
public class AssociatedPatientSearchPatientInfo {
	@JsonProperty("firstName")
	private String firstName;
	@JsonProperty("lastName")
	private String lastName;
	@JsonProperty("middleName")
	private String middleName;
	@JsonProperty("patientId")
	private String patientId;
	@JsonProperty("userId")
	private Long userId;
	@JsonProperty("flagged")
	private Boolean flagged;
	@JsonProperty("sessionPercentage")
	private long sessionPercentage;
	@JsonProperty("isNew")
	private Boolean isNew;
	@JsonProperty("lastTrans")
	private Long lastTrans;
	@JsonProperty("firstTrans")
	private Long firstTrans;
	@JsonProperty("never")
	private Boolean never;
	@JsonProperty("stop")
	private Boolean stop;
	@JsonProperty("devices")
	private List<String> devices = null;
	@JsonProperty("isManual")
	private Boolean isManual;
	@JsonProperty("active")
	private Boolean active;
	@JsonProperty("reason")
	private String reason;
	/**
	* No args constructor for use in serialization
	* 
	*/
	public AssociatedPatientSearchPatientInfo() {
	}
	
	@JsonProperty("firstName")
	public String getFirstName() {
	return firstName;
	}
	
	@JsonProperty("firstName")
	public void setFirstName(String firstName) {
	this.firstName = firstName;
	}
	
	@JsonProperty("lastName")
	public String getLastName() {
	return lastName;
	}
	
	@JsonProperty("lastName")
	public void setLastName(String lastName) {
	this.lastName = lastName;
	}
	
	@JsonProperty("middleName")
	public String getMiddleName() {
	return middleName;
	}
	
	@JsonProperty("middleName")
	public void setMiddleName(String middleName) {
	this.middleName = middleName;
	}
	
	@JsonProperty("patientId")
	public String getPatientId() {
	return patientId;
	}
	
	@JsonProperty("patientId")
	public void setPatientId(String patientId) {
	this.patientId = patientId;
	}
	
	@JsonProperty("userId")
	public Long getUserId() {
	return userId;
	}
	
	@JsonProperty("userId")
	public void setUserId(Long userId) {
	this.userId = userId;
	}
	
	@JsonProperty("flagged")
	public Boolean getFlagged() {
	return flagged;
	}
	
	@JsonProperty("flagged")
	public void setFlagged(Boolean flagged) {
	this.flagged = flagged;
	}
	
	@JsonProperty("sessionPercentage")
	public long getSessionPercentage() {
	return sessionPercentage;
	}
	
	@JsonProperty("sessionPercentage")
	public void setSessionPercentage(long sessionPercentage) {
	this.sessionPercentage = sessionPercentage;
	}
	
	@JsonProperty("isNew")
	public Boolean getIsNew() {
	return isNew;
	}
	
	@JsonProperty("isNew")
	public void setIsNew(Boolean isNew) {
	this.isNew = isNew;
	}
	
	@JsonProperty("lastTrans")
	public Long getLastTrans() {
	return lastTrans;
	}
	
	@JsonProperty("lastTrans")
	public void setLastTrans(Long lastTrans) {
	this.lastTrans = lastTrans;
	}
	
	@JsonProperty("never")
	public Boolean getNever() {
	return never;
	}
	
	@JsonProperty("never")
	public void setNever(Boolean never) {
	this.never = never;
	}
	
	@JsonProperty("stop")
	public Boolean getStop() {
	return stop;
	}
	
	@JsonProperty("stop")
	public void setStop(Boolean stop) {
	this.stop = stop;
	}
	
	@JsonProperty("devices")
	public List<String> getDevices() {
	return devices;
	}
	
	@JsonProperty("devices")
	public void setDevices(List<String> devices) {
	this.devices = devices;
	}
	
	public Long getFirstTrans() {
		return firstTrans;
	}
	
	public void setFirstTrans(Long firstTrans) {
		this.firstTrans = firstTrans;
	}
	
	public Boolean getActive() {
		return active;
	}
	
	public void setActive(Boolean active) {
		this.active = active;
	}
	
	public String getReason() {
		return reason;
	}
	
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	public Boolean getIsManual() {
		return isManual;
	}

	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((active == null) ? 0 : active.hashCode());
		result = prime * result + ((devices == null) ? 0 : devices.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((firstTrans == null) ? 0 : firstTrans.hashCode());
		result = prime * result + ((flagged == null) ? 0 : flagged.hashCode());
		result = prime * result + (isManual ? 1231 : 1237);
		result = prime * result + ((isNew == null) ? 0 : isNew.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((lastTrans == null) ? 0 : lastTrans.hashCode());
		result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result + ((never == null) ? 0 : never.hashCode());
		result = prime * result + ((patientId == null) ? 0 : patientId.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + (int) (sessionPercentage ^ (sessionPercentage >>> 32));
		result = prime * result + ((stop == null) ? 0 : stop.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AssociatedPatientSearchPatientInfo other = (AssociatedPatientSearchPatientInfo) obj;
		if (active == null) {
			if (other.active != null)
				return false;
		} else if (!active.equals(other.active))
			return false;
		if (devices == null) {
			if (other.devices != null)
				return false;
		} else if (!devices.equals(other.devices))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (firstTrans == null) {
			if (other.firstTrans != null)
				return false;
		} else if (!firstTrans.equals(other.firstTrans))
			return false;
		if (flagged == null) {
			if (other.flagged != null)
				return false;
		} else if (!flagged.equals(other.flagged))
			return false;
		if (isManual != other.isManual)
			return false;
		if (isNew == null) {
			if (other.isNew != null)
				return false;
		} else if (!isNew.equals(other.isNew))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (lastTrans == null) {
			if (other.lastTrans != null)
				return false;
		} else if (!lastTrans.equals(other.lastTrans))
			return false;
		if (middleName == null) {
			if (other.middleName != null)
				return false;
		} else if (!middleName.equals(other.middleName))
			return false;
		if (never == null) {
			if (other.never != null)
				return false;
		} else if (!never.equals(other.never))
			return false;
		if (patientId == null) {
			if (other.patientId != null)
				return false;
		} else if (!patientId.equals(other.patientId))
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (sessionPercentage != other.sessionPercentage)
			return false;
		if (stop == null) {
			if (other.stop != null)
				return false;
		} else if (!stop.equals(other.stop))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
}
