package com.hillrom.portal.managepatients.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"clinicName",
"clinicId"
})
public class AssociatedPatientSearchClinicInfo {

@JsonProperty("clinicName")
private String clinicName;
@JsonProperty("clinicId")
private String clinicId;

/**
* No args constructor for use in serialization
* 
*/
public AssociatedPatientSearchClinicInfo() {
}

/**
* 
* @param clinicName
* @param clinicId
*/
public AssociatedPatientSearchClinicInfo(String clinicName, String clinicId) {
super();
this.clinicName = clinicName;
this.clinicId = clinicId;
}

@JsonProperty("clinicName")
public String getClinicName() {
return clinicName;
}

@JsonProperty("clinicName")
public void setClinicName(String clinicName) {
this.clinicName = clinicName;
}

@JsonProperty("clinicId")
public String getClinicId() {
return clinicId;
}

@JsonProperty("clinicId")
public void setClinicId(String clinicId) {
this.clinicId = clinicId;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((clinicId == null) ? 0 : clinicId.hashCode());
	result = prime * result + ((clinicName == null) ? 0 : clinicName.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	AssociatedPatientSearchClinicInfo other = (AssociatedPatientSearchClinicInfo) obj;
	if (clinicId == null) {
		if (other.clinicId != null)
			return false;
	} else if (!clinicId.equals(other.clinicId))
		return false;
	if (clinicName == null) {
		if (other.clinicName != null)
			return false;
	} else if (!clinicName.equals(other.clinicName))
		return false;
	return true;
}

}