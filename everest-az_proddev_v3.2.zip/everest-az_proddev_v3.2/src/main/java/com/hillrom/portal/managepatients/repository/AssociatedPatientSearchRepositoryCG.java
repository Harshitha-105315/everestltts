package com.hillrom.portal.managepatients.repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.hillrom.portal.managepatients.dto.AsscociatedPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchCAVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchClinicInfo;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchPatientInfo;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchProviderInfo;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientsDetailStatsVO;
import com.hillrom.portal.patientinformation.service.PatientSessionCompletedService;
import com.hillrom.portal.patientview.service.PortalSearchUtil;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.PatientInfoService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.util.RelationshipLabelConstants;

@Repository
public class AssociatedPatientSearchRepositoryCG {
	
	private final Logger log = LoggerFactory
			.getLogger(AssociatedPatientSearchRepositoryCG.class);

	@Inject
	private EntityManager entityManager;
	
	@Inject
	private PatientSessionCompletedService patientSessionCompletedRepository;
	
	@Inject
	private PatientInfoService patientInfoService;

	
	static String PATIENT_SEARCH_BASE_QUERY = "select\n" + 
			"	patientId,\n" + 
			"    userId,\n" + 
			"    hillromId,\n" + 
			"    clinics,\n" + 
			"    firstName,\n" + 
			"    lastName,\n" + 
			"    middleName,\n" + 
			"    isNew,\n" + 
			"	 flagged,\n"+
			"    HCP,\n" + 
			"    devices,\n" +
			"    if(deleted=0,1,0) as active,\n" +
			"    reason\n" +
			"from\n" + 
			"(select\n" + 
			"	upaSelf.patient_id as patientId,\n" + 
			"    uSelf.id as userId,\n" + 
			"    uSelf.hillrom_id as hillromId,\n" + 
			"    uSelf.is_deleted as deleted,\n" + 
			"    uExSelf.deactivation_reason as reason,\n" + 
			"    group_concat(distinct concat(cl.id,	'#_#', COALESCE(cl.name,'null')) separator '|') as clinics,\n" + 
			"    uSelf.first_name as firstName,\n" + 
			"    uSelf.last_name as lastName,\n" + 
			"    uSelf.middle_name as middleName,\n" + 
			"    IF(DATEDIFF(curdate(),uSelf.created_date)<LEAST(15,DATEDIFF(curdate(),COALESCE(userCG.last_loggedin_at,'0000-00-00'))),1,0) as isNew,\n" +
			"	 COALESCE(upfa.flagged,0) as flagged,\n" + 
			"    group_concat(distinct (select concat(id, '#_#', COALESCE(first_name,'null'), '#_#' , COALESCE(last_name,'null'), '#_#', COALESCE(middle_name,'null')) from USER where id=upaHCP.user_id) separator '|') as HCP,\n" + 
			"    group_concat(distinct(pda.device_type) separator '|') as devices\n" + 
			"from \n" + 
			"	USER_PATIENT_ASSOC upa\n" + 
			"left join PATIENT_INFO pi on upa.patient_id=pi.id and upa.user_role='"  + AuthoritiesConstants.CARE_GIVER + "'\n" +
			"left join CLINIC_PATIENT_ASSOC cpa on cpa.patient_id = pi.id\n" +
			"left join CLINIC cl on cl.id=cpa.clinic_id\n" + 
			"left join USER userCG on userCG.id=upa.user_id\n" + 
			"left join USER_PATIENT_ASSOC upaHCP on upaHCP.patient_id=pi.id and upaHCP.user_id=cua.users_id and upaHCP.user_role='"  + AuthoritiesConstants.HCP + "'\n" + 
			"left join USER_PATIENT_ASSOC upaSelf on upaSelf.patient_id=pi.id and upaSelf.user_role='"  + AuthoritiesConstants.PATIENT + "' and upaSelf.relation_label='"+RelationshipLabelConstants.SELF+"'\n" +
			"left join USER uSelf on uSelf.id=upaSelf.user_id\n" + 
			"left join USER_EXTENSION uExSelf on uSelf.id=uExSelf.user_id\n" +
			"left join PATIENT_DEVICES_ASSOC pda on pda.patient_id=pi.id\n" +
			"left join USER_PATIENT_FLAG_ASSOC upfa on  upfa.patient_id = pi.id and upfa.user_id = $USER_ID$\n"+
			"where\n"
			+ "upa.user_id=$USER_ID$ and upa.user_role='" + AuthoritiesConstants.CARE_GIVER +"'"
			+ "and upaSelf.user_role='"+ AuthoritiesConstants.PATIENT +"' "
			+ "$USER_PATTERN_FILTER$ "
			+ "$USER_ACTIVE_STATUS$ "
			+ "$USER_CREATED_DATE$ "
			+ "$USER_GENDER$ "
			+ "$FLAGGED$ "
			+ "$DEVICE_ACTIVE_STATUS$ "
			+ "$DEVICE_TYPE$ "
			+ "$PATIENT_TYPE$ "
			+ "$HCP_ID$ "
			+ "$CLINIC_ID$ "
			+ "$PATIENT_AGE$ "
			+ "group by uSelf.id)x;";

	private String setUserId(String queryStr, boolean enable, Long userId)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_ID$","");
		}else {
			queryStr = queryStr.replace("$USER_ID$", "" + userId);
		}
		return queryStr;
	}
	
	private String setFlagged(String queryStr, boolean enable, boolean value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$FLAGGED$","");
		}else {
			queryStr = queryStr.replace("$FLAGGED$", "and upfa.user_id=upa.user_id and upfa.flagged=" + value);
		}
		return queryStr;
	}
	
	private String setClinicId(String queryStr, boolean enable, String clinic_id)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$CLINIC_ID$","");
		}else {
			queryStr = queryStr.replace("$CLINIC_ID$", " and cl.id='" + clinic_id +"' ");
		}
		return queryStr;
	}
	
	private String setHCPId(String queryStr, boolean enable, String hcp_id)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$HCP_ID$","");
		}else {
			queryStr = queryStr.replace("$HCP_ID$", " and upaHCP.user_id=" + hcp_id + " ");
		}
		return queryStr;
	}
	

//	$PATIENT_TYPE$
	private String setDeviceAssocPatientType(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$PATIENT_TYPE$","");
		}else {
			queryStr = queryStr.replace("$PATIENT_TYPE$", "and pda.patient_type='CD'");
		}
		return queryStr;
	}

	private String setDeviceAssocDeviceType(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$DEVICE_TYPE$","");
		}else {
			if(value.equals("VEST")) {
				queryStr = queryStr.replace("$DEVICE_TYPE$", "and (pda.device_type='VEST')");
			}else if (value.equals("MONARCH")) {
				queryStr = queryStr.replace("$DEVICE_TYPE$", "and (pda.device_type='MONARCH')");
			}else {
				queryStr = queryStr.replace("$DEVICE_TYPE$","");
			}
		}
		return queryStr;
	}

//	$DEVICE_ACTIVE_STATUS$
	private String setDeviceAssocDeviceStatus(String queryStr, boolean enable, String activeSts)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$","");
		}else {
			if (activeSts.equals("active")) {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$", "and pda.is_active=1");
			}else if (activeSts.equals("inactive")) {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$", "and pda.is_active=0");
			}else {
				queryStr = queryStr.replace("$DEVICE_ACTIVE_STATUS$","");
			}				
		}
		return queryStr;
	}
	
//	$USER_PATTERN_FILTER$ 
	private String setUserPattern(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_PATTERN_FILTER$","");
		}else {
			String valueName =PortalSearchUtil.updatebaseString(value);
			value = valueName;
			valueName = Arrays.asList(valueName.split("\\s+")).stream().map(c -> "+" + c.toLowerCase() + "*").collect(Collectors.joining(" "));
					
			queryStr = queryStr.replace("$USER_PATTERN_FILTER$", " and MATCH(uSelf.first_name,uSelf.last_name,uSelf.middle_name) AGAINST ('" + valueName + "' IN BOOLEAN MODE)");
		}
		return queryStr;
	}

//	$USER_ACTIVE_STATUS$ 
	private String setUserActiveStatus(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_ACTIVE_STATUS$","");
		}else {
			if(value.equals("active")) {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$", "and uSelf.is_deleted=0 and uSelf.expired=0");
			}else if(value.equals("inactive")) {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$", "and ( uSelf.is_deleted=1 or uSelf.expired=1 )");
			}else {
				queryStr = queryStr.replace("$USER_ACTIVE_STATUS$","");
			}
		}
		return queryStr;
	}

//	$USER_CREATED_DATE$ 
	private String setUserCreatedDate(String queryStr, boolean enable)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_CREATED_DATE$","");
		}else {
			queryStr = queryStr.replace("$USER_CREATED_DATE$", "and DATEDIFF(curdate(),uSelf.created_date)<15");
		}
		return queryStr;
	}

//	$USER_GENDER$
	private String setUserGender(String queryStr, boolean enable, String value)
	{
		if (!enable)
		{
			queryStr = queryStr.replace("$USER_GENDER$","");
		}else {
			if(value.equals("male")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( uSelf.gender='Male' or uSelf.gender='M' )");
			}else if (value.equals("female")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( uSelf.gender='Female' or uSelf.gender='F' )");
			}
			else if (value.equals("other")) {
				queryStr = queryStr.replace("$USER_GENDER$", "and ( uSelf.gender not in ('male', 'M', 'Female', 'F') or uSelf.gender is null )");
			}else {
				queryStr = queryStr.replace("$USER_GENDER$","");
			}
		}
		return queryStr;
	}
	
	private String setUserAge(String queryStr, boolean enable, String ageRange)
	{
		if(!enable) {
			queryStr = queryStr.replace("$PATIENT_AGE$","");
		}else {
			if (ageRange.equals("all"))
			{
				queryStr = queryStr.replace("$PATIENT_AGE$","");
			}else if (ageRange.equals("18")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(uSelf.dob,curdate()), curdate()) <= 17");
			}else if (ageRange.equals("35")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(uSelf.dob,curdate()), curdate()) >= 18 and TIMESTAMPDIFF(YEAR, uSelf.dob, curdate()) <= 35");
			}else if (ageRange.equals("65")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(uSelf.dob,curdate()), curdate()) >= 36 and TIMESTAMPDIFF(YEAR, uSelf.dob, curdate()) <= 64");
			}else if (ageRange.equals("above65")){
				queryStr = queryStr.replace("$PATIENT_AGE$"," and TIMESTAMPDIFF(YEAR, COALESCE(uSelf.dob,curdate()), curdate()) >= 65");
			}
		}
	
		return queryStr;
	}

	private boolean isPatientMatchingTransmissionCriteria(AssociatedPatientSearchCAVO record, AssociatedPatientSearchDTO dto, LocalDate lastTrans)
	{
		if(Objects.nonNull(dto) && Objects.nonNull(dto.getTransmission())) {
			if(dto.getTransmission().equals("never")) {
//Need to filter based on never transmitted and no range is needed				
				if(Objects.isNull(lastTrans)) {
					return true;
				}else {
					return false;
				}
			}else if(dto.getTransmission().equals("stopped")) {
//Need to filter based on stopped and no range is needed
				if(Objects.nonNull(lastTrans) && lastTrans.isBefore(LocalDate.now()) && DateUtil.getDaysCountBetweenLocalDates(lastTrans,LocalDate.now()) > 30) {
					return true;
				}else {
					return false;
				}
			}else if(dto.getTransmission().equals("all")) {
//Need to list all and ignore range
				return true;
			}
		}

		//Need to include all within range
		if(Objects.nonNull(lastTrans)) {
			if((lastTrans.equals(dto.getFrom()) || lastTrans.isAfter(dto.getFrom())) && (lastTrans.equals(dto.getTo()) || lastTrans.isBefore(dto.getTo()))) {
				return true;
			}
		}
		
		return false;
	}
		
	private AsscociatedPatientSearchResultVO generateSearchResult(String queryStr, AssociatedPatientSearchDTO dto)
	{
		AsscociatedPatientSearchResultVO result = new AsscociatedPatientSearchResultVO();
		Boolean needSessionCount = Objects.nonNull(dto.getSession());
		
		log.debug(queryStr);
		Query query = entityManager.createNativeQuery(queryStr, "ManageAssociatedPatientSearchResultMapping");
		@SuppressWarnings("unchecked")
		List<AssociatedPatientSearchCAVO> resultsMapping = (List<AssociatedPatientSearchCAVO>) query.getResultList();
		if(resultsMapping.size()>0) {
			List<AssociatedPatientSearchVO> results = new ArrayList<AssociatedPatientSearchVO>();
			Long totalResSz = 0L;
			
			for (AssociatedPatientSearchCAVO record : resultsMapping) {
				long sessionPercentage = 0;
				Boolean addToResult = false;
				
				// Get min for first transmission
				Long firstTrans = patientInfoService.getFirstTransmission(record.getPatientId());
				
				// Get max for last transmission within range to determine, never, stopped
				Long maxDateInRange = patientInfoService.getMaxDateBetweenRange(record.getPatientId(),dto.getFrom(),dto.getTo());
				
				if(maxDateInRange != 0) {
					addToResult = isPatientMatchingTransmissionCriteria(record, dto, new LocalDate(maxDateInRange));					
				}else {
					addToResult = isPatientMatchingTransmissionCriteria(record, dto, null);
				}
				
				if(!addToResult) {
					continue;
				}
				
				sessionPercentage = patientSessionCompletedRepository.getSessionCompletedPercentage(record.getUserId(), record.getPatientId(),dto.getFrom(), dto.getTo(),dto.getTimeZone());
				
				if(needSessionCount) {
					addToResult = false;
					if(dto.getSession().equals("session50"))
					{
						if(sessionPercentage <= 49) {
							addToResult = true;
						}
					}else if (dto.getSession().equals("session80")) {
						if(sessionPercentage <= 79 && sessionPercentage >= 50) {
							addToResult = true;
						}							
					}else if (dto.getSession().equals("session100")) {
						if(sessionPercentage <= 100 && sessionPercentage >= 80) {
							addToResult = true;
						}							
					}
				}else {
					addToResult=true;
				}

				if(addToResult) {
					totalResSz+=1;
					AssociatedPatientSearchVO associatedPatientSearchVO = new AssociatedPatientSearchVO();
					List<AssociatedPatientSearchProviderInfo> providerInfo = getProviderDetails(record.getHCP());
					List<AssociatedPatientSearchClinicInfo> clinicInfo = getClinicDetails(record.getClinics());
					AssociatedPatientSearchPatientInfo patientInfo = new AssociatedPatientSearchPatientInfo();
					if(Objects.nonNull(record.getDevices())){
						patientInfo.setDevices(Arrays.asList(record.getDevices().split("\\|")));
					}else {
						patientInfo.setDevices(null);
					}
					
					patientInfo.setFirstName(record.getFirstName());
					patientInfo.setLastName(record.getLastName());
					patientInfo.setMiddleName(record.getMiddleName());
					patientInfo.setPatientId(record.getPatientId());
					patientInfo.setUserId(record.getUserId());
					patientInfo.setIsNew(record.getIsNew());
					patientInfo.setFlagged(record.getFlagged());
					patientInfo.setActive(record.getIsActive());
					patientInfo.setReason(record.getReason());
					patientInfo.setNever((maxDateInRange==0)?true:false);
					patientInfo.setStop((maxDateInRange > 0 && new LocalDate(maxDateInRange).isBefore(LocalDate.now()) && DateUtil.getDaysCountBetweenLocalDates(new LocalDate(maxDateInRange),LocalDate.now()) > 30));
					patientInfo.setLastTrans(maxDateInRange);
					patientInfo.setFirstTrans(firstTrans);
					patientInfo.setSessionPercentage(sessionPercentage);
					
					associatedPatientSearchVO.setClinicInfo(clinicInfo);
					associatedPatientSearchVO.setPatientInfo(patientInfo);
					associatedPatientSearchVO.setProviderInfo(providerInfo);
					
					results.add(associatedPatientSearchVO);
				}
			}
			
			result.setTotalCnt(totalResSz);
			
			if(results.size()>0) {
				result.setResults(results);			
			}					
		}
		
		return result;		
	}

	private void addToSession(AssociatedPatientSearchCAVO record, AssociatedPatientsDetailStatsVO session)
	{
		if(Objects.isNull(session.getProviderInfo())) {
			List<AssociatedPatientSearchProviderInfo> providerInfo = new ArrayList<AssociatedPatientSearchProviderInfo>();
			session.setProviderInfo(providerInfo);
		}
		
		if(Objects.isNull(session.getClinicInfo())) {
			List<AssociatedPatientSearchClinicInfo> clinicInfo = new ArrayList<AssociatedPatientSearchClinicInfo>();
			session.setClinicInfo(clinicInfo);
		}

		List<AssociatedPatientSearchClinicInfo> clinicInfo = session.getClinicInfo();
		List<AssociatedPatientSearchProviderInfo> providerInfo = session.getProviderInfo();
		
		List<AssociatedPatientSearchProviderInfo> provider = getProviderDetails(record.getHCP());
		if(Objects.nonNull(provider)) {
			for (AssociatedPatientSearchProviderInfo associatedPatientSearchProviderInfo : provider) {
				boolean found = false;
				if(!providerInfo.isEmpty()) {
					for (AssociatedPatientSearchProviderInfo masterList: providerInfo){
						if(masterList.equals(associatedPatientSearchProviderInfo)) {
							found = true;
							break;
						}
					}
				}
				if(!found) {
					providerInfo.add(associatedPatientSearchProviderInfo);
				}
			}
		}
		List<AssociatedPatientSearchClinicInfo> clinic = getClinicDetails(record.getClinics());
		if(Objects.nonNull(clinic)) {
			for (AssociatedPatientSearchClinicInfo associatedPatientSearchClinicInfo : clinic) {
				boolean found = false;
				if(!clinicInfo.isEmpty()) {
					for (AssociatedPatientSearchClinicInfo masterList: clinicInfo){
						if(masterList.equals(associatedPatientSearchClinicInfo)) {
							found = true;
							break;
						}
					}
				}
				if(!found) {
					clinicInfo.add(associatedPatientSearchClinicInfo);
				}
			}
		}
		session.setCount(session.getCount()+1);
		if(!providerInfo.isEmpty()) {
			session.setProviderInfo(providerInfo);
		}
		if(!clinicInfo.isEmpty()) {
			session.setClinicInfo(clinicInfo);
		}
	}

	private AssociatedPatientsDetailStatsVO generateStats(String queryStr, 
			AssociatedPatientSearchDTO dto, 
			AssociatedPatientsDetailStatsVO session50, 
			AssociatedPatientsDetailStatsVO session80, 
			AssociatedPatientsDetailStatsVO session100,
			AssociatedPatientsDetailStatsVO vest,
			AssociatedPatientsDetailStatsVO monarch,
			AssociatedPatientsDetailStatsVO titan,
			AssociatedPatientsDetailStatsVO multi,
			AssociatedPatientsDetailStatsVO flagged)
	{
		AssociatedPatientsDetailStatsVO result = new AssociatedPatientsDetailStatsVO();
		
		log.debug(queryStr);
		Query query = entityManager.createNativeQuery(queryStr, "ManageAssociatedPatientSearchResultMapping");
		@SuppressWarnings("unchecked")
		List<AssociatedPatientSearchCAVO> resultsMapping = (List<AssociatedPatientSearchCAVO>) query.getResultList();
		if(resultsMapping.size()>0) {
			Long totalResSz = 0L;
			List<AssociatedPatientSearchProviderInfo> providerInfo = new ArrayList<AssociatedPatientSearchProviderInfo>();
			List<AssociatedPatientSearchClinicInfo> clinicInfo = new ArrayList<AssociatedPatientSearchClinicInfo>();
			
			session50.setCount(0L);
			session80.setCount(0L);
			session100.setCount(0L);
			vest.setCount(0L);
			monarch.setCount(0L);
			titan.setCount(0L);
			multi.setCount(0L);
			flagged.setCount(0L);
			
			for (AssociatedPatientSearchCAVO record : resultsMapping) {
				long sessionPercentage = 0;
				// Get max for last transmission within range to determine, never, stopped
				Long maxDateInRange = patientInfoService.getMaxDateBetweenRange(record.getPatientId(),dto.getFrom(),dto.getTo());

				boolean addToResult = false;
				if(maxDateInRange != 0) {
					addToResult = isPatientMatchingTransmissionCriteria(record, dto, new LocalDate(maxDateInRange));					
				}else {
					addToResult = isPatientMatchingTransmissionCriteria(record, dto, null);
				}
				
				if(!addToResult) {
					continue;
				}

				sessionPercentage = patientSessionCompletedRepository.getSessionCompletedPercentage(record.getUserId(), record.getPatientId(),dto.getFrom(), dto.getTo(), dto.getTimeZone());

				if(sessionPercentage <= 49) {
					addToSession(record, session50);
				}
				if(sessionPercentage <= 79 && sessionPercentage >= 50) {
					addToSession(record, session80);
				}							
				if(sessionPercentage <= 100 && sessionPercentage >= 80) {
					addToSession(record, session100);
				}						
				
				if(Objects.nonNull(record.getDevices()) && record.getDevices().contains(Constants.VEST)) {
					addToSession(record, vest);
				}
				
				if(Objects.nonNull(record.getDevices()) && record.getDevices().contains(Constants.MONARCH)) {
					addToSession(record, monarch);
				}
				
				if(Objects.nonNull(record.getDevices()) && record.getDevices().contains(Constants.TITAN)) {
					addToSession(record, titan);
				}
				
				if(Objects.nonNull(record.getDevices()) && record.getDevices().contains(Constants.VEST) &&
						(record.getDevices().contains(Constants.MONARCH)||record.getDevices().contains(Constants.TITAN))|| record.getDevices().contains(Constants.TITAN) &&
						(record.getDevices().contains(Constants.MONARCH)||record.getDevices().contains(Constants.VEST))|| record.getDevices().contains(Constants.MONARCH) &&
						(record.getDevices().contains(Constants.VEST)||record.getDevices().contains(Constants.TITAN))	)
				{
					addToSession(record, multi);
				}
				
				if(Objects.nonNull(record.getFlagged()) && record.getFlagged().booleanValue()) {
					addToSession(record, flagged);
				}

				totalResSz+=1;
				List<AssociatedPatientSearchProviderInfo> provider = getProviderDetails(record.getHCP());
				if(Objects.nonNull(provider)) {
					for (AssociatedPatientSearchProviderInfo associatedPatientSearchProviderInfo : provider) {
						boolean found = false;
						if(!providerInfo.isEmpty()) {
							for (AssociatedPatientSearchProviderInfo masterList: providerInfo){
								if(masterList.equals(associatedPatientSearchProviderInfo)) {
									found = true;
									break;
								}
							}
						}
						if(!found) {
							providerInfo.add(associatedPatientSearchProviderInfo);
						}
					}
				}
				List<AssociatedPatientSearchClinicInfo> clinic = getClinicDetails(record.getClinics());
				if(Objects.nonNull(clinic)) {
					for (AssociatedPatientSearchClinicInfo associatedPatientSearchClinicInfo : clinic) {
						boolean found = false;
						if(!clinicInfo.isEmpty()) {
							for (AssociatedPatientSearchClinicInfo masterList: clinicInfo){
								if(masterList.equals(associatedPatientSearchClinicInfo)) {
									found = true;
									break;
								}
							}
						}
						if(!found) {
							clinicInfo.add(associatedPatientSearchClinicInfo);
						}
					}
				}
			}
			
			result.setCount(totalResSz);
			if(!providerInfo.isEmpty()) {
				result.setProviderInfo(providerInfo);
			}
			if(!clinicInfo.isEmpty()) {
				result.setClinicInfo(clinicInfo);
			}
		}else {
			result.setCount(0L);
		}
		
		return result;		
	}
	
	public List<AssociatedPatientSearchProviderInfo> getProviderDetails(String provider)
	{
		List<AssociatedPatientSearchProviderInfo> result = new ArrayList<AssociatedPatientSearchProviderInfo>();
		
		if(Objects.nonNull(provider)) {
			List<String> providers =Arrays.asList(provider.split("\\|"));
			for (String cl : providers) {
				AssociatedPatientSearchProviderInfo providerInfo = new AssociatedPatientSearchProviderInfo();
				List<String> info = Arrays.asList(cl.split("#_#"));
				String userId = info.get(0);
				String firstName = info.get(1);
				String lastName = info.get(2);
				
				providerInfo.setUserId(userId);
				
				if(!firstName.equals("null")) {
					providerInfo.setFirstName(firstName);
				}
				
				if(!lastName.equals("null")) {
					providerInfo.setLastName(lastName);
				}

				if(info.size() > 3) {
					String middleName = info.get(3);
					if(!middleName.equals("null")) {
						providerInfo.setMiddleName(middleName);
					}
				}
				
				result.add(providerInfo);
			}
		}
		
		if(result.isEmpty()) {
			return null;
		}
		return result;
	}
	
	public List<AssociatedPatientSearchClinicInfo> getClinicDetails(String clinic)
	{
		List<AssociatedPatientSearchClinicInfo> result = new ArrayList<AssociatedPatientSearchClinicInfo>();
		
		if(Objects.nonNull(clinic)) {
			List<String> clinics =Arrays.asList(clinic.split("\\|"));
			for (String cl : clinics) {
				AssociatedPatientSearchClinicInfo clinicInfo = new AssociatedPatientSearchClinicInfo();
				List<String> info = Arrays.asList(cl.split("#_#"));
				String clinicId =info.get(0);
				String clinicName =info.get(1);
				
				if(!clinicId.equals("null")) {
					clinicInfo.setClinicId(clinicId);
				}
				
				if(!clinicName.equals("null")) {
					clinicInfo.setClinicName(clinicName);
				}
				result.add(clinicInfo);
			}
		}
		
		if(result.isEmpty()) {
			return null;
		}
		return result;
	}	
	
	public AsscociatedPatientSearchResultVO searchPatientSimple(AssociatedPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,false,null);
		queryStr=setUserPattern(queryStr,Objects.nonNull(dto.getPattern()),dto.getPattern());
		queryStr=setUserActiveStatus(queryStr,false,null);
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,false, null);
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return generateSearchResult(queryStr, dto);
	}
	
	public AsscociatedPatientSearchResultVO searchPatientAll(AssociatedPatientSearchDTO dto){
		if(Objects.nonNull(dto.getDeviceType())) {
			if(dto.getDeviceType().equalsIgnoreCase("vest")) {
				return generateSearchResult(queryPatientVest(dto), dto);
			}else if(dto.getDeviceType().equalsIgnoreCase("monarch")) {
				return generateSearchResult(queryPatientMonarch(dto), dto);
			}else if(dto.getDeviceType().equalsIgnoreCase("multi")) {
				return generateSearchResult(queryPatientMulti(dto), dto);
			}
		}
		return generateSearchResult(queryPatientAll(dto), dto);
	}
	
	public AssociatedPatientsDetailStatsVO statsPatientAll(AssociatedPatientSearchDTO dto, 
			AssociatedPatientsDetailStatsVO session50, 
			AssociatedPatientsDetailStatsVO session80, 
			AssociatedPatientsDetailStatsVO session100,
			AssociatedPatientsDetailStatsVO vest,
			AssociatedPatientsDetailStatsVO monarch,
			AssociatedPatientsDetailStatsVO titan,
			AssociatedPatientsDetailStatsVO multi,
			AssociatedPatientsDetailStatsVO flagged
			){
		return generateStats(queryPatientAll(dto), 
					dto, 
					session50, 
					session80, 
					session100,
					vest,
					monarch,
					titan,
					multi,
					flagged);
	}
	
	public String queryPatientAll(AssociatedPatientSearchDTO dto)
	{
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}

	public AsscociatedPatientSearchResultVO searchPatientVest(AssociatedPatientSearchDTO dto){
		return generateSearchResult(queryPatientVest(dto), dto);
	}

	public String queryPatientVest(AssociatedPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"VEST");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}
	public AsscociatedPatientSearchResultVO searchPatientMonarch(AssociatedPatientSearchDTO dto){
		return generateSearchResult(queryPatientMonarch(dto), dto);
	}

	public String queryPatientMonarch(AssociatedPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"MONARCH");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}
	public AsscociatedPatientSearchResultVO searchPatientTitan(AssociatedPatientSearchDTO dto){
		return generateSearchResult(queryPatientTitan(dto), dto);
	}

	public String queryPatientTitan(AssociatedPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,false);
		queryStr=setDeviceAssocDeviceType(queryStr,true,"TITAN");
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}
	
	public AsscociatedPatientSearchResultVO searchPatientMulti(AssociatedPatientSearchDTO dto){
		return generateSearchResult(queryPatientMulti(dto), dto);
	}

	public String queryPatientMulti(AssociatedPatientSearchDTO dto){
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		queryStr=setDeviceAssocPatientType(queryStr,true);
		queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, false, false);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}

	public AsscociatedPatientSearchResultVO searchPatientFlagged(AssociatedPatientSearchDTO dto) {
		return generateSearchResult(queryPatientFlagged(dto), dto);
	}
	
	public String queryPatientFlagged(AssociatedPatientSearchDTO dto) {
		String queryStr = PATIENT_SEARCH_BASE_QUERY;
		queryStr=setUserId(queryStr, true, dto.getUserId());
		if(Objects.nonNull(dto.getDeviceType())) {
			if(dto.getDeviceType().equalsIgnoreCase("vest")) {
				queryStr=setDeviceAssocPatientType(queryStr,false);
				queryStr=setDeviceAssocDeviceType(queryStr,true,"VEST");
			}else if(dto.getDeviceType().equalsIgnoreCase("monarch")) {
				queryStr=setDeviceAssocPatientType(queryStr,false);
				queryStr=setDeviceAssocDeviceType(queryStr,true,"MONARCH");
			}else if(dto.getDeviceType().equalsIgnoreCase("multi")) {
				queryStr=setDeviceAssocPatientType(queryStr,true);
				queryStr=setDeviceAssocDeviceType(queryStr,false,null);
			}else{
				queryStr=setDeviceAssocPatientType(queryStr,false);
				queryStr=setDeviceAssocDeviceType(queryStr,false,null);				
			}
		}else {
			queryStr=setDeviceAssocPatientType(queryStr,false);
			queryStr=setDeviceAssocDeviceType(queryStr,false,null);
		}
		queryStr=setDeviceAssocDeviceStatus(queryStr,Objects.nonNull(dto.getDeviceSts()),dto.getDeviceSts());
		queryStr=setUserPattern(queryStr,false,null);
		queryStr=setUserActiveStatus(queryStr,Objects.nonNull(dto.getPatientSts()),dto.getPatientSts());
		queryStr=setUserCreatedDate(queryStr,false);
		queryStr=setUserGender(queryStr,Objects.nonNull(dto.getGender()),dto.getGender());
		queryStr=setClinicId(queryStr, Objects.nonNull(dto.getClinicId()), dto.getClinicId());
		queryStr=setHCPId(queryStr, Objects.nonNull(dto.getProviderId()), dto.getProviderId());
		queryStr=setFlagged(queryStr, true, true);
		queryStr=setUserAge(queryStr,Objects.nonNull(dto.getAgeRange()), dto.getAgeRange());
		return queryStr;
	}
}
