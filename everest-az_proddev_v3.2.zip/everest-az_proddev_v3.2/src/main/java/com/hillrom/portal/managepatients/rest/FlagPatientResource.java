package com.hillrom.portal.managepatients.rest;

import java.util.List;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.portal.managepatients.dto.PatientFlagDTO;
import com.hillrom.portal.managepatients.service.FlagPatientService;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.security.xauth.TokenProvider;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Manage Patient Flag", description = "Flag management for patients: Implemented", tags = { "Manage Patient flag" })
public class FlagPatientResource {
	@Inject
	FlagPatientService flagPatientService;
	
	@Inject
	TokenProvider tokenProvider;
	
	@ApiOperation(httpMethod = "POST", value = "CA flag patient")
	@RequestMapping(value = "/patient/manage/flag/ca", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.CLINIC_ADMIN})
	public ResponseEntity<List<PatientFlagDTO>> flaggingPatientAssociatedToCA(
		@RequestHeader(value="x-auth-token",required=true)String authToken,
		@RequestBody List<PatientFlagDTO> dto) {
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		try {
		dto = flagPatientService.flagAssociatedPatientsCA(userId, dto);
		}catch(Exception e) {
			e.printStackTrace();
		}
		for (PatientFlagDTO patientFlagDTO : dto) {
			if(patientFlagDTO.getMessage().contains("Failed"))
			{
				return new ResponseEntity<>(dto,HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<>(dto,HttpStatus.OK);
	}

	@ApiOperation(httpMethod = "POST", value = "Provider flag patient")
	@RequestMapping(value = "/patient/manage/flag/hcp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.HCP})
	public ResponseEntity<List<PatientFlagDTO>> flaggingPatientAssociatedToHCP(
			@RequestHeader(value="x-auth-token",required=true)String authToken,
			@RequestBody List<PatientFlagDTO> dto) {		
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		dto = flagPatientService.flagAssociatedPatientsHCP(userId, dto);
		for (PatientFlagDTO patientFlagDTO : dto) {
			if(patientFlagDTO.getMessage().contains("Failed"))
			{
				return new ResponseEntity<>(dto,HttpStatus.BAD_REQUEST);
			}
		}
		return new ResponseEntity<>(dto,HttpStatus.OK);
	}
 }
