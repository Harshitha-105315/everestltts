package com.hillrom.portal.managepatients.dto;

public class AssociatedPatientStatsVO {
	// patient_id or user_id of patient
	
	private AssociatedPatientsDetailStatsVO total_patients;
	private AssociatedPatientsDetailStatsVO flagged_patients;
	private AssociatedPatientsDetailStatsVO session50;
	private AssociatedPatientsDetailStatsVO session80;
	private AssociatedPatientsDetailStatsVO session100;
	private AssociatedPatientsDetailStatsVO monarch_patients;
	private AssociatedPatientsDetailStatsVO vest_patients;
	private AssociatedPatientsDetailStatsVO titan_patients;
	private AssociatedPatientsDetailStatsVO multi_device_patients;
	
	public AssociatedPatientsDetailStatsVO getTotal_patients() {
		return total_patients;
	}
	public void setTotal_patients(AssociatedPatientsDetailStatsVO total_patients) {
		this.total_patients = total_patients;
	}
	public AssociatedPatientsDetailStatsVO getFlagged_patients() {
		return flagged_patients;
	}
	public void setFlagged_patients(AssociatedPatientsDetailStatsVO flagged_patients) {
		this.flagged_patients = flagged_patients;
	}
	public AssociatedPatientsDetailStatsVO getSession50() {
		return session50;
	}
	public void setSession50(AssociatedPatientsDetailStatsVO session50) {
		this.session50 = session50;
	}
	public AssociatedPatientsDetailStatsVO getSession80() {
		return session80;
	}
	public void setSession80(AssociatedPatientsDetailStatsVO session80) {
		this.session80 = session80;
	}
	public AssociatedPatientsDetailStatsVO getSession100() {
		return session100;
	}
	public void setSession100(AssociatedPatientsDetailStatsVO session100) {
		this.session100 = session100;
	}
	public AssociatedPatientsDetailStatsVO getMonarch_patients() {
		return monarch_patients;
	}
	public void setMonarch_patients(AssociatedPatientsDetailStatsVO monarch_patients) {
		this.monarch_patients = monarch_patients;
	}
	public AssociatedPatientsDetailStatsVO getVest_patients() {
		return vest_patients;
	}
	public void setVest_patients(AssociatedPatientsDetailStatsVO vest_patients) {
		this.vest_patients = vest_patients;
	}
	public AssociatedPatientsDetailStatsVO getTitan_patients() {
		return titan_patients;
	}
	public void setTitan_patients(AssociatedPatientsDetailStatsVO titan_patients) {
		this.titan_patients =titan_patients;
	}
	public AssociatedPatientsDetailStatsVO getMulti_device_patients() {
		return multi_device_patients;
	}
	public void setMulti_device_patients(AssociatedPatientsDetailStatsVO multi_device_patients) {
		this.multi_device_patients = multi_device_patients;
	}	
}
