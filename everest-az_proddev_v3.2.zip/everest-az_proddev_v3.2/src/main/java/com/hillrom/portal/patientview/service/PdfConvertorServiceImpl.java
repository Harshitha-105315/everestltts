package com.hillrom.portal.patientview.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hillrom.portal.patientview.constant.HillromConstants;
import com.hillrom.portal.patientview.dto.ClinicsVO;
import com.hillrom.portal.patientview.dto.DaySessionsVO;
import com.hillrom.portal.patientview.dto.DeviceEventsVO;
import com.hillrom.portal.patientview.dto.DeviceSessionsVO;
import com.hillrom.portal.patientview.dto.DiagnosisCodesVO;
import com.hillrom.portal.patientview.dto.PatientDetailsVO;
import com.hillrom.portal.patientview.dto.ProvidersVO;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfConvertorServiceImpl implements PdfConvertorService {
	@Inject
	PatientSessionStatsService patientSessionStatsService;

	public byte[] createPdf(String userId, LocalDate startDate, LocalDate endDate, String timeZone, PatientDetailsVO patientDetailsVO)
			throws IOException, DocumentException, ParseException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			// Font info
			Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 7, BaseColor.BLACK);
			Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 7, BaseColor.BLACK);

			Document document = new Document(PageSize.A4);
			PdfWriter writer;
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			writer = PdfWriter.getInstance(document, out);


			// Set header and footer events
			HeaderFooterPageEvent pageEvent = new HeaderFooterPageEvent(patientDetailsVO, startDate.toString("MMM dd YYYY"),
					endDate.toString("MMM dd YYYY"));
			writer.setPageEvent(pageEvent);
			document.open();

			// Method to add patient info
			addPatientDetails(document, patientDetailsVO, startDate.toString("MMM dd YYYY"), endDate.toString("MMM dd YYYY"));

			Long startDateInMs = startDate.toDateTimeAtStartOfDay(DateTimeZone.forID(timeZone)).getMillis();
			Long endDateInMs = endDate.toDateTimeAtStartOfDay(DateTimeZone.forID(timeZone)).plusDays(1).getMillis();

			int i = 0;
			Pageable defaultPageSize = new PageRequest(i, 10);
			Page<DaySessionsVO> sessions = null;
			List<DaySessionsVO> daySessionsList = new ArrayList<DaySessionsVO>(); 
			do {

				// Method to replace
				sessions = patientSessionStatsService.getSessionWiseDeviceDetails(Long.parseLong(userId), startDateInMs, endDateInMs, timeZone,
						defaultPageSize, HillromConstants.SORT_ORDER);
				daySessionsList.addAll(sessions.getContent());

				i = i + 1;
				defaultPageSize = new PageRequest(i, 10);

			} while (i < sessions.getTotalPages());

			// Detailed report generation

			PdfPTable table = new PdfPTable(7);
			table.setWidths(new int[] { 5, 5, 18, 5, 5, 5, 5 });
			PdfPCell cell;

			cell = new PdfPCell(new Phrase(HillromConstants.DATE, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.TIME, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.EVENT, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.FREQUENCY, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.PRESSURE, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.SESSION_DURATION, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(HillromConstants.DEVICE, headerFont));
			setCellFontHeader(cell);
			table.addCell(cell);

			for (DaySessionsVO daySessionsVO : daySessionsList) {

				for (DeviceSessionsVO deviceSessionsVO : daySessionsVO.getSessions()) {
					float sessionCount = 0;
					if(deviceSessionsVO!=null && deviceSessionsVO.getEvents()!=null) 
					{
						for (DeviceEventsVO event : deviceSessionsVO.getEvents()) {

							if (sessionCount == 0) {
								cell = new PdfPCell(new Phrase(daySessionsVO.getDate(), titleFont));
								cell.setRowspan(deviceSessionsVO.getEvents().size());
								setCellFont(cell);
								table.addCell(cell);

							}
							String duration = String.valueOf(deviceSessionsVO.getDuration());
							cell = new PdfPCell(new Phrase(event.getTime(), titleFont));
							setCellFont(cell);
							table.addCell(cell);

							cell = new PdfPCell(new Phrase(event.getName(), titleFont));
							setCellFont(cell);
							table.addCell(cell);

							cell = new PdfPCell(new Phrase(Objects.nonNull(event.getFrequency())?event.getFrequency().toString():"", titleFont));
							setCellFont(cell);
							table.addCell(cell);

							cell = new PdfPCell(new Phrase(Objects.nonNull(event.getPressure())?event.getPressure().toString():"", titleFont));
							setCellFont(cell);
							table.addCell(cell);

							if (sessionCount == 0) {
								cell = new PdfPCell(new Phrase(duration, titleFont));
								cell.setRowspan(deviceSessionsVO.getEvents().size());
								setCellFont(cell);
								table.addCell(cell);
							}

							if (sessionCount == 0) {
								cell = new PdfPCell(getDeviceImage(deviceSessionsVO.getDevice(),deviceSessionsVO.isManual()));
								cell.setRowspan(deviceSessionsVO.getEvents().size());
								setCellFont(cell);
								table.addCell(cell);
							}
							sessionCount = sessionCount + 1;
						}
					}
				}

			}

			table.setWidthPercentage(90);
			float h = table.getTotalHeight();
			document.setMargins(30, 30, 70 + h, 50);
			document.add(table);
			document.close();

			// Get page number
			Font pageFont = FontFactory.getFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
			PdfReader reader = new PdfReader(out.toByteArray());
			int n = reader.getNumberOfPages();

			PdfStamper stamper = new PdfStamper(reader, baos);
			PdfContentByte pagecontent;
			for (int x = 0; x < n;) {
				pagecontent = stamper.getOverContent(++x);
				ColumnText.showTextAligned(pagecontent, Element.ALIGN_CENTER,
						new Phrase(String.format("Page %s of %s", x, n), pageFont), 515, 30, 0);
			}
			stamper.close();
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return baos.toByteArray();
	}

	private void addPatientDetails(Document document, PatientDetailsVO patientDetailsVO, String startDate,
			String endDate) throws DocumentException, IOException {
		Font detailFont = FontFactory.getFont(FontFactory.HELVETICA, 8, BaseColor.BLACK);
		Font detailKeyFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8, BaseColor.BLACK);
		Font nameFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.BLACK);

		PdfPTable patientInfo = new PdfPTable(1);
		patientInfo.setWidths(new int[] { 100 });
		PdfPCell piCell = new PdfPCell(new Phrase(""));
		piCell.setBorder(Rectangle.NO_BORDER);
		patientInfo.addCell(piCell);
		patientInfo.setSpacingAfter(35);
		patientInfo.setWidthPercentage(92);
		document.add(patientInfo);

		// Patient name
		if (patientDetailsVO.getFlagged()) {
			PdfPTable patientName = new PdfPTable(2);
			PdfPCell flaggedCell = new PdfPCell((getFlaggedImage()));
			flaggedCell.setBorder(Rectangle.NO_BORDER);
			patientName.addCell(flaggedCell);
			patientName.setWidths(new int[] { 5, 100 });
			PdfPCell fCell = new PdfPCell(
					new Phrase(patientDetailsVO.getFirstName() + " " + patientDetailsVO.getLastName(), nameFont));
			fCell.setBorder(Rectangle.NO_BORDER);
			patientName.addCell(fCell);
			patientName.setSpacingAfter(20);
			patientName.setWidthPercentage(92);
			document.add(patientName);
		} else {
			PdfPTable patientName = new PdfPTable(1);
			patientName.setWidths(new int[] { 100 });
			PdfPCell pCell;
			Phrase ph = new Phrase(patientDetailsVO.getFirstName() + " " + patientDetailsVO.getLastName(), nameFont);
			pCell = new PdfPCell(ph);
			pCell.setBorder(Rectangle.NO_BORDER);
			patientName.addCell(pCell);
			patientName.setSpacingAfter(20);
			patientName.setWidthPercentage(92);
			document.add(patientName);
		}

		// Patient details
		String status = checkIsDeleted(patientDetailsVO.getIsDeleted());
		PdfPTable patientDetails = new PdfPTable(1);
		patientDetails.setWidths(new int[] { 100 });
		Phrase p = new Phrase("Status: " + "  ", detailKeyFont);
		p.add(new Chunk(status, detailFont));
		if (status.equals("Inactive") && patientDetailsVO.getInactiveReason() != null) {
			p.add(new Chunk("(" + patientDetailsVO.getInactiveReason() + ")", detailFont));
		}
		p.add(new Chunk("   " + "Hillrom ID :" + "  ", detailKeyFont));
		p.add(new Chunk(patientDetailsVO.getHillromId(), detailFont));
		p.add(new Chunk("   " + "DOB :" + "  ", detailKeyFont));
		p.add(new Chunk(patientDetailsVO.getDob(), detailFont));
		PdfPCell pdCell = new PdfPCell(p);

		pdCell.setBorder(Rectangle.NO_BORDER);
		patientDetails.addCell(pdCell);
		patientDetails.setSpacingAfter(10);
		patientDetails.setWidthPercentage(92);
		document.add(patientDetails);

		// Diagnosis codes
		PdfPTable diagnosisCodes = new PdfPTable(1);
		diagnosisCodes.setWidths(new int[] { 100 });
		for (DiagnosisCodesVO code : patientDetailsVO.getDiagnosisCodes()) {
			Phrase pd = new Phrase("Diagnosis Codes : ", detailKeyFont);
			pd.add(new Chunk("  " + code.getTypeCode() + ", " + code.getTypeCodeValue(), detailFont));
			PdfPCell dCell = new PdfPCell(pd);
			dCell.setBorder(Rectangle.NO_BORDER);
			dCell.setFixedHeight(20f);
			diagnosisCodes.addCell(dCell);
		}
		diagnosisCodes.setSpacingAfter(10);
		diagnosisCodes.setWidthPercentage(92);
		document.add(diagnosisCodes);

		// Clinic information
		PdfPTable clinics = new PdfPTable(1);
		clinics.setWidths(new int[] { 100 });
		for (ClinicsVO clinic : patientDetailsVO.getClinics()) {
			Phrase c = new Phrase("Clinic ID : ", detailKeyFont);
			c.add(new Chunk("  " + clinic.getHillromId(), detailFont));
			c.add(new Chunk("  " + "Clinic : ", detailKeyFont));
			c.add(new Chunk("  " + clinic.getName(), detailFont));
			PdfPCell cCell = new PdfPCell(c);

			cCell.setBorder(Rectangle.NO_BORDER);
			cCell.setFixedHeight(20f);
			clinics.addCell(cCell);
		}
		clinics.setSpacingAfter(10);
		clinics.setWidthPercentage(92);
		document.add(clinics);

		// Providers information
		PdfPTable providers = new PdfPTable(1);
		providers.setWidths(new int[] { 100 });
		for (ProvidersVO provider : patientDetailsVO.getProviders()) {
			Phrase pro = new Phrase("Provider : ", detailKeyFont);
			pro.add(new Chunk("  " + provider.getFirstName() + " " + provider.getLastName(), detailFont));
			PdfPCell prCell = new PdfPCell(pro);
			prCell.setFixedHeight(20f);
			prCell.setBorder(Rectangle.NO_BORDER);
			providers.addCell(prCell);
		}
		providers.setSpacingAfter(10);
		providers.setWidthPercentage(92);
		document.add(providers);

		PdfPTable reportRequester = new PdfPTable(1);
		reportRequester.setWidths(new int[] { 100 });
		Phrase requester = new Phrase("Requester Of Report :", detailKeyFont);
		requester.add(new Chunk("  " + patientDetailsVO.getReportRequester(), detailFont));
		PdfPCell requesterCell = new PdfPCell(requester);
		requesterCell.setBorder(Rectangle.NO_BORDER);
		reportRequester.addCell(requesterCell);
		reportRequester.setSpacingAfter(10);
		reportRequester.setWidthPercentage(92);
		document.add(reportRequester);

		PdfPTable dateRange = new PdfPTable(1);
		dateRange.setWidths(new int[] { 100 });
		Phrase range = new Phrase("Date Range :", detailKeyFont);
		range.add(new Chunk("  " +startDate + " " + "to" + " " + endDate, detailFont));
		PdfPCell dateRangeCell = new PdfPCell(range);
		dateRangeCell.setBorder(Rectangle.NO_BORDER);
		dateRange.addCell(dateRangeCell);
		dateRange.setSpacingAfter(10);
		dateRange.setWidthPercentage(92);
		document.add(dateRange);

		PdfPTable currentDate = new PdfPTable(1);
		currentDate.setWidths(new int[] { 100 });
		Phrase cd = new Phrase("Report Ran On :", detailKeyFont);
		cd.add(new Chunk("  " +patientDetailsVO.getReportRanDate(), detailFont));
		PdfPCell currentDateCell = new PdfPCell(cd);
		currentDateCell.setBorder(Rectangle.NO_BORDER);
		currentDate.addCell(currentDateCell);
		currentDate.setSpacingAfter(500);
		currentDate.setWidthPercentage(92);
		document.add(currentDate);

	}

	private void setCellFontHeader(PdfPCell cell) {
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setFixedHeight(30f);

	}

	private void setCellFont(PdfPCell cell) {
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setFixedHeight(25f);

	}

	private Image getFlaggedImage() throws BadElementException, IOException {
		ClassPathResource res = new ClassPathResource(HillromConstants.PATH_FOR_FLAG);
		Image img = Image.getInstance("classpath:" + res.getPath());
		img.scaleToFit(15, 15);
		return img;
	}

	private Image getDeviceImage(String device, boolean isManual) throws DocumentException, IOException {
		String path = "";
		if (device.equals(HillromConstants.VEST)) {
			if(isManual) {
				path = HillromConstants.PATH_FOR_MANUAL_VEST;
			} else {
				path = HillromConstants.PATH_FOR_VEST;
			}

		} else if (device.equals(HillromConstants.MONARCH)) {
			path = HillromConstants.PATH_FOR_MONARCH;
		}
		else if (device.equals(HillromConstants.TITAN)) {
			path = HillromConstants.PATH_FOR_TITAN;
		}
		Image img = Image.getInstance("classpath:" + path);
		img.scaleToFit(20, 20);
		return img;

	}

	private Long stringToDateConvertor(String date) throws ParseException {
		SimpleDateFormat f = new SimpleDateFormat(date);
		Date d = f.parse(date);
		return d.getTime();

	}

	private String checkIsDeleted(Boolean isDeleted) {
		if (isDeleted) {
			return HillromConstants.IN_ACTIVE;
		} else {
			return HillromConstants.ACTIVE;
		}
	}

}