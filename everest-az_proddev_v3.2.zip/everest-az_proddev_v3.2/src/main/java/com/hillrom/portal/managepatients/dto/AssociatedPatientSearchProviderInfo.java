package com.hillrom.portal.managepatients.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"firstName",
"lastName",
"middleName",
"userId"
})
public class AssociatedPatientSearchProviderInfo {

@JsonProperty("firstName")
private String firstName;
@JsonProperty("lastName")
private String lastName;
@JsonProperty("middleName")
private String middleName;
@JsonProperty("userId")
private String userId;

/**
* No args constructor for use in serialization
* 
*/
public AssociatedPatientSearchProviderInfo() {
}

/**
* 
* @param middleName
* @param lastName
* @param userId
* @param firstName
*/
public AssociatedPatientSearchProviderInfo(String firstName, String lastName, String middleName, String userId) {
super();
this.firstName = firstName;
this.lastName = lastName;
this.middleName = middleName;
this.userId = userId;
}

@JsonProperty("firstName")
public String getFirstName() {
return firstName;
}

@JsonProperty("firstName")
public void setFirstName(String firstName) {
this.firstName = firstName;
}

@JsonProperty("lastName")
public String getLastName() {
return lastName;
}

@JsonProperty("lastName")
public void setLastName(String lastName) {
this.lastName = lastName;
}

@JsonProperty("middleName")
public String getMiddleName() {
return middleName;
}

@JsonProperty("middleName")
public void setMiddleName(String middleName) {
this.middleName = middleName;
}

@JsonProperty("userId")
public String getUserId() {
return userId;
}

@JsonProperty("userId")
public void setUserId(String userId) {
this.userId = userId;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
	result = prime * result + ((userId == null) ? 0 : userId.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	AssociatedPatientSearchProviderInfo other = (AssociatedPatientSearchProviderInfo) obj;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (middleName == null) {
		if (other.middleName != null)
			return false;
	} else if (!middleName.equals(other.middleName))
		return false;
	if (userId == null) {
		if (other.userId != null)
			return false;
	} else if (!userId.equals(other.userId))
		return false;
	return true;
}

}
