package com.hillrom.portal.managepatients.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"patientInfo",
"providerInfo",
"clinicInfo"
})
public class AssociatedPatientSearchVO {

@JsonProperty("patientInfo")
private AssociatedPatientSearchPatientInfo patientInfo;
@JsonProperty("providerInfo")
private List<AssociatedPatientSearchProviderInfo> providerInfo = null;
@JsonProperty("clinicInfo")
private List<AssociatedPatientSearchClinicInfo> clinicInfo = null;

/**
* No args constructor for use in serialization
* 
*/
public AssociatedPatientSearchVO() {
}

/**
* 
* @param patientInfo
* @param clinicInfo
* @param providerInfo
*/
public AssociatedPatientSearchVO(AssociatedPatientSearchPatientInfo patientInfo, List<AssociatedPatientSearchProviderInfo> providerInfo, List<AssociatedPatientSearchClinicInfo> clinicInfo) {
super();
this.patientInfo = patientInfo;
this.providerInfo = providerInfo;
this.clinicInfo = clinicInfo;
}

@JsonProperty("patientInfo")
public AssociatedPatientSearchPatientInfo getPatientInfo() {
return patientInfo;
}

@JsonProperty("patientInfo")
public void setPatientInfo(AssociatedPatientSearchPatientInfo patientInfo) {
this.patientInfo = patientInfo;
}

@JsonProperty("providerInfo")
public List<AssociatedPatientSearchProviderInfo> getProviderInfo() {
return providerInfo;
}

@JsonProperty("providerInfo")
public void setProviderInfo(List<AssociatedPatientSearchProviderInfo> providerInfo) {
this.providerInfo = providerInfo;
}

@JsonProperty("clinicInfo")
public List<AssociatedPatientSearchClinicInfo> getClinicInfo() {
return clinicInfo;
}

@JsonProperty("clinicInfo")
public void setClinicInfo(List<AssociatedPatientSearchClinicInfo> clinicInfo) {
this.clinicInfo = clinicInfo;
}

}