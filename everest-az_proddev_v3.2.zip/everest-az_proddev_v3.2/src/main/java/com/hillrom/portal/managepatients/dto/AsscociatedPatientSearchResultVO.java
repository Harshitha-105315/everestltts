package com.hillrom.portal.managepatients.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
"totalCnt",
"totalPage",
"currPage",
"currPageSz",
"results"
})
public class AsscociatedPatientSearchResultVO {

@JsonProperty("totalCnt")
private Long totalCnt;
@JsonProperty("results")
private List<AssociatedPatientSearchVO> results = null;

/**
* No args constructor for use in serialization
* 
*/
public AsscociatedPatientSearchResultVO() {
}

/**
* 
* @param currPage
* @param results
* @param currPageSz
* @param totalPage
* @param totalCnt
*/
public AsscociatedPatientSearchResultVO(Long totalCnt, List<AssociatedPatientSearchVO> results) {
super();
this.totalCnt = totalCnt;
this.results = results;
}

@JsonProperty("totalCnt")
public Long getTotalCnt() {
return totalCnt;
}

@JsonProperty("totalCnt")
public void setTotalCnt(Long totalCnt) {
this.totalCnt = totalCnt;
}

@JsonProperty("results")
public List<AssociatedPatientSearchVO> getResults() {
return results;
}

@JsonProperty("results")
public void setResults(List<AssociatedPatientSearchVO> results) {
this.results = results;
}

}
