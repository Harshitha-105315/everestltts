package com.hillrom.portal.managepatients.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import com.hillrom.vest.domain.AbstractAuditingEntity;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.User;

/**
 * A AWARD_MASTER.
 */
@Entity
@Audited
@Table(name = "USER_PATIENT_FLAG_ASSOC")
public class UserPatientFlagAssoc extends AbstractAuditingEntity {

		@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(name = "id")
	    private Long id;

		@ManyToOne(cascade = CascadeType.ALL)
		@JoinColumn(name="user_id",referencedColumnName="id")
	    private User user;

		@ManyToOne(cascade = CascadeType.ALL)
		@JoinColumn(name="patient_id",referencedColumnName="id")
	    private PatientInfo patient;

	    @Column(name = "flagged")
	    private Boolean flagged;

		/**
		 * @return the id
		 */
		public Long getId() {
			return id;
		}

		/**
		 * @param id the id to set
		 */
		public void setId(Long id) {
			this.id = id;
		}

		/**
		 * @return the userId
		 */
		public User getUser() {
			return user;
		}

		/**
		 * @param userId the userId to set
		 */
		public void setUser(User user) {
			this.user = user;
		}

		/**
		 * @return the patientId
		 */
		public PatientInfo getPatient() {
			return patient;
		}

		/**
		 * @param patientId the patientId to set
		 */
		public void setPatient(PatientInfo patientId) {
			this.patient = patientId;
		}

		/**
		 * @return the flagged
		 */
		public Boolean getFlagged() {
			return flagged;
		}

		/**
		 * @param flagged the flagged to set
		 */
		public void setFlagged(Boolean flagged) {
			this.flagged = flagged;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((flagged == null) ? 0 : flagged.hashCode());
			result = prime * result + ((id == null) ? 0 : id.hashCode());
			result = prime * result + ((patient == null) ? 0 : patient.hashCode());
			result = prime * result + ((user == null) ? 0 : user.hashCode());
			return result;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			UserPatientFlagAssoc other = (UserPatientFlagAssoc) obj;
			if (flagged == null) {
				if (other.flagged != null)
					return false;
			} else if (!flagged.equals(other.flagged))
				return false;
			if (id == null) {
				if (other.id != null)
					return false;
			} else if (!id.equals(other.id))
				return false;
			if (patient == null) {
				if (other.patient != null)
					return false;
			} else if (!patient.equals(other.patient))
				return false;
			if (user == null) {
				if (other.user != null)
					return false;
			} else if (!user.equals(other.user))
				return false;
			return true;
		}
}
