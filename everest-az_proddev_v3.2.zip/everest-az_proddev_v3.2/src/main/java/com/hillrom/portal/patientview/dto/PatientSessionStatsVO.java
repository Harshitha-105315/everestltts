package com.hillrom.portal.patientview.dto;

public class PatientSessionStatsVO {
	private long total_performed_sessions;
	private long completed_sessions_percentage;
	private long completed_minutes_percentage;
	private long missed_sessions;
	private long myScore;
	private long myScoreDiff;
	private long vest_sessions;
	private long vest_minutes;
	private long monarch_sessions;
	private long monarch_minutes;
	private long titan_sessions;
	private long titan_minutes;
	private long total_sessions;
	private long total_minutes;
	private long total_completed_sessions;
	private long total_completed_minutes;
	
	
	public long getTotal_sessions() {
		return total_sessions;
	}
	public void setTotal_sessions(long total_sessions) {
		this.total_sessions = total_sessions;
	}
	public long getTotal_minutes() {
		return total_minutes;
	}
	public void setTotal_minutes(long total_minutes) {
		this.total_minutes = total_minutes;
	}
	public long getTotal_completed_sessions() {
		return total_completed_sessions;
	}
	public void setTotal_completed_sessions(long total_completed_sessions) {
		this.total_completed_sessions = total_completed_sessions;
	}
	public long getMissed_sessions() {
		return missed_sessions;
	}
	public void setMissed_sessions(long missed_sessions) {
		this.missed_sessions = missed_sessions;
	}
	public long getMyScore() {
		return myScore;
	}
	public void setMyScore(long myScore) {
		this.myScore = myScore;
	}
	public long getMyScoreDiff() {
		return myScoreDiff;
	}
	public void setMyScoreDiff(long myScoreDiff) {
		this.myScoreDiff = myScoreDiff;
	}
	public long getVest_sessions() {
		return vest_sessions;
	}
	public void setVest_sessions(long vest_sessions) {
		this.vest_sessions = vest_sessions;
	}
	public long getVest_minutes() {
		return vest_minutes;
	}
	public void setVest_minutes(long vest_minutes) {
		this.vest_minutes = vest_minutes;
	}
	public long getMonarch_sessions() {
		return monarch_sessions;
	}
	public void setMonarch_sessions(long monarch_sessions) {
		this.monarch_sessions = monarch_sessions;
	}
	public long getMonarch_minutes() {
		return monarch_minutes;
	}
	public void setMonarch_minutes(long monarch_minutes) {
		this.monarch_minutes = monarch_minutes;
	}
	public long getTitan_sessions() {
		return titan_sessions;
	}
	public void setTitan_sessions(long titan_sessions) {
		this.titan_sessions = titan_sessions;
	}
	public long getTitan_minutes() {
		return titan_minutes;
	}
	public void setTitan_minutes(long titan_minutes) {
		this.titan_minutes = titan_minutes;
	}
	public long getTotal_performed_sessions() {
		return total_performed_sessions;
	}
	public void setTotal_performed_sessions(long total_performed_sessions) {
		this.total_performed_sessions = total_performed_sessions;
	}
	public long getCompleted_sessions_percentage() {
		return completed_sessions_percentage;
	}
	public void setCompleted_sessions_percentage(long completed_sessions_percentage) {
		this.completed_sessions_percentage = completed_sessions_percentage;
	}
	public long getCompleted_minutes_percentage() {
		return completed_minutes_percentage;
	}
	public void setCompleted_minutes_percentage(long completed_minutes_percentage) {
		this.completed_minutes_percentage = completed_minutes_percentage;
	}
	public long getTotal_completed_minutes() {
		return total_completed_minutes;
	}
	public void setTotal_completed_minutes(long total_completed_minutes) {
		this.total_completed_minutes = total_completed_minutes;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (completed_minutes_percentage ^ (completed_minutes_percentage >>> 32));
		result = prime * result + (int) (completed_sessions_percentage ^ (completed_sessions_percentage >>> 32));
		result = prime * result + (int) (missed_sessions ^ (missed_sessions >>> 32));
		result = prime * result + (int) (monarch_minutes ^ (monarch_minutes >>> 32));
		result = prime * result + (int) (monarch_sessions ^ (monarch_sessions >>> 32));
		result = prime * result + (int) (myScore ^ (myScore >>> 32));
		result = prime * result + (int) (myScoreDiff ^ (myScoreDiff >>> 32));
		result = prime * result + (int) (total_completed_minutes ^ (total_completed_minutes >>> 32));
		result = prime * result + (int) (total_completed_sessions ^ (total_completed_sessions >>> 32));
		result = prime * result + (int) (total_minutes ^ (total_minutes >>> 32));
		result = prime * result + (int) (total_performed_sessions ^ (total_performed_sessions >>> 32));
		result = prime * result + (int) (total_sessions ^ (total_sessions >>> 32));
		result = prime * result + (int) (vest_minutes ^ (vest_minutes >>> 32));
		result = prime * result + (int) (vest_sessions ^ (vest_sessions >>> 32));
		result = prime * result + (int) (titan_minutes ^ (titan_minutes >>> 32));
		result = prime * result + (int) (titan_sessions ^ (titan_sessions >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientSessionStatsVO other = (PatientSessionStatsVO) obj;
		if (completed_minutes_percentage != other.completed_minutes_percentage)
			return false;
		if (completed_sessions_percentage != other.completed_sessions_percentage)
			return false;
		if (missed_sessions != other.missed_sessions)
			return false;
		if (monarch_minutes != other.monarch_minutes)
			return false;
		if (monarch_sessions != other.monarch_sessions)
			return false;
		if (myScore != other.myScore)
			return false;
		if (myScoreDiff != other.myScoreDiff)
			return false;
		if (total_completed_minutes != other.total_completed_minutes)
			return false;
		if (total_completed_sessions != other.total_completed_sessions)
			return false;
		if (total_minutes != other.total_minutes)
			return false;
		if (total_performed_sessions != other.total_performed_sessions)
			return false;
		if (total_sessions != other.total_sessions)
			return false;
		if (vest_minutes != other.vest_minutes)
			return false;
		if (vest_sessions != other.vest_sessions)
			return false;
		if (titan_minutes != other.titan_minutes)
			return false;
		if (titan_sessions != other.titan_sessions)
			return false;
		return true;
	}	
}
