package com.hillrom.portal.viewclinic.dto;

import java.util.List;

import org.joda.time.DateTime;

public class AEListVO {
	private String firstName;
	private String lastName;
	private String middleName;
	private String emailID;
	private DateTime lastLoggedInAt;
	private Long userId;
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}
	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	/**
	 * @return the emailID
	 */
	public String getEmailID() {
		return emailID;
	}
	/**
	 * @param emailID the emailID to set
	 */
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	/**
	 * @return the lastLoggedInAt
	 */
	public DateTime getLastLoggedInAt() {
		return lastLoggedInAt;
	}
	/**
	 * @param lastLoggedInAt the lastLoggedInAt to set
	 */
	public void setLastLoggedInAt(DateTime lastLoggedInAt) {
		this.lastLoggedInAt = lastLoggedInAt;
	}
	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public AEListVO(String firstName, String lastName, String middleName, String emailID, DateTime lastLoggedInAt,
			Long userId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.emailID = emailID;
		this.lastLoggedInAt = lastLoggedInAt;
		this.userId = userId;
	}
	public AEListVO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
