package com.hillrom.portal.managepatients.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.portal.managepatients.domain.UserPatientFlagAssoc;
import com.hillrom.portal.managepatients.dto.PatientFlagDTO;
import com.hillrom.portal.managepatients.repository.UserPatientFlagAssocRepository;
import com.hillrom.vest.domain.Authority;
import com.hillrom.vest.domain.ClinicPatientAssoc;
import com.hillrom.vest.domain.EntityUserAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.repository.AuthorityRepository;
import com.hillrom.vest.repository.ClinicPatientRepository;
import com.hillrom.vest.repository.EntityUserRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;

@Service
@Transactional
public class FlagPatientService {
	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	@Inject
	private EntityUserRepository entityUserRepository;	
	
	@Inject
	private AuthorityRepository authorityRepository;

	@Inject 
	private UserRepository userRepository;
	
	@Inject
	private ClinicPatientRepository clinicPatientRepository; 
	
	@Inject
	private UserPatientFlagAssocRepository userPatientFlagAssocRepository;

	public List<PatientFlagDTO> flagAssociatedPatientsCA(Long userId, List<PatientFlagDTO> dto) {
		Boolean flagSetOrNot = false;
		List<Authority> authorities  = authorityRepository.findAll();
		Map<String,Authority> authorityMap = new HashMap<>();
    	authorities.stream().forEach(authority -> {
    		authorityMap.put(authority.getName(), authority);
    	});

		User existingUser = userRepository.findOne(userId);

		for (PatientFlagDTO patientFlagDTO : dto) {
			
			PatientInfo pat_info =  patientInfoRepository.findOneById(patientFlagDTO.getPatientId());
			
			if(Objects.nonNull(pat_info)) {
				if(Objects.nonNull(existingUser)) {
					List<EntityUserAssoc> entityUserAssoc = entityUserRepository.findByUserIdAndUserRole(userId, AuthoritiesConstants.CLINIC_ADMIN);
	
					if(Objects.nonNull(entityUserAssoc) && entityUserAssoc.size() > 0 ) {
						boolean found = false;
						for (EntityUserAssoc entityUserAssoc2 : entityUserAssoc) {
							Optional<ClinicPatientAssoc> clinicPatientAssoc = clinicPatientRepository.findOneByClinicIdAndPatientId(entityUserAssoc2.getClinic().getId(), pat_info.getId());
							
							if (clinicPatientAssoc.isPresent()) {
								flagSetOrNot = associatingFlagToPatient(patientFlagDTO,userId);
								if(flagSetOrNot) {
									patientFlagDTO.setMessage("Success");
								} else {
									patientFlagDTO.setMessage("Failed: flagging failed");								
								}							
								patientFlagDTO.setFlag(flagSetOrNot);
								found = true;
								break;
							}
						}
						
						if(!found) {
							patientFlagDTO.setMessage("Failed: Patient Id not found in associated clinic");							
						}						 
					}
				}else {
					patientFlagDTO.setMessage("Failed: Not a valid user id");
				}
			} else {
				patientFlagDTO.setMessage("Failed: Patient Id not found");
			}
		}
		return dto;
	}
		
	public List<PatientFlagDTO> flagAssociatedPatientsHCP(Long userId, List<PatientFlagDTO> dto) {
		Boolean flagSetOrNot = false;
		List<Authority> authorities  = authorityRepository.findAll();
		Map<String,Authority> authorityMap = new HashMap<>();
    	authorities.stream().forEach(authority -> {
    		authorityMap.put(authority.getName(), authority);
    	});

		User existingUser = userRepository.findOne(userId);

		for (PatientFlagDTO patientFlagDTO : dto) {
			
			PatientInfo pat_info =  patientInfoRepository.findOneById(patientFlagDTO.getPatientId());
			
			if(Objects.nonNull(pat_info)) {
				if(Objects.nonNull(existingUser)) {
					Optional<UserPatientAssoc> userPatientAssoc = userPatientRepository.findOneByUserIdAndPatientId(userId, pat_info.getId());
					
					if (userPatientAssoc.isPresent()) 
					{
						flagSetOrNot = associatingFlagToPatient(patientFlagDTO,userId);
						if(flagSetOrNot) {
							patientFlagDTO.setMessage("Success");
						} else {
							patientFlagDTO.setMessage("Failed");								
						}							
						patientFlagDTO.setFlag(flagSetOrNot);
					}else {
						patientFlagDTO.setMessage("Failed: Patient not associated with HCP");
					}
				}else {
					patientFlagDTO.setMessage("Failed: Not a valid user id");
				}
			} else {
				patientFlagDTO.setMessage("Failed: Patient Id not found");
			}
		}
		return dto;
	}
	
	private Boolean associatingFlagToPatient(PatientFlagDTO patientFlagDTO, Long userId) {
		Boolean statusFlag = false;
		try {
			Optional<UserPatientFlagAssoc> result=userPatientFlagAssocRepository.findOneByPatientIdAndUserId(patientFlagDTO.getPatientId(), userId);
			
			UserPatientFlagAssoc userPatientFlagAssoc =null;
			
			if(result.isPresent()) {
				userPatientFlagAssoc = result.get();
			}else {
				userPatientFlagAssoc = new UserPatientFlagAssoc();
			}
			userPatientFlagAssoc.setUser(userRepository.findOne(userId));
			userPatientFlagAssoc.setPatient(patientInfoRepository.findOne(patientFlagDTO.getPatientId()));
			userPatientFlagAssoc.setFlagged(patientFlagDTO.getFlag());
			userPatientFlagAssocRepository.save(userPatientFlagAssoc);
			statusFlag = true;
		} catch(Exception e){
			e.printStackTrace();
		}
		return statusFlag;
	}
}
