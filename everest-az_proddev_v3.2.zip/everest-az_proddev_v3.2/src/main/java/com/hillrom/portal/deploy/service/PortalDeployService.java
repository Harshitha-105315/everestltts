package com.hillrom.portal.deploy.service;

import static com.hillrom.vest.security.AuthoritiesConstants.HCP;

import java.io.FileReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.supercsv.cellprocessor.ConvertNullTo;
import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.monarch.web.rest.dto.ProtocolEntryMonarchDTO;
import com.hillrom.monarch.web.rest.dto.ProtocolMonarchDTO;
import com.hillrom.portal.deploy.dto.PortalClinicProviderLinkDTO;
import com.hillrom.portal.deploy.dto.PortalDeployAECreateDTO;
import com.hillrom.portal.deploy.dto.PortalDeployProtocolAssocDTO;
import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.EntityUserAssoc;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.AuthorityRepository;
import com.hillrom.vest.repository.ClinicRepository;
import com.hillrom.vest.repository.EntityUserRepository;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.ClinicPatientService;
import com.hillrom.vest.service.ClinicService;
import com.hillrom.vest.service.HCPClinicService;
import com.hillrom.vest.service.PatientHCPService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.web.rest.dto.ClinicDTO;
import com.hillrom.vest.web.rest.dto.ClinicVO;
import com.hillrom.vest.web.rest.dto.ProtocolDTO;
import com.hillrom.vest.web.rest.dto.ProtocolEntryDTO;
import com.hillrom.vest.web.rest.dto.UserExtensionDTO;



@Service
public class PortalDeployService {
	@Inject
	PatientProtocolMonarchRepository patientProtocolMonarchRepository;
	
	@Inject
	PatientProtocolRepository patientProtocolRepository;
	
	@Inject
	UserRepository userRepository;
	
	@Inject
	UserService userService;

	@Inject
	ClinicRepository clinicRepository;

	@Inject
	EntityUserRepository entityUserRepository;

	@Inject 
	private PatientProtocolMonarchService patientProtocolMonarchService;

	@Inject 
	private PatientProtocolService patientProtocolService;

    @Inject
    private PasswordEncoder passwordEncoder;
    
    @Inject
    private ClinicService clinicService;
    
    @Inject
    private ClinicPatientService clinicPatientService;
    
    @Inject
    private UserExtensionRepository userExtensionRepository;

    @Inject
    private AuthorityRepository authorityRepository;
    
    @Inject
    private HCPClinicService hcpClinicService;

    @Inject
    private PatientHCPService patientHCPService;
    
	private static CellProcessor[] getProtocolProcessor() {
        final CellProcessor[] processors = new CellProcessor[] {
        	new NotNull(), //private String timsID;
			new NotNull(),//private String devicetype;
			new NotNull(),//private String protocoltype;
			new Optional(new ParseInt()),//private int treatments_per_day;
			new Optional(new ParseInt()),//private int p1_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p1_minimum_frequency;
			new Optional(new ParseInt()),//private int p1_maximum_frequency;
			new Optional(new ParseInt()),//private int p1_minimum_pressure;
			new Optional(new ParseInt()),//private int p1_maximum_pressure;
			new Optional(new ParseInt()),//private int p2_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p2_minimum_frequency;
			new Optional(new ParseInt()),//private int p2_maximum_frequency;
			new Optional(new ParseInt()),//private int p2_minimum_pressure;
			new Optional(new ParseInt()),//private int p2_maximum_pressure;
			new Optional(new ParseInt()),//private int p3_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p3_minimum_frequency;
			new Optional(new ParseInt()),//private int p3_maximum_frequency;
			new Optional(new ParseInt()),//private int p3_minimum_pressure;
			new Optional(new ParseInt()),//private int p3_maximum_pressure;
			new Optional(new ParseInt()),//private int p4_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p4_minimum_frequency;
			new Optional(new ParseInt()),//private int p4_maximum_frequency;
			new Optional(new ParseInt()),//private int p4_minimum_pressure;
			new Optional(new ParseInt()),//private int p4_maximum_pressure;
			new Optional(new ParseInt()),//private int p5_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p5_minimum_frequency;
			new Optional(new ParseInt()),//private int p5_maximum_frequency;
			new Optional(new ParseInt()),//private int p5_minimum_pressure;
			new Optional(new ParseInt()),//private int p5_maximum_pressure;
			new Optional(new ParseInt()),//private int p6_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p6_minimum_frequency;
			new Optional(new ParseInt()),//private int p6_maximum_frequency;
			new Optional(new ParseInt()),//private int p6_minimum_pressure;
			new Optional(new ParseInt()),//private int p6_maximum_pressure;
			new Optional(new ParseInt()),//private int p7_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p7_minimum_frequency;
			new Optional(new ParseInt()),//private int p7_maximum_frequency;
			new Optional(new ParseInt()),//private int p7_minimum_pressure;
			new Optional(new ParseInt()),//private int p7_maximum_pressure;
			new Optional(new ParseInt()),//private int p8_minimum_minutes_per_treatment;
			new Optional(new ParseInt()),//private int p8_minimum_frequency;
			new Optional(new ParseInt()),//private int p8_maximum_frequency;
			new ConvertNullTo(1,new ParseInt()),//private int p8_minimum_pressure;
			new ConvertNullTo(10,new ParseInt())//private int p8_maximum_pressure;
        };
        return processors;
	}
	
	public void udpatePatientProtocol(String fileName)
	{
		try {
			ICsvBeanReader beanReader = new CsvBeanReader(new FileReader(fileName), CsvPreference.STANDARD_PREFERENCE);
		    // the header elements are used to map the values to the bean
			final String[] headers = {"TimsId",
					"devicetype",
					"protocoltype",
					"treatments_per_day",
					"p1_minimum_minutes_per_treatment",
					"p1_minimum_frequency",
					"p1_maximum_frequency",
					"p1_minimum_pressure",
					"p1_maximum_pressure",
					"p2_minimum_minutes_per_treatment",
					"p2_minimum_frequency",
					"p2_maximum_frequency",
					"p2_minimum_pressure",
					"p2_maximum_pressure",
					"p3_minimum_minutes_per_treatment",
					"p3_minimum_frequency",
					"p3_maximum_frequency",
					"p3_minimum_pressure",
					"p3_maximum_pressure",
					"p4_minimum_minutes_per_treatment",
					"p4_minimum_frequency",
					"p4_maximum_frequency",
					"p4_minimum_pressure",
					"p4_maximum_pressure",
					"p5_minimum_minutes_per_treatment",
					"p5_minimum_frequency",
					"p5_maximum_frequency",
					"p5_minimum_pressure",
					"p5_maximum_pressure",
					"p6_minimum_minutes_per_treatment",
					"p6_minimum_frequency",
					"p6_maximum_frequency",
					"p6_minimum_pressure",
					"p6_maximum_pressure",
					"p7_minimum_minutes_per_treatment",
					"p7_minimum_frequency",
					"p7_maximum_frequency",
					"p7_minimum_pressure",
					"p7_maximum_pressure",
					"p8_minimum_minutes_per_treatment",
					"p8_minimum_frequency",
					"p8_maximum_frequency",
					"p8_minimum_pressure",
					"p8_maximum_pressure"
				};
		    final CellProcessor[] processors = getProtocolProcessor();
		    
		    String[] tempHeaders = beanReader.getHeader(true);
		    PortalDeployProtocolAssocDTO portalDeployProtocolAssocDTO = new PortalDeployProtocolAssocDTO();

			boolean valid = true;
		
			while(valid) {
				portalDeployProtocolAssocDTO = beanReader.read(PortalDeployProtocolAssocDTO.class, headers, processors);
		    	
		    	if(Objects.nonNull(portalDeployProtocolAssocDTO)) {
		    		java.util.Optional<User> user = userRepository.findOneByHillromId(portalDeployProtocolAssocDTO.getTimsId());
		    		if(user.isPresent()) {
		    			if(portalDeployProtocolAssocDTO.getDevicetype().equalsIgnoreCase("MONARCH")) {
		    				assignProtocolToMonarchPatient(portalDeployProtocolAssocDTO, user.get().getId());
		    			}else if(portalDeployProtocolAssocDTO.getDevicetype().equalsIgnoreCase("VEST")) {
		    				assignProtocolToVestPatient(portalDeployProtocolAssocDTO, user.get().getId());
		    			}
		    		}
		    	}else {
		    		valid = false;
		    	}
		    }
			beanReader.close();
		}catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Transactional
	private void assignProtocolToMonarchPatient(PortalDeployProtocolAssocDTO record, Long userId)
	{
		if(record.getTreatments_per_day() != 0)
		{
			List<PatientProtocolDataMonarch> existingProtocol =  patientProtocolMonarchService.findOneByPatientUserIdAndStatus(userId, false);
			
			for (PatientProtocolDataMonarch protocolDataMonarch : existingProtocol) {
				try {
					patientProtocolMonarchService.deleteProtocolForPatient(userId, protocolDataMonarch.getProtocolKey());
				}catch(Exception e) {
					e.printStackTrace();
					return;
				}
			}
			
			List<ProtocolEntryMonarchDTO> ppdList = new LinkedList<ProtocolEntryMonarchDTO>();
			if(record.getP1_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point1", 
													record.getP1_minimum_minutes_per_treatment(),
													record.getP1_minimum_minutes_per_treatment(),
													record.getP1_minimum_frequency(), 
													record.getP1_maximum_frequency(), 
													record.getP1_minimum_pressure(), 
													record.getP1_maximum_pressure()));
			}
			
			if(record.getP2_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point2", 
													record.getP2_minimum_minutes_per_treatment(), 
													record.getP2_minimum_minutes_per_treatment(), 
													record.getP2_minimum_frequency(), 
													record.getP2_maximum_frequency(), 
													record.getP2_minimum_pressure(), 
													record.getP2_maximum_pressure()));
			}

			
			if(record.getP3_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point3", 
													record.getP3_minimum_minutes_per_treatment(), 
													record.getP3_minimum_minutes_per_treatment(), 
													record.getP3_minimum_frequency(), 
													record.getP3_maximum_frequency(), 
													record.getP3_minimum_pressure(), 
													record.getP3_maximum_pressure()));
			}

			if(record.getP4_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point4",
													record.getP4_minimum_minutes_per_treatment(), 
													record.getP4_minimum_minutes_per_treatment(), 
													record.getP4_minimum_frequency(), 
													record.getP4_maximum_frequency(), 
													record.getP4_minimum_pressure(), 
													record.getP4_maximum_pressure()));
			}

			if(record.getP5_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point5", 
													record.getP5_minimum_minutes_per_treatment(), 
													record.getP5_minimum_minutes_per_treatment(), 
													record.getP5_minimum_frequency(), 
													record.getP5_maximum_frequency(), 
													record.getP5_minimum_pressure(), 
													record.getP5_maximum_pressure()));
			}

			if(record.getP6_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point6", 
													record.getP6_minimum_minutes_per_treatment(), 
													record.getP6_minimum_minutes_per_treatment(), 
													record.getP6_minimum_frequency(), 
													record.getP6_maximum_frequency(), 
													record.getP6_minimum_pressure(), 
													record.getP6_maximum_pressure()));
			}

			if(record.getP7_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point7", 
													record.getP7_minimum_minutes_per_treatment(), 
													record.getP7_minimum_minutes_per_treatment(), 
													record.getP7_minimum_frequency(), 
													record.getP7_maximum_frequency(), 
													record.getP7_minimum_pressure(), 
													record.getP7_maximum_pressure()));
			}

			if(record.getP8_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocolMonarch(	"point8", 
													record.getP8_minimum_minutes_per_treatment(), 
													record.getP8_minimum_minutes_per_treatment(), 
													record.getP8_minimum_frequency(), 
													record.getP8_maximum_frequency(), 
													record.getP8_minimum_pressure(), 
													record.getP8_maximum_pressure()));
			}
			
			ProtocolMonarchDTO protocolMonarchDTO = new ProtocolMonarchDTO();			

			protocolMonarchDTO.setTreatmentsPerDay(record.getTreatments_per_day());
			protocolMonarchDTO.setType(record.getProtocoltype());
			protocolMonarchDTO.setProtocolEntries(ppdList);
			try {
				patientProtocolMonarchService.addProtocolToPatient(userId, protocolMonarchDTO);
			}catch(HillromException e){
				e.printStackTrace();
			}
							
		}else {
			List<PatientProtocolDataMonarch> protocol =  patientProtocolMonarchService.findOneByPatientUserIdAndStatus(userId, false);
			
			if (protocol.isEmpty()) {
				List<ProtocolEntryMonarchDTO> ppdList = new LinkedList<ProtocolEntryMonarchDTO>();

				ppdList.add(createProtocolMonarch(	null, 
						5, 
						20, 
						5, 
						20, 
						1, 
						10));
				
				ProtocolMonarchDTO protocolMonarchDTO = new ProtocolMonarchDTO();			

				protocolMonarchDTO.setTreatmentsPerDay(2);
				protocolMonarchDTO.setType("Normal");
				protocolMonarchDTO.setProtocolEntries(ppdList);
				try {
					patientProtocolMonarchService.addProtocolToPatient(userId, protocolMonarchDTO);
				}catch(HillromException e) {
					e.printStackTrace();					
				}
			}
		}		
	}
	
	private ProtocolEntryMonarchDTO createProtocolMonarch(String treatmentLabel,int minMinutesPerTreatment, int maxMinutesPerTreatment, int minFrequency, int maxFrequency, int minIntensity, int maxIntensity) {
		// TODO: To check what is last modified time
		ProtocolEntryMonarchDTO protocolEntryMonarchDTO = new ProtocolEntryMonarchDTO();
		protocolEntryMonarchDTO.setMaxFrequency(maxFrequency);
		protocolEntryMonarchDTO.setMinFrequency(minFrequency);
		protocolEntryMonarchDTO.setMinMinutesPerTreatment(minMinutesPerTreatment);
		protocolEntryMonarchDTO.setMaxMinutesPerTreatment(maxMinutesPerTreatment);
		if(maxIntensity == 0 || Objects.isNull(maxIntensity)) {
			protocolEntryMonarchDTO.setMaxIntensity(10);
		}else {
			protocolEntryMonarchDTO.setMaxIntensity(maxIntensity);
		}
		if(minIntensity == 0 || Objects.isNull(minIntensity)) {
			protocolEntryMonarchDTO.setMinIntensity(1);
		}else {
			protocolEntryMonarchDTO.setMinIntensity(minIntensity);
		}
		protocolEntryMonarchDTO.setTreatmentLabel(treatmentLabel);
		return protocolEntryMonarchDTO;
	}
	
	@Transactional
	private void assignProtocolToVestPatient(PortalDeployProtocolAssocDTO record, Long userId)
	{
		if(record.getTreatments_per_day() != 0)
		{
			List<PatientProtocolData> existinProtocol =  patientProtocolService.findOneByPatientUserIdAndStatus(userId, false);
			
			for (PatientProtocolData protocolData: existinProtocol) {
				try {
					patientProtocolService.deleteProtocolForPatient(userId, protocolData.getProtocolKey());
				}catch(Exception e) {
					e.printStackTrace();
					return;
				}
			}
			
			List<ProtocolEntryDTO> ppdList = new LinkedList<ProtocolEntryDTO>();
			if(record.getP1_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point1", 
											record.getP1_minimum_minutes_per_treatment(), 
											record.getP1_minimum_minutes_per_treatment(), 
											record.getP1_minimum_frequency(), 
											record.getP1_maximum_frequency(), 
											record.getP1_minimum_pressure(), 
											record.getP1_maximum_pressure()));
			}
			
			if(record.getP2_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point2", 
											record.getP2_minimum_minutes_per_treatment(), 
											record.getP2_minimum_minutes_per_treatment(), 
											record.getP2_minimum_frequency(), 
											record.getP2_maximum_frequency(), 
											record.getP2_minimum_pressure(), 
											record.getP2_maximum_pressure()));
			}

			
			if(record.getP3_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point3", 
											record.getP3_minimum_minutes_per_treatment(), 
											record.getP3_minimum_minutes_per_treatment(), 
											record.getP3_minimum_frequency(), 
											record.getP3_maximum_frequency(), 
											record.getP3_minimum_pressure(), 
											record.getP3_maximum_pressure()));
			}

			if(record.getP4_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point4",
											record.getP4_minimum_minutes_per_treatment(), 
											record.getP4_minimum_minutes_per_treatment(), 
											record.getP4_minimum_frequency(), 
											record.getP4_maximum_frequency(), 
											record.getP4_minimum_pressure(), 
											record.getP4_maximum_pressure()));
			}

			if(record.getP5_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point5", 
											record.getP5_minimum_minutes_per_treatment(), 
											record.getP5_minimum_minutes_per_treatment(), 
											record.getP5_minimum_frequency(), 
											record.getP5_maximum_frequency(), 
											record.getP5_minimum_pressure(), 
											record.getP5_maximum_pressure()));
			}

			if(record.getP6_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point6", 
											record.getP6_minimum_minutes_per_treatment(), 
											record.getP6_minimum_minutes_per_treatment(), 
											record.getP6_minimum_frequency(), 
											record.getP6_maximum_frequency(), 
											record.getP6_minimum_pressure(), 
											record.getP6_maximum_pressure()));
			}

			if(record.getP7_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point7", 
											record.getP7_minimum_minutes_per_treatment(), 
											record.getP7_minimum_minutes_per_treatment(), 
											record.getP7_minimum_frequency(), 
											record.getP7_maximum_frequency(), 
											record.getP7_minimum_pressure(), 
											record.getP7_maximum_pressure()));
			}

			if(record.getP8_minimum_minutes_per_treatment() != 0)
			{
				ppdList.add(createProtocol(	"point8", 
											record.getP8_minimum_minutes_per_treatment(), 
											record.getP8_minimum_minutes_per_treatment(), 
											record.getP8_minimum_frequency(), 
											record.getP8_maximum_frequency(), 
											record.getP8_minimum_pressure(), 
											record.getP8_maximum_pressure()));
			}
			
			ProtocolDTO protocolDTO = new ProtocolDTO();			

			protocolDTO.setTreatmentsPerDay(record.getTreatments_per_day());
			protocolDTO.setType(record.getProtocoltype());
			protocolDTO.setProtocolEntries(ppdList);
			try {
				patientProtocolService.addProtocolToPatient(userId, protocolDTO);
			}catch(HillromException e) {
				e.printStackTrace();
			}				
		}else {
			List<PatientProtocolData> protocol =  patientProtocolService.findOneByPatientUserIdAndStatus(userId, false);
			
			if (protocol.isEmpty()) {
				List<ProtocolEntryDTO> ppdList = new LinkedList<ProtocolEntryDTO>();

				ppdList.add(createProtocol(	null, 
						5, 
						20, 
						5, 
						20, 
						1, 
						10));
				
				ProtocolDTO protocolDTO = new ProtocolDTO();			

				protocolDTO.setTreatmentsPerDay(2);
				protocolDTO.setType("Normal");
				protocolDTO.setProtocolEntries(ppdList);
				try {
					patientProtocolService.addProtocolToPatient(userId, protocolDTO);
				}catch(HillromException e) {
					e.printStackTrace();
				}
			}
		}		
	}
	private ProtocolEntryDTO createProtocol(String treatmentLabel,int minMinutesPerTreatment, int maxMinutesPerTreatment, int minFrequency, int maxFrequency, int minPressure, int maxPressure) {
		// TODO: To check what is last modified time
		ProtocolEntryDTO protocolEntryDTO = new ProtocolEntryDTO();
		protocolEntryDTO.setMaxFrequency(maxFrequency);
		protocolEntryDTO.setMinFrequency(minFrequency);
		protocolEntryDTO.setMinMinutesPerTreatment(minMinutesPerTreatment);
		protocolEntryDTO.setMaxMinutesPerTreatment(maxMinutesPerTreatment);
		if(maxPressure == 0 || Objects.isNull(maxPressure)) {
			protocolEntryDTO.setMaxPressure(10);
		}else {
			protocolEntryDTO.setMaxPressure(maxPressure);
		}
		if(minPressure == 0 || Objects.isNull(minPressure)) {
			protocolEntryDTO.setMinPressure(1);
		}else {
			protocolEntryDTO.setMinPressure(minPressure);
		}
		protocolEntryDTO.setTreatmentLabel(treatmentLabel);
		return protocolEntryDTO;
	}

    private static CellProcessor[] getProcessors() {
        final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(),//private String firstName;
				new NotNull(),//private String lastName;
				new NotNull(),//private String timsID;
				new NotNull(),//private String password;
				new NotNull()//private String email;
        };
        return processors;
    }
    
    @Transactional
	public void createAE(String firstName, 
			String lastName,
			String email,
			String hillromId,
			String password) throws Exception
	{
		java.util.Optional<User> user = userRepository.findOneByEmail(email);
		if(user.isPresent()) {
			User aeUser = user.get();
			aeUser.setHillromId(hillromId);
			aeUser.setPassword(passwordEncoder.encode(password));
			userRepository.save(aeUser);
		}else {
			UserExtensionDTO userExtensionDTO = new UserExtensionDTO();
			userExtensionDTO.setFirstName(firstName);
			userExtensionDTO.setLastName(lastName);
			userExtensionDTO.setHillromId(hillromId);
			userExtensionDTO.setPassword(password);
			userExtensionDTO.setEmail(email);
			userExtensionDTO.setClinicList(null);
			userExtensionDTO.setRole(AuthoritiesConstants.ASSOCIATE_EXECUTIVE);
			userService.createAssocExecutiveUser(userExtensionDTO,true);
		}
	}
	
	public void createAEUser(String filepath) {
		try {
			ICsvBeanReader beanReader = new CsvBeanReader(new FileReader(filepath), CsvPreference.STANDARD_PREFERENCE);
		    // the header elements are used to map the values to the bean
			final String[] headers = {"FirstName","LastName","TimsID","Password","Email"};
		    final CellProcessor[] processors = getProcessors();
		    
		    PortalDeployAECreateDTO portalDeployAECreateDTO = new PortalDeployAECreateDTO();

			boolean valid = true;
		
			while(valid) {
				portalDeployAECreateDTO = beanReader.read(PortalDeployAECreateDTO.class, headers, processors);
		    	
		    	if(Objects.nonNull(portalDeployAECreateDTO)) {
		    		java.util.Optional<User> user = userRepository.findOneByHillromId(portalDeployAECreateDTO.getTimsID());
		    		if(!user.isPresent()) {
		    			createAE(portalDeployAECreateDTO.getFirstName(),portalDeployAECreateDTO.getLastName(), portalDeployAECreateDTO.getEmail(), portalDeployAECreateDTO.getTimsID(), portalDeployAECreateDTO.getPassword());
		    		}
		    	}else {
		    		valid = false;
		    	}
		    }
			beanReader.close();
		}catch (Exception e) {
			e.printStackTrace();
		}		
	}

    private static CellProcessor[] getAEAssocProcessors() {
        final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(),//private String firstName;
				new NotNull()//private String lastName;
        };
        return processors;
    }

	@Transactional
	public void linkPatientProviderClinic(PortalClinicProviderLinkDTO record) {
		Clinic clinic = null;
		java.util.Optional<User> patientUser = null;
		try {
			patientUser = userService.findOneByEmailOrHillromId(record.getPatientHillromId());
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		if(Objects.isNull(record.getClinicHillromId())) {
			return;
		}
		
		if(Objects.nonNull(patientUser) && !patientUser.isPresent()) {
			
		}
		// Create Clinic if not existing
		java.util.Optional<Clinic> existingClinic = clinicRepository.findOneByHillromId(record.getClinicHillromId());
		if (!existingClinic.isPresent()) {
			//TODO: Check with Christine whether can automate specialty or not
			ClinicDTO clinicDTO = new ClinicDTO();
			clinicDTO.setAddress(record.getClinicAddress1());
			clinicDTO.setAddress2(record.getClinicAddress2());
			clinicDTO.setCity(record.getClinicCity());
			clinicDTO.setHillromId(record.getClinicHillromId());
			clinicDTO.setName(record.getClinicName());
			clinicDTO.setPhoneNumber(record.getClinicPhoneNumber());
			clinicDTO.setFaxNumber(record.getClinicFaxNumber());
			clinicDTO.setState(record.getClinicState());
			clinicDTO.setParent(true);
			clinicDTO.setZipcode(record.getClinicZipCode());
			
			try {
				clinic = clinicService.createClinic(clinicDTO);
			}catch(HillromException e) {
				e.printStackTrace();
			}						
		}else {
			clinic = existingClinic.get();
		}

		if (Objects.nonNull(clinic)) {
			
			if(Objects.nonNull(patientUser) && patientUser.isPresent()) {
				//Check the patient associated clinic						
				List<ClinicVO> associatedClinicList = null;
				try {
					associatedClinicList = clinicPatientService.getAssociatedClinicsForPatient(patientUser.get().getId());
				} catch (HillromException e1) {
					e1.printStackTrace();
				}
				
				boolean found = false;
				for(ClinicVO assocClinic : associatedClinicList){
					if(assocClinic.getId().equals(clinic.getId())) {
						found = true;
						break;
					}
				}
				
				if (!found) {
					// Associate Patient to clinic
	
					List<Map<String, String>> clinicList = new LinkedList<Map<String, String>>();
					Map<String,String> clinicMap = new HashMap<String,String>();
					clinicMap.put("id", clinic.getId());
					clinicMap.put("mrnId", null);
					clinicMap.put("notes", null);
					clinicList.add(clinicMap);
					
					try {
						clinicPatientService.associateClinicsToPatient(patientUser.get().getId(), clinicList);
					}catch(HillromException e){
						e.printStackTrace();				
					}
				}
			}
			
			// Create HCP if not existing
			if (Objects.nonNull(record.getProviderNPI())) {
				List<UserExtension> userList = userExtensionRepository.findByNpiNumber(record.getProviderNPI());
				if(userList.size()==0) {
					UserExtension userExtension = new UserExtension();
					userExtension.setCreatedBy("TIMS Java app");
					userExtension.setActivated(true);
					userExtension.setDeleted(false);
					userExtension.setFirstName(record.getProviderFirstName());
					userExtension.setLastName(record.getProviderLastName());
					userExtension.setNpiNumber(record.getProviderNPI());
					userExtension.getAuthorities().add(authorityRepository.findOne(HCP));
					userExtensionRepository.save(userExtension);
					// Associate HCP to clinic
					try {
						hcpClinicService.associateHCPToClinic(clinic.getId(), userExtension.getId());
					}catch(HillromException e){
						e.printStackTrace();
					}
					
					if(Objects.nonNull(patientUser) && patientUser.isPresent()) {
						// Associate Patient to HCP
						List<Map<String, String>> hcpList = new LinkedList<Map<String, String>>();
						Map<String,String> hcpMap = new HashMap<String,String>();
						hcpMap.put("id", userExtension.getId().toString());
						hcpList.add(hcpMap);
						
						try {
							patientHCPService.associateHCPToPatient(patientUser.get().getId(), hcpList);
						}catch(HillromException e){
							e.printStackTrace();
						}
					}

				}else if(userList.size() == 1) {
						// Associate Patient to HCP
						List<Map<String, String>> hcpList = new LinkedList<Map<String, String>>();
						Map<String,String> hcpMap = new HashMap<String,String>();
						hcpMap.put("id", userList.get(0).getId().toString());
						hcpList.add(hcpMap);
						if(Objects.nonNull(patientUser) && patientUser.isPresent()) {											
							try {
								patientHCPService.associateHCPToPatient(patientUser.get().getId(), hcpList);
							}catch(HillromException e){
								e.printStackTrace();							
							}
						}
					// Associate HCP to clinic
					try {
						hcpClinicService.associateHCPToClinic(clinic.getId(), hcpList);
					}catch(HillromException e){
						e.printStackTrace();					
					}
					
				}
			}						
		}
	}
	
	public void linkPatientProviderClinic(String filepath) {
		try {
			ICsvBeanReader beanReader = new CsvBeanReader(new FileReader(filepath), CsvPreference.STANDARD_PREFERENCE);
		    // the header elements are used to map the values to the bean
			final String[] headers = {"PatientHillromId",
					"ClinicHillromId",
					"ClinicName",
					"ClinicAddress1",
					"ClinicAddress2",
					"ClinicCity",
					"ClinicState",
					"ClinicZipCode",
					"ClinicPhoneNumber",
					"ClinicFaxNumber",
					"ProviderFirstName",
					"ProviderLastName",
					"ProviderNPI"};
		    final CellProcessor[] processors = getClinicPatientLinkProcessors();
		    
		    PortalClinicProviderLinkDTO portalClinicProviderLinkDTO = new PortalClinicProviderLinkDTO();

			boolean valid = true;
		
			while(valid) {
				portalClinicProviderLinkDTO = beanReader.read(PortalClinicProviderLinkDTO.class, headers, processors);
				if(Objects.nonNull(portalClinicProviderLinkDTO)) {
					linkPatientProviderClinic(portalClinicProviderLinkDTO);
				}else {
					valid=false;
				}
			}
			beanReader.close();
		}catch (Exception e) {
			e.printStackTrace();			
		}
	}
	private CellProcessor[] getClinicPatientLinkProcessors() {
        final CellProcessor[] processors = new CellProcessor[] {
        		new NotNull(), // private String PatientHillromId;
        		new NotNull(), // private String ClinicHillromId;
        		new ConvertNullTo(null),//private String ClinicName;
        		new ConvertNullTo(null),//private String ClinicAddress1;
        		new ConvertNullTo(null),//private String ClinicAddress2;
        		new ConvertNullTo(null),//private String ClinicCity;
        		new ConvertNullTo(null),//private String ClinicState;
        		new ConvertNullTo(null),//private String ClinicZipCode;
        		new ConvertNullTo(null),//private String ClinicPhoneNumber;
        		new ConvertNullTo(null),//private String ClinicFaxNumber;
        		new ConvertNullTo(null),//private String ProviderFirstName;
        		new ConvertNullTo(null),//private String ProviderLastName;
        		new ConvertNullTo(null)//private String ProviderNPI;
        };
        return processors;
	}
}
