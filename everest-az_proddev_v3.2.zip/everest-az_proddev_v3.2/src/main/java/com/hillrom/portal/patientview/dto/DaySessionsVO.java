package com.hillrom.portal.patientview.dto;


import java.io.Serializable;
import java.util.Comparator;
import java.util.List;

public class DaySessionsVO  implements Serializable,Comparable<DaySessionsVO>,Cloneable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String date;
	private List<DeviceSessionsVO> sessions;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public List<DeviceSessionsVO> getSessions() {
		return sessions;
	}
	public void setSessions(List<DeviceSessionsVO> sessions) {
		this.sessions = sessions;
	}
	
	@Override
	public int compareTo(DaySessionsVO o) {
		return this.getDate().compareTo(o.getDate());
	}
	
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
	}
	@Override
	public String toString() {
		return "DaySessionsVO [date=" + date + ", sessions=" + sessions + "]";
	}
	
}
