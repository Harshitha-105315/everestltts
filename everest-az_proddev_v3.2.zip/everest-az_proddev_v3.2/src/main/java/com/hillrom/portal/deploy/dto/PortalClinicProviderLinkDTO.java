package com.hillrom.portal.deploy.dto;

public class PortalClinicProviderLinkDTO {
	private String PatientHillromId;
	private String ClinicHillromId;
	private String ClinicName;
	private String ClinicAddress1;
	private String ClinicAddress2;
	private String ClinicCity;
	private String ClinicState;
	private String ClinicZipCode;
	private String ClinicPhoneNumber;
	private String ClinicFaxNumber;
	private String ProviderFirstName;
	private String ProviderLastName;
	private String ProviderNPI;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ClinicAddress1 == null) ? 0 : ClinicAddress1.hashCode());
		result = prime * result + ((ClinicAddress2 == null) ? 0 : ClinicAddress2.hashCode());
		result = prime * result + ((ClinicCity == null) ? 0 : ClinicCity.hashCode());
		result = prime * result + ((ClinicFaxNumber == null) ? 0 : ClinicFaxNumber.hashCode());
		result = prime * result + ((ClinicHillromId == null) ? 0 : ClinicHillromId.hashCode());
		result = prime * result + ((ClinicName == null) ? 0 : ClinicName.hashCode());
		result = prime * result + ((ClinicPhoneNumber == null) ? 0 : ClinicPhoneNumber.hashCode());
		result = prime * result + ((ClinicState == null) ? 0 : ClinicState.hashCode());
		result = prime * result + ((ClinicZipCode == null) ? 0 : ClinicZipCode.hashCode());
		result = prime * result + ((PatientHillromId == null) ? 0 : PatientHillromId.hashCode());
		result = prime * result + ((ProviderFirstName == null) ? 0 : ProviderFirstName.hashCode());
		result = prime * result + ((ProviderLastName == null) ? 0 : ProviderLastName.hashCode());
		result = prime * result + ((ProviderNPI == null) ? 0 : ProviderNPI.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortalClinicProviderLinkDTO other = (PortalClinicProviderLinkDTO) obj;
		if (ClinicAddress1 == null) {
			if (other.ClinicAddress1 != null)
				return false;
		} else if (!ClinicAddress1.equals(other.ClinicAddress1))
			return false;
		if (ClinicAddress2 == null) {
			if (other.ClinicAddress2 != null)
				return false;
		} else if (!ClinicAddress2.equals(other.ClinicAddress2))
			return false;
		if (ClinicCity == null) {
			if (other.ClinicCity != null)
				return false;
		} else if (!ClinicCity.equals(other.ClinicCity))
			return false;
		if (ClinicFaxNumber == null) {
			if (other.ClinicFaxNumber != null)
				return false;
		} else if (!ClinicFaxNumber.equals(other.ClinicFaxNumber))
			return false;
		if (ClinicHillromId == null) {
			if (other.ClinicHillromId != null)
				return false;
		} else if (!ClinicHillromId.equals(other.ClinicHillromId))
			return false;
		if (ClinicName == null) {
			if (other.ClinicName != null)
				return false;
		} else if (!ClinicName.equals(other.ClinicName))
			return false;
		if (ClinicPhoneNumber == null) {
			if (other.ClinicPhoneNumber != null)
				return false;
		} else if (!ClinicPhoneNumber.equals(other.ClinicPhoneNumber))
			return false;
		if (ClinicState == null) {
			if (other.ClinicState != null)
				return false;
		} else if (!ClinicState.equals(other.ClinicState))
			return false;
		if (ClinicZipCode == null) {
			if (other.ClinicZipCode != null)
				return false;
		} else if (!ClinicZipCode.equals(other.ClinicZipCode))
			return false;
		if (PatientHillromId == null) {
			if (other.PatientHillromId != null)
				return false;
		} else if (!PatientHillromId.equals(other.PatientHillromId))
			return false;
		if (ProviderFirstName == null) {
			if (other.ProviderFirstName != null)
				return false;
		} else if (!ProviderFirstName.equals(other.ProviderFirstName))
			return false;
		if (ProviderLastName == null) {
			if (other.ProviderLastName != null)
				return false;
		} else if (!ProviderLastName.equals(other.ProviderLastName))
			return false;
		if (ProviderNPI == null) {
			if (other.ProviderNPI != null)
				return false;
		} else if (!ProviderNPI.equals(other.ProviderNPI))
			return false;
		return true;
	}
	public String getPatientHillromId() {
		return PatientHillromId;
	}
	public void setPatientHillromId(String patientHillromId) {
		PatientHillromId = patientHillromId;
	}
	public String getClinicHillromId() {
		return ClinicHillromId;
	}
	public void setClinicHillromId(String clinicHillromId) {
		ClinicHillromId = clinicHillromId;
	}
	public String getClinicName() {
		return ClinicName;
	}
	public void setClinicName(String clinicName) {
		ClinicName = clinicName;
	}
	public String getClinicAddress1() {
		return ClinicAddress1;
	}
	public void setClinicAddress1(String clinicAddress1) {
		ClinicAddress1 = clinicAddress1;
	}
	public String getClinicAddress2() {
		return ClinicAddress2;
	}
	public void setClinicAddress2(String clinicAddress2) {
		ClinicAddress2 = clinicAddress2;
	}
	public String getClinicCity() {
		return ClinicCity;
	}
	public void setClinicCity(String clinicCity) {
		ClinicCity = clinicCity;
	}
	public String getClinicState() {
		return ClinicState;
	}
	public void setClinicState(String clinicState) {
		ClinicState = clinicState;
	}
	public String getClinicZipCode() {
		return ClinicZipCode;
	}
	public void setClinicZipCode(String clinicZipCode) {
		ClinicZipCode = clinicZipCode;
	}
	public String getClinicPhoneNumber() {
		return ClinicPhoneNumber;
	}
	public void setClinicPhoneNumber(String clinicPhoneNumber) {
		ClinicPhoneNumber = clinicPhoneNumber;
	}
	public String getClinicFaxNumber() {
		return ClinicFaxNumber;
	}
	public void setClinicFaxNumber(String clinicFaxNumber) {
		ClinicFaxNumber = clinicFaxNumber;
	}
	public String getProviderFirstName() {
		return ProviderFirstName;
	}
	public void setProviderFirstName(String providerFirstName) {
		ProviderFirstName = providerFirstName;
	}
	public String getProviderLastName() {
		return ProviderLastName;
	}
	public void setProviderLastName(String providerLastName) {
		ProviderLastName = providerLastName;
	}
	public String getProviderNPI() {
		return ProviderNPI;
	}
	public void setProviderNPI(String providerNPI) {
		ProviderNPI = providerNPI;
	}
	public PortalClinicProviderLinkDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
