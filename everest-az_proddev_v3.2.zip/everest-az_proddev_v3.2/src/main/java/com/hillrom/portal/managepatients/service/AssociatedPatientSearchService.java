package com.hillrom.portal.managepatients.service;

import java.util.Objects;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.portal.managepatients.dto.AsscociatedPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientStatsVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientsDetailStatsVO;
import com.hillrom.portal.managepatients.repository.AssociatedPatientSearchRepositoryAE;
import com.hillrom.portal.managepatients.repository.AssociatedPatientSearchRepositoryCA;
import com.hillrom.portal.managepatients.repository.AssociatedPatientSearchRepositoryCG;
import com.hillrom.portal.managepatients.repository.AssociatedPatientSearchRepositoryClinic;
import com.hillrom.portal.managepatients.repository.AssociatedPatientSearchRepositoryHCP;

@Service
@Transactional
public class AssociatedPatientSearchService {
	private final Logger log = LoggerFactory
			.getLogger(AssociatedPatientSearchService.class);
	@Inject 
	private AssociatedPatientSearchRepositoryCA associatedPatientSearchRepositoryCA;

	@Inject 
	private AssociatedPatientSearchRepositoryHCP associatedPatientSearchRepositoryHCP;

	@Inject 
	private AssociatedPatientSearchRepositoryAE associatedPatientSearchRepositoryAE;

	@Inject 
	private AssociatedPatientSearchRepositoryCG associatedPatientSearchRepositoryCG;

	@Inject 
	private AssociatedPatientSearchRepositoryClinic associatedPatientSearchRepositoryClinic;

	public AssociatedPatientStatsVO searchPatientsCAStats(AssociatedPatientSearchDTO dto) {
		AssociatedPatientStatsVO result = new AssociatedPatientStatsVO();
		AssociatedPatientsDetailStatsVO session50 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session80 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session100 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO vest = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO monarch = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO titan = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO multi = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO flagged = new AssociatedPatientsDetailStatsVO();
		
		result.setTotal_patients(associatedPatientSearchRepositoryCA.statsPatientAll(dto, 
				session50, 
				session80, 
				session100,
				vest,
				monarch,
				titan,
				multi,
				flagged));
		result.setVest_patients(vest);
		result.setMonarch_patients(monarch);
		result.setTitan_patients(titan);
		result.setMulti_device_patients(multi);
		result.setFlagged_patients(flagged);
		result.setSession50(session50);
		result.setSession80(session80);
		result.setSession100(session100);
		return result;
	}

	public AssociatedPatientStatsVO searchPatientsHCPStats(AssociatedPatientSearchDTO dto) {
		AssociatedPatientStatsVO result = new AssociatedPatientStatsVO();
		AssociatedPatientsDetailStatsVO session50 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session80 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session100 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO vest = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO monarch = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO titan = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO multi = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO flagged = new AssociatedPatientsDetailStatsVO();
		
		result.setTotal_patients(associatedPatientSearchRepositoryHCP.statsPatientAll(dto, 
				session50, 
				session80, 
				session100,
				vest,
				monarch,
				titan,
				multi,
				flagged));
		result.setVest_patients(vest);
		result.setMonarch_patients(monarch);
		result.setTitan_patients(titan);
		result.setMulti_device_patients(multi);
		result.setFlagged_patients(flagged);
		result.setSession50(session50);
		result.setSession80(session80);
		result.setSession100(session100);
		return result;
	}

	public AssociatedPatientStatsVO searchPatientsAEStats(AssociatedPatientSearchDTO dto) {
		AssociatedPatientStatsVO result = new AssociatedPatientStatsVO();
		AssociatedPatientsDetailStatsVO session50 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session80 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session100 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO vest = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO monarch = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO titan = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO multi = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO flagged = new AssociatedPatientsDetailStatsVO();
		
		result.setTotal_patients(associatedPatientSearchRepositoryAE.statsPatientAll(dto, 
				session50, 
				session80, 
				session100,
				vest,
				monarch,
				titan,
				multi,
				flagged));
		result.setVest_patients(vest);
		result.setMonarch_patients(monarch);
		result.setTitan_patients(titan);
		result.setMulti_device_patients(multi);
		result.setFlagged_patients(flagged);
		result.setSession50(session50);
		result.setSession80(session80);
		result.setSession100(session100);
		return result;
	}

	public AssociatedPatientStatsVO searchPatientsClinicStats(AssociatedPatientSearchDTO dto) {
		AssociatedPatientStatsVO result = new AssociatedPatientStatsVO();
		AssociatedPatientsDetailStatsVO session50 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session80 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session100 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO vest = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO monarch = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO titan = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO multi = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO flagged = new AssociatedPatientsDetailStatsVO();
		
		result.setTotal_patients(associatedPatientSearchRepositoryClinic.statsPatientAll(dto, 
				session50, 
				session80, 
				session100,
				vest,
				monarch,
				titan,
				multi,
				flagged));
		result.setVest_patients(vest);
		result.setMonarch_patients(monarch);
		result.setTitan_patients(titan);
		result.setMulti_device_patients(multi);
		result.setFlagged_patients(flagged);
		result.setSession50(session50);
		result.setSession80(session80);
		result.setSession100(session100);
		return result;
	}
	
	public AsscociatedPatientSearchResultVO searchPatientsCA(AssociatedPatientSearchDTO dto) {
		AsscociatedPatientSearchResultVO result = null;
		if(Objects.isNull(dto)) {
			result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = associatedPatientSearchRepositoryCA.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = associatedPatientSearchRepositoryCA.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = associatedPatientSearchRepositoryCA.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("titan")) {
					result = associatedPatientSearchRepositoryCA.searchPatientTitan(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = associatedPatientSearchRepositoryCA.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("session50")) {
					dto.setSession("session50");
					result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session80")) {
					dto.setSession("session80");
					result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session100")) {
					dto.setSession("session100");
					result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("flagged")) {
					result = associatedPatientSearchRepositoryCA.searchPatientFlagged(dto);					
				}else {
					result = associatedPatientSearchRepositoryCA.searchPatientAll(dto);
				}
			}
		}
		return result;
	}

	public AsscociatedPatientSearchResultVO searchPatientsHCP(AssociatedPatientSearchDTO dto) {
		AsscociatedPatientSearchResultVO result = null;
		if(Objects.isNull(dto)) {
			result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("titan")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientTitan(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("session50")) {
					dto.setSession("session50");
					result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session80")) {
					dto.setSession("session80");
					result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session100")) {
					dto.setSession("session100");
					result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("flagged")) {
					result = associatedPatientSearchRepositoryHCP.searchPatientFlagged(dto);					
				}else {
					result = associatedPatientSearchRepositoryHCP.searchPatientAll(dto);
				}
			}
		}
		return result;
	}

	public AsscociatedPatientSearchResultVO searchPatientsAE(AssociatedPatientSearchDTO dto) {
		AsscociatedPatientSearchResultVO result = null;
		if(Objects.isNull(dto)) {
			result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = associatedPatientSearchRepositoryAE.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = associatedPatientSearchRepositoryAE.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = associatedPatientSearchRepositoryAE.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("titan")) {
					result = associatedPatientSearchRepositoryAE.searchPatientTitan(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = associatedPatientSearchRepositoryAE.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("session50")) {
					dto.setSession("session50");
					result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session80")) {
					dto.setSession("session80");
					result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session100")) {
					dto.setSession("session100");
					result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("flagged")) {
					result = associatedPatientSearchRepositoryAE.searchPatientFlagged(dto);					
				}else {
					result = associatedPatientSearchRepositoryAE.searchPatientAll(dto);
				}
			}
		}
		return result;
	}

	public AsscociatedPatientSearchResultVO searchPatientsClinic(AssociatedPatientSearchDTO dto) {
		AsscociatedPatientSearchResultVO result = null;
		if(Objects.isNull(dto)) {
			result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("session50")) {
					dto.setSession("session50");
					result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session80")) {
					dto.setSession("session80");
					result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session100")) {
					dto.setSession("session100");
					result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("flagged")) {
					result = associatedPatientSearchRepositoryClinic.searchPatientFlagged(dto);					
				}else {
					result = associatedPatientSearchRepositoryClinic.searchPatientAll(dto);
				}
			}
		}
		return result;
	}

	public AssociatedPatientStatsVO searchPatientsCGStats(AssociatedPatientSearchDTO dto) {
		AssociatedPatientStatsVO result = new AssociatedPatientStatsVO();
		AssociatedPatientsDetailStatsVO session50 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session80 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO session100 = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO vest = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO monarch = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO titan = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO multi = new AssociatedPatientsDetailStatsVO();
		AssociatedPatientsDetailStatsVO flagged = new AssociatedPatientsDetailStatsVO();
		
		result.setTotal_patients(associatedPatientSearchRepositoryCG.statsPatientAll(dto, 
				session50, 
				session80, 
				session100,
				vest,
				monarch,
				titan,
				multi,
				flagged));
		result.setVest_patients(vest);
		result.setMonarch_patients(monarch);
		result.setTitan_patients(titan);
		result.setMulti_device_patients(multi);
		result.setFlagged_patients(flagged);
		result.setSession50(session50);
		result.setSession80(session80);
		result.setSession100(session100);
		return result;
	}
	public AsscociatedPatientSearchResultVO searchPatientsCG(AssociatedPatientSearchDTO dto) {
		AsscociatedPatientSearchResultVO result = null;
		if(Objects.isNull(dto)) {
			result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = associatedPatientSearchRepositoryCG.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = associatedPatientSearchRepositoryCG.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = associatedPatientSearchRepositoryCG.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("titan")) {
					result = associatedPatientSearchRepositoryCG.searchPatientTitan(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = associatedPatientSearchRepositoryCG.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("session50")) {
					dto.setSession("session50");
					result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session80")) {
					dto.setSession("session80");
					result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("session100")) {
					dto.setSession("session100");
					result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("flagged")) {
					result = associatedPatientSearchRepositoryCG.searchPatientFlagged(dto);					
				}else {
					result = associatedPatientSearchRepositoryCG.searchPatientAll(dto);
				}
			}
		}
		return result;
	}
}
