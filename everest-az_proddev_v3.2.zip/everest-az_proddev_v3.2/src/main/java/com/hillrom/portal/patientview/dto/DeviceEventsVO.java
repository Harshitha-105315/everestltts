package com.hillrom.portal.patientview.dto;

public class DeviceEventsVO {
	private String time;
	private String name;
    private String frequency;
    private String  pressure;
    private String duration;
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getPressure() {
		return pressure;
	}
	public void setPressure(String pressure) {
		this.pressure = pressure;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "DeviceEventsVO [time=" + time + ", name=" + name + ", frequency=" + frequency + ", pressure=" + pressure
				+ ", duration=" + duration + "]";
	}
    
	
}
