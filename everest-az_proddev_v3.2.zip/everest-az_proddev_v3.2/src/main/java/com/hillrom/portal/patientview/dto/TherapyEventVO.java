package com.hillrom.portal.patientview.dto;

public class TherapyEventVO {

	private Integer frequency;
	private boolean freq_deviated;
	private Integer pressure;
	private boolean press_deviated;
	private Integer intensity;
	private boolean intensity_deviated;
	private long duration;
	private boolean dur_deviated;
	/**
	 * @return the frequency
	 */
	public Integer getFrequency() {
		return frequency;
	}
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}
	/**
	 * @return the freq_deviated
	 */
	public boolean isFreq_deviated() {
		return freq_deviated;
	}
	/**
	 * @param freq_deviated the freq_deviated to set
	 */
	public void setFreq_deviated(boolean freq_deviated) {
		this.freq_deviated = freq_deviated;
	}
	/**
	 * @return the pressure
	 */
	public Integer getPressure() {
		return pressure;
	}
	/**
	 * @param pressure the pressure to set
	 */
	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}
	/**
	 * @return the press_deviated
	 */
	public boolean isPress_deviated() {
		return press_deviated;
	}
	/**
	 * @param press_deviated the press_deviated to set
	 */
	public void setPress_deviated(boolean press_deviated) {
		this.press_deviated = press_deviated;
	}
 	/**
	 * @return the intensity
	 */

	public Integer getIntensity() {
		return intensity;
	}
	/**
	 * @param Intensity the Intensity to set
	 */
	public void setIntensity(Integer intensity) {
		this.intensity = intensity;
	}
	/**
	 * @return the intensity_deviated
	 */
	public boolean isIntensity_deviated() {
		return intensity_deviated;
	}
	/**
	 * @param intensity_deviated the intensity_deviated to set
	 */
	public void setIntensity_deviated(boolean intensity_deviated) {
		this.intensity_deviated = intensity_deviated;
	}
	/**
	 * @return the duration
	 */
	public long getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(long duration) {
		this.duration = duration;
	}
	/**
	 * @return the dur_deviated
	 */
	public boolean isDur_deviated() {
		return dur_deviated;
	}
	/**
	 * @param dur_deviated the dur_deviated to set
	 */
	public void setDur_deviated(boolean dur_deviated) {
		this.dur_deviated = dur_deviated;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (dur_deviated ? 1231 : 1237);
		result = prime * result + (int) (duration ^ (duration >>> 32));
		result = prime * result + (freq_deviated ? 1231 : 1237);
		result = prime * result + ((frequency == null) ? 0 : frequency.hashCode());
		result = prime * result + (press_deviated ? 1231 : 1237);
		result = prime * result + ((pressure == null) ? 0 : pressure.hashCode());
		result = prime * result + (intensity_deviated ? 1231 : 1237);
		result = prime * result + ((intensity == null) ? 0 : intensity.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TherapyEventVO other = (TherapyEventVO) obj;
		if (dur_deviated != other.dur_deviated)
			return false;
		if (duration != other.duration)
			return false;
		if (freq_deviated != other.freq_deviated)
			return false;
		if (frequency == null) {
			if (other.frequency != null)
				return false;
		} else if (!frequency.equals(other.frequency))
			return false;
		if (press_deviated != other.press_deviated)
			return false;
		if (pressure == null) {
			if (other.pressure != null)
				return false;
		} else if (!pressure.equals(other.pressure))
			return false;
		if (intensity_deviated != other.intensity_deviated)
			return false;
		if (intensity == null) {
			if (other.intensity != null)
				return false;
		} else if (!intensity.equals(other.intensity))
			return false;	
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TherapyEventVO [frequency=" + frequency + ", freq_deviated=" + freq_deviated
		 + ", pressure=" + pressure + ", press_deviated=" + press_deviated 
		 + ", intensity=" + intensity + ", intensity_deviated=" + intensity_deviated 
		 + ", duration=" + duration + ", dur_deviated=" + dur_deviated
				+ "]";
	}

}
