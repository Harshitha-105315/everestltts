package com.hillrom.portal.managepatients.dto;

public class AllPatientSearchDTO {
	
	String gender;		
	String clinicSts;	
	String patientSts;	
	String deviceSts;
	String transmission;
	String country;
	String state;
	String city;
	String range;
	String type;
	String sortBy;	
	String sortOrder;
	String ageRange;
	
	int pageNo;
	int pageSize;
	String pattern;
	boolean countOnly;
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getClinicSts() {
		return clinicSts;
	}
	public void setClinicSts(String clinicSts) {
		this.clinicSts = clinicSts;
	}
	public String getPatientSts() {
		return patientSts;
	}
	public void setPatientSts(String patientSts) {
		this.patientSts = patientSts;
	}
	public String getDeviceSts() {
		return deviceSts;
	}
	public void setDeviceSts(String deviceSts) {
		this.deviceSts = deviceSts;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	public boolean isCountOnly() {
		return countOnly;
	}
	public void setCountOnly(boolean countOnly) {
		this.countOnly = countOnly;
	}
	/**
	 * @return the ageRange
	 */
	public String getAgeRange() {
		return ageRange;
	}
	/**
	 * @param ageRange the ageRange to set
	 */
	public void setAgeRange(String ageRange) {
		this.ageRange = ageRange;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AllPatientSearchDTO [gender=" + gender + ", clinicSts=" + clinicSts + ", patientSts=" + patientSts
				+ ", deviceSts=" + deviceSts + ", transmission=" + transmission + ", country=" + country + ", state="
				+ state + ", city=" + city + ", range=" + range + ", type=" + type + ", sortBy=" + sortBy
				+ ", sortOrder=" + sortOrder + ", ageRange=" + ageRange + ", pageNo=" + pageNo + ", pageSize="
				+ pageSize + ", pattern=" + pattern + ", countOnly=" + countOnly + "]";
	}
	public AllPatientSearchDTO(String gender, String clinicSts, String patientSts, String deviceSts,
			String transmission, String country, String state, String city, String range, String type, String sortBy,
			String sortOrder, String ageRange, int pageNo, int pageSize, String pattern, boolean countOnly) {
		super();
		this.gender = gender;
		this.clinicSts = clinicSts;
		this.patientSts = patientSts;
		this.deviceSts = deviceSts;
		this.transmission = transmission;
		this.country = country;
		this.state = state;
		this.city = city;
		this.range = range;
		this.type = type;
		this.sortBy = sortBy;
		this.sortOrder = sortOrder;
		this.ageRange = ageRange;
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.pattern = pattern;
		this.countOnly = countOnly;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ageRange == null) ? 0 : ageRange.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((clinicSts == null) ? 0 : clinicSts.hashCode());
		result = prime * result + (countOnly ? 1231 : 1237);
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((deviceSts == null) ? 0 : deviceSts.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + pageNo;
		result = prime * result + pageSize;
		result = prime * result + ((patientSts == null) ? 0 : patientSts.hashCode());
		result = prime * result + ((pattern == null) ? 0 : pattern.hashCode());
		result = prime * result + ((range == null) ? 0 : range.hashCode());
		result = prime * result + ((sortBy == null) ? 0 : sortBy.hashCode());
		result = prime * result + ((sortOrder == null) ? 0 : sortOrder.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((transmission == null) ? 0 : transmission.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AllPatientSearchDTO other = (AllPatientSearchDTO) obj;
		if (ageRange == null) {
			if (other.ageRange != null)
				return false;
		} else if (!ageRange.equals(other.ageRange))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (clinicSts == null) {
			if (other.clinicSts != null)
				return false;
		} else if (!clinicSts.equals(other.clinicSts))
			return false;
		if (countOnly != other.countOnly)
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (deviceSts == null) {
			if (other.deviceSts != null)
				return false;
		} else if (!deviceSts.equals(other.deviceSts))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (pageNo != other.pageNo)
			return false;
		if (pageSize != other.pageSize)
			return false;
		if (patientSts == null) {
			if (other.patientSts != null)
				return false;
		} else if (!patientSts.equals(other.patientSts))
			return false;
		if (pattern == null) {
			if (other.pattern != null)
				return false;
		} else if (!pattern.equals(other.pattern))
			return false;
		if (range == null) {
			if (other.range != null)
				return false;
		} else if (!range.equals(other.range))
			return false;
		if (sortBy == null) {
			if (other.sortBy != null)
				return false;
		} else if (!sortBy.equals(other.sortBy))
			return false;
		if (sortOrder == null) {
			if (other.sortOrder != null)
				return false;
		} else if (!sortOrder.equals(other.sortOrder))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (transmission == null) {
			if (other.transmission != null)
				return false;
		} else if (!transmission.equals(other.transmission))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	public AllPatientSearchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
