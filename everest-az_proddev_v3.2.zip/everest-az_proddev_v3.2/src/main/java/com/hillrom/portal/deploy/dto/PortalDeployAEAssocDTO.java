package com.hillrom.portal.deploy.dto;

public class PortalDeployAEAssocDTO {
	private String ZipCode;
	private String TimsID;
	public String getZipCode() {
		return ZipCode;
	}
	public void setZipCode(String zipCode) {
		ZipCode = zipCode;
	}
	public String getTimsID() {
		return TimsID;
	}
	public void setTimsID(String timsID) {
		TimsID = timsID;
	}
	public PortalDeployAEAssocDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((TimsID == null) ? 0 : TimsID.hashCode());
		result = prime * result + ((ZipCode == null) ? 0 : ZipCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PortalDeployAEAssocDTO other = (PortalDeployAEAssocDTO) obj;
		if (TimsID == null) {
			if (other.TimsID != null)
				return false;
		} else if (!TimsID.equals(other.TimsID))
			return false;
		if (ZipCode == null) {
			if (other.ZipCode != null)
				return false;
		} else if (!ZipCode.equals(other.ZipCode))
			return false;
		return true;
	}
	
}
