package com.hillrom.portal.managehcp.rest;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.security.xauth.TokenProvider;
import com.hillrom.vest.service.AdvancedSearchService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.web.rest.dto.AdvancedHcpDTO;
import com.hillrom.vest.web.rest.dto.HcpVO;
import com.hillrom.vest.web.rest.util.PaginationUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Manage HCP", description = "Search HCP : Implemented", tags = { "Manage HCP" })
public class SearchHCP {
	@Inject
	private AdvancedSearchService advancedSearchService;

	@Inject
	TokenProvider tokenProvider;
	
	@Inject
	private UserService userService;
	@ApiOperation(httpMethod = "GET", value = "HCP Advanced search", response = HcpVO.class, responseContainer="List")
	@RequestMapping(value = "/advancedSearch/hcp", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> searchHcpsAssociated(@RequestParam(value = "country" , required = false) String country,
    			  @RequestParam(value = "name", required = false) String name,
                  @RequestParam(value = "state" , required = false) String state,
                  @RequestParam(value = "city" , required = false) String city,
                  @RequestParam(value = "providerSpecialty" , required = false) String providerSpecialty,
                  @RequestParam(value = "page" , required = false) Integer offset,
                  @RequestParam(value = "per_page", required = false) Integer limit,
                  @RequestParam(value = "sort_by", required = false) String sortBy,
                  @RequestParam(value = "status", required = false) String status,
                  @RequestParam(value = "asc",required = false) Boolean isAscending)
                  throws URISyntaxException {
                  AdvancedHcpDTO advancedHcpDTO = new AdvancedHcpDTO();
            Map<String,Boolean> sortOrder = new HashMap<>();
            if(sortBy != null  && !sortBy.equals("")) {
                   isAscending =  (isAscending != null)?  isAscending : true;
                   sortOrder.put(sortBy, isAscending);
            }

           Page<HcpVO> page;
           
           try {
		   			List<String> countryList = null;
		   			List<String> stateList = null;
		   			List<String> cityList = null;
		   			
		   			if(Objects.nonNull(country)) {
		   				countryList = new ArrayList<String>();
		   				countryList.add(country);
		   			}
		   			
		   			if(Objects.nonNull(state)) {
		   				stateList = new ArrayList<String>();
		   				stateList.add(state);
		   			}
		   			
		   			if(Objects.nonNull(city)) {
		   				cityList = new ArrayList<String>();			
		   				cityList.add(city);
		   			}
		   		  advancedHcpDTO.setStatus(status);
                  advancedHcpDTO.setName(name);
                  advancedHcpDTO.setCountry(countryList);
                  advancedHcpDTO.setState(stateList);
                  advancedHcpDTO.setCity(cityList);
                  advancedHcpDTO.setSpecialty(providerSpecialty);
                  page = advancedSearchService.advancedSearchHcps(advancedHcpDTO,PaginationUtil.generatePageRequest(offset, limit),sortOrder);
                  HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/advancedSearch/hcp", offset, limit);
                  return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
           } catch (HillromException e) {
                  return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
           }
    }
	@ApiOperation(httpMethod = "GET", value = "HCP Advanced search", response = HcpVO.class, responseContainer="List")
	@RequestMapping(value = "/hcp/advanced/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> searchHcps(@RequestParam(value = "country" , required = false) String country,
    			  @RequestParam(value = "name", required = false) String name,
                  @RequestParam(value = "state" , required = false) String state,
                  @RequestParam(value = "city" , required = false) String city,
                  @RequestParam(value = "providerSpecialty" , required = false) String providerSpecialty,
                  @RequestParam(value = "page" , required = false) Integer offset,
                  @RequestParam(value = "per_page", required = false) Integer limit,
                  @RequestParam(value = "sort_by", required = false) String sortBy,
                  @RequestParam(value = "status", required = false) String status,
                  @RequestParam(value = "clinicId", required = false) String clinicId,
                  @RequestParam(value = "asc",required = false) Boolean isAscending,
                  @RequestHeader(value="x-auth-token",required=true)String authToken)
                  throws URISyntaxException {
		Long userId = tokenProvider.getUserIdFromToken(authToken);
                  AdvancedHcpDTO advancedHcpDTO = new AdvancedHcpDTO();
            Map<String,Boolean> sortOrder = new HashMap<>();
            if(sortBy != null  && !sortBy.equals("")) {
                   isAscending =  (isAscending != null)?  isAscending : true;
                   sortOrder.put(sortBy, isAscending);
            }
           Page<HcpVO> page;
           try {
		   			List<String> countryList = null;
		   			List<String> stateList = null;
		   			List<String> cityList = null;
		   			if(Objects.isNull(name)) {
		   			if(Objects.nonNull(country)) {
		   				countryList = new ArrayList<String>();
		   				countryList.add(country);
		   			}
		   			if(Objects.nonNull(state)) {
		   				stateList = new ArrayList<String>();
		   				stateList.add(state);
		   			}
		   			if(Objects.nonNull(city)) {
		   				cityList = new ArrayList<String>();			
		   				cityList.add(city);
		   			}
		   		  }
		   		  advancedHcpDTO.setStatus(status);
                  advancedHcpDTO.setName(name);
                  advancedHcpDTO.setCountry(countryList);
                  advancedHcpDTO.setState(stateList);
                  advancedHcpDTO.setCity(cityList);
                  advancedHcpDTO.setSpecialty(providerSpecialty);
                  advancedHcpDTO.setClinicId(clinicId);
                  page = advancedSearchService.advancedSearchHcp(advancedHcpDTO, userId,PaginationUtil.generatePageRequest(offset, limit),sortOrder);
                  HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/advancedSearch/hcp", offset, limit);
                  List<HcpVO> content = page.getContent();
                  content.forEach(x->x.setEmail(userService.encryptData(x.getEmail())));
                  return new ResponseEntity<>(content, headers, HttpStatus.OK);
           } catch (HillromException e) {
                  return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
           }
    }
}
