package com.hillrom.portal.patientview.dto;

import java.util.Date;
import java.util.List;

public class PatientDetailsVO {
	private String firstName;
	private String lastName;
	private String hillromId;
	private String dob;
	private Boolean flagged;
	private List<DiagnosisCodesVO> diagnosisCodes;
	private List<ClinicsVO> clinics;
	private List<ProvidersVO> providers;
	private Boolean isDeleted;
	private String inactiveReason;
	private String reportRequester;
	private String reportRanDate;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getHillromId() {
		return hillromId;
	}

	public void setHillromId(String hillromId) {
		this.hillromId = hillromId;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean getFlagged() {
		return flagged;
	}

	public void setFlagged(Boolean flagged) {
		this.flagged = flagged;
	}

	public List<DiagnosisCodesVO> getDiagnosisCodes() {
		return diagnosisCodes;
	}

	public void setDiagnosisCodes(List<DiagnosisCodesVO> diagnosisCodes) {
		this.diagnosisCodes = diagnosisCodes;
	}

	public List<ClinicsVO> getClinics() {
		return clinics;
	}

	public void setClinics(List<ClinicsVO> clinics) {
		this.clinics = clinics;
	}

	public List<ProvidersVO> getProviders() {
		return providers;
	}

	public void setProviders(List<ProvidersVO> providers) {
		this.providers = providers;
	}

	public String getInactiveReason() {
		return inactiveReason;
	}

	public void setInactiveReason(String inactiveReason) {
		this.inactiveReason = inactiveReason;
	}

	public String getReportRequester() {
		return reportRequester;
	}

	public void setReportRequester(String reportRequester) {
		this.reportRequester = reportRequester;
	}

	public String getReportRanDate() {
		return reportRanDate;
	}

	public void setReportRanDate(String reportRanDate) {
		this.reportRanDate = reportRanDate;
	}
}
