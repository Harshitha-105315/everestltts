package com.hillrom.portal.managepatients.rest;

import static com.hillrom.vest.security.AuthoritiesConstants.ADMIN;
import static com.hillrom.vest.security.AuthoritiesConstants.ASSOCIATE_EXECUTIVE;
import static com.hillrom.vest.security.AuthoritiesConstants.CLINIC_ADMIN;
import static com.hillrom.vest.security.AuthoritiesConstants.CUSTOMER_SERVICES;
import static com.hillrom.vest.security.AuthoritiesConstants.HCP;
import static com.hillrom.vest.security.AuthoritiesConstants.CARE_GIVER;

import java.net.URISyntaxException;
import java.util.Objects;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.portal.managepatients.dto.AllPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AllPatientStatVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientStatsVO;
import com.hillrom.portal.managepatients.service.AllPatientSearchService;
import com.hillrom.portal.managepatients.service.AssociatedPatientSearchService;
import com.hillrom.vest.security.xauth.TokenProvider;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Manage Patient Stats", description = "Retrieve statistics for manage patients : implemented", tags = { "Manage Patient Stats" })
public class StatsResource {
	private final Logger log = LoggerFactory.getLogger(StatsResource.class);
	
	@Inject
	AllPatientSearchService allPatientSearchService;
	
	@Inject
	AssociatedPatientSearchService associatedPatientSearchService;
	
	@Inject TokenProvider tokenProvider;
	
	@ApiOperation(httpMethod = "GET", value = "Hillrom role stats for patients", response = AllPatientStatVO.class)
	@RequestMapping(value = "/patient/manage/stats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES})
 	public AllPatientStatVO getPatientAssociatedCount(
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "clinicSts", required = false) String clinicSts,	
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "country", required = false) String country,
 			@RequestParam(value = "state", required = false) String state,
 			@RequestParam(value = "city", required = false) String city,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "ageRange", required = false) String ageRange
 			) throws URISyntaxException
 	{	
		AllPatientSearchDTO dto = new AllPatientSearchDTO();
		
		dto.setClinicSts(clinicSts);
		dto.setDeviceSts(deviceSts);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setRange(range);
		dto.setTransmission(transmission);
		dto.setCity(city);
		dto.setCountry(country);
		dto.setState(state);
		dto.setAgeRange(ageRange);
		return allPatientSearchService.getStats(dto);		
 	}	

	@ApiOperation(httpMethod = "GET", value = "Hillrom role patient stats by clinic", response = AssociatedPatientStatsVO.class)
	@RequestMapping(value = "/patient/manage/stats/{clinicId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES})
	public AssociatedPatientStatsVO getClinicWisePatientStats(
			@ApiParam(value = "clinicId", required = false) @PathVariable String clinicId, 			
			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to) {
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsClinicStats(dto);
	}
	
	@ApiOperation(httpMethod = "GET", value = "Clinic admin stats by associated patients", response = AssociatedPatientStatsVO.class)
	@RequestMapping(value = "/patient/manage/stats/ca", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({CLINIC_ADMIN})
	public AssociatedPatientStatsVO getClinicAdminPatientStats(
			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to) {
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsCAStats(dto);
	}
	
	@ApiOperation(httpMethod = "GET", value = "Provider stats by associated patients", response = AssociatedPatientStatsVO.class)
	@RequestMapping(value = "/patient/manage/stats/hcp", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({HCP})
	public AssociatedPatientStatsVO getHCPPatientStats(
			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to) {
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsHCPStats(dto);
	}
	
	@ApiOperation(httpMethod = "GET", value = "AE stats by associated patients", response = AssociatedPatientStatsVO.class)
	@RequestMapping(value = "/patient/manage/stats/ae", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ASSOCIATE_EXECUTIVE})
	public AssociatedPatientStatsVO getAEPatientStats(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to) {
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsAEStats(dto);
	}

	@ApiOperation(httpMethod = "GET", value = "AE stats by associated patients", response = AssociatedPatientStatsVO.class)
	@RequestMapping(value = "/patient/manage/stats/cg", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({CARE_GIVER})
	public AssociatedPatientStatsVO getCGPatientStats(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to) {
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsCGStats(dto);
	}
}
