package com.hillrom.portal.patientview.dto;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.util.MMDDYYYYLocalDateSerializer;
import com.hillrom.vest.web.rest.dto.HillromTypeCodeFormatDTO;

 public class FlaggedPatientVO {

 	private Long id;
	private String email;
	private String firstName;
	private String lastName;
	private Boolean isDeleted;
	private String zipcode;
	private String address;
	private String city;

 	@JsonSerialize(using = MMDDYYYYLocalDateSerializer.class)
	private LocalDate dob;

 	private String gender;
	private String title;
	private String hillromId;
	private String langKey;
	private String middleName;
	private String state;
	private String mobilePhone;
	private String primaryPhone;
	private DateTime createdAt;
	private Boolean isActivated;
	private int adherence;
	private Date lastTransmissionDate;
	private Date lastTransmissionDateMonarch;
	private DateTime lastLoggedInAt;

 	private List<Map<String,String>> clinics = new LinkedList<>();


 	private UserExtension hcp;

 	private Map<String,Object> clinicMRNId = new HashMap<>();
	private String clinicNamesCSV;
	private String hcpNamesCSV;
	private String mrnId;
	private boolean isExpired;
	private double hoursOfUsage;
	private String serialNumber;
	private String deviceType;

 	private String vestGarmentColor;
	private String vestGarmentSize;
	private String vestGarmentType;
	private String monarchGarmentColor;
	private String monarchGarmentSize;
	private String monarchGarmentType;

	private String titanGarmentColor;
	private String titanGarmentSize;
	private String titanGarmentType;

 	private Boolean tagged;

 	private List<HillromTypeCodeFormatDTO> vestTypeCodeList;
	private List<HillromTypeCodeFormatDTO> monrachTypeCodeList;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getHillromId() {
		return hillromId;
	}
	public void setHillromId(String hillromId) {
		this.hillromId = hillromId;
	}
	public String getLangKey() {
		return langKey;
	}
	public void setLangKey(String langKey) {
		this.langKey = langKey;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getPrimaryPhone() {
		return primaryPhone;
	}
	public void setPrimaryPhone(String primaryPhone) {
		this.primaryPhone = primaryPhone;
	}
	public DateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(DateTime createdAt) {
		this.createdAt = createdAt;
	}
	public Boolean getIsActivated() {
		return isActivated;
	}
	public void setIsActivated(Boolean isActivated) {
		this.isActivated = isActivated;
	}
	public int getAdherence() {
		return adherence;
	}
	public void setAdherence(int adherence) {
		this.adherence = adherence;
	}
	public Date getLastTransmissionDate() {
		return lastTransmissionDate;
	}
	public void setLastTransmissionDate(Date lastTransmissionDate) {
		this.lastTransmissionDate = lastTransmissionDate;
	}
	public Date getLastTransmissionDateMonarch() {
		return lastTransmissionDateMonarch;
	}
	public void setLastTransmissionDateMonarch(Date lastTransmissionDateMonarch) {
		this.lastTransmissionDateMonarch = lastTransmissionDateMonarch;
	}
	public DateTime getLastLoggedInAt() {
		return lastLoggedInAt;
	}
	public void setLastLoggedInAt(DateTime lastLoggedInAt) {
		this.lastLoggedInAt = lastLoggedInAt;
	}
	public List<Map<String, String>> getClinics() {
		return clinics;
	}
	public void setClinics(List<Map<String, String>> clinics) {
		this.clinics = clinics;
	}
	public UserExtension getHcp() {
		return hcp;
	}
	public void setHcp(UserExtension hcp) {
		this.hcp = hcp;
	}
	public Map<String, Object> getClinicMRNId() {
		return clinicMRNId;
	}
	public void setClinicMRNId(Map<String, Object> clinicMRNId) {
		this.clinicMRNId = clinicMRNId;
	}
	public String getClinicNamesCSV() {
		return clinicNamesCSV;
	}
	public void setClinicNamesCSV(String clinicNamesCSV) {
		this.clinicNamesCSV = clinicNamesCSV;
	}
	public String getHcpNamesCSV() {
		return hcpNamesCSV;
	}
	public void setHcpNamesCSV(String hcpNamesCSV) {
		this.hcpNamesCSV = hcpNamesCSV;
	}
	public String getMrnId() {
		return mrnId;
	}
	public void setMrnId(String mrnId) {
		this.mrnId = mrnId;
	}
	public boolean isExpired() {
		return isExpired;
	}
	public void setExpired(boolean isExpired) {
		this.isExpired = isExpired;
	}
	public double getHoursOfUsage() {
		return hoursOfUsage;
	}
	public void setHoursOfUsage(double hoursOfUsage) {
		this.hoursOfUsage = hoursOfUsage;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getVestGarmentColor() {
		return vestGarmentColor;
	}
	public void setVestGarmentColor(String vestGarmentColor) {
		this.vestGarmentColor = vestGarmentColor;
	}
	public String getVestGarmentSize() {
		return vestGarmentSize;
	}
	public void setVestGarmentSize(String vestGarmentSize) {
		this.vestGarmentSize = vestGarmentSize;
	}
	public String getVestGarmentType() {
		return vestGarmentType;
	}
	public void setVestGarmentType(String vestGarmentType) {
		this.vestGarmentType = vestGarmentType;
	}
	public String getMonarchGarmentColor() {
		return monarchGarmentColor;
	}
	public void setMonarchGarmentColor(String monarchGarmentColor) {
		this.monarchGarmentColor = monarchGarmentColor;
	}
	public String getMonarchGarmentSize() {
		return monarchGarmentSize;
	}
	public void setMonarchGarmentSize(String monarchGarmentSize) {
		this.monarchGarmentSize = monarchGarmentSize;
	}
	public String getMonarchGarmentType() {
		return monarchGarmentType;
	}
	public void setMonarchGarmentType(String monarchGarmentType) {
		this.monarchGarmentType = monarchGarmentType;
	}
	public String getTitanGarmentColor() {
		return titanGarmentColor;
	}
	public void setTitanGarmentColor(String titanGarmentColor) {
		this.titanGarmentColor = titanGarmentColor;
	}
	public String getTitanGarmentSize() {
		return titanGarmentSize;
	}
	public void setTitanGarmentSize(String titanGarmentSize) {
		this.titanGarmentSize = titanGarmentSize;
	}
	public String getTitanGarmentType() {
		return titanGarmentType;
	}
	public void setTitanGarmentType(String titanGarmentType) {
		this.titanGarmentType = titanGarmentType;
	}
	public List<HillromTypeCodeFormatDTO> getVestTypeCodeList() {
		return vestTypeCodeList;
	}
	public void setVestTypeCodeList(List<HillromTypeCodeFormatDTO> vestTypeCodeList) {
		this.vestTypeCodeList = vestTypeCodeList;
	}
	public List<HillromTypeCodeFormatDTO> getMonrachTypeCodeList() {
		return monrachTypeCodeList;
	}
	public void setMonrachTypeCodeList(List<HillromTypeCodeFormatDTO> monrachTypeCodeList) {
		this.monrachTypeCodeList = monrachTypeCodeList;
	}
	public Boolean getTagged() {
		return tagged;
	}
	public void setTagged(Boolean tagged) {
		this.tagged = tagged;
	}


 }
