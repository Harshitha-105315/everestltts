package com.hillrom.portal.managepatients.dto;

import org.joda.time.LocalDate;

public class AssociatedPatientSearchDTO {
	Long userId;
	String clinicId;
	String gender;
	String patientSts;
	String deviceSts;
	String transmission;
	String range;
	String type;
	String session;
	String providerId;
	String pattern;
	LocalDate from;
	LocalDate to;
	String deviceType;
	String ageRange;
	String timeZone;
	String countOnly;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getClinicId() {
		return clinicId;
	}
	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPatientSts() {
		return patientSts;
	}
	public void setPatientSts(String patientSts) {
		this.patientSts = patientSts;
	}
	public String getDeviceSts() {
		return deviceSts;
	}
	public void setDeviceSts(String deviceSts) {
		this.deviceSts = deviceSts;
	}
	public String getTransmission() {
		return transmission;
	}
	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	public LocalDate getFrom() {
		return from;
	}
	public void setFrom(LocalDate from) {
		this.from = from;
	}
	public LocalDate getTo() {
		return to;
	}
	public void setTo(LocalDate to) {
		this.to = to;
	}
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
		return deviceType;
	}
	/**
	 * @param deviceType the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	/**
	 * @return the ageRange
	 */
	public String getAgeRange() {
		return ageRange;
	}
	/**
	 * @param ageRange the ageRange to set
	 */
	public void setAgeRange(String ageRange) {
		this.ageRange = ageRange;
	}
	/**
	 * @return the countOnly
	 */
	public String isCountOnly() {
		return countOnly;
	}
	/**
	 * @param countOnly the countOnly to set
	 */
	public void setCountOnly(String countOnly) {
		this.countOnly = countOnly;
	}	
	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}
	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ageRange == null) ? 0 : ageRange.hashCode());
		result = prime * result + ((clinicId == null) ? 0 : clinicId.hashCode());
		result = prime * result + ((countOnly == null) ? 0 : countOnly.hashCode());
		result = prime * result + ((deviceSts == null) ? 0 : deviceSts.hashCode());
		result = prime * result + ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((patientSts == null) ? 0 : patientSts.hashCode());
		result = prime * result + ((pattern == null) ? 0 : pattern.hashCode());
		result = prime * result + ((providerId == null) ? 0 : providerId.hashCode());
		result = prime * result + ((range == null) ? 0 : range.hashCode());
		result = prime * result + ((session == null) ? 0 : session.hashCode());
		result = prime * result + ((timeZone == null) ? 0 : timeZone.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		result = prime * result + ((transmission == null) ? 0 : transmission.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AssociatedPatientSearchDTO other = (AssociatedPatientSearchDTO) obj;
		if (ageRange == null) {
			if (other.ageRange != null)
				return false;
		} else if (!ageRange.equals(other.ageRange))
			return false;
		if (clinicId == null) {
			if (other.clinicId != null)
				return false;
		} else if (!clinicId.equals(other.clinicId))
			return false;
		if (!countOnly.equals(other.countOnly))
			return false;
		if (deviceSts == null) {
			if (other.deviceSts != null)
				return false;
		} else if (!deviceSts.equals(other.deviceSts))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (from == null) {
			if (other.from != null)
				return false;
		} else if (!from.equals(other.from))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (patientSts == null) {
			if (other.patientSts != null)
				return false;
		} else if (!patientSts.equals(other.patientSts))
			return false;
		if (pattern == null) {
			if (other.pattern != null)
				return false;
		} else if (!pattern.equals(other.pattern))
			return false;
		if (providerId == null) {
			if (other.providerId != null)
				return false;
		} else if (!providerId.equals(other.providerId))
			return false;
		if (range == null) {
			if (other.range != null)
				return false;
		} else if (!range.equals(other.range))
			return false;
		if (session == null) {
			if (other.session != null)
				return false;
		} else if (!session.equals(other.session))
			return false;
		if (timeZone == null) {
			if (other.timeZone != null)
				return false;
		} else if (!timeZone.equals(other.timeZone))
			return false;
		if (to == null) {
			if (other.to != null)
				return false;
		} else if (!to.equals(other.to))
			return false;
		if (transmission == null) {
			if (other.transmission != null)
				return false;
		} else if (!transmission.equals(other.transmission))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AssociatedPatientSearchDTO [userId=" + userId + ", clinicId=" + clinicId + ", gender=" + gender
				+ ", patientSts=" + patientSts + ", deviceSts=" + deviceSts + ", transmission=" + transmission
				+ ", range=" + range + ", type=" + type + ", session=" + session + ", providerId=" + providerId
				+ ", pattern=" + pattern + ", from=" + from + ", to=" + to + ", deviceType=" + deviceType
				+ ", ageRange=" + ageRange + ", timeZone=" + timeZone + ", countOnly=" + countOnly + "]";
	}
	public AssociatedPatientSearchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
