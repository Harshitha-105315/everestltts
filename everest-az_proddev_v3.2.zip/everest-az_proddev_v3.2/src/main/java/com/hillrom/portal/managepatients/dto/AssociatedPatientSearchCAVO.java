package com.hillrom.portal.managepatients.dto;

public class AssociatedPatientSearchCAVO {
	String patientId;
	Long userId;
	String hillromId;
	String clinics;
	String firstName;
	String lastName;
	String middleName;
	Boolean flagged;
	String HCP;
	String devices;
	Boolean isManual;
	Boolean isNew;
	Boolean isActive;
	String reason;	
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getHillromId() {
		return hillromId;
	}
	public void setHillromId(String hillromId) {
		this.hillromId = hillromId;
	}
	public String getClinics() {
		return clinics;
	}
	public void setClinics(String clinics) {
		this.clinics = clinics;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public Boolean getFlagged() {
		return flagged;
	}
	public void setFlagged(Boolean flagged) {
		this.flagged = flagged;
	}
	public String getHCP() {
		return HCP;
	}
	public void setHCP(String hCP) {
		HCP = hCP;
	}
	public String getDevices() {
		return devices;
	}
	public void setDevices(String devices) {
		this.devices = devices;
	}
	public Boolean getIsNew() {
		return isNew;
	}
	public void setIsNew(Boolean isNew) {
		this.isNew = isNew;
	}
	
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Boolean getIsManual() {
		return isManual;
	}
	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((HCP == null) ? 0 : HCP.hashCode());
		result = prime * result + ((clinics == null) ? 0 : clinics.hashCode());
		result = prime * result + ((devices == null) ? 0 : devices.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((flagged == null) ? 0 : flagged.hashCode());
		result = prime * result + ((hillromId == null) ? 0 : hillromId.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((isNew == null) ? 0 : isNew.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((middleName == null) ? 0 : middleName.hashCode());
		result = prime * result + ((patientId == null) ? 0 : patientId.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AssociatedPatientSearchCAVO other = (AssociatedPatientSearchCAVO) obj;
		if (HCP == null) {
			if (other.HCP != null)
				return false;
		} else if (!HCP.equals(other.HCP))
			return false;
		if (clinics == null) {
			if (other.clinics != null)
				return false;
		} else if (!clinics.equals(other.clinics))
			return false;
		if (devices == null) {
			if (other.devices != null)
				return false;
		} else if (!devices.equals(other.devices))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (flagged == null) {
			if (other.flagged != null)
				return false;
		} else if (!flagged.equals(other.flagged))
			return false;
		if (hillromId == null) {
			if (other.hillromId != null)
				return false;
		} else if (!hillromId.equals(other.hillromId))
			return false;
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;
		if (isNew == null) {
			if (other.isNew != null)
				return false;
		} else if (!isNew.equals(other.isNew))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (middleName == null) {
			if (other.middleName != null)
				return false;
		} else if (!middleName.equals(other.middleName))
			return false;
		if (patientId == null) {
			if (other.patientId != null)
				return false;
		} else if (!patientId.equals(other.patientId))
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	public AssociatedPatientSearchCAVO(String patientId, Long userId, String hillromId, String clinics,
			String firstName, String lastName, String middleName, Boolean flagged, String hCP, String devices,
			Boolean isManual, Boolean isNew, Boolean isActive, String reason) {
		super();
		this.patientId = patientId;
		this.userId = userId;
		this.hillromId = hillromId;
		this.clinics = clinics;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.flagged = flagged;
		HCP = hCP;
		this.devices = devices;
		this.isManual = isManual;
		this.isNew = isNew;
		this.isActive = isActive;
		this.reason = reason;
	}
	
	
}
