package com.hillrom.portal.managepatients.rest;

import static com.hillrom.vest.security.AuthoritiesConstants.ADMIN;
import static com.hillrom.vest.security.AuthoritiesConstants.CUSTOMER_SERVICES;

import java.net.URISyntaxException;
import java.util.Objects;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.portal.managepatients.dto.AllPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AllPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AsscociatedPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AssociatedPatientSearchDTO;
import com.hillrom.portal.managepatients.service.AllPatientSearchService;
import com.hillrom.portal.managepatients.service.AssociatedPatientSearchService;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.security.xauth.TokenProvider;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api/v1.0")
@Api(value = "Manage Patient Search", description = "Search results for manage patients: implemented", tags = { "Manage Patient Search" })
public class SearchResource {
	private final Logger log = LoggerFactory.getLogger(SearchResource.class);
	
	@Inject
	AllPatientSearchService allPatientSearchService;

	@Inject
	AssociatedPatientSearchService associatedPatientSearchService;
	
	@Inject TokenProvider tokenProvider;	
	
	@ApiOperation(httpMethod = "GET", value = "HillRom admin all patient search", response = AllPatientSearchResultVO.class)
	@RequestMapping(value = "/patient/manage/search", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES})
 	public AllPatientSearchResultVO searchPatientsAssociated(
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "clinicSts", required = false) String clinicSts,	
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "country", required = false) String country,
 			@RequestParam(value = "state", required = false) String state,
 			@RequestParam(value = "city", required = false) String city,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "sortBy", required = false) String sortBy,	
 			@RequestParam(value = "sortOrder", required = false) String sortOrder,
 			@RequestParam(value = "pageNo", required = true) int pageNo,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "pageSize", required = true) int pageSize,
 			@RequestParam(value = "pattern", required = false) String pattern
 			
 	) throws URISyntaxException
 	{
		AllPatientSearchDTO dto = new AllPatientSearchDTO();
		
		dto.setClinicSts(clinicSts);
		dto.setDeviceSts(deviceSts);
		dto.setGender(gender);
		dto.setPageNo(pageNo);
		dto.setPageSize(pageSize);
		dto.setPatientSts(patientSts);
		dto.setPattern(pattern);
		dto.setRange(range);
		dto.setSortBy(sortBy);
		dto.setSortOrder(sortOrder);
		dto.setTransmission(transmission);
		dto.setType(type);
		dto.setCity(city);
		dto.setCountry(country);
		dto.setState(state);
		dto.setAgeRange(ageRange);
		log.debug("Search : " + dto.toString());
		return allPatientSearchService.searchPatients(dto);		
 	}

	@ApiOperation(httpMethod = "GET", value = "Hillrom roles search patient by clinic", response = AsscociatedPatientSearchResultVO.class)
	@RequestMapping(value = "patient/manage/search/{clinicId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ADMIN,CUSTOMER_SERVICES})
 	public AsscociatedPatientSearchResultVO searchPatientsAssociatedClinic(
 			@ApiParam(value = "clinicId", required = true, example = "12345") @PathVariable String clinicId,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "pattern", required = false) String pattern,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    ) throws URISyntaxException
 	{
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setType(type);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setPattern(pattern);		
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsClinic(dto);		
 	}
	
	@ApiOperation(httpMethod = "GET", value = "Clinic admin search associated patient", response = AsscociatedPatientSearchResultVO.class)
	@RequestMapping(value = "patient/manage/search/ca", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.CLINIC_ADMIN})
 	public AsscociatedPatientSearchResultVO searchPatientsAssociatedCA(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "pattern", required = false) String pattern,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    ) throws URISyntaxException
 	{
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
	
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setType(type);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setPattern(pattern);		
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsCA(dto);		
 	}
	
	@ApiOperation(httpMethod = "GET", value = "Provider search associated patient", response = AsscociatedPatientSearchResultVO.class)
	@RequestMapping(value = "patient/manage/search/hcp", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.HCP})
 	public AsscociatedPatientSearchResultVO searchPatientsAssociatedHCP(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "pattern", required = false) String pattern,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    ) throws URISyntaxException
 	{
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setRange(range);
		dto.setType(type);
		dto.setDeviceType(deviceType);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setPattern(pattern);		
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsHCP(dto);		
 	}

	@ApiOperation(httpMethod = "GET", value = "AE search associated patient", response = AsscociatedPatientSearchResultVO.class)
	@RequestMapping(value = "patient/manage/search/ae", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.ASSOCIATE_EXECUTIVE})
 	public AsscociatedPatientSearchResultVO searchPatientsAssociatedAE(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "pattern", required = false) String pattern,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    ) throws URISyntaxException
 	{
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setDeviceType(deviceType);
		dto.setRange(range);
		dto.setType(type);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setPattern(pattern);		
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsAE(dto);		
 	}

	@ApiOperation(httpMethod = "GET", value = "CG search associated patient", response = AsscociatedPatientSearchResultVO.class)
	@RequestMapping(value = "patient/manage/search/cg", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({AuthoritiesConstants.CARE_GIVER})
 	public AsscociatedPatientSearchResultVO searchPatientsAssociatedCG(
 			@RequestHeader(value="x-auth-token",required=true)String authToken,
 			@RequestParam(value = "gender", required = false) String gender,		
 			@RequestParam(value = "patientSts", required = false) String patientSts,	
 			@RequestParam(value = "deviceSts", required = false) String deviceSts,
 			@RequestParam(value = "transmission", required = false) String transmission,
 			@RequestParam(value = "range", required = false) String range,
 			@RequestParam(value = "type", required = false) String type,
 			@RequestParam(value = "session", required = false) String session,
 			@RequestParam(value = "providerId", required = false) String providerId,
 			@RequestParam(value = "deviceType", required = false) String deviceType,
 			@RequestParam(value = "clinicId", required = false) String clinicId,
 			@RequestParam(value = "pattern", required = false) String pattern,
 			@RequestParam(value = "ageRange", required = false) String ageRange,
 			@RequestParam(value = "timeZone", required = true) String timeZone,
    		@RequestParam(value="from",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate from,
    		@RequestParam(value="to",required=false)@DateTimeFormat(pattern="yyyy-MM-dd") LocalDate to
    ) throws URISyntaxException
 	{
		AssociatedPatientSearchDTO dto = new AssociatedPatientSearchDTO();
		Long userId = tokenProvider.getUserIdFromToken(authToken);
		
		if(Objects.isNull(from))
		{
			from = LocalDate.now().minusMonths(3);
			to = LocalDate.now();
		}
		
		dto.setUserId(userId);
		dto.setClinicId(clinicId);
		dto.setGender(gender);
		dto.setPatientSts(patientSts);
		dto.setDeviceSts(deviceSts);
		dto.setTransmission(transmission);
		dto.setDeviceType(deviceType);
		dto.setRange(range);
		dto.setType(type);
		dto.setSession(session);
		dto.setProviderId(providerId);
		dto.setPattern(pattern);		
		dto.setFrom(from);
		dto.setTo(to);
		dto.setAgeRange(ageRange);
		dto.setTimeZone(timeZone);
		return associatedPatientSearchService.searchPatientsCG(dto);		
 	}


}
