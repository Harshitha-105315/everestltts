package com.hillrom.portal.patientview.dto;

import java.util.List;

import org.joda.time.DateTime;

public class ProtocolVO {
	String key;
	Boolean isActive;
	DateTime from;
	DateTime to;
	List<ProtocolPointVO> points;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public DateTime getFrom() {
		return from;
	}
	public void setFrom(DateTime from) {
		this.from = from;
	}
	public DateTime getTo() {
		return to;
	}
	public void setTo(DateTime to) {
		this.to = to;
	}
	public List<ProtocolPointVO> getPoints() {
		return points;
	}
	public void setPoints(List<ProtocolPointVO> points) {
		this.points = points;
	}

	public ProtocolVO(String key, Boolean isActive, DateTime from, DateTime to) {
		super();
		this.key = key;
		this.isActive = isActive;
		this.from = from;
		this.to = to;
	}
	
}
