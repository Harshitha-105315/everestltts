package com.hillrom.portal.patientview.service;

import java.io.IOException;
import java.text.ParseException;

import org.joda.time.LocalDate;

import com.hillrom.portal.patientview.dto.PatientDetailsVO;
import com.itextpdf.text.DocumentException;

public interface PdfConvertorService {

	byte[] createPdf(String userId, LocalDate startDate, LocalDate endDate, String timeZone, PatientDetailsVO patientDetailsVO)
			throws IOException, DocumentException, ParseException;

}
