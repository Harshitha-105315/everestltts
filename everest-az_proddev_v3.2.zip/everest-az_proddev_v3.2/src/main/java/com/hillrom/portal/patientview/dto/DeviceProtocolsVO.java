package com.hillrom.portal.patientview.dto;

import java.util.List;

public class DeviceProtocolsVO {
	String deviceType;
	List<ProtocolPointVO> defaultProtocol;
	List<ProtocolVO> protocolList;
	
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public List<ProtocolPointVO> getDefaultProtocol() {
		return defaultProtocol;
	}
	public void setDefaultProtocol(List<ProtocolPointVO> defaultProtocol) {
		this.defaultProtocol = defaultProtocol;
	}
	public List<ProtocolVO> getProtocolList() {
		return protocolList;
	}
	public void setProtocolList(List<ProtocolVO> protocolList) {
		this.protocolList = protocolList;
	}
	
	
}
