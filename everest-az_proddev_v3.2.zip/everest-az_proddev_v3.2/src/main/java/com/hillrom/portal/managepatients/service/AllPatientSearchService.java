package com.hillrom.portal.managepatients.service;

import java.util.Objects;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.portal.managepatients.dto.AllPatientSearchDTO;
import com.hillrom.portal.managepatients.dto.AllPatientSearchResultVO;
import com.hillrom.portal.managepatients.dto.AllPatientStatVO;
import com.hillrom.portal.managepatients.repository.AllPatientSearchRepository;

@Service
@Transactional
public class AllPatientSearchService {
	@Inject
	AllPatientSearchRepository allPatientSearchRepository;
	
	public AllPatientStatVO getStats(AllPatientSearchDTO dto)
	{
		AllPatientStatVO stat = new AllPatientStatVO();
		dto.setCountOnly(true);
		stat.setAll(allPatientSearchRepository.searchPatientAll(dto).getTotalCnt());
		stat.setVest(allPatientSearchRepository.searchPatientVest(dto).getTotalCnt());
		stat.setMonarch(allPatientSearchRepository.searchPatientMonarch(dto).getTotalCnt());
		stat.setTitan(allPatientSearchRepository.searchPatientTitan(dto).getTotalCnt());
		stat.setMulti(allPatientSearchRepository.searchPatientMulti(dto).getTotalCnt());
		stat.setNewPatients(allPatientSearchRepository.searchPatientNew(dto).getTotalCnt());
		dto.setTransmission(null);
		stat.setInactive(allPatientSearchRepository.searchPatientInactive(dto).getTotalCnt());		
		dto.setTransmission("never");
		stat.setNever(allPatientSearchRepository.searchPatientNever(dto).getTotalCnt());
		dto.setTransmission("stopped");
		stat.setStop(allPatientSearchRepository.searchPatientStop(dto).getTotalCnt());
		return stat;
	}
	
	public AllPatientSearchResultVO searchPatients(AllPatientSearchDTO dto)
	{
		AllPatientSearchResultVO result = null;
		
		if(Objects.isNull(dto)) {
			result = allPatientSearchRepository.searchPatientNew(dto);
		}else {
			if(Objects.isNull(dto.getType())) {
				result = allPatientSearchRepository.searchPatientNew(dto);
			}else {
				if(dto.getType().equalsIgnoreCase("simple")) {
					result = allPatientSearchRepository.searchPatientSimple(dto);
				}else if(dto.getType().equalsIgnoreCase("all")) {
					result = allPatientSearchRepository.searchPatientAll(dto);
				}else if(dto.getType().equalsIgnoreCase("vest")) {
					result = allPatientSearchRepository.searchPatientVest(dto);
				}else if(dto.getType().equalsIgnoreCase("monarch")) {
					result = allPatientSearchRepository.searchPatientMonarch(dto);
				}else if(dto.getType().equalsIgnoreCase("titan")) {
					result = allPatientSearchRepository.searchPatientTitan(dto);
				}else if(dto.getType().equalsIgnoreCase("multi")) {
					result = allPatientSearchRepository.searchPatientMulti(dto);
				}else if(dto.getType().equalsIgnoreCase("new")) {
					result = allPatientSearchRepository.searchPatientNew(dto);
				}else if(dto.getType().equalsIgnoreCase("never")) {
					dto.setTransmission("never");
					result = allPatientSearchRepository.searchPatientNever(dto);
				}else if(dto.getType().equalsIgnoreCase("stop")) {
					dto.setTransmission("stopped");
					result = allPatientSearchRepository.searchPatientStop(dto);
				}else if(dto.getType().equalsIgnoreCase("inactive")) {
					result = allPatientSearchRepository.searchPatientInactive(dto);
				}else {
					result = allPatientSearchRepository.searchPatientNew(dto);
				}
			}
		}
		return result;
	}
}
