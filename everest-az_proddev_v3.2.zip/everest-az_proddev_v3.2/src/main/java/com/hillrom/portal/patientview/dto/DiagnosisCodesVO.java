package com.hillrom.portal.patientview.dto;

public class DiagnosisCodesVO {
	private String typeCode;
	private String typeCodeValue;
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getTypeCodeValue() {
		return typeCodeValue;
	}
	public void setTypeCodeValue(String typeCodeValue) {
		this.typeCodeValue = typeCodeValue;
	}
}
