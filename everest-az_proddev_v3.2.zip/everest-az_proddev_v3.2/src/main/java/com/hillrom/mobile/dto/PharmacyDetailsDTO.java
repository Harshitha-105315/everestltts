package com.hillrom.mobile.dto;

public class PharmacyDetailsDTO {

	private Long id;
	
	private Integer pharmacyName;
	
	private String pharmacyAddress;
	
	private Integer longitude;

	private Integer latitude;

	private String phoneNumber;
	
	private String faxNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getPharmacyName() {
		return pharmacyName;
	}

	public void setPharmacyName(Integer pharmacyName) {
		this.pharmacyName = pharmacyName;
	}

	public String getPharmacyAddress() {
		return pharmacyAddress;
	}

	public void setPharmacyAddress(String pharmacyAddress) {
		this.pharmacyAddress = pharmacyAddress;
	}

	public Integer getLongitude() {
		return longitude;
	}

	public void setLongitude(Integer longitude) {
		this.longitude = longitude;
	}

	public Integer getLatitude() {
		return latitude;
	}

	public void setLatitude(Integer latitude) {
		this.latitude = latitude;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	@Override
	public String toString() {
		return "PharmacyDetailsDto [id=" + id + ", pharmacyName="
				+ pharmacyName + ", pharmacyAddress=" + pharmacyAddress
				+ ", longitude=" + longitude + ", latitude=" + latitude
				+ ", phoneNumber=" + phoneNumber + ", faxNumber=" + faxNumber
				+ "]";
	}

	public PharmacyDetailsDTO(Integer pharmacyName, String pharmacyAddress,
			Integer longitude, Integer latitude, String phoneNumber,
			String faxNumber) {
		super();
		this.pharmacyName = pharmacyName;
		this.pharmacyAddress = pharmacyAddress;
		this.longitude = longitude;
		this.latitude = latitude;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
	}	
}