package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

/**
 * A AWARD_MASTER.
 */
@Entity
@Table(name = "AWARD_MASTER")
public class AwardMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    @ApiModelProperty(notes="ID of award", dataType="java.lang.Long", required=true)
    private Long id;

	@JsonIgnore
    @Column(name = "ACTIVITY_TYPE_ID")
    private Long activityTypeId;

    @Column(name = "AWARD_NAME")
    @ApiModelProperty(notes="Name of award", required=true)
    private String awardName;
	@JsonIgnore
    @Column(name = "AWARD_MET_MIN_VALUE")
    private String awardMetMinValue;
	@JsonIgnore
    @Column(name = "AWARD_MET_MAX_VALUE")
    private String awardMetMaxValue;

    @Column(name = "AWARD_DESCRIPTION")
    @ApiModelProperty(notes="Description of award", required=true)
    private String awardDescription;

    @Column(name = "THUMBNAIL")
    @ApiModelProperty(notes="Path of thumnail image", required=true)
    private String thumbnail;

    @Column(name = "IMAGE")
    @ApiModelProperty(notes="File path of fullsize image", required=true)
    private String image;

    @Column(name = "THUMBNAIL_ACHIEVED")
    @ApiModelProperty(notes="Path of thumnail image", required=true)
    private String thumbnail_achieved;
     @Column(name = "IMAGE_ACHIEVED")
    @ApiModelProperty(notes="File path of fullsize image", required=true)
    private String image_achieved;
  
  
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getActivityTypeId() {
		return activityTypeId;
	}

	public void setActivityTypeId(Long activityTypeId) {
		this.activityTypeId = activityTypeId;
	}

	public String getAwardName() {
		return awardName;
	}

	public void setAwardName(String awardName) {
		this.awardName = awardName;
	}

	public String getAwardMetMinValue() {
		return awardMetMinValue;
	}

	public void setAwardMetMinValue(String awardMetMinValue) {
		this.awardMetMinValue = awardMetMinValue;
	}

	public String getAwardMetMaxValue() {
		return awardMetMaxValue;
	}

	public void setAwardMetMaxValue(String awardMetMaxValue) {
		this.awardMetMaxValue = awardMetMaxValue;
	}

	public String getAwardDescription() {
		return awardDescription;
	}

	public void setAwardDescription(String awardDescription) {
		this.awardDescription = awardDescription;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	
	public String getThumbnail_achieved() {
		return thumbnail_achieved;
	}
 	public void setThumbnail_achieved(String thumbnail_achieved) {
		this.thumbnail_achieved = thumbnail_achieved;
	}
 	public String getImage_achieved() {
		return image_achieved;
	}
 	public void setImage_achieved(String image_achieved) {
		this.image_achieved = image_achieved;
	}

	public AwardMaster(Long id, Long activityTypeId, String awardName, String awardMetMinValue, String awardMetMaxValue,
			String awardDescription, String thumbnail, String image, String thumbnail_achieved, String image_achieved) {
		super();
		this.id = id;
		this.activityTypeId = activityTypeId;
		this.awardName = awardName;
		this.awardMetMinValue = awardMetMinValue;
		this.awardMetMaxValue = awardMetMaxValue;
		this.awardDescription = awardDescription;
		this.thumbnail = thumbnail;
		this.image = image;
		this.thumbnail_achieved = thumbnail_achieved;
		this.image_achieved = image_achieved;
	}

	public AwardMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityTypeId == null) ? 0 : activityTypeId.hashCode());
		result = prime * result + ((awardDescription == null) ? 0 : awardDescription.hashCode());
		result = prime * result + ((awardMetMaxValue == null) ? 0 : awardMetMaxValue.hashCode());
		result = prime * result + ((awardMetMinValue == null) ? 0 : awardMetMinValue.hashCode());
		result = prime * result + ((awardName == null) ? 0 : awardName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + ((image_achieved == null) ? 0 : image_achieved.hashCode());
		result = prime * result + ((thumbnail == null) ? 0 : thumbnail.hashCode());
		result = prime * result + ((thumbnail_achieved == null) ? 0 : thumbnail_achieved.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AwardMaster other = (AwardMaster) obj;
		if (activityTypeId == null) {
			if (other.activityTypeId != null)
				return false;
		} else if (!activityTypeId.equals(other.activityTypeId))
			return false;
		if (awardDescription == null) {
			if (other.awardDescription != null)
				return false;
		} else if (!awardDescription.equals(other.awardDescription))
			return false;
		if (awardMetMaxValue == null) {
			if (other.awardMetMaxValue != null)
				return false;
		} else if (!awardMetMaxValue.equals(other.awardMetMaxValue))
			return false;
		if (awardMetMinValue == null) {
			if (other.awardMetMinValue != null)
				return false;
		} else if (!awardMetMinValue.equals(other.awardMetMinValue))
			return false;
		if (awardName == null) {
			if (other.awardName != null)
				return false;
		} else if (!awardName.equals(other.awardName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (image_achieved == null) {
			if (other.image_achieved != null)
				return false;
		} else if (!image_achieved.equals(other.image_achieved))
			return false;
		if (thumbnail == null) {
			if (other.thumbnail != null)
				return false;
		} else if (!thumbnail.equals(other.thumbnail))
			return false;
		if (thumbnail_achieved == null) {
			if (other.thumbnail_achieved != null)
				return false;
		} else if (!thumbnail_achieved.equals(other.thumbnail_achieved))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AwardMaster [id=" + id + ", activityTypeId=" + activityTypeId + ", awardName=" + awardName
				+ ", awardMetMinValue=" + awardMetMinValue + ", awardMetMaxValue=" + awardMetMaxValue
				+ ", awardDescription=" + awardDescription + ", thumbnail=" + thumbnail + ", image=" + image
				+ ", thumbnail_achieved=" + thumbnail_achieved + ", image_achieved=" + image_achieved + "]";
	}

}
