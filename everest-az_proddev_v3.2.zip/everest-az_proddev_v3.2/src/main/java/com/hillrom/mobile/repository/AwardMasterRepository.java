package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.AwardMaster;

@Repository
public interface AwardMasterRepository extends JpaRepository<AwardMaster, Long> {

	@Query("from AwardMaster am where am.activityTypeId = ?1")
	 List<AwardMaster> findOneByActivityTypeId(Long activityTypeId);
	
	@Query("from AwardMaster")
	List<AwardMaster> getAll();
}
