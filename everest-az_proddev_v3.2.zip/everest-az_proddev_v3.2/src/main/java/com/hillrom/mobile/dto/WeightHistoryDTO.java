package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "date", "weight" })
public class WeightHistoryDTO {

	@JsonProperty("pid")
	private String pid;
	@JsonProperty("date")
	private Long date;
	@JsonProperty("weight")
	private Long weight;

	@JsonProperty("date")
	public Long getDate() {
		return date;
	}

	@JsonProperty("date")
	public void setDate(Long date) {
		this.date = date;
	}

	@JsonProperty("weight")
	public Long getWeight() {
		return weight;
	}

	@JsonProperty("weight")
	public void setWeight(Long weight) {
		this.weight = weight;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

}
