package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "LogActivityDTO", description = "Logging the Activity Information")
public class LogActivityDTO {

	@ApiModelProperty(value = "Patient ID", required = true)
	private String pid;
	
	@ApiModelProperty(value = "ExerciseDuration", required = true)
	private String exerciseDuration;
	
	@ApiModelProperty(value = "ExerciseDate", required = true)
	private Long exerciseDate;
	
	@ApiModelProperty(value = "ActivityId", required = true)
	private Long activityId;
	
	@ApiModelProperty(value = "Weight", required = true)
	private Long weight;
	
	@ApiModelProperty(value = "Date", required = true)
	private Long date;
	
	@ApiModelProperty(value = "Nutrition", required = true)
	private Long nutrition;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getExerciseDuration() {
		return exerciseDuration;
	}
	public void setExerciseDuration(String exerciseDuration) {
		this.exerciseDuration = exerciseDuration;
	}
	public Long getExerciseDate() {
		return exerciseDate;
	}
	public void setExerciseDate(Long exerciseDate) {
		this.exerciseDate = exerciseDate;
	}
	
	public Long getWeight() {
		return weight;
	}
	public void setWeight(Long weight) {
		this.weight = weight;
	}
	public Long getDate() {
		return date;
	}
	public void setDate(Long date) {
		this.date = date;
	}
	public Long getNutrition() {
		return nutrition;
	}
	public void setNutrition(Long nutrition) {
		this.nutrition = nutrition;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
}
