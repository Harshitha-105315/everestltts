package com.hillrom.mobile.dto;

import java.util.List;

import org.joda.time.LocalDate;


public class PaientMedicationVO {
	
	private String pid;
	private String medicationType;
	private String medicationName;
	private String medicationNote;
	private boolean medicationReminderFlag;
	private List<MedicationRemindersVO> medicationReminder; 
	private String medicationPrescriptionNo;
	private String medicationPharmacyName;
	private String medicationPharmacyAddress;
	private String medicationPharmacyPhoneNumber;
	private String medicationPharmacyLocationCoordinates;
	private boolean medicationRefillReminderFlag;
	private LocalDate medicationRefillReminderDate;
	private boolean medicationIsArchiveFlag;
	private byte[] photo;
	
	
	public List<MedicationRemindersVO> getMedicationReminder() {
		return medicationReminder;
	}
	public void setMedicationReminder(List<MedicationRemindersVO> medicationReminder) {
		this.medicationReminder = medicationReminder;
	}
	public String getMedicationType() {
		return medicationType;
	}
	public void setMedicationType(String medicationType) {
		this.medicationType = medicationType;
	}
	public String getMedicationName() {
		return medicationName;
	}
	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}
	public String getMedicationNote() {
		return medicationNote;
	}
	public void setMedicationNote(String medicationNote) {
		this.medicationNote = medicationNote;
	}
	public boolean isMedicationReminderFlag() {
		return medicationReminderFlag;
	}
	public void setMedicationReminderFlag(boolean medicationReminderFlag) {
		this.medicationReminderFlag = medicationReminderFlag;
	}	
	public PaientMedicationVO() {
		super();
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getMedicationPharmacyName() {
		return medicationPharmacyName;
	}
	public void setMedicationPharmacyName(String medicationPharmacyName) {
		this.medicationPharmacyName = medicationPharmacyName;
	}
	public String getMedicationPharmacyAddress() {
		return medicationPharmacyAddress;
	}
	public void setMedicationPharmacyAddress(String medicationPharmacyAddress) {
		this.medicationPharmacyAddress = medicationPharmacyAddress;
	}
	public String getMedicationPharmacyPhoneNumber() {
		return medicationPharmacyPhoneNumber;
	}
	public void setMedicationPharmacyPhoneNumber(String medicationPharmacyPhoneNumber) {
		this.medicationPharmacyPhoneNumber = medicationPharmacyPhoneNumber;
	}
	public String getMedicationPharmacyLocationCoordinates() {
		return medicationPharmacyLocationCoordinates;
	}
	public void setMedicationPharmacyLocationCoordinates(String medicationPharmacyLocationCoordinates) {
		this.medicationPharmacyLocationCoordinates = medicationPharmacyLocationCoordinates;
	}
	public boolean isMedicationRefillReminderFlag() {
		return medicationRefillReminderFlag;
	}
	public void setMedicationRefillReminderFlag(boolean medicationRefillReminderFlag) {
		this.medicationRefillReminderFlag = medicationRefillReminderFlag;
	}
	public LocalDate getMedicationRefillReminderDate() {
		return medicationRefillReminderDate;
	}
	public void setMedicationRefillReminderDate(LocalDate medicationRefillReminderDate) {
		this.medicationRefillReminderDate = medicationRefillReminderDate;
	}	
	public String getMedicationPrescriptionNo() {
		return medicationPrescriptionNo;
	}
	public void setMedicationPrescriptionNo(String medicationPrescriptionNo) {
		this.medicationPrescriptionNo = medicationPrescriptionNo;
	}
	public boolean isMedicationIsArchiveFlag() {
		return medicationIsArchiveFlag;
	}
	public void setMedicationIsArchiveFlag(boolean medicationIsArchiveFlag) {
		this.medicationIsArchiveFlag = medicationIsArchiveFlag;
	}
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	@Override
	public String toString() {
		return "PaientMedicationVO [pid=" + pid + ", medicationType="
				+ medicationType + ", medicationName=" + medicationName
				+ ", medicationNote=" + medicationNote
				+ ", medicationReminderFlag=" + medicationReminderFlag
				+ ", medicationReminder=" + medicationReminder
				+ ", medicationPrescriptionNo=" + medicationPrescriptionNo
				+ ", medicationPharmacyName=" + medicationPharmacyName
				+ ", medicationPharmacyAddress=" + medicationPharmacyAddress
				+ ", medicationPharmacyPhoneNumber="
				+ medicationPharmacyPhoneNumber
				+ ", medicationPharmacyLocationCoordinates="
				+ medicationPharmacyLocationCoordinates
				+ ", medicationRefillReminderFlag="
				+ medicationRefillReminderFlag
				+ ", medicationRefillReminderDate="
				+ medicationRefillReminderDate + ", medicationIsArchiveFlag="
				+ medicationIsArchiveFlag + ", photo=" + photo + "]";
	}
	public PaientMedicationVO(String medicationType, String medicationName,
			String medicationNote, boolean medicationReminderFlag,
			List<MedicationRemindersVO> medicationReminder,
			String medicationPrescriptionNo, String medicationPharmacyName,
			String medicationPharmacyAddress,
			String medicationPharmacyPhoneNumber,
			String medicationPharmacyLocationCoordinates,
			boolean medicationRefillReminderFlag,
			LocalDate medicationRefillReminderDate,
			boolean medicationIsArchiveFlag, byte[] photo) {
		super();
		this.medicationType = medicationType;
		this.medicationName = medicationName;
		this.medicationNote = medicationNote;
		this.medicationReminderFlag = medicationReminderFlag;
		this.medicationReminder = medicationReminder;
		this.medicationPrescriptionNo = medicationPrescriptionNo;
		this.medicationPharmacyName = medicationPharmacyName;
		this.medicationPharmacyAddress = medicationPharmacyAddress;
		this.medicationPharmacyPhoneNumber = medicationPharmacyPhoneNumber;
		this.medicationPharmacyLocationCoordinates = medicationPharmacyLocationCoordinates;
		this.medicationRefillReminderFlag = medicationRefillReminderFlag;
		this.medicationRefillReminderDate = medicationRefillReminderDate;
		this.medicationIsArchiveFlag = medicationIsArchiveFlag;
		this.photo = photo;
	}	
}
