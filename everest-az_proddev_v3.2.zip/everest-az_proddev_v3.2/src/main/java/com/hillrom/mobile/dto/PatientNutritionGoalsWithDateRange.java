package com.hillrom.mobile.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class PatientNutritionGoalsWithDateRange {
	@JsonProperty("nutrition history")
	@ApiModelProperty(notes="List of nutrition history", dataType="List<com.hillrom.mobile.dto.PatientActivityHistoryVO>", required=true)
	List<PatientActivityHistoryVO> patientActivityHistoryListVO;
	
	@JsonProperty("current goal")
	@ApiModelProperty(notes="Current goal", required=true)
	CurrentGoalVO currentGoalVO;
	
	@JsonProperty("award history")
	@ApiModelProperty(notes="List of nutrition activity", dataType="AwardsHistoryVO", required=true)
	List<AwardsHistoryVO> awardsHistoryListVO;	
	
	@JsonProperty("isActiveActivity")
	@ApiModelProperty(notes="Is active activity", required=true)
	Boolean currentActivity;
	
	public List<PatientActivityHistoryVO> getPatientActivityHistoryListVO() {
		return patientActivityHistoryListVO;
	}
	public void setPatientActivityHistoryListVO(List<PatientActivityHistoryVO> patientActivityHistoryListVO) {
		this.patientActivityHistoryListVO = patientActivityHistoryListVO;
	}
	public CurrentGoalVO getCurrentGoalVO() {
		return currentGoalVO;
	}
	public void setCurrentGoalVO(CurrentGoalVO currentGoalVO) {
		this.currentGoalVO = currentGoalVO;
	}
	public List<AwardsHistoryVO> getAwardsHistoryListVO() {
		return awardsHistoryListVO;
	}
	public void setAwardsHistoryListVO(List<AwardsHistoryVO> awardsHistoryListVO) {
		this.awardsHistoryListVO = awardsHistoryListVO;
	}
	public Boolean getCurrentActivity() {
		return currentActivity;
	}
	public void setCurrentActivity(Boolean currentActivity) {
		this.currentActivity = currentActivity;
	}
	
	
	public PatientNutritionGoalsWithDateRange() {
		super();
		patientActivityHistoryListVO = null;
		currentGoalVO = null;
		awardsHistoryListVO = null;
		currentActivity = false;
	}
}

