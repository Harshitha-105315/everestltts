package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"badgeId",
"badgeName",
"Date",
"isUnlocked"
})

public class BadgesHistoryVO {
	@JsonProperty("badgeId")
	private Long badgeId;
	@JsonProperty("badgeName")
	private String badgeName;
	@JsonProperty("Date")
	private Long Date;
	@JsonProperty("isUnlocked")
	private Boolean isUnlocked;
	
	public Long getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(Long badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeName() {
		return badgeName;
	}
	public void setBadgeName(String badgeName) {
		this.badgeName = badgeName;
	}
	public Long getDate() {
		return Date;
	}
	public void setDate(Long date) {
		Date = date;
	}
	public Boolean getIsUnlocked() {
		return isUnlocked;
	}
	public void setIsUnlocked(Boolean isUnlocked) {
		this.isUnlocked = isUnlocked;
	}

}
