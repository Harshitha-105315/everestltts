package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class PatientCurrentActivitiesDTO {
	@JsonProperty("exercise")
	@ApiModelProperty(notes="Exercise activity", required=true)
	CurrentActivityExerciseVO patientExerciseActivity = null;
	@JsonProperty("weight")
	@ApiModelProperty(notes="Weight activity", required=true)
	CurrentActivityWeightVO patientWeightActivity = null;
	@JsonProperty("nutrition")
	@ApiModelProperty(notes="Nutrition activity", required=true)
	CurrentActivityNutritionVO patientNutritionActivity = null;
	
	public CurrentActivityExerciseVO getPatientExerciseActivity() {
		return patientExerciseActivity;
	}
	public void setPatientExerciseActivity(CurrentActivityExerciseVO patientExerciseActivity) {
		this.patientExerciseActivity = patientExerciseActivity;
	}
	public CurrentActivityWeightVO getPatientWeightActivity() {
		return patientWeightActivity;
	}
	public void setPatientWeightActivity(CurrentActivityWeightVO patientWeightActivity) {
		this.patientWeightActivity = patientWeightActivity;
	}
	public CurrentActivityNutritionVO getPatientNutritionActivity() {
		return patientNutritionActivity;
	}
	public void setPatientNutritionActivity(CurrentActivityNutritionVO patientNutritionActivity) {
		this.patientNutritionActivity = patientNutritionActivity;
	}

}
