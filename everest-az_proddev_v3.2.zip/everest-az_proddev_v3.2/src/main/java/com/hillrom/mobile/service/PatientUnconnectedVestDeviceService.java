package com.hillrom.mobile.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.mobile.domain.MobileDeviceInfo;
import com.hillrom.mobile.dto.PatientVestDeviceDataMobileVO;
import com.hillrom.mobile.repository.MobileDeviceInfoRepository;
import com.hillrom.monarch.service.AdherenceCalculationServiceMonarch;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientVestDeviceData;
import com.hillrom.vest.domain.PatientVestDeviceDataPK;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.HillromTypeCodeFormatRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientVestDeviceDataRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.service.AdvanceAdherenceCalculationService;
import com.hillrom.vest.service.TherapySessionService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;
import com.hillrom.vest.web.rest.dto.ProtocolDTO;

@Service
@Transactional
public class PatientUnconnectedVestDeviceService {

	@Inject
	private UserService userService;

	@Inject
	private UserRepository userRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject
	private AdherenceCalculationServiceMonarch adherenceCalculationServiceMonarch;

	@Inject
	private PatientVestDeviceRepository patientVestDeviceRepository;

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepo;

	@Inject
	private TherapySessionService therapySessionService;

	@Inject
	private PatientVestDeviceDataRepository patientVestDeviceDataRepository;

	@Inject
	private AwardsAndBadgesCalculatorService awardsAndBadgesCalculatorService;
	
	@Inject
	private AdvanceAdherenceCalculationService advanceAdherenceCalculationService;
	
	@Inject
	private MobileDeviceInfoRepository mobileDeviceInfoRepository;
	
	@Inject
	private HillromTypeCodeFormatRepository hillromTypeCodeFormatRepository;

	private PatientVestDeviceHistory updateDeviceDetailsForPatient(PatientVestDeviceHistory patientVestDeviceActive,
			Map<String, Object> deviceData) throws HillromException {
		PatientInfo patientInfo = patientVestDeviceActive.getPatient();
		if (Objects.nonNull(patientInfo)) {
			patientInfo.setSerialNumber(
					Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null);
			patientInfoRepository.save(patientInfo);
			patientVestDeviceActive.setSerialNumber(
					Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null);
			patientVestDeviceActive.setActive(true);
			patientVestDeviceActive.setLastModifiedDate(DateTime.now());
			patientVestDeviceRepository.saveAndFlush(patientVestDeviceActive);
			return patientVestDeviceActive;
		} else {
			throw new HillromException(ExceptionConstants.HR_523); // No such user exist
		}
	}

	private PatientVestDeviceHistory assignDeviceToPatient(Long id, Map<String, Object> deviceData)
			throws HillromException {
		PatientVestDeviceHistory patientUnconnectedVestDeviceAssoc = null;
		User patientUser = userRepository.findOne(id);
		if (Objects.nonNull(patientUser)) {
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
			if (Objects.nonNull(patientInfo)) {
				patientInfo.setSerialNumber(
						Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString()
								: null);
				patientInfo.setDeviceAssocDate(DateTime.now());
				patientInfoRepository.save(patientInfo);
				Optional<PatientVestDeviceHistory> currentAssoc = patientVestDeviceRepository
						.findOneByPatientIdAndSerialNumber(patientInfo.getId(), deviceData.get("serialNumber").toString());
				
				if (currentAssoc.isPresent()) {
					currentAssoc.get().setActive(true);
					currentAssoc.get().setLastModifiedDate(DateTime.now());
					patientVestDeviceRepository.save(currentAssoc.get());
					return currentAssoc.get();
				} else {
				 patientUnconnectedVestDeviceAssoc = new PatientVestDeviceHistory(
						new PatientVestDevicePK(patientInfo, deviceData.get("serialNumber").toString()), true,
						DateTime.now());
				patientVestDeviceRepository.saveAndFlush(patientUnconnectedVestDeviceAssoc);	
				return patientUnconnectedVestDeviceAssoc;
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_523); // No such patient exist
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_512); // No such user exist
		}
		
	}

	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for (UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()) {
			if (RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())) {
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}

	private User getPatientUserObjFromPatientInfo(PatientInfo patientInfo) {
		User user = null;
		for (UserPatientAssoc patientAssoc : patientInfo.getUserPatientAssoc()) {
			if (RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())) {
				user = patientAssoc.getUser();
			}
		}
		return user;
	}
	
	public Object linkUnconnectedVestDeviceWithPatient(Long id, Map<String, Object> deviceData, String patientId)
			throws HillromException {
		User alreadyLinkedPatientuser = new User();
		List<PatientVestDeviceHistory> assocList = patientVestDeviceRepository
				.findOneBySerialNumberAndStatusActive(deviceData.get("serialNumber").toString());
		PatientVestDeviceHistory activeAssocList = patientVestDeviceRepository
				.findLatestActiveDeviceByPatientId(patientId, true);
		PatientVestDeviceHistory patientVestDeviceAssoc = new PatientVestDeviceHistory();
		if (Objects.nonNull(assocList) && !assocList.isEmpty()) {
			alreadyLinkedPatientuser = assocList.get(0).getPatient().getUserPatientAssoc().stream()
					.filter(userPatientAssoc -> RelationshipLabelConstants.SELF
							.equals(userPatientAssoc.getRelationshipLabel()))
					.collect(Collectors.toList()).get(0).getUser();
			if (!alreadyLinkedPatientuser.getId().equals(id)) {
				return alreadyLinkedPatientuser;
			}
		}
		if (assocList.isEmpty()) {
			patientVestDeviceAssoc = assignDeviceToPatient(id, deviceData);
		} else {
			if (Objects.nonNull(activeAssocList)) {
				activeAssocList.setActive(false);
			}
			List<PatientVestDeviceHistory> activeDeviceList = assocList.stream()
					.filter(patientDevice -> patientDevice.isActive()).collect(Collectors.toList());
			if (!activeDeviceList.isEmpty()) {
				PatientVestDeviceHistory activeDevice = activeDeviceList.get(0);
				alreadyLinkedPatientuser = activeDevice.getPatient().getUserPatientAssoc().stream()
						.filter(userPatientAssoc -> RelationshipLabelConstants.SELF
								.equals(userPatientAssoc.getRelationshipLabel()))
						.collect(Collectors.toList()).get(0).getUser();
				if (alreadyLinkedPatientuser.getId().equals(id)) {
					patientVestDeviceAssoc = updateDeviceDetailsForPatient(activeDevice, deviceData);
					return patientVestDeviceAssoc;
				} else {
					return alreadyLinkedPatientuser;
				}
			} else {
				PatientInfo patientInfo = userService.getPatientInfoObjFromPatientUser(userRepository.getOne(id));
				List<PatientVestDeviceHistory> patientDeviceList = assocList.stream()
						.filter(patientDevice -> (patientDevice.getPatient().getId()
								.equalsIgnoreCase(patientInfo.getId()) && !patientDevice.isActive()))
						.collect(Collectors.toList());
				if (patientDeviceList.isEmpty()) {
					patientVestDeviceAssoc = assignDeviceToPatient(id, deviceData);
				} else {
					patientVestDeviceAssoc = updateDeviceDetailsForPatient(patientDeviceList.get(0), deviceData);
				}
			}
		}
		return patientVestDeviceAssoc;
	}

	public Object linkUnconnectedVestToMonarch(String patientId,String deviceType)throws HillromException {
        Object responseObj_Vest = null;

             PatientInfo patient = patientInfoRepository.getOne(patientId);
             User patientUser = getPatientUserObjFromPatientInfo(patient);
             
            Map<String,Object> deviceData = new HashMap<String,Object>();

            	List<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepository.
            			findByPatientId(patient.getId());
            	if( !activeDevice.isEmpty()
            		&&
            		(
            				(activeDevice.get(0).getPatientType()).equalsIgnoreCase("sd") || 
            				((activeDevice.get(0).getPatientType()).equalsIgnoreCase("cd") && activeDevice.size()==1)
            		)
            	) {
                      deviceData.put("serialNumber", patient.getId()+"_UV");
                      
                      responseObj_Vest = linkUnconnectedVestDeviceWithPatient(patientUser.getId(), deviceData,patient.getId());
                      PatientDevicesAssoc checkPatientType = patientDevicesAssocRepository.findOneByPatientIdAndDeviceType(patient.getId(), "VEST");
                      List<PatientDevicesAssoc> patDevList = new LinkedList<>();
                      if(Objects.isNull(checkPatientType)){
                    	  Optional<PatientDevicesAssoc> vestDevice = patientDevicesAssocRepository.findOneBySerialNumberWithOutActiveStatus(deviceData.get("serialNumber").toString());
                    	  if(!vestDevice.isPresent()) {
                            PatientDevicesAssoc addPatientType = new PatientDevicesAssoc(patient.getId(), "VEST", "CD", true, deviceData.get("serialNumber").toString(), patient.getHillromId());
                            patientDevicesAssocRepository.save(addPatientType);
                            patDevList.add(addPatientType);
                    	  } else {
                    		  vestDevice.get().setIsActive(true);
                    		  vestDevice.get().setDeviceType(deviceType);
                    		  vestDevice.get().setPatientType("CD");
                    		  vestDevice.get().setSerialNumber(deviceData.get("serialNumber").toString());
                    		  vestDevice.get().setHillromId(patient.getHillromId());
                    		  vestDevice.get().setPatientId(patient.getId());
                    		  patientDevicesAssocRepository.save(vestDevice.get());
                    		  patDevList.add(vestDevice.get());
                    	  }
                    	  
                      }else{
                            checkPatientType.setPatientType("CD");                                   
                            checkPatientType.setCreatedDate(Objects.isNull(checkPatientType.getCreatedDate()) ?
                                          DateUtil.getPlusOrMinusTodayLocalDate(-1) :  checkPatientType.getCreatedDate());
                            checkPatientType.setSerialNumber(deviceData.get("serialNumber").toString());
                            patientDevicesAssocRepository.save(checkPatientType);
                            patDevList.add(checkPatientType);
                      }
                      if(deviceType.equals("MONARCH"))
                            adherenceCalculationServiceMonarch.executeMergingProcess(patDevList, 1);

                      PatientDevicesAssoc updatePatientType = patientDevicesAssocRepository.findOneByPatientIdAndDeviceType(patient.getId(), "MONARCH");
                      updatePatientType.setPatientType("CD");
                      patientDevicesAssocRepository.save(updatePatientType);
                           @SuppressWarnings("unused")
                           String changedDevType;
                           changedDevType = "ALL";
            	} else {
            		throw new HillromException(ExceptionConstants.HR_905);
            	}
          
            return responseObj_Vest;
    }


	public  List<String> ingestDataToDevice(List<PatientVestDeviceDataMobileVO> vestDeviceDataList,String authToken) throws Exception  {
		List<TherapySession> therapySessions = null;
		List<String> therapyIds = new ArrayList<String>();
		PatientDevicesAssoc activeDeviceList = patientDevicesAssocRepository.findOneBySerialNumberAndActive(vestDeviceDataList.get(0).getSerialNumber());
		if(Objects.isNull(activeDeviceList)) {
			throw new HillromException(ExceptionConstants.HR_950);
		}	
		List<PatientVestDeviceDataMobileVO> validDeviceDataList=activeVestDeviceDataList(vestDeviceDataList);
		if (Objects.isNull(validDeviceDataList) || validDeviceDataList.size() < 1) {
			throw new HillromException(ExceptionConstants.HR_954);
		}

		Long from,to;
		String serialNumber;
		String mobileDeviceType = Constants.ANDROID; 
		MobileDeviceInfo mobileDeviceDetails = mobileDeviceInfoRepository.findByPatientIdAndXAuthToken(activeDeviceList.getPatientId(), authToken);
		if(Objects.nonNull(mobileDeviceDetails)) {
			mobileDeviceType = hillromTypeCodeFormatRepository.findOne(mobileDeviceDetails.getPlatform_type()).getType_code();
		}
		List<PatientVestDeviceData> patientVestDeviceDataEvents = preparingVestDeviceDataEvents(validDeviceDataList,mobileDeviceType);
		Collections.sort(patientVestDeviceDataEvents);
		Long patientUserId = patientVestDeviceDataEvents.get(0).getPatientUser().getId();
		String patientId = patientVestDeviceDataEvents.get(0).getPatient().getId();
		
		 DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		 String dateString = sdf.format(new Date());
		 Date currentDate =sdf.parse(dateString);
		 Calendar currentCalendar = Calendar.getInstance();
		 Calendar minus90DaysCalendar = Calendar.getInstance();
		 minus90DaysCalendar.add(Calendar.DATE, -Constants.DELTA_DAYS);
		 Date calanderDateFormat = minus90DaysCalendar.getTime();
		 String dateString1 = sdf.format(calanderDateFormat);
		 Date dateBefore90Days = sdf.parse(dateString1);
		 currentCalendar.setTime(currentDate);
		 minus90DaysCalendar.setTime(dateBefore90Days);
		 to = currentCalendar.getTimeInMillis();
		 from = minus90DaysCalendar.getTimeInMillis();
		serialNumber = patientVestDeviceDataEvents.get(0).getSerialNumber();

		List<PatientVestDeviceData> existingEvents = patientVestDeviceDataRepository.
				findByPatientUserIdAndTimestampBetween(patientUserId, from, to);
		List<PatientVestDeviceData> patientVestDeviceRecords = getDelta(existingEvents, patientVestDeviceDataEvents);

		if(patientVestDeviceRecords.isEmpty()){
			throw new HillromException(ExceptionConstants.HR_913);
		} else {
			for(PatientVestDeviceData patientVestDeviceRecord:patientVestDeviceRecords)
			{
				patientVestDeviceDataRepository.saveAndFlush(patientVestDeviceRecord);//adding all new events
			}
		}

		List<PatientVestDeviceHistory> deviceHistoryList = patientVestDeviceRepository.
				findOneBySerialNumberAndStatusActive(serialNumber);
		Optional<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepo.findOneBySerialNumber(serialNumber);				 
		PatientInfo patientInfo = patientInfoRepository.findOneById(activeDevice.get().getPatientId()); 
		Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
		PatientVestDeviceData patientVestDeviceData = patientVestDeviceDataRepository.
				findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(associatedUser.get().getId(),serialNumber);
		if(Objects.nonNull(deviceHistoryList)) {
			deviceHistoryList.get(0).setHmr(patientVestDeviceData.getHmr());
		}
		patientVestDeviceRepository.save(deviceHistoryList);

		PatientVestDeviceHistory latestInActiveDevice = patientVestDeviceRepository.
				findLatestInActiveDeviceByPatientId(patientId, false);
		therapySessions = PatientVestDeviceTherapyUtil
				.prepareTherapySessionFromDeviceData(patientVestDeviceRecords,latestInActiveDevice);
		//therapySessionService.saveOrUpdate(therapySessions);
		advanceAdherenceCalculationService.saveOrUpdate(therapySessions, true);
		awardsAndBadgesCalculatorService.vestLogMetrics(patientId);

		patientInfo.setLastVest(therapySessionService.getLatestEndTime(patientId));
		patientInfoRepository.saveAndFlush(patientInfo);

		for(TherapySession therapySession : therapySessions ) {
			if(Objects.nonNull(therapySession)) {
				therapyIds.add(therapySession.getId().toString());
			}
		}
		return therapyIds;

	}

	private List<PatientVestDeviceData> preparingVestDeviceDataEvents(List<PatientVestDeviceDataMobileVO> validDeviceDataList,
			String mobileDeviceType) throws HillromException {
		List<PatientVestDeviceData> preparedDeviceEvents = new ArrayList<PatientVestDeviceData>();
		if (!(validDeviceDataList.isEmpty())) {
			String serialNumber = validDeviceDataList.get(0).getSerialNumber();
			List<PatientVestDeviceHistory> deviceHistoryList = patientVestDeviceRepository
					.findOneBySerialNumberAndStatusActive(serialNumber);
			Optional<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepo.findOneBySerialNumber(serialNumber);
			PatientInfo patientInfo = patientInfoRepository.findOneById(activeDevice.get().getPatientId());
			Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
			if (!(deviceHistoryList.isEmpty())) {
				Double existingHmr = deviceHistoryList.get(0).getHmr();
				Double hmr = 0.0;
				hmr = existingHmr;
				Boolean startEvent = true;

				for (PatientVestDeviceDataMobileVO validDeviceData : validDeviceDataList) {
					Long offset = 0L;
					if (startEvent) {
						PatientVestDeviceData patientVestDeviceData = new PatientVestDeviceData();
						PatientVestDeviceDataPK patientVestDeviceDataPK = new PatientVestDeviceDataPK();
						patientVestDeviceData.setPatientVestDeviceDataPK(patientVestDeviceDataPK);
						offset = DateUtil.getOffSet(validDeviceData,mobileDeviceType);
						patientVestDeviceData.setTimestamp(validDeviceData.getCreatedDate() + offset);
						patientVestDeviceData.setSequenceNumber(1);
						patientVestDeviceData.setEventId("1:SessionEventCodeNormalStarted");
						patientVestDeviceData.setHmr(hmr);
						patientVestDeviceData.setPatient(patientInfo);
						patientVestDeviceData.setSerialNumber(validDeviceData.getSerialNumber());
						patientVestDeviceData.setBluetoothId(validDeviceData.getSerialNumber());
						patientVestDeviceData.setHubId(validDeviceData.getSerialNumber());
						patientVestDeviceData.setFrequency(validDeviceData.getFrequency());
						patientVestDeviceData.setPressure(validDeviceData.getPressure());
						patientVestDeviceData.setDuration(validDeviceData.getDuration());
						patientVestDeviceData.setPatientUser(associatedUser.get());
						startEvent = false;
						preparedDeviceEvents.add(patientVestDeviceData);

					}
					if (!startEvent) {
						PatientVestDeviceData patientVestDeviceData = new PatientVestDeviceData();
						PatientVestDeviceDataPK patientVestDeviceDataPK = new PatientVestDeviceDataPK();
						patientVestDeviceData.setPatientVestDeviceDataPK(patientVestDeviceDataPK);						
						Long durationToMillies = (long) ((validDeviceData.getDuration()) * (60 * 1000));
						offset = DateUtil.getOffSet(validDeviceData,mobileDeviceType);
						patientVestDeviceData.setTimestamp((validDeviceData.getCreatedDate()) + (durationToMillies) + offset);
						patientVestDeviceData.setSequenceNumber(2);
						patientVestDeviceData.setEventId("3:SessionEventCodeCompleted");
						hmr = hmr + ((validDeviceData.getDuration()) * (60));
						patientVestDeviceData.setHmr(hmr);
						patientVestDeviceData.setPatient(patientInfo);
						patientVestDeviceData.setSerialNumber(validDeviceData.getSerialNumber());
						patientVestDeviceData.setBluetoothId(validDeviceData.getSerialNumber());
						patientVestDeviceData.setHubId(validDeviceData.getSerialNumber());
						patientVestDeviceData.setFrequency(0);
						patientVestDeviceData.setPressure(0);
						patientVestDeviceData.setDuration(0);
						patientVestDeviceData.setPatientUser(associatedUser.get());
						startEvent = true;
						preparedDeviceEvents.add(patientVestDeviceData);
					}
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_911);
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_912);
		}
		return preparedDeviceEvents;
	}
	
	private List<PatientVestDeviceDataMobileVO> activeVestDeviceDataList(List<PatientVestDeviceDataMobileVO> vestDeviceDataList) {

		final List<PatientVestDeviceDataMobileVO> patientVestDeviceValidEvents = new ArrayList<PatientVestDeviceDataMobileVO>();
		if(Objects.nonNull(vestDeviceDataList)) {

			/*Calendar cal = Calendar.getInstance();
			Timestamp timestamp = new Timestamp(DateUtil.getEndOfDay(new Date()).getTime());
			Timestamp timestampMinus3mths;
			cal.add(Calendar.DAY_OF_MONTH, -90);
			timestampMinus3mths = new Timestamp(cal.getTime().getTime());
			DateTime dt = new DateTime(DateTimeZone.UTC);
			Long  timestamp = (dt).getMillis();
			Long timestampMinus3mths = dt.minusDays(90).getMillis();*/

			vestDeviceDataList.forEach(vestDeviceData -> {
				if(Objects.nonNull(vestDeviceData.getCreatedDate()) && 
						DateUtil.isDateTimeWithin90Days(vestDeviceData.getCreatedDate())){
					vestDeviceData.setCreatedDate((vestDeviceData.getCreatedDate()/1000) * 1000);
					patientVestDeviceValidEvents.add(vestDeviceData);
				}
			}); 
		}
		return patientVestDeviceValidEvents;
	}

	private List<PatientVestDeviceData> getDelta(List<PatientVestDeviceData> existingEvents, List<PatientVestDeviceData> newEvents) throws HillromException{
		if(Objects.isNull(existingEvents) || existingEvents.isEmpty())
			return newEvents;
		else{
			Iterator<PatientVestDeviceData> itr = newEvents.iterator();
			while(itr.hasNext()){
				PatientVestDeviceData newEvent = itr.next();
				for(PatientVestDeviceData existingData : existingEvents){
					if((existingData.getTimestamp()  <= newEvent.getTimestamp()) &&
							(newEvent.getTimestamp() <= (existingData.getTimestamp() + (30 *60*1000))) &&
							newEvent.getBluetoothId().equals(existingData.getBluetoothId()) &&
							newEvent.getEventId().equals(existingData.getEventId())){
						itr.remove();
						break;
					}
				}
			}
			Collections.sort(newEvents);
			if(newEvents.size()>1) {
				return newEvents;
			} else {
				throw new HillromException(ExceptionConstants.HR_913);	
			}
			
		}
	}
	
	public void setDefaultFRequencyAndPressureForNull(List<PatientProtocolData> patientProtocolData) {
		try {
			for (PatientProtocolData patientProtocolDataIfNull : patientProtocolData) {
				if (patientProtocolDataIfNull.getMinFrequency() == null) {
					patientProtocolDataIfNull.setMinFrequency(Constants.MIN_FREQUENCY);
				}
				if (patientProtocolDataIfNull.getMaxFrequency() == null) {
					patientProtocolDataIfNull.setMaxFrequency(Constants.MAX_FREQUENCY);
				}
				if (patientProtocolDataIfNull.getMinPressure() == null) {
					patientProtocolDataIfNull.setMinPressure(Constants.MIN_PRESSURE);
				}
				if (patientProtocolDataIfNull.getMaxPressure() == null) {
					patientProtocolDataIfNull.setMaxPressure(Constants.MAX_PRESSURE);
				}
			}
		} catch (Exception ex) {
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter(writer);
			ex.printStackTrace(printWriter);
		}
	}

 	public void setDefaultFRequencyAndPressureForNull(ProtocolDTO protocolDTO, String deviceType) {
		try {
			for (int i = 0; i < protocolDTO.getProtocolEntries().size(); i++) {
				if ((protocolDTO.getProtocolEntries().get(i).getMinFrequency()) == null) {
					protocolDTO.getProtocolEntries().get(i).setMinFrequency(Constants.MIN_FREQUENCY);
				}
				if ((protocolDTO.getProtocolEntries().get(i).getMaxFrequency()) == null) {
					protocolDTO.getProtocolEntries().get(i).setMaxFrequency(Constants.MAX_FREQUENCY);
				}
				if ((protocolDTO.getProtocolEntries().get(i).getMinPressure()) == null) {
					protocolDTO.getProtocolEntries().get(i).setMinPressure(Constants.MIN_PRESSURE);
				}
				if ((protocolDTO.getProtocolEntries().get(i).getMaxPressure()) == null) {
					protocolDTO.getProtocolEntries().get(i).setMaxPressure(Constants.MAX_PRESSURE);
				}
			}
		} catch (Exception ex) {
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter(writer);
			ex.printStackTrace(printWriter);
		}
	}
	
}
