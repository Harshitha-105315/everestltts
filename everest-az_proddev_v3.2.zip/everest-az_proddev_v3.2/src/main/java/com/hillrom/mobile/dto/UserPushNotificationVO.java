package com.hillrom.mobile.dto;
import io.swagger.annotations.ApiModelProperty;

public class UserPushNotificationVO {
	
	@ApiModelProperty(notes="ID of push Notification", dataType="java.lang.Long", required=true)
    private Long id;

	@ApiModelProperty(notes="sent date", required=true)
    private Long sentDate;
     
	@ApiModelProperty(notes="is Read", required=true)
    private Boolean isRead;
   
	@ApiModelProperty(notes="read date", required=true)
    private Long read_date;
    
    @ApiModelProperty(notes="message or content pushed to user", required=true)
    private NotificationExtendedInfoDTO message;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSentDate() {
		return sentDate;
	}

	public void setSentDate(Long sentDate) {
		this.sentDate = sentDate;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public Long getRead_date() {
		return read_date;
	}

	public void setRead_date(Long read_date) {
		this.read_date = read_date;
	}

	public NotificationExtendedInfoDTO getMessage() {
		return message;
	}

	public void setMessage(NotificationExtendedInfoDTO message) {
		this.message = message;
	}

	public UserPushNotificationVO(Long id, Long sentDate, Boolean isRead, Long read_date,
			NotificationExtendedInfoDTO message) {
		super();
		this.id = id;
		this.sentDate = sentDate;
		this.isRead = isRead;
		this.read_date = read_date;
		this.message = message;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((isRead == null) ? 0 : isRead.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result + ((read_date == null) ? 0 : read_date.hashCode());
		result = prime * result + ((sentDate == null) ? 0 : sentDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserPushNotificationVO other = (UserPushNotificationVO) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (isRead == null) {
			if (other.isRead != null)
				return false;
		} else if (!isRead.equals(other.isRead))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (read_date == null) {
			if (other.read_date != null)
				return false;
		} else if (!read_date.equals(other.read_date))
			return false;
		if (sentDate == null) {
			if (other.sentDate != null)
				return false;
		} else if (!sentDate.equals(other.sentDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserPushNotificationVO [id=" + id + ", sentDate=" + sentDate + ", isRead=" + isRead + ", read_date="
				+ read_date + ", message=" + message + "]";
	}

	public UserPushNotificationVO() {
		super();
		// TODO Auto-generated constructor stub
	}    
    
    
}
