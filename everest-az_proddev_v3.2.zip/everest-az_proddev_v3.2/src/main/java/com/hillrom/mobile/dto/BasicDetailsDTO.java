package com.hillrom.mobile.dto;


import io.swagger.annotations.ApiModelProperty;

public class BasicDetailsDTO {

	
	public BasicDetailsDTO() {
		super();
	}
	@ApiModelProperty(notes="userId", dataType="java.lang.String", required=true)
	private Long userId;
	@ApiModelProperty(notes="device_UUID", dataType="java.lang.String", required=true)
	private String device_UUID;
	@ApiModelProperty(notes="device_type", dataType="java.lang.String", required=true)
	private String device_type;
	@ApiModelProperty(notes="version", dataType="java.lang.String", required=true)
	private String version;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getDevice_UUID() {	
		return device_UUID;	
	}	
	public void setDevice_UUID(String device_uUid) {	
		this.device_UUID = device_uUid;	
	}
	public String getDevice_type() {
		return device_type;
	}
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
}
