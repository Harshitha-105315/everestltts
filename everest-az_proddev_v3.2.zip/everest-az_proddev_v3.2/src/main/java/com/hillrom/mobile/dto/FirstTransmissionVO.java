package com.hillrom.mobile.dto;

public class FirstTransmissionVO {
	
	
	public FirstTransmissionVO() {
		super();
	}
	private	String firsttransmission_Vest;
	private	String firsttransmission_Monarch;
	private	String firsttransmission_Titan;
	private	String firsttransmission_Airway;
	private	String firsttransmission_Medication;
	private	String firsttransmission_Nutrition_history;
	private	String firsttransmission_Weight_history;
	private	String firsttransmission_Exercise_history;
	public String getFirsttransmission_Vest() {
		return firsttransmission_Vest;
	}
	public void setFirsttransmission_Vest(String firsttransmission_Vest) {
		this.firsttransmission_Vest = firsttransmission_Vest;
	}
	public String getFirsttransmission_Monarch() {
		return firsttransmission_Monarch;
	}
	public void setFirsttransmission_Monarch(String firsttransmission_Monarch) {
		this.firsttransmission_Monarch = firsttransmission_Monarch;
	}
	public String getFirsttransmission_Airway() {
		return firsttransmission_Airway;
	}
	public void setFirsttransmission_Airway(String firsttransmission_Airway) {
		this.firsttransmission_Airway = firsttransmission_Airway;
	}
	public String getFirsttransmission_Medication() {
		return firsttransmission_Medication;
	}
	public void setFirsttransmission_Medication(String firsttransmission_Medication) {
		this.firsttransmission_Medication = firsttransmission_Medication;
	}
	public String getFirsttransmission_Nutrition_history() {
		return firsttransmission_Nutrition_history;
	}
	public void setFirsttransmission_Nutrition_history(
			String firsttransmission_Nutrition_history) {
		this.firsttransmission_Nutrition_history = firsttransmission_Nutrition_history;
	}
	public String getFirsttransmission_Weight_history() {
		return firsttransmission_Weight_history;
	}
	public void setFirsttransmission_Weight_history(
			String firsttransmission_Weight_history) {
		this.firsttransmission_Weight_history = firsttransmission_Weight_history;
	}
	public String getFirsttransmission_Exercise_history() {
		return firsttransmission_Exercise_history;
	}
	public void setFirsttransmission_Exercise_history(
			String firsttransmission_Exercise_history) {
		this.firsttransmission_Exercise_history = firsttransmission_Exercise_history;
	}
	public String getFirsttransmission_Titan() {
		return firsttransmission_Titan;
	}
	public void setFirsttransmission_Titan(String firsttransmission_Titan) {
		this.firsttransmission_Titan = firsttransmission_Titan;
	}
	@Override
	public String toString() {
		return "FirstTransmissionVO [firsttransmission_Vest="
				+ firsttransmission_Vest + ", firsttransmission_Monarch="
				+ firsttransmission_Monarch + ", firsttransmission_Airway="
				+ firsttransmission_Airway + ", firsttransmission_Medication="
				+ firsttransmission_Medication
				+ ", firsttransmission_Nutrition_history="
				+ firsttransmission_Nutrition_history
				+ ", firsttransmission_Weight_history="
				+ firsttransmission_Weight_history
				+ ", firsttransmission_Exercise_history="
				+ firsttransmission_Exercise_history + ""
				+ ", firsttransmission_Titan="
				+ firsttransmission_Titan +"]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((firsttransmission_Airway == null) ? 0
						: firsttransmission_Airway.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Exercise_history == null) ? 0
						: firsttransmission_Exercise_history.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Medication == null) ? 0
						: firsttransmission_Medication.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Monarch == null) ? 0
						: firsttransmission_Monarch.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Nutrition_history == null) ? 0
						: firsttransmission_Nutrition_history.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Vest == null) ? 0
						: firsttransmission_Vest.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Weight_history == null) ? 0
						: firsttransmission_Weight_history.hashCode());
		result = prime
				* result
				+ ((firsttransmission_Titan == null) ? 0
						: firsttransmission_Titan.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FirstTransmissionVO other = (FirstTransmissionVO) obj;
		if (firsttransmission_Airway == null) {
			if (other.firsttransmission_Airway != null)
				return false;
		} else if (!firsttransmission_Airway
				.equals(other.firsttransmission_Airway))
			return false;
		if (firsttransmission_Exercise_history == null) {
			if (other.firsttransmission_Exercise_history != null)
				return false;
		} else if (!firsttransmission_Exercise_history
				.equals(other.firsttransmission_Exercise_history))
			return false;
		if (firsttransmission_Medication == null) {
			if (other.firsttransmission_Medication != null)
				return false;
		} else if (!firsttransmission_Medication
				.equals(other.firsttransmission_Medication))
			return false;
		if (firsttransmission_Monarch == null) {
			if (other.firsttransmission_Monarch != null)
				return false;
		} else if (!firsttransmission_Monarch
				.equals(other.firsttransmission_Monarch))
			return false;
		if (firsttransmission_Nutrition_history == null) {
			if (other.firsttransmission_Nutrition_history != null)
				return false;
		} else if (!firsttransmission_Nutrition_history
				.equals(other.firsttransmission_Nutrition_history))
			return false;
		if (firsttransmission_Vest == null) {
			if (other.firsttransmission_Vest != null)
				return false;
		} else if (!firsttransmission_Vest.equals(other.firsttransmission_Vest))
			return false;
		if (firsttransmission_Weight_history == null) {
			if (other.firsttransmission_Weight_history != null)
				return false;
		} else if (!firsttransmission_Weight_history
				.equals(other.firsttransmission_Weight_history))
			return false;
		if (firsttransmission_Titan == null) {
			if (other.firsttransmission_Titan != null)
				return false;
		} else if (!firsttransmission_Titan
				.equals(other.firsttransmission_Titan))
			return false;
		return true;
	}

}
