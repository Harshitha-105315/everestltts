package com.hillrom.mobile.rest;

import static com.hillrom.vest.util.MessageConstants.HR_241;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.mobile.dto.PatientTestResultsDTO;
import com.hillrom.mobile.dto.PatientVestDeviceDataMobileVO;
import com.hillrom.mobile.service.PateintTestResultMobileService;
import com.hillrom.mobile.service.PatientProtocolUnconnectedService;
import com.hillrom.mobile.service.PatientUnconnectedVestDeviceService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;
import com.hillrom.vest.web.rest.dto.ProtocolDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api")
@Api(description = "MOBILE RESOURCE")
public class MobileResource {

	private final Logger log = LoggerFactory.getLogger(MobileResource.class);

	@Inject
	private PatientProtocolUnconnectedService patientProtocolUnconnectedService;

	@Inject
	private PatientUnconnectedVestDeviceService patientUnconnectedVestDeviceService;

	@Inject
	private PatientProtocolService patientProtocolService;

	@Inject
	private PateintTestResultMobileService pateintTestResultMobileService;
	
	@Inject
	private UserService userService;
	
	@ApiOperation(httpMethod = "POST", value = "Add Protocol To Patient for Unconnected Vest Device ")
	@ApiImplicitParams({ @ApiImplicitParam(name = "deviceType", value = "Device Type", required = true, dataType = "String"),
		@ApiImplicitParam(name = "deviceValue", value = "Device Value", required = true, dataType = "String")})
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "CREATED"),
			@ApiResponse(code = 400, message = "BAD REQUEST") })
	@RequestMapping(value = "/patient/{id}/setupdevice/add",

			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<JSONObject> addProtocolToPatientForUnconnectedVestDevice(@PathVariable Long id,
			@RequestBody ProtocolDTO protocolDTO,
			@RequestParam(value = "deviceType", required = true) String deviceType,
			@RequestParam(value = "deviceValue", required = true) String deviceValue) {
		log.debug("REST request to add protocol with patient user : {}", id);

		JSONObject jsonObject = new JSONObject();
		try {
			patientUnconnectedVestDeviceService.setDefaultFRequencyAndPressureForNull(protocolDTO, deviceType);
			PatientInfo patient = userService.getPatientInfoObjFromPatientUserId(id);
			
			Object vestObj = patientUnconnectedVestDeviceService.linkUnconnectedVestToMonarch(patient.getId(), deviceType);
			
			List<PatientProtocolData> protocolList = patientProtocolUnconnectedService.addProtocolToUnconnectedVest(id,protocolDTO);
			
			if (Objects.nonNull(vestObj)) {
				jsonObject.put("ERROR", ExceptionConstants.HR_901);
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
			if (protocolList.isEmpty()) {
				jsonObject.put("message", ExceptionConstants.HR_902);
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
			 else {
				jsonObject.put("message", HR_241);
				jsonObject.put("protocol", protocolList);
				jsonObject.put("Serial Number", (Objects.nonNull(vestObj) ? ((PatientVestDeviceHistory) vestObj).getSerialNumber() : null));
				jsonObject.put("message", MessageConstants.HR_318);
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.CREATED);
			}
			
		} catch (HillromException hre) {
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "GET", value = "Retrieve Protocol List", response = PatientProtocolData.class)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "Patient UserId", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "deviceType", value = "Device Type", required = true, dataType = "String")
			 })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Retrieve a medication"),
			@ApiResponse(code = 400, message = "No protocol found for patient.") })
	@RequestMapping(value = "/patient/{id}/protocol/retrieve", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> getAllProtocols(@PathVariable Long id, @RequestParam(value = "deviceType", required = true) String deviceType){
		log.debug("REST request to get protocol for patient user : {}", id);
		JSONObject jsonObject = new JSONObject();
		try{			
			List<PatientProtocolData> protocolList_VEST = patientProtocolService.getActiveProtocolsAssociatedWithPatient(id);
			patientUnconnectedVestDeviceService.setDefaultFRequencyAndPressureForNull(protocolList_VEST);
			if(protocolList_VEST.isEmpty()){
				jsonObject.put("message", MessageConstants.HR_245);
			} else {
				List<Object> objectList = new ArrayList<>();
				for (PatientProtocolData patientProtocolData : protocolList_VEST){
					Object oneObject = patientProtocolData;
					objectList.add(oneObject);
				}
				jsonObject.put("protocol", objectList);
			}
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		}catch (HillromException hre){
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject,
					HttpStatus.BAD_REQUEST);

		}
	}

	@ApiOperation(httpMethod = "DELETE", value = "Delete Protocol For Patient")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "Patient UserId", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "protocolId", value = "Protocol Id", required = false, dataType = "String"),
			@ApiImplicitParam(name = "deviceType", value = "Device Type", required = true, dataType = "String") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Protocol deleted successfully."),
			@ApiResponse(code = 400, message = "BAD_REQUEST") })
	@RequestMapping(value = "/patient/{id}/protocol/{protocolId}/delete", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> deleteProtocolForPatient(@PathVariable Long id, @PathVariable String protocolId,
															   @RequestParam(value = "deviceType", required = true) String deviceType){
		log.debug("REST request to delete protocol for patient user : {}", id);
		JSONObject jsonObject = new JSONObject();
		try {
			String message = "Invalid Device Type";
			if(deviceType.equals("VEST")){
				message = patientProtocolService.deleteProtocolForPatient(id, protocolId);
			}
			if (!Objects.isNull(message)) {
				jsonObject.put("message", message);
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			} else {
				jsonObject.put("message", MessageConstants.HR_245);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		}catch (HillromException hre){
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "UPDATE", value = "Update Protocol For Patient")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "Patient UserId", required = false, dataType = "Long"),
			 })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Protocol updated successfully."),
			@ApiResponse(code = 400, message = "BAD_REQUEST"),
			@ApiResponse(code = 400, message = "Unable to update protocol.")})
	@RequestMapping(value = "/patient/{id}/protocol/unconnectedvestdevice",
			method = RequestMethod.PUT,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> updateProtocolToPatient(@PathVariable Long id,
																			  @RequestBody List<PatientProtocolData> patientProtocolDataList){
		log.debug("REST request to update protocol with patient user : {}", id);
		JSONObject jsonObject = new JSONObject();
		try{
			patientUnconnectedVestDeviceService.setDefaultFRequencyAndPressureForNull(patientProtocolDataList);
			List<PatientProtocolData> protocolList = patientProtocolUnconnectedService.updateProtocolToPatient(id, patientProtocolDataList);
			if (protocolList.isEmpty()) {
				jsonObject.put("ERROR", ExceptionConstants.HR_560);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			} else {
				jsonObject.put("message", MessageConstants.HR_242);
				jsonObject.put("protocol", protocolList);
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			}
		} catch (HillromException hre){
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@ApiOperation(httpMethod = "POST", value = "Ingest Data to Unconnected Vest",response = PatientVestDeviceDataMobileVO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 400, message = "BAD_REQUEST"),
			@ApiResponse(code = 400, message = "No valid events to form therapy sessions, Ingestion fail.")})
	@RequestMapping(value = "patient/v1.0/ingestData/add",

			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<JSONObject>  ingestDataToUnconnectedVest(@RequestBody(required = true) List<PatientVestDeviceDataMobileVO> vestDeviceDataList,
			@RequestHeader(value="x-auth-token",required=true)String authToken) {
		log.debug("REST request to ingest data to unconnectedVest: {}", vestDeviceDataList);	
		JSONObject jsonObject = new JSONObject();
		try {
			
			for(PatientVestDeviceDataMobileVO patientVestDeviceDataMobileList : vestDeviceDataList) {
                if(patientVestDeviceDataMobileList.getFrequency()==null) {
                       patientVestDeviceDataMobileList.setFrequency(Constants.MIN_FREQUENCY);
                }
                if(patientVestDeviceDataMobileList.getPressure()==null) {
                       patientVestDeviceDataMobileList.setPressure(Constants.MIN_PRESSURE);
                }
			}

			List<String> therpySessionList = patientUnconnectedVestDeviceService.
					ingestDataToDevice(vestDeviceDataList,authToken);

			if(therpySessionList.isEmpty()){
				jsonObject.put("message", MessageConstants.HR_319);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			} else {
				jsonObject.put("therpysession", therpySessionList);
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			}
		}
		catch (Exception hre){
			hre.printStackTrace();
			jsonObject.put("Error",hre.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
		
	@ApiOperation(httpMethod = "POST", value = "Add PFT Test results ")
	@ApiImplicitParams({@ApiImplicitParam(name = "pid", value = "pid", required = false, dataType = "String"),
		@ApiImplicitParam(name = "comments", value = "comments", required = false, dataType = "String"),
		@ApiImplicitParam(name = "fev1_L", value = "fev1_L", required = false, dataType = "Double"),
		@ApiImplicitParam(name = "fev1_P", value = "fev1_P", required = true, dataType = "Double"),
		@ApiImplicitParam(name = "fev1_TO_FVC_RATIO", value = "fev1_TO_FVC_RATIO", required = false, dataType = "Double"),
		@ApiImplicitParam(name = "fvc_L", value = "fvc_L", required = false, dataType = "Double"),
		@ApiImplicitParam(name = "fvc_P", value = "fvc_P", required = false, dataType = "Double"),
		@ApiImplicitParam(name = "pef_L_Min", value = "pef_L_Min", required = false, dataType = "Double"),
		@ApiImplicitParam(name = "pef_P", value = "pef_P", required = false, dataType = "Double"), 
		@ApiImplicitParam(name = "testResultDate", value = "testResultDate", required = true, dataType = "LocalDate")
	})
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "CREATED"),
			@ApiResponse(code = 400, message = "BAD REQUEST"),
			@ApiResponse(code = 422, message = "\"Failed: Invalid Date Range\" or "
					+ "\"Failed: No Patient is asscoiated  with  userid\"")
			})
	@RequestMapping(
			value = "/v1.0/testresult/user/{userId}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ AuthoritiesConstants.PATIENT })
	public ResponseEntity<?> addPatientTestResult(
			@RequestBody PatientTestResultsDTO patientTestResultsDTO,
			@PathVariable Long userId, HttpServletRequest request) {
		JSONObject jsonObject = new JSONObject();

		try {
			if (patientTestResultsDTO.getFev1_P() != null
					&& patientTestResultsDTO.getTestResultDate() != null) {
				String baseUrl = request.getScheme() + "://"
						+ request.getServerName() + ":"
						+ request.getServerPort();
				jsonObject = pateintTestResultMobileService.createPatientTestResult(patientTestResultsDTO, userId,
						baseUrl);
				if (jsonObject.containsValue(ExceptionConstants.HR_954) 
						|| jsonObject.containsValue(ExceptionConstants.HR_956)) {
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				}
			} else {
				jsonObject.put("message", ExceptionConstants.HR_916);
				return new ResponseEntity<JSONObject>(jsonObject,HttpStatus.BAD_REQUEST);
			}
		} catch (Exception hre) {
			log.error("Exception in addPatientTestResult: " + hre.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

	}
}


