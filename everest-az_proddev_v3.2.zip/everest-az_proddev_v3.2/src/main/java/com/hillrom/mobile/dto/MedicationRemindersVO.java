package com.hillrom.mobile.dto;

import java.util.List;

import com.hillrom.mobile.dto.ReminderVO;

public class MedicationRemindersVO {
	private String reminderDay;
	private List<ReminderVO> reminderList;
	
	public String getReminderDay() {
		return reminderDay;
	}
	public void setReminderDay(String reminderDay) {
		this.reminderDay = reminderDay;
	}
	public List<ReminderVO> getReminderList() {
		return reminderList;
	}
	public void setReminderList(List<ReminderVO> reminderList) {
		this.reminderList = reminderList;
	}
	@Override
	public String toString() {
		return "MedicationRemindersVO [reminderDay=" + reminderDay + ", reminderList=" + reminderList + "]";
	}
	public MedicationRemindersVO(String reminderDay, List<ReminderVO> reminderList) {
		super();
		this.reminderDay = reminderDay;
		this.reminderList = reminderList;
	}
	public MedicationRemindersVO() {
		super();
	}
	
}
