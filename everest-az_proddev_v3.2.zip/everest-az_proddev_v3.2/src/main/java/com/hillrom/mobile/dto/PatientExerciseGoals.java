package com.hillrom.mobile.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;

@JsonPropertyOrder({
"activityId",
"current",
"initial",
"activityName",
"awardId",
"isGoalAchieved",
"exercise history",
"target"
})
public class PatientExerciseGoals {

@JsonProperty("activityId")
@ApiModelProperty(notes="Activity Id (Long)", required=true)
private Long activityId;
@JsonProperty("current")
@ApiModelProperty(notes="Current", required=true)
private Long current;
@JsonProperty("initial")
@ApiModelProperty(notes="initial", required=true)
private Long initial;
@JsonProperty("awardId")
@ApiModelProperty(notes="Award Id", required=true)
private Long awardId;
@JsonProperty("achievedDate")
@ApiModelProperty(notes="Achieved Date", required=true)
private Long achievedDate;
@JsonProperty("activityName")
@ApiModelProperty(notes="Activity name", required=true)
private String activityName;
@JsonProperty("isGoalAchieved")
@ApiModelProperty(notes="Is Goal Achieved", required=true)
private Boolean isGoalAchieved;
@JsonProperty("Exercise history")
@ApiModelProperty(notes="Exercise History", required=true)
private List<PatientActivityHistoryVO> patientActivityHistoryVO = null;
@JsonProperty("target")
@ApiModelProperty(notes="Target", required=true)
private Long target;
@ApiModelProperty(notes="Goal start date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
private Long goalStartDate;
@ApiModelProperty(notes="Goal end date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
private Long goalEndDate;
@JsonProperty("extendedInfo")
@ApiModelProperty(notes="Extended Information", required=true)
private ExtendedInfoDTO extendedInfo;

@JsonProperty("activityId")
public Long getActivityId() {
return activityId;
}

@JsonProperty("activityId")
public void setActivityId(Long activityId) {
this.activityId = activityId;
}

@JsonProperty("current")
public Long getCurrent() {
return current;
}

@JsonProperty("current")
public void setCurrent(Long current) {
this.current = current;
}

@JsonProperty("initial")
public Long getInitial() {
return initial;
}

@JsonProperty("initial")
public void setInitial(Long initial) {
this.initial = initial;
}

@JsonProperty("activityName")
public String getActivityName() {
return activityName;
}

@JsonProperty("activityName")
public void setActivityName(String activityName) {
this.activityName = activityName;
}

@JsonProperty("isGoalAchieved")
public Boolean getIsGoalAchieved() {
return isGoalAchieved;
}

@JsonProperty("isGoalAchieved")
public void setIsGoalAchieved(Boolean isGoalAchieved) {
this.isGoalAchieved = isGoalAchieved;
}

@JsonProperty("target")
public Long getTarget() {
return target;
}

@JsonProperty("target")
public void setTarget(Long target) {
this.target = target;
}

public Long getAwardId() {
	return awardId;
}

public void setAwardId(Long awardId) {
	this.awardId = awardId;
}

public List<PatientActivityHistoryVO> getPatientActivityHistoryVO() {
	return patientActivityHistoryVO;
}

public void setPatientActivityHistoryVO(List<PatientActivityHistoryVO> patientActivityHistoryVO) {
	this.patientActivityHistoryVO = patientActivityHistoryVO;
}

public Long getAchievedDate() {
	return achievedDate;
}

public void setAchievedDate(Long achievedDate) {
	this.achievedDate = achievedDate;
}

public Long getGoalStartDate() {
	return goalStartDate;
}

public void setGoalStartDate(Long goalStartDate) {
	this.goalStartDate = goalStartDate;
}

public Long getGoalEndDate() {
	return goalEndDate;
}

public void setGoalEndDate(Long goalEndDate) {
	this.goalEndDate = goalEndDate;
}

public ExtendedInfoDTO getExtendedInfo() {
	return extendedInfo;
}

public void setExtendedInfo(ExtendedInfoDTO extendedInfo) {
	this.extendedInfo = extendedInfo;
}

}