package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class NotificationExtendedInfoDTO {
	private String category;
	private String type;
	private String title;
	private String description;
	private String header;
	
	// default 
	private Long imageId;
	
	// medication
	private Long medicationId;
	
	//Awards
	private Long awardId;
	private Long activityId;
	private String activityType;
	
	// Badges
	private Long badgeId;
	private String badgeCategory;
	private String badgeType;
	
	//Image,Thumbnail
	private String image;
	private String thumbNail;
	
	public String getThumbNail() {
		return thumbNail;
	}
	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getImageId() {
		return imageId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public void setImageId(Long imageId) {
		this.imageId = imageId;
	}
	public Long getAwardId() {
		return awardId;
	}
	public void setAwardId(Long awardId) {
		this.awardId = awardId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public Long getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(Long badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeCategory() {
		return badgeCategory;
	}
	public void setBadgeCategory(String badgeCategory) {
		this.badgeCategory = badgeCategory;
	}
	public String getBadgeType() {
		return badgeType;
	}
	public void setBadgeType(String badgeType) {
		this.badgeType = badgeType;
	}
	public Long getMedicationId() {
		return medicationId;
	}
	public void setMedicationId(Long medicationId) {
		this.medicationId = medicationId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public NotificationExtendedInfoDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the header
	 */
	public String getHeader() {
		return header;
	}
	/**
	 * @param header the header to set
	 */
	public void setHeader(String header) {
		this.header = header;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NotificationExtendedInfoDTO [category=" + category + ", type=" + type + ", title=" + title
				+ ", description=" + description + ", header=" + header + ", imageId=" + imageId + ", medicationId="
				+ medicationId + ", awardId=" + awardId + ", activityId=" + activityId + ", activityType="
				+ activityType + ", badgeId=" + badgeId + ", badgeCategory=" + badgeCategory + ", badgeType="
				+ badgeType + ", image=" + image + ", thumbNail=" + thumbNail + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityId == null) ? 0 : activityId.hashCode());
		result = prime * result + ((activityType == null) ? 0 : activityType.hashCode());
		result = prime * result + ((awardId == null) ? 0 : awardId.hashCode());
		result = prime * result + ((badgeCategory == null) ? 0 : badgeCategory.hashCode());
		result = prime * result + ((badgeId == null) ? 0 : badgeId.hashCode());
		result = prime * result + ((badgeType == null) ? 0 : badgeType.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((header == null) ? 0 : header.hashCode());
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + ((imageId == null) ? 0 : imageId.hashCode());
		result = prime * result + ((medicationId == null) ? 0 : medicationId.hashCode());
		result = prime * result + ((thumbNail == null) ? 0 : thumbNail.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NotificationExtendedInfoDTO other = (NotificationExtendedInfoDTO) obj;
		if (activityId == null) {
			if (other.activityId != null)
				return false;
		} else if (!activityId.equals(other.activityId))
			return false;
		if (activityType == null) {
			if (other.activityType != null)
				return false;
		} else if (!activityType.equals(other.activityType))
			return false;
		if (awardId == null) {
			if (other.awardId != null)
				return false;
		} else if (!awardId.equals(other.awardId))
			return false;
		if (badgeCategory == null) {
			if (other.badgeCategory != null)
				return false;
		} else if (!badgeCategory.equals(other.badgeCategory))
			return false;
		if (badgeId == null) {
			if (other.badgeId != null)
				return false;
		} else if (!badgeId.equals(other.badgeId))
			return false;
		if (badgeType == null) {
			if (other.badgeType != null)
				return false;
		} else if (!badgeType.equals(other.badgeType))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (header == null) {
			if (other.header != null)
				return false;
		} else if (!header.equals(other.header))
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (imageId == null) {
			if (other.imageId != null)
				return false;
		} else if (!imageId.equals(other.imageId))
			return false;
		if (medicationId == null) {
			if (other.medicationId != null)
				return false;
		} else if (!medicationId.equals(other.medicationId))
			return false;
		if (thumbNail == null) {
			if (other.thumbNail != null)
				return false;
		} else if (!thumbNail.equals(other.thumbNail))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
}
