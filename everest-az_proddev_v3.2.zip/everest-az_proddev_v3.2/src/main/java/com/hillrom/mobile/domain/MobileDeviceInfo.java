package com.hillrom.mobile.domain;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MOBILE_DEVICE_INFO")
public class MobileDeviceInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	@ApiModelProperty(notes = "ID of award", dataType = "java.lang.Long", required = true)
	private Long id;
	@Column(name = "patient_id")
	private String patientId;
	
	
	@Column(name = "device_token")
	private String device_token;
	
	@Column(name = "UUID")
	private String device_UUID;
	
	public String getDevice_UUID() {
		return device_UUID;
	}
	public void setDevice_UUID(String device_UUID) {
		this.device_UUID = device_UUID;
	}
	@Column(name = "serial_number")
	private String serial_number;
	
	@Column(name = "authentication_type")
	private Long authentication_type;
	
	@Column(name = "platform_type")
	private Long platform_type;
	
	@Column(name = "mobile_registration_datetime")
	private Long mobile_registration_datetime;
	
	@Column(name="authentication_flag")
	private Boolean authentication_flag;
	
	@Column(name="x_auth_token")
	private String auth_token;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getDevice_token() {
		return device_token;
	}
	public void setDevice_token(String device_token) {
		this.device_token = device_token;
	}

	public String getSeraial_number() {
		return serial_number;
	}
	public void setSeraial_number(String serial_number) {
		this.serial_number = serial_number;
	}
	public Long getAuthentication_type() {
		return authentication_type;
	}
	public void setAuthentication_type(Long authentication_type) {
		this.authentication_type = authentication_type;
	}
	public Long getPlatform_type() {
		return platform_type;
	}
	public void setPlatform_type(Long platform_type) {
		this.platform_type = platform_type;
	}
	public Long getMobile_registration_datetime() {
		return mobile_registration_datetime;
	}
	public void setMobile_registration_datetime(Long mobile_registration_datetime) {
		this.mobile_registration_datetime = mobile_registration_datetime;
	}
	public Boolean getAuthentication_flag() {
		return authentication_flag;
	}
	public void setAuthentication_flag(Boolean authentication_flag) {
		this.authentication_flag = authentication_flag;
	}
	public String getAuth_token() {
		return auth_token;
	}
	public void setAuth_token(String auth_token) {
		this.auth_token = auth_token;
	}
	
	@Override
	public String toString() {
		return "MobileDeviceInfo [id=" + id + ", patientId=" + patientId + ", device_token=" + device_token
				+ ", device_UUID=" + device_UUID + ", serial_number=" + serial_number + ", authentication_type="
				+ authentication_type + ", platform_type=" + platform_type + ", mobile_registration_datetime="
				+ mobile_registration_datetime + ", authentication_flag=" + authentication_flag + ", auth_token="
				+ auth_token + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((auth_token == null) ? 0 : auth_token.hashCode());
		result = prime * result + ((authentication_flag == null) ? 0 : authentication_flag.hashCode());
		result = prime * result + ((authentication_type == null) ? 0 : authentication_type.hashCode());
		result = prime * result + ((device_UUID == null) ? 0 : device_UUID.hashCode());
		result = prime * result + ((device_token == null) ? 0 : device_token.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((mobile_registration_datetime == null) ? 0 : mobile_registration_datetime.hashCode());
		result = prime * result + ((patientId == null) ? 0 : patientId.hashCode());
		result = prime * result + ((platform_type == null) ? 0 : platform_type.hashCode());
		result = prime * result + ((serial_number == null) ? 0 : serial_number.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MobileDeviceInfo other = (MobileDeviceInfo) obj;
		if (auth_token == null) {
			if (other.auth_token != null)
				return false;
		} else if (!auth_token.equals(other.auth_token))
			return false;
		if (authentication_flag == null) {
			if (other.authentication_flag != null)
				return false;
		} else if (!authentication_flag.equals(other.authentication_flag))
			return false;
		if (authentication_type == null) {
			if (other.authentication_type != null)
				return false;
		} else if (!authentication_type.equals(other.authentication_type))
			return false;
		if (device_UUID == null) {
			if (other.device_UUID != null)
				return false;
		} else if (!device_UUID.equals(other.device_UUID))
			return false;
		if (device_token == null) {
			if (other.device_token != null)
				return false;
		} else if (!device_token.equals(other.device_token))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (mobile_registration_datetime == null) {
			if (other.mobile_registration_datetime != null)
				return false;
		} else if (!mobile_registration_datetime.equals(other.mobile_registration_datetime))
			return false;
		if (patientId == null) {
			if (other.patientId != null)
				return false;
		} else if (!patientId.equals(other.patientId))
			return false;
		if (platform_type == null) {
			if (other.platform_type != null)
				return false;
		} else if (!platform_type.equals(other.platform_type))
			return false;
		if (serial_number == null) {
			if (other.serial_number != null)
				return false;
		} else if (!serial_number.equals(other.serial_number))
			return false;
		return true;
	}
	
}
