package com.hillrom.mobile.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "nutritionHistory",
        "awardsHistory",
        "anyActiveGoal",
        "currentGoal"
})
public class NutritionHistoryVO {

    @JsonProperty("nutritionHistory")
    private List<NutritionHistoryDTO> nutritionHistory = null;
    @JsonProperty("awardsHistory")
    private List<AwardsNutritionHistoryVO> awardsHistory = null;
    @JsonProperty("anyActiveGoal")
    private boolean anyActiveGoal;
    @JsonProperty("currentGoal")
    private CurrentNutritionGoalDTO currentGoal;

    @JsonProperty("nutritionHistory")
    public List<NutritionHistoryDTO> getNutritionHistory() {
        return nutritionHistory;
    }

    @JsonProperty("nutritionHistory")
    public void setNutritionHistory(List<NutritionHistoryDTO> nutritionHistory) {
        this.nutritionHistory = nutritionHistory;
    }

    @JsonProperty("awardsHistory")
    public List<AwardsNutritionHistoryVO> getAwardsHistory() {
        return awardsHistory;
    }

    @JsonProperty("awardsHistory")
    public void setAwardsHistory(List<AwardsNutritionHistoryVO> awardsHistory) {
        this.awardsHistory = awardsHistory;
    }

    @JsonProperty("anyActiveGoal")
    public boolean isAnyActiveGoal() {
        return anyActiveGoal;
    }

    @JsonProperty("anyActiveGoal")
    public void setAnyActiveGoal(boolean anyActiveGoal) {
        this.anyActiveGoal = anyActiveGoal;
    }

    @JsonProperty("currentGoal")
    public CurrentNutritionGoalDTO getCurrentGoal() {
        return currentGoal;
    }

    @JsonProperty("currentGoal")
    public void setCurrentGoal(CurrentNutritionGoalDTO currentGoal) {
        this.currentGoal = currentGoal;
    }
}