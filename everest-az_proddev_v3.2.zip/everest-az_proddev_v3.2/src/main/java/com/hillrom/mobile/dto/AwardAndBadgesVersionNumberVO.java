package com.hillrom.mobile.dto;

public class AwardAndBadgesVersionNumberVO {

	private String awardAndBadgesVersionNumber;

	public String getAwardAndBadgesVersionNumber() {
		return awardAndBadgesVersionNumber;
	}

	public void setAwardAndBadgesVersionNumber(String awardAndBadgesVersionNumber) {
		this.awardAndBadgesVersionNumber = awardAndBadgesVersionNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((awardAndBadgesVersionNumber == null) ? 0
						: awardAndBadgesVersionNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AwardAndBadgesVersionNumberVO other = (AwardAndBadgesVersionNumberVO) obj;
		if (awardAndBadgesVersionNumber == null) {
			if (other.awardAndBadgesVersionNumber != null)
				return false;
		} else if (!awardAndBadgesVersionNumber
				.equals(other.awardAndBadgesVersionNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AwardAndBadgesVersionNumberVO [awardAndBadgesVersionNumber="
				+ awardAndBadgesVersionNumber + "]";
	}
}
