package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.mobile.domain.MedicationReminderDetails;
import com.hillrom.mobile.dto.MedicationRemindersVO;

public interface MedicationReminderDetailsRepository extends
		JpaRepository<MedicationReminderDetails, String> {

	@Query("from MedicationReminderDetails mrd where mrd.id = ?1 ")
	List<MedicationReminderDetails> findByPatientId(Long id);
	
	@Query("from MedicationReminderDetails mrd where mrd.medicationRecordingsId = ?1 ")
	List<MedicationRemindersVO> findByMedicationId(Long medicationId);
	
	@Query("from MedicationReminderDetails mrd where mrd.medicationRecordingsId = ?1 ")
	List<MedicationReminderDetails> findByMedicationIdByDTO(Long medicationId);
	
	@Query("from MedicationReminderDetails mrd where mrd.id = ?1 and mrd.medicationRecordingsId = ?2 ")
	MedicationReminderDetails findByMedicationIdAndReminderId(Long reminderId, Long medicationId);
	
	MedicationReminderDetails findById(Long id);
	

	@Query("from MedicationReminderDetails mrd where mrd.medicationRecordingsId = ?1 and reminderDay= ?2 ")
	List<MedicationReminderDetails> findByMedicationIdAndDayName(Long medicationId, String day);
	
	@Query(nativeQuery=true,
			 value="SELECT mrd.id, mrd.reminder_time, htcv.type_code_value"
 			 		+ " FROM MEDICATION_REMINDER_DETAILS mrd " 
 					+ " JOIN HILLROM_TYPE_CODE_VALUES htcv ON mrd.reminder_day = htcv.id "
 					+ " where medication_recordings_id=?1")
	List<Object[]> findByMedicationIdWithHillromTypeCode(Long medicationId);
	
	@Query(nativeQuery=true,
			value="select count(*) FROM MEDICATION_REMINDER_DETAILS "
					+ " where medication_recordings_id=?1")
	int getCountByMedicationId(Long medicationId);
	
	
	 @Override
	    void delete(MedicationReminderDetails t);
}
