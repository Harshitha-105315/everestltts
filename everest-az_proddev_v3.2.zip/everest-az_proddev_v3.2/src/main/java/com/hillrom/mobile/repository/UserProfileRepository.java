package com.hillrom.mobile.repository;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.hibernate.internal.SessionImpl;
import org.springframework.stereotype.Repository;


/**
 * Spring Data JPA repository for the Tims Patient & Patient User entity.
 */
@Repository
public class UserProfileRepository{
	
	@Inject
	private EntityManager entityManager;
	
	public Map<String, Object> getAllBasicDetailsForUser(int userId,
										String device_uUid,
										String device_type)  throws SQLException,Exception{

		
			Map<String,Object> returnValues = new HashMap<String, Object>();
	
			try{
				
				
				java.sql.Connection connection = entityManager.unwrap(SessionImpl.class).connection();
				  CallableStatement callableStatement = connection.prepareCall("{call get_mobile_info(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				  callableStatement.setInt(1, userId);
				  callableStatement.setString(2, device_uUid);
				  callableStatement.setString(3, device_type);
				 
				callableStatement.execute();
				callableStatement.registerOutParameter(4, Types.VARCHAR);
				callableStatement.registerOutParameter(5, Types.BIGINT);
				callableStatement.registerOutParameter(6, Types.BIGINT);
				callableStatement.registerOutParameter(7, Types.DATE);
				callableStatement.registerOutParameter(8, Types.DATE);
				callableStatement.registerOutParameter(9, Types.DATE); //titan first transmission
				callableStatement.registerOutParameter(10, Types.BIGINT);
				callableStatement.registerOutParameter(11, Types.TIMESTAMP);
				callableStatement.registerOutParameter(12, Types.BIGINT);
				callableStatement.registerOutParameter(13, Types.BIGINT);
				callableStatement.registerOutParameter(14,  Types.INTEGER);
				callableStatement.registerOutParameter(15,  Types.FLOAT);	// fev1_p
				callableStatement.registerOutParameter(16,  Types.BIGINT);	// last pft date
				callableStatement.registerOutParameter(17,  Types.INTEGER);
				callableStatement.registerOutParameter(18,  Types.INTEGER);
				callableStatement.registerOutParameter(19,  Types.VARCHAR);
				callableStatement.registerOutParameter(20,  Types.VARCHAR);
				callableStatement.registerOutParameter(21,  Types.VARCHAR);
				callableStatement.registerOutParameter(22,  Types.VARCHAR);
				callableStatement.registerOutParameter(23,  Types.VARCHAR);
				callableStatement.registerOutParameter(24,  Types.VARCHAR);
				callableStatement.registerOutParameter(25,  Types.VARCHAR);
				callableStatement.registerOutParameter(26,  Types.VARCHAR);
				callableStatement.registerOutParameter(27,  Types.VARCHAR);
				callableStatement.registerOutParameter(28,  Types.VARCHAR); // garment_type
				callableStatement.registerOutParameter(29,  Types.VARCHAR);
				callableStatement.registerOutParameter(30,   Types.VARCHAR);
				callableStatement.registerOutParameter(31,   Types.VARCHAR);
				callableStatement.registerOutParameter(32,   Types.VARCHAR);
				callableStatement.registerOutParameter(33,   Types.VARCHAR);
				callableStatement.registerOutParameter(34,   Types.VARCHAR);
				callableStatement.registerOutParameter(35,  Types.VARCHAR);
				callableStatement.registerOutParameter(36,   Types.VARCHAR);
				callableStatement.registerOutParameter(37,   Types.VARCHAR);
				callableStatement.registerOutParameter(38,   Types.VARCHAR);
				callableStatement.registerOutParameter(39,   Types.VARCHAR);
				callableStatement.registerOutParameter(40,   Types.VARCHAR);
				callableStatement.registerOutParameter(41,   Types.VARCHAR);
				callableStatement.registerOutParameter(42,   Types.VARCHAR);
				callableStatement.registerOutParameter(43,  Types.VARCHAR);
				callableStatement.registerOutParameter(44,   Types.VARCHAR);
				callableStatement.registerOutParameter(45,   Types.VARCHAR);
				callableStatement.registerOutParameter(46,   Types.VARCHAR); //titan min freq
				callableStatement.registerOutParameter(47,   Types.VARCHAR);
				callableStatement.registerOutParameter(48,   Types.VARCHAR);
				callableStatement.registerOutParameter(49,   Types.VARCHAR);
				callableStatement.registerOutParameter(50,   Types.VARCHAR);
				callableStatement.registerOutParameter(51,  Types.VARCHAR);
				callableStatement.registerOutParameter(52,   Types.VARCHAR);
				callableStatement.registerOutParameter(53,   Types.VARCHAR); //titan protocol type
				callableStatement.registerOutParameter(54,   Types.DOUBLE); // vest HMR
				callableStatement.registerOutParameter(55,   Types.DOUBLE); //monarch HMR
				callableStatement.registerOutParameter(56,   Types.DOUBLE); //titan HMR
				callableStatement.registerOutParameter(57,   Types.BIGINT); //  vest last transmission date
				callableStatement.registerOutParameter(58,   Types.BIGINT); // monarch last transmission date
				callableStatement.registerOutParameter(59,   Types.BIGINT); // titan last transmission date
				callableStatement.registerOutParameter(60,   Types.INTEGER); // Monarch protocol duration
				callableStatement.registerOutParameter(61,   Types.INTEGER); // Vest protocol duration
				callableStatement.registerOutParameter(62,   Types.INTEGER); // Titan protocol duration
				callableStatement.registerOutParameter(63,   Types.BIGINT); // First Test Result date
				callableStatement.registerOutParameter(64,   Types.VARCHAR); // o_byod
				callableStatement.registerOutParameter(65,   Types.VARCHAR); // o_byodDND
				callableStatement.registerOutParameter(66,   Types.VARCHAR); // o_dndDeviceIdentifier
				callableStatement.registerOutParameter(67,   Types.VARCHAR); // o_byodState
				callableStatement.registerOutParameter(68,   Types.VARCHAR); // o_byodLastUpdate
				callableStatement.registerOutParameter(69,   Types.VARCHAR); // o_byodDeviceIdentifier
				callableStatement.registerOutParameter(70,   Types.VARCHAR); // o_byodOptOutRequestedDate
				callableStatement.registerOutParameter(71,   Types.VARCHAR); // o_byodOptOutDeviceIdentifier
				callableStatement.registerOutParameter(72,   Types.VARCHAR); // o_byodOptOutAgreedDate
				callableStatement.registerOutParameter(73,   Types.VARCHAR); // o_byodOptOutReason
				callableStatement.registerOutParameter(74,   Types.VARCHAR); // o_byodOptOutFeedback
				callableStatement.registerOutParameter(75,   Types.VARCHAR); // o_deviceAddress

					String serialNumber = (String) callableStatement.getString(4);
					BigInteger weight = BigInteger.valueOf(callableStatement.getLong(5));	// current value
                    Long firsttransmission_Weight_history = (callableStatement.getLong(6));

                    Date firsttransmission_Vest =  callableStatement.getDate(7); //
                    Date firsttransmission_Monarch = callableStatement.getDate(8);
                    Date firsttransmission_Titan = callableStatement.getDate(9);
                    Long firsttransmission_Airway = callableStatement.getLong(10);
                    Timestamp firsttransmission_Medication =  callableStatement.getTimestamp(11);
                    BigInteger firsttransmission_Exercise_history = BigInteger.valueOf(callableStatement.getLong(12));
                    BigInteger firsttransmission_Nutrition_history = BigInteger.valueOf(callableStatement.getLong(13));
                    
                    Integer latest_Adherence_score = callableStatement.getInt(14);
                    Float latest_pulmonary_value = callableStatement.getFloat(15);
                    Long latest_pft_result_date = callableStatement.getLong(16);
                    
                    Integer medication_count = callableStatement.getInt(17);
                    Integer airway_therapy_count = callableStatement.getInt(18);
                    
                    String height = (String) callableStatement.getString(19);
                    String origin = (String) callableStatement.getString(20);
                    String gender = (String) callableStatement.getString(21);
                    
                    // device details
                    String deviceSerialNumberCsv = (String) callableStatement.getString(22);
    				String deviceTypeCsv = (String) callableStatement.getString(23);
    				String isManualCsv = (String) callableStatement.getString(24);
    				String deviceNameCsv = (String) callableStatement.getString(25);
    				String deviceSizeCsv = (String) callableStatement.getString(26);
    				String deviceColorCsv = (String) callableStatement.getString(27);
    				String deviceGarmentTypeCsv = (String) callableStatement.getString(28);
    				String isActiveCsv = (String) callableStatement.getString(29);

    				// vest protocol details
    				String minFreq = (String) callableStatement.getString(30);
    				String maxFreq = (String) callableStatement.getString(31);
    				String minMpt = (String) callableStatement.getString(32);
    				String maxMpt = (String) callableStatement.getString(33);
    				String minPressure = (String) callableStatement.getString(34);
    				String maxPressure = (String) callableStatement.getString(35);
    				String tpd = (String) callableStatement.getString(36);
    				String protocolType = (String) callableStatement.getString(37);
    				
    				// monarch protocol details
    				String minFreqM = (String) callableStatement.getString(38);
    				String maxFreqM = (String) callableStatement.getString(39);
    				String minMptM = (String) callableStatement.getString(40);
    				String maxMptM = (String) callableStatement.getString(41);
    				String minPressureM = (String) callableStatement.getString(42);
    				String maxPressureM = (String) callableStatement.getString(43);
    				String tpdM = (String) callableStatement.getString(44);
    				String protocolTypeM = (String) callableStatement.getString(45);
    				
    				// titan protocol details
    				String minFreqT = (String) callableStatement.getString(46);
    				String maxFreqT = (String) callableStatement.getString(47);
    				String minMptT = (String) callableStatement.getString(48);
    				String maxMptT = (String) callableStatement.getString(49);
    				String minPressureT = (String) callableStatement.getString(50);
    				String maxPressureT = (String) callableStatement.getString(51);
    				String tpdT = (String) callableStatement.getString(52);
    				String protocolTypeT = (String) callableStatement.getString(53);

    				// hmr details
    				Double vestHMR = (Double) (callableStatement.getDouble(54));
    				Double monarchHMR = (Double) (callableStatement.getDouble(55));
    				Double titanHMR = (Double) (callableStatement.getDouble(56));

    				Long vest_last_transmission_date =  callableStatement.getLong(57); //
                    Long monarch_last_transmission_date = callableStatement.getLong(58);
                    Long titan_last_transmission_date = callableStatement.getLong(59);

                    Integer monarch_therapy_duration = callableStatement.getInt(60);
                    Integer vest_therapy_duration = callableStatement.getInt(61);
                    Integer titan_therapy_duration = callableStatement.getInt(62);
                    
                    Long test_result_first_transmission_date = callableStatement.getLong(63);
                    String is_byod = callableStatement.getString(64);
                    String is_dnd =callableStatement.getString(65);
                    String dnd_device_identifier= callableStatement.getString(66);
                    String byod_state = callableStatement.getString(67);
                    String byod_last_updated= callableStatement.getString(68); 
                    String byod_device_identifier= callableStatement.getString(69);
                    String opt_out_requested_date = callableStatement.getString(70);
                    String opt_out_device_identifier = callableStatement.getString(71);
                    String opt_out_agreed_date =callableStatement.getString(72);
                    String opt_out_reason = callableStatement.getString(73);
                    String opt_out_feedback =callableStatement.getString(74);
                    String deviceAddress =callableStatement.getString(75);
                    
				returnValues.put("serialNumber", serialNumber);
				returnValues.put("firsttransmission_Vest", firsttransmission_Vest);
				returnValues.put("firsttransmission_Monarch", firsttransmission_Monarch);
				returnValues.put("firsttransmission_Titan", firsttransmission_Titan);
				returnValues.put("firsttransmission_Airway", firsttransmission_Airway);
				returnValues.put("firsttransmission_Medication", firsttransmission_Medication);
				returnValues.put("firsttransmission_Exercise_history", firsttransmission_Exercise_history);
				returnValues.put("weight", weight);
				returnValues.put("firsttransmission_Weight_history", firsttransmission_Weight_history);
				returnValues.put("firsttransmission_Nutrition_history", firsttransmission_Nutrition_history);
				returnValues.put("latest_Adherence_score", latest_Adherence_score);
				returnValues.put("latest_pulmonary_value", latest_pulmonary_value);
				returnValues.put("last_pft_result_date", latest_pft_result_date);
				returnValues.put("test_result_first_transmission_date", test_result_first_transmission_date);
				returnValues.put("medication_count", medication_count);
				returnValues.put("airway_therapy_count", airway_therapy_count);
				returnValues.put("height", height);
				returnValues.put("origin", origin);
				returnValues.put("gender", gender);
				returnValues.put("deviceSerialNumberCsv", deviceSerialNumberCsv);
				returnValues.put("deviceTypeCsv", deviceTypeCsv);
				returnValues.put("isManualCsv", isManualCsv);
				returnValues.put("deviceNameCsv", deviceNameCsv);
				returnValues.put("deviceSizeCsv", deviceSizeCsv);
				returnValues.put("deviceColorCsv", deviceColorCsv);
				returnValues.put("deviceGarmentTypeCsv", deviceGarmentTypeCsv);
				returnValues.put("isActiveCsv", isActiveCsv);
				returnValues.put("minFreq", minFreq);
				returnValues.put("maxFreq", maxFreq);
				returnValues.put("minMpt", minMpt);
				returnValues.put("maxMpt", maxMpt);
				returnValues.put("minPressure", minPressure);
				returnValues.put("maxPressure", maxPressure);
				returnValues.put("tpd", tpd);
				returnValues.put("protocolType", protocolType);
				returnValues.put("minFreqM", minFreqM);
				returnValues.put("maxFreqM", maxFreqM);
				returnValues.put("minMptM", minMptM);
				returnValues.put("maxMptM", maxMptM);
				returnValues.put("minPressureM", minPressureM);
				returnValues.put("maxPressureM", maxPressureM);
				returnValues.put("tpdM", tpdM);
				returnValues.put("protocolTypeM", protocolTypeM);
				returnValues.put("minFreqT", minFreqT);
				returnValues.put("maxFreqT", maxFreqT);
				returnValues.put("minMptT", minMptT);
				returnValues.put("maxMptT", maxMptT);
				returnValues.put("minPressureT", minPressureT);
				returnValues.put("maxPressureT", maxPressureT);
				returnValues.put("tpdT", tpdT);
				returnValues.put("protocolTypeT", protocolTypeT);
				returnValues.put("vestHMR",vestHMR);
				returnValues.put("monarchHMR",monarchHMR);
				returnValues.put("titanHMR",titanHMR);
				returnValues.put("vest_last_transmission_date",vest_last_transmission_date);
				returnValues.put("monarch_last_transmission_date",monarch_last_transmission_date);
				returnValues.put("titan_last_transmission_date",titan_last_transmission_date);
				returnValues.put("monarch_therapy_duration",monarch_therapy_duration);
				returnValues.put("vest_therapy_duration",vest_therapy_duration);
				returnValues.put("titan_therapy_duration",titan_therapy_duration);
				returnValues.put("is_byod",is_byod);
				returnValues.put("is_dnd",is_dnd);
				returnValues.put("dnd_device_identifier",dnd_device_identifier);
				returnValues.put("byod_state",byod_state);
				returnValues.put("byod_last_updated",byod_last_updated);
				returnValues.put("byod_device_identifier",byod_device_identifier);
				returnValues.put("opt_out_requested_date",opt_out_requested_date);
				returnValues.put("opt_out_device_identifier",opt_out_device_identifier);
				returnValues.put("opt_out_agreed_date",opt_out_agreed_date);
				returnValues.put("opt_out_reason",opt_out_reason);
				returnValues.put("opt_out_feedback",opt_out_feedback);
				returnValues.put("deviceAddress",deviceAddress);
			}
			catch(SQLException se)
			{
				throw se;
				//log.debug(se.getMessage());
			}catch(Exception e){
				e.printStackTrace();
				
			}
			return returnValues;

	}

	
}

