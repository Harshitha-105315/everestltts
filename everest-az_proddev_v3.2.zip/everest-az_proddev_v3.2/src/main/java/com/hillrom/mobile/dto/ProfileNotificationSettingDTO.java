package com.hillrom.mobile.dto;

public class ProfileNotificationSettingDTO {
	Long userId;
	boolean remindersSetting;
	boolean deviationAlert;
	boolean notificationsSettings;
	boolean achievementsSetting;
	boolean rtpSetting;
	boolean newTherapySetting;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public boolean isRemindersSetting() {
		return remindersSetting;
	}
	public void setRemindersSetting(boolean remindersSetting) {
		this.remindersSetting = remindersSetting;
	}
	public boolean isDeviationAlert() {
		return deviationAlert;
	}
	public void setDeviationAlert(boolean deviationAlert) {
		this.deviationAlert = deviationAlert;
	}
	public boolean isNotificationsSettings() {
		return notificationsSettings;
	}
	public void setNotificationsSettings(boolean notificationsSettings) {
		this.notificationsSettings = notificationsSettings;
	}
	public boolean isAchievementsSetting() {
		return achievementsSetting;
	}
	public void setAchievementsSetting(boolean achievementsSetting) {
		this.achievementsSetting = achievementsSetting;
	}
	public boolean isRtpSetting() {
		return rtpSetting;
	}
	public void setRtpSetting(boolean rtpSetting) {
		this.rtpSetting = rtpSetting;
	}
	public boolean isNewTherapySetting() {
		return newTherapySetting;
	}
	public void setNewTherapySetting(boolean newTherapySetting) {
		this.newTherapySetting = newTherapySetting;
	}
	
	@Override
	public String toString() {
		return "ProfileNotificationSettingDTO [userId=" + userId + ", remindersSetting=" + remindersSetting
				+ ", deviationAlert=" + deviationAlert + ", notificationsSettings=" + notificationsSettings
				+ ", achievementsSetting=" + achievementsSetting + ", rtpSetting=" + rtpSetting + ", newTherapySetting="
				+ newTherapySetting + "]";
	}
}
