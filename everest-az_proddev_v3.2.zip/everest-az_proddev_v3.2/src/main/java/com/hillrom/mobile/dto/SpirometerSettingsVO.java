package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class SpirometerSettingsVO {

	@ApiModelProperty(value = "patientId ", required = true)
	private String pid;
	@ApiModelProperty(value = "weight", required = true)
	private String weight;
	@ApiModelProperty(value = "height ", required = true)
	private String height;
	@ApiModelProperty(value = "origin ", required = true)
	private String origin;
	@ApiModelProperty(value = "gender ", required = true)
	private String gender;

	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "SpirometerSettingsVO [pid=" + pid + ", weight=" + weight + ", height=" + height
				+ ", origin=" + origin + ", gender=" + gender + "]";
	}
	public SpirometerSettingsVO(String pid, String weight, String height, String origin, String gender) {
		super();
		this.pid = pid;
		this.weight = weight;
		this.height = height;
		this.origin = origin;
		this.gender = gender;
	}
	public SpirometerSettingsVO() {
		super();
		// TODO Auto-generated constructor stub
	}
}

