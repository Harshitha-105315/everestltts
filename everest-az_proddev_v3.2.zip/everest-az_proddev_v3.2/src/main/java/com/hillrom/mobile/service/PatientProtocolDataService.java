package com.hillrom.mobile.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.hillrom.mobile.dto.PatientProtocolDataDTO;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;

import net.minidev.json.JSONObject;

@Service
@Transactional
public class PatientProtocolDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PatientProtocolDataService.class);

	@Inject
	private PatientProtocolRepository patientProtocolRepository;

	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject
	private PatientUnconnectedVestDeviceService patientUnconnectedVestDeviceService;

	@Inject
	private PatientVestDeviceRepository patientVestDeviceRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;

	public List<PatientProtocolData> createProtocol(PatientProtocolDataDTO protocolDTO) throws HillromException {
		LOGGER.debug("Adding new protocol with information: {}", protocolDTO);
		List<PatientProtocolData> protocolList = new LinkedList<>();
		PatientInfo patientInfo = patientInfoRepository.getOne(protocolDTO.getPid());

		if (patientInfo != null) {
			Object vest_object = patientUnconnectedVestDeviceService.linkUnconnectedVestToMonarch(patientInfo.getId(),
					"VEST");
			
			User patientUser = getPatientUserObjFromPatientInfo(patientInfo);
			
			if (Objects.nonNull(vest_object)) {

				if (patientUser != null) {
					String protocolKey = patientProtocolRepository.id();
					List<PatientProtocolData> ppdList = patientProtocolRepository.findByPatientId(patientInfo.getId());

					Optional<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepository
							.findOneBySerialNumber((patientInfo.getId() + "_UV"));
					if (activeDevice.isPresent()) {
						activeDevice.get().setName(protocolDTO.getDeviceName());
						activeDevice.get().setIsManual(true);
					} else {
						throw new HillromException(ExceptionConstants.HR_903);
					}
					patientDevicesAssocRepository.saveAndFlush(activeDevice.get());
					List<PatientVestDeviceHistory> activedeviceHistoryList = patientVestDeviceRepository.
							findOneBySerialNumberAndStatusActive((patientInfo.getId() + "_UV"));
					if(activedeviceHistoryList.size() > 1) {
						throw new HillromException(ExceptionConstants.HR_903);
					} else {
						activedeviceHistoryList.get(0).setIsManual(true);
						activedeviceHistoryList.get(0).setName(protocolDTO.getDeviceName());
					}
					patientVestDeviceRepository.saveAndFlush(activedeviceHistoryList.get(0));
					PatientDevicesAssoc oPatientDevicesAssoc = new PatientDevicesAssoc();
					if (!Objects.isNull(ppdList)) {
						PatientProtocolData ppd = new PatientProtocolData();

						ppd.setId(patientInfo.getId() + 1);
						ppd.setPatientUser(patientUser);
						ppd.setPatient(patientInfo);
						ppd.setProtocolKey(protocolKey);
						ppd.setTreatmentsPerDay(protocolDTO.getNoOfTimesaDay());
						
						if(Objects.isNull(protocolDTO.getMinFrequency())) {
							ppd.setMinFrequency(Constants.MIN_FREQUENCY);
						} else {
							ppd.setMinFrequency(protocolDTO.getMinFrequency());
						}
						
						if(Objects.isNull(protocolDTO.getMaxFrequency())) {
							ppd.setMaxFrequency(Constants.MAX_FREQUENCY);
						} else {
							ppd.setMaxFrequency(protocolDTO.getMaxFrequency());
						}
						if(Objects.isNull(protocolDTO.getMinPressure())) {
							ppd.setMinPressure(Constants.MIN_PRESSURE);
						} else {
							ppd.setMinPressure(protocolDTO.getMinPressure());
						}
						if(Objects.isNull(protocolDTO.getMaxPressure())) {
							ppd.setMaxPressure(Constants.MAX_PRESSURE);
						} else {
							ppd.setMaxPressure(protocolDTO.getMaxPressure());
						}
						if(Objects.isNull(protocolDTO.getDuration())) {
							ppd.setMinMinutesPerTreatment(Constants.MIN_DURATION);
						} else {
							ppd.setMinMinutesPerTreatment(protocolDTO.getDuration());
						}
						ppd.setDeviceType("VEST");
						ppd.setType("Normal");
						oPatientDevicesAssoc.setIsActive(true);
						protocolList.add(ppd);
						patientProtocolRepository.save(protocolList);
						patientDevicesAssocRepository.saveAndFlush(oPatientDevicesAssoc);
						return protocolList;
					} else {
						throw new HillromException(ExceptionConstants.HR_512);						
					}
				} else {
					throw new HillromException(ExceptionConstants.HR_523);
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_904); // Vest Patient Not Created
			}

		} else {
			throw new HillromException(ExceptionConstants.HR_903);
		}
	}

	private User getPatientUserObjFromPatientInfo(PatientInfo patientInfo) {
		User user = null;
		for (UserPatientAssoc patientAssoc : patientInfo.getUserPatientAssoc()) {
			if (RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())) {
				user = patientAssoc.getUser();
			}
		}
		return user;
	}

	public List<PatientProtocolData> updateProtocol(PatientProtocolDataDTO protocolDTO) throws HillromException {
		LOGGER.debug("Updating protocol with information: {}", protocolDTO);
		List<PatientProtocolData> protocolList = new LinkedList<>();
		PatientInfo patientInfo = patientInfoRepository.getOne(protocolDTO.getPid());
		if (patientInfo != null) {
			User patientUser = getPatientUserObjFromPatientInfo(patientInfo);
			if (patientUser != null) {
				//String protocolKey = patientProtocolRepository.id();
				List<PatientProtocolData> ppdList = patientProtocolRepository.findByPatientId(patientInfo.getId());
				Optional<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepository
						.findOneBySerialNumber((patientInfo.getId() + "_UV"));
				if (activeDevice.isPresent()) {
					activeDevice.get().setName(protocolDTO.getDeviceName());
					activeDevice.get().setIsManual(true);
				} else {
					throw new HillromException(ExceptionConstants.HR_906);
				}
				//PatientDevicesAssoc oPatientDevicesAssoc = new PatientDevicesAssoc();
				if (!Objects.isNull(ppdList) && ppdList.size() > 0) {
					PatientProtocolData ppd = ppdList.get(0);//new PatientProtocolData();

					//ppd.setId(patientInfo.getId() + 1);
					//ppd.setPatientUser(patientUser);
					//ppd.setPatient(patientInfo);
					//ppd.setProtocolKey(protocolKey);
					if(Objects.nonNull(protocolDTO.getNoOfTimesaDay()) && 
							(protocolDTO.getNoOfTimesaDay() != ppd.getTreatmentsPerDay())) {
						ppd.setTreatmentsPerDay(protocolDTO.getNoOfTimesaDay());
					}
					if(Objects.nonNull(protocolDTO.getMinFrequency()) &&
							(protocolDTO.getMinFrequency() != ppd.getMinFrequency())) {
						ppd.setMinFrequency(protocolDTO.getMinFrequency());
					}
					if(Objects.nonNull(protocolDTO.getMaxFrequency()) && 
							(protocolDTO.getMaxFrequency() != ppd.getMaxFrequency())) {
						ppd.setMaxFrequency(protocolDTO.getMaxFrequency());
					}

 					if(Objects.nonNull(protocolDTO.getMinPressure()) && 
							(protocolDTO.getMinPressure() != ppd.getMinPressure())) {
						ppd.setMinPressure(protocolDTO.getMinPressure());
					}

 					if(Objects.nonNull(protocolDTO.getMaxPressure()) && 
							(protocolDTO.getMaxPressure() != ppd.getMaxPressure())) {
						ppd.setMaxPressure(protocolDTO.getMaxPressure());
					}

 					if(Objects.nonNull(protocolDTO.getDuration()) && 
							(protocolDTO.getDuration() != ppd.getMinMinutesPerTreatment())) {
						ppd.setMinMinutesPerTreatment(protocolDTO.getDuration());
					}
					//ppd.setDeviceType("VEST");
					//ppd.setType("Normal");
					//oPatientDevicesAssoc.setIsActive(true);
					protocolList.add(ppd);
					patientProtocolRepository.save(protocolList);
					//patientDevicesAssocRepository.saveAndFlush(activeDevice.get());
					//patientDevicesAssocRepository.saveAndFlush(oPatientDevicesAssoc);
					return protocolList;
				} else {
					throw new HillromException(ExceptionConstants.HR_906);
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_512);
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_523);
		}
	}

	public JSONObject deactivateUnconnectedVestFromPatient(String serialNumber) throws HillromException, JSONException {
		JSONObject jsonObject = new JSONObject();
		Optional<PatientDevicesAssoc> pdaVest = patientDevicesAssocRepository.findOneBySerialNumber(serialNumber);
		if (!pdaVest.isPresent()) {
			throw new HillromException(ExceptionConstants.HR_571);
		} else {
			List<UserPatientAssoc> patientUser = userPatientRepository.findByPatientIdAndUserRole(pdaVest.get().getPatientId(),AuthoritiesConstants.PATIENT);
			if (Objects.nonNull(patientUser)) {
				/*User user = userRepository.findOne(patientUser.get(0).getUser().getId());
				if (Objects.nonNull(user)) {
					throw new HillromException(ExceptionConstants.HR_512);// No such user exist
				}
				PatientInfo patientInfo = getPatientInfoObjFromPatientUser(user);*/
				PatientInfo patientInfo = patientInfoRepository.findOneById(patientUser.get(0).getUserPatientAssocPK().getPatient().getId());
				if (Objects.nonNull(patientInfo)) {
					Optional<PatientVestDeviceHistory> pvdh = patientVestDeviceRepository
							.findOneByPatientIdAndSerialNumber(patientInfo.getId(), serialNumber);
					if (pvdh.isPresent()) {
						if (pvdh.get().isActive()) {
							
							// When dis-associated update the latest hmr
							pvdh.get().setActive(false);
							pvdh.get().setLastModifiedDate(DateTime.now());
							
							pdaVest.get().setIsActive(false);
							pdaVest.get().setPatientType("SD");
							
							List<PatientDevicesAssoc> pdaMonarch = patientDevicesAssocRepository.
									findByPatientIdAndDeviceType(pdaVest.get().getPatientId(), "MONARCH");
							pdaMonarch.get(0).setPatientType("SD");
	                        
							patientDevicesAssocRepository.save(pdaVest.get());
							patientVestDeviceRepository.save(pvdh.get());
							
							patientInfo.setSerialNumber(null);
							patientInfo.setBluetoothId(null);
							patientInfo.setHubId(null);
							patientInfo.setDeviceAssocDate(null);
							
							patientInfoRepository.save(patientInfo);
							jsonObject.put("did", pvdh.get().getSerialNumber());

						} else {
							throw new HillromException(ExceptionConstants.HR_570);// Vest device is already in Inactive
																					// mode
						}
					} else {
						throw new HillromException(ExceptionConstants.HR_571);// Invalid Serial Number
					}
				} else {
					throw new HillromException(ExceptionConstants.HR_523);// No such patient exist
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_512);// No such user exist
			}
		}

		return jsonObject;
	}
	
	public void setDefaultFRequencyAndPressureForNull(PatientProtocolDataDTO patientProtocolDataDTO) {
		try {
			if((patientProtocolDataDTO.getMinFrequency())==null) {
				patientProtocolDataDTO.setMinFrequency(Constants.MIN_FREQUENCY);
			}
			if((patientProtocolDataDTO.getMaxFrequency())==null) {
				patientProtocolDataDTO.setMaxFrequency(Constants.MAX_FREQUENCY);
			}
			if((patientProtocolDataDTO.getMinPressure())==null) {
				patientProtocolDataDTO.setMinPressure(Constants.MIN_PRESSURE);
			}
			if((patientProtocolDataDTO.getMaxPressure())==null) {
				patientProtocolDataDTO.setMaxPressure(Constants.MAX_PRESSURE);
			}
		} catch (Exception ex) {
			LOGGER.debug("setDefaultFRequencyAndPressureForNull " + ex.getMessage());
		}
	}
}
