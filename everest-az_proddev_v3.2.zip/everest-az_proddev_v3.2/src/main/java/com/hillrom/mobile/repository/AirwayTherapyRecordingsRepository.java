package com.hillrom.mobile.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.AirwayTherapyRecordings;



@Repository
public interface AirwayTherapyRecordingsRepository extends JpaRepository<AirwayTherapyRecordings, Long>, QueryDslPredicateExecutor<AirwayTherapyRecordings> {

	long countByPid(String pid);
	List<AirwayTherapyRecordings> findByPid(String pid, Pageable pageRequest);
	
	@Query(" FROM AirwayTherapyRecordings atr where atr.pid = ?1 and dateTime between ?2 and ?3")
	ArrayList<AirwayTherapyRecordings> findByPatientIdAndDateRange(String pid,Long startDate,Long endDate);
	
	@Query(" FROM AirwayTherapyRecordings atr where atr.pid = ?1 and dateTime <= ?2")
	ArrayList<AirwayTherapyRecordings> findByPatientIdAndEndDate(String pid,Long endDate);
	
	@Query(" FROM AirwayTherapyRecordings atr where atr.pid = ?1 and dateTime >= ?2")
	ArrayList<AirwayTherapyRecordings> findByPatientIdAndStartDate(String pid,Long startDate);
	
	@Query("from AirwayTherapyRecordings atrs where atrs.pid = ?1 and atrs.dateTime = ?2 and atrs.name = ?3")
	List<AirwayTherapyRecordings> findByDateTimeAndName(String pid,Long dateTime,String name);

	@Query(" FROM AirwayTherapyRecordings atr where atr.pid = ?1 ")
	ArrayList<AirwayTherapyRecordings> findByPatientId(String pid);
}
