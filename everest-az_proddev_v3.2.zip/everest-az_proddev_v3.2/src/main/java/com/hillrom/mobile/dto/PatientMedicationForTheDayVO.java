package com.hillrom.mobile.dto;


import java.util.List;

public class PatientMedicationForTheDayVO {
	
		private Long medicationId;
		private String medicationType;
		private String medicationName;
		private String medicationNote;
		private List<ReminderVO> medicationReminder; 
		private boolean medicationTakenStatus;
		
		public Long getMedicationId() {
			return medicationId;
		}
		public void setMedicationId(Long medicationId) {
			this.medicationId = medicationId;
		}
		public String getMedicationType() {
			return medicationType;
		}
		public void setMedicationType(String medicationType) {
			this.medicationType = medicationType;
		}
		public String getMedicationName() {
			return medicationName;
		}
		public void setMedicationName(String medicationName) {
			this.medicationName = medicationName;
		}
		public String getMedicationNote() {
			return medicationNote;
		}
		public void setMedicationNote(String medicationNote) {
			this.medicationNote = medicationNote;
		}
		public List<ReminderVO> getMedicationReminder() {
			return medicationReminder;
		}
		public void setMedicationReminder(List<ReminderVO> medicationReminder) {
			this.medicationReminder = medicationReminder;
		}
		public boolean getMedicationTakenStatus() {
			return medicationTakenStatus;
		}
		public void setMedicationTakenStatus(boolean medicationTakenStatus) {
			this.medicationTakenStatus = medicationTakenStatus;
		}
		public PatientMedicationForTheDayVO(Long medicationId,
				String medicationType, String medicationName,
				String medicationNote, List<ReminderVO> medicationReminder,
				boolean medicationTakenStatus) {
			super();
			this.medicationId = medicationId;
			this.medicationType = medicationType;
			this.medicationName = medicationName;
			this.medicationNote = medicationNote;
			this.medicationReminder = medicationReminder;
			this.medicationTakenStatus = medicationTakenStatus;
		}
		public PatientMedicationForTheDayVO() {
			super();
		}
		@Override
		public String toString() {
			return "PatientMedicationForTheDayVO [medicationId=" + medicationId
					+ ", medicationType=" + medicationType
					+ ", medicationName=" + medicationName
					+ ", medicationNote=" + medicationNote
					+ ", medicationReminder=" + medicationReminder
					+ ", medicationTakenStatus=" + medicationTakenStatus + "]";
		}
}
