package com.hillrom.mobile.dto;

public class TherapyReminderDTO {
	String pid;
	String reminders;

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getReminders() {
		return reminders;
	}

	public void setReminders(String reminders) {
		this.reminders = reminders;
	}

	@Override
	public String toString() {
		return "TherapyReminderDTO [pid=" + pid + ", reminders=" + reminders + "]";
	}

	public TherapyReminderDTO(String pid, String reminders) {
		super();
		this.pid = pid;
		this.reminders = reminders;
	}
	
	public TherapyReminderDTO() {
		super();
	}

}
