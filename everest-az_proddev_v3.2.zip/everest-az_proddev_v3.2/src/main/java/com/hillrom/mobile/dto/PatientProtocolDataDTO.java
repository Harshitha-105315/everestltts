package com.hillrom.mobile.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Patient", description = "Creating a new Unconnected Vest Device")
public class PatientProtocolDataDTO {

	@NotNull(message = "Patient ID may not be null")
	@ApiModelProperty(value = "Person's first name", required = true)
	private String pid;
	
	@NotNull
	@Min(value = 1, message = "No of times a day should not be less than 0")
	@ApiModelProperty(value = "No of times a day", required = true)
	private Integer noOfTimesaDay;
	
	@Min(value = 5, message = "Minimum frequency should not be less than 0")
	@ApiModelProperty(value = "Minimum frequency", required = false)
	private Integer minFrequency;
	
	@Min(value = 20, message = "Maximum frequency should not be less than 20")
	@ApiModelProperty(value = "Maximum frequency", required = false)
	private Integer maxFrequency;
	
	@Min(value = 1, message = "Minimum pressure should not be less than 0")
	@ApiModelProperty(value = "Minimum pressure", required = false)
	private Integer minPressure;
	
	@Min(value = 20, message = "Maximum pressure should not be less than 10")
	@ApiModelProperty(value = "Maximum pressure", required = false)
	private Integer maxPressure;
	
	@Min(value = 0, message = "Duration should not be less than 0")
	@ApiModelProperty(value = "Duration", required = true)
	private Integer duration;

	@NotNull(message = "Device Name may not be null")
	@ApiModelProperty(value = "Device name", required = true)
	private String deviceName;
	
	@ApiModelProperty(value = "Device Serial Number", required = true)
	private String did;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Integer getNoOfTimesaDay() {
		return noOfTimesaDay;
	}
	public void setNoOfTimesaDay(Integer noOfTimesaDay) {
		this.noOfTimesaDay = noOfTimesaDay;
	}
	public Integer getMinFrequency() {
		return minFrequency;
	}
	public void setMinFrequency(Integer minFrequency) {
		this.minFrequency = minFrequency;
	}
	public Integer getMaxFrequency() {
		return maxFrequency;
	}
	public void setMaxFrequency(Integer maxFrequency) {
		this.maxFrequency = maxFrequency;
	}
	public Integer getMinPressure() {
		return minPressure;
	}
	public void setMinPressure(Integer minPressure) {
		this.minPressure = minPressure;
	}
	public Integer getMaxPressure() {
		return maxPressure;
	}
	public void setMaxPressure(Integer maxPressure) {
		this.maxPressure = maxPressure;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
}
