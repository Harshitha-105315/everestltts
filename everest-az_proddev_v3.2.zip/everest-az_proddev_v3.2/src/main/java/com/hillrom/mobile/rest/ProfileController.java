package com.hillrom.mobile.rest;


import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hillrom.mobile.dto.BYODUpdateDTO;
import com.hillrom.mobile.dto.BasicDetailsDTO;
import com.hillrom.mobile.dto.BasicInfoDetailsVO;
import com.hillrom.mobile.dto.MedicationTakenListDTO;
import com.hillrom.mobile.dto.PatientProfileDetailsDTO;
import com.hillrom.mobile.dto.ProfileNotificationSettingDTO;
import com.hillrom.mobile.dto.ProfileOnboardingDetailsDTO;
import com.hillrom.mobile.dto.ProfileUpdateVO;
import com.hillrom.mobile.dto.SpirometerSettingsVO;
import com.hillrom.mobile.dto.TherapyReminderDTO;
import com.hillrom.mobile.service.ProfileService;
import com.hillrom.titan.service.PatientVestDeviceTitanService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.security.AesUtil;
import com.hillrom.vest.service.util.DecodeToDecryptUtil;
import com.hillrom.vest.util.ExceptionConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.minidev.json.JSONObject;

@RestController
@Api(value = "Profile Details of patient", description = "PROFILE CONTROLLER")
@RequestMapping("/api/patient/"+ Constants.ApiVersion)
public class ProfileController implements EnvironmentAware{

	private final Logger log = LoggerFactory.getLogger(ProfileController.class);
	
	private RelaxedPropertyResolver propertyResolver;
	
	@Inject
	private ProfileService profileService;
	
	@Inject
	private PatientVestDeviceTitanService patientVestDeviceTitanService;


    @RequestMapping(value = "/profile/spirometerSettings/update", method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(httpMethod = "PUT", value = "Adding the spirometer settings",
	notes = "weight is optional value", responseContainer = "List")
    @ApiImplicitParams({
    @ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
    @ApiImplicitParam(name = "weight", value = "weight", required = false, dataType = "String"),
    @ApiImplicitParam(name = "height", value = "height", required = true, dataType = "String"),
    @ApiImplicitParam(name = "origin", value = "origin", required = true, dataType = "String"),
    @ApiImplicitParam(name = "gender", value = "gender", required = true, dataType = "String")})
    @ApiResponses(value = {
		    @ApiResponse(code = 200, message =  ExceptionConstants.HR_940 
		    		+ " or \r\n" +  ExceptionConstants.HR_941
		    		+ " or \r\n" + ExceptionConstants.HR_915
		    		+ " or \r\n" + ExceptionConstants.HR_916)})
	public ResponseEntity<JSONObject> spirometerSettingForPatient(
	            @RequestBody SpirometerSettingsVO spirometerSetting ){
	     log.debug("REST request to set SpirometerSetting associated for patient : {}");
	     JSONObject jsonObject = new JSONObject();
	
	     if (spirometerSetting.getPid() != null && spirometerSetting.getHeight() != null
	                  && spirometerSetting.getGender() != null && spirometerSetting.getOrigin() != null) {
	            try {
	                  jsonObject = profileService.addSpirometerSettings(spirometerSetting);
	                  if(!jsonObject.isEmpty()) {
	                         return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	                  } else{
	                         return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	                  }
	            } catch (Exception e) {
	                  jsonObject.put("message", e.getMessage());
	                  return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
	            }
	
	     } else {
	            jsonObject.put("message", ExceptionConstants.HR_916);
	            return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
	     }
	}

	
    @RequestMapping(value = "/profile/patientDetails/retrieve/{userId}", method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Retrieving all the patient Details",
	notes = "Patient Details will have multiple values", responseContainer = "List" ,response = PatientProfileDetailsDTO.class)
	@ApiImplicitParams({@ApiImplicitParam(name = "userId", value = "user Id", required = true, dataType = "String")}) 
	@ApiResponses(value = {@ApiResponse(code = 200, message = ExceptionConstants.HR_512)})
	public ResponseEntity<JSONObject> getAllPatientDetails(@PathVariable Long userId) {
		log.debug("REST request to get all patient Details : {}");
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject = profileService.getPatientDetails(userId);
			if(jsonObject.containsValue(ExceptionConstants.HR_512)) {
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			}
		}catch(Exception e){
			e.printStackTrace();
			log.error("getAllPatientDetails : " + e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
    @ApiOperation(httpMethod = "GET", value = "Retrievie Timezones", responseContainer = "Map", response=Map.class)
	@RequestMapping(value = "/profile/timezonelist/retrieve", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> genericTimeZonesList() {
		JSONObject jsonObject = new JSONObject();
		Map<String, String> map = new LinkedHashMap<String, String>();
		try {
			map = profileService.getGenericWindowsTimeZonesList();
			if (map.size() > 0) {
				jsonObject.put("message", "TIME_ZONES_FETCH_SUCCESS");
				jsonObject.put("timezones", map);
			}
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
		} catch (Exception e) {
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@ApiOperation(httpMethod = "POST", value = "Add Onboarding Details")
	@ApiImplicitParams({ @ApiImplicitParam(name = "userId", value = "User Id", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "device_token", value = "Device Token", required = true, dataType = "String"),
			@ApiImplicitParam(name = "device_UUID", value = "UUID", required = true, dataType = "String"),
			@ApiImplicitParam(name = "device_type", value = "Device_Type", required = false, dataType = "String"),
			@ApiImplicitParam(name = "authentication_type", value = "faceId or touchId or PIN", required = false, dataType = "String")})
	@ApiResponses(value = { @ApiResponse(code = 201, message = ExceptionConstants.HR_949),
							@ApiResponse(code = 200, message = ExceptionConstants.HR_512
												+ " or \r\n" + ExceptionConstants.HR_937
												+ " or \r\n" + ExceptionConstants.HR_936
												+ " or \r\n" + ExceptionConstants.HR_915
												+ " or \r\n" + ExceptionConstants.HR_916)})
	@RequestMapping(value = "/profile/onboarding/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> createProfileOnboarding(@RequestBody ProfileOnboardingDetailsDTO 
			profileOnboardingDetailsDTO,@RequestHeader(value="x-auth-token",required=true)String authToken) {
		JSONObject jsonObject = new JSONObject();
		try {
	        if(profileOnboardingDetailsDTO.getUserId() !=null & profileOnboardingDetailsDTO.getDevice_type() !=null & 
	        		profileOnboardingDetailsDTO.getDevice_token() !=null & profileOnboardingDetailsDTO.getDevice_UUID() !=null ){
	        	jsonObject = profileService.addProfileOnboardingDetails(profileOnboardingDetailsDTO,authToken);
				if(jsonObject.containsValue(ExceptionConstants.HR_949)) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
	        } else {
	        	log.error(ExceptionConstants.HR_916);
	        	jsonObject.put("message", ExceptionConstants.HR_916);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
	        	
	        }
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/profile/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Updating the patient Details", notes = "Patient Details will have multiple values", responseContainer = "List")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = ExceptionConstants.HR_915 + " or \r\n" + ExceptionConstants.HR_937) })
	public ResponseEntity<?> updatePatientDetails(@RequestParam(value = "userId", required = true) Long userId,
			@RequestParam(value = "profilePictureImage", required = false) MultipartFile file,
			@RequestParam(value = "emailId", required = false) String rawEmailId,
			@RequestParam(value = "password", required = false) String rawPassword,
			@RequestParam(value = "isPictureUpdated", required = false) boolean isPictureUpdated,
			@RequestParam(value = "profilePictureType", required = false) String profilePictureType,
			@RequestParam(value = "timeZone", required = false) String timeZone,
			@RequestParam(value = "primaryPhone", required = false) String primaryPhone,
			@RequestParam(value = "secondaryPhone", required = false) String secondaryPhone,
			@RequestParam(value = "remindersSetting", required = false) boolean remindersSetting,
			@RequestParam(value = "deviationAlert", required = false) boolean deviationAlert,
			@RequestParam(value = "notificationsSettings", required = false) boolean notificationsSettings,
			HttpServletRequest request) {
		log.debug("REST request to get update patient Details : {}");
		JSONObject jsonObject = new JSONObject();
		String baseUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
		try {
			// Get the filename and build the local file path
			int keySize = propertyResolver.getProperty("keysize", Integer.class);
			int iterationCount = propertyResolver.getProperty("iterationcount", Integer.class);
			String pass_phrase = propertyResolver.getProperty("passphrase");
			
			AesUtil aesUtil = new AesUtil(keySize, iterationCount);
			
			String decodedMessageEmailId = null;
			String decodedMessagePassword = null;
			
			if(StringUtils.isNotBlank(rawEmailId)) {
				decodedMessageEmailId = DecodeToDecryptUtil.decodeRawMessegeforDecryption(rawEmailId);
			}						
			if(StringUtils.isNotBlank(rawPassword)) {
			decodedMessagePassword = DecodeToDecryptUtil.decodeRawMessegeforDecryption(rawPassword);
			}
			String decryptedEmailId = null;
			String decryptedPassword = null;
			
			if (decodedMessageEmailId != null && decodedMessageEmailId.split("::").length == 3) {
				decryptedEmailId = aesUtil.decrypt(decodedMessageEmailId.split("::")[1],
						decodedMessageEmailId.split("::")[0], pass_phrase, decodedMessageEmailId.split("::")[2]);
			}
			if (decodedMessagePassword != null && decodedMessagePassword.split("::").length == 3) {
				decryptedPassword = aesUtil.decrypt(decodedMessagePassword.split("::")[1],
						decodedMessagePassword.split("::")[0], pass_phrase, decodedMessagePassword.split("::")[2]);
			}
			ProfileUpdateVO profileUpdateVO = new ProfileUpdateVO();
			profileUpdateVO.setDeviationAlert(deviationAlert);
			profileUpdateVO.setEmailId(decryptedEmailId);
			profileUpdateVO.setPassword(decryptedPassword);
			profileUpdateVO.setPictureUpdated(isPictureUpdated);
			profileUpdateVO.setPrimaryPhone(primaryPhone);
			profileUpdateVO.setSecondaryPhone(secondaryPhone);
			profileUpdateVO.setUserId(userId);
			profileUpdateVO.setTimeZone(timeZone);
			profileUpdateVO.setNotificationsSetting(notificationsSettings);
			profileUpdateVO.setRemindersSetting(remindersSetting);

			jsonObject = profileService.updatePatientDetails(profileUpdateVO, file, profilePictureType, baseUrl);
			if (!jsonObject.isEmpty()) {
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

	}

	@RequestMapping(value = "/profile/notificationSetting", method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Updating the patient Details",
	notes = "Patient Details will have multiple values", responseContainer = "List")
	/*@ApiImplicitParams({
		@ApiImplicitParam(name = "userId", value = "user Id", required = true, dataType = "Long")})*/
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = ExceptionConstants.HR_915
					+ " or \r\n" + ExceptionConstants.HR_937)})
	public ResponseEntity<?> updateNotificationSetting(@RequestBody(required=true) ProfileNotificationSettingDTO profileNotificationSetting)
		{	
			log.debug("REST request to update notification Setting :"+profileNotificationSetting);
			JSONObject jsonObject = new JSONObject();
			
			try {
				// Get the filename and build the local file path
				ProfileUpdateVO profileUpdateVO = new ProfileUpdateVO();
				//UserExtension patientUser = userExtensionRepository.findOne(profileNotificationSetting.getUserId());
				List<PatientVestDeviceHistoryTitan> deviceList_titan = patientVestDeviceTitanService.getLinkedVestDeviceWithPatientTitan(profileNotificationSetting.getUserId());
				List<PatientVestDeviceHistoryTitan> activeDeviceList = deviceList_titan.stream().filter(patientDevice -> patientDevice.isActive()).collect(Collectors.toList());
				log.debug("activeDeviceList for rtpSetting :"+activeDeviceList);			
				
				profileUpdateVO.setDeviationAlert(profileNotificationSetting.isDeviationAlert());
				profileUpdateVO.setUserId(profileNotificationSetting.getUserId());		
				//profileUpdateVO.setNotificationsSetting(profileNotificationSetting.isNotificationsSettings());
				profileUpdateVO.setAchievementsSetting(profileNotificationSetting.isNotificationsSettings());
				profileUpdateVO.setRemindersSetting(profileNotificationSetting.isRemindersSetting());
				//profileUpdateVO.setAchievementsSetting(profileNotificationSetting.isAchievementsSetting());
				profileUpdateVO.setNewTherapySetting(profileNotificationSetting.isNewTherapySetting());
				if(!activeDeviceList.isEmpty())
					profileUpdateVO.setRtpSetting(profileNotificationSetting.isRtpSetting());
				
				log.debug("Request data profileUpdateVO :"+profileUpdateVO);
				jsonObject = profileService.updatePatientNotificationSettings(profileUpdateVO);
				if(!jsonObject.isEmpty()) {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}		
			} catch (Exception e) {
				jsonObject.put("message", e.getMessage());
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}			

		}

	
	@RequestMapping(value = "/profile/basicinfo/retrieve", method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Retrieving basicinfo ",
	notes = "Patient Details will have multiple values", responseContainer = "List",response =BasicInfoDetailsVO.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "userId", value = "user Id", required = true, dataType = "Long"),
		@ApiImplicitParam(name = "device_UUID", value = "UUID", required = true, dataType = "String"),
		@ApiImplicitParam(name = "device_type", value = "Device type", required = true, dataType = "String"),
		@ApiImplicitParam(name = "version", value = "version", required = false, dataType = "String")})
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = ExceptionConstants.HR_915
					+ " or \r\n" + ExceptionConstants.HR_916
					+ " or \r\n" + ExceptionConstants.HR_512
					+ " or \r\n" + ExceptionConstants.HR_948
					+ " or \r\n" + ExceptionConstants.HR_942
					+ " or \r\n" + ExceptionConstants.HR_916)})
	public ResponseEntity<Object> getAllBasicDetails(@RequestBody BasicDetailsDTO basicDTO ,
			@RequestHeader(value="x-auth-token",required=true)String authToken)  {
		log.debug("REST request to get all Basic  Details : {}");
		JSONObject jsonObject = new JSONObject();
	
	 if(basicDTO.getUserId() != 0 && basicDTO.getDevice_type() !=null 
			 &&  basicDTO.getDevice_UUID() !=null ){
			try {
				String token = authToken;
				jsonObject =profileService.getallBasicDetails(basicDTO,token);
				if(Objects.nonNull(jsonObject)){
	//				jsonObject.put("message", basicInfoDetailsVO);
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				} else {
					jsonObject.put("message",ExceptionConstants.HR_915 );
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			} catch (Exception e) {
				e.printStackTrace();
				jsonObject.put("message", e.getMessage());
				return new ResponseEntity<>(jsonObject, HttpStatus.FORBIDDEN);
			}
		} else {
			jsonObject.put("message", ExceptionConstants.HR_916);
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	

	@RequestMapping(value = "/profile/retrieveForceUpgrade/{version}/{deviceType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getForceUpgrade(@PathVariable String version,@PathVariable String deviceType) {
					
		log.debug("REST request to getForceUpgrade : {}");
		JSONObject jsonObject = new JSONObject();
		Pattern pattern = Pattern.compile("(\\d+\\.)(\\d+\\.)(\\d+\\.)(\\d+)");
	    Matcher matcher = pattern.matcher(version);
	    if (!matcher.matches()) {
	    	jsonObject.put("ERROR", "Invalid version string");
	    } else {	    	
	    	if(Objects.nonNull(deviceType) && (deviceType.equalsIgnoreCase("IOS") || deviceType.equalsIgnoreCase("ANDROID"))) {
	    		jsonObject = profileService.forceUpgradeApp(version, deviceType);					    		
	    	}else {
	    		jsonObject.put("ERROR", "Invalid device type");
	    	}
	    }
		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/profile/checkPassword", method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Validating password ",
							notes = "Validation of password", responseContainer = "Boolean")
	@ApiImplicitParams({
    @ApiImplicitParam(name = "username", value = "username", required = true, dataType = "String"),
    @ApiImplicitParam(name = "password", value = "password", required = true, dataType = "String")})
	@ApiResponses(value = {
            @ApiResponse(code = 200, message = ExceptionConstants.HR_512
                         + " or \r\n" + ExceptionConstants.HR_519
                         + " or \r\n" + ExceptionConstants.HR_716
                         + " or \r\n" + ExceptionConstants.HR_704)})
	public ResponseEntity<Object> verifyPassword(@RequestBody(required = true) String rawMessage) {
		log.debug("REST request to validate the password for the user : {}");
		JSONObject jsonObject = new JSONObject();
		try {
			int keySize = propertyResolver.getProperty("keysize", Integer.class);
			int iterationCount = propertyResolver.getProperty("iterationcount", Integer.class);
			String pass_phrase = propertyResolver.getProperty("passphrase");
	   	 	AesUtil aesUtil = new AesUtil(keySize, iterationCount);
	  	 	 String decodedMessage = null;
	  	 	 decodedMessage=DecodeToDecryptUtil.decodeRawMessegeforDecryption(rawMessage);  
	    	 String decryptedusername=null;
	    	 String decryptedPassword=null;
	    	 if (decodedMessage != null && decodedMessage.split("::").length == 4) {
	    		 decryptedusername = aesUtil.decrypt(decodedMessage.split("::")[1], decodedMessage.split("::")[0], pass_phrase, decodedMessage.split("::")[2]);
	    		 decryptedPassword = aesUtil.decrypt(decodedMessage.split("::")[1], decodedMessage.split("::")[0], pass_phrase, decodedMessage.split("::")[3]);
	    	 }
	    	 if (StringUtils.isNotBlank(decryptedusername) && StringUtils.isNotBlank(decryptedPassword)) {
	    		 jsonObject = profileService.validatePassword(decryptedusername, decryptedPassword);
	    		 if (Objects.nonNull(jsonObject)) {
	    			 String encodedString = java.util.Base64.getEncoder().encodeToString((decryptedusername + ":" + (jsonObject.containsKey("status") ? jsonObject.get("status") : false)).getBytes());
	    			 jsonObject.put("status", encodedString);
	    			 return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	    		 } else {
	    			 jsonObject.put("message", ExceptionConstants.HR_512);
	    			 return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	    		 }
	    	 } else {
	    		 jsonObject.put("message", ExceptionConstants.HR_916);
	    		 return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	    	 }
		} catch (Exception e) {
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.FORBIDDEN);
		}
	}
	
	@RequestMapping(value = "/profile/therapyReminder/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiResponses(value = { @ApiResponse(code = 200, message = ExceptionConstants.HR_915) })
	public ResponseEntity<Object> getTherapyReminderList(@PathVariable String pid) {
		log.debug("REST request to getTherapyReminders : {}" + pid);
		JSONObject jsonObject = new JSONObject();
		jsonObject = profileService.getTherapyReminderList(pid);
		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	}

	@RequestMapping(value = "/profile/therapyReminder/update", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Update therapy reminder", notes = "Update therapy reminder")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "patientId", required = true, dataType = "String"),
			@ApiImplicitParam(name = "reminders", value = "reminders", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = ExceptionConstants.HR_915) })
	public ResponseEntity<Object> updateTherapyReminderList(@RequestBody TherapyReminderDTO therapyReminder) {
		log.debug("REST request to updateTherapyReminderList : {}" + therapyReminder.toString());
		JSONObject jsonObject = new JSONObject();
		if (therapyReminder.getPid() != null && therapyReminder.getReminders() != null) {
			try {
				jsonObject = profileService.updateTherapyReminderList(therapyReminder);
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			} catch (Exception e) {
				jsonObject.put("message", e.getMessage());
				return new ResponseEntity<>(jsonObject, HttpStatus.FORBIDDEN);
			}
		} else {
			jsonObject.put("message", ExceptionConstants.HR_916);
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

    @RequestMapping(value = "/profile/byod/{userId}", method = RequestMethod.POST, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "Update BYOD status")
	@ApiImplicitParams({@ApiImplicitParam(name = "userId", value = "user Id", required = true, dataType = "String")}) 
	@ApiResponses(value = {@ApiResponse(code = 200, message = ExceptionConstants.HR_512)})
	public ResponseEntity<?> updateBYODSettings(
			@RequestHeader(value="x-auth-token",required=true)String authToken,
			@PathVariable Long userId,
			@RequestBody BYODUpdateDTO dto
			) {
		log.debug("Update BYOD : {}");
		try {
			JSONObject message = profileService.updateBYOD(userId, dto);
			return new ResponseEntity<>(message, HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			log.error("getAllPatientDetails : " + e.getMessage());
			return new ResponseEntity<>("Failed", HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public void setEnvironment(Environment environment) {
		this.propertyResolver = new RelaxedPropertyResolver(environment, Constants.ENV_SPRING_AUTHENTICATE);	
	}

}
