package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.PatientActivityHistory;

@Repository
public interface PatientActivityHistoryRepository extends JpaRepository<PatientActivityHistory, Long> {
	 @Query(nativeQuery=true, value=" SELECT * from PATIENT_ACTIVITY_HISTORY pah where pah.patient_id = ?1 and pah.patient_activity_assoc_id = ?2 order by id DESC LIMIT 1") 
	 PatientActivityHistory findTop1ByPatientIdAndPatientActivityAssocId(String patientId ,Long patientActivityAsssoctionId);

	 @Query(nativeQuery=true, value=" SELECT * from PATIENT_ACTIVITY_HISTORY pah where pah.patient_id = ?1 and pah.activity_type_id = ?2 order by id DESC LIMIT 1") 
	 PatientActivityHistory findTop1ByPatientIdAndActivityTypeID(String patientId ,Long patientActivityTypeId);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.patientActivityAssociationId = ?2")
	 List<PatientActivityHistory> findByPatientIdAndPatientActivityAssocId(String patientId ,Long patientActivityAsssoctionId);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.patientActivityAssociationId = ?2 and (pah.recordedDateTime between ?3 and ?4)")
	 List<PatientActivityHistory> findByPatientIdAndPatientActivityAssocIdWithinRange(String patientId ,Long patientActivityAsssoctionId, Long from, Long to);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.patientActivityAssociationId = ?2 and pah.recordedDateTime >= ?3")
	 List<PatientActivityHistory> findByPatientIdAndPatientActivityAssocIdSince(String patientId ,Long patientActivityAsssoctionId, Long from);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.patientActivityAssociationId = ?2 and pah.recordedDateTime <= ?3")
	 List<PatientActivityHistory> findByPatientIdAndPatientActivityAssocIdTill(String patientId ,Long patientActivityAsssoctionId, Long to);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.activityTypeId = ?2")
	 List<PatientActivityHistory> findByPatientIdAndActivityTypeId(String patientId ,Long activityTypeId);
	 
	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.activityTypeId = ?2 and (pah.recordedDateTime between ?3 and ?4)")
	 List<PatientActivityHistory> findByPatientIdAndActivityTypeIdWithinRange(String patientId ,Long activityTypeId, Long from, Long to);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.activityTypeId = ?2 and pah.recordedDateTime >= ?3")
	 List<PatientActivityHistory> findByPatientIdAndActivityTypeIdSince(String patientId ,Long activityTypeId, Long from);

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.activityTypeId = ?2 and pah.recordedDateTime <= ?3")
	 List<PatientActivityHistory> findByPatientIdAndActivityTypeIdTill(String patientId ,Long activityTypeId, Long to);

	 @Query(nativeQuery=true,value=" SELECT count(*) from PATIENT_ACTIVITY_HISTORY pah where pah.patient_id = ?1 and pah.activity_type_id = ?2")
	 int findCountByPatientIdAndActivityTypeId(String patientId ,Long activityTypeId);
	 

	 @Query("from PatientActivityHistory pah where pah.patientId = ?1 and pah.activityTypeId = ?2 order by recordedDateTime")
	 List<PatientActivityHistory> findByIntialValue(String patientId ,Long activityTypeId);

	 @Query(nativeQuery=true, value=" SELECT * from PATIENT_ACTIVITY_HISTORY pah where pah.patient_id = ?1 and pah.activity_type_id = ?2 order by id DESC LIMIT 1")
	 PatientActivityHistory findRecentWeight(String patientId ,Long activityTypeId);
}
