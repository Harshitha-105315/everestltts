package com.hillrom.mobile.service;
import java.io.IOException;
import java.lang.reflect.Type;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hillrom.mobile.dto.NotificationData;
import com.hillrom.mobile.dto.NotificationDataDTO;
import com.hillrom.mobile.dto.NotificationRequestModel;

@Service
public class AndroidPushService {

	private final Logger logger = LoggerFactory.getLogger(AndroidPushService.class);
	
	@Inject
	private Environment env;
			
    public String SendNotification(String deviceToken, NotificationDataDTO data) {

      try
      {
    	  logger.debug("Inside Android SendNotification:" + deviceToken);
          CloseableHttpClient httpClient = HttpClientBuilder.create().build();
          String pushNotificationUrl = env.getProperty("spring.mobileapp.android.pushNotificationUrl");
          if (StringUtils.isBlank(pushNotificationUrl)) {
        	  pushNotificationUrl = "https://fcm.googleapis.com/fcm/send";
          }
          
          String serverKey = env.getProperty("spring.mobileapp.android.serverKey");
          if (StringUtils.isBlank(pushNotificationUrl)) {
        	  return "Server key is null";
          }
          HttpPost postRequest = new HttpPost(pushNotificationUrl);
          NotificationRequestModel notificationRequestModel = new NotificationRequestModel();
          notificationRequestModel.setmTo(deviceToken);
          notificationRequestModel.setData(data);
          
          NotificationData notificationData = new NotificationData();  //to be changed to notification
          notificationData.setTitle(data.getMessage().getTitle());
          notificationData.setDetail(data.getMessage().getDescription());
          notificationRequestModel.setNotification(notificationData);
                 
          Gson gson = new Gson();
          Type type = new TypeToken<NotificationRequestModel>() {
          }.getType();

          String json = gson.toJson(notificationRequestModel, type);
          StringEntity input = new StringEntity(json);
          input.setContentType("application/json");
          postRequest.addHeader("Authorization", "key=" + serverKey);
          postRequest.setEntity(input);

          logger.debug("request:" + json);
          HttpResponse response = httpClient.execute(postRequest);
          if (response.getStatusLine().getStatusCode() != 200) {
              //throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
        	  logger.debug("response:" + EntityUtils.toString(response.getEntity()));
        	  return "Fail";
          } else if (response.getStatusLine().getStatusCode() == 200) {
              logger.debug("response:" + EntityUtils.toString(response.getEntity()));
              return "Success";
          }

        } catch (Exception e) {
            // handle
          logger.debug("Entered Builder Excption" + e.getMessage());
        }
      return "Fail";
    }
}
