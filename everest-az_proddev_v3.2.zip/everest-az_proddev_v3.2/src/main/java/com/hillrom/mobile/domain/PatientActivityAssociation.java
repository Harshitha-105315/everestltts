package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PATIENT_ACTIVITY_ASSOCIATION")
public class PatientActivityAssociation {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name = "patient_id")
	private String patientId;
	
	@Column(name = "activity_type_id")
	private Long activityTypeId;
	
	@Column(name = "activity_name")
	private String activityName;
	
	@Column(name = "AWARD_ASSOC_ID")
    //@OneToMany(targetEntity = PatientAwardHistory.class,fetch = FetchType.LAZY)
    //@JoinColumn(name = "ID", nullable =false)
    private Long awardAssocId;

	@Column(name = "initial_value")
	private String intialValue;
	
	@Column(name = "target_value")
	private String targetValue;
	
	@Column(name = "target_date")
	private Long targetDate;
	
	@Column(name = "created_date")
	private Long createdDate;
	
	@Column(name = "extended_info")
	private String extendedInfo;
	
	@Column(name = "is_active")
	private Boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Long getActivityTypeId() {
		return activityTypeId;
	}

	public void setActivityTypeId(Long activityTypeId) {
		this.activityTypeId = activityTypeId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Long getAwardAssocId() {
		return awardAssocId;
	}

	public void setAwardAssocId(Long awardAssocId) {
		this.awardAssocId = awardAssocId;
	}

	public String getIntialValue() {
		return intialValue;
	}

	public void setIntialValue(String intialValue) {
		this.intialValue = intialValue;
	}

	public String getTargetValue() {
		return targetValue;
	}

	public void setTargetValue(String targetValue) {
		this.targetValue = targetValue;
	}

	public Long getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Long targetDate) {
		this.targetDate = targetDate;
	}

	public Long getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}

	public String getExtendedInfo() {
		return extendedInfo;
	}

	public void setExtendedInfo(String extendedInfo) {
		this.extendedInfo = extendedInfo;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
}
