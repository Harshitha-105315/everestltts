package com.hillrom.mobile.dto;

public class NotificationReadStatusDTO {
	private Long notificationId;
	private Boolean isRead;
	
	// TODO if they provide read date should have add filed
	
	public Long getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}
	public Boolean getIsRead() {
		return isRead;
	}
	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}
	public NotificationReadStatusDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "NotificationReadStatusDTO [notificationId=" + notificationId + ", isRead=" + isRead + "]";
	}
	
}
