package com.hillrom.mobile.dto;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "MedicationVO", description = "Medication VO")
public class MedicationVO {
	
		@ApiModelProperty(value = "medicationId", required = true)
		private Long medicationId;
		
		@ApiModelProperty(value = "medicationRecordingId", required = true)
		@JsonIgnore
		private Long medicationRecordingId;
		
		@ApiModelProperty(value = "medicationType", required = true)
		private String medicationType;
		
		@ApiModelProperty(value = "medicationName", required = true)
		private String medicationName;
		
		@ApiModelProperty(value = "medicationNote", required = true)
		private String medicationNote;
		
		@ApiModelProperty(value = "medicationReminderFlag", required = true)
		private boolean medicationReminderFlag;
		
		@ApiModelProperty(value = "medicationReminder", required = true)
		private List<MedicationRemindersVO> medicationReminder; 
		
		@ApiModelProperty(value = "medicationPrescriptionNo", required = true)
		private String medicationPrescriptionNo;
		
		@ApiModelProperty(value = "medicationPharmacyName", required = true)
		private String medicationPharmacyName;
		
		@ApiModelProperty(value = "medicationPharmacyAddress", required = true)
		private String medicationPharmacyAddress;
		
		@ApiModelProperty(value = "medicationPharmacyPhoneNumber", required = true)
		private String medicationPharmacyPhoneNumber;
		
		@ApiModelProperty(value = "medicationPharmacyLocationCoordinates", required = true)
		private String medicationPharmacyLocationCoordinates;
		
		@ApiModelProperty(value = "medicationRefillReminderFlag", required = true)
		private boolean medicationRefillReminderFlag;
		
		@ApiModelProperty(value = "medicationRefillReminderDate", required = true)
		private String medicationRefillReminderDate;
		
		@ApiModelProperty(value = "medicationIsArchiveFlag", required = true)
		private boolean medicationIsArchiveFlag;
		
		@ApiModelProperty(value = "photo", required = true , dataType="byte[]")
		private byte[] photo;
		
		@ApiModelProperty(value = "photo_available", required = true )
		private boolean photo_available;
				
		public String getMedicationType() {
			return medicationType;
		}
		public void setMedicationType(String medicationType) {
			this.medicationType = medicationType;
		}
		public String getMedicationName() {
			return medicationName;
		}
		public void setMedicationName(String medicationName) {
			this.medicationName = medicationName;
		}
		public String getMedicationNote() {
			return medicationNote;
		}
		public void setMedicationNote(String medicationNote) {
			this.medicationNote = medicationNote;
		}
		public boolean isMedicationReminderFlag() {
			return medicationReminderFlag;
		}
		public void setMedicationReminderFlag(boolean medicationReminderFlag) {
			this.medicationReminderFlag = medicationReminderFlag;
		}
		public List<MedicationRemindersVO> getMedicationReminder() {
			return medicationReminder;
		}
		public void setMedicationReminder(List<MedicationRemindersVO> medicationReminder) {
			this.medicationReminder = medicationReminder;
		}
		public String getMedicationPrescriptionNo() {
			return medicationPrescriptionNo;
		}
		public void setMedicationPrescriptionNo(String medicationPrescriptionNo) {
			this.medicationPrescriptionNo = medicationPrescriptionNo;
		}
		public String getMedicationPharmacyName() {
			return medicationPharmacyName;
		}
		public void setMedicationPharmacyName(String medicationPharmacyName) {
			this.medicationPharmacyName = medicationPharmacyName;
		}
		public String getMedicationPharmacyAddress() {
			return medicationPharmacyAddress;
		}
		public void setMedicationPharmacyAddress(String medicationPharmacyAddress) {
			this.medicationPharmacyAddress = medicationPharmacyAddress;
		}
		public String getMedicationPharmacyPhoneNumber() {
			return medicationPharmacyPhoneNumber;
		}
		public void setMedicationPharmacyPhoneNumber(String medicationPharmacyPhoneNumber) {
			this.medicationPharmacyPhoneNumber = medicationPharmacyPhoneNumber;
		}
		public String getMedicationPharmacyLocationCoordinates() {
			return medicationPharmacyLocationCoordinates;
		}
		public void setMedicationPharmacyLocationCoordinates(String medicationPharmacyLocationCoordinates) {
			this.medicationPharmacyLocationCoordinates = medicationPharmacyLocationCoordinates;
		}
		public boolean isMedicationRefillReminderFlag() {
			return medicationRefillReminderFlag;
		}
		public void setMedicationRefillReminderFlag(boolean medicationRefillReminderFlag) {
			this.medicationRefillReminderFlag = medicationRefillReminderFlag;
		}
		
		public MedicationVO() {
			super();
		}
		
		public boolean isPhoto_available() {
			return photo_available;
		}
		public void setPhoto_available(boolean photo_available) {
			this.photo_available = photo_available;
		}
		public byte[] getPhoto() {
			return photo;
		}
		public void setPhoto(byte[] photo) {
			this.photo = photo;
		}
		
		public boolean isMedicationIsArchiveFlag() {
			return medicationIsArchiveFlag;
		}
		public void setMedicationIsArchiveFlag(boolean medicationIsArchiveFlag) {
			this.medicationIsArchiveFlag = medicationIsArchiveFlag;
		}
		public Long getMedicationId() {
			return medicationId;
		}
		public void setMedicationId(Long medicationId) {
			this.medicationId = medicationId;
		}
		public Long getMedicationRecordingId() {
			return medicationRecordingId;
		}
		public void setMedicationRecordingId(Long medicationRecordingId) {
			this.medicationRecordingId = medicationRecordingId;
		}
		public String getMedicationRefillReminderDate() {
			return medicationRefillReminderDate;
		}
		public void setMedicationRefillReminderDate(String medicationRefillReminderDate) {
			this.medicationRefillReminderDate = medicationRefillReminderDate;
		}
		
		public MedicationVO(Long medicationId, Long medicationRecordingId, String medicationType, String medicationName,
				String medicationNote, boolean medicationReminderFlag, List<MedicationRemindersVO> medicationReminder,
				String medicationPrescriptionNo, String medicationPharmacyName, String medicationPharmacyAddress,
				String medicationPharmacyPhoneNumber, String medicationPharmacyLocationCoordinates,
				boolean medicationRefillReminderFlag, String medicationRefillReminderDate,
				boolean medicationIsArchiveFlag, byte[] photo) {
			super();
			this.medicationId = medicationId;
			this.medicationRecordingId = medicationRecordingId;
			this.medicationType = medicationType;
			this.medicationName = medicationName;
			this.medicationNote = medicationNote;
			this.medicationReminderFlag = medicationReminderFlag;
			this.medicationReminder = medicationReminder;
			this.medicationPrescriptionNo = medicationPrescriptionNo;
			this.medicationPharmacyName = medicationPharmacyName;
			this.medicationPharmacyAddress = medicationPharmacyAddress;
			this.medicationPharmacyPhoneNumber = medicationPharmacyPhoneNumber;
			this.medicationPharmacyLocationCoordinates = medicationPharmacyLocationCoordinates;
			this.medicationRefillReminderFlag = medicationRefillReminderFlag;
			this.medicationRefillReminderDate = medicationRefillReminderDate;
			this.medicationIsArchiveFlag = medicationIsArchiveFlag;
			this.photo = photo;			
		}
		public MedicationVO(Long medicationId, String medicationType, String medicationName, String medicationNote,
				boolean medicationReminderFlag, List<MedicationRemindersVO> medicationReminder,
				String medicationPrescriptionNo, String medicationPharmacyName, String medicationPharmacyAddress,
				String medicationPharmacyPhoneNumber, String medicationPharmacyLocationCoordinates,
				boolean medicationRefillReminderFlag, String medicationRefillReminderDate,
				boolean medicationIsArchiveFlag, byte[] photo) {
			this.medicationId = medicationId;
			this.medicationType = medicationType;
			this.medicationName = medicationName;
			this.medicationNote = medicationNote;
			this.medicationReminderFlag = medicationReminderFlag;
			this.medicationReminder = medicationReminder;
			this.medicationPrescriptionNo = medicationPrescriptionNo;
			this.medicationPharmacyName = medicationPharmacyName;
			this.medicationPharmacyAddress = medicationPharmacyAddress;
			this.medicationPharmacyPhoneNumber = medicationPharmacyPhoneNumber;
			this.medicationPharmacyLocationCoordinates = medicationPharmacyLocationCoordinates;
			this.medicationRefillReminderFlag = medicationRefillReminderFlag;
			this.medicationRefillReminderDate = medicationRefillReminderDate;
			this.medicationIsArchiveFlag = medicationIsArchiveFlag;
			this.photo = photo;
		}		
}
