package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.hillrom.mobile.domain.UserPushNotification;

@Repository
public interface UserPushNotificationRepository extends JpaRepository<UserPushNotification, Long>{
	
	@Query(nativeQuery=true,value=" SELECT * from USER_PUSH_NOTIFICATIONS upn where upn.patient_id = ?1 ORDER BY upn.id DESC LIMIT 100")
	List<UserPushNotification> findByPatientId(String patientId);
	
	@Query(nativeQuery=true,value=" SELECT * from USER_PUSH_NOTIFICATIONS upn where upn.patient_id = ?1 AND upn.mobile_info_id = ?2 ORDER BY upn.id DESC LIMIT 100")
	List<UserPushNotification> findByPatientIdAndMobileInfoId(String patientId,Long deviceId);
	
	@Query(nativeQuery=true,value=" SELECT COUNT(*) from USER_PUSH_NOTIFICATIONS upn where upn.patient_id = ?1 and upn.is_read='0'")
	Long findUnreadNotificationCountByPatientId(String patientId);

}
