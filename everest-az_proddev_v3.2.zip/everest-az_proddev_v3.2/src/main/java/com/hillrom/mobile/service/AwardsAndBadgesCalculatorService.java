package com.hillrom.mobile.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hillrom.mobile.domain.AwardMaster;
import com.hillrom.mobile.domain.BadgesMaster;
import com.hillrom.mobile.domain.MobileDeviceInfo;
import com.hillrom.mobile.domain.PatientActivityAssociation;
import com.hillrom.mobile.domain.PatientActivityHistory;
import com.hillrom.mobile.domain.PatientAwardHistory;
import com.hillrom.mobile.domain.PatientBadgesHistory;
import com.hillrom.mobile.dto.ExtendedInfoDTO;
import com.hillrom.mobile.repository.AwardMasterRepository;
import com.hillrom.mobile.repository.BadgesMasterRepository;
import com.hillrom.mobile.repository.MobileDeviceInfoRepository;
import com.hillrom.mobile.repository.PatientActivityAssociationRepository;
import com.hillrom.mobile.repository.PatientActivityHistoryRepository;
import com.hillrom.mobile.repository.PatientAwardHistoryRepository;
import com.hillrom.mobile.repository.PatientBadgesHistoryRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.HillromTypeCodeFormat;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.HillromTypeCodeFormatRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientTestResultRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.MobileUtil;

@Service
@Transactional
public class AwardsAndBadgesCalculatorService {
	
	private final Logger logger = LoggerFactory.getLogger(AwardsAndBadgesCalculatorService.class);
	
	@Inject
	private PatientActivityAssociationRepository patientActivityAssociationRepository;
	
	@Inject
	private PatientActivityHistoryRepository patientActivityHistoryRepository;
	
	@Inject 
	private HillromTypeCodeFormatRepository hillromTypeCodeFormatRepository;
	
	@Inject
	private PatientBadgesHistoryRepository patientBadgesHistoryRepository;
	
	@Inject
	private PatientAwardHistoryRepository patientAwardHistoryRepository;
	
	@Inject 
	private AwardMasterRepository awardMasterRepository;
	
	@Inject
	private BadgesMasterRepository badgesMasterRepository;
	
	@Inject 
	private MobileDeviceInfoRepository mobileDeviceInfoRepository;
	
	@Inject 
	private PatientTestResultRepository patientTestResultRepository;
	
	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;
	
	@Inject 
	private TherapySessionRepository therapySessionRepository;
	
	@Inject 
	private TherapySessionMonarchRepository therapySessionMonarchRepository;
	
	@Inject 
	private TherapySessionTitanRepository therapySessionTitanRepository;
	
	@Inject
	private PushNotificationService pushNotificationService;
	
	public Map<String, List<Long>> awardsAndBadgesAssociatedToPatient(String patientId,Long activityTypeId) throws HillromException {
		//List<Long> awardList = new ArrayList<Long>();
		//Long award = null;
    	List<Long> badges = null;
    	Map<String,List<Long>> awardAndBadges = new HashMap<String,List<Long>>();
    	HillromTypeCodeFormat hillromTypeCodeValues =  hillromTypeCodeFormatRepository.findOne(activityTypeId);
    	switch(hillromTypeCodeValues.getType_code()) {
    	case "ExerciseLog" : badges = exerciseLogMetrics(patientId,hillromTypeCodeValues.getId());
    				break;
    	case "WeightLog" :badges =  weightLogMetrics(patientId,hillromTypeCodeValues.getId());
    				break;
    	case "NutritionLog" : badges = nutritionLogMetrics(patientId,hillromTypeCodeValues.getId());
    				break;		
    	default:
    				break;

    	}
    	//awardList.add(award);
    	//awardAndBadges.put("awards", awardList);
		awardAndBadges.put("badges", badges);
		
		// Award Combo Badge
		awardComboBadge(awardAndBadges, patientId);
		
    	return awardAndBadges;   
	}
	
	public void awardComboBadge(Map<String,List<Long>> awardAndBadges, String patientId) {
		
		if (Objects.nonNull(awardAndBadges)) {
			if (Objects.nonNull(awardAndBadges.get("badges")) && awardAndBadges.get("badges").size() > 0) {
				Long badgeId = awardAndBadges.get("badges").get(0);
				List<Long> badgeIds = new ArrayList<>();
				badgeIds.add(badgesMasterRepository.findOneByCategoryTypeForFirstLog("Log", "Exercise").getId()); // exercise
				badgeIds.add(badgesMasterRepository.findOneByCategoryTypeForFirstLog("Log", "Weight").getId()); // Weight
				badgeIds.add(badgesMasterRepository.findOneByCategoryTypeForFirstLog("Log", "Nutrition").getId()); // Nutrition
				
				if (badgeIds.contains(badgeId)) {
					List<PatientBadgesHistory> pbhList = patientBadgesHistoryRepository.findOneByPatientIdBadgeMasterId(patientId, badgeIds);
					if (Objects.nonNull(pbhList) && pbhList.size() == 3 ) { // User awarded all 3 different types of badges
						BadgesMaster bm = badgesMasterRepository.findOne(24L); // Power User
						awardAndBadges.get("badges").add(bm.getId());

						// save combo badge in ptient badge history
						PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
						patientBadgesHistory.setPatientId(patientId);
						patientBadgesHistory.setBadgesMasterId(24L);
						patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
						patientBadgesHistoryRepository.save(patientBadgesHistory);
 					}
				}
				
			}

		
		}
		
	}
	

	public Long exerciseGoalMetrics(String patientId,Long activityTypeId) throws HillromException {
		Long awardId = 0L;
		List<PatientActivityAssociation> patientActivityAssoc = patientActivityAssociationRepository.
				findActiveActivityByPatientIdandActivityTypeId(patientId,activityTypeId);
		if(patientActivityAssoc.size() ==1){
			Long targetDate = patientActivityAssoc.get(0).getTargetDate();
			Long intialDate = patientActivityAssoc.get(0).getCreatedDate();
			if((LocalDate.now(DateTimeZone.UTC)).isAfter(new LocalDate(targetDate))) {
				String extendedInfo = patientActivityAssoc.get(0).getExtendedInfo();
				ExtendedInfoDTO ExtendedInfo = null;
				if(!StringUtils.isEmpty(extendedInfo)) {
					ObjectMapper objmap = new ObjectMapper();
					TypeReference<ExtendedInfoDTO> mapType = new TypeReference<ExtendedInfoDTO>() {};
					try {
						ExtendedInfo = objmap.readValue(extendedInfo, mapType);
					} catch (Exception e) {
						e.printStackTrace();
					} 
				} else {
					return 0L;
				}
				
				List<String> days = new ArrayList<String>();
				days.addAll(ExtendedInfo.getExerciseDays());
				String duration = ExtendedInfo.getExerciseDuration();
				int countOfDays = 0;
				countOfDays = MobileUtil.getNumberOfDays(new LocalDate(intialDate),new LocalDate(targetDate),days);
				double targetValue = 0;
				targetValue =  new Double((countOfDays*Integer.parseInt(duration)));
				List<PatientActivityHistory> patientActivityHistoryLogs=patientActivityHistoryRepository.
						findByPatientIdAndPatientActivityAssocId(patientId, patientActivityAssoc.get(0).getId());
				double sumOfAllDurations = 0;
				int exerciseDeviation =0;

				if(!patientActivityHistoryLogs.isEmpty()) {
					for(PatientActivityHistory  patientActivityHistoryLog:patientActivityHistoryLogs) {
						sumOfAllDurations =   new Double(sumOfAllDurations+Integer.parseInt(patientActivityHistoryLog.getCurrentValue()));
					}

					if(sumOfAllDurations <= targetValue) {
						exerciseDeviation = (int) Math.round((sumOfAllDurations*100)/targetValue); //calculating percentage
					} else {
						exerciseDeviation = Constants.Goal_Completed;
					}
				}

				PatientAwardHistory patientAwardHistory = new PatientAwardHistory();

				awardId = assignAwardToDeviation(exerciseDeviation,activityTypeId);
				if(awardId != null) {
					patientAwardHistory.setAwardMasterId(awardId);
					patientAwardHistory.setPatientId(patientId);
					patientAwardHistory.setReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
					patientAwardHistoryRepository.save(patientAwardHistory);
					patientActivityAssoc.get(0).setAwardAssocId(patientAwardHistory.getId());
					patientActivityAssoc.get(0).setIsActive(false);
					patientActivityAssociationRepository.save(patientActivityAssoc);
					awardId= patientAwardHistory.getId();
				}else {
		              patientActivityAssoc.get(0).setAwardAssocId(null);
		              patientActivityAssoc.get(0).setIsActive(false);
		              patientActivityAssociationRepository.save(patientActivityAssoc);
	            }
			} else {
				return 0L;
			}
		}
		else {
			return 0L;// we have to write mail service code 
		}
		return awardId;
	}

    public Long weightGoalMetrics(String patientId,Long activityTypeId) throws HillromException {
    	Long awardId = 0L;
    	List<PatientActivityAssociation> patientActivityAssoc = patientActivityAssociationRepository.
    			findActiveActivityByPatientIdandActivityTypeId(patientId,activityTypeId);
    	if(patientActivityAssoc.size() == 1) {
    		Long targetDate = patientActivityAssoc.get(0).getTargetDate();
			if((LocalDate.now(DateTimeZone.UTC)).isAfter(new LocalDate(targetDate))) {
	    		double targetValue = Double.parseDouble(patientActivityAssoc.get(0).getTargetValue());
	    		double intialValue =  Double.parseDouble(patientActivityAssoc.get(0).getIntialValue());

				PatientAwardHistory patientAwardHistory = new PatientAwardHistory();

	    		PatientActivityHistory patientActivityLatestLog=patientActivityHistoryRepository.
	    				findTop1ByPatientIdAndPatientActivityAssocId(patientId, patientActivityAssoc.get(0).getId());
    			int weightDeviation =0;
    			double currentWeightValue = intialValue;

	    		if(Objects.nonNull(patientActivityLatestLog)) {
	    			currentWeightValue = Double.parseDouble(patientActivityLatestLog.getCurrentValue());
    		
		    		// Check if user wants to gain weight
					if(targetValue > intialValue) {
						// Check if user weight is greater than target weight
						if(currentWeightValue > targetValue) {
							weightDeviation = 100;
						} else {
							// Check if user weight is below initial weight, in this case the user achieved 0 percent
							if(currentWeightValue < intialValue) {
								weightDeviation = 0;
							}else {
								// Else the user gained weight
								// Percentage = gained weight/planned gain weight
								weightDeviation = (int)(((currentWeightValue-intialValue)*100)/(targetValue-intialValue));
							}
						}					
						awardId = assignAwardToDeviation(weightDeviation,activityTypeId);					
					// Check if user wants to reduce weight
					} else if(targetValue < intialValue) {
						// Check if user weight is less than planned weight
						if(currentWeightValue < targetValue) {
							weightDeviation = 100;
						} else {
							// check if user weight is greater than initial weight, in this case user achieved 0 percent
							if(currentWeightValue > intialValue) {
								weightDeviation = 0;
							}else {
								// Else user reduced weight
								// Percentage = reduced weight/planned reduced weight
								weightDeviation = (int)(((intialValue-currentWeightValue)*100)/(intialValue-targetValue));
							}						
						}
						awardId = assignAwardToDeviation(weightDeviation,activityTypeId);
					// User wants to maintain weight
					} else {
						// Check if user weight is greater than initial weight
						if(currentWeightValue > intialValue) {
							// The deviation is how much weight % user gained against the initial weight
							weightDeviation = (int)(((currentWeightValue-intialValue)*100)/intialValue);
							// If the weight gained is > 100 percent, then user achieved 0 percent
							if(weightDeviation > 100) {
								weightDeviation = 0;
							}else {
								// If gained weight is less than 100%, then the deviation is the achieved percent
								weightDeviation = 100 - weightDeviation;
							}
							// Check if user weight is less than initial weight
						}else if(currentWeightValue < intialValue) {
							// The deviation is how much weight % user reduced against the initial weight
							weightDeviation = (int)(((intialValue-currentWeightValue)*100)/intialValue);
							// If reduced weight is > 100%, then user achieved 0 percent
							if(weightDeviation > 100) {
								weightDeviation = 0;
							}else {
								// If reduced weight is less than 100%, then the deviation is the achieved percent
								weightDeviation = 100 - weightDeviation;
							}
						}else {
							//  if the user maintains in this case is 100%
							weightDeviation = 100;
						}
						
						awardId = assignAwardToDeviation(weightDeviation,activityTypeId);
					}
				}
	    		else
				{
	    			awardId = assignAwardToDeviation(weightDeviation,activityTypeId);
				}
	            if(awardId != null) {
	              patientAwardHistory.setAwardMasterId(awardId);
	              patientAwardHistory.setPatientId(patientId);
	              patientAwardHistory.setReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
	              patientAwardHistoryRepository.save(patientAwardHistory);
	              patientActivityAssoc.get(0).setAwardAssocId(patientAwardHistory.getId());
	              patientActivityAssoc.get(0).setIsActive(false);
	              patientActivityAssociationRepository.save(patientActivityAssoc);
	              awardId= patientAwardHistory.getId();
	            }else {
		              patientActivityAssoc.get(0).setAwardAssocId(null);
		              patientActivityAssoc.get(0).setIsActive(false);
		              patientActivityAssociationRepository.save(patientActivityAssoc);
	            }
			}else {
    			return 0L;
    		}
    	}else {
    		return 0L;// we have to write mail service code 
    	}
    	return awardId;
    }

    public Long nutritionGoalMetrics(String patientId,Long activityTypeId) throws HillromException {
    	Long awardId = 0L;
    	List<PatientActivityAssociation> patientActivityAssoc = patientActivityAssociationRepository.
    			findActiveActivityByPatientIdandActivityTypeId(patientId,activityTypeId);
    	if(patientActivityAssoc.size() == 1) {
    		Long targetDate = patientActivityAssoc.get(0).getTargetDate();
    		Long intialDate = patientActivityAssoc.get(0).getCreatedDate();
    		if((LocalDate.now(DateTimeZone.UTC)).isAfter(new LocalDate(targetDate))) {
				int daysBetweenDates = DateUtil.getDaysCountBetweenLocalDates(new LocalDate(intialDate),new LocalDate(targetDate))+1;
					
				double targetValue = new Double((Integer.parseInt(patientActivityAssoc.get(0).getTargetValue())) * daysBetweenDates);
				
				double toatalTargetValue = 0;
				List<PatientActivityHistory> patientActivityHistoryLogs=patientActivityHistoryRepository.
						findByPatientIdAndPatientActivityAssocId(patientId, patientActivityAssoc.get(0).getId());

    			if(!patientActivityHistoryLogs.isEmpty()) {
    				for(PatientActivityHistory  patientActivityHistoryLog:patientActivityHistoryLogs) {
    					toatalTargetValue =   new Double(toatalTargetValue+Integer.parseInt(patientActivityHistoryLog.getCurrentValue()));
    				}
    			}
				int nutritionDeviation = 0;
				PatientAwardHistory patientAwardHistory = new PatientAwardHistory();
				if(toatalTargetValue <= targetValue) {
				nutritionDeviation = (int) Math.round((toatalTargetValue*100)/targetValue); //calculating percentage
				} else {
					nutritionDeviation = Constants.Goal_Completed;
				}

				awardId = assignAwardToDeviation(nutritionDeviation,activityTypeId);
				if(awardId != null) {
    				patientAwardHistory.setAwardMasterId(awardId);
    				patientAwardHistory.setPatientId(patientId);
    				patientAwardHistory.setReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
    				patientAwardHistoryRepository.save(patientAwardHistory);
    				patientActivityAssoc.get(0).setAwardAssocId(patientAwardHistory.getId());
    				patientActivityAssoc.get(0).setIsActive(false);
    				patientActivityAssociationRepository.save(patientActivityAssoc);
    				awardId= patientAwardHistory.getId();
				}else {
		              patientActivityAssoc.get(0).setAwardAssocId(null);
		              patientActivityAssoc.get(0).setIsActive(false);
		              patientActivityAssociationRepository.save(patientActivityAssoc);
	            }
    		} else {
    			return 0L;
    		}
    	}else {
    		return 0L;// we have to write mail service code 
    	}
    	return awardId;
    }
	
	//Assigning the Award to patient based on the deviation
    private Long assignAwardToDeviation(int deviation, Long activityTypeId) {
    	Long awardId = null;
    	List<AwardMaster> awardMasterList = awardMasterRepository.findOneByActivityTypeId(activityTypeId);
    	for(AwardMaster awardMaster:awardMasterList){
    		int maxValue = Integer.parseInt(awardMaster.getAwardMetMaxValue());
    		int minValue = Integer.parseInt(awardMaster.getAwardMetMinValue());
    		if(minValue <= deviation && deviation <= maxValue ) {
    			awardId = awardMaster.getId();
    			break;
    		}
    	}
    	return awardId;
    }
    
   //Exercise Log calculation for associating the badge 
	private List<Long> exerciseLogMetrics(String patientId,Long activityTypeId) {
		Long badgeIdForLog = null;
		List<Long> badgesList = new ArrayList<Long>();
		int countOfExerciseLogs =  patientActivityHistoryRepository.findCountByPatientIdAndActivityTypeId(patientId,activityTypeId);
		badgeIdForLog = assignBadgeToDeviation(countOfExerciseLogs,activityTypeId);
		if(badgeIdForLog != null) {
			PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
			patientBadgesHistory.setPatientId(patientId);
			patientBadgesHistory.setBadgesMasterId(badgeIdForLog);
			patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
			patientBadgesHistoryRepository.save(patientBadgesHistory);
			badgesList.add(badgeIdForLog);
		} else {
			badgeIdForLog=null;
		}

		return badgesList;
	}
	
	//weight Log calculation for associating the badge 
	private List<Long> weightLogMetrics(String patientId,Long activityTypeId) {
		Long badgeId = null;
		List<Long> badgesList = new ArrayList<Long>();
		int countOfWeightLogs =  patientActivityHistoryRepository.findCountByPatientIdAndActivityTypeId(patientId,activityTypeId);
		badgeId = assignBadgeToDeviation(countOfWeightLogs,activityTypeId);
		PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
		if(badgeId != null) {
			patientBadgesHistory.setPatientId(patientId);
			patientBadgesHistory.setBadgesMasterId(badgeId);
			patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
			patientBadgesHistoryRepository.save(patientBadgesHistory);
			badgesList.add(badgeId);
		} else {
			badgeId=null;
		}

		return badgesList;
	}
	
	//Nutrition Log calculation for associating the badge 
	private List<Long> nutritionLogMetrics(String patientId,Long activityTypeId) {
		Long badgeId = null;
		List<Long> badgesList = new ArrayList<Long>();
		int countOfNutritionLogs =  patientActivityHistoryRepository.findCountByPatientIdAndActivityTypeId(patientId,activityTypeId);

		badgeId = assignBadgeToDeviation(countOfNutritionLogs,activityTypeId);
		PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
		if(badgeId != null) {
			patientBadgesHistory.setPatientId(patientId);
			patientBadgesHistory.setBadgesMasterId(badgeId);
			patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
			patientBadgesHistoryRepository.save(patientBadgesHistory);
			badgesList.add(badgeId);
		} else {
			badgeId=null;
		}
		return badgesList;
	}
	//Assigning the Badge to patient based on the deviation
	private Long assignBadgeToDeviation(int deviation, Long activityTypeId) {
		Long badgeId = null;
		List<BadgesMaster> badgesMasterList = badgesMasterRepository.findOneByActivityTypeId(activityTypeId);
		for(BadgesMaster badgeMaster:badgesMasterList){
			int count = Integer.parseInt(badgeMaster.getBadgeThersholdValue());
			if(count == deviation) {
				badgeId = badgeMaster.getId();
				break;
			}
		}
		return badgeId;
	}
	
	//Assigning the Badge to patient based on the Goals completion
	public Long assignBadgeToCompletedGoals(String patientId) {
		Long badgeId = null;
		int completedGoals = 0;
		List<PatientAwardHistory> awardHistory = patientAwardHistoryRepository.findByPatientId(patientId);
		if (Objects.nonNull(awardHistory)) {
			completedGoals = awardHistory.size();
		}
		List<BadgesMaster> badgesMasterList = badgesMasterRepository.findOneByActivityTypeId(Constants.Goal_Total_Id);
		for(BadgesMaster badgeMaster:badgesMasterList){
			int count = Integer.parseInt(badgeMaster.getBadgeThersholdValue());
			if(count == completedGoals) {
				badgeId = badgeMaster.getId();
				if(badgeId !=null) {
					PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
					patientBadgesHistory.setPatientId(patientId);
					patientBadgesHistory.setBadgesMasterId(badgeId);
					patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
					patientBadgesHistoryRepository.save(patientBadgesHistory);
					pushNotificationService.pushNotificationForBadges(patientId, badgeMaster.getId(), badgeMaster.getCategory(), badgeMaster.getType(), badgeMaster.getCompletedDescription(), badgeMaster.getBadgeName());
				}
				break;
			}
		}
		return badgeId;
	}
	
	public void spiroLogMetrics(String patientId) {
		
		Long badgeId = null;
		MobileDeviceInfo mobileDeviceInfo = mobileDeviceInfoRepository.findOneByPatientIdAndMobileRegistrationDate(patientId);
		if(Objects.nonNull(mobileDeviceInfo)) {
			LocalDate mobileRegistrtionDate = new LocalDate(mobileDeviceInfo.getMobile_registration_datetime());
		Integer countOfSpiroLogs =  patientTestResultRepository.
				findCountByPatientIdAndMobileRegistrationDate(patientId,mobileRegistrtionDate.toString());
		
		List<HillromTypeCodeFormat> typeCodeLogList = hillromTypeCodeFormatRepository
				.findCodeValuesListByTypeCode("SpiroLog");
		if (typeCodeLogList.get(0) != null) {
			logger.debug(" SpiroLog typecode:" + typeCodeLogList.get(0).getId());
		}
		
		badgeId = assignBadgeToDeviation(countOfSpiroLogs.intValue(),typeCodeLogList.get(0).getId());
		PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
		
		if(badgeId != null) {
			patientBadgesHistory.setPatientId(patientId);
			patientBadgesHistory.setBadgesMasterId(badgeId);
			patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
			patientBadgesHistoryRepository.save(patientBadgesHistory);
			
			// Push notification for SpiroLog
			BadgesMaster badgeMaster = badgesMasterRepository.getOne(badgeId);
			pushNotificationService.pushNotificationForBadges(patientId, badgeMaster.getId(), badgeMaster.getCategory(), badgeMaster.getType(), badgeMaster.getCompletedDescription(), badgeMaster.getBadgeName());

		}
		else {
			badgeId =  null;	
		}
		}else {
			badgeId =  null;
		}
		
	}
	
   public void vestLogMetrics(String patientId) {
		
	   Long badgeId = null;
		int countOfTherapySesssions = 0;
		MobileDeviceInfo mobileDeviceInfo = mobileDeviceInfoRepository.findOneByPatientIdAndMobileRegistrationDate(patientId);
		if(Objects.nonNull(mobileDeviceInfo)) {
			LocalDate mobileRegistrtionDate = new LocalDate(mobileDeviceInfo.getMobile_registration_datetime());
		List<PatientDevicesAssoc> activeVestDevices = patientDevicesAssocRepository.findByPatientId(patientId);
		if(activeVestDevices.size() > 1) {
			for(int i = 0; i< activeVestDevices.size(); i++)
			{
				if(activeVestDevices.get(i).getDeviceType().equalsIgnoreCase(Constants.VEST)) {
					if(Objects.nonNull(activeVestDevices.get(i).getIsManual()) && activeVestDevices.get(i).getIsManual().booleanValue() == true)
					{
						countOfTherapySesssions +=  therapySessionRepository.
								findCountByPatientIdAndMobileRegistrtionDate(patientId, "1970-01-01");
					}else {
						countOfTherapySesssions +=  therapySessionRepository.
								findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
					}
				}
				else if(activeVestDevices.get(i).getDeviceType().equalsIgnoreCase(Constants.MONARCH)) {
					countOfTherapySesssions += therapySessionMonarchRepository.
					findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
				}
				else {
					countOfTherapySesssions += therapySessionTitanRepository.
							findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
				}
			}
		} else if(activeVestDevices.get(0).getDeviceType().equalsIgnoreCase(Constants.VEST)) {
			
			countOfTherapySesssions = therapySessionRepository.
						findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
			// Consider monarch therapy sessions 
			countOfTherapySesssions += therapySessionMonarchRepository.
					findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());

		} else if(activeVestDevices.get(0).getDeviceType().equalsIgnoreCase(Constants.MONARCH)){
			countOfTherapySesssions =  therapySessionMonarchRepository.
						findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
			// Consider vest therapy sessions
			countOfTherapySesssions +=  therapySessionRepository.
					findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
		}else {
			countOfTherapySesssions =  therapySessionTitanRepository.
					findCountByPatientIdAndMobileRegistrtionDate(patientId, mobileRegistrtionDate.toString());
		}
		
		List<HillromTypeCodeFormat> typeCodeLogList = hillromTypeCodeFormatRepository
				.findCodeValuesListByTypeCode("VestLog");
		if (typeCodeLogList.get(0) != null) {
			logger.debug(" VestLog typecode:" + typeCodeLogList.get(0).getId());
		}
		
		badgeId = assignBadgeToDeviation(countOfTherapySesssions,typeCodeLogList.get(0).getId());
		PatientBadgesHistory patientBadgesHistory = new PatientBadgesHistory();
		
		if(badgeId != null) {
			patientBadgesHistory.setPatientId(patientId);
			patientBadgesHistory.setBadgesMasterId(badgeId);
			patientBadgesHistory.setBadgeReceivedDate(DateTime.now(DateTimeZone.UTC).getMillis());
			patientBadgesHistoryRepository.save(patientBadgesHistory);
			
			// Push notification for VestLog
			BadgesMaster badgeMaster = badgesMasterRepository.getOne(badgeId);
			pushNotificationService.pushNotificationForBadges(patientId, badgeMaster.getId(), badgeMaster.getCategory(), badgeMaster.getType(), badgeMaster.getCompletedDescription(), badgeMaster.getBadgeName());

		} else {
			badgeId=null;
		}
		} else {
			badgeId=null;
		}
		
	}
}
