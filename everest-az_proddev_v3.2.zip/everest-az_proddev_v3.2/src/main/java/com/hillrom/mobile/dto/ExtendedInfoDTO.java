package com.hillrom.mobile.dto;

import java.util.List;

public class ExtendedInfoDTO {

	private List<String> exerciseDays;
	private String exerciseDuration;
	
	public List<String> getExerciseDays() {
		return exerciseDays;
	}
	public void setExerciseDays(List<String> exerciseDays) {
		this.exerciseDays = exerciseDays;
	}
	public String getExerciseDuration() {
		return exerciseDuration;
	}
	public void setExerciseDuration(String exerciseDuration) {
		this.exerciseDuration = exerciseDuration;
	}
	
	
}
