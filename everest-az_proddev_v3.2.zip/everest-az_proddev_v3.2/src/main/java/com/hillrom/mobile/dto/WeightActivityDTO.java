package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
		"pid",
        "activityId",
        "targetWeight",
        "currentWeight",
        "goalStartDate",
        "goalEndDate",
        "name"
})
@ApiModel(value = "WeightActivityDTO", description = "WeightActivity Log Info")
public class WeightActivityDTO {

	@JsonProperty("pid")
	@ApiModelProperty(value = "Patient", required = true)
	private String pid;
	
    @JsonProperty("activityId")
    @ApiModelProperty(value = "ActivityId", required = true)
    private Long activityId;
    
    @JsonProperty("targetWeight")
    @ApiModelProperty(value = "TargetWeight", required = true)
    private Long targetWeight;
    
    @JsonProperty("currentWeight")
    @ApiModelProperty(value = "CurrentWeight", required = true)
    private Long currentWeight;
    
    @JsonProperty("goalStartDate")
    @ApiModelProperty(value = "GoalStartDate", required = false)
    private Long goalStartDate;
    
    @JsonProperty("goalEndDate")
    @ApiModelProperty(value = "GoalEndDate", required = true)
    private Long goalEndDate;
    
    @JsonProperty("name")
    @ApiModelProperty(value = "Goal name", required = true)
    private String name;
    
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Long getTargetWeight() {
		return targetWeight;
	}
	public void setTargetWeight(Long targetWeight) {
		this.targetWeight = targetWeight;
	}
	public Long getCurrentWeight() {
		return currentWeight;
	}
	public void setCurrentWeight(Long currentWeight) {
		this.currentWeight = currentWeight;
	}
	public Long getGoalEndDate() {
		return goalEndDate;
	}
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}
	public Long getGoalStartDate() {
		return goalStartDate;
	}
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

    
    

}