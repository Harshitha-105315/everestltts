package com.hillrom.mobile.service;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hillrom.mobile.domain.AwardMaster;
import com.hillrom.mobile.domain.BadgesMaster;
import com.hillrom.mobile.domain.ImageMaster;
import com.hillrom.mobile.domain.MobileEmoji;
import com.hillrom.mobile.domain.PatientActivityAssociation;
import com.hillrom.mobile.domain.PatientActivityHistory;
import com.hillrom.mobile.domain.PatientAwardHistory;
import com.hillrom.mobile.domain.PatientBadgesHistory;
import com.hillrom.mobile.dto.AwardMasterVO;
import com.hillrom.mobile.dto.AwardsHistoryVO;
import com.hillrom.mobile.dto.BadgesHistoryListVO;
import com.hillrom.mobile.dto.BadgesLockedVO;
import com.hillrom.mobile.dto.BadgesUnlockedVO;
import com.hillrom.mobile.dto.CurrentActivityExerciseVO;
import com.hillrom.mobile.dto.CurrentActivityNutritionVO;
import com.hillrom.mobile.dto.CurrentActivityWeightVO;
import com.hillrom.mobile.dto.CurrentGoalVO;
import com.hillrom.mobile.dto.ExerciseActivityDTO;
import com.hillrom.mobile.dto.ExtendedInfoDTO;
import com.hillrom.mobile.dto.ImagesVO;
import com.hillrom.mobile.dto.LogActivityDTO;
import com.hillrom.mobile.dto.NutritionActivityDTO;
import com.hillrom.mobile.dto.PatientActivityHistoryVO;
import com.hillrom.mobile.dto.PatientCurrentActivitiesDTO;
import com.hillrom.mobile.dto.PatientExerciseGoals;
import com.hillrom.mobile.dto.PatientExerciseGoalsWithDateRange;
import com.hillrom.mobile.dto.PatientNutritionGoals;
import com.hillrom.mobile.dto.PatientNutritionGoalsWithDateRange;
import com.hillrom.mobile.dto.PatientWeightGoals;
import com.hillrom.mobile.dto.PatientWeightGoalsWithDateRange;
import com.hillrom.mobile.dto.WeightActivityDTO;
import com.hillrom.mobile.repository.AwardMasterRepository;
import com.hillrom.mobile.repository.BadgesMasterRepository;
import com.hillrom.mobile.repository.ImageMasterRepository;
import com.hillrom.mobile.repository.MobileEmojiRepository;
import com.hillrom.mobile.repository.PatientActivityAssociationRepository;
import com.hillrom.mobile.repository.PatientActivityHistoryRepository;
import com.hillrom.mobile.repository.PatientAwardHistoryRepository;
import com.hillrom.mobile.repository.PatientBadgesHistoryRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.HillromTypeCodeFormat;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.repository.HillromTypeCodeFormatRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.MobileUtil;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;

@Service
@Transactional
public class ActivityService {
	private final Logger log = LoggerFactory.getLogger(ActivityService.class);

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject
	private PatientActivityAssociationRepository patientActivityAssociationRepository;

	@Inject
	private PatientActivityHistoryRepository patientActivityHistoryRepository;

	@Inject
	private HillromTypeCodeFormatRepository hillromTypeCodeFormatRepository;

	@Inject
	private PatientBadgesHistoryRepository patientBadgesHistoryRepository;

	@Inject
	private PatientAwardHistoryRepository patientAwardHistoryRepository;

	@Inject
	private AwardMasterRepository awardMasterRepository;

	@Inject
	private BadgesMasterRepository badgesMasterRepository;

	@Inject
	private MobileEmojiRepository mobileEmojiRepository;

	@Inject
	private AwardsAndBadgesCalculatorService awardsAndBadgesCalculatorService;

	@Inject
	private PushNotificationService pushNotificationService;

	@Inject
	private EntityManager entityManager;
	
	@Inject
	private ImageMasterRepository imageMasterRepository;
	
	public List<AwardsHistoryVO> getAllPatientAwardsDetails(String patientId) throws URIException {
		List<AwardsHistoryVO> awardsHistoryList = new ArrayList<>();
		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		if (Objects.nonNull(patientInfo)) {
			List<PatientActivityAssociation> associationList = patientActivityAssociationRepository
					.findByPatientId(patientId);
			if (!associationList.isEmpty()) {
				for (PatientActivityAssociation assoc : associationList) {
					if (Objects.nonNull(assoc.getAwardAssocId())) {
						PatientAwardHistory patientAwardHistoryVO = patientAwardHistoryRepository
								.findOne(assoc.getAwardAssocId());
						if (Objects.nonNull(patientAwardHistoryVO.getAwardMasterId())) {
							AwardMaster awardMasterVO = awardMasterRepository
									.findOne(patientAwardHistoryVO.getAwardMasterId());
							if (Objects.nonNull(awardMasterVO)) {
								AwardsHistoryVO awardHistoryVO = new AwardsHistoryVO();
								awardHistoryVO.setActivityId(assoc.getId());
								awardHistoryVO.setActivityName(assoc.getActivityName());
								awardHistoryVO.setIsAchieved(true); // all achieved awards
								awardHistoryVO.setAchievedDate(patientAwardHistoryVO.getReceivedDate());
								awardHistoryVO.setAwardId(awardMasterVO.getId());
								awardHistoryVO.setAwardName(awardMasterVO.getAwardName());
								awardHistoryVO.setHeader("Trophy Unlocked");
								awardHistoryVO.setTitle(awardMasterVO.getAwardName()); 
								awardHistoryVO.setMessage(awardMasterVO.getAwardDescription());
								awardHistoryVO.setImage(awardMasterVO.getImage_achieved());
								awardHistoryVO.setThumbNail(awardMasterVO.getThumbnail_achieved());
								awardHistoryVO.setActivityType(hillromTypeCodeFormatRepository.getOne(awardMasterVO.getActivityTypeId()).getType_code_value());
								awardsHistoryList.add(awardHistoryVO);
							}
						}
					}
				}
			} else {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_917);
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915);
		}
		if (awardsHistoryList.isEmpty()) {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_917);
		}
		return awardsHistoryList;
	}

	public BadgesHistoryListVO getAllPatientBadgesDetails(String patientId) throws URIException {
		BadgesHistoryListVO badgesHistoryList = new BadgesHistoryListVO();

		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		if (Objects.nonNull(patientInfo)) {
			List<BadgesMaster> lockedBadgeMasterList = new ArrayList<BadgesMaster>();
			List<BadgesUnlockedVO> badgesUnlockedList = new ArrayList<BadgesUnlockedVO>();
			List<BadgesLockedVO> badgesLockedList = new ArrayList<BadgesLockedVO>();
			List<BadgesMaster> badgeMasterList = badgesMasterRepository.findAll();
			List<PatientBadgesHistory> unLockedBadgesHistoryList = patientBadgesHistoryRepository.findByPatientId(patientId);
			if (!unLockedBadgesHistoryList.isEmpty()) {
				for (PatientBadgesHistory unLockedBadgesHistory : unLockedBadgesHistoryList) {
					BadgesUnlockedVO badgesUnlocked = new BadgesUnlockedVO();
					badgesUnlocked.setBadgeId(unLockedBadgesHistory.getBadgesMasterId());
					badgesUnlocked.setCompletedDate(unLockedBadgesHistory.getBadgeReceivedDate());
					BadgesMaster badgeAssociated = badgesMasterRepository.findOne(unLockedBadgesHistory.getBadgesMasterId());
					badgesUnlocked.setBadgeName(badgeAssociated.getBadgeName());
					// Code changes for category an type
					badgesUnlocked.setCategory(badgeAssociated.getCategory());
					badgesUnlocked.setType(badgeAssociated.getType());
					badgesUnlocked.setDescription(badgeAssociated.getCompletedDescription());
					badgesUnlocked.setHeader("Badge Unlocked");
					badgesUnlocked.setImage(badgeAssociated.getImage());
					badgesUnlocked.setThumbNail(badgeAssociated.getThumbnail());
					BadgesMaster lockedBadgeMaster = new BadgesMaster();
					lockedBadgeMaster = badgesMasterRepository.findOne(unLockedBadgesHistory.getBadgesMasterId());

					badgeMasterList.remove(lockedBadgeMaster);
					badgesUnlockedList.add(badgesUnlocked);
				}
				lockedBadgeMasterList.addAll(badgeMasterList);
			} else {
				lockedBadgeMasterList.addAll(badgeMasterList);
				badgesUnlockedList.add(null);
			}
			badgesHistoryList.setBadgesUnlockedList(badgesUnlockedList);
			if (!lockedBadgeMasterList.isEmpty()) {
				for (BadgesMaster lockedBadgeMaster : lockedBadgeMasterList) {
					BadgesLockedVO badgesLocked = new BadgesLockedVO();
					int currentCount = patientActivityHistoryRepository.findCountByPatientIdAndActivityTypeId(patientId,
							lockedBadgeMaster.getActivityTypeId());
					badgesLocked.setBadgeId(lockedBadgeMaster.getId());
					badgesLocked.setBadgeName(lockedBadgeMaster.getBadgeName());
					badgesLocked.setCurrentCount(currentCount);
					badgesLocked.setCategory(lockedBadgeMaster.getCategory());
					badgesLocked.setType(lockedBadgeMaster.getType());
					badgesLocked.setTotalCount(Integer.parseInt(lockedBadgeMaster.getBadgeThersholdValue()));
					if(lockedBadgeMaster.getProgressDescription().contains("#dd#")) {
						badgesLocked.setDescription(lockedBadgeMaster.getProgressDescription().replace("#dd#", Integer.toString(currentCount)));
					}else {
						badgesLocked.setDescription(lockedBadgeMaster.getBadgeDescription());
					}
					badgesLocked.setHeader("Badge Locked");
					badgesLocked.setImage(lockedBadgeMaster.getImage());
					badgesLocked.setThumbNail(lockedBadgeMaster.getThumbnail());
					badgesLockedList.add(badgesLocked);
				}
			} else {
				badgesLockedList.add(null);
			}
			badgesHistoryList.setBadgesLockedList(badgesLockedList);
			if (Objects.isNull(badgesHistoryList)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_918);
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915);
		}
		return badgesHistoryList;
	}

	public PatientNutritionGoals getAllPatientNutritionGoals(String pid, Long activityId, Long from, Long to)
			throws URIException {
		PatientNutritionGoals patientNutritionGoals = new PatientNutritionGoals();
		Long sum = 0L;
		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<PatientActivityHistory> patientActivityHistoryList = null;
			PatientActivityAssociation patientActivityAssociation = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdWithinRange(pid, activityId, from, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdWithinRange(pid,
						activityId, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdSince(pid, activityId, from);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdSince(pid,
						activityId, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdTill(pid, activityId, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdTill(pid,
						activityId, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocId(pid, activityId);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndId(pid, activityId);
			}

			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("NutritionGoal");

			Long activityTypeCode = typeCodeList.get(0).getId();

			if (Objects.isNull(patientActivityAssociation)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_919);
			} else if (!patientActivityAssociation.getActivityTypeId().equals(activityTypeCode)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_920);
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();
					sum = sum + Long.parseLong(listItem.getCurrentValue());
					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));

					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientNutritionGoals.setPatientActivityHistoryVO(patientActivityHistoryListVO);
			}

			patientNutritionGoals.setActivityId(patientActivityAssociation.getId());
			patientNutritionGoals.setActivityName(patientActivityAssociation.getActivityName());
			if (Objects.nonNull(patientActivityAssociation.getAwardAssocId())) {
				PatientAwardHistory awardHistory = patientAwardHistoryRepository
						.findOne(patientActivityAssociation.getAwardAssocId());
				if (Objects.nonNull(awardHistory)) {
					patientNutritionGoals.setAwardId(awardHistory.getAwardMasterId());
					patientNutritionGoals.setIsGoalAchieved(true);
					patientNutritionGoals.setAchievedDate(awardHistory.getReceivedDate());
				}
			}
			patientNutritionGoals.setInitial(Long.parseLong(patientActivityAssociation.getIntialValue()));
			int daysBetweenDates = DateUtil.getDaysCountBetweenLocalDates(
					new LocalDate(patientActivityAssociation.getCreatedDate()), LocalDate.now(DateTimeZone.UTC));
			if (daysBetweenDates == 0) {
				patientNutritionGoals.setCurrent(sum);
			} else {
				sum = sum / daysBetweenDates;
				patientNutritionGoals.setCurrent(sum);
			}
			patientNutritionGoals.setTarget(Long.parseLong(patientActivityAssociation.getTargetValue()));
			patientNutritionGoals.setGoalStartDate(patientActivityAssociation.getCreatedDate());
			patientNutritionGoals.setGoalEndDate(patientActivityAssociation.getTargetDate());
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}
		return patientNutritionGoals;
	}

	public PatientExerciseGoals getAllPatientExerciseGoals(String pid, Long activityId, Long from, Long to)
			throws URIException {
		PatientExerciseGoals patientExerciseGoals = new PatientExerciseGoals();
		Long sum = 0L;
		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<PatientActivityHistory> patientActivityHistoryList = null;
			PatientActivityAssociation patientActivityAssociation = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdWithinRange(pid, activityId, from, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdWithinRange(pid,
						activityId, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdSince(pid, activityId, from);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdSince(pid,
						activityId, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdTill(pid, activityId, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdTill(pid,
						activityId, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocId(pid, activityId);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndId(pid, activityId);
			}

			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("ExerciseGoal");

			Long activityTypeCode = typeCodeList.get(0).getId();

			if (Objects.isNull(patientActivityAssociation)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_919);
			} else if (!patientActivityAssociation.getActivityTypeId().equals(activityTypeCode)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_931);
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();
					sum = sum + Long.parseLong(listItem.getCurrentValue());
					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));
					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientExerciseGoals.setPatientActivityHistoryVO(patientActivityHistoryListVO);
			}

			patientExerciseGoals.setActivityId(patientActivityAssociation.getId());
			patientExerciseGoals.setActivityName(patientActivityAssociation.getActivityName());
			if (Objects.nonNull(patientActivityAssociation.getAwardAssocId())) {
				PatientAwardHistory awardHistory = patientAwardHistoryRepository
						.findOne(patientActivityAssociation.getAwardAssocId());
				if (Objects.nonNull(awardHistory)) {
					patientExerciseGoals.setAwardId(awardHistory.getAwardMasterId());
					patientExerciseGoals.setIsGoalAchieved(true);
					patientExerciseGoals.setAchievedDate(awardHistory.getReceivedDate());
				} else {
					patientExerciseGoals.setIsGoalAchieved(false);
				}
			}
			patientExerciseGoals.setCurrent(sum);
			patientExerciseGoals.setInitial(Long.parseLong(patientActivityAssociation.getIntialValue()));
			String extendedInfo = patientActivityAssociation.getExtendedInfo();
			Long targetValue = 0L;
			if (!extendedInfo.isEmpty()) {
				try {
					ExtendedInfoDTO extendedInfoDTO = new ObjectMapper().readValue(extendedInfo, ExtendedInfoDTO.class);
					patientExerciseGoals.setExtendedInfo(extendedInfoDTO);
					targetValue = Long.parseLong(patientActivityAssociation.getTargetValue())
							* MobileUtil.getNumberOfDays(new LocalDate(patientActivityAssociation.getCreatedDate()),
									new LocalDate(patientActivityAssociation.getTargetDate()),
									extendedInfoDTO.getExerciseDays());
					patientExerciseGoals.setTarget(targetValue);
				} catch (IOException e) {
					patientExerciseGoals.setTarget(targetValue);
				}
			} else {
				patientExerciseGoals.setTarget(targetValue);
			}
			patientExerciseGoals.setGoalStartDate(patientActivityAssociation.getCreatedDate());
			patientExerciseGoals.setGoalEndDate(patientActivityAssociation.getTargetDate());
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}
		return patientExerciseGoals;
	}

	public PatientWeightGoals getAllPatientWeightGoals(String pid, Long activityId, Long from, Long to)
			throws URIException {
		PatientWeightGoals patientWeightGoals = new PatientWeightGoals();
		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<PatientActivityHistory> patientActivityHistoryList = null;
			PatientActivityAssociation patientActivityAssociation = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdWithinRange(pid, activityId, from, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdWithinRange(pid,
						activityId, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdSince(pid, activityId, from);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdSince(pid,
						activityId, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocIdTill(pid, activityId, to);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndIdTill(pid,
						activityId, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndPatientActivityAssocId(pid, activityId);
				patientActivityAssociation = patientActivityAssociationRepository.findByPatientIdAndId(pid, activityId);
			}

			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("WeightGoal");

			Long activityTypeCode = typeCodeList.get(0).getId();

			if (Objects.isNull(patientActivityAssociation)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_919);
			} else if (!patientActivityAssociation.getActivityTypeId().equals(activityTypeCode)) {
				throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_933);
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();
					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));

					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientWeightGoals.setPatientActivityHistoryVO(patientActivityHistoryListVO);
			}

			patientWeightGoals.setActivityId(patientActivityAssociation.getId());
			patientWeightGoals.setActivityName(patientActivityAssociation.getActivityName());
			if (Objects.nonNull(patientActivityAssociation.getAwardAssocId())) {
				PatientAwardHistory awardHistory = patientAwardHistoryRepository
						.findOne(patientActivityAssociation.getAwardAssocId());
				if (Objects.nonNull(awardHistory)) {
					patientWeightGoals.setAwardId(awardHistory.getAwardMasterId());
					patientWeightGoals.setIsGoalAchieved(true);
					patientWeightGoals.setAchievedDate(awardHistory.getReceivedDate());
				} else {
					patientWeightGoals.setIsGoalAchieved(false);
				}
			}

			PatientActivityHistory currentActivityHistory = patientActivityHistoryRepository
					.findTop1ByPatientIdAndPatientActivityAssocId(pid, patientActivityAssociation.getId());
			
			if (Objects.nonNull(currentActivityHistory)) {
				patientWeightGoals.setCurrent(Long.parseLong(currentActivityHistory.getCurrentValue()));
			} else {
				patientWeightGoals.setCurrent(Long.parseLong(patientActivityAssociation.getIntialValue()));
			}

			patientWeightGoals.setInitial(Long.parseLong(patientActivityAssociation.getIntialValue()));
			patientWeightGoals.setTarget(Long.parseLong(patientActivityAssociation.getTargetValue()));
			patientWeightGoals.setGoalStartDate(patientActivityAssociation.getCreatedDate());
			patientWeightGoals.setGoalEndDate(patientActivityAssociation.getTargetDate());
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}
		return patientWeightGoals;
	}

	public PatientNutritionGoalsWithDateRange getAllPatientNutritionGoalsWithDateRange(String pid, Long from, Long to)
			throws URIException {
		PatientNutritionGoalsWithDateRange patientNutritionGoalsWithDateRange = new PatientNutritionGoalsWithDateRange();
		Long sum = 0L;
		CurrentGoalVO currentGoalVO = null;

		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("NutritionGoal");

			List<HillromTypeCodeFormat> typeCodeLogList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("NutritionLog");

			Long activityTypeCode = typeCodeList.get(0).getId();
			Long activityTypeCodeLog = typeCodeLogList.get(0).getId();

			List<PatientActivityHistory> patientActivityHistoryList = null;
			List<PatientActivityAssociation> patientActivityAssociationList = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCodeLog, from, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCode, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdSince(pid,
						activityTypeCodeLog, from);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdSince(pid, activityTypeCode, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdTill(pid,
						activityTypeCodeLog, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdTill(pid, activityTypeCode, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeId(pid,
						activityTypeCodeLog);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdandActivityTypeId(pid, activityTypeCode);
			}

			if (!patientActivityAssociationList.isEmpty()) {
				List<AwardsHistoryVO> awardsHistoryListVO = null;
				for (PatientActivityAssociation listItem : patientActivityAssociationList) {
					if (listItem.getIsActive()) {
						currentGoalVO = new CurrentGoalVO();
						currentGoalVO.setActivityID(listItem.getId());
						currentGoalVO.setActivityName(listItem.getActivityName());
						currentGoalVO.setInitial(Long.parseLong(listItem.getIntialValue()));
						currentGoalVO.setTarget(Long.parseLong(listItem.getTargetValue()));
						currentGoalVO.setGoalStartDate(listItem.getCreatedDate());
						currentGoalVO.setGoalEndDate(listItem.getTargetDate());
					} else {
						AwardsHistoryVO awardsHistoryVO = new AwardsHistoryVO();
						awardsHistoryVO.setActivityId(listItem.getId());
						awardsHistoryVO.setActivityName(listItem.getActivityName());
						if (Objects.nonNull(listItem.getAwardAssocId())) {
							PatientAwardHistory awardHistory = patientAwardHistoryRepository
									.findOne(listItem.getAwardAssocId());
							if (Objects.nonNull(awardHistory)) {
								awardsHistoryVO.setAwardId(awardHistory.getAwardMasterId());
								AwardMaster award = awardMasterRepository.getOne(awardHistory.getAwardMasterId());
								awardsHistoryVO.setAwardName(award.getAwardName());
								awardsHistoryVO.setIsAchieved(true);
								awardsHistoryVO.setAchievedDate(awardHistory.getReceivedDate());
							} else {
								awardsHistoryVO.setIsAchieved(false);
								awardsHistoryVO.setAwardId(null);
								awardsHistoryVO.setAchievedDate(null);
							}
						} else {
							awardsHistoryVO.setIsAchieved(false);
							awardsHistoryVO.setAwardId(null);
							awardsHistoryVO.setAchievedDate(null);
						}

						if (!Objects.nonNull(awardsHistoryListVO)) {
							awardsHistoryListVO = new ArrayList<>();
						}

						awardsHistoryListVO.add(awardsHistoryVO);
					}
				}

				if (Objects.nonNull(currentGoalVO)) {
					patientNutritionGoalsWithDateRange.setCurrentActivity(true);
					currentGoalVO.setCurrent(sum);
					patientNutritionGoalsWithDateRange.setCurrentGoalVO(currentGoalVO);
				}
				if (!Objects.isNull(awardsHistoryListVO) && awardsHistoryListVO.size() > 0) {
					patientNutritionGoalsWithDateRange.setAwardsHistoryListVO(awardsHistoryListVO);
				}
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();
					if (Objects.nonNull(currentGoalVO) && Objects.nonNull(listItem.getPatientActivityAssociationId())
							&& listItem.getPatientActivityAssociationId().equals(currentGoalVO.getActivityID())) {
						sum = sum + Long.parseLong(listItem.getCurrentValue());
					}

					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));

					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientNutritionGoalsWithDateRange.setPatientActivityHistoryListVO(patientActivityHistoryListVO);
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}

		return patientNutritionGoalsWithDateRange;
	}

	public PatientExerciseGoalsWithDateRange getAllPatientExerciseGoalsWithDateRange(String pid, Long from, Long to)
			throws URIException {
		PatientExerciseGoalsWithDateRange patientExerciseGoalsWithDateRange = new PatientExerciseGoalsWithDateRange();
		Long sum = 0L;
		CurrentGoalVO currentGoalVO = null;

		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("ExerciseGoal");

			List<HillromTypeCodeFormat> typeCodeLogList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("ExerciseLog");

			Long activityTypeCode = typeCodeList.get(0).getId();
			Long activityTypeCodeLog = typeCodeLogList.get(0).getId();

			List<PatientActivityHistory> patientActivityHistoryList = null;
			List<PatientActivityAssociation> patientActivityAssociationList = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCodeLog, from, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCode, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdSince(pid,
						activityTypeCodeLog, from);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdSince(pid, activityTypeCode, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdTill(pid,
						activityTypeCodeLog, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdTill(pid, activityTypeCode, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeId(pid,
						activityTypeCodeLog);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdandActivityTypeId(pid, activityTypeCode);
			}

			if (!patientActivityAssociationList.isEmpty()) {
				List<AwardsHistoryVO> awardsHistoryListVO = null;
				for (PatientActivityAssociation listItem : patientActivityAssociationList) {
					if (listItem.getIsActive()) {
						currentGoalVO = new CurrentGoalVO();
						currentGoalVO.setActivityID(listItem.getId());
						currentGoalVO.setActivityName(listItem.getActivityName());
						currentGoalVO.setInitial(Long.parseLong(listItem.getIntialValue()));
						currentGoalVO.setTarget(Long.parseLong(listItem.getTargetValue()));
						currentGoalVO.setGoalStartDate(listItem.getCreatedDate());
						currentGoalVO.setGoalEndDate(listItem.getTargetDate());
						ExtendedInfoDTO extendedInfoDTO = null;
						if (!listItem.getExtendedInfo().isEmpty()) {
							try {
								extendedInfoDTO = new ObjectMapper().readValue(listItem.getExtendedInfo(),
										ExtendedInfoDTO.class);
							} catch (IOException e) {
							}
							currentGoalVO.setExtendedInfo(extendedInfoDTO);
						}
					} else {
						AwardsHistoryVO awardsHistoryVO = new AwardsHistoryVO();
						awardsHistoryVO.setActivityId(listItem.getId());
						awardsHistoryVO.setActivityName(listItem.getActivityName());
						if (Objects.nonNull(listItem.getAwardAssocId())) {
							PatientAwardHistory awardHistory = patientAwardHistoryRepository
									.findOne(listItem.getAwardAssocId());
							if (Objects.nonNull(awardHistory)) {
								awardsHistoryVO.setAwardId(awardHistory.getAwardMasterId());
								AwardMaster award = awardMasterRepository.getOne(awardHistory.getAwardMasterId());
								awardsHistoryVO.setAwardName(award.getAwardName());
								awardsHistoryVO.setIsAchieved(true);
								awardsHistoryVO.setAchievedDate(awardHistory.getReceivedDate());
							} else {
								awardsHistoryVO.setIsAchieved(false);
								awardsHistoryVO.setAwardId(null);
								awardsHistoryVO.setAchievedDate(null);
							}
						} else {
							awardsHistoryVO.setIsAchieved(false);
							awardsHistoryVO.setAwardId(null);
							awardsHistoryVO.setAchievedDate(null);
						}

						if (!Objects.nonNull(awardsHistoryListVO)) {
							awardsHistoryListVO = new ArrayList<>();
						}

						awardsHistoryListVO.add(awardsHistoryVO);
					}
				}

				if (Objects.nonNull(currentGoalVO)) {
					currentGoalVO.setCurrent(sum);
					patientExerciseGoalsWithDateRange.setCurrentGoalVO(currentGoalVO);
					patientExerciseGoalsWithDateRange.setCurrentActivity(true);
				}

				if (!Objects.isNull(awardsHistoryListVO) && awardsHistoryListVO.size() > 0) {
					patientExerciseGoalsWithDateRange.setAwardsHistoryListVO(awardsHistoryListVO);
				}
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();
					if (Objects.nonNull(currentGoalVO) && Objects.nonNull(listItem.getPatientActivityAssociationId())
							&& listItem.getPatientActivityAssociationId().equals(currentGoalVO.getActivityID())) {
						sum = sum + Long.parseLong(listItem.getCurrentValue());
					}

					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));

					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientExerciseGoalsWithDateRange.setPatientActivityHistoryListVO(patientActivityHistoryListVO);
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}

		return patientExerciseGoalsWithDateRange;
	}

	public PatientWeightGoalsWithDateRange getAllPatientWeightGoalsWithDateRange(String pid, Long from, Long to)
			throws URIException {
		PatientWeightGoalsWithDateRange patientWeightGoalsWithDateRange = new PatientWeightGoalsWithDateRange();
		Boolean currentActivity = false;
		PatientInfo patientInfo = patientInfoRepository.findOneById(pid);
		if (Objects.nonNull(patientInfo)) {
			List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("WeightGoal");

			List<HillromTypeCodeFormat> typeCodeLogList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("WeightLog");

			Long activityTypeCode = typeCodeList.get(0).getId();
			Long activityTypeCodeLog = typeCodeLogList.get(0).getId();

			List<PatientActivityHistory> patientActivityHistoryList = null;
			List<PatientActivityAssociation> patientActivityAssociationList = null;

			if (Objects.nonNull(from) && Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCodeLog, from, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdWithinRange(pid, activityTypeCode, from, to);
			} else if (Objects.nonNull(from)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdSince(pid,
						activityTypeCodeLog, from);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdSince(pid, activityTypeCode, from);
			} else if (Objects.nonNull(to)) {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeIdTill(pid,
						activityTypeCodeLog, to);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdAndActivityTypeIdTill(pid, activityTypeCode, to);
			} else {
				patientActivityHistoryList = patientActivityHistoryRepository.findByPatientIdAndActivityTypeId(pid,
						activityTypeCodeLog);
				patientActivityAssociationList = patientActivityAssociationRepository
						.findByPatientIdandActivityTypeId(pid, activityTypeCode);
			}

			if (!patientActivityHistoryList.isEmpty()) {
				List<PatientActivityHistoryVO> patientActivityHistoryListVO = new ArrayList<>();
				for (PatientActivityHistory listItem : patientActivityHistoryList) {
					PatientActivityHistoryVO patientActivityHistoryVO = new PatientActivityHistoryVO();

					patientActivityHistoryVO.setDate(listItem.getRecordedDateTime());
					patientActivityHistoryVO.setValue(Long.parseLong(listItem.getCurrentValue()));

					patientActivityHistoryListVO.add(patientActivityHistoryVO);
				}
				patientWeightGoalsWithDateRange.setPatientActivityHistoryListVO(patientActivityHistoryListVO);
			}

			if (!patientActivityAssociationList.isEmpty()) {
				List<AwardsHistoryVO> awardsHistoryListVO = null;
				for (PatientActivityAssociation listItem : patientActivityAssociationList) {
					if (listItem.getIsActive()) {
						currentActivity = true;
						CurrentGoalVO currentGoalVO = new CurrentGoalVO();
						currentGoalVO.setActivityID(listItem.getId());
						currentGoalVO.setActivityName(listItem.getActivityName());
						PatientActivityHistory currentActivityHistory = patientActivityHistoryRepository
								.findTop1ByPatientIdAndPatientActivityAssocId(pid, listItem.getId());
						currentGoalVO.setInitial(Long.parseLong(listItem.getIntialValue()));
						currentGoalVO.setTarget(Long.parseLong(listItem.getTargetValue()));
						currentGoalVO.setGoalStartDate(listItem.getCreatedDate());
						currentGoalVO.setGoalEndDate(listItem.getTargetDate());
						if (Objects.nonNull(currentActivityHistory)) {
							currentGoalVO.setCurrent(Long.parseLong(currentActivityHistory.getCurrentValue()));
						} else {
							currentGoalVO.setCurrent(Long.parseLong(listItem.getIntialValue()));
						}
						patientWeightGoalsWithDateRange.setCurrentGoalVO(currentGoalVO);
					} else {
						AwardsHistoryVO awardsHistoryVO = new AwardsHistoryVO();
						awardsHistoryVO.setActivityId(listItem.getId());
						awardsHistoryVO.setActivityName(listItem.getActivityName());
						if (Objects.nonNull(listItem.getAwardAssocId())) {
							PatientAwardHistory awardHistory = patientAwardHistoryRepository
									.findOne(listItem.getAwardAssocId());
							if (Objects.nonNull(awardHistory)) {
								awardsHistoryVO.setAwardId(awardHistory.getAwardMasterId());
								AwardMaster award = awardMasterRepository.getOne(awardHistory.getAwardMasterId());
								awardsHistoryVO.setAwardName(award.getAwardName());
								awardsHistoryVO.setIsAchieved(true);
								awardsHistoryVO.setAchievedDate(awardHistory.getReceivedDate());
							} else {
								awardsHistoryVO.setIsAchieved(false);
								awardsHistoryVO.setAwardId(null);
								awardsHistoryVO.setAchievedDate(null);
							}
						} else {
							awardsHistoryVO.setIsAchieved(false);
							awardsHistoryVO.setAwardId(null);
							awardsHistoryVO.setAchievedDate(null);
						}

						if (!Objects.nonNull(awardsHistoryListVO)) {
							awardsHistoryListVO = new ArrayList<>();
						}

						awardsHistoryListVO.add(awardsHistoryVO);
					}
				}
				patientWeightGoalsWithDateRange.setCurrentActivity(currentActivity);
				if (!Objects.isNull(awardsHistoryListVO) && awardsHistoryListVO.size() > 0) {
					patientWeightGoalsWithDateRange.setAwardsHistoryListVO(awardsHistoryListVO);
				}
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}

		return patientWeightGoalsWithDateRange;
	}

	public PatientCurrentActivitiesDTO getAllPatientCurrentActivities(String patientId) throws URIException {
		PatientCurrentActivitiesDTO patientCurrentActivitiesDTO = new PatientCurrentActivitiesDTO();

		CurrentActivityExerciseVO patientExerciseActivity = null;
		CurrentActivityWeightVO patientWeightActivity = null;
		CurrentActivityNutritionVO patientNutritionActivity = null;

		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		if (Objects.nonNull(patientInfo)) {
			List<PatientActivityAssociation> patientActivityAssociation = patientActivityAssociationRepository
					.findActiveActivityByPatientId(patientId);

			if (!patientActivityAssociation.isEmpty()) {
				List<HillromTypeCodeFormat> weightTypeCodeList = hillromTypeCodeFormatRepository
						.findCodeValuesListByTypeCode("WeightGoal");
				List<HillromTypeCodeFormat> nutritionTypeCodeList = hillromTypeCodeFormatRepository
						.findCodeValuesListByTypeCode("NutritionGoal");
				List<HillromTypeCodeFormat> exerciseTypeCodeList = hillromTypeCodeFormatRepository
						.findCodeValuesListByTypeCode("ExerciseGoal");

				Long weightTypeCode = weightTypeCodeList.get(0).getId();
				Long exerciseTypeCode = exerciseTypeCodeList.get(0).getId();
				Long nutritionTypeCode = nutritionTypeCodeList.get(0).getId();

				for (int i = 0; i < patientActivityAssociation.size(); i++) {
					Long activityTypeId = patientActivityAssociation.get(i).getActivityTypeId();
					if (activityTypeId.equals(exerciseTypeCode)) {
						patientExerciseActivity = new CurrentActivityExerciseVO();
						patientExerciseActivity.setActivityId(patientActivityAssociation.get(i).getId());
						patientExerciseActivity.setName(patientActivityAssociation.get(i).getActivityName());
						String extendedInfo = patientActivityAssociation.get(i).getExtendedInfo();
						if (!extendedInfo.isEmpty()) {
							ExtendedInfoDTO extendedInfoDTO;
							try {
								extendedInfoDTO = new ObjectMapper().readValue(extendedInfo, ExtendedInfoDTO.class);
								patientExerciseActivity.setExeciseDays(extendedInfoDTO.getExerciseDays());
								patientExerciseActivity.setDuration(extendedInfoDTO.getExerciseDuration());
							} catch (IOException e) {
								patientExerciseActivity.setExeciseDays(null);
								patientExerciseActivity.setDuration(null);
							}
						}
						patientExerciseActivity.setGoalStartDate(patientActivityAssociation.get(i).getCreatedDate());
						patientExerciseActivity.setGoalEndDate(patientActivityAssociation.get(i).getTargetDate());
						patientCurrentActivitiesDTO.setPatientExerciseActivity(patientExerciseActivity);
					} else if (activityTypeId.equals(weightTypeCode)) {
						patientWeightActivity = new CurrentActivityWeightVO();
						patientWeightActivity.setActivityId(patientActivityAssociation.get(i).getId());
						patientWeightActivity.setGoalStartDate(patientActivityAssociation.get(i).getCreatedDate());
						patientWeightActivity.setGoalEndDate(patientActivityAssociation.get(i).getTargetDate());
						patientWeightActivity.setTargetWeight(patientActivityAssociation.get(i).getTargetValue());
						patientWeightActivity.setCurrentWeight(patientActivityAssociation.get(i).getIntialValue());
						patientWeightActivity.setName(patientActivityAssociation.get(i).getActivityName());
						patientCurrentActivitiesDTO.setPatientWeightActivity(patientWeightActivity);
					} else if (activityTypeId.equals(nutritionTypeCode)) {
						patientNutritionActivity = new CurrentActivityNutritionVO();
						patientNutritionActivity.setActivityId(patientActivityAssociation.get(i).getId());
						patientNutritionActivity
								.setCaloriesTargetInTake(patientActivityAssociation.get(i).getTargetValue());
						patientNutritionActivity.setGoalStartDate(patientActivityAssociation.get(i).getCreatedDate());
						patientNutritionActivity.setGoalEndDate(patientActivityAssociation.get(i).getTargetDate());
						patientNutritionActivity.setName(patientActivityAssociation.get(i).getActivityName());
						patientCurrentActivitiesDTO.setPatientNutritionActivity(patientNutritionActivity);
					}
				}
			}
		} else {
			throw new URIException(HttpStatus.SC_OK, ExceptionConstants.HR_915); // Patient is not found
		}

		return patientCurrentActivitiesDTO;
	}

	public JSONObject addExerciseGoal(ExerciseActivityDTO exerciseActivity) {
		JSONObject message = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOneById(exerciseActivity.getPid());

		if (!Objects.isNull(patientInfo)) {
			long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("ExerciseGoal").get(0)
					.getId();

			List<PatientActivityAssociation> paaList = patientActivityAssociationRepository
					.findActiveActivityByPatientIdandActivityTypeId(exerciseActivity.getPid(), activityTypeId);
			if (paaList.isEmpty()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("exerciseDuration", exerciseActivity.getExerciseDuration());
				jsonObject.put("exerciseDays", exerciseActivity.getExerciseDays());
				PatientActivityAssociation patientActivityAssociation = new PatientActivityAssociation();

				patientActivityAssociation.setActivityTypeId(activityTypeId);
				patientActivityAssociation.setIsActive(true);
				patientActivityAssociation.setActivityName(exerciseActivity.getName());
				patientActivityAssociation.setTargetDate(exerciseActivity.getGoalEndDate());

				patientActivityAssociation.setIntialValue("0");
				patientActivityAssociation.setTargetValue(exerciseActivity.getExerciseDuration().toString());
				if (Objects.nonNull(exerciseActivity.getGoalStartDate())) {
					patientActivityAssociation.setCreatedDate(exerciseActivity.getGoalStartDate());
				} else {
					patientActivityAssociation.setCreatedDate(DateTime.now(DateTimeZone.UTC).getMillis());
				}
				patientActivityAssociation.setPatientId(exerciseActivity.getPid());
				patientActivityAssociation.setExtendedInfo(jsonObject.toString());
				patientActivityAssociationRepository.save(patientActivityAssociation);
				Long activityId = patientActivityAssociation.getId();
				message.put("activityId : ", activityId);
				// return activityId.toString();
			} else {
				message.put("message", ExceptionConstants.HR_939);

			}
		} else {
			message.put("message", ExceptionConstants.HR_915);
		}
		return message;
	}

	public JSONObject updateExerciseGoal(ExerciseActivityDTO exerciseActivityDTO) {
		JSONObject message = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOneById(exerciseActivityDTO.getPid());

		if (!Objects.isNull(patientInfo)) {
			long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("ExerciseGoal").get(0)
					.getId();

			List<PatientActivityAssociation> paaList = patientActivityAssociationRepository
					.findByPatientIdandActivityId(exerciseActivityDTO.getPid(), exerciseActivityDTO.getActivityId());
			if (!paaList.isEmpty()) {
				if (activityTypeId == paaList.get(0).getActivityTypeId()) {
					try {
						PatientActivityAssociation patActivityAssociation = patientActivityAssociationRepository
								.findOne(exerciseActivityDTO.getActivityId());

						patActivityAssociation.setPatientId(exerciseActivityDTO.getPid());
						if (exerciseActivityDTO.getGoalEndDate() != null) {
							patActivityAssociation.setTargetDate(exerciseActivityDTO.getGoalEndDate());
						}
						if (exerciseActivityDTO.getName() != null) {
							patActivityAssociation.setActivityName(exerciseActivityDTO.getName());
						}
						if (exerciseActivityDTO.getExerciseDays() != null
								|| exerciseActivityDTO.getExerciseDuration() != null) {
							JSONObject jsonObject = new JSONObject();
							jsonObject.put("exerciseDuration", exerciseActivityDTO.getExerciseDuration());
							jsonObject.put("exerciseDays", exerciseActivityDTO.getExerciseDays());
							patActivityAssociation.setTargetValue(exerciseActivityDTO.getExerciseDuration().toString());
							patActivityAssociation.setExtendedInfo(jsonObject.toString());
						}

						patientActivityAssociationRepository.save(patActivityAssociation);
					} catch (Exception e) {
						e.printStackTrace();
					}
					message.put("message", "Updated successfully");
				} else {
					message.put("message", "Failed: Activity is not associated with patient");
				}
			} else {
				message.put("message", "Failed: Activity is not associated with patient");

			}
		} else {
			message.put("message", "Failed: Patient is not found");
		}
		return message;
	}

	public String deleteActivity(ExerciseActivityDTO exerciseActivityDTO) {

		PatientInfo patientInfo = patientInfoRepository.findOneById(exerciseActivityDTO.getPid());
		if (!Objects.isNull(patientInfo)) {
			PatientActivityAssociation patientActivityId = patientActivityAssociationRepository
					.findByPatientIdAndId(exerciseActivityDTO.getPid(), exerciseActivityDTO.getActivityId());
			if (Objects.nonNull(patientActivityId)) {
				try {
					PatientActivityAssociation patActivityAssociation = patientActivityAssociationRepository
							.findOne(exerciseActivityDTO.getActivityId());

					patActivityAssociation.setPatientId(exerciseActivityDTO.getPid());
					patActivityAssociation.setIsActive(false);
					patientActivityAssociationRepository.save(patActivityAssociation);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return ExceptionConstants.HR_938;
			} else {
				return ExceptionConstants.HR_919;
			}
		} else {
			return ExceptionConstants.HR_915;
		}
	}

	public JSONObject addNutritionGoal(NutritionActivityDTO nutritionActivity) {
		JSONObject message = new JSONObject();
		PatientActivityAssociation patientActivityAssociation = new PatientActivityAssociation();
		PatientInfo patientInfo = patientInfoRepository.findOneById(nutritionActivity.getPid());

		if (!Objects.isNull(patientInfo)) {
			long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("NutritionGoal").get(0)
					.getId();

			List<PatientActivityAssociation> patientActivityAssociationList = patientActivityAssociationRepository
					.findActiveActivityByPatientIdandActivityTypeId(nutritionActivity.getPid(), activityTypeId);
			if (patientActivityAssociationList.isEmpty()) {

				patientActivityAssociation.setActivityTypeId(activityTypeId);
				patientActivityAssociation.setIsActive(true);
				patientActivityAssociation.setActivityName(nutritionActivity.getName());
				if (Objects.nonNull(nutritionActivity.getGoalStartDate())) {
					patientActivityAssociation.setCreatedDate(nutritionActivity.getGoalStartDate());
				} else {
					patientActivityAssociation.setCreatedDate(DateTime.now(DateTimeZone.UTC).getMillis());
				}
				patientActivityAssociation.setIntialValue("0");
				patientActivityAssociation.setTargetValue(nutritionActivity.getCaloriesTargetIntake() + "");

				patientActivityAssociation.setTargetDate(nutritionActivity.getGoalEndDate());
				patientActivityAssociation.setPatientId(nutritionActivity.getPid());

				patientActivityAssociationRepository.save(patientActivityAssociation);
				message.put("activityId", patientActivityAssociation.getId());
			} else {
				message.put("message", "Nutrition Goal is alerady set for the Patient Id");

			}
		} else {
			message.put("message", "Failed: Patient is not found");
		}
		return message;
	}

	public JSONObject updateNutritionGoal(NutritionActivityDTO nutritionActivity) {
		JSONObject message = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOneById(nutritionActivity.getPid());

		if (!Objects.isNull(patientInfo)) {
			long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("NutritionGoal").get(0)
					.getId();

			List<PatientActivityAssociation> paaList = patientActivityAssociationRepository
					.findByPatientIdandActivityId(nutritionActivity.getPid(), nutritionActivity.getActivityId());
			if (!paaList.isEmpty()) {
				if (activityTypeId == paaList.get(0).getActivityTypeId()) {
					try {
						PatientActivityAssociation patActivityAssociation = patientActivityAssociationRepository
								.findOne(nutritionActivity.getActivityId());

						patActivityAssociation.setPatientId(nutritionActivity.getPid());
						if (nutritionActivity.getCaloriesTargetIntake() != null) {
							patActivityAssociation.setTargetValue(nutritionActivity.getCaloriesTargetIntake() + "");
						}
						if (nutritionActivity.getGoalEndDate() != null) {
							patActivityAssociation.setTargetDate(nutritionActivity.getGoalEndDate());
						}
						if (nutritionActivity.getName() != null) {
							patActivityAssociation.setActivityName(nutritionActivity.getName());
						}
						patientActivityAssociationRepository.save(patActivityAssociation);
						message.put("message", "Updated successfully");
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					message.put("message", "Failed: Activity is not associated with patient");

				}
			} else {
				message.put("message", "Failed: Activity is not associated with patient");

			}
		} else {
			message.put("message", "Failed: Patient is not found");
		}
		return message;
	}

	public JSONObject addWeightGoal(WeightActivityDTO weightActivity) {
		PatientActivityAssociation patientActivityAssociation = new PatientActivityAssociation();

		JSONObject message = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOneById(weightActivity.getPid());

		if (!Objects.isNull(patientInfo)) {
			long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightGoal").get(0)
					.getId();
			// String activityName =
			// hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightGoal").get(0).getType_code_value();
			List<PatientActivityAssociation> paaList = patientActivityAssociationRepository
					.findActiveActivityByPatientIdandActivityTypeId(weightActivity.getPid(), activityTypeId);
			if (paaList.isEmpty()) {

				patientActivityAssociation.setIsActive(true);
				patientActivityAssociation.setActivityTypeId(activityTypeId);
				patientActivityAssociation.setActivityName(weightActivity.getName());
				patientActivityAssociation.setCreatedDate(DateTime.now(DateTimeZone.UTC).getMillis());

				if (weightActivity.getCurrentWeight() != null) {
					patientActivityAssociation.setIntialValue(weightActivity.getCurrentWeight() + "");
				} else {
					long activityTypeIdForWeight = hillromTypeCodeFormatRepository
							.findCodeValuesListByTypeCode("WeightLog").get(0).getId();
					PatientActivityHistory patWeightHistory = patientActivityHistoryRepository
							.findRecentWeight(weightActivity.getPid(), activityTypeIdForWeight);
					if (Objects.nonNull(patWeightHistory)) {
						patientActivityAssociation.setIntialValue(patWeightHistory.getCurrentValue());
					} else {
						patientActivityAssociation.setIntialValue("0");
					}
				}
				patientActivityAssociation.setTargetValue(weightActivity.getTargetWeight() + "");
				patientActivityAssociation.setPatientId(weightActivity.getPid());
				patientActivityAssociation.setTargetDate(weightActivity.getGoalEndDate());
				patientActivityAssociationRepository.save(patientActivityAssociation);
				message.put("activityId", patientActivityAssociation.getId());
			} else {
				message.put("message", "Weight Goal is alerady set for the Patient Id");

			}
		} else {
			message.put("message", "Failed: Patient is not found");
		}
		return message;
	}

	public JSONObject updateWeightGoal(WeightActivityDTO weightActivity) {
		JSONObject message = new JSONObject();
		long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightGoal").get(0).getId();
		PatientInfo patientInfo = patientInfoRepository.findOneById(weightActivity.getPid());
		if (!Objects.isNull(patientInfo)) {
			List<PatientActivityAssociation> patientActivityId = patientActivityAssociationRepository
					.findByPatientIdandActivityId(weightActivity.getPid(), weightActivity.getActivityId());
			if (!patientActivityId.isEmpty()) {
				if (activityTypeId == patientActivityId.get(0).getActivityTypeId()) {
					PatientActivityAssociation patActivityAssociation = patientActivityAssociationRepository
							.findOne(weightActivity.getActivityId());
					patActivityAssociation.setPatientId(weightActivity.getPid());
					if (weightActivity.getTargetWeight() != null) {
						patActivityAssociation.setTargetValue(weightActivity.getTargetWeight().toString());
					}
					if (weightActivity.getCurrentWeight() != null) {
						patActivityAssociation.setIntialValue(weightActivity.getCurrentWeight().toString());
					}
					if (weightActivity.getGoalEndDate() != null) {
						patActivityAssociation.setTargetDate(weightActivity.getGoalEndDate());
					}
					if (weightActivity.getName() != null) {
						patActivityAssociation.setActivityName(weightActivity.getName());
					}
					patientActivityAssociationRepository.save(patActivityAssociation);

					message.put("message", "Updated successfully");
				} else {
					message.put("message", "Failed: Activity is not associated with patient");
				}
			} else {
				message.put("message", "Failed: Activity is not associated with patient");
			}
		} else {
			message.put("message", "Failed: Patient is not found");
		}
		return message;
	}

	public List<BadgesMaster> getAllPatientBadges() {
		// JSONObject jsonObject = new JSONObject();
		List<BadgesMaster> badgesMasterlist = badgesMasterRepository.getAll();
		// jsonObject.put("badges", badgesMasterlist);
		return badgesMasterlist;
	}

	public List<AwardMasterVO> getAllAwards() {
        List<AwardMaster> awardsMasterlist = awardMasterRepository.getAll();
        List<AwardMasterVO> awardMasterVOList = new ArrayList<>();
        for (AwardMaster am : awardsMasterlist) {
               AwardMasterVO amo = new AwardMasterVO(am);
               amo.setActivityType(hillromTypeCodeFormatRepository.getOne(am.getActivityTypeId()).getType_code_value());
               awardMasterVOList.add(amo);
        }
        return awardMasterVOList;
 }

	public JSONObject logWeight(LogActivityDTO logActivity) {
		JSONObject jsonObject = new JSONObject();
		Boolean isValidDate = DateUtil.isDateTimeWithin90Days(logActivity.getDate());
		if (!isValidDate) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		PatientActivityHistory patientActivityHistory = new PatientActivityHistory();
		Map<String, List<Long>> awardsAndBadges = new HashMap<String, List<Long>>();

		Long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightGoal").get(0).getId();
		Long activityTypeIdForWeightLog = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightLog").get(0).getId();
		if (activityTypeId != null) {
			try {
				PatientInfo patientInfo = patientInfoRepository.findOneById(logActivity.getPid());
				if (!Objects.isNull(patientInfo)) {
					List<PatientActivityAssociation> pidActId = null;
					if (logActivity.getActivityId() != null) { // acvtivityId
						pidActId = patientActivityAssociationRepository.findActiveActivityByPatientIdandActivityId(
								logActivity.getPid(), logActivity.getActivityId(), activityTypeId);
					} else {
						pidActId = patientActivityAssociationRepository
								.findActiveActivityByPatientIdandActivityTypeId(logActivity.getPid(), activityTypeId);
					}

					if (!pidActId.isEmpty()) {
						// new entry in history table
						patientActivityHistory.setPatientId(logActivity.getPid());
						patientActivityHistory.setCurrentValue(logActivity.getWeight() + "");
						patientActivityHistory.setActivityTypeId(activityTypeIdForWeightLog);
						patientActivityHistory.setPatientActivityAssociationId(pidActId.get(0).getId());
						patientActivityHistory.setRecordedDateTime(logActivity.getDate());
						patientActivityHistoryRepository.save(patientActivityHistory);
						awardsAndBadges = awardsAndBadgesCalculatorService
								.awardsAndBadgesAssociatedToPatient(logActivity.getPid(), activityTypeIdForWeightLog);
						jsonObject.put("message", ExceptionConstants.HR_936);
						jsonObject.put("badges",
								(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

						// Push notifications for awarded badges
						notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
					} else {
						if (logActivity.getActivityId() != null) { // acvtivityId
							jsonObject.put("message", ExceptionConstants.HR_919);
						} else {
							// jus an entry in history table
							patientActivityHistory.setPatientId(logActivity.getPid());
							patientActivityHistory.setCurrentValue(logActivity.getWeight() + "");
							patientActivityHistory.setActivityTypeId(activityTypeIdForWeightLog);
							patientActivityHistory.setRecordedDateTime(logActivity.getDate());
							patientActivityHistoryRepository.save(patientActivityHistory);
							awardsAndBadges = awardsAndBadgesCalculatorService.awardsAndBadgesAssociatedToPatient(
									logActivity.getPid(), activityTypeIdForWeightLog);
							jsonObject.put("message", ExceptionConstants.HR_936);
							jsonObject.put("badges",
									(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

							// Push notifications for awarded badges
							notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
						}
					}

				} else {
					jsonObject.put("message", ExceptionConstants.HR_915);

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			jsonObject.put("message", ExceptionConstants.HR_919);
		}
		return jsonObject;
	}

	public JSONObject logNutrition(LogActivityDTO logActivity) {
		JSONObject jsonObject = new JSONObject();
		Boolean isValidDate = DateUtil.isDateTimeWithin90Days(logActivity.getDate());
		if (!isValidDate) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		Map<String, List<Long>> awardsAndBadges = new HashMap<String, List<Long>>();
		PatientActivityHistory patientActivityHistory = new PatientActivityHistory();
		Long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("NutritionGoal").get(0)
				.getId();
		Long activityTypeIdFoNutritionLog = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("NutritionLog")
				.get(0).getId();
		if (activityTypeId != null) {
			try {
				PatientInfo patientInfo = patientInfoRepository.findOneById(logActivity.getPid());
				if (!Objects.isNull(patientInfo)) {
					List<PatientActivityAssociation> pidActId = null;
					if (logActivity.getActivityId() != null) { // acvtivityId
						pidActId = patientActivityAssociationRepository.findActiveActivityByPatientIdandActivityId(
								logActivity.getPid(), logActivity.getActivityId(), activityTypeId);
					} else {
						pidActId = patientActivityAssociationRepository
								.findActiveActivityByPatientIdandActivityTypeId(logActivity.getPid(), activityTypeId);
					}

					if (!pidActId.isEmpty()) {
						// new entry in history table
						patientActivityHistory.setPatientId(logActivity.getPid());
						patientActivityHistory.setCurrentValue(logActivity.getNutrition() + "");
						patientActivityHistory.setActivityTypeId(activityTypeIdFoNutritionLog);
						patientActivityHistory.setPatientActivityAssociationId(pidActId.get(0).getId());
						patientActivityHistory.setRecordedDateTime(logActivity.getDate());
						patientActivityHistoryRepository.save(patientActivityHistory);
						awardsAndBadges = awardsAndBadgesCalculatorService
								.awardsAndBadgesAssociatedToPatient(logActivity.getPid(), activityTypeIdFoNutritionLog);
						jsonObject.put("message", ExceptionConstants.HR_936);
						jsonObject.put("badges",
								(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

						// Push notifications for awarded badges
						notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
					} else {
						if (logActivity.getActivityId() != null) {
							jsonObject.put("message", ExceptionConstants.HR_919);
						} else {
							patientActivityHistory.setPatientId(logActivity.getPid());
							patientActivityHistory.setCurrentValue(logActivity.getNutrition() + "");
							patientActivityHistory.setActivityTypeId(activityTypeIdFoNutritionLog);
							patientActivityHistory.setRecordedDateTime(logActivity.getDate());
							patientActivityHistoryRepository.save(patientActivityHistory);
							awardsAndBadges = awardsAndBadgesCalculatorService.awardsAndBadgesAssociatedToPatient(
									logActivity.getPid(), activityTypeIdFoNutritionLog);
							jsonObject.put("message", ExceptionConstants.HR_936);
							jsonObject.put("badges",
									(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

							// Push notifications for awarded badges
							notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
						}
					}
				} else {
					jsonObject.put("message", ExceptionConstants.HR_915);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			jsonObject.put("message", ExceptionConstants.HR_919);
		}
		return jsonObject;
	}

	public JSONObject logExercise(LogActivityDTO logActivity) {
		JSONObject jsonObject = new JSONObject();
		Boolean isValidDate = DateUtil.isDateTimeWithin90Days(logActivity.getExerciseDate());
		if (!isValidDate) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		PatientActivityHistory patientActivityHistory = new PatientActivityHistory();
		Map<String, List<Long>> awardsAndBadges = new HashMap<String, List<Long>>();
		try {
			Long activityTypeId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("ExerciseGoal").get(0)
					.getId();
			Long activityTypeIdForExercise = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("ExerciseLog")
					.get(0).getId();
			PatientInfo patientInfo = patientInfoRepository.findOneById(logActivity.getPid());
			if (Objects.isNull(patientInfo)) {
				jsonObject.put("message", ExceptionConstants.HR_915);
				return jsonObject;
			} 
				patientActivityHistory.setPatientId(logActivity.getPid());
				patientActivityHistory.setCurrentValue(logActivity.getExerciseDuration().toString());
				patientActivityHistory.setActivityTypeId(activityTypeIdForExercise);
				patientActivityHistory.setRecordedDateTime(logActivity.getExerciseDate());

				List<PatientActivityAssociation> patientActivityAssociation = null;

				if (logActivity.getActivityId() != null) { // acvtivityId
					patientActivityAssociation = patientActivityAssociationRepository
							.findActiveActivityByPatientIdandActivityId(logActivity.getPid(),
									logActivity.getActivityId(), activityTypeId);
				} else {
					patientActivityAssociation = patientActivityAssociationRepository
							.findActiveActivityByPatientIdandActivityTypeId(logActivity.getPid(), activityTypeId);
				}

				String weekDay = patientActivityAssociationRepository
						.getDayNameFromDate(new DateTime(logActivity.getExerciseDate()).toString());

			if (Objects.nonNull(patientActivityAssociation) && patientActivityAssociation.size() > 0) {
					String extendedInfo = patientActivityAssociation.get(0).getExtendedInfo();

				if (Objects.nonNull(extendedInfo) && extendedInfo.toUpperCase().contains(weekDay.toUpperCase())
							&& patientActivityAssociation.get(0).getIsActive()) {
						patientActivityHistory.setPatientActivityAssociationId(logActivity.getActivityId());
						patientActivityHistoryRepository.save(patientActivityHistory);
						awardsAndBadges = awardsAndBadgesCalculatorService
								.awardsAndBadgesAssociatedToPatient(logActivity.getPid(), activityTypeIdForExercise);
						jsonObject.put("message", ExceptionConstants.HR_936);
						jsonObject.put("badges",
								(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

						// Push notifications for awarded badges
						notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
					} else {
						patientActivityHistoryRepository.save(patientActivityHistory);
						awardsAndBadges = awardsAndBadgesCalculatorService
								.awardsAndBadgesAssociatedToPatient(logActivity.getPid(), activityTypeIdForExercise);
						jsonObject.put("message", ExceptionConstants.HR_936);
						jsonObject.put("badges",
								(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

						// Push notifications for awarded badges
						notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
					}
				} else {
					if (logActivity.getActivityId() != null) { // acvtivityId
						jsonObject.put("message", ExceptionConstants.HR_919);
					} else {
						patientActivityHistoryRepository.save(patientActivityHistory);
						awardsAndBadges = awardsAndBadgesCalculatorService
								.awardsAndBadgesAssociatedToPatient(logActivity.getPid(), activityTypeIdForExercise);
						jsonObject.put("message", ExceptionConstants.HR_936);
						jsonObject.put("badges",
								(awardsAndBadges.get("badges").size() > 0 ? awardsAndBadges.get("badges") : null));

						// Push notifications for awarded badges
						notifyAwardedBadges(awardsAndBadges, logActivity.getPid());
				}
			}
		} catch (Exception e) {
			jsonObject.put("message", ExceptionConstants.HR_915);
		}
		return jsonObject;
	}

	public void notifyAwardedBadges(Map<String, List<Long>> awardsAndBadges,String patientId) {

		if (Objects.nonNull(awardsAndBadges.get("badges")) && awardsAndBadges.get("badges").size() > 0) {
				// Badges
				List<Long> badges = awardsAndBadges.get("badges");
				for (Long badge : badges) {
					BadgesMaster badgeMaster = badgesMasterRepository.getOne(badge);
					pushNotificationService.pushNotificationForBadges(patientId,
							badgeMaster.getId(), badgeMaster.getCategory(),
							badgeMaster.getType(), badgeMaster.getCompletedDescription(),
							badgeMaster.getBadgeName());
			}
		}
	}
	
	public ImagesVO getAllImages() {
		ImagesVO imagesList = new ImagesVO();
		List<BadgesMaster> badgesMasterList = badgesMasterRepository.getAll();
		//List<AwardMaster> awardsMasterList = awardMasterRepository.getAll();
		List<AwardMasterVO> awardsMasterList = getAllAwards();
		List<MobileEmoji> emojiList = mobileEmojiRepository.getAll();
		List<ImageMaster> imageList =  imageMasterRepository.getAll();
		
		imagesList.setBadgesList(badgesMasterList);
		imagesList.setAwardsList(awardsMasterList);
		imagesList.setEmojiList(emojiList);
		imagesList.setImageList(imageList);

		return imagesList;
	}

	// Dummy cron to mark expired activities inactive
    @Scheduled(cron="${cron.award.assign.utcminus12}")
    @Scheduled(cron="${cron.award.assign.utcminus11}")    
    @Scheduled(cron="${cron.award.assign.utcminus10}")
    @Scheduled(cron="${cron.award.assign.utcminus9}")
    @Scheduled(cron="${cron.award.assign.utcminus8}")
    @Scheduled(cron="${cron.award.assign.utcminus7}")
    @Scheduled(cron="${cron.award.assign.utcminus6}")
    @Scheduled(cron="${cron.award.assign.utcminus5}")
    @Scheduled(cron="${cron.award.assign.utcminus4}")
    @Scheduled(cron="${cron.award.assign.utcminus330}")
    @Scheduled(cron="${cron.award.assign.utcminus230}")
    @Scheduled(cron="${cron.award.assign.utcplus10}")
    public void assignAwards() {
    	assignAwards(false);
    }
    
	public void assignAwards(boolean forceTimezone) {
		try {
			log.debug("Started marking expired activities " + DateTime.now());
			List<HillromTypeCodeFormat> exerciseTypeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("ExerciseGoal");

			List<HillromTypeCodeFormat> weightTypeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("WeightGoal");   	

			List<HillromTypeCodeFormat> nutritionTypeCodeList = hillromTypeCodeFormatRepository
					.findCodeValuesListByTypeCode("NutritionGoal");

			// This job runs before an hour
			
			String timeZone = DateUtil.getTimeZoneFromESTHour(LocalDateTime.now().getHourOfDay()+1);
			if (StringUtils.isBlank(timeZone)) {
				return;
			}
			
			if(forceTimezone)
			{
				timeZone = Constants.UTC_MINUS5;
			}
			
			String zoneIdString = new StringBuilder("'%").append(timeZone)
					.append("%'").toString();
			
			String query = QueryConstants.QUERY_ASSIGN_AWARDS_PATIENTS;
			if (StringUtils.isBlank(query)) {
				return;
			}
			
			String finalQuery = query.replaceAll(":zone", zoneIdString);
			
			log.debug(finalQuery);
			Query nativeQuery = entityManager.createNativeQuery(finalQuery);
			@SuppressWarnings("unchecked")
			List<Object[]> resultSet = nativeQuery.getResultList();
			resultSet.stream().forEach((record) -> {
				String patient_id = record[0].toString();
				Long activity_id = ((BigInteger) record[1]).longValue();
				Long activity_type_id = ((BigInteger) record[2]).longValue();
				Long awardId = 0L;

				log.debug("deactivating activity Id : " + activity_id);
				try {
	    			if(activity_type_id.equals(exerciseTypeCodeList.get(0).getId())) {
	        			awardId = awardsAndBadgesCalculatorService.exerciseGoalMetrics(patient_id,activity_type_id);    				
	    			}else if(activity_type_id.equals(weightTypeCodeList.get(0).getId())) {
	    				awardId = awardsAndBadgesCalculatorService.weightGoalMetrics(patient_id,activity_type_id);
	    			}else if(activity_type_id.equals(nutritionTypeCodeList.get(0).getId())) {
	    				awardId = awardsAndBadgesCalculatorService.nutritionGoalMetrics(patient_id,activity_type_id);
	    			}
	    			
	    			if(awardId != 0) {
	    				awardsAndBadgesCalculatorService.assignBadgeToCompletedGoals(patient_id);
	    			}
				}catch (Exception ex) {
					ex.printStackTrace();
				}
			});		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
