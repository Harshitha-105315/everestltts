package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class BadgesLockedVO {

	@ApiModelProperty(notes="badgeId (Long)", required=true, example = "2")
	private Long badgeId;

	@ApiModelProperty(notes="badgeName (String)", required=true, example = "AllStar")
	private String badgeName;
	
	@ApiModelProperty(notes="currentCount (int)", required=true, dataType = "int" ,example = "10")
	private int currentCount;
	
	@ApiModelProperty(notes="totalCount (int)", required=true,example = "25")
	private int totalCount;
	
	@ApiModelProperty(notes = "category (String)", required = false, example = "Goal")
	private String category;
	
	@ApiModelProperty(notes = "type (String)", required = false, example = "Activity")
	private String type;
	
	@ApiModelProperty(notes="description (String)", required=true, example="Weigh in 50 times")
	private String  description;
	
	@ApiModelProperty(notes="header (String)", required=true, example="Badge Unlocked")
	private String  header;
	
	@ApiModelProperty(notes="image (String)", required=true, example="/path/image.png")
	private String  image;

	@ApiModelProperty(notes="thumbNail (String)", required=true, example="/path/thumbNail.png")
	private String  thumbNail;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getThumbNail() {
		return thumbNail;
	}
	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String badgeDescription) {
		this.description = badgeDescription;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public Long getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(Long badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeName() {
		return badgeName;
	}
	public void setBadgeName(String badgeName) {
		this.badgeName = badgeName;
	}
	public int getCurrentCount() {
		return currentCount;
	}
	public void setCurrentCount(int currentCount) {
		this.currentCount = currentCount;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
