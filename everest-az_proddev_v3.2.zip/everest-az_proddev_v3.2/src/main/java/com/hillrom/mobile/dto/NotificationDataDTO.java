package com.hillrom.mobile.dto;

public class NotificationDataDTO {

	//id,sendDate
	private Long id;
	private Long sentDate;

	// NotificationExtendedInfoDTO as message
	private NotificationExtendedInfoDTO message;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSentDate() {
		return sentDate;
	}
	public void setSentDate(Long sentDate) {
		this.sentDate = sentDate;
	}
	public NotificationExtendedInfoDTO getMessage() {
		return message;
	}
	public void setMessage(NotificationExtendedInfoDTO message) {
		this.message = message;
	}
	public NotificationDataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NotificationDataDTO(NotificationExtendedInfoDTO message, Long id, Long sentDate) {
		super();
		this.message = message;
		this.id = id;
		this.sentDate = sentDate;
	}
	
}
