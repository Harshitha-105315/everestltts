package com.hillrom.mobile.rest;

import java.net.URISyntaxException;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.httpclient.URIException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.mobile.domain.AwardMaster;
import com.hillrom.mobile.domain.BadgesMaster;
import com.hillrom.mobile.dto.AwardMasterVO;
import com.hillrom.mobile.dto.AwardsHistoryVO;
import com.hillrom.mobile.dto.BadgesHistoryListVO;
import com.hillrom.mobile.dto.ExerciseActivityDTO;
import com.hillrom.mobile.dto.ImagesVO;
import com.hillrom.mobile.dto.LogActivityDTO;
import com.hillrom.mobile.dto.NutritionActivityDTO;
import com.hillrom.mobile.dto.PatientCurrentActivitiesDTO;
import com.hillrom.mobile.dto.PatientExerciseGoals;
import com.hillrom.mobile.dto.PatientExerciseGoalsWithDateRange;
import com.hillrom.mobile.dto.PatientNutritionGoals;
import com.hillrom.mobile.dto.PatientNutritionGoalsWithDateRange;
import com.hillrom.mobile.dto.PatientWeightGoals;
import com.hillrom.mobile.dto.PatientWeightGoalsWithDateRange;
import com.hillrom.mobile.dto.WeightActivityDTO;
import com.hillrom.mobile.service.ActivityService;
import com.hillrom.mobile.service.PushNotificationService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.util.ExceptionConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.minidev.json.JSONObject;

@RestController
@Api(value = "SetExerciseGoal", description = "ACTIVITY CONTROLLER")
@RequestMapping("/api/patient/"+ Constants.ApiVersion)
public class ActivityController {

	private final Logger log = LoggerFactory
			.getLogger(ActivityController.class);
	
	@Inject
	private ActivityService activityService;
	
	@Inject
	private PushNotificationService pushNotificationService;
		
	@ApiOperation(httpMethod = "POST", value = "Set Exercise Goal")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "exerciseDays", value = "Exersice Days", required = true, dataType = "String[]", allowableValues = "Sun, Mon,Tues"),
			@ApiImplicitParam(name = "exerciseDuration", value = "Exersice Performed Duration", required = true, dataType = "Long", example = "20"),
			@ApiImplicitParam(name = "goalStartDate", value = "Start Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010" ),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010" ),
			@ApiImplicitParam(name = "name", value = "Name of the exercise performed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns activityId") })
	@RequestMapping(value = "/activity/exercise/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createExercise(@RequestBody ExerciseActivityDTO exerciseActivity) {
		JSONObject jsonObject = new JSONObject();
		if (exerciseActivity.getPid() != null && exerciseActivity.getExerciseDays() != null
				&& exerciseActivity.getExerciseDuration() != null && exerciseActivity.getGoalEndDate() != null
				&& exerciseActivity.getName() != null) {
			try {
				jsonObject = activityService.addExerciseGoal(exerciseActivity);
				if(!jsonObject.isEmpty()) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				jsonObject.put("message", e);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "POST", value = "Set Weight Goal")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "targetWeight", value = "target weight to be acheived", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "currentWeight", value = "Current weight", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "goalStartDate", value = "Start Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "name", value = "Name of the exercise performed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns activityId") })
	@RequestMapping(value = "/activity/weight/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createWeight(@RequestBody WeightActivityDTO weightActivity) {
		JSONObject jsonObject = new JSONObject();
		if (weightActivity.getPid() != null && weightActivity.getTargetWeight() != null && weightActivity.getGoalEndDate() != null && weightActivity.getName() != null) {
			try {
				jsonObject = activityService.addWeightGoal(weightActivity);
				if(!jsonObject.isEmpty()){
					if(jsonObject.containsValue("Failed: Current weight is not found") || jsonObject.containsValue("Failed: Weight Goal is already Set") || jsonObject.containsValue("Failed: Patient is not found")) {
						return new ResponseEntity<>(jsonObject, HttpStatus.OK);
					}else {
						return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
					}
				}else {
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			}catch(Exception e) {
				jsonObject.put("message", e);
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		}else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "POST", value = "Set Nutrition Goal")

	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "caloriesTargetIntake", value = "calories consumed", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "goalStartDate", value = "Start Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "name", value = "Name of the nutrition consumed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns activityId") })
	@RequestMapping(value = "/activity/nutrition/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createNutrition(@RequestBody NutritionActivityDTO nutritionActivity)
			{
           JSONObject jsonObject = new JSONObject();
           if (nutritionActivity.getPid() != null && nutritionActivity.getCaloriesTargetIntake() != null
                        && nutritionActivity.getGoalEndDate() != null && nutritionActivity.getName() != null) {
                  try {
                        jsonObject = activityService.addNutritionGoal(nutritionActivity);
                        if(!jsonObject.isEmpty()){
                               if(jsonObject.containsValue("Nutrition Goal is alerady set for the Patient Id") || jsonObject.containsValue("Failed: Patient is not found")) {
                                      return new ResponseEntity<>(jsonObject, HttpStatus.OK);
                               }else {
                               return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
                               }
                        }else {
                               return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
                        }
                        
                        
                  } catch (Exception e) {
                        jsonObject.put("message", e);
                        return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
                  }

           } else {
                  jsonObject.put("message", "Failed: Required Field is missing");
                  return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
           }
           
    }



	@ApiOperation(httpMethod = "POST", value = "Log Excersice Activity")

	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "exerciseDuration", value = "Exercise performed", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "exerciseDate", value = "Exercise Date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = false, dataType = "Long") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Log Successfull"),
			@ApiResponse(code = 422, message = "Failed: Invalid Date Range")})
	@RequestMapping(value = "/activity/exercise/log", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> logExercise(@RequestBody LogActivityDTO logActivity) throws URISyntaxException {
		JSONObject jsonObject = new JSONObject();
		if(logActivity.getPid()!=null && logActivity.getExerciseDate()!=null && logActivity.getExerciseDuration()!=null) {
			try {
				jsonObject = activityService.logExercise(logActivity);

				if (jsonObject.containsValue("Log successfull")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else if (jsonObject.containsValue(ExceptionConstants.HR_954)) { 
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			} catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}

		}else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
		

	}

	@ApiOperation(httpMethod = "POST", value = "Log Weight Activity")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = false, dataType = "String"),
			@ApiImplicitParam(name = "weight", value = "weight", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "date", value = "date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Log Successfull"),
			@ApiResponse(code = 422, message = "Failed: Invalid Date Range") })
	@RequestMapping(value = "/activity/weight/log", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> logWeight(
			@RequestBody LogActivityDTO logActivity) {

		JSONObject jsonObject = new JSONObject();
		if (logActivity.getPid() != null && logActivity.getWeight() != null
				&& logActivity.getDate() != null) {
			try {

				jsonObject = activityService.logWeight(logActivity);

		
				if (jsonObject.containsValue("Log successfull")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else if (jsonObject.containsValue(ExceptionConstants.HR_954)) { 
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			}

			catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject,
						HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "POST", value = "Log Nutrition Activity")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = false, dataType = "String"),
			@ApiImplicitParam(name = "nutrition", value = "nutrition", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "date", value = "date with Unix time stamp in milli seconds", required = true, dataType = "Long", example = "1527502581010") })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Log Successfull"),
			@ApiResponse(code = 422, message = "Failed: Invalid Date Range") })
	@RequestMapping(value = "/activity/nutrition/log", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> logNutrition(
			@RequestBody LogActivityDTO logActivity) {

		JSONObject jsonObject = new JSONObject();
		if (logActivity.getPid() != null
				&& logActivity.getNutrition() != null
				&& logActivity.getDate() != null) {
			try {
				jsonObject = activityService.logNutrition(logActivity);

				if (jsonObject.containsValue("Log successfull")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else if (jsonObject.containsValue(ExceptionConstants.HR_954)) { 
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			}

			catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject,
						HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}

	}

	@ApiOperation(httpMethod = "PUT", value = "Edit Exercise Goal")

	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "exerciseDays", value = "exercise Days", required = false, dataType = "String[]", allowableValues = "Sun, Mon,Tues"),
			@ApiImplicitParam(name = "exerciseDuration", value = "exercise Performed Duration", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "name", value = "Name of the exercise performed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Updated Successfully") })
	@RequestMapping(value = "/activity/exercise/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> editExercise(@RequestBody ExerciseActivityDTO exerciseActivity)
			{
		JSONObject jsonObject = new JSONObject();
		if (exerciseActivity.getPid() != null && exerciseActivity.getActivityId() != null && exerciseActivity.getName() != null) {
			try {
				jsonObject = activityService.updateExerciseGoal(exerciseActivity);

				if (jsonObject.containsValue("Updated successfully")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			}

			catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject,
						HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
	

	@ApiOperation(httpMethod = "PUT", value = "Edit Nutrition Activity Goal")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "caloriesTargetIntake", value = "calories consumed", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "name", value = "Name of the nutrition consumed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Updated Successfully") })
	@RequestMapping(value = "/activity/nutrition/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> editNutrition(@RequestBody NutritionActivityDTO nutritionActivity)
			 {
		JSONObject jsonObject = new JSONObject();
		if (nutritionActivity.getPid() != null && nutritionActivity.getActivityId() != null && nutritionActivity.getName() != null) {
			try {
				jsonObject = activityService.updateNutritionGoal(nutritionActivity);

				if (jsonObject.containsValue("Updated successfully")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			}

			catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject,
						HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "PUT", value = "Edit Weight Activity Goal")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "targetWeight", value = "target weight to be acheived", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "currentWeight", value = "Current weight", required = false, dataType = "Long"),
			@ApiImplicitParam(name = "goalEndDate", value = "Target Date with Unix time stamp in milli seconds", required = false, dataType = "Long", example = "1527502581010"),
			@ApiImplicitParam(name = "name", value = "Name of the exercise performed", required = true, dataType = "String") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Updated Successfully") })
	@RequestMapping(value = "/activity/weight/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> editWeight(@RequestBody WeightActivityDTO weightActivity)  {
		JSONObject jsonObject = new JSONObject();
		if (weightActivity.getPid() != null && weightActivity.getActivityId() != null && weightActivity.getName() != null) {
			try {
				jsonObject = activityService.updateWeightGoal(weightActivity);

				if (jsonObject.containsValue("Updated successfully")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				} else {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
				}
			}

			catch (Exception e) {
				jsonObject.put("ERROR", e.getMessage());
				return new ResponseEntity<JSONObject>(jsonObject,
						HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@ApiOperation(httpMethod = "DELETE", value = "DELETE Activity")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "Activity Id", required = true, dataType = "Long") })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Deleted Successfully") })
	@RequestMapping(value = "/activity/remove", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> deleteExercise(@RequestBody ExerciseActivityDTO exerciseActivity) {
		JSONObject jsonObject = new JSONObject();
		if (exerciseActivity.getPid() != null && exerciseActivity.getActivityId() != null) {
			String message = activityService.deleteActivity(exerciseActivity);
			jsonObject.put("message", message);
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/badges/retrieve/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find badges for patient", responseContainer = "List")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "patient ID", required = true, dataType = "String", access = "patient") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message =  ExceptionConstants.HR_918
												+ " or \r\n" + ExceptionConstants.HR_915					
			) })
	public BadgesHistoryListVO getBadgesForPatient(
			@ApiParam(value = "Patient Id is required to filter all badges associated", required = true, example = "HR000000000") @PathVariable String pid) {
		log.debug(
				"REST request to retrieve all badges associated for Patient : {}",pid);
		// ResponseEntity<JSONObject>
		BadgesHistoryListVO badgesHistoryList = null;
		try {
			badgesHistoryList = activityService.getAllPatientBadgesDetails(pid);
		} catch (Exception e) {
			log.debug("Exception in getBadgesForPatient" + e.getMessage());
		}
		return badgesHistoryList;
		
		
	}

	@RequestMapping(value = "/awards/retrieve/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find awards for patient", responseContainer = "List")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "pid", value = "patient ID", required = true, dataType = "String", access = "patient") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message =  ExceptionConstants.HR_917 
										+ " or \r\n" + ExceptionConstants.HR_915					
			) })
	public ResponseEntity<?> getAwardsForPatient(
			@ApiParam(value = "Patient Id is required to filter all awards associated", required = true, example = "HR000000000") @PathVariable String pid) {
		log.debug("REST request to retrieve all awards associated for Patient : {}",pid);
		List<AwardsHistoryVO> awardHistoryList = null;
		try {
			awardHistoryList = activityService.getAllPatientAwardsDetails(pid);
		} catch(URIException ue) { 
			log.debug(" URIException in getAwardsForPatient " + ue.getMessage());
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", ue.getReason());
			return new ResponseEntity<JSONObject>(jsonObject,HttpStatus.OK);
		} catch(Exception e) {
			log.debug(" Exception in getAwardsForPatient " + e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(awardHistoryList,HttpStatus.OK);

	}

	@RequestMapping(value = "/activity/nutrition/retrieveGoal/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all nutrition goals associated with patient with data range", notes = "Multiple status values can be provided for nutrition history, award history and any active goal", responseContainer = "List")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "activity Id", required = true, dataType = "long"),
			@ApiImplicitParam(name = "fromDate", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "toDate", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = "Failed: Activity is not associated with patient" 
										+ " or \r\n" + "Failed: Activity id is not associated with nutrition goal" 
										+ " or \r\n" + ExceptionConstants.HR_915
			) })
	public PatientNutritionGoals getNutritionGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "activityId", required = true) Long activityId,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to) {
		log.debug("REST request to get all nutrition details associated for patient : {}");
		PatientNutritionGoals patientNutritionGoals = null;
		try {
			patientNutritionGoals = activityService.getAllPatientNutritionGoals(pid,
					activityId, from, to);
		} catch(Exception e) {
			log.debug("Exception in getNutritionGoalDetailsForPatient" + e.getMessage());
		}
		return patientNutritionGoals;
	}

	@RequestMapping(value = "/activity/exercise/retrieveGoal/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all exercise goals associated with patient with data range", notes = "Multiple status values can be provided for exercise history, award history and any active goal", responseContainer = "List")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "activity Id", required = true, dataType = "long"),
			@ApiImplicitParam(name = "from", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "to", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = "Failed: Activity is not associated with patient" 
										+ " or \r\n" + "Failed: Activity id is not associated with weight goal" 
										+ " or \r\n" + ExceptionConstants.HR_915					
			) })
	public PatientExerciseGoals getExerciseGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "activityId", required = true) Long activityId,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to) {
		log.debug("REST request to get all nutrition details associated for patient : {}");
		PatientExerciseGoals patientExerciseGoals = null;
		try {
			patientExerciseGoals = activityService.getAllPatientExerciseGoals(pid,
					activityId, from, to);
		} catch (Exception e) {
			
		}
		return patientExerciseGoals;
	}

	@RequestMapping(value = "/activity/weight/retrieveGoal/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all weight goals associated with patient with data range", notes = "Multiple status values can be provided for weight history, award history and any active goal", responseContainer = "List")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "activityId", value = "activity Id", required = true, dataType = "long"),
			@ApiImplicitParam(name = "fromDate", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "toDate", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = "Failed: Activity is not associated with patient" 
										+ " or \r\n" + "Failed: Activity id is not associated with weight goal" 
										+ " or \r\n" + ExceptionConstants.HR_915					
			) })
	public PatientWeightGoals getWeightGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "activityId", required = true) Long activityId,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to) {
		log.debug("REST request to get all nutrition details associated for patient : {}");
		PatientWeightGoals patientWeightGoals = null;
		try {
			patientWeightGoals = activityService.getAllPatientWeightGoals(pid,activityId,from,to);
		} catch(Exception e) {
			log.debug("Exception in getWeightGoalDetailsForPatient" + e.getMessage());
		}
		return patientWeightGoals;
	}

	@RequestMapping(value = "/activity/nutrition/retrieveDateRange/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all nutrition goals associated with patient with data range", 
	notes = "Multiple status values can be provided for nutrition history, award history and any active goal",
	response = JSONObject.class)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "from", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "to", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid patient ID"),
			 @ApiResponse(code = 200, message = "Success",response = JSONObject.class)})
	public ResponseEntity<?> getAllNutritionGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to) {

			PatientNutritionGoalsWithDateRange patientNutritionGoalsWithDateRange = null;
			try {
				patientNutritionGoalsWithDateRange = activityService.getAllPatientNutritionGoalsWithDateRange(pid, from, to);
			} catch(URIException ue) { 
				log.error(" URIException in getAllNutritionGoalDetailsForPatient " + ue.getMessage());
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("message", ue.getReason());
				return new ResponseEntity<JSONObject>(jsonObject,HttpStatus.OK);
			} catch (Exception e) {
				log.error(" Exception in getAllNutritionGoalDetailsForPatient " + e.getMessage());
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>(patientNutritionGoalsWithDateRange,HttpStatus.OK);

	}


	@RequestMapping(value = "/activity/exercise/retrieveDateRange/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all exercise goals associated with patient with data range", notes = "Multiple status values can be provided for exercise history, award history and any active goal", responseContainer = "List")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "from", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "to", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = 	ExceptionConstants.HR_915 )
	})
	public ResponseEntity<?> getAllExerciseGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to)  {
		PatientExerciseGoalsWithDateRange patientExerciseGoalsWithDateRange = null;
		try {
			patientExerciseGoalsWithDateRange= activityService.getAllPatientExerciseGoalsWithDateRange(
				pid, from, to);
		} catch(URIException ue) { 
			log.error(" URIException in getAllExerciseGoalDetailsForPatient " + ue.getMessage());
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", ue.getReason());
			return new ResponseEntity<JSONObject>(jsonObject,HttpStatus.OK);
		} catch(Exception e) {
			log.error("Excepton in getAllExerciseGoalDetailsForPatient" + e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(patientExerciseGoalsWithDateRange,HttpStatus.OK);
	}

	@RequestMapping(value = "/activity/weight/retrieveDateRange/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find all weight goals associated with patient with data range", notes = "Multiple status values can be provided for weight history, award history and any active goal", responseContainer = "List")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "from", value = "start date", required = false, dataType = "long"),
			@ApiImplicitParam(name = "to", value = "end date", required = false, dataType = "long") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = 	ExceptionConstants.HR_915 )
	})
	public ResponseEntity<?> getAllWeightGoalDetailsForPatient(
			@PathVariable String pid,
			@RequestParam(value = "from", required = false) Long from,
			@RequestParam(value = "to", required = false) Long to) {
		PatientWeightGoalsWithDateRange patientWeightGoalsWithDateRange = null;
		try {
			patientWeightGoalsWithDateRange= activityService.getAllPatientWeightGoalsWithDateRange(
					pid, from, to);
		} catch(URIException ue) { 
			log.error(" URIException in getAllWeightGoalDetailsForPatient " + ue.getMessage());
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("message", ue.getReason());
			return new ResponseEntity<JSONObject>(jsonObject,HttpStatus.OK);
		} catch(Exception e) {
			log.error("Exception in getAllWeightGoalDetailsForPatient" + e.getMessage());
		}
		return new ResponseEntity<>(patientWeightGoalsWithDateRange,HttpStatus.OK);
	}

	@RequestMapping(value = "/activity/currentActivities/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Find current activities for patient", notes = "Multiple status values can be provided with comma separated like exercise, weight, nutrition", responseContainer = "List")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "patient ID", required = true, dataType = "String", access = "patient") })
	@ApiResponses(value = { 
			@ApiResponse(code = 500, message = 	ExceptionConstants.HR_915 )
	})
	public PatientCurrentActivitiesDTO getCurrentActivitiesForPatient(
			@ApiParam(value = "Patient Id is required to filter all activities associated", required = true, example = "HR000000000") @PathVariable String pid) {
		log.debug("REST request to get current activities for patient : {}",
				pid);
		PatientCurrentActivitiesDTO patientCurrentActivitiesDTO = null;
		try {
		patientCurrentActivitiesDTO = activityService.getAllPatientCurrentActivities(pid);
		} catch(Exception e) {
			log.debug("Exception in getCurrentActivitiesForPatient" + e.getMessage());
		}
		return patientCurrentActivitiesDTO;
	}
	
	@RequestMapping(value = "/badges/retrieveAll", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Retrieve all badges")
	public List<BadgesMaster> getAllBadges() {
		log.debug("REST request to retrieve all badges");
			return activityService.getAllPatientBadges();
	}

	@RequestMapping(value = "/awards/retrieveAll", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Retrieve all awards")
	public List<AwardMasterVO> getAwards() {
		return activityService.getAllAwards();
	}
	
	@RequestMapping(value = "/images/retrieve", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "GET", value = "Retrieve all awards, badges and emojis", response = ImagesVO.class)
	public ImagesVO getAllImages() {
		return activityService.getAllImages();
	}

	@RequestMapping(value="activity/executeCron", method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> executeActivityCron(){
		JSONObject jsonObject = new JSONObject();
		activityService.assignAwards(true);
		jsonObject.put("Message", "Success");
		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	}
	
	@RequestMapping(value="activity/executeAwardCron", method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> executeAwardPushNototificationCron(){
		JSONObject jsonObject = new JSONObject();
		pushNotificationService.awardUnlockedPushNotificationJob(true);
		jsonObject.put("Message", "Success");
		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	}
}
