
package com.hillrom.mobile.dto;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
public class NotificationRequestModel {

    @SerializedName("notification") //changing from notification to data
	private NotificationData notification;
	
	@SerializedName("data")
	private NotificationDataDTO data;
   
	@SerializedName("to")
    private String mTo;

	public NotificationDataDTO getData() {
		return data;
	}

	public NotificationData getNotification() {
		return notification;
	}

	public void setNotification(NotificationData notification) {
		this.notification = notification;
	}

	public void setData(NotificationDataDTO data) {
		this.data = data;
	}

	public String getmTo() {
		return mTo;
	}

	public void setmTo(String mTo) {
		this.mTo = mTo;
	}

    

}
