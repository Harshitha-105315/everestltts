package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.mobile.domain.PatientMedicationAssoc;

public interface PatientMedicationAssocRepository extends
		JpaRepository<PatientMedicationAssoc, String> {

	PatientMedicationAssoc findOneById(Long Id);
	
	@Query("from PatientMedicationAssoc ppd where ppd.patient = ?1 ")
	List<PatientMedicationAssoc> findByPatientId(String patientId);
	
	@Query("from PatientMedicationAssoc ppd where ppd.patient = ?1 and isActive=1 ")
	List<PatientMedicationAssoc> findByPatientIdAndIsActive(String patientId);
	
	@Query("from PatientMedicationAssoc ppd where ppd.patient = ?1 and ppd.id = ?2")
	PatientMedicationAssoc findByPatientIdAndMedicationId(String patientId, Long id);

	@Query("from PatientMedicationAssoc ppd where ppd.patient = ?1 and ppd.id = ?2")
	List<PatientMedicationAssoc> findByPatientIdAndMedicationIdList(String patientId, Long id);
	
	@Query(nativeQuery=true,
			 value="SELECT pma.id, pma.patient_id, pma.medication_recordings_id, pma.createdTime, "
			 		+ " pma.isArchive, pma.isActive "
			 		+ " FROM PATIENT_MEDICATION_ASSOC pma "					
					+ " where pma.patient_id=?1 and pma.createdTime between ?2 and ?3")
	List<PatientMedicationAssoc> findByPatientIdAndDate(String patientId, java.util.Date strDate, java.util.Date endDte );
	
}
