package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PATIENT_MEDICATION_ASSOC")
public class PatientMedicationAssoc {
	
	@JsonIgnore
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	/*@ManyToOne(optional = false, targetEntity = MedicationsRecordings.class,fetch=FetchType.LAZY)
	@JoinColumn(name = "medication_id", referencedColumnName = "id")*/
	@Column(name = "medication_recordings_id")
	private Long medicationRecordingsId;
	
	/*@ManyToOne(optional = false, targetEntity = PatientInfo.class,fetch=FetchType.LAZY)
	@JoinColumn(name = "patient_id", referencedColumnName = "id")*/
	@Column(name = "patient_id")
	private String patient;

	@Column(name="createdTime")
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdTime = DateTime.now();
	
	@Column(name="isArchive")
	private boolean isArchive;
	
	@Column(name="isActive")
	private boolean isActive;
	
	
	public String getPatient() {
		return patient;
	}

	public void setPatient(String patient) {
		this.patient = patient;
	}

	public DateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(DateTime createdTime) {
		this.createdTime = createdTime;
	}

	public boolean isArchive() {
		return isArchive;
	}

	public void setArchive(boolean isArchive) {
		this.isArchive = isArchive;
	}	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public PatientMedicationAssoc() {
	}

	public Long getMedicationRecordingsId() {
		return medicationRecordingsId;
	}

	public void setMedicationRecordingsId(Long medicationRecordingsId) {
		this.medicationRecordingsId = medicationRecordingsId;
	}

	@Override
	public String toString() {
		return "PatientMedicationAssoc [id=" + id + ", medicationRecordingsId=" + medicationRecordingsId + ", patient="
				+ patient + ", createdTime=" + createdTime + ", isArchive=" + isArchive + ", isActive=" + isActive
				+ "]";
	}

	public PatientMedicationAssoc(Long medicationRecordingsId, String patient, DateTime createdTime, boolean isArchive,
			boolean isActive) {
		super();
		this.medicationRecordingsId = medicationRecordingsId;
		this.patient = patient;
		this.createdTime = createdTime;
		this.isArchive = isArchive;
		this.isActive = isActive;
	}		
}