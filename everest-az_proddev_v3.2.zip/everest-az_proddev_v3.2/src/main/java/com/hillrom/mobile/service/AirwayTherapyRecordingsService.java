package com.hillrom.mobile.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.mobile.domain.AirwayTherapyRecordings;
import com.hillrom.mobile.dto.AirwayTherapyDataDTO;
import com.hillrom.mobile.dto.AirwayTherapyRecordingsDTO;
import com.hillrom.mobile.dto.RetrieveAirwayTherapyDTO;
import com.hillrom.mobile.dto.RetrieveAllAirwayTherapyDTO;
import com.hillrom.mobile.repository.AirwayTherapyRecordingsRepository;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;
@Service
@Transactional
public class AirwayTherapyRecordingsService {
	
	@Inject
	public AirwayTherapyRecordingsRepository airwayTherapyRecordingsRepository;
	@Inject
	public PatientInfoRepository patientInfoRepository;

	public JSONObject createAirwayTherapy(AirwayTherapyRecordingsDTO airwayTherapyRecording) {
		
		JSONObject jsonObject = new JSONObject();
		Boolean isValidDateTime = DateUtil.isDateTimeWithin90Days(airwayTherapyRecording.getDateTime());
		if (!isValidDateTime) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		PatientInfo patientInfo = patientInfoRepository.findOneById(airwayTherapyRecording.getPid());
		if (Objects.isNull(patientInfo)) {
			jsonObject.put("message", ExceptionConstants.HR_915);
			return jsonObject;
		}
		
		AirwayTherapyRecordings airway = new AirwayTherapyRecordings();
		List<AirwayTherapyRecordings> airw = airwayTherapyRecordingsRepository.findByDateTimeAndName(
				airwayTherapyRecording.getPid(), airwayTherapyRecording.getDateTime(), airwayTherapyRecording.getName());

		if (airw.isEmpty()) {
			airway.setDateTime(airwayTherapyRecording.getDateTime());
			airway.setPid(airwayTherapyRecording.getPid());
			airway.setDuration(airwayTherapyRecording.getDuration());
			airway.setName(airwayTherapyRecording.getName());
			airwayTherapyRecordingsRepository.save(airway);
			jsonObject.put("therapyId", airway.getId());
		} else {
			jsonObject.put("message", "AIR_THERAPY_ADD_FAIL");
		}
		return jsonObject;
	}

	public JSONObject updateAirwayTherapy(AirwayTherapyRecordingsDTO airwayTherapyRecording) {
		
		JSONObject jsonObject = new JSONObject();
		Boolean isValidDateTime = DateUtil.isDateTimeWithin90Days(airwayTherapyRecording.getDateTime());
		if (!isValidDateTime) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		Long id = airwayTherapyRecording.getTid();
		AirwayTherapyRecordings airwayTherapyRecordingup = airwayTherapyRecordingsRepository.findOne(id);
		if (airwayTherapyRecordingup != null) {
			airwayTherapyRecordingup.setDuration(airwayTherapyRecording.getDuration());
			airwayTherapyRecordingup.setPid(airwayTherapyRecording.getPid());
			airwayTherapyRecordingup.setDateTime(airwayTherapyRecording.getDateTime());
			airwayTherapyRecordingup.setId(airwayTherapyRecording.getTid());
			airwayTherapyRecordingup.setName(airwayTherapyRecording.getName());
			airwayTherapyRecordingsRepository.save(airwayTherapyRecordingup);
			jsonObject.put("message : ", "AIR_THERAPY_UPDATED_SUCCESSFULLY");
		} else {
			jsonObject.put("message", "AIR_THERAPY_UPDATE_FAIL");
		}

		return jsonObject;
	}

	public RetrieveAllAirwayTherapyDTO getAllAirwayTherapy(String pid, int page, int size) throws Exception {
		RetrieveAllAirwayTherapyDTO retrieveAllAirwayTherapyDTO = new RetrieveAllAirwayTherapyDTO();
		Long count = airwayTherapyRecordingsRepository.countByPid(pid);
		int totalPage = 1;
		
		if(count > size)
		{
			totalPage = count.intValue()/size;
			if((count.intValue()%size)>0) totalPage++;
		}
		
		if(page > totalPage)
		{
			throw new Exception("Page out of bounds");
		}
		
		List<AirwayTherapyRecordings> results = airwayTherapyRecordingsRepository.findByPid(pid, new PageRequest(page-1, size, Sort.Direction.DESC, "id"));
	    List<AirwayTherapyDataDTO> airwayList = new ArrayList<AirwayTherapyDataDTO>();
		for (AirwayTherapyRecordings airwayTherapyRecording : results) {
				AirwayTherapyDataDTO airwayTherapyDataDTO = new AirwayTherapyDataDTO();
				airwayTherapyDataDTO.setTid(airwayTherapyRecording.getId());
				airwayTherapyDataDTO.setName(airwayTherapyRecording.getName());
				airwayTherapyDataDTO.setDuration(airwayTherapyRecording.getDuration());
				airwayTherapyDataDTO.setDateTime(airwayTherapyRecording.getDateTime());
				airwayList.add(airwayTherapyDataDTO);
			}
		if(Objects.nonNull(airwayList)){
			retrieveAllAirwayTherapyDTO.setData(airwayList);
			if(page+1 <=totalPage)
			{
				retrieveAllAirwayTherapyDTO.setNextURL("?page="+(page+1)+"&size="+size);
			}
		}			
		
		return retrieveAllAirwayTherapyDTO;
	}
	
	public RetrieveAirwayTherapyDTO getAirwayTherapy(String pid, Long startDate,
			Long endDate) {
		RetrieveAirwayTherapyDTO retrieveAirwayTherapyDTO = new RetrieveAirwayTherapyDTO();
		List<AirwayTherapyRecordings> results = null;
		if(pid != null && startDate != null
				&& endDate != null){
			results = airwayTherapyRecordingsRepository.findByPatientIdAndDateRange(pid,startDate,endDate);

		}else if(pid != null && startDate != null){
			results = airwayTherapyRecordingsRepository.findByPatientIdAndStartDate(pid,startDate);
		}else if(pid != null && endDate != null){
			results = airwayTherapyRecordingsRepository.findByPatientIdAndEndDate(pid,endDate);
		}
		else
		{
			results = airwayTherapyRecordingsRepository.findByPatientId(pid);
		}
	    List<AirwayTherapyDataDTO> airwayList = new ArrayList<AirwayTherapyDataDTO>();
		for (AirwayTherapyRecordings airwayTherapyRecording : results) {
				AirwayTherapyDataDTO airwayTherapyDataDTO = new AirwayTherapyDataDTO();
				airwayTherapyDataDTO.setTid(airwayTherapyRecording.getId());
				airwayTherapyDataDTO.setName(airwayTherapyRecording.getName());
				airwayTherapyDataDTO.setDuration(airwayTherapyRecording.getDuration());
				airwayTherapyDataDTO.setDateTime(airwayTherapyRecording.getDateTime());
				airwayList.add(airwayTherapyDataDTO);
			}
		if(Objects.nonNull(airwayList)){
			retrieveAirwayTherapyDTO.setData(airwayList);
		}
		
		return retrieveAirwayTherapyDTO;
	}

	public JSONObject deleteAirwayTherapy(AirwayTherapyRecordingsDTO airwayTherapyRecordings) {
		JSONObject jsonObject = new JSONObject();
		AirwayTherapyRecordings airwayTherapyRecordingsData=airwayTherapyRecordingsRepository.findOne(airwayTherapyRecordings.getTid());
		 if(Objects.nonNull(airwayTherapyRecordingsData)){
			 
			 airwayTherapyRecordingsRepository.delete(airwayTherapyRecordings.getTid());
			jsonObject.put("message", "AIR_THERAPY_REMOVE_SUCCESS"); 
		 }else{
			 jsonObject.put("message", "Therapy Id is not associated"); 
		 }
		
		
		return jsonObject;
	}

}
