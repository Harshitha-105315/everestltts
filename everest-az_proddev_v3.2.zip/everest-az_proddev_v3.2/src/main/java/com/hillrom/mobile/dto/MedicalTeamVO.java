package com.hillrom.mobile.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class MedicalTeamVO {
	@JsonIgnore
	private String clinicId;
	@ApiModelProperty(notes="clinicName (String)", dataType="java.lang.String", required=true)
	private String clinicName;
	@ApiModelProperty(notes="clinicAddress (String)", dataType="java.lang.String", required=true)
	private String clinicAddress;
	@ApiModelProperty(notes="clinicPhoneNumber (String)", dataType="java.lang.String", required=true)
	private String clinicPhoneNumber;
	@ApiModelProperty(notes="clinicAdminList", required=true)
	private List<ClinicAdminVO> clinicAdminList;
	@ApiModelProperty(notes="hcpList", required=true)
	private List<HcpDetailsVO> hcpList;
	
	public String getClinicId() {
		return clinicId;
	}
	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getClinicAddress() {
		return clinicAddress;
	}
	public void setClinicAddress(String clinicAddress) {
		this.clinicAddress = clinicAddress;
	}
	public String getClinicPhoneNumber() {
		return clinicPhoneNumber;
	}
	public void setClinicPhoneNumber(String clinicPhoneNumber) {
		this.clinicPhoneNumber = clinicPhoneNumber;
	}
	public List<ClinicAdminVO> getClinicAdminList() {
		return clinicAdminList;
	}
	public void setClinicAdminList(List<ClinicAdminVO> clinicAdminList) {
		this.clinicAdminList = clinicAdminList;
	}
	public List<HcpDetailsVO> getHcpList() {
		return hcpList;
	}
	public void setHcpList(List<HcpDetailsVO> hcpList) {
		this.hcpList = hcpList;
	}
	public MedicalTeamVO(String clinicId, String clinicName, String clinicAddress, String clinicPhoneNumber,
			List<ClinicAdminVO> clinicAdminList, List<HcpDetailsVO> hcpList) {
		super();
		this.clinicId = clinicId;
		this.clinicName = clinicName;
		this.clinicAddress = clinicAddress;
		this.clinicPhoneNumber = clinicPhoneNumber;
		this.clinicAdminList = clinicAdminList;
		this.hcpList = hcpList;
	}
	public MedicalTeamVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "MedicalTeamVO [clinicId=" + clinicId + ", clinicName=" + clinicName + ", clinicAddress=" + clinicAddress
				+ ", clinicPhoneNumber=" + clinicPhoneNumber + ", clinicAdminList=" + clinicAdminList + ", hcpList="+ hcpList + "]";
	}
}
