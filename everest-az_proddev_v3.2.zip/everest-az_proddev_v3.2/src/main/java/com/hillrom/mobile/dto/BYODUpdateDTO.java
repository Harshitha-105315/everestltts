package com.hillrom.mobile.dto;

import java.util.List;

/**
 * @author kaliapr1
 *
 */
public class BYODUpdateDTO {
	private Boolean dnd;
	private String phoneIdentifier;
	List<BYODUpdateDeviceInfo> deviceInfo;
	/**
	 * @return the dnd
	 */
	public Boolean getDnd() {
		return dnd;
	}
	/**
	 * @param dnd the dnd to set
	 */
	public void setDnd(Boolean dnd) {
		this.dnd = dnd;
	}
	/**
	 * @return the phoneIdentifier
	 */
	public String getPhoneIdentifier() {
		return phoneIdentifier;
	}
	/**
	 * @param phoneIdentifier the phoneIdentifier to set
	 */
	public void setPhoneIdentifier(String phoneIdentifier) {
		this.phoneIdentifier = phoneIdentifier;
	}
	/**
	 * @return the deviceInfo
	 */
	public List<BYODUpdateDeviceInfo> getDeviceInfo() {
		return deviceInfo;
	}
	/**
	 * @param deviceInfo the deviceInfo to set
	 */
	public void setDeviceInfo(List<BYODUpdateDeviceInfo> deviceInfo) {
		this.deviceInfo = deviceInfo;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deviceInfo == null) ? 0 : deviceInfo.hashCode());
		result = prime * result + ((dnd == null) ? 0 : dnd.hashCode());
		result = prime * result + ((phoneIdentifier == null) ? 0 : phoneIdentifier.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BYODUpdateDTO other = (BYODUpdateDTO) obj;
		if (deviceInfo == null) {
			if (other.deviceInfo != null)
				return false;
		} else if (!deviceInfo.equals(other.deviceInfo))
			return false;
		if (dnd == null) {
			if (other.dnd != null)
				return false;
		} else if (!dnd.equals(other.dnd))
			return false;
		if (phoneIdentifier == null) {
			if (other.phoneIdentifier != null)
				return false;
		} else if (!phoneIdentifier.equals(other.phoneIdentifier))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BYODUpdateDTO [dnd=" + dnd + ", phoneIdentifier=" + phoneIdentifier + ", deviceInfo=" + deviceInfo
				+ "]";
	}
	public BYODUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
