package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "activityId", "caloriesTargetIntake", "goalEndDate", "name" })
@ApiModel(value = "NutritionActivityDTO", description = "NutritionActivity Log Info")

public class NutritionActivityDTO {

	@JsonProperty("pid")
	@ApiModelProperty(value = "Patient ID", required = true)
	private String pid;
	
	@JsonProperty("activityId")
	@ApiModelProperty(value = "Activity Id", required = true)
	private Long activityId;
	
	@JsonProperty("caloriesTargetIntake")
	@ApiModelProperty(value = "CaloriesTargetIntake", required = true)
	private Long caloriesTargetIntake;

	@JsonProperty("goalStartDate")
	@ApiModelProperty(value = "GoalStartDate", required = false)
	private Long goalStartDate;
	
	@JsonProperty("goalEndDate")
	@ApiModelProperty(value = "GoalEndDate", required = true)
	private Long goalEndDate;
	
	@JsonProperty("name")
	@ApiModelProperty(value = "Goal Name", required = true)
	private String name;

	@JsonProperty("activityId")
	public Long getActivityId() {
		return activityId;
	}

	@JsonProperty("activityId")
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	@JsonProperty("caloriesTargetIntake")
	public Long getCaloriesTargetIntake() {
		return caloriesTargetIntake;
	}

	@JsonProperty("caloriesTargetIntake")
	public void setCaloriesTargetIntake(Long caloriesTargetIntake) {
		this.caloriesTargetIntake = caloriesTargetIntake;
	}

	@JsonProperty("goalEndDate")
	public Long getGoalEndDate() {
		return goalEndDate;
	}

	@JsonProperty("goalEndDate")
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}

	@JsonProperty("goalStartDate")
	public Long getGoalStartDate() {
		return goalStartDate;
	}

	@JsonProperty("goalStartDate")
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	
	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;

	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}
}
