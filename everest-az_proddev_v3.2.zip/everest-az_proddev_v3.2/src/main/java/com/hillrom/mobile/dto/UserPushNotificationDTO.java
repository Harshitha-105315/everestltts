package com.hillrom.mobile.dto;
 public class UserPushNotificationDTO {
 	private String pid;
	private String device_UUID;
	private String category;
	private String type;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	
	public String getDevice_UUID() {
		return device_UUID;
	}
	public void setDevice_UUID(String device_UUID) {
		this.device_UUID = device_UUID;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public UserPushNotificationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserPushNotificationDTO [pid=" + pid + ", device_UUID=" + device_UUID + ", category=" + category + ", type=" + type
				+ "]";
	}

}