package com.hillrom.mobile.dto;

import java.util.HashMap;
import java.util.Map;

public class ProfileSupportVO {

	private String customerServiceNo;
	private String technicalSupportNumber;
	private Map<String, String> userManualUrl = new HashMap<>();
	private String supportEmail;
	private String privacyPolicy;

	
	public String getSupportEmail() {
		return supportEmail;
	}
	public void setSupportEmail(String supportEmail) {
		this.supportEmail = supportEmail;
	}
	public String getPrivacyPolicy() {
		return privacyPolicy;
	}
	public void setPrivacyPolicy(String privacyPolicy) {
		this.privacyPolicy = privacyPolicy;
	}
	public String getCustomerServiceNo() {
		return customerServiceNo;
	}
	public void setCustomerServiceNo(String customerServiceNo) {
		this.customerServiceNo = customerServiceNo;
	}
	public String getTechnicalSupportNumber() {
		return technicalSupportNumber;
	}
	public void setTechnicalSupportNumber(String technicalSupportNumber) {
		this.technicalSupportNumber = technicalSupportNumber;
	}
	public Map<String, String> getUserManualUrl() {
		return userManualUrl;
	}
	public void setUserManualUrl(Map<String, String> userManualUrl) {
		this.userManualUrl = userManualUrl;
	}

}