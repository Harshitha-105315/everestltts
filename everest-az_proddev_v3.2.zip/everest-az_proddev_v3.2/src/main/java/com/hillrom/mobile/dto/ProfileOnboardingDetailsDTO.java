package com.hillrom.mobile.dto;

public class ProfileOnboardingDetailsDTO {
	
	private Long userId;
	private String device_token;
	private String device_UUID;
	private String device_type;
	private Boolean authentication_type;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getDevice_token() {
		return device_token;
	}
	public void setDevice_token(String device_token) {
		this.device_token = device_token;
	}
	public String getDevice_UUID() {
		return device_UUID;
	}
	public void setDevice_UUID(String device_UUID) {
		this.device_UUID = device_UUID;
	}
	public String getDevice_type() {
		return device_type;
	}
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	public Boolean isAuthentication_type() {
		return authentication_type;
	}
	public void setAuthentication_type(Boolean authentication_type) {
		this.authentication_type = authentication_type;
	}
}