package com.hillrom.mobile.domain;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 * A PATIENT_BADGES_HISTORY.
 */
@Entity
@Table(name = "PATIENT_BADGES_HISTORY")
public class PatientBadgesHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "BADGES_MASTER_ID")
    //@ManyToMany(targetEntity=BadgesMaster.class,fetch=FetchType.LAZY)
    @JoinColumn(name = "ID", nullable = false)
    private Long badgesMasterId;

    @Column(name = "PATIENT_ID")
    //@OneToMany(targetEntity=PatientInfo.class,fetch=FetchType.LAZY)
    @JoinColumn(name = "ID", nullable = false)
    private String patientId;

    @Column(name = "BADGE_RECEIVED_DATE")
    /*@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")*/
    private Long badgeReceivedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getBadgesMasterId() {
		return badgesMasterId;
	}

	public void setBadgesMasterId(Long badgesMasterId) {
		this.badgesMasterId = badgesMasterId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Long getBadgeReceivedDate() {
		return badgeReceivedDate;
	}

	public void setBadgeReceivedDate(Long badgeReceivedDate) {
		this.badgeReceivedDate = badgeReceivedDate;
	}

}
