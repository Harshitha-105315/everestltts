package com.hillrom.mobile.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hillrom.mobile.domain.MedicationsRecordings;

public interface MedicationsRecordingsRepository extends
		JpaRepository<MedicationsRecordings, String> {

	@Query("from MedicationsRecordings ppd where ppd.name = ?1 ")
	List<MedicationsRecordings> findByPatientId(String name);

	MedicationsRecordings findOneById(Long id);
	
	@Query("from MedicationsRecordings mr where mr.id = ?1 and mr.medicationTimeReminderFlag=1")
	MedicationsRecordings findActiveMedicationsByPatientId(Long id);

	@Query(nativeQuery=true,value=" SELECT COUNT(*) FROM PATIENT_MEDICATION_ASSOC pma "
			+ "JOIN MEDICATIONS_RECORDINGS mr on pma.medication_recordings_id = mr.id "
			+ "where pma.patient_id = :patientId and mr.medication_type_id = :medType and mr.name = :medName ")
	Long getMedicationCount(@Param("patientId")String patientId,
			@Param("medType")String medType, 
			@Param("medName")String medName);
	
	@Query(nativeQuery=true,value=" SELECT pma.id FROM PATIENT_MEDICATION_ASSOC pma "
			+ "JOIN MEDICATIONS_RECORDINGS mr on pma.medication_recordings_id = mr.id "
			+ "where pma.patient_id = :patientId and mr.medication_type_id = :medType and mr.name = :medName ")
	List<BigInteger> getMedicationIdList(@Param("patientId")String patientId,
			@Param("medType")String medType, 
			@Param("medName")String medName);
}
