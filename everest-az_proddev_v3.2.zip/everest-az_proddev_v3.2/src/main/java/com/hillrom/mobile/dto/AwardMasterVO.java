package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hillrom.mobile.domain.AwardMaster;

public class AwardMasterVO {

    private Long id;
    @JsonIgnore
    private Long activityTypeId;
    private String awardName;
    @JsonIgnore
    private String awardMetMinValue;
    @JsonIgnore
    private String awardMetMaxValue;
    private String awardDescription;
    private String thumbnail;
    private String image;
    private String thumbnail_achieved;
    private String image_achieved;
    private String activityType;
       public Long getId() {
              return id;
       }
       public void setId(Long id) {
              this.id = id;
       }
       public Long getActivityTypeId() {
              return activityTypeId;
       }
       public void setActivityTypeId(Long activityTypeId) {
              this.activityTypeId = activityTypeId;
       }
       public String getAwardName() {
              return awardName;
       }
       public void setAwardName(String awardName) {
              this.awardName = awardName;
       }
       public String getAwardMetMinValue() {
              return awardMetMinValue;
       }
       public void setAwardMetMinValue(String awardMetMinValue) {
              this.awardMetMinValue = awardMetMinValue;
       }
       public String getAwardMetMaxValue() {
              return awardMetMaxValue;
       }
       public void setAwardMetMaxValue(String awardMetMaxValue) {
              this.awardMetMaxValue = awardMetMaxValue;
       }
       public String getAwardDescription() {
              return awardDescription;
       }
       public void setAwardDescription(String awardDescription) {
              this.awardDescription = awardDescription;
       }
       public String getThumbnail() {
              return thumbnail;
       }
       public void setThumbnail(String thumbnail) {
              this.thumbnail = thumbnail;
       }
       public String getImage() {
              return image;
       }
       public void setImage(String image) {
              this.image = image;
       }
       public String getThumbnail_achieved() {
              return thumbnail_achieved;
       }
       public void setThumbnail_achieved(String thumbnail_achieved) {
              this.thumbnail_achieved = thumbnail_achieved;
       }
       public String getImage_achieved() {
              return image_achieved;
       }
       public void setImage_achieved(String image_achieved) {
              this.image_achieved = image_achieved;
       }
      
       public String getActivityType() {
		return activityType;
	}
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
	public AwardMasterVO(Long id, Long activityTypeId, String awardName, String awardMetMinValue,
                     String awardMetMaxValue, String awardDescription, String thumbnail, String image, String thumbnail_achieved,
                     String image_achieved, String activityType) {
              super();
              this.id = id;
              this.activityTypeId = activityTypeId;
              this.awardName = awardName;
              this.awardMetMinValue = awardMetMinValue;
              this.awardMetMaxValue = awardMetMaxValue;
              this.awardDescription = awardDescription;
              this.thumbnail = thumbnail;
              this.image = image;
              this.thumbnail_achieved = thumbnail_achieved;
              this.image_achieved = image_achieved;
              this.activityType = activityType;
       }
       
       public AwardMasterVO(AwardMaster am) {
              this.id = am.getId();
              this.activityTypeId = am.getActivityTypeId();
              this.awardName = am.getAwardName();
              this.awardMetMinValue = am.getAwardMetMinValue();
              this.awardMetMaxValue = am.getAwardMetMaxValue();
              this.awardDescription = am.getAwardDescription();
              this.thumbnail = am.getThumbnail();
              this.image = am.getImage();
              this.thumbnail_achieved = am.getThumbnail_achieved();
              this.image_achieved = am.getImage_achieved();
              
       }
    
    
}