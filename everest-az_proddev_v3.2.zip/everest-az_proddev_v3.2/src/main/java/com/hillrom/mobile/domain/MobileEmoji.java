package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "MOBILE_EMOJI")
public class MobileEmoji {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(name = "id")
	    @ApiModelProperty(notes="id of emoji", dataType="java.lang.Long", required=true)
	    private Long id;
 	    @Column(name = "emoji_name")
	    @ApiModelProperty(notes="emoji Name", dataType="java.lang.Long", required=true)
	    private String emojiName;
 		public Long getId() {
			return id;
		}
 		public void setId(Long id) {
			this.id = id;
		}
 		public String getEmojiName() {
			return emojiName;
		}
 		public void setEmojiName(String emojiName) {
			this.emojiName = emojiName;
		}
 		@Override
		public String toString() {
			return "MobileEmoji [id=" + id + ", emojiName=" + emojiName + "]";
		}    
 }