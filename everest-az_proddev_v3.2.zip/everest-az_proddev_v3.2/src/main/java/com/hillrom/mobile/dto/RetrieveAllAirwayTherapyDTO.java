package com.hillrom.mobile.dto;

import java.util.List;

public class RetrieveAllAirwayTherapyDTO {
	List<AirwayTherapyDataDTO> data;
	String nextURL;
	public List<AirwayTherapyDataDTO> getData() {
		return data;
	}
	public void setData(List<AirwayTherapyDataDTO> data) {
		this.data = data;
	}
	public String getNextURL() {
		return nextURL;
	}
	public void setNextURL(String nextURL) {
		this.nextURL = nextURL;
	}	
}
