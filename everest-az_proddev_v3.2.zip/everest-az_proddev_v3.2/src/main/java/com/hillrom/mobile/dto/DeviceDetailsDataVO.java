package com.hillrom.mobile.dto;

import java.util.List;
import io.swagger.annotations.ApiModelProperty;

public class DeviceDetailsDataVO {

	@ApiModelProperty(notes="deviceName (String)", dataType="java.lang.String", required=true)
	private String deviceName;
	@ApiModelProperty(notes="deviceType (String)", dataType="java.lang.String", required=true)
	private String deviceType;
	@ApiModelProperty(notes="serialNumber (String)", dataType="java.lang.String", required=true)
	private String serialNumber;
	@ApiModelProperty(notes="deviceColor (String)", dataType="java.lang.String", required=true)
	private String deviceColor;
	@ApiModelProperty(notes="deviceSize (String)", dataType="java.lang.String", required=true)
	private String deviceSize;
	@ApiModelProperty(notes="garment type (String)", dataType="java.lang.String", required=true)
	private String garmentType;
	@ApiModelProperty(notes="isManual (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean isManual;
	@ApiModelProperty(notes="isActive (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean isActive;
	private String deviceAddress;
	
	private Boolean isByod;
	
	private Boolean isDnd;
	
	private String dndDeviceIdentifier;
	
	private String byodState;

	private BYODPairInfo pairInfo;
	
	private BYODOptOutInfo optOutInfo;

	private List<ProtocolDataListVO> protocolData;
	/**
	 * @return the deviceName
	 */
	public String getDeviceName() {
		return deviceName;
	}
	/**
	 * @param deviceName the deviceName to set
	 */
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
		return deviceType;
	}
	/**
	 * @param deviceType the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the deviceColor
	 */
	public String getDeviceColor() {
		return deviceColor;
	}
	/**
	 * @param deviceColor the deviceColor to set
	 */
	public void setDeviceColor(String deviceColor) {
		this.deviceColor = deviceColor;
	}
	/**
	 * @return the deviceSize
	 */
	public String getDeviceSize() {
		return deviceSize;
	}
	/**
	 * @param deviceSize the deviceSize to set
	 */
	public void setDeviceSize(String deviceSize) {
		this.deviceSize = deviceSize;
	}
	/**
	 * @return the garmentType
	 */
	public String getGarmentType() {
		return garmentType;
	}
	/**
	 * @param garmentType the garmentType to set
	 */
	public void setGarmentType(String garmentType) {
		this.garmentType = garmentType;
	}
	/**
	 * @return the isManual
	 */
	public Boolean getIsManual() {
		return isManual;
	}
	/**
	 * @param isManual the isManual to set
	 */
	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}
	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the protocolData
	 */
	public List<ProtocolDataListVO> getProtocolData() {
		return protocolData;
	}
	/**
	 * @param protocolData the protocolData to set
	 */
	public void setProtocolData(List<ProtocolDataListVO> protocolData) {
		this.protocolData = protocolData;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
	 * @return the deviceAddress
	 */
	public String getDeviceAddress() {
		return deviceAddress;
	}
	/**
	 * @param deviceAddress the deviceAddress to set
	 */
	public void setDeviceAddress(String deviceAddress) {
		this.deviceAddress = deviceAddress;
	}
	/**
	 * @return the isByod
	 */
	public Boolean getIsByod() {
		return isByod;
	}
	/**
	 * @param isByod the isByod to set
	 */
	public void setIsByod(Boolean isByod) {
		this.isByod = isByod;
	}
	/**
	 * @return the isDnd
	 */
	public Boolean getIsDnd() {
		return isDnd;
	}
	/**
	 * @param isDnd the isDnd to set
	 */
	public void setIsDnd(Boolean isDnd) {
		this.isDnd = isDnd;
	}
	/**
	 * @return the dndDeviceIdentifier
	 */
	public String getDndDeviceIdentifier() {
		return dndDeviceIdentifier;
	}
	/**
	 * @param dndDeviceIdentifier the dndDeviceIdentifier to set
	 */
	public void setDndDeviceIdentifier(String dndDeviceIdentifier) {
		this.dndDeviceIdentifier = dndDeviceIdentifier;
	}
	/**
	 * @return the byodState
	 */
	public String getByodState() {
		return byodState;
	}
	/**
	 * @param byodState the byodState to set
	 */
	public void setByodState(String byodState) {
		this.byodState = byodState;
	}
	/**
	 * @return the pairInfo
	 */
	public BYODPairInfo getPairInfo() {
		return pairInfo;
	}
	/**
	 * @param pairInfo the pairInfo to set
	 */
	public void setPairInfo(BYODPairInfo pairInfo) {
		this.pairInfo = pairInfo;
	}
	/**
	 * @return the optOutInfo
	 */
	public BYODOptOutInfo getOptOutInfo() {
		return optOutInfo;
	}
	/**
	 * @param optOutInfo the optOutInfo to set
	 */
	public void setOptOutInfo(BYODOptOutInfo optOutInfo) {
		this.optOutInfo = optOutInfo;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((byodState == null) ? 0 : byodState.hashCode());
		result = prime * result + ((deviceAddress == null) ? 0 : deviceAddress.hashCode());
		result = prime * result + ((deviceColor == null) ? 0 : deviceColor.hashCode());
		result = prime * result + ((deviceName == null) ? 0 : deviceName.hashCode());
		result = prime * result + ((deviceSize == null) ? 0 : deviceSize.hashCode());
		result = prime * result + ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + ((dndDeviceIdentifier == null) ? 0 : dndDeviceIdentifier.hashCode());
		result = prime * result + ((garmentType == null) ? 0 : garmentType.hashCode());
		result = prime * result + ((isActive == null) ? 0 : isActive.hashCode());
		result = prime * result + ((isByod == null) ? 0 : isByod.hashCode());
		result = prime * result + ((isDnd == null) ? 0 : isDnd.hashCode());
		result = prime * result + ((isManual == null) ? 0 : isManual.hashCode());
		result = prime * result + ((optOutInfo == null) ? 0 : optOutInfo.hashCode());
		result = prime * result + ((pairInfo == null) ? 0 : pairInfo.hashCode());
		result = prime * result + ((protocolData == null) ? 0 : protocolData.hashCode());
		result = prime * result + ((serialNumber == null) ? 0 : serialNumber.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DeviceDetailsDataVO other = (DeviceDetailsDataVO) obj;
		if (byodState == null) {
			if (other.byodState != null)
				return false;
		} else if (!byodState.equals(other.byodState))
			return false;
		if (deviceAddress == null) {
			if (other.deviceAddress != null)
				return false;
		} else if (!deviceAddress.equals(other.deviceAddress))
			return false;
		if (deviceColor == null) {
			if (other.deviceColor != null)
				return false;
		} else if (!deviceColor.equals(other.deviceColor))
			return false;
		if (deviceName == null) {
			if (other.deviceName != null)
				return false;
		} else if (!deviceName.equals(other.deviceName))
			return false;
		if (deviceSize == null) {
			if (other.deviceSize != null)
				return false;
		} else if (!deviceSize.equals(other.deviceSize))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (dndDeviceIdentifier == null) {
			if (other.dndDeviceIdentifier != null)
				return false;
		} else if (!dndDeviceIdentifier.equals(other.dndDeviceIdentifier))
			return false;
		if (garmentType == null) {
			if (other.garmentType != null)
				return false;
		} else if (!garmentType.equals(other.garmentType))
			return false;
		if (isActive == null) {
			if (other.isActive != null)
				return false;
		} else if (!isActive.equals(other.isActive))
			return false;
		if (isByod == null) {
			if (other.isByod != null)
				return false;
		} else if (!isByod.equals(other.isByod))
			return false;
		if (isDnd == null) {
			if (other.isDnd != null)
				return false;
		} else if (!isDnd.equals(other.isDnd))
			return false;
		if (isManual == null) {
			if (other.isManual != null)
				return false;
		} else if (!isManual.equals(other.isManual))
			return false;
		if (optOutInfo == null) {
			if (other.optOutInfo != null)
				return false;
		} else if (!optOutInfo.equals(other.optOutInfo))
			return false;
		if (pairInfo == null) {
			if (other.pairInfo != null)
				return false;
		} else if (!pairInfo.equals(other.pairInfo))
			return false;
		if (protocolData == null) {
			if (other.protocolData != null)
				return false;
		} else if (!protocolData.equals(other.protocolData))
			return false;
		if (serialNumber == null) {
			if (other.serialNumber != null)
				return false;
		} else if (!serialNumber.equals(other.serialNumber))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DeviceDetailsDataVO [deviceName=" + deviceName + ", deviceType=" + deviceType + ", serialNumber="
				+ serialNumber + ", deviceColor=" + deviceColor + ", deviceSize=" + deviceSize + ", garmentType="
				+ garmentType + ", isManual=" + isManual + ", isActive=" + isActive + ", deviceAddress=" + deviceAddress
				+ ", isByod=" + isByod + ", isDnd=" + isDnd + ", dndDeviceIdentifier=" + dndDeviceIdentifier
				+ ", byodState=" + byodState + ", pairInfo=" + pairInfo + ", optOutInfo=" + optOutInfo
				+ ", protocolData=" + protocolData + "]";
	}
	public DeviceDetailsDataVO() {
		super();
		// TODO Auto-generated constructor stub
	}}
