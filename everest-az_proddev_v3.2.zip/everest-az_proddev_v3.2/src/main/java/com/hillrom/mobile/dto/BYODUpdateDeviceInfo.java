package com.hillrom.mobile.dto;

public class BYODUpdateDeviceInfo {
	private String deviceType;
	private String serialNo;
	private String byodState;
	private String reason;
	private String feedback;
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
		return deviceType;
	}
	/**
	 * @param deviceType the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	/**
	 * @return the serialNo
	 */
	public String getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the byodState
	 */
	public String getByodState() {
		return byodState;
	}
	/**
	 * @param byodState the byodState to set
	 */
	public void setByodState(String byodState) {
		this.byodState = byodState;
	}
	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}
	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 * @return the feedback
	 */
	public String getFeedback() {
		return feedback;
	}
	/**
	 * @param feedback the feedback to set
	 */
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((byodState == null) ? 0 : byodState.hashCode());
		result = prime * result + ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + ((feedback == null) ? 0 : feedback.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + ((serialNo == null) ? 0 : serialNo.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BYODUpdateDeviceInfo other = (BYODUpdateDeviceInfo) obj;
		if (byodState == null) {
			if (other.byodState != null)
				return false;
		} else if (!byodState.equals(other.byodState))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (feedback == null) {
			if (other.feedback != null)
				return false;
		} else if (!feedback.equals(other.feedback))
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (serialNo == null) {
			if (other.serialNo != null)
				return false;
		} else if (!serialNo.equals(other.serialNo))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BYODUpdateDeviceInfo [deviceType=" + deviceType + ", serialNo=" + serialNo + ", byodState=" + byodState
				+ ", reason=" + reason + ", feedback=" + feedback + "]";
	}
	public BYODUpdateDeviceInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BYODUpdateDeviceInfo(String deviceType, String serialNo, String byodState, String reason, String feedback) {
		super();
		this.deviceType = deviceType;
		this.serialNo = serialNo;
		this.byodState = byodState;
		this.reason = reason;
		this.feedback = feedback;
	}
	
	
}
