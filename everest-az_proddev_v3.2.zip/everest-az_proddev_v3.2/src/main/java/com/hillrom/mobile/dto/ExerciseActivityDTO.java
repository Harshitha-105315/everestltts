package com.hillrom.mobile.dto;

import java.util.List;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "ExerciseActivityDTO", description = "Exercise Log Info")
public class ExerciseActivityDTO {
	
	@ApiModelProperty(value = "Patient Info", required = true)
	private String pid;
	
	@ApiModelProperty(value = "ActivityId", required = true)
	private Long activityId;
	
	@ApiModelProperty(value = "ExerciseDays", required = true)
	private List<String> exerciseDays;
	
	@ApiModelProperty(value = "ExerciseDuration", required = true)
	private Long exerciseDuration;

	@ApiModelProperty(value = "GoalStartDate", required = true)
	private Long goalStartDate;
	
	@ApiModelProperty(value = "GoalEndDate", required = true)
	private Long goalEndDate;
	
	@ApiModelProperty(value = "GoalName", required = true)
	private String name;
	
	@ApiModelProperty(value = "ExtendedInfoDTO", required = true)
	private String extendedInfoDTO;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public List<String> getExerciseDays() {
		return exerciseDays;
	}
	public void setExerciseDays(List<String> exerciseDays) {
		this.exerciseDays = exerciseDays;
	}
	public Long getExerciseDuration() {
		return exerciseDuration;
	}
	public void setExerciseDuration(Long exerciseDuration) {
		this.exerciseDuration = exerciseDuration;
	}
	public Long getGoalEndDate() {
		return goalEndDate;
	}
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}
	
	public Long getGoalStartDate() {
		return goalStartDate;
	}
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExtendedInfoDTO() {
		return extendedInfoDTO;
	}
	public void setExtendedInfoDTO(String extendedInfoDTO) {
		this.extendedInfoDTO = extendedInfoDTO;
	}
	
	
}
