package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

/**
 * USER_PUSH_NOTIFICATIONS.
 */
@Entity
@Table(name = "USER_PUSH_NOTIFICATIONS")
public class UserPushNotification {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    @ApiModelProperty(notes="ID of push Notification", dataType="java.lang.Long", required=true)
    private Long id;

	@JsonIgnore
    @Column(name = "notification_id" )
    private Long notificationId ;

    @Column(name = "sent_date")
    @ApiModelProperty(notes="sent date", required=true)
    private Long sentDate;
    
    @Column(name = "is_read")
    private Boolean isRead;

    @Column(name = "read_date")
    private Long read_date;

    @JsonIgnore
    @Column(name = "is_deleted")
    @ApiModelProperty(notes="isDeleted", required=true)
    private Boolean isDeleted;

    @JsonIgnore
    @Column(name = "mobile_info_id")
    @ApiModelProperty(notes="mobileIinfoId", required=true)
    private Long mobileIinfoId;

    @Column(name = "message")
    @ApiModelProperty(notes="message", required=true)
    private String message;

    @JsonIgnore
    @Column(name = "lang_code")
    @ApiModelProperty(notes="langCode", required=true)
    private String langCode;
    
    @JsonIgnore
    @Column(name = "extended_info")
    @ApiModelProperty(notes="extended Info for Push Notification", required=true)
    private String extendedInfo;
    
    @JsonIgnore
    @Column(name = "patient_id")
    @ApiModelProperty(notes="patient Id", required=true)
    private String patientId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public Long getSentDate() {
		return sentDate;
	}

	public void setSentDate(Long sentDate) {
		this.sentDate = sentDate;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public Long getRead_date() {
		return read_date;
	}

	public void setRead_date(Long read_date) {
		this.read_date = read_date;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getMobileIinfoId() {
		return mobileIinfoId;
	}

	public void setMobileIinfoId(Long mobileIinfoId) {
		this.mobileIinfoId = mobileIinfoId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getLangCode() {
		return langCode;
	}

	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}

	public String getExtendedInfo() {
		return extendedInfo;
	}

	public void setExtendedInfo(String extendedInfo) {
		this.extendedInfo = extendedInfo;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "UserPushNotification [id=" + id + ", notificationId=" + notificationId + ", sentDate=" + sentDate
				+ ", isRead=" + isRead + ", read_date=" + read_date + ", isDeleted=" + isDeleted + ", mobileIinfoId="
				+ mobileIinfoId + ", message=" + message + ", langCode=" + langCode + ", extendedInfo=" + extendedInfo
				+ ", patientId=" + patientId + "]";
	}

	public UserPushNotification(Long id, Long notificationId, Long sentDate, Boolean isRead, Long read_date,
			Boolean isDeleted, Long mobileIinfoId, String message, String langCode, String extendedInfo,
			String patientId) {
		super();
		this.id = id;
		this.notificationId = notificationId;
		this.sentDate = sentDate;
		this.isRead = isRead;
		this.read_date = read_date;
		this.isDeleted = isDeleted;
		this.mobileIinfoId = mobileIinfoId;
		this.message = message;
		this.langCode = langCode;
		this.extendedInfo = extendedInfo;
		this.patientId = patientId;
	}

	public UserPushNotification() {
		super();
		// TODO Auto-generated constructor stub
	}
     
}
