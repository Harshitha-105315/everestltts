package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class CurrentGoalVO {

@JsonProperty("activityID")
@ApiModelProperty(notes="Activity ID (Long)", required=true)
private Long activityID;
@ApiModelProperty(notes="Activity name", required=true)
@JsonProperty("activityName")
private String activityName;
@JsonProperty("target")
@ApiModelProperty(notes="Target value(Long)", required=true)
private Long target;
@JsonProperty("initial")
@ApiModelProperty(notes="Initial value (Long)", required=true)
private Long initial;
@JsonProperty("current")
@ApiModelProperty(notes="Current value (Long)", required=true)
private Long current;
@ApiModelProperty(notes="Goal start date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
private Long goalStartDate;
@ApiModelProperty(notes="Goal end date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
private Long goalEndDate;
@JsonProperty("extendedInfo")
@ApiModelProperty(notes="Extended Information", required=true)
private ExtendedInfoDTO extendedInfo;

@JsonProperty("activityID")
public Long getActivityID() {
return activityID;
}

@JsonProperty("activityID")
public void setActivityID(Long activityID) {
this.activityID = activityID;
}

@JsonProperty("activityName")
public String getActivityName() {
return activityName;
}

@JsonProperty("activityName")
public void setActivityName(String activityName) {
this.activityName = activityName;
}

@JsonProperty("target")
public Long getTarget() {
return target;
}

@JsonProperty("target")
public void setTarget(Long target) {
this.target = target;
}

@JsonProperty("initial")
public Long getInitial() {
return initial;
}

@JsonProperty("initial")
public void setInitial(Long initial) {
this.initial = initial;
}

@JsonProperty("current")
public Long getCurrent() {
return current;
}

@JsonProperty("current")
public void setCurrent(Long current) {
this.current = current;
}


public Long getGoalStartDate() {
	return goalStartDate;
}

public void setGoalStartDate(Long goalStartDate) {
	this.goalStartDate = goalStartDate;
}

public Long getGoalEndDate() {
	return goalEndDate;
}

public void setGoalEndDate(Long goalEndDate) {
	this.goalEndDate = goalEndDate;
}

public ExtendedInfoDTO getExtendedInfo() {
	return extendedInfo;
}

public void setExtendedInfo(ExtendedInfoDTO extendedInfo) {
	this.extendedInfo = extendedInfo;
}

}
