package com.hillrom.mobile.dto;

import java.util.List;

public class PatientMedicationUpdateVO {
	
	private String pid;
	private List<MedicationVO> medicationList;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public List<MedicationVO> getMedicationList() {
		return medicationList;
	}
	public void setMedicationList(List<MedicationVO> medicationList) {
		this.medicationList = medicationList;
	}
	
	public PatientMedicationUpdateVO(String pid, List<MedicationVO> medicationList) {
		super();
		this.pid = pid;
		this.medicationList = medicationList;
	}
	
	public PatientMedicationUpdateVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PatientMedicationUpdateVO [pid=" + pid + ", medicationList=" + medicationList + "]";
	}

}
