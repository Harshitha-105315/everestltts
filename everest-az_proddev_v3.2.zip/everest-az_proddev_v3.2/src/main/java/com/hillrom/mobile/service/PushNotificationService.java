package com.hillrom.mobile.service;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hillrom.mobile.domain.AwardMaster;
import com.hillrom.mobile.domain.BadgesMaster;
import com.hillrom.mobile.domain.MobileDeviceInfo;
import com.hillrom.mobile.domain.NotificationMaster;
import com.hillrom.mobile.domain.UserPushNotification;
import com.hillrom.mobile.dto.NotificationDataDTO;
import com.hillrom.mobile.dto.NotificationExtendedInfoDTO;
import com.hillrom.mobile.dto.NotificationReadStatusDTO;
import com.hillrom.mobile.dto.UserPushNotificationVO;
import com.hillrom.mobile.dto.UserPushNotifictionStatusDTO;
import com.hillrom.mobile.repository.AwardMasterRepository;
import com.hillrom.mobile.repository.BadgesMasterRepository;
import com.hillrom.mobile.repository.MobileDeviceInfoRepository;
import com.hillrom.mobile.repository.NotificationMasterRepository;
import com.hillrom.mobile.repository.UserPushNotificationRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.HillromTypeCodeFormat;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.HillromTypeCodeFormatRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.UserLoginTokenService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.util.ExceptionConstants;

@Service
@Transactional
public class PushNotificationService {
	private final Logger logger = LoggerFactory.getLogger(PushNotificationService.class);

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject
	private MobileDeviceInfoRepository mobileDeviceInfoRepository;

	@Inject
	private HillromTypeCodeFormatRepository hillromTypeCodeFormatRepository;

	@Inject
	private EntityManager entityManager;

	@Inject
	private AndroidPushService androidPushService;

	@Inject
	private IOSPushService iOSPushService;
	
	@Inject
	private UserPushNotificationRepository userPushNotificationRepository;
	
	@Inject
	private NotificationMasterRepository notificationMasterRepository;
	
	@Inject
	private AwardMasterRepository awardMasterRepository;

	@Inject
	private BadgesMasterRepository badgesMasterRepository;
	
	@Inject
	private UserExtensionRepository userExtensionRepository;
	
    @Inject
    private UserPatientRepository userPatientRepository;
    
    @Inject
    private UserLoginTokenService authTokenService;

	public List<UserPushNotificationVO> getUserPushNotifications(String pid) throws HillromException{
		PatientInfo patient = patientInfoRepository.findOne(pid);
		if (Objects.nonNull(patient)) {
			List<UserPushNotificationVO> upnvl = new ArrayList<UserPushNotificationVO>();
			List<UserPushNotification> upnl = userPushNotificationRepository.findByPatientId(pid);
			ObjectMapper mapper = new ObjectMapper();
			try {
				for (UserPushNotification upn : upnl) {
					//(Long id, Long sentDate, Boolean isRead, Long read_date, NotificationExtendedInfoDTO message)
					UserPushNotificationVO upnv = new UserPushNotificationVO(upn.getId(),
							upn.getSentDate(),
							Objects.nonNull(upn.getIsRead()) ? upn.getIsRead() : false,
							upn.getRead_date(),
							mapper.readValue(upn.getMessage(), NotificationExtendedInfoDTO.class));
					upnvl.add(upnv);
				}
				
			} catch(Exception e) {
				logger.debug("getUserPushNotifications" + e.getMessage());
			}
			return upnvl;
			
		} else {
			throw new HillromException(ExceptionConstants.HR_915);
		}
	}

    @Scheduled(cron="${cron.medication.refill.utcminus12}")
    @Scheduled(cron="${cron.medication.refill.utcminus11}")    
    @Scheduled(cron="${cron.medication.refill.utcminus10}")
    @Scheduled(cron="${cron.medication.refill.utcminus9}")
    @Scheduled(cron="${cron.medication.refill.utcminus8}")
    @Scheduled(cron="${cron.medication.refill.utcminus7}")
    @Scheduled(cron="${cron.medication.refill.utcminus6}")
    @Scheduled(cron="${cron.medication.refill.utcminus5}")
    @Scheduled(cron="${cron.medication.refill.utcminus4}")
    @Scheduled(cron="${cron.medication.refill.utcminus330}")
    @Scheduled(cron="${cron.medication.refill.utcminus230}")
    @Scheduled(cron="${cron.medication.refill.utcplus10}")
	public void medicationRefillReminderNotificationJob() {
    	medicationRefillReminderNotificationJob(false);
    }
    
    public void medicationRefillReminderNotificationJob(boolean forceTimeZone) {
    	NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("Medication", "RefillReminder");
    	if (Objects.nonNull(notificationMaster)) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
			
				logger.debug("Running medication refillreminder job");
				String timeZone = DateUtil.getTimeZoneFromESTHour(LocalDateTime.now().getHourOfDay());
				if (StringUtils.isBlank(timeZone)) {
					logger.debug("timeZone is null : " + timeZone);
					return;
				}
				
				if(forceTimeZone) {
					timeZone = Constants.UTC_MINUS5;
				}
				
				String zoneIdString = new StringBuilder("'%").append(timeZone)
						.append("%'").toString();
		
				// D<5
				DateTime from = new LocalDate().toDateTimeAtStartOfDay();
				DateTime to = from.plusDays(5).plusHours(23).plusMinutes(59).plusSeconds(59);
				String query = QueryConstants.QUERY_MEDICATION_REFILL_REMINDER;
				if (StringUtils.isBlank(query)) {
					logger.debug("QUERY_MEDICATION_REFILL_REMINDER is null : " + query);
					return;
				}
				
				String finalQuery = query.replaceAll(":from", from.toString()).replaceAll(":to", to.toString()).replaceAll(":zone", zoneIdString);
				Query nativeQuery = entityManager.createNativeQuery(finalQuery);
		
				@SuppressWarnings("unchecked")
				List<Object[]> resultListD5 = nativeQuery.getResultList();
				resultListD5.stream().forEach((record) -> {
					String patientId = ((String) record[0]);
					Long medId = ((BigInteger) record[1]).longValue();
					logger.debug("Patient Id" + patientId + "medId" + medId);
					pushNotificationForRefill(patientId,nexDTO,medId,notificationMaster.getId());
				});
			} catch(Exception e) {
				logger.debug("medicationRefillReminderNotificationJob ObjectMapper :" + e.getMessage());
				return;
			}
		} else {
			logger.debug("medicationRefillReminderNotificationJob No refill reminder message configured ");
			return;
		}
	}

	public void pushNotificationForRefill(String pid, NotificationExtendedInfoDTO nexDTO, Long medId, Long notificationId) {
		nexDTO.setMedicationId(medId);
		nexDTO.setTitle(nexDTO.getType());
		nexDTO.setDescription(nexDTO.getCategory() + " " + nexDTO.getType());
		nexDTO.setImageId(3L);
		pushNotificationToUser(pid, nexDTO, notificationId, "Medication");
	}

	
	public boolean canPushNotification(String pid, String category) {

		boolean canPushNotification = false;
		List<UserPatientAssoc> upaList = userPatientRepository.findByPatientIdAndUserRole(pid, AuthoritiesConstants.PATIENT);
		UserExtension uex = userExtensionRepository.findOne(upaList.get(0).getUser().getId());

		if (Objects.nonNull(uex)) {
			switch(category){
				case "Caution":
					canPushNotification = (uex.isProtocolDeviationNotification() == true) ? true : false;
					break;
					
				case "Generic":
					canPushNotification = (uex.isReminderNotification() == true) ? true : false;
					break;
					
				case "Award":
					canPushNotification = (uex.isAchievementNotification() == true) ? true : false;
					break;
					
				case "Badge":
					canPushNotification = (uex.isAchievementNotification() == true) ? true : false;
					break;
					
				case "Medication":
					canPushNotification = (uex.isReminderNotification() == true) ? true : false;
					break;
					
				case "RTU":
					canPushNotification = (uex.isRtpUpdateNotification() == true) ? true : false;
					break;
				
				case "NewTherapy":
					canPushNotification = (uex.isNewTherapyNotification() == true) ? true : false;
					break;
				
			}
		}
		
		return canPushNotification;
	}
	
	public boolean confirmDeviceAuthentication(MobileDeviceInfo mdi) {
		boolean authentication_flag = false;
		if (Objects.nonNull(mdi) && mdi.getAuthentication_flag()) {
			authentication_flag = true;
		} else { // authentication_flag is false
			if (Objects.nonNull(mdi) && StringUtils.isNotBlank(mdi.getAuth_token())  && authTokenService.validateToken(mdi.getAuth_token())) {
				authentication_flag = true;
			}			
		}
		return authentication_flag;
	}
	
	public String pushTestNotificationToUser(String pid, String uuid, String category, String type) {
		PatientInfo patient = patientInfoRepository.findOne(pid);
		if (Objects.nonNull(patient)) {
			NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory(category, type);
			if (Objects.nonNull(notificationMaster)) {
				ObjectMapper mapper = new ObjectMapper();
				try {
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					OrientDTOWithSampleValues(nexDTO, category, type);
					String  message = pushNotificationToUser(pid, nexDTO, notificationMaster.getId(), category);
			        if (!StringUtils.isBlank(message)) {
			        	return message;
			        } else {
			        	return ExceptionConstants.HR_952;
			        }
				} catch (Exception e) {
					logger.debug("pushNotificationToUser:" + e.getMessage());
				}
			} else {
				return ExceptionConstants.HR_951;
			}
		}
		return null;
	}
	
	public void OrientDTOWithSampleValues(NotificationExtendedInfoDTO nexDTO, String category, String type) {	
				
		switch(category){
		
			case "Caution":
				if (type.equals("MissedTherapy")) {
					nexDTO.setTitle("Missed Therapy");
					nexDTO.setDescription("Log therapy for yesterday");
					//nexDTO.setImageId(imageId);
				} else if (type.equals("ProtocolDeviation")) {
					nexDTO.setTitle("Protocol Deviation");
					nexDTO.setDescription("Therapy duration is less than protocol duration");
					//nexDTO.setImageId(imageId);
				}
				break;
				
			case "Generic":
				if (type.equals("Holiday")) {
					nexDTO.setTitle("Holiday");
					nexDTO.setDescription("Holiday");
					
				} else if (type.equals("Celebrations")) {
					nexDTO.setTitle("Celebrations");
					nexDTO.setDescription("Celebrations");
					
				} else if (type.equals("Motivational")) {
					nexDTO.setTitle("Motivational");
					nexDTO.setDescription("Motivational");
					
				}
				break;
				
			case "Award":
				if (type.equals("NewAward")) {
					AwardMaster award = awardMasterRepository.findOne(5L);
					HillromTypeCodeFormat htc = hillromTypeCodeFormatRepository.findOne(award.getActivityTypeId());
					
					nexDTO.setTitle("Good Job");
					nexDTO.setDescription("Goal met 60-69%");
					nexDTO.setAwardId(award.getId());
					nexDTO.setActivityId(award.getActivityTypeId());
					nexDTO.setActivityType(htc.getType_code_value());
				}
				break;
				
			case "Badge":
				if (type.equals("NutritionLog")) {
					BadgesMaster badge = badgesMasterRepository.findOne(20L);
					nexDTO.setTitle("Top Chef");
					nexDTO.setDescription("Log first nutrition");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
					//nexDTO.setImageId(20L);
					
				} else if (type.equals("ExerciseLog")) {
					BadgesMaster badge = badgesMasterRepository.findOne(24L);
					nexDTO.setTitle("Power User");
					nexDTO.setDescription("Log once to exercise");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
					
					
				} else if (type.equals("WeightLog")) {
					BadgesMaster badge = badgesMasterRepository.findOne(21L);
					nexDTO.setTitle("Weigh-in");
					nexDTO.setDescription("Log first weight");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
					
				} else if (type.equals("SpiroLog")) {
					BadgesMaster badge = badgesMasterRepository.findOne(23L);
					nexDTO.setTitle("Breath of Fresh Air");
					nexDTO.setDescription("Log first spiro");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
					
				} else if (type.equals("VestLog")) {
					BadgesMaster badge = badgesMasterRepository.findOne(22L);
					nexDTO.setTitle("Vest Time");
					nexDTO.setDescription("Log first vest");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
										
				} else if (type.equals("CompletingGoal")) {
					BadgesMaster badge = badgesMasterRepository.findOne(1L);
					nexDTO.setTitle("Go-Getter");
					nexDTO.setDescription("Complete 10 goals");
					nexDTO.setBadgeCategory(badge.getCategory());
					nexDTO.setBadgeId(badge.getId());
					nexDTO.setBadgeType(badge.getType());
					
				}
				break;
				
			case "Medication":
				if (type.equals("RefillReminder")) {
					nexDTO.setTitle("Refill Reminder");
					nexDTO.setDescription("It's time to refill medication");
					nexDTO.setMedicationId(1L);
					//nexDTO.setImageId(imageId);
				}
				break;

			case "RTU":
				if (type.equals("RemoteTherapyUpdateAccepted")) {
					nexDTO.setTitle("Remote Therapy Update Accepted");
					nexDTO.setDescription("Therapy settings have been updated on the Vest® APX System");
					//nexDTO.setImageId(imageId);
				}else if(type.equals("RemoteTherapyUpdateRejected")) {
					nexDTO.setTitle("Remote Therapy Update Rejected");
					nexDTO.setDescription("Request to update therapy settings has been rejected on the Vest® APX System");
					//nexDTO.setImageId(imageId);
				}
				break;
			
			case "NewTherapy":
				if (type.equals("PowerOnDevice")) {
					nexDTO.setTitle("Power On APX Device");
					nexDTO.setDescription("New therapy settings available. Power on the Vest® APX System to update the therapy settings");
					//nexDTO.setImageId(imageId);
				}
				break;

		}
	}
	
	public String pushNotificationToUser(Long mobDevId, NotificationExtendedInfoDTO nexDTO, Long notificationId, Long sendDate) {
		MobileDeviceInfo mobileDeviceInfo = mobileDeviceInfoRepository.findOne(mobDevId);
		Long IOSPlatformType = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("ios").get(0).getId();
		
		if (!confirmDeviceAuthentication(mobileDeviceInfo)) {
			logger.debug("Authentication flag for device UUID = " + mobileDeviceInfo.getDevice_UUID() + " : " + mobileDeviceInfo.getAuthentication_flag());
			return  "Fail";
		}
		
		if (Objects.nonNull(mobileDeviceInfo) && mobileDeviceInfo.getPlatform_type().equals(IOSPlatformType)) {
			NotificationDataDTO ndDTO = new NotificationDataDTO(nexDTO, notificationId, sendDate);
			return iOSPushService.SendNotification(mobileDeviceInfo.getDevice_token(), ndDTO); // TODO
		} else { // assuming other android
			NotificationDataDTO ndDTO = new NotificationDataDTO(nexDTO, notificationId, sendDate);
			return androidPushService.SendNotification(mobileDeviceInfo.getDevice_token(), ndDTO);
		}
	}
		
	public String pushNotificationToUser(String pid, NotificationExtendedInfoDTO nexDTO, Long notificationMasterId, String category) {
		List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
		if (Objects.nonNull(mobileDeviceList) && mobileDeviceList.size() > 0) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				String dataMessage = mapper.writeValueAsString(nexDTO);
				
				UserPushNotification upn = new UserPushNotification();
				upn.setMessage(dataMessage);
				upn.setLangCode("en");
				upn.setNotificationId(notificationMasterId);
				upn.setPatientId(pid);
				upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
				upn.setMobileIinfoId(mobileDeviceList.get(0).getId());
				upn.setIsRead(false);
				upn.setIsDeleted(false);
				userPushNotificationRepository.save(upn);
	
				if(canPushNotification(pid,category)) {
					for (MobileDeviceInfo mobileDeviceInfo : mobileDeviceList) {
						pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
					}
				}
			} catch (Exception e) {
				logger.debug("saveNotificationPushStatus:" + e.getMessage());
			}
		}
		return null;
	}
	
	public void testPushNotificationForAward(String pid, Long awardId, Long activityId, String activityType, String awardDesc, String awardName) {
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("Award", "NewAward");
		if (Objects.nonNull(notificationMaster) ) {
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			if (Objects.nonNull(mobileDeviceList) && mobileDeviceList.size() > 0) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setActivityId(activityId);
					nexDTO.setAwardId(awardId);
					nexDTO.setActivityType(activityType);
					nexDTO.setDescription(awardDesc);
					nexDTO.setTitle(awardName);
					nexDTO.setHeader("Trophy Unlocked");
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setLangCode("en");
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					
					if(canPushNotification(pid,"Award")) {
						for (MobileDeviceInfo mobileDeviceInfo : mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
							//upn.setMobileIinfoId(mobileDeviceInfo.getId());
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForAward :" + e.getMessage());
				}
			}
        }
	}
	
	public void pushNotificationForAward(String pid, Long awardId, Long activityId, String activityType, String awardDesc, String awardName) {
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("Award", "NewAward");
		if (Objects.nonNull(notificationMaster) ) {
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			if (Objects.nonNull(mobileDeviceList) && mobileDeviceList.size() > 0) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setActivityId(activityId);
					nexDTO.setAwardId(awardId);
					nexDTO.setActivityType(activityType);
					nexDTO.setDescription(awardDesc);
					nexDTO.setTitle(awardName);
					nexDTO.setHeader("Trophy Unlocked");
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setLangCode("en");
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					
					if(canPushNotification(pid,"Award")) {
						for (MobileDeviceInfo mobileDeviceInfo : mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
							//upn.setMobileIinfoId(mobileDeviceInfo.getId());
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForAward :" + e.getMessage());
				}
			}
        }
	}
	
	// awardId, activityId, activityType
	@Async
	public void pushNotificationForBadges(String pid, Long badgeId, String badgeCategory, String badgeType, String badgeDesc, String badgeName) {
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("Badge", badgeType + badgeCategory);
		if (Objects.nonNull(notificationMaster)) {
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			if (Objects.nonNull(mobileDeviceList) && mobileDeviceList.size() > 0) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setBadgeCategory(badgeCategory);
					nexDTO.setBadgeId(badgeId);
					nexDTO.setBadgeType(badgeType);
					nexDTO.setDescription(badgeDesc);
					nexDTO.setTitle(badgeName);
					nexDTO.setHeader("Badge Unlocked");
					
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setLangCode("en");
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					
					if(canPushNotification(pid,"Badge")) {
						for (MobileDeviceInfo mobileDeviceInfo: mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
							//upn.setMobileIinfoId(mobileDeviceInfo.getId());	// updating mobile device ID
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForBadges :" + e.getMessage());
				}
			}
        }
	}

	public void pushNotificationForSettingDeviation(String pid, String description, String category) {
		logger.debug("Start pushNotificationForSettingDeviation");
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("Caution", category);
		if (Objects.nonNull(notificationMaster)) {
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			if(Objects.nonNull(mobileDeviceList) && mobileDeviceList.size() > 0) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setTitle(nexDTO.getType());
					nexDTO.setDescription(description);
					if(category.equalsIgnoreCase("MissedTherapy")) {
						nexDTO.setImageId(1L);
					}else {
						nexDTO.setImageId(2L);
					}
					
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setLangCode("en");
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					if(canPushNotification(pid,"Caution")) {
						for (MobileDeviceInfo mobileDeviceInfo: mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForSettingDeviation :" + e.getMessage());
				}
			}
		}
	}

	@Async
	public void pushNotificationForDeviations(int deviation, String patientId)
	{	
		switch(deviation){
			case Constants.PUSH_NOTIFICATION_HMR_DEVIATION:    
			case Constants.PUSH_NOTIFICATION_ALL_PARAMETERS_DEVIATED:
			case Constants.PUSH_NOTIFICATION_DURATION_FREQENCY_DEVIATED:
			case Constants.PUSH_NOTIFICATION_DURATION_PRESSURE_DEVIATED:
			case Constants.PUSH_NOTIFICATION_DURATION_DEVIATED:
			case Constants.PUSH_NOTIFICATION_FREQUENCY_PRESSURE_DEVIATED:
			case Constants.PUSH_NOTIFICATION_FREQUENCY_DEVIATED:
			case Constants.PUSH_NOTIFICATION_PRESSURE_DEVIATED:
			{
				pushNotificationForSettingDeviation(patientId, "Please follow prescribed protocol. If you need assistance please contact Hillrom Respiratory Health at 800-426-4224.", "ProtocolDeviation");
			}
			break;
			
			case Constants.PUSH_NOTIFICATION_MISSED_THERAPY_DEVIATION:
			{
				pushNotificationForSettingDeviation(patientId, "Please follow prescribed protocol. If you need assistance please contact Hillrom Respiratory Health at 800-426-4224.", "MissedTherapy");
			}
			break;
			
			default:
				logger.debug("Yet to handle notificationType:" + deviation);
				break;
			
		}
	}
	

	public String updateNotificationReadStatus(UserPushNotifictionStatusDTO upnsDTO) {
		PatientInfo patient = patientInfoRepository.findOne(upnsDTO.getPid());
		if (Objects.nonNull(patient)) {
			List<NotificationReadStatusDTO> nrsList = upnsDTO.getNotificationReadStatusList();
			for (NotificationReadStatusDTO nrs:nrsList) {
				UserPushNotification upn = userPushNotificationRepository.getOne(nrs.getNotificationId());
				upn.setIsRead(nrs.getIsRead());
				upn.setRead_date(DateTime.now(DateTimeZone.UTC).getMillis());
			}
			return ExceptionConstants.HR_937;
		} else {
			return ExceptionConstants.HR_915;
		}
	}

    @Scheduled(cron="${cron.award.achieved.notification.utcminus12}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus11}")    
    @Scheduled(cron="${cron.award.achieved.notification.utcminus10}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus9}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus8}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus7}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus6}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus5}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus4}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus330}")
    @Scheduled(cron="${cron.award.achieved.notification.utcminus230}")
    @Scheduled(cron="${cron.award.achieved.notification.utcplus10}")
    public void awardUnlockedPushNotificationJob() {
    	awardUnlockedPushNotificationJob(false);
    }
    
	public void awardUnlockedPushNotificationJob(boolean forceTimeZone) {
		try {
			logger.debug("Running Awards Push Notification job");
			String timeZone = DateUtil.getTimeZoneFromESTHour(LocalDateTime.now().getHourOfDay());
			if (StringUtils.isBlank(timeZone)) {
				logger.debug("timeZone is null : " + timeZone);
				return;
			}
			if(forceTimeZone) {
				timeZone = Constants.UTC_MINUS5;
			}
			String zoneIdString = new StringBuilder("'%").append(timeZone)
					.append("%'").toString();
			DateTime from = new LocalDate().toDateTimeAtStartOfDay();
			DateTime to = from.plusHours(23).plusMinutes(59).plusSeconds(59);
			String query = QueryConstants.QUERY_AWARDS_UNLOCKED_PATIENTS;
			if (StringUtils.isBlank(query)) {
				logger.debug("QUERY_AWARDS_UNLOCKED_PATIENTS is null : " + query);
				return;
			}
			String finalQuery = query.replaceAll(":from", from.toString()).replaceAll(":to", to.toString()).replaceAll(":zone", zoneIdString);
			Query nativeQuery = entityManager.createNativeQuery(finalQuery);
			@SuppressWarnings("unchecked")
			List<Object[]> resultSet = nativeQuery.getResultList();
			resultSet.stream().forEach((record) -> {
				String patient_id = record[0].toString();
				Long award_id = ((BigInteger) record[1]).longValue();
				Long activity_id = ((BigInteger) record[2]).longValue();
				String activityType = record[3].toString();
				String awardDescription = record[4].toString();
				String  awardName = record[5].toString();
				pushNotificationForAward(patient_id, award_id, activity_id, activityType, awardDescription, awardName);
			});
		} catch(Exception e) {
			logger.debug("awardPushNotificationJob ObjectMapper :" + e.getMessage());
			return;
		}
	}
	
	public void pushNotificationForRemoteTherapyUpdate(String pid, String description, String type) {
		logger.debug("Start pushNotificationForRemoteTherapyUpdate");
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("RTU", type);
		if (Objects.nonNull(notificationMaster)) {
			logger.debug("patient id : "+pid);
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			logger.debug("mobileDeviceList : "+mobileDeviceList);

			if(Objects.nonNull(mobileDeviceList) && !mobileDeviceList.isEmpty()) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setTitle(nexDTO.getType());
					nexDTO.setDescription(description);
					if("RemoteTherapyUpdateAccepted".equals(type)) {
						nexDTO.setImageId(4L);
					}else {
						nexDTO.setImageId(5L);
					}
					
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setLangCode("en");
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					if(canPushNotification(pid,"RTU")) {
						for (MobileDeviceInfo mobileDeviceInfo: mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForRemoteTherapyUpdate :" + e.getMessage());
				}
			}
		}
	}
	
	public void pushNotificationForNewTherapySetting(String pid, String description, String type) {
		logger.debug("Start pushNotificationForNewTherapySetting");
		NotificationMaster notificationMaster = notificationMasterRepository.findByTypeAndCategory("NewTherapy", type);
		if (Objects.nonNull(notificationMaster)) {
			logger.debug("patient id : "+pid);
			List<MobileDeviceInfo> mobileDeviceList = mobileDeviceInfoRepository.findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(pid);
			logger.debug("mobileDeviceList : "+mobileDeviceList);

			if(Objects.nonNull(mobileDeviceList) && !mobileDeviceList.isEmpty()) {
				try {
					ObjectMapper mapper = new ObjectMapper();
					NotificationExtendedInfoDTO nexDTO = mapper.readValue(notificationMaster.getExtendedInfo(), NotificationExtendedInfoDTO.class);
					nexDTO.setTitle(nexDTO.getType());
					nexDTO.setDescription(description);
					nexDTO.setImageId(6L);
					
					//save
					UserPushNotification upn = new UserPushNotification();
					String dataMessage = mapper.writeValueAsString(nexDTO);
					upn.setMessage(dataMessage);
					upn.setLangCode("en");
					upn.setNotificationId(notificationMaster.getId());
					upn.setPatientId(pid);
					upn.setMobileIinfoId(mobileDeviceList.get(0).getId());	// Setting to first device
					upn.setSentDate(DateTime.now(DateTimeZone.UTC).getMillis());
					upn.setIsRead(false);
					upn.setIsDeleted(false);
					userPushNotificationRepository.save(upn);
					if(canPushNotification(pid,"NewTherapy")) {
						for (MobileDeviceInfo mobileDeviceInfo: mobileDeviceList) {
							pushNotificationToUser(mobileDeviceInfo.getId(), nexDTO, upn.getId(), upn.getSentDate());
						}
					}
				} catch (IOException e) {
					logger.debug(" pushNotificationForNewTherapySetting :" + e.getMessage());
				}
			}
		}
	}

}
