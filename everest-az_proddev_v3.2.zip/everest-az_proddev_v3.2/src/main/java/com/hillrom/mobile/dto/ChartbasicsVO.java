package com.hillrom.mobile.dto;

public class ChartbasicsVO {

	public ChartbasicsVO() {
		super();
	}
	private String latest_Adherence_score;
	private String latest_pulmonary_value;
	private String medication_count;
	private String airway_therapy_count;
	public String getLatest_Adherence_score() {
		return latest_Adherence_score;
	}
	public void setLatest_Adherence_score(String latest_Adherence_score) {
		this.latest_Adherence_score = latest_Adherence_score;
	}
	public String getLatest_pulmonary_value() {
		return latest_pulmonary_value;
	}
	public void setLatest_pulmonary_value(String latest_pulmonary_value) {
		this.latest_pulmonary_value = latest_pulmonary_value;
	}
	public String getMedication_count() {
		return medication_count;
	}
	public void setMedication_count(String medication_count) {
		this.medication_count = medication_count;
	}
	public String getAirway_therapy_count() {
		return airway_therapy_count;
	}
	public void setAirway_therapy_count(String airway_therapy_count) {
		this.airway_therapy_count = airway_therapy_count;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((airway_therapy_count == null) ? 0 : airway_therapy_count
						.hashCode());
		result = prime
				* result
				+ ((latest_Adherence_score == null) ? 0
						: latest_Adherence_score.hashCode());
		result = prime
				* result
				+ ((latest_pulmonary_value == null) ? 0
						: latest_pulmonary_value.hashCode());
		result = prime
				* result
				+ ((medication_count == null) ? 0 : medication_count.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChartbasicsVO other = (ChartbasicsVO) obj;
		if (airway_therapy_count == null) {
			if (other.airway_therapy_count != null)
				return false;
		} else if (!airway_therapy_count.equals(other.airway_therapy_count))
			return false;
		if (latest_Adherence_score == null) {
			if (other.latest_Adherence_score != null)
				return false;
		} else if (!latest_Adherence_score.equals(other.latest_Adherence_score))
			return false;
		if (latest_pulmonary_value == null) {
			if (other.latest_pulmonary_value != null)
				return false;
		} else if (!latest_pulmonary_value.equals(other.latest_pulmonary_value))
			return false;
		if (medication_count == null) {
			if (other.medication_count != null)
				return false;
		} else if (!medication_count.equals(other.medication_count))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ChartbasicsVO [latest_Adherence_score="
				+ latest_Adherence_score + ", latest_pulmonary_value="
				+ latest_pulmonary_value + ", medication_count="
				+ medication_count + ", airway_therapy_count="
				+ airway_therapy_count + "]";
	}
}
