package com.hillrom.mobile.rest;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.mobile.dto.AirwayTherapyRecordingsDTO;
import com.hillrom.mobile.dto.RetrieveAirwayTherapyDTO;
import com.hillrom.mobile.dto.RetrieveAllAirwayTherapyDTO;
import com.hillrom.mobile.service.AirwayTherapyRecordingsService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.util.ExceptionConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.minidev.json.JSONObject;

@RestController
@Api(value = "AirwayTherapyRecordingsResource", description = "AIRWAY THERAPY RESOURCE")
@RequestMapping("/api/patient/"+ Constants.ApiVersion)
public class AirwayTherapyRecordingsResource {

	private final Logger log = LoggerFactory.getLogger(AirwayTherapyRecordingsResource.class);

	@Inject
	public AirwayTherapyRecordingsService airwayTherapyRecordingsService;
	
	@ApiOperation(httpMethod = "POST", value = "Add Airway Therapy")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
		@ApiImplicitParam(name = "name", value = "Therapy Name", required = true, dataType = "String"),
		@ApiImplicitParam(name = "dateTime", value = "Unix time in milli seconds", required = true, dataType = "Long", example = "1513307652000"),
		@ApiImplicitParam(name = "duration", value = "Duaration in minutes", required = true, dataType = "Long", example = "30" )
		 })
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Returns therapyId"),
			@ApiResponse(code = 422, message = "Failed: Invalid Date Range") })
	@RequestMapping(value = "/airwayTherapy/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> create(@RequestBody AirwayTherapyRecordingsDTO airwayTherapyRecording) {

		log.debug("REST request to save airway threapy recordings : {}", airwayTherapyRecording);
		JSONObject jsonObject = new JSONObject();
		if (airwayTherapyRecording.getName() != null && airwayTherapyRecording.getDateTime() != null
				&& airwayTherapyRecording.getPid() != null && airwayTherapyRecording.getDuration() != null) {
			try {
				jsonObject = airwayTherapyRecordingsService.createAirwayTherapy(airwayTherapyRecording);
				if (jsonObject.containsKey("therapyId")) {
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} else if (jsonObject.containsValue(ExceptionConstants.HR_954)) { 
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					//return new ResponseEntity<>(jsonObject, HttpStatus.OK);
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				jsonObject.put("message", "AIR_THERAPY_ADD_FAIL");
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	
	}
	
	
	@ApiOperation(httpMethod = "PUT", value = "Update Airway Therapy")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
		@ApiImplicitParam(name = "tid", value = "Therapy Id", required = true, dataType = "Long",  example="1513307"),
		@ApiImplicitParam(name = "name", value = "Therapy Name", required = true, dataType = "String"),
		@ApiImplicitParam(name = "dateTime", value = "Unix time in milli seconds", required = true, dataType = "Long", example = "1513307652000"),
		@ApiImplicitParam(name = "duration", value = "Duaration in minutes", required = true, dataType = "Long", example = "30" )
		 })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "AIR_THERAPY_UPDATED_SUCCESSFULLY"),
			@ApiResponse(code = 422, message = "Failed: Invalid Date Range") })
	@RequestMapping(value = "/airwayTherapy/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> update(@RequestBody AirwayTherapyRecordingsDTO airwayTherapyRecording) {

		JSONObject jsonObject = new JSONObject();
		log.debug("REST request to update airway threapy recordings : {}", airwayTherapyRecording);
		if (airwayTherapyRecording.getTid() != null && airwayTherapyRecording.getPid() != null
				&& airwayTherapyRecording.getDateTime() != null && airwayTherapyRecording.getDuration() != null
				&& airwayTherapyRecording.getName() != null) {
			try {
				jsonObject = airwayTherapyRecordingsService.updateAirwayTherapy(airwayTherapyRecording);
				if (jsonObject.containsValue(ExceptionConstants.HR_954)) { 
					return new ResponseEntity<>(jsonObject, HttpStatus.UNPROCESSABLE_ENTITY);
				} else {
					//return new ResponseEntity<>(jsonObject, HttpStatus.OK);
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				jsonObject.put("message", "AIR_THERAPY_UPDATE_FAIL");
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	
	}

	
	@ApiOperation(httpMethod = "GET", value = "Retrieve Airway Therapy History")
	@RequestMapping(value = "/airwayTherapy/retrieve/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public RetrieveAirwayTherapyDTO get(@PathVariable String pid,
			@RequestParam(value = "startDate", required = false) Long startDate,
			@RequestParam(value = "endDate", required = false) Long endDate) {

		RetrieveAirwayTherapyDTO retrieveAirwayTherapyDTO = null; 
		if(pid != null ){
			retrieveAirwayTherapyDTO = airwayTherapyRecordingsService.getAirwayTherapy(pid,startDate,endDate);
		}
		
		return retrieveAirwayTherapyDTO;
	}
	
	/*
	*//**
		 * GET /airwayTherapy/:id -> get the "id" airwaythreapyrecordings.
	 * @throws Exception 
		 */
	@RequestMapping(value = "/airwayTherapy/retrieveAll/{pid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)

	public RetrieveAllAirwayTherapyDTO getAll(@PathVariable String pid,
			@RequestParam(value = "page", required=true)int page,
			@RequestParam(value = "size", required=true)int size) throws Exception {
		RetrieveAllAirwayTherapyDTO retrieveAllAirwayTherapyDTO = null;
		if(pid != null && page != 0 && size != 0 ){
			retrieveAllAirwayTherapyDTO = airwayTherapyRecordingsService.getAllAirwayTherapy(pid,page,size);
		}
		return retrieveAllAirwayTherapyDTO;
	}

	@ApiOperation(httpMethod = "DELETE", value = "Remove Airway Therapy")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
		@ApiImplicitParam(name = "tid", value = "Therapy Id", required = true, dataType = "Long",  example="1513307")
		 })
	@RequestMapping(value = "/airwayTherapy/remove", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@RolesAllowed({ AuthoritiesConstants.PATIENT })
	public ResponseEntity<Object> delete(@RequestBody AirwayTherapyRecordingsDTO airwayTherapyRecordings) {
	
		JSONObject jsonObject = new JSONObject();
		log.debug("REST request to delete Airwaythreapyrecordings : {}", airwayTherapyRecordings.getTid());
		if (airwayTherapyRecordings.getTid() != null && airwayTherapyRecordings.getPid() != null) {
			try {
				jsonObject = airwayTherapyRecordingsService.deleteAirwayTherapy(airwayTherapyRecordings);
				if (jsonObject.containsValue("AIR_THERAPY_REMOVE_SUCCESS")) {
					//return new ResponseEntity<>(jsonObject, HttpStatus.OK);
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				} else {
					//return new ResponseEntity<>(jsonObject, HttpStatus.NOT_FOUND);
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} catch (Exception e) {
				jsonObject.put("message", e.getMessage());
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", "Failed: Required Field is missing");
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	
	}
}