package com.hillrom.mobile.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "PATIENT_ACTIVITY_HISTORY")
public class PatientActivityHistory {

	@Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "ACTIVITY_TYPE_ID")
    private Long activityTypeId;

    @Column(name = "PATIENT_ID")
    @JoinColumn(name = "ID", nullable = false)
    private String patientId;

    @Column(name = "PATIENT_ACTIVITY_ASSOC_ID")
    @JoinColumn(name = "ID")
    private Long patientActivityAssociationId;

    @Column(name = "CURRENT_VALUE")
    private String currentValue;

    @Column(name = "RECORDED_DATETIME")
    private Long recordedDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getActivityTypeId() {
		return activityTypeId;
	}

	public void setActivityTypeId(Long activityTypeId) {
		this.activityTypeId = activityTypeId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Long getPatientActivityAssociationId() {
		return patientActivityAssociationId;
	}

	public void setPatientActivityAssociationId(Long patientActivityAssociationId) {
		this.patientActivityAssociationId = patientActivityAssociationId;
	}

	public String getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(String currentValue) {
		this.currentValue = currentValue;
	}

	public Long getRecordedDateTime() {
		return recordedDateTime;
	}

	public void setRecordedDateTime(Long recordedDateTime) {
		this.recordedDateTime = recordedDateTime;
	}
	
}
