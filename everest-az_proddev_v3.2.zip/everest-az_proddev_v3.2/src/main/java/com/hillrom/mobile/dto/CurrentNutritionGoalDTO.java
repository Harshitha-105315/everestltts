package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "activityName",
        "targetNutrition",
        "initialNutrition",
        "currentNutrition"
})
public class CurrentNutritionGoalDTO {

    @JsonProperty("activityName")
    private String activityName;
    @JsonProperty("targetNutrition")
    private int targetNutrition;
    @JsonProperty("initialNutrition")
    private int initialNutrition;
    @JsonProperty("currentNutrition")
    private int currentNutrition;

    @JsonProperty("activityName")
    public String getActivityName() {
        return activityName;
    }

    @JsonProperty("activityName")
    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    @JsonProperty("targetNutrition")
    public int getTargetNutrition() {
        return targetNutrition;
    }

    @JsonProperty("targetNutrition")
    public void setTargetNutrition(int targetNutrition) {
        this.targetNutrition = targetNutrition;
    }

    @JsonProperty("initialNutrition")
    public int getInitialNutrition() {
        return initialNutrition;
    }

    @JsonProperty("initialNutrition")
    public void setInitialNutrition(int initialNutrition) {
        this.initialNutrition = initialNutrition;
    }

    @JsonProperty("currentNutrition")
    public int getCurrentNutrition() {
        return currentNutrition;
    }

    @JsonProperty("currentNutrition")
    public void setCurrentNutrition(int currentNutrition) {
        this.currentNutrition = currentNutrition;
    }


}
