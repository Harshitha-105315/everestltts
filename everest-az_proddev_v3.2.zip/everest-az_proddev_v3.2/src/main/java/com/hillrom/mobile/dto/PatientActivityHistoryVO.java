package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;

@JsonPropertyOrder({
"date",
"value"
})
public class PatientActivityHistoryVO {

@JsonProperty("date")
@ApiModelProperty(notes="Date of log in unix timestamp (Long)", dataType="java.lang.Long",  required=true, example="1535384304000")
private Long date;
@JsonProperty("value")
@ApiModelProperty(notes="Value logged (Long)", required=true, example="30")
private Long value;

@JsonProperty("date")
public Long getDate() {
return date;
}

@JsonProperty("date")
public void setDate(Long date) {
this.date = date;
}

@JsonProperty("value")
public Long getValue() {
return value;
}

@JsonProperty("value")
public void setValue(Long value) {
this.value = value;
}

}
