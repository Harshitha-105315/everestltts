package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PHARMACY_DETAILS")
public class PharmacyDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="pharmacy_name")
	private String pharmacyName;
	
	@Column(name="pharmacy_address")
	private String pharmacyAddress;
	
	@Column(name="longitude")
    private String longitude;

	@Column(name="latitude")
    private String latitude;
	
	@Column(name="phone_number")
	private String phoneNumber;
	
	@Column(name="fax_number")
	private String faxNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getPharmacyAddress() {
		return pharmacyAddress;
	}

	public void setPharmacyAddress(String pharmacyAddress) {
		this.pharmacyAddress = pharmacyAddress;
	}

	@Override
	public String toString() {
		return "PharmacyDetails [id=" + id + ", pharmacyName=" + pharmacyName + ", pharmacyAddress=" + pharmacyAddress
				+ ", longitude=" + longitude + ", latitude=" + latitude + ", phoneNumber=" + phoneNumber
				+ ", faxNumber=" + faxNumber + "]";
	}

	public PharmacyDetails(String pharmacyName, String pharmacyAddress, String longitude, String latitude,
			String phoneNumber, String faxNumber) {
		super();
		this.pharmacyName = pharmacyName;
		this.pharmacyAddress = pharmacyAddress;
		this.longitude = longitude;
		this.latitude = latitude;
		this.phoneNumber = phoneNumber;
		this.faxNumber = faxNumber;
	}

	public PharmacyDetails() {
		// TODO Auto-generated constructor stub
	}

	public String getPharmacyName() {
		return pharmacyName;
	}

	public void setPharmacyName(String pharmacyName) {
		this.pharmacyName = pharmacyName;
	}
	
}