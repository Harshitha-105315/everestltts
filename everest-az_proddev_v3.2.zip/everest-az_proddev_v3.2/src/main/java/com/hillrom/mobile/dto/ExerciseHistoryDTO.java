package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"exerciseDuration",
"exerciseDate",
"activityId"
})
public class ExerciseHistoryDTO {

	@JsonProperty("pid")
	private String pid;
	@JsonProperty("exerciseDuration")
	private Long exerciseDuration;
	@JsonProperty("exerciseDate")
	private Long exerciseDate;
	@JsonProperty("activityId")
	private Long activityId;

	@JsonProperty("exerciseDuration")
	public Long getExerciseDuration() {
		return exerciseDuration;
	}

	@JsonProperty("exerciseDuration")
	public void setExerciseDuration(Long exerciseDuration) {
		this.exerciseDuration = exerciseDuration;
	}

	@JsonProperty("exerciseDate")
	public Long getExerciseDate() {
		return exerciseDate;
	}

	@JsonProperty("exerciseDate")
	public void setExerciseDate(Long exerciseDate) {
		this.exerciseDate = exerciseDate;
	}

	@JsonProperty("activityId")
	public Long getActivityId() {
		return activityId;
	}

	@JsonProperty("activityId")
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

}