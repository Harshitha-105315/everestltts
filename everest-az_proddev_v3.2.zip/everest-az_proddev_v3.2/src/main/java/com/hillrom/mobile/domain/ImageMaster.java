package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

/**
 * A IMAGE_MASTER.
 */
@Entity
@Table(name = "IMAGE_MASTER")
public class ImageMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    @ApiModelProperty(notes="ID of Image", dataType="java.lang.Long", required=true)
    private Long id;

    @Column(name = "THUMBNAIL")
    @ApiModelProperty(notes="Path of thumnail image", required=true)
    private String thumbnail;

    @Column(name = "IMAGE")
    @ApiModelProperty(notes="File path of fullsize image", required=true)
    private String image;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "ImageMaster [id=" + id + ", thumbnail=" + thumbnail + ", image=" + image + "]";
	}

	public ImageMaster(Long id, String thumbnail, String image) {
		super();
		this.id = id;
		this.thumbnail = thumbnail;
		this.image = image;
	}

	public ImageMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
