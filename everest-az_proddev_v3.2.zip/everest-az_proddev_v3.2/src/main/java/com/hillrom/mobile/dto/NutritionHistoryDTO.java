package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "date",
        "NutritionDTO intake in calories"
})
public class NutritionHistoryDTO {

    @JsonProperty("date")
    private Long date;
    @JsonProperty("NutritionDTO intake in calories")
    private Long nutritionIntakeInCalories;

    @JsonProperty("date")
    public Long getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(Long date) {
        this.date = date;
    }

    @JsonProperty("NutritionDTO intake in calories")
    public Long getNutritionIntakeInCalories() {
        return nutritionIntakeInCalories;
    }

    @JsonProperty("NutritionDTO intake in calories")
    public void setNutritionIntakeInCalories(Long nutritionIntakeInCalories) {
        this.nutritionIntakeInCalories = nutritionIntakeInCalories;
    }

}
