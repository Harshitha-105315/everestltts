package com.hillrom.mobile.dto;

public class LegalTermsAndConditionsVO {
	
	public LegalTermsAndConditionsVO() {
		super();
	}

	private String legalTermsandConditionsURL;

	public String getLegalTermsandConditionsURL() {
		return legalTermsandConditionsURL;
	}

	public void setLegalTermsandConditionsURL(String legalTermsandConditionsURL) {
		this.legalTermsandConditionsURL = legalTermsandConditionsURL;
	}

	@Override
	public String toString() {
		return "LegalTermsAndConditionsVO [legalTermsandConditionsURL="
				+ legalTermsandConditionsURL + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((legalTermsandConditionsURL == null) ? 0
						: legalTermsandConditionsURL.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegalTermsAndConditionsVO other = (LegalTermsAndConditionsVO) obj;
		if (legalTermsandConditionsURL == null) {
			if (other.legalTermsandConditionsURL != null)
				return false;
		} else if (!legalTermsandConditionsURL
				.equals(other.legalTermsandConditionsURL))
			return false;
		return true;
	}

}
