package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.PatientBadgesHistory;

@Repository
public interface PatientBadgesHistoryRepository extends JpaRepository<PatientBadgesHistory, Long> {
	
	List<PatientBadgesHistory> findByPatientId(String patientId);
	
	List<PatientBadgesHistory> findOneByPatientId(String patientId);
	
	@Query("from PatientBadgesHistory pbh where pbh.patientId = ?1 and pbh.badgesMasterId in ?2")
	List<PatientBadgesHistory> findOneByPatientIdBadgeMasterId(String patientId,List<Long> badgeMasterId);
	
	/*@Query("from PatientBadgesHistory pbh where pbh.patientId = ?1 and pbh.badgesMasterId = ?2 ")
	PatientBadgesHistory findOneByPatientIdAndBadgeMasterId(String patientId, Long badgeMasterId);*/
}
