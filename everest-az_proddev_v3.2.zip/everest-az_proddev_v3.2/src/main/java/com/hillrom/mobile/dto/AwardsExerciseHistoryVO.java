package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "activityId",
        "completedDate",
        "awardName",
        "awardType",
        "goalAchieved"
})
public class AwardsExerciseHistoryVO {
	@JsonProperty("pid")
    private String pid;

    @JsonProperty("activityId")
    private int activityId;
    @JsonProperty("completedDate")
    private int completedDate;
    @JsonProperty("awardName")
    private String awardName;
    @JsonProperty("awardType")
    private String awardType;
    @JsonProperty("goalAchieved")
    private boolean goalAchieved;

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public int getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(int completedDate) {
        this.completedDate = completedDate;
    }

    public String getAwardName() {
        return awardName;
    }

    public void setAwardName(String awardName) {
        this.awardName = awardName;
    }

    public String getAwardType() {
        return awardType;
    }

    public void setAwardType(String awardType) {
        this.awardType = awardType;
    }

    public boolean isGoalAchieved() {
        return goalAchieved;
    }

    public void setGoalAchieved(boolean goalAchieved) {
        this.goalAchieved = goalAchieved;
    }

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}
}
