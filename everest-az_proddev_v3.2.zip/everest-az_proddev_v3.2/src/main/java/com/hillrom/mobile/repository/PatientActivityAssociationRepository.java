package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.PatientActivityAssociation;

@Repository
public interface PatientActivityAssociationRepository extends JpaRepository<PatientActivityAssociation, Long> {

    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 ")
    List<PatientActivityAssociation> findByPatientId(String patientId);
    
    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId= ?2 and paa.isActive=true")
    List<PatientActivityAssociation> findActiveActivityByPatientIdandActivityTypeId(String patientId,Long activityTypeId);

    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.isActive=true")
    List<PatientActivityAssociation> findActiveActivityByPatientId(String patientId);
	
	@Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId= ?2")
    List<PatientActivityAssociation> findByPatientIdandActivityTypeId(String patientId,Long activityTypeId);

    @Query(nativeQuery=true,value=" SELECT count(*) from PATIENT_ACTIVITY_ASSOCIATION paa where paa.patient_id = ?1 and paa.is_active = false")
	 int findByPatientIdAndGoalISNotActive(String patientId);

	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId = ?2 and (paa.createdDate between ?3 and ?4)")
	 List<PatientActivityAssociation> findByPatientIdAndActivityTypeIdWithinRange(String patientId ,Long activityTypeId, Long from, Long to);

	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId = ?2 and paa.createdDate >= ?3")
	 List<PatientActivityAssociation> findByPatientIdAndActivityTypeIdSince(String patientId ,Long activityTypeId, Long from);

	@Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId = ?2 and paa.createdDate <= ?3")
	 List<PatientActivityAssociation> findByPatientIdAndActivityTypeIdTill(String patientId ,Long activityTypeId, Long to);

	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.id = ?2")
	 PatientActivityAssociation findByPatientIdAndId(String patientId, Long id);
	 
	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.id = ?2 and (paa.createdDate between ?3 and ?4)")
	 PatientActivityAssociation findByPatientIdAndIdWithinRange(String patientId ,Long Id, Long from, Long to);

	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.id = ?2 and paa.createdDate >= ?3")
	 PatientActivityAssociation findByPatientIdAndIdSince(String patientId ,Long Id, Long from);

	 @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.id = ?2 and paa.createdDate <= ?3")
	 PatientActivityAssociation findByPatientIdAndIdTill(String patientId ,Long Id, Long to);

	@Query("from PatientActivityAssociation paa where paa.patientId = ?1 and id= ?2")
    public List<PatientActivityAssociation> findByPatientIdandActivityId(String patientId,Long activityId);
	
	@Query("from PatientActivityAssociation where patientId = ?1 and activityTypeId = ?2")
	public List<PatientActivityAssociation> findPatientIdActivity(String pid, Long activityTypeId);
	
    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId = ?2 ")
    List<PatientActivityAssociation> findActivitiesByPatientId(String patientId,Long activityTypeid);

    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and paa.activityTypeId = ?2 and paa.id = ?3")
    PatientActivityAssociation findOneByPatientIdAndActivityTypeIdAndId(String patientId,Long activityTypeid, Long activityId);
    
    @Query("from PatientActivityAssociation paa where paa.patientId = ?1 and id= ?2 and paa.activityTypeId = ?3 and paa.isActive=true")
    public List<PatientActivityAssociation> findActiveActivityByPatientIdandActivityId(String patientId,Long activityId,Long activityTypeId);

    @Query(nativeQuery=true, value="SELECT dayname(?1)")
	String getDayNameFromDate(String date);
    
    //@Query("from PatientActivityAssociation paa where paa.isActive=true and paa.targetDate < unix_timestamp(curdate())")
    @Query(nativeQuery=true,value="SELECT * from PATIENT_ACTIVITY_ASSOCIATION paa where paa.is_active = true and paa.target_date < (unix_timestamp(curdate())*1000)")
    public List<PatientActivityAssociation> findActiveActivitiesWhichAreExpired();

}
