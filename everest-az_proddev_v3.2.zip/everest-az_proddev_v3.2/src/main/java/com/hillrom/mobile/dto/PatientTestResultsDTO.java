package com.hillrom.mobile.dto;

import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PatientTestResultsDTO {

	@JsonIgnore
	private String pid;

	private String comments;

	private Double fev1_L;

	private Double fev1_P;

	private Double fev1_TO_FVC_RATIO;

	private Double fvc_L;

	private Double fvc_P;

	private Double pef_L_Min;

	private Double pef_P;

	private LocalDate testResultDate;

	private String type = "CLINIC";

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Double getFev1_L() {
		return fev1_L;
	}

	public void setFev1_L(Double fev1_L) {
		this.fev1_L = fev1_L;
	}

	public Double getFev1_P() {
		return fev1_P;
	}

	public void setFev1_P(Double fev1_P) {
		this.fev1_P = fev1_P;
	}

	public Double getFev1_TO_FVC_RATIO() {
		return fev1_TO_FVC_RATIO;
	}

	public void setFev1_TO_FVC_RATIO(Double fev1_TO_FVC_RATIO) {
		this.fev1_TO_FVC_RATIO = fev1_TO_FVC_RATIO;
	}

	public Double getFvc_L() {
		return fvc_L;
	}

	public void setFvc_L(Double fvc_L) {
		this.fvc_L = fvc_L;
	}

	public Double getFvc_P() {
		return fvc_P;
	}

	public void setFvc_P(Double fvc_P) {
		this.fvc_P = fvc_P;
	}

	public Double getPef_L_Min() {
		return pef_L_Min;
	}

	public void setPef_L_Min(Double pef_L_Min) {
		this.pef_L_Min = pef_L_Min;
	}

	public Double getPef_P() {
		return pef_P;
	}

	public void setPef_P(Double pef_P) {
		this.pef_P = pef_P;
	}

	public LocalDate getTestResultDate() {
		return testResultDate;
	}

	public void setTestResultDate(LocalDate testResultDate) {
		this.testResultDate = testResultDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


	public PatientTestResultsDTO() {
		super();
	}

	public PatientTestResultsDTO(String pid, String comments, Double fev1_L,
			Double fev1_P, Double fev1_TO_FVC_RATIO, Double fvc_L,
			Double fvc_P, Double pef_L_Min, Double pef_P,
			LocalDate testResultDate, String type) {
		super();
		this.pid = pid;
		this.comments = comments;
		this.fev1_L = fev1_L;
		this.fev1_P = fev1_P;
		this.fev1_TO_FVC_RATIO = fev1_TO_FVC_RATIO;
		this.fvc_L = fvc_L;
		this.fvc_P = fvc_P;
		this.pef_L_Min = pef_L_Min;
		this.pef_P = pef_P;
		this.testResultDate = testResultDate;
		this.type = type;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((comments == null) ? 0 : comments.hashCode());
		result = prime * result + ((fev1_L == null) ? 0 : fev1_L.hashCode());
		result = prime * result + ((fev1_P == null) ? 0 : fev1_P.hashCode());
		result = prime
				* result
				+ ((fev1_TO_FVC_RATIO == null) ? 0 : fev1_TO_FVC_RATIO
						.hashCode());
		result = prime * result + ((fvc_L == null) ? 0 : fvc_L.hashCode());
		result = prime * result + ((fvc_P == null) ? 0 : fvc_P.hashCode());
		result = prime * result
				+ ((pef_L_Min == null) ? 0 : pef_L_Min.hashCode());
		result = prime * result + ((pef_P == null) ? 0 : pef_P.hashCode());
		result = prime * result + ((pid == null) ? 0 : pid.hashCode());
		result = prime * result
				+ ((testResultDate == null) ? 0 : testResultDate.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PatientTestResultsDTO other = (PatientTestResultsDTO) obj;
		if (comments == null) {
			if (other.comments != null)
				return false;
		} else if (!comments.equals(other.comments))
			return false;
		if (fev1_L == null) {
			if (other.fev1_L != null)
				return false;
		} else if (!fev1_L.equals(other.fev1_L))
			return false;
		if (fev1_P == null) {
			if (other.fev1_P != null)
				return false;
		} else if (!fev1_P.equals(other.fev1_P))
			return false;
		if (fev1_TO_FVC_RATIO == null) {
			if (other.fev1_TO_FVC_RATIO != null)
				return false;
		} else if (!fev1_TO_FVC_RATIO.equals(other.fev1_TO_FVC_RATIO))
			return false;
		if (fvc_L == null) {
			if (other.fvc_L != null)
				return false;
		} else if (!fvc_L.equals(other.fvc_L))
			return false;
		if (fvc_P == null) {
			if (other.fvc_P != null)
				return false;
		} else if (!fvc_P.equals(other.fvc_P))
			return false;
		if (pef_L_Min == null) {
			if (other.pef_L_Min != null)
				return false;
		} else if (!pef_L_Min.equals(other.pef_L_Min))
			return false;
		if (pef_P == null) {
			if (other.pef_P != null)
				return false;
		} else if (!pef_P.equals(other.pef_P))
			return false;
		if (pid == null) {
			if (other.pid != null)
				return false;
		} else if (!pid.equals(other.pid))
			return false;
		if (testResultDate == null) {
			if (other.testResultDate != null)
				return false;
		} else if (!testResultDate.equals(other.testResultDate))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "PatientTestResultsDTO [pid=" + pid + ", comments=" + comments
				+ ", fev1_L=" + fev1_L + ", fev1_P=" + fev1_P
				+ ", fev1_TO_FVC_RATIO=" + fev1_TO_FVC_RATIO + ", fvc_L="
				+ fvc_L + ", fvc_P=" + fvc_P + ", pef_L_Min=" + pef_L_Min
				+ ", pef_P=" + pef_P + ", testResultDate=" + testResultDate
				+ ", type=" + type + "]";
	}


}
