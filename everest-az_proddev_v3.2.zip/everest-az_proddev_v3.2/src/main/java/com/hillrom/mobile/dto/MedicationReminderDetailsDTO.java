package com.hillrom.mobile.dto;


public class MedicationReminderDetailsDTO{

	private Long id;
	
	private Long medicationRecordingsId;
	
	private String reminderDay;
	
	private Double reminderTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMedicationRecordingsId() {
		return medicationRecordingsId;
	}

	public void setMedicationRecordingsId(Long medicationRecordingsId) {
		this.medicationRecordingsId = medicationRecordingsId;
	}

	public String getReminderDay() {
		return reminderDay;
	}

	public void setReminderDay(String reminderDay) {
		this.reminderDay = reminderDay;
	}

	public Double getReminderTime() {
		return reminderTime;
	}

	public void setReminderTime(Double reminderTime) {
		this.reminderTime = reminderTime;
	}

	
	@Override
	public String toString() {
		return "MedicationReminderDetailsDto [id=" + id + ", reminderDay=" + reminderDay + ", reminderTime="
				+ reminderTime + "]";
	}

	public MedicationReminderDetailsDTO(Long medicationRecordingsId, String reminderDay, Double reminderTime) {
		super();
		this.medicationRecordingsId = medicationRecordingsId;
		this.reminderDay = reminderDay;
		this.reminderTime = reminderTime;
	}
	
}
