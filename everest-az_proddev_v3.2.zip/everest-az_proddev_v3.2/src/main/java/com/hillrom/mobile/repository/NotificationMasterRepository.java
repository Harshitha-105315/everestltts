package com.hillrom.mobile.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.NotificationMaster;



@Repository
public interface NotificationMasterRepository extends JpaRepository<NotificationMaster, Long>, QueryDslPredicateExecutor<NotificationMaster> {
	
	@Query("from NotificationMaster nm where nm.notificationCategory = ?1 and nm.notificationType = ?2")	
	NotificationMaster findByTypeAndCategory(String category, String type);
	
}