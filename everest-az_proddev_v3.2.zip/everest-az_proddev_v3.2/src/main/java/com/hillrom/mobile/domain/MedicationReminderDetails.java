package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "MEDICATION_REMINDER_DETAILS")
public class MedicationReminderDetails{

	@Id
	@JsonIgnore
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@JsonIgnore
//	@ManyToOne(optional=false,targetEntity=MedicationsRecordings.class)
//	@JoinColumn(name="medication_id",referencedColumnName="id")
	@Column(name="medication_recordings_id")
	private Long medicationRecordingsId;
	
	@Column(name="reminder_day")
	private String reminderDay;
	
	@Column(name="reminder_time")
	private String reminderTime;

	/*
	@Column(name="is_medication_taken_flag")
	private boolean isMedicationTakenFlag;
	
	@Column(name="actual_medication_taken")
	private DateTime actualMedicationTaken;*/
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMedicationRecordingsId() {
		return medicationRecordingsId;
	}

	public void setMedicationRecordingsId(Long medicationRecordingsId) {
		this.medicationRecordingsId = medicationRecordingsId;
	}

	public String getReminderDay() {
		return reminderDay;
	}

	public void setReminderDay(String reminderDay) {
		this.reminderDay = reminderDay;
	}

	public String getReminderTime() {
		return reminderTime;
	}

	public void setReminderTime(String reminderTime) {
		this.reminderTime = reminderTime;
	}

	

	public MedicationReminderDetails() {
		super();
	}

	

	public MedicationReminderDetails(Long medicationRecordingsId, String reminderDay, String reminderTime) {
		super();
		this.medicationRecordingsId = medicationRecordingsId;
		this.reminderDay = reminderDay;
		this.reminderTime = reminderTime;
	}

	@Override
	public String toString() {
		return "MedicationReminderDetails [id=" + id + ", medicationRecordingsId=" + medicationRecordingsId
				+ ", reminderDay=" + reminderDay + ", reminderTime=" + reminderTime + "]";
	}

	

}
