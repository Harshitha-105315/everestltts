package com.hillrom.mobile.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.hillrom.mobile.domain.ManageAppVersion;

@Repository
public interface ManageAppVersionRepository extends JpaRepository<ManageAppVersion, Long> {
	@Query("from ManageAppVersion mav where mav.version = ?1")
	ManageAppVersion findOneByVersion(String version);
	
	@Query("from ManageAppVersion mav where mav.type = ?1 and mav.is_active='1'")
	ManageAppVersion findOneByVersionAndType(String deviceType);
}
