package com.hillrom.mobile.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.security.SecurityUtils;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;
import com.hillrom.vest.web.rest.dto.ProtocolDTO;
import com.hillrom.vest.web.rest.dto.ProtocolEntryDTO;

@Service
@Transactional
public class PatientProtocolUnconnectedService {

	@Inject
	private UserRepository userRepository;

	@Inject
	private PatientProtocolMonarchRepository patientProtocolMonarchRepository;

	@Inject
	private PatientProtocolRepository patientProtocolRepository;

	@Inject
	private MailService mailService;

	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for (UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()) {
			if (RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())) {
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}

	public List<PatientProtocolData> addProtocolToUnconnectedVest(Long patientUserId, ProtocolDTO protocolDTO)
			throws HillromException {
		List<PatientProtocolData> protocolList = new LinkedList<>();
		
		User patientUser = userRepository.findOne(patientUserId);
		if (Objects.nonNull(patientUser)) {
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
			if (Objects.nonNull(patientInfo)) {
				String protocolKey = patientProtocolMonarchRepository.id();
				List<PatientProtocolData> ppdList = patientProtocolRepository.findByProtocolKey(protocolKey);
				if (ppdList != null) {
					Boolean isFirstPoint = true;

					for (ProtocolEntryDTO protocolEntryDTO : protocolDTO.getProtocolEntries()) {
						PatientProtocolData patientProtocolAssoc = new PatientProtocolData(protocolDTO.getType(),
								patientInfo, patientUser, protocolDTO.getTreatmentsPerDay(),
								protocolEntryDTO.getMinMinutesPerTreatment(), protocolEntryDTO.getMinFrequency(),
								protocolEntryDTO.getMinPressure(), protocolEntryDTO.getHmr());
						if (isFirstPoint) {
							patientProtocolAssoc.setId(protocolKey);
							isFirstPoint = false;
						} else {
							patientProtocolAssoc.setId(patientProtocolRepository.id());
						}
						patientProtocolAssoc.setProtocolKey(protocolKey);
						protocolList.add(patientProtocolAssoc);
					}
					patientProtocolRepository.save(protocolList);
				} else {
					throw new HillromException(ExceptionConstants.HR_523);
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_512);
			}
		}
		return protocolList;
	}

	@SuppressWarnings("null")
	public List<PatientProtocolData> updateProtocolToPatient(Long patientUserId, List<PatientProtocolData> patientProtocolDataList) throws HillromException {

		User patientUser = userRepository.findOne(patientUserId);
		if (Objects.nonNull(patientUser)) {
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
			if (Objects.nonNull(patientInfo)) {
				List<PatientProtocolData> protocolDataList = new LinkedList<>();
				int treatmentsPerDay = patientProtocolDataList.get(0).getTreatmentsPerDay();
				String type = patientProtocolDataList.get(0).getType();
				String protocolKey = patientProtocolDataList.get(0).getProtocolKey();
				// Check whether protocol type is same
				Boolean isFirstPoint = true;
				PatientProtocolData existingPPD = patientProtocolRepository.findOne(patientProtocolDataList.get(0).getId());
				//If not same
				if (Objects.nonNull(existingPPD) & !existingPPD.getType().equalsIgnoreCase(type)) {
					AtomicReference<String> protocolId = null;
					deleteProtocolForPatient(patientUserId, protocolKey);
					for (PatientProtocolData ppd : patientProtocolDataList) {
						if (isFirstPoint) {
							protocolKey = patientProtocolRepository.id();
							protocolId.set(protocolKey);
							isFirstPoint = false;
						} else {
							protocolId.set(patientProtocolRepository.id());
							addProtocolByProtocolKey(patientUser, patientInfo, patientProtocolDataList, treatmentsPerDay, type,
								protocolKey, ppd);
						}
					}
				} else {
					patientProtocolDataList.forEach(ppd -> {
						if (Objects.nonNull(ppd.getId())) {
							PatientProtocolData currentPPD = patientProtocolRepository.findOne(ppd.getId());
							if (Objects.nonNull(currentPPD)) {
								PatientProtocolUnconnectedService.this.assignValuesToPatientProtocolObj(ppd, currentPPD);
								patientProtocolRepository.saveAndFlush(currentPPD);
								patientProtocolDataList.add(currentPPD);
							}
						} else {
							String existingprotocolKey = patientProtocolDataList.get(0).getProtocolKey();
							PatientProtocolUnconnectedService.this.addProtocolByProtocolKey(patientUser, patientInfo, patientProtocolDataList, treatmentsPerDay, type,
									existingprotocolKey, ppd);
						}
					});
					try {
						if (Objects.nonNull(patientUser.getEmail())) {
							mailService.sendUpdateProtocolMailToPatient(patientUser, patientProtocolDataList);
						}
						if (SecurityContextHolder.getContext().getAuthentication()
								.getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.HCP)) || SecurityContextHolder.getContext()
								.getAuthentication()
								.getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.CLINIC_ADMIN))) {
							Optional<User> currentUser = userRepository
									.findOneByEmailOrHillromId(SecurityUtils.getCurrentLogin());
							mailService.sendUpdateProtocolMailToMailingList(currentUser.get(), patientUser, patientProtocolDataList);
						}
					} catch (Exception ex) {
						StringWriter writer = new StringWriter();
						PrintWriter printWriter = new PrintWriter(writer);
						ex.printStackTrace(printWriter);
					}
					return protocolDataList;
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_523);
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);
		}

		return patientProtocolDataList;
	}

	private void assignValuesToPatientProtocolObj(PatientProtocolData updateProtocol, PatientProtocolData currentProtocol) {
		if(Objects.nonNull(updateProtocol.getTreatmentsPerDay()))
			currentProtocol.setTreatmentsPerDay(updateProtocol.getTreatmentsPerDay());
		if(Objects.nonNull(updateProtocol.getTreatmentLabel()))
			currentProtocol.setTreatmentLabel(updateProtocol.getTreatmentLabel());
		if(Objects.nonNull(updateProtocol.getMinMinutesPerTreatment()))
			currentProtocol.setMinMinutesPerTreatment(updateProtocol.getMinMinutesPerTreatment());
		if(Objects.nonNull(updateProtocol.getMinFrequency()))
			currentProtocol.setMinFrequency(updateProtocol.getMinFrequency());
		if(Objects.nonNull(updateProtocol.getMinPressure()))
			currentProtocol.setMinPressure(updateProtocol.getMinPressure());
		if(Objects.nonNull(updateProtocol.getHmr()))
			currentProtocol.setHmr(updateProtocol.getHmr());
	}

	private void addProtocolByProtocolKey(User patientUser, PatientInfo patientInfo, List<PatientProtocolData> patientProtocolDataList,
										  int treatmentsPerDay, String type, String protocolKey, PatientProtocolData ppd){
		PatientProtocolData patientProtocolAssoc = new PatientProtocolData(type,
				patientInfo, patientUser, treatmentsPerDay,
				ppd.getMinMinutesPerTreatment(), ppd.getMinFrequency(),
				ppd.getMinPressure(), ppd.getHmr());
		patientProtocolAssoc.setId(patientProtocolRepository.id());
		patientProtocolAssoc.setProtocolKey(protocolKey);
		patientProtocolAssoc.setLastModifiedDate(DateTime.now());
		patientProtocolRepository.saveAndFlush(patientProtocolAssoc);
		patientProtocolDataList.add(patientProtocolAssoc);

	}

	public String deleteProtocolForPatient(Long patientUserId, String protocolId) throws HillromException{
		User patientUser = userRepository.findOne(patientUserId);
		if(Objects.nonNull(patientUser)){
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
			if(Objects.nonNull(patientInfo)){
				List<PatientProtocolData> protocolList = patientProtocolRepository.findByProtocolKey(protocolId);
				if(protocolList.isEmpty()){
					throw new HillromException(ExceptionConstants.HR_551);
				} else {
					for (PatientProtocolData protocol : protocolList) {
						protocol.setDeleted(true);
						protocol.setLastModifiedDate(new DateTime().minusSeconds(1));
						patientProtocolRepository.save(protocol);
					}
					return MessageConstants.HR_244;
				}
			} else {
				throw new HillromException(ExceptionConstants.HR_523);
			}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);
		}
	}

}