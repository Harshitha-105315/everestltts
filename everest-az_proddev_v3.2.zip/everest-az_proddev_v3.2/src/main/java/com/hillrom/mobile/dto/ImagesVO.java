package com.hillrom.mobile.dto;

import java.util.List;

import com.hillrom.mobile.domain.BadgesMaster;
import com.hillrom.mobile.domain.ImageMaster;
import com.hillrom.mobile.domain.MobileEmoji;

 public class ImagesVO {
 	
	private List<BadgesMaster> badgesList;
	private List<AwardMasterVO> awardsList;
	private List<MobileEmoji> emojiList;
	private List<ImageMaster> imageList;
	
	public List<BadgesMaster> getBadgesList() {
		return badgesList;
	}
	public void setBadgesList(List<BadgesMaster> badgesList) {
		this.badgesList = badgesList;
	}
	public List<AwardMasterVO> getAwardsList() {
		return awardsList;
	}
	public void setAwardsList(List<AwardMasterVO> awardsList) {
		this.awardsList = awardsList;
	}
	public List<MobileEmoji> getEmojiList() {
		return emojiList;
	}
	public void setEmojiList(List<MobileEmoji> emojiList) {
		this.emojiList = emojiList;
	}
	public List<ImageMaster> getImageList() {
		return imageList;
	}
	public void setImageList(List<ImageMaster> imageList) {
		this.imageList = imageList;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((awardsList == null) ? 0 : awardsList.hashCode());
		result = prime * result + ((badgesList == null) ? 0 : badgesList.hashCode());
		result = prime * result + ((emojiList == null) ? 0 : emojiList.hashCode());
		result = prime * result + ((imageList == null) ? 0 : imageList.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ImagesVO other = (ImagesVO) obj;
		if (awardsList == null) {
			if (other.awardsList != null)
				return false;
		} else if (!awardsList.equals(other.awardsList))
			return false;
		if (badgesList == null) {
			if (other.badgesList != null)
				return false;
		} else if (!badgesList.equals(other.badgesList))
			return false;
		if (emojiList == null) {
			if (other.emojiList != null)
				return false;
		} else if (!emojiList.equals(other.emojiList))
			return false;
		if (imageList == null) {
			if (other.imageList != null)
				return false;
		} else if (!imageList.equals(other.imageList))
			return false;
		return true;
	}
	public ImagesVO(List<BadgesMaster> badgesList, List<AwardMasterVO> awardsList, List<MobileEmoji> emojiList,
			List<ImageMaster> imageList) {
		super();
		this.badgesList = badgesList;
		this.awardsList = awardsList;
		this.emojiList = emojiList;
		this.imageList = imageList;
	}
	public ImagesVO() {
		super();
		// TODO Auto-generated constructor stub
	}	
}
