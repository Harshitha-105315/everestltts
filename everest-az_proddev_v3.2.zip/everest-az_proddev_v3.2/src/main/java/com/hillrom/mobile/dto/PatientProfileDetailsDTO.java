package com.hillrom.mobile.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class PatientProfileDetailsDTO {

	@ApiModelProperty(notes="patient_Id (String)", dataType="java.lang.String", required=true)
	private String patient_Id;
	@ApiModelProperty(notes="patientName (String)", dataType="java.lang.String", required=true)
	private String patientName;
	@ApiModelProperty(notes="email (String)", dataType="java.lang.String", required=true)
	private String email;
	@ApiModelProperty(notes="profilePictureURL (String)", dataType="java.lang.String", required=true)
	private String profilePictureURL;
	@ApiModelProperty(notes="timeZone (String)", dataType="java.lang.String", required=true)
	private String timeZone;
	@ApiModelProperty(notes="careGiverList", required=true)
	private List<String> careGiverList;
	@ApiModelProperty(notes="mailingAddress (String)", dataType="java.lang.String", required=true)
	private String mailingAddress;
	@ApiModelProperty(notes="primaryPhoneNumber (String)", dataType="java.lang.String", required=true)
	private String primaryPhoneNumber;
	@ApiModelProperty(notes="mobilePhoneNumber (String)", dataType="java.lang.String", required=true)
	private String mobilePhoneNumber;
	@ApiModelProperty(notes="devicesDetails", required=true)
	private List<DeviceDetailsDataVO> devicesDetails;
	@ApiModelProperty(notes="clinicsAndMedicalTeam", required=true)
	private List<MedicalTeamVO> clinicsAndMedicalTeam;
	@ApiModelProperty(notes="reminderSettings (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean reminderSettings;
	@ApiModelProperty(notes="notificationSettings (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean notificationSettings;
	@ApiModelProperty(notes="deviationAlerts (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean deviationAlerts;
	@ApiModelProperty(notes="rtuSettings (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean rtuSettings;
	@ApiModelProperty(notes="newTherapySettings (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean newTherapySettings;
	
	public List<DeviceDetailsDataVO> getDevicesDetails() {
		return devicesDetails;
	}
	public void setDevicesDetails(List<DeviceDetailsDataVO> devicesDetails) {
		this.devicesDetails = devicesDetails;
	}
	public String getPatient_Id() {
		return patient_Id;
	}
	public void setPatient_Id(String patient_Id) {
		this.patient_Id = patient_Id;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getProfilePictureURL() {
		return profilePictureURL;
	}
	public void setProfilePictureURL(String profilePictureURL) {
		this.profilePictureURL = profilePictureURL;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public List<String> getCareGiverList() {
		return careGiverList;
	}
	public void setCareGiverList(List<String> careGiverList) {
		this.careGiverList = careGiverList;
	}
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}
	public void setPrimaryPhoneNumber(String primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}
	public String getMobilePhoneNumber() {
		return mobilePhoneNumber;
	}
	public void setMobilePhoneNumber(String mobilePhoneNumber) {
		this.mobilePhoneNumber = mobilePhoneNumber;
	}
	public List<MedicalTeamVO> getClinicsAndMedicalTeam() {
		return clinicsAndMedicalTeam;
	}
	public void setClinicsAndMedicalTeam(List<MedicalTeamVO> clinicsAndMedicalTeam) {
		this.clinicsAndMedicalTeam = clinicsAndMedicalTeam;
	}
	public Boolean getReminderSettings() {
		return reminderSettings;
	}
	public void setReminderSettings(Boolean reminderSettings) {
		this.reminderSettings = reminderSettings;
	}
	public Boolean getNotificationSettings() {
		return notificationSettings;
	}
	public void setNotificationSettings(Boolean notificationSettings) {
		this.notificationSettings = notificationSettings;
	}
	public Boolean getDeviationAlerts() {
		return deviationAlerts;
	}
	public void setDeviationAlerts(Boolean deviationAlerts) {
		this.deviationAlerts = deviationAlerts;
	}
	public Boolean getRtuSettings() {
		return rtuSettings;
	}
	public void setRtuSettings(Boolean rtuSettings) {
		this.rtuSettings = rtuSettings;
	}
	public Boolean getNewTherapySettings() {
		return newTherapySettings;
	}
	public void setNewTherapySettings(Boolean newTherapySettings) {
		this.newTherapySettings = newTherapySettings;
	}
	public PatientProfileDetailsDTO(String patient_Id, String patientName, String email, String profilePicture,
			String timeZone, List<String> careGiverList, String mailingAddress, String primaryPhoneNumber,
			String mobilePhoneNumber, List<DeviceDetailsDataVO> devices, List<MedicalTeamVO> clinicsAndMedicalTeam,
			Boolean reminderSettings, Boolean notificationSettings, Boolean deviationAlerts, Boolean rtuSettings, Boolean newTherapySettings) {
		super();
		this.patient_Id = patient_Id;
		this.patientName = patientName;
		this.email = email;
		this.profilePictureURL = profilePicture;
		this.timeZone = timeZone;
		this.careGiverList = careGiverList;
		this.mailingAddress = mailingAddress;
		this.primaryPhoneNumber = primaryPhoneNumber;
		this.mobilePhoneNumber = mobilePhoneNumber;
		this.devicesDetails = devices;
		this.clinicsAndMedicalTeam = clinicsAndMedicalTeam;
		this.reminderSettings = reminderSettings;
		this.notificationSettings = notificationSettings;
		this.deviationAlerts = deviationAlerts;
		this.rtuSettings = rtuSettings;
		this.newTherapySettings = newTherapySettings;
	}
	public PatientProfileDetailsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PatientProfileDetailsDTO [patient_Id=" + patient_Id + ", patientName=" + patientName + ", email="
				+ email + ", profilePictureURL=" + profilePictureURL + ", timeZone=" + timeZone + ", careGiverList="
				+ careGiverList + ", mailingAddress=" + mailingAddress + ", primaryPhoneNumber=" + primaryPhoneNumber
				+ ", mobilePhoneNumber=" + mobilePhoneNumber + ", devicesDetails=" + devicesDetails + ", clinicsAndMedicalTeam="
				+ clinicsAndMedicalTeam + ", reminderSettings=" + reminderSettings + ", notificationSettings="
				+ notificationSettings + ", deviationAlerts=" + deviationAlerts + ", rtuSettings=" + rtuSettings + ", newTherapySettings=" +newTherapySettings+"]";
	}

}
