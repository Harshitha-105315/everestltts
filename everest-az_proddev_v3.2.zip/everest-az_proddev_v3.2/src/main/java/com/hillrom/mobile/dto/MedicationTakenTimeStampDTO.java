package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class MedicationTakenTimeStampDTO {

	@ApiModelProperty(notes="isTaken (Boolean)", dataType="java.lang.Boolean", required=true)
	private Boolean isTaken;
	
	@ApiModelProperty(notes="takenTimestamp (Boolean)", dataType="java.lang.Long", required=true)
	private Long takenTimestamp;

	public Boolean getIsTaken() {
		return isTaken;
	}

	public void setIsTaken(Boolean isTaken) {
		this.isTaken = isTaken;
	}

	public Long getTakenTimestamp() {
		return takenTimestamp;
	}

	public void setTakenTimestamp(Long takenTimestamp) {
		this.takenTimestamp = takenTimestamp;
	}

	public MedicationTakenTimeStampDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
