package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "awardId",
        "awardName",
        "date",
        "isAchieved",
        "activityId"
})

public class AwardsWeightHistoryVO {
	 
	@JsonProperty("pid")
	private String pid;

    @JsonProperty("awardId")
    private Integer awardId;
    @JsonProperty("awardName")
    private String awardName;
    @JsonProperty("date")
    private Integer date;
    @JsonProperty("isAchieved")
    private Boolean isAchieved;
    @JsonProperty("activityId")
    private Integer activityId;


    @JsonProperty("awardId")
    public Integer getAwardId() {
        return awardId;
    }

    @JsonProperty("awardId")
    public void setAwardId(Integer awardId) {
        this.awardId = awardId;
    }

    @JsonProperty("awardName")
    public String getAwardName() {
        return awardName;
    }

    @JsonProperty("awardName")
    public void setAwardName(String awardName) {
        this.awardName = awardName;
    }

    @JsonProperty("date")
    public Integer getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(Integer date) {
        this.date = date;
    }

    @JsonProperty("isAchieved")
    public Boolean getIsAchieved() {
        return isAchieved;
    }

    @JsonProperty("isAchieved")
    public void setIsAchieved(Boolean isAchieved) {
        this.isAchieved = isAchieved;
    }

    @JsonProperty("activityId")
    public Integer getActivityId() {
        return activityId;
    }

    @JsonProperty("activityId")
    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	
}
