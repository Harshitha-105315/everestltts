package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class ProtocolDataListVO {
	
	@ApiModelProperty(notes="protocolType (String)", dataType="java.lang.String", required=true)
	private String protocolType;
	@ApiModelProperty(notes="minFrequency (String)", dataType="java.lang.String", required=true)
	private String minFrequency;
	@ApiModelProperty(notes="maxFrequency (String)", dataType="java.lang.String", required=true)
	private String maxFrequency;
	@ApiModelProperty(notes="minPressure (String)", dataType="java.lang.String", required=true)
	private String minPressure;
	@ApiModelProperty(notes="maxPressure (String)", dataType="java.lang.String", required=true)
	private String maxPressure;
	@ApiModelProperty(notes="min_minutes_per_treatment (String)", dataType="java.lang.String", required=true)
	private String min_minutes_per_treatment;
	@ApiModelProperty(notes="max_minutes_per_treatment (String)", dataType="java.lang.String", required=true)
	private String max_minutes_per_treatment;
	@ApiModelProperty(notes="treatments_per_day (String)", dataType="java.lang.String", required=true)
	private String treatments_per_day;
	@JsonIgnore
	private String deviceType;
	
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getProtocolType() {
		return protocolType;
	}
	public void setProtocolType(String protocolType) {
		this.protocolType = protocolType;
	}
	public String getMinFrequency() {
		return minFrequency;
	}
	public void setMinFrequency(String minFrequency) {
		this.minFrequency = minFrequency;
	}
	public String getMaxFrequency() {
		return maxFrequency;
	}
	public void setMaxFrequency(String maxFrequency) {
		this.maxFrequency = maxFrequency;
	}
	public String getMinPressure() {
		return minPressure;
	}
	public void setMinPressure(String minPressure) {
		this.minPressure = minPressure;
	}
	public String getMaxPressure() {
		return maxPressure;
	}
	public void setMaxPressure(String maxPressure) {
		this.maxPressure = maxPressure;
	}
	public String getMin_minutes_per_treatment() {
		return min_minutes_per_treatment;
	}
	public void setMin_minutes_per_treatment(String min_minutes_per_treatment) {
		this.min_minutes_per_treatment = min_minutes_per_treatment;
	}
	public String getMax_minutes_per_treatment() {
		return max_minutes_per_treatment;
	}
	public void setMax_minutes_per_treatment(String max_minutes_per_treatment) {
		this.max_minutes_per_treatment = max_minutes_per_treatment;
	}
	public String getTreatments_per_day() {
		return treatments_per_day;
	}
	public void setTreatments_per_day(String treatments_per_day) {
		this.treatments_per_day = treatments_per_day;
	}
	
	@Override
	public String toString() {
		return "ProtocolDataListVO [protocolType=" + protocolType + ", minFrequency=" + minFrequency + ", maxFrequency="
				+ maxFrequency + ", minPressure=" + minPressure + ", maxPressure=" + maxPressure
				+ ", min_minutes_per_treatment=" + min_minutes_per_treatment + ", max_minutes_per_treatment="
				+ max_minutes_per_treatment + ", treatments_per_day=" + treatments_per_day + ", deviceType="
				+ deviceType + ", minIntensity=" + "]";
	}
	public ProtocolDataListVO(String protocolType, String minFrequency, String maxFrequency, String minPressure,
			String maxPressure, String min_minutes_per_treatment, String max_minutes_per_treatment,
			String treatments_per_day, String deviceType) {
		super();
		this.protocolType = protocolType;
		this.minFrequency = minFrequency;
		this.maxFrequency = maxFrequency;
		this.minPressure = minPressure;
		this.maxPressure = maxPressure;
		this.min_minutes_per_treatment = min_minutes_per_treatment;
		this.max_minutes_per_treatment = max_minutes_per_treatment;
		this.treatments_per_day = treatments_per_day;
		this.deviceType = deviceType;
	}	
	
	public ProtocolDataListVO(String protocolType, String minFrequency, String maxFrequency, String minPressure,String maxPressure, String min_minutes_per_treatment, String max_minutes_per_treatment,	
		String treatments_per_day) {
		super();
		this.protocolType = protocolType;
		this.minFrequency = minFrequency;	
		this.maxFrequency = maxFrequency;	
		this.minPressure = minPressure;	
		this.maxPressure = maxPressure;	
		this.min_minutes_per_treatment = min_minutes_per_treatment;	
		this.max_minutes_per_treatment = max_minutes_per_treatment;	
		this.treatments_per_day = treatments_per_day;
	}
	public ProtocolDataListVO() {
		super();
	}
	
	
}
