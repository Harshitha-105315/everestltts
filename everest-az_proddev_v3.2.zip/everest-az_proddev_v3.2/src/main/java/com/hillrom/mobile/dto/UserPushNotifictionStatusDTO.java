package com.hillrom.mobile.dto;

import java.util.List;

public class UserPushNotifictionStatusDTO {
	private String pid;
	List<NotificationReadStatusDTO> notificationReadStatusList;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public List<NotificationReadStatusDTO> getNotificationReadStatusList() {
		return notificationReadStatusList;
	}
	public void setNotificationReadStatusList(List<NotificationReadStatusDTO> notificationReadStatusList) {
		this.notificationReadStatusList = notificationReadStatusList;
	}
	public UserPushNotifictionStatusDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserPushNotifictionStatusDTO [pid=" + pid + ", notificationReadStatusList=" + notificationReadStatusList
				+ "]";
	}
	
	
}
