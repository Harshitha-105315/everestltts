package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "Completed Date",
        "Name",
        "Achieved goal",
        "AwardType",
        "activityId"
})
public class AwardsNutritionHistoryVO {

	@JsonProperty("pid")
    private String pid;
    @JsonProperty("Completed Date")
    private int completedDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Achieved goal")
    private boolean achievedGoal;
    @JsonProperty("AwardType")
    private String awardType;
    @JsonProperty("activityId")
    private int activityId;

    @JsonProperty("Completed Date")
    public int getCompletedDate() {
        return completedDate;
    }

    @JsonProperty("Completed Date")
    public void setCompletedDate(int completedDate) {
        this.completedDate = completedDate;
    }

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Achieved goal")
    public boolean isAchievedGoal() {
        return achievedGoal;
    }

    @JsonProperty("Achieved goal")
    public void setAchievedGoal(boolean achievedGoal) {
        this.achievedGoal = achievedGoal;
    }

    @JsonProperty("AwardType")
    public String getAwardType() {
        return awardType;
    }

    @JsonProperty("AwardType")
    public void setAwardType(String awardType) {
        this.awardType = awardType;
    }

    @JsonProperty("activityId")
    public int getActivityId() {
        return activityId;
    }

    @JsonProperty("activityId")
    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

}
