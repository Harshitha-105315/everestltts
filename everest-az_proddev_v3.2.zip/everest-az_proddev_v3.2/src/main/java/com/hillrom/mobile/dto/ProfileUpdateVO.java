package com.hillrom.mobile.dto;

public class ProfileUpdateVO {
	private Long userId;
	private String emailId;
	public boolean isPictureUpdated;	
	private long profilePictureType;
	private String profilePictureImage;
	private String password;
	private String timeZone;
	private String primaryPhone;
	private String secondaryPhone;
	private boolean remindersSetting;
	private boolean notificationsSetting;
	private boolean achievementsSetting;
	private boolean deviationAlert;
	private boolean rtpSetting;
	private boolean newTherapySetting;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public boolean isPictureUpdated() {
		return isPictureUpdated;
	}
	public void setPictureUpdated(boolean isPictureUpdated) {
		this.isPictureUpdated = isPictureUpdated;
	}
	public long getProfilePictureType() {
		return profilePictureType;
	}
	public void setProfilePictureType(long profilePictureType) {
		this.profilePictureType = profilePictureType;
	}
	public String getProfilePictureImage() {
		return profilePictureImage;
	}
	public void setProfilePictureImage(String profilePictureImage) {
		this.profilePictureImage = profilePictureImage;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getPrimaryPhone() {
		return primaryPhone;
	}
	public void setPrimaryPhone(String primaryPhone) {
		this.primaryPhone = primaryPhone;
	}
	public String getSecondaryPhone() {
		return secondaryPhone;
	}
	public void setSecondaryPhone(String secondaryPhone) {
		this.secondaryPhone = secondaryPhone;
	}
	public boolean isRemindersSetting() {
		return remindersSetting;
	}
	public void setRemindersSetting(boolean remindersSetting) {
		this.remindersSetting = remindersSetting;
	}
	public boolean isNotificationsSetting() {
		return notificationsSetting;
	}
	public void setNotificationsSetting(boolean notificationsSetting) {
		this.notificationsSetting = notificationsSetting;
	}
	public boolean isDeviationAlert() {
		return deviationAlert;
	}
	public void setDeviationAlert(boolean deviationAlert) {
		this.deviationAlert = deviationAlert;
	}
	public boolean isAchievementsSetting() {
		return achievementsSetting;
	}
	public void setAchievementsSetting(boolean achievementsSetting) {
		this.achievementsSetting = achievementsSetting;
	}
	public boolean isRtpSetting() {
		return rtpSetting;
	}
	public void setRtpSetting(boolean rtpSetting) {
		this.rtpSetting = rtpSetting;
	}
	public boolean isNewTherapySetting() {
		return newTherapySetting;
	}
	public void setNewTherapySetting(boolean newTherapySetting) {
		this.newTherapySetting = newTherapySetting;
	}
	

	@Override
	public String toString() {
		return "ProfileUpdateVO [userId=" + userId + ", emailId=" + emailId + ", isPictureUpdated=" + isPictureUpdated
				+ ", profilePictureType=" + profilePictureType + ", profilePictureImage=" + profilePictureImage
				+ ", password=" + password + ", timeZone=" + timeZone + ", primaryPhone=" + primaryPhone
				+ ", secondaryPhone=" + secondaryPhone + ", remindersSetting=" + remindersSetting
				+ ", notificationsSetting=" + notificationsSetting + ", achievementsSetting=" + achievementsSetting
				+ ", deviationAlert=" + deviationAlert + ", rtpSetting=" + rtpSetting + ", newTherapySetting="
				+ newTherapySetting + "]";
	}
}
