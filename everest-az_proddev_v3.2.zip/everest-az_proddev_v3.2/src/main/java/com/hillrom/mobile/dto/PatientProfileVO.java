package com.hillrom.mobile.dto;

public class PatientProfileVO {
	
	private String patientId;
	private String email;
	private String pFirstName;
	private String pLastName;
	private String deviceName;
	private String deviceColor;
	private String deviceSize;
	private String timeZone;
	private String profilePicture;
	private String careGiver;
	private String mailingAddress;
	private String primaryPhoneNumber;
	private String secondaryPhoneNumber;
	private String serialNumber;
	private Boolean isManual;
	private Boolean isActive;
	private String clinicName;
	private String clinicAddress;
	private String clinicPhoneNumber;
	private String caName;
	private String caCredentials;
	private String caPhoneNumber;
	private String hcpName;
	private String hcpCredentials;
	private String hcpPhoneNumber;
	private Boolean reminderSettings;
	private Boolean notificationSettings;
	private Boolean deviationSettings;
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getpFirstName() {
		return pFirstName;
	}
	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}
	public String getpLastName() {
		return pLastName;
	}
	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDeviceColor() {
		return deviceColor;
	}
	public void setDeviceColor(String deviceColor) {
		this.deviceColor = deviceColor;
	}
	public String getDeviceSize() {
		return deviceSize;
	}
	public void setDeviceSize(String deviceSize) {
		this.deviceSize = deviceSize;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getProfilePicture() {
		return profilePicture;
	}
	public void setProfilePicture(String profilePicture) {
		this.profilePicture = profilePicture;
	}
	public String getCareGiver() {
		return careGiver;
	}
	public void setCareGiver(String careGiver) {
		this.careGiver = careGiver;
	}
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}
	public void setPrimaryPhoneNumber(String primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}
	public String getSecondaryPhoneNumber() {
		return secondaryPhoneNumber;
	}
	public void setSecondaryPhoneNumber(String secondaryPhoneNumber) {
		this.secondaryPhoneNumber = secondaryPhoneNumber;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Boolean getIsManual() {
		return isManual;
	}
	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getClinicAddress() {
		return clinicAddress;
	}
	public void setClinicAddress(String clinicAddress) {
		this.clinicAddress = clinicAddress;
	}
	public String getClinicPhoneNumber() {
		return clinicPhoneNumber;
	}
	public void setClinicPhoneNumber(String clinicPhoneNumber) {
		this.clinicPhoneNumber = clinicPhoneNumber;
	}
	public String getCaName() {
		return caName;
	}
	public void setCaName(String caName) {
		this.caName = caName;
	}
	public String getCaCredentials() {
		return caCredentials;
	}
	public void setCaCredentials(String caCredentials) {
		this.caCredentials = caCredentials;
	}
	public String getCaPhoneNumber() {
		return caPhoneNumber;
	}
	public void setCaPhoneNumber(String caPhoneNumber) {
		this.caPhoneNumber = caPhoneNumber;
	}
	public String getHcpName() {
		return hcpName;
	}
	public void setHcpName(String hcpName) {
		this.hcpName = hcpName;
	}
	public String getHcpCredentials() {
		return hcpCredentials;
	}
	public void setHcpCredentials(String hcpCredentials) {
		this.hcpCredentials = hcpCredentials;
	}
	public String getHcpPhoneNumber() {
		return hcpPhoneNumber;
	}
	public void setHcpPhoneNumber(String hcpPhoneNumber) {
		this.hcpPhoneNumber = hcpPhoneNumber;
	}
	public Boolean getReminderSettings() {
		return reminderSettings;
	}
	public void setReminderSettings(Boolean reminderSettings) {
		this.reminderSettings = reminderSettings;
	}
	public Boolean getNotificationSettings() {
		return notificationSettings;
	}
	public void setNotificationSettings(Boolean notificationSettings) {
		this.notificationSettings = notificationSettings;
	}
	public Boolean getDeviationSettings() {
		return deviationSettings;
	}
	public void setDeviationSettings(Boolean deviationSettings) {
		this.deviationSettings = deviationSettings;
	}
	public PatientProfileVO(String patientId, String email, String pFirstName, String pLastName, String deviceName,
			String deviceColor, String deviceSize, String timeZone, String profilePicture, String careGiver,
			String mailingAddress, String primaryPhoneNumber, String secondaryPhoneNumber, String serialNumber,
			Boolean isManual, Boolean isActive, String clinicName, String clinicAddress, String clinicPhoneNumber,
			String caName, String caCredentials, String caPhoneNumber, String hcpName, String hcpCredentials,
			String hcpPhoneNumber, Boolean reminderSettings, Boolean notificationSettings, Boolean deviationSettings) {
		super();
		this.patientId = patientId;
		this.email = email;
		this.pFirstName = pFirstName;
		this.pLastName = pLastName;
		this.deviceName = deviceName;
		this.deviceColor = deviceColor;
		this.deviceSize = deviceSize;
		this.timeZone = timeZone;
		this.profilePicture = profilePicture;
		this.careGiver = careGiver;
		this.mailingAddress = mailingAddress;
		this.primaryPhoneNumber = primaryPhoneNumber;
		this.secondaryPhoneNumber = secondaryPhoneNumber;
		this.serialNumber = serialNumber;
		this.isManual = isManual;
		this.isActive = isActive;
		this.clinicName = clinicName;
		this.clinicAddress = clinicAddress;
		this.clinicPhoneNumber = clinicPhoneNumber;
		this.caName = caName;
		this.caCredentials = caCredentials;
		this.caPhoneNumber = caPhoneNumber;
		this.hcpName = hcpName;
		this.hcpCredentials = hcpCredentials;
		this.hcpPhoneNumber = hcpPhoneNumber;
		this.reminderSettings = reminderSettings;
		this.notificationSettings = notificationSettings;
		this.deviationSettings = deviationSettings;
	}
	public PatientProfileVO() {
		super();
		// TODO Auto-generated constructor stub
	}
}

