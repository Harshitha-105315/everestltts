package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.PatientProtocolData;

public interface PatientProtocolDataRepository extends JpaRepository<PatientProtocolData, String> {
	
	@Query("from PatientProtocolData ppd where ppd.patient.id = ?1 group by ppd.protocolKey")
	List<PatientProtocolData> findByPatientId(String patientId);
	
	List<PatientProtocolData> findByProtocolKey(String protocolKey);
	
}
