package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 * A PATIENT_AWARD_HISTORY.
 */
@Entity
@Table(name = "PATIENT_AWARD_HISTORY")
public class PatientAwardHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;

    @Column(name = "AWARD_MASTER_ID")
    //@ManyToMany(targetEntity = AwardMaster.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "ID", nullable = false)
    private Long awardMasterId;

    @Column(name = "PATIENT_ID")
    //@OneToMany(targetEntity=PatientInfo.class,fetch=FetchType.LAZY)
    @JoinColumn(name = "ID", nullable = false)
    private String patientId;

    @Column(name = "RECEIVED_DATE")
    private Long receivedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAwardMasterId() {
		return awardMasterId;
	}

	public void setAwardMasterId(Long awardMasterId) {
		this.awardMasterId = awardMasterId;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public Long getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(Long receivedDate) {
		this.receivedDate = receivedDate;
	}

	}
