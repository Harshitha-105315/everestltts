package com.hillrom.mobile.dto;

import java.util.List;


public class MedicationTakenListDTO {
	//private String patientId;
	private List<MedicationTakenDTO> medicationTakenList;

	public List<MedicationTakenDTO> getMedicationTakenList() {
		return medicationTakenList;
	}

	public void setMedicationTakenList(List<MedicationTakenDTO> medicationTakenList) {
		this.medicationTakenList = medicationTakenList;
	}

	/*public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}*/
	
	

}
