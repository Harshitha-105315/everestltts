package com.hillrom.mobile.dto;

public class BYODPairInfo {
	private Long lastUpdated;
	private String deviceIdentifier;
	/**
	 * @return the lastUpdated
	 */
	public Long getLastUpdated() {
		return lastUpdated;
	}
	/**
	 * @param lastUpdated the lastUpdated to set
	 */
	public void setLastUpdated(Long lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	/**
	 * @return the deviceIdentifier
	 */
	public String getDeviceIdentifier() {
		return deviceIdentifier;
	}
	/**
	 * @param deviceIdentifier the deviceIdentifier to set
	 */
	public void setDeviceIdentifier(String deviceIdentifier) {
		this.deviceIdentifier = deviceIdentifier;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deviceIdentifier == null) ? 0 : deviceIdentifier.hashCode());
		result = prime * result + ((lastUpdated == null) ? 0 : lastUpdated.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BYODPairInfo other = (BYODPairInfo) obj;
		if (deviceIdentifier == null) {
			if (other.deviceIdentifier != null)
				return false;
		} else if (!deviceIdentifier.equals(other.deviceIdentifier))
			return false;
		if (lastUpdated == null) {
			if (other.lastUpdated != null)
				return false;
		} else if (!lastUpdated.equals(other.lastUpdated))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BYODPairInfo [lastUpdated=" + lastUpdated + ", deviceIdentifier=" + deviceIdentifier + "]";
	}
	
	public BYODPairInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
}
