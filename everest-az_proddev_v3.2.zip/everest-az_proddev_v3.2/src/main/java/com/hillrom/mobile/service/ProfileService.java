package com.hillrom.mobile.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.io.Files;
import com.hillrom.mobile.domain.ManageAppVersion;
import com.hillrom.mobile.domain.MobileDeviceInfo;
import com.hillrom.mobile.dto.AwardAndBadgesVersionNumberVO;
import com.hillrom.mobile.dto.BYODOptOutInfo;
import com.hillrom.mobile.dto.BYODPairInfo;
import com.hillrom.mobile.dto.BYODUpdateDTO;
import com.hillrom.mobile.dto.BYODUpdateDeviceInfo;
import com.hillrom.mobile.dto.BasicDetailsDTO;
import com.hillrom.mobile.dto.BasicInfoDetailsVO;
import com.hillrom.mobile.dto.ChartbasicsVO;
import com.hillrom.mobile.dto.ClinicAdminVO;
import com.hillrom.mobile.dto.DeviceDetailsDataVO;
import com.hillrom.mobile.dto.DeviceDetailsVO;
import com.hillrom.mobile.dto.FirstTransmissionVO;
import com.hillrom.mobile.dto.LegalTermsAndConditionsVO;
import com.hillrom.mobile.dto.MedicalTeamVO;
import com.hillrom.mobile.dto.MobileAppVO;
import com.hillrom.mobile.dto.PatientProfileDetailsDTO;
import com.hillrom.mobile.dto.ProfileOnboardingDetailsDTO;
import com.hillrom.mobile.dto.ProfileSupportVO;
import com.hillrom.mobile.dto.ProfileUpdateVO;
import com.hillrom.mobile.dto.ProtocolDataListVO;
import com.hillrom.mobile.dto.RevisionInfo;
import com.hillrom.mobile.dto.SerialNumberAssociatedToTheUUIDVO;
import com.hillrom.mobile.dto.SpirometerSettingsVO;
import com.hillrom.mobile.dto.TherapyReminderDTO;
import com.hillrom.mobile.repository.ManageAppVersionRepository;
import com.hillrom.mobile.repository.MobileDeviceInfoRepository;
import com.hillrom.mobile.repository.PatientActivityAssociationRepository;
import com.hillrom.mobile.repository.PatientActivityHistoryRepository;
import com.hillrom.mobile.repository.UserProfileRepository;
import com.hillrom.mobile.repository.UserPushNotificationRepository;
import com.hillrom.monarch.repository.PatientMonarchDeviceRepository;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.titan.service.PatientProtocolTitanService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.HillromTypeCodeFormat;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.HillromTypeCodeFormatRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.security.OnCredentialsChangeEvent;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.RandomUtil;
import com.hillrom.vest.service.util.TimeZoneUtil;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;

@Service
@Transactional
public class ProfileService {
	
	private static final Logger logger = LoggerFactory.getLogger(ProfileService.class);

	@Inject
	private EntityManager entityManager;
	
	@Inject
	private UserRepository userRepository;
	
	@Inject
	private UserPatientRepository userPatientRepository;
	
	@Inject
	private UserExtensionRepository userExtensionRepository;
	
	@Inject 
	private MobileDeviceInfoRepository mobileDeviceInfoRepository;
	
	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	@Inject
	private Environment env;
	
	@Inject
	private PasswordEncoder passwordEncoder;

	@Inject
	private HillromTypeCodeFormatRepository hillromTypeCodeFormatRepository;
	
	@Inject
	private UserPushNotificationRepository userPushNotificationRepository;
	
	@Inject
	private UserService userService;
	
	@Inject
	private UserProfileRepository userProfileRepository;
	
	@Inject
	private PatientProtocolMonarchService protocolMonarchService;
	
	@Inject
	private PatientProtocolTitanService protocolTitanService;

	@Inject
	private PatientProtocolService protocolVestService;
	
    @Inject
    private MailService mailService;
    
    @Inject
    private ApplicationEventPublisher eventPublisher;
    
    @Inject
    private ManageAppVersionRepository manageAppVersionRepository;

    @Inject
    private PatientDevicesAssocRepository patientDevicesAssocRepository;

    @Inject
    private PatientVestDeviceRepository patientVestDeviceRepository;

    @Inject
    private PatientMonarchDeviceRepository patientMonarchDeviceRepository;
    
    @Inject
    private ActivityService activityService;

	@Inject
	private PatientActivityAssociationRepository patientActivityAssociationRepository;

	@Inject
	private PatientActivityHistoryRepository patientActivityHistoryRepository;

    //@Inject
    //private ProtocolConstantsMonarchRepository protocolConstantsMonarchRepository;
	
	public JSONObject addSpirometerSettings(SpirometerSettingsVO spirometerSetting) {
        JSONObject jsonObject = new JSONObject();
        try {
        	PatientInfo patientInfo = patientInfoRepository.findOne(spirometerSetting.getPid());
	        if(Objects.nonNull(patientInfo)) {
	           patientInfo.setGender(spirometerSetting.getGender());
	           List<UserPatientAssoc> patientUser = userPatientRepository.findOneByPatientId(patientInfo.getId());
	           User associatedUser = userRepository.findOne(patientUser.get(0).getUser().getId());
	           associatedUser.setGender(spirometerSetting.getGender());
	           patientInfo.setOrigin(spirometerSetting.getOrigin());
				/*
				 * if(StringUtils.isNotBlank(spirometerSetting.getWeight())) { LogActivityDTO
				 * logWeight = new LogActivityDTO();
				 * logWeight.setPid(spirometerSetting.getPid());
				 * logWeight.setWeight(Long.parseLong(spirometerSetting.getWeight()));
				 * logWeight.setDate((new DateTime(DateTimeZone.UTC)).getMillis());
				 * activityService.logWeight(logWeight); }
				 */
	           patientInfo.setWeight(spirometerSetting.getWeight());
	           patientInfo.setHeight(spirometerSetting.getHeight());
	           patientInfoRepository.save(patientInfo);
	           userRepository.save(associatedUser);
	           jsonObject.put("message",ExceptionConstants.HR_940);
	        } else {
	        	jsonObject.put("message",ExceptionConstants.HR_915);
	        }
        } catch(Exception e) {
        	e.printStackTrace();
        }
        return jsonObject;
 }
	
	public JSONObject updatePatientDetails(ProfileUpdateVO profileUpdateVO, MultipartFile file,
			String profilePictureType, String baseUrl) {

		JSONObject jsonObject = new JSONObject();
		String filepath = null;
		String message = null;
		String filename = null;

		if (Objects.nonNull(profileUpdateVO)) {
			if (Objects.nonNull(profileUpdateVO.getUserId())) {
				UserExtension patientUser = userExtensionRepository.findOne(profileUpdateVO.getUserId());
				if (Objects.nonNull(patientUser)) {
					if (profileUpdateVO.isPictureUpdated) {
						if (Objects.isNull(profilePictureType)) {
							if (Objects.nonNull(file)) {
								try {
									filename = file.getOriginalFilename();
									String fileExtension = Files.getFileExtension(filename);
									String directory = Constants.UPLOAD_FILE_PATH; // Change file path accordingly
									File picDir = new File(directory);
									if (!picDir.exists()) {
										if (picDir.mkdirs()) {
											logger.info("Creating directories if does not exists");
										}
									}
									filename = passwordEncoder.encode(filename).substring(1, 12) + "." + fileExtension;
									filepath = Paths.get(directory, filename).toString();
									// Save the file locally
									BufferedOutputStream stream = new BufferedOutputStream(
											new FileOutputStream(new File(filepath)));
									stream.write(file.getBytes());
									stream.close();
								} catch (Exception e) {
									e.printStackTrace();
								}
								if (Objects.nonNull(filename)) {
									profileUpdateVO.setProfilePictureImage(Constants.PROFILE_FILE_PATH + filename);
								}
							}
						} else {
							profileUpdateVO.setProfilePictureImage(null);
							// if(Objects.nonNull(profilePictureType)) {
							profileUpdateVO.setProfilePictureType(Long.parseLong(profilePictureType));
							// }
						}
					}

					if (Objects.nonNull(profileUpdateVO.getEmailId())
							&& !profileUpdateVO.getEmailId().equals(patientUser.getEmail())) {
						boolean isEmailUpdated = false;
						message = userService.isUserExistsWithEmailOrNot(profileUpdateVO.getEmailId(), patientUser);
						// TODO:Send Email to to newly registered Email and Update response with boolean
						// flag
						if (null != message) {
							jsonObject.put("ERROR", message);
							return jsonObject;
						} else {
							patientUser.setEmail(profileUpdateVO.getEmailId());
							reSendEmailNotificationForMobileUser(baseUrl, patientUser);
							isEmailUpdated = true;
						}
						jsonObject.put("isEmailUpdated", isEmailUpdated);
					}
					if (profileUpdateVO.isPictureUpdated()) {
						if (profileUpdateVO.getProfilePictureType() != 0L) {
							patientUser.setProfileEmojiId(profileUpdateVO.getProfilePictureType());
							patientUser.setProfileImageName(null);
							patientUser.setProfileImageType(false);
						} else {
							if (Objects.nonNull(profileUpdateVO.getProfilePictureImage())) {
								patientUser.setProfileImageName(profileUpdateVO.getProfilePictureImage());
								patientUser.setProfileEmojiId(null);
								patientUser.setProfileImageType(true);
							} else {
								jsonObject.put("ERROR", ExceptionConstants.HR_502);
								return jsonObject;
							}
						}
					}
					String encryptedPassword = null;
					if (Objects.nonNull(profileUpdateVO.getPassword())) {
						encryptedPassword = passwordEncoder.encode(profileUpdateVO.getPassword());
						if (!patientUser.getPassword().equals(encryptedPassword)) {
							patientUser.setPassword(encryptedPassword);
						}
					}

					if (Objects.nonNull(profileUpdateVO.getTimeZone())
							&& !profileUpdateVO.getTimeZone().equals(patientUser.getTimeZone())) {
						patientUser.setTimeZone(profileUpdateVO.getTimeZone());
					}

					if (Objects.nonNull(profileUpdateVO.getPrimaryPhone())
							&& !profileUpdateVO.getPrimaryPhone().equals(patientUser.getPrimaryPhone())) {
						patientUser.setPrimaryPhone(profileUpdateVO.getPrimaryPhone());
					}

					if (Objects.nonNull(profileUpdateVO.getSecondaryPhone())
							&& !profileUpdateVO.getSecondaryPhone().equals(patientUser.getMobilePhone())) {
						patientUser.setMobilePhone(profileUpdateVO.getSecondaryPhone());
					}
					// userExtensionRepository.save(patientUser);
					jsonObject.put("message", ExceptionConstants.HR_937);
				} else {
					jsonObject.put("ERROR", ExceptionConstants.HR_512);
				}
			} else {
				jsonObject.put("ERROR", ExceptionConstants.HR_512);
			}
		} else {
			jsonObject.put("ERROR", ExceptionConstants.HR_518);
		}
		return jsonObject;
	}

public JSONObject updatePatientNotificationSettings(ProfileUpdateVO profileUpdateVO) {

	JSONObject jsonObject = new JSONObject();

	if(Objects.nonNull(profileUpdateVO)){
		if(Objects.nonNull(profileUpdateVO.getUserId())) {
			UserExtension patientUser = userExtensionRepository.findOne(profileUpdateVO.getUserId());							
			if(Objects.nonNull(patientUser)) {					
				//patientUser.setNonHMRNotification(profileUpdateVO.isNotificationsSetting());
				patientUser.setReminderNotification(profileUpdateVO.isRemindersSetting());
				patientUser.setProtocolDeviationNotification(profileUpdateVO.isDeviationAlert());
				patientUser.setAchievementNotification(profileUpdateVO.isAchievementsSetting());
				patientUser.setRtpUpdateNotification(profileUpdateVO.isRtpSetting());
				patientUser.setNewTherapyNotification(profileUpdateVO.isNewTherapySetting());				
				
				logger.debug("Response set patientUser :"+patientUser);
				userExtensionRepository.save(patientUser);
				jsonObject.put("message",ExceptionConstants.HR_937);
			}else {
				jsonObject.put("ERROR", ExceptionConstants.HR_512);
			}
		}else {
			jsonObject.put("ERROR", ExceptionConstants.HR_512);
		}
	} else {
		jsonObject.put("ERROR", ExceptionConstants.HR_518);
	}
	return jsonObject;
}

	public Map<String,String> getGenericWindowsTimeZonesList(){
		Map<String,String> timeZones = new LinkedHashMap<String,String>();
		try {
			timeZones =  TimeZoneUtil.getTimezones();
			return timeZones;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public JSONObject addProfileOnboardingDetails( ProfileOnboardingDetailsDTO profileOnboardingDetailsDTO, String authToken) {
		JSONObject  jsonObject = new JSONObject();
		PatientInfo  patientInfo = userService.getPatientInfoObjFromPatientUser(userRepository.getOne(profileOnboardingDetailsDTO.getUserId()));;
		if(Objects.isNull(patientInfo)){
			jsonObject.put("ERROR",ExceptionConstants.HR_915);
			return jsonObject;
		}
		
		// valid device type 
		List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository
				.findCodeValuesListByTypeCode(profileOnboardingDetailsDTO.getDevice_type().toLowerCase());
		if(Objects.isNull(typeCodeList) || typeCodeList.isEmpty()) {
			jsonObject.put("ERROR",ExceptionConstants.HR_958);
			return jsonObject;
		}
				
		MobileDeviceInfo mobileDevAssocPatient = mobileDeviceInfoRepository.findByPatientIdAndUUID(patientInfo.getId(),
				profileOnboardingDetailsDTO.getDevice_UUID());

		if (Objects.isNull(mobileDevAssocPatient)) {
			MobileDeviceInfo mobileDevice = mobileDeviceInfoRepository
					.findByUUID(profileOnboardingDetailsDTO.getDevice_UUID());
			if (Objects.isNull(mobileDevice)) {		// never registered
				MobileDeviceInfo mobileDeviceInfoDetails = new MobileDeviceInfo();
				mobileDeviceInfoDetails.setPatientId(patientInfo.getId());
				mobileDeviceInfoDetails.setDevice_token(profileOnboardingDetailsDTO.getDevice_token());
				mobileDeviceInfoDetails.setPlatform_type(typeCodeList.get(0).getId());
				mobileDeviceInfoDetails.setDevice_UUID(profileOnboardingDetailsDTO.getDevice_UUID());
				mobileDeviceInfoDetails.setMobile_registration_datetime(DateTime.now(DateTimeZone.UTC).getMillis());
				mobileDeviceInfoDetails.setAuthentication_flag(profileOnboardingDetailsDTO.isAuthentication_type());
				mobileDeviceInfoDetails.setAuth_token(authToken);
				mobileDeviceInfoRepository.save(mobileDeviceInfoDetails);
				jsonObject.put("message", ExceptionConstants.HR_949);
			} else {
				if (!mobileDevice.getPatientId().equals(patientInfo.getId())) {	// registering with different or same patient login
					mobileDevice.setMobile_registration_datetime(DateTime.now(DateTimeZone.UTC).getMillis());
					mobileDevice.setPatientId(patientInfo.getId());
				}
				if(!profileOnboardingDetailsDTO.getDevice_token().isEmpty() && !mobileDevice.getDevice_token().equals(profileOnboardingDetailsDTO.getDevice_token())) { // update device token
					mobileDevice.setDevice_token(profileOnboardingDetailsDTO.getDevice_token());
				}
				if(typeCodeList != null && typeCodeList.size() > 0 
						&& !mobileDevice.getPlatform_type().equals(typeCodeList.get(0).getId())) { // platform type
					mobileDevice.setPlatform_type(typeCodeList.get(0).getId());
				}
				
				if(profileOnboardingDetailsDTO.isAuthentication_type() != mobileDevice.getAuthentication_flag()) {				
					mobileDevice.setAuthentication_flag(profileOnboardingDetailsDTO.isAuthentication_type());
				}
				mobileDevice.setAuth_token(authToken);
				mobileDeviceInfoRepository.save(mobileDevice);
				jsonObject.put("message", ExceptionConstants.HR_937);
			}
			
		} else {
			if(!profileOnboardingDetailsDTO.getDevice_token().isEmpty() && !mobileDevAssocPatient.getDevice_token().equals(profileOnboardingDetailsDTO.getDevice_token())) { // update device token
				mobileDevAssocPatient.setDevice_token(profileOnboardingDetailsDTO.getDevice_token());
			}
			if(typeCodeList != null && typeCodeList.size() > 0 
					&& !mobileDevAssocPatient.getPlatform_type().equals(typeCodeList.get(0).getId())) { // platform type
				mobileDevAssocPatient.setPlatform_type(typeCodeList.get(0).getId());
			}
			
			if(profileOnboardingDetailsDTO.isAuthentication_type() != mobileDevAssocPatient.getAuthentication_flag()) {				
				mobileDevAssocPatient.setAuthentication_flag(profileOnboardingDetailsDTO.isAuthentication_type());
			}
			mobileDevAssocPatient.setAuth_token(authToken);
			mobileDeviceInfoRepository.save(mobileDevAssocPatient);
			jsonObject.put("message", ExceptionConstants.HR_937);
		}
		return jsonObject;
	}
	
	public JSONObject getallBasicDetails(BasicDetailsDTO basicDTO,String authToken) {

		JSONObject  jsonObject =new JSONObject();
		BasicInfoDetailsVO basicInfoDetailsVO = new BasicInfoDetailsVO();
		try {
			User associatedUser = userRepository.findOne(basicDTO.getUserId());
			if(Objects.nonNull(associatedUser)){
				List<UserPatientAssoc> associations = userPatientRepository.findOneByUserId(basicDTO.getUserId());
				UserPatientAssoc userPatientAssoc;
				if(associations.isEmpty()){
					jsonObject.put("ERROR",ExceptionConstants.HR_512);
					return jsonObject;
				} else {
					userPatientAssoc =associations.get(0);
					if(Objects.isNull(userPatientAssoc)){
						jsonObject.put("ERROR",ExceptionConstants.HR_915);
						return jsonObject;
					}

					PatientInfo  patientInfo =userPatientAssoc.getPatient();
					if(Objects.isNull(patientInfo.getId())){
						jsonObject.put("ERROR",ExceptionConstants.HR_915);
						return jsonObject;
					}

					MobileDeviceInfo mobileDeviceDetails = mobileDeviceInfoRepository.findByPatientIdAndUUID(patientInfo.getId(), basicDTO.getDevice_UUID());
					if(Objects.nonNull(mobileDeviceDetails)){
						mobileDeviceDetails.setAuth_token(authToken);
						mobileDeviceInfoRepository.save(mobileDeviceDetails);
					}

					List<HillromTypeCodeFormat> typeCodeList = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode(basicDTO.getDevice_type().toLowerCase());
					if(typeCodeList.isEmpty()){
						 jsonObject.put("ERROR",ExceptionConstants.HR_948);
						 return jsonObject;
					}
							
					Map<String, Object> results  = userProfileRepository.getAllBasicDetailsForUser(
							basicDTO.getUserId().intValue(),  
							basicDTO.getDevice_UUID(), 
							basicDTO.getDevice_type());
					
					logger.info("Final results from stre proc = "+results);
					
					if (Objects.nonNull(results)) {    			    				
						
						List<String> protocolTypeListVest = Arrays.asList(Objects.nonNull(results.get("protocolType")) ? results.get("protocolType").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
							
						List<String> minFreqListVest = Arrays.asList(Objects.nonNull(results.get("minFreq")) ? results.get("minFreq").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxFreqListVest = Arrays.asList(Objects.nonNull(results.get("maxFreq")) ? results.get("maxFreq").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minMptListVest = Arrays.asList(Objects.nonNull(results.get("minMpt")) ? results.get("minMpt").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxMptListVest = Arrays.asList(Objects.nonNull(results.get("maxMpt")) ? results.get("maxMpt").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minPressureListVest = Arrays.asList(Objects.nonNull(results.get("minPressure")) ? results.get("minPressure").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxPressureListVest = Arrays.asList(Objects.nonNull(results.get("maxPressure")) ? results.get("maxPressure").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> tpdListVest = Arrays.asList(Objects.nonNull(results.get("tpd")) ? results.get("tpd").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						List<String> protocolTypeListMonarch = Arrays.asList(Objects.nonNull(results.get("protocolTypeM")) ? results.get("protocolTypeM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						List<String> minFreqListMonarch = Arrays.asList(Objects.nonNull(results.get("minFreqM")) ? results.get("minFreqM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxFreqListMonarch = Arrays.asList(Objects.nonNull(results.get("maxFreqM")) ? results.get("maxFreqM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minMptListMonarch = Arrays.asList(Objects.nonNull(results.get("minMptM")) ? results.get("minMptM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxMptListMonarch = Arrays.asList(Objects.nonNull(results.get("maxMptM")) ? results.get("maxMptM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minPressureListMonarch = Arrays.asList(Objects.nonNull(results.get("minPressureM")) ? results.get("minPressureM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxPressureListMonarch = Arrays.asList(Objects.nonNull(results.get("maxPressureM")) ? results.get("maxPressureM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						List<String> tpdListMonarch = Arrays.asList(Objects.nonNull(results.get("tpdM")) ? results.get("tpdM").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						
						List<String> protocolTypeListTitan = Arrays.asList(Objects.nonNull(results.get("protocolTypeT")) ? results.get("protocolTypeT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						List<String> minFreqListTitan = Arrays.asList(Objects.nonNull(results.get("minFreqT")) ? results.get("minFreqT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxFreqListTitan = Arrays.asList(Objects.nonNull(results.get("maxFreqT")) ? results.get("maxFreqT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minMptListTitan = Arrays.asList(Objects.nonNull(results.get("minMptT")) ? results.get("minMptT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxMptListTitan = Arrays.asList(Objects.nonNull(results.get("maxMptT")) ? results.get("maxMptT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> minIntensityListTitan = Arrays.asList(Objects.nonNull(results.get("minPressureT")) ? results.get("minPressureT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> maxIntensityListTitan = Arrays.asList(Objects.nonNull(results.get("maxPressureT")) ? results.get("maxPressureT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> tpdListTitan = Arrays.asList(Objects.nonNull(results.get("tpdT")) ? results.get("tpdT").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						List<ProtocolDataListVO> protocolDataMonarchList = new ArrayList<ProtocolDataListVO>();
						List<ProtocolDataListVO> protocolDataVestList = new ArrayList<ProtocolDataListVO>();
						List<ProtocolDataListVO> protocolDataTitanList = new ArrayList<ProtocolDataListVO>();

						protocolDataMonarchList = getProtocolListForBasicInfo(minFreqListMonarch,maxFreqListMonarch,minMptListMonarch,
								maxMptListMonarch,minPressureListMonarch,maxPressureListMonarch,tpdListMonarch,protocolTypeListMonarch);

						protocolDataVestList = getProtocolListForBasicInfo(minFreqListVest,maxFreqListVest,minMptListVest,maxMptListVest,
								minPressureListVest,maxPressureListVest,tpdListVest,protocolTypeListVest);
						
						protocolDataTitanList = getProtocolListForBasicInfoTitan(minFreqListTitan,maxFreqListTitan,minMptListTitan,
								maxMptListTitan,minIntensityListTitan,maxIntensityListTitan,tpdListTitan,protocolTypeListTitan);

						List<String> deviceNameList = Arrays.asList(Objects.nonNull(results.get("deviceNameCsv")) ? results.get("deviceNameCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceTypeList = Arrays.asList(Objects.nonNull(results.get("deviceTypeCsv")) ? results.get("deviceTypeCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceSerialNumberList = Arrays.asList(Objects.nonNull(results.get("deviceSerialNumberCsv")) ? results.get("deviceSerialNumberCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceColorList = Arrays.asList(Objects.nonNull(results.get("deviceColorCsv")) ? results.get("deviceColorCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceGarmentTypeList = Arrays.asList(Objects.nonNull(results.get("deviceGarmentTypeCsv")) ? results.get("deviceGarmentTypeCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceSizeList = Arrays.asList(Objects.nonNull(results.get("deviceSizeCsv")) ? results.get("deviceSizeCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> isManualList = Arrays.asList(Objects.nonNull(results.get("isManualCsv")) ? results.get("isManualCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> isActiveList = Arrays.asList(Objects.nonNull(results.get("isActiveCsv")) ? results.get("isActiveCsv").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> is_byod = Arrays.asList(Objects.nonNull(results.get("is_byod")) ? results.get("is_byod").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> is_dnd = Arrays.asList(Objects.nonNull(results.get("is_dnd")) ? results.get("is_dnd").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> dnd_device_identifier = Arrays.asList(Objects.nonNull(results.get("dnd_device_identifier")) ? results.get("dnd_device_identifier").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> byod_state = Arrays.asList(Objects.nonNull(results.get("byod_state")) ? results.get("byod_state").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> byod_last_updated = Arrays.asList(Objects.nonNull(results.get("byod_last_updated")) ? results.get("byod_last_updated").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> byod_device_identifier = Arrays.asList(Objects.nonNull(results.get("byod_device_identifier")) ? results.get("byod_device_identifier").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> opt_out_requested_date = Arrays.asList(Objects.nonNull(results.get("opt_out_requested_date")) ? results.get("opt_out_requested_date").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> opt_out_device_identifier = Arrays.asList(Objects.nonNull(results.get("opt_out_device_identifier")) ? results.get("opt_out_device_identifier").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> opt_out_agreed_date = Arrays.asList(Objects.nonNull(results.get("opt_out_agreed_date")) ? results.get("opt_out_agreed_date").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> opt_out_reason = Arrays.asList(Objects.nonNull(results.get("opt_out_reason")) ? results.get("opt_out_reason").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> opt_out_feedback = Arrays.asList(Objects.nonNull(results.get("opt_out_feedback")) ? results.get("opt_out_feedback").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);
						List<String> deviceAddress = Arrays.asList(Objects.nonNull(results.get("deviceAddress")) ? results.get("deviceAddress").toString().split("\\s*,\\s*") : ArrayUtils.EMPTY_STRING_ARRAY);

						// TODO this common code can be moved to function and utilise
						List<DeviceDetailsVO> deviceDetailsList = new ArrayList<DeviceDetailsVO>();
						String lastTransmissionDate = null;
						Long lastTrasmission = 0L;
						Long monarchProtocolDuration = 0L;
						Long vestProtocolDuration = 0L;
						Long titanProtocolDuration = 0L;
						
						for(int i=0; i< deviceTypeList.size(); i++) {
							Boolean found = false;
							for (DeviceDetailsVO deviceDetailsVO : deviceDetailsList) {
								if(deviceDetailsVO.getDeviceType().equals(deviceTypeList.get(i)) && deviceDetailsVO.getSerialNumber().equals(deviceSerialNumberList.get(i)))
								{
									found = true;
									break;
								}
							}
							
							if (found) {
								continue;
							}
							
							DeviceDetailsVO deviceDetails = new DeviceDetailsVO();
							
						    try {
								deviceDetails.setDeviceName((i < deviceNameList.size()) ? (deviceNameList.get(i).equalsIgnoreCase("null") ? null : deviceNameList.get(i)) : null);
						    	deviceDetails.setDeviceType((i < deviceTypeList.size()) ? (deviceTypeList.get(i).equalsIgnoreCase("null") ? null : deviceTypeList.get(i)) : null);
						    	deviceDetails.setSerialNumber((i < deviceSerialNumberList.size()) ? (deviceSerialNumberList.get(i).equalsIgnoreCase("null") ? null : deviceSerialNumberList.get(i)) : null);
						    	deviceDetails.setDeviceColor((i < deviceColorList.size()) ? (deviceColorList.get(i).equalsIgnoreCase("null") ? null : deviceColorList.get(i)) : null);
						    	deviceDetails.setDeviceSize((i < deviceSizeList.size()) ? (deviceSizeList.get(i).equalsIgnoreCase("null") ? null : deviceSizeList.get(i)) : null);
						    	//deviceDetails.setGarmentType((i < deviceGarmentTypeList.size()) ? (deviceGarmentTypeList.get(i).equalsIgnoreCase("null") ? null : deviceGarmentTypeList.get(i)) : null);
						    	deviceDetails.setIsManual((i < isManualList.size()) ? (StringUtils.isBlank(isManualList.get(i)) ? false : Boolean.parseBoolean(isManualList.get(i))) : false);
								deviceDetails.setIsActive((i < isActiveList.size()) ? (StringUtils.isBlank(isActiveList.get(i)) ? false : Boolean.parseBoolean(isActiveList.get(i))) : false);
								deviceDetails.setIsByod((i < is_byod.size()) ? (StringUtils.isBlank(is_byod.get(i)) ? false : Boolean.parseBoolean(is_byod.get(i))) : false);
								deviceDetails.setDeviceAddress((i < deviceAddress.size()) ? (deviceAddress.get(i).equalsIgnoreCase("null") ? null : deviceAddress.get(i)) : null);
								deviceDetails.setIsDnd((i < is_dnd.size()) ? (StringUtils.isBlank(is_dnd.get(i)) ? false : Boolean.parseBoolean(is_dnd.get(i))) : false);
								deviceDetails.setDndDeviceIdentifier((i < dnd_device_identifier.size()) ? (dnd_device_identifier.get(i).equalsIgnoreCase("null") ? null : dnd_device_identifier.get(i)) : null);
								deviceDetails.setByodState((i < byod_state.size()) ? (byod_state.get(i).equalsIgnoreCase("null") ? null : byod_state.get(i)) : null);
								if(Objects.nonNull(deviceDetails.getByodState())) {
									if ((deviceDetails.getByodState().equals(Constants.BYOD_PAIRED) || deviceDetails.getByodState().equals(Constants.BYOD_OPT_OUT_REQUESTED))) {
										BYODPairInfo pairInfo = new BYODPairInfo();
										pairInfo.setDeviceIdentifier((i < byod_device_identifier.size()) ? (byod_device_identifier.get(i).equalsIgnoreCase("null") ? null : byod_device_identifier.get(i)) : null);
										pairInfo.setLastUpdated((i < byod_last_updated.size()) ? (byod_last_updated.get(i).equalsIgnoreCase("null") ? null : Long.parseLong(byod_last_updated.get(i))) : null);
										deviceDetails.setPairInfo(pairInfo);
									}
									if(deviceDetails.getByodState().equals(Constants.BYOD_OPTED_OUT) || deviceDetails.getByodState().equals(Constants.BYOD_OPT_OUT_REQUESTED) )
									{
										BYODOptOutInfo optOutInfo = new BYODOptOutInfo();
										optOutInfo.setDeviceIdentifier((i < opt_out_device_identifier.size()) ? (opt_out_device_identifier.get(i).equalsIgnoreCase("null") ? null : opt_out_device_identifier.get(i)) : null);
										optOutInfo.setAgreedDate((i < opt_out_agreed_date.size()) ? (opt_out_agreed_date.get(i).equalsIgnoreCase("null") ? null : Long.parseLong(opt_out_agreed_date.get(i))) : null);
										optOutInfo.setFeedback((i < opt_out_feedback.size()) ? (opt_out_feedback.get(i).equalsIgnoreCase("null") ? null : opt_out_feedback.get(i)) : null);
										optOutInfo.setReason((i < opt_out_reason.size()) ? (opt_out_reason.get(i).equalsIgnoreCase("null") ? null : opt_out_reason.get(i)) : null);
										optOutInfo.setRequestedDate((i < opt_out_requested_date.size()) ? (opt_out_requested_date.get(i).equalsIgnoreCase("null") ? null : Long.parseLong(opt_out_requested_date.get(i))) : null);										
										deviceDetails.setOptOutInfo(optOutInfo);
									}
								}
							} catch(Exception e) {
								e.printStackTrace();
								logger.debug("basicInfo deviceDetails:" +deviceDetails.getDeviceType() + ":"  + e.getMessage());
							}
							
						    
							if(i < deviceTypeList.size() && ((deviceTypeList.get(i)).equalsIgnoreCase("VEST"))){
								if (protocolDataVestList.size() > 0) {
									deviceDetails.setProtocolData(protocolDataVestList);
								} else {
									List<ProtocolDataListVO> defaultProtocolList = new ArrayList<ProtocolDataListVO>();
									defaultProtocolList.add(new ProtocolDataListVO( "Normal","5","20","1","10","5","20","2"));
									deviceDetails.setProtocolData(defaultProtocolList);
								}
								
								ProtocolConstants userProtocolConstantsVestMap = protocolVestService.getProtocolForPatientUserId(basicDTO.getUserId());
								vestProtocolDuration = userProtocolConstantsVestMap.getMinMinutesPerTreatment()*userProtocolConstantsVestMap.getTreatmentsPerDay() * 1L;

								//  garment Type for vest only
								deviceDetails.setGarmentType((i < deviceGarmentTypeList.size()) ? (deviceGarmentTypeList.get(i).equalsIgnoreCase("null") ? null : deviceGarmentTypeList.get(i)) : null);
								
								// vestHMR
								deviceDetails.setHMR(results.get("vestHMR").toString());
								
								// last transmission date
								String  vest_last_transmission_date = results.get("vest_last_transmission_date").toString();
								deviceDetails.setLast_transmission_date(vest_last_transmission_date);
								if(Objects.nonNull(vest_last_transmission_date))
								{
									Long deviceDateTime = Long.parseLong(vest_last_transmission_date);
									if(deviceDateTime > lastTrasmission) {
										lastTrasmission = deviceDateTime;
										lastTransmissionDate = vest_last_transmission_date;
									}
								}
							} else if(i < deviceTypeList.size() && ((deviceTypeList.get(i)).equalsIgnoreCase("MONARCH"))){
								if (protocolDataMonarchList.size() > 0) {
									deviceDetails.setProtocolData(protocolDataMonarchList);
								} else {
									List<ProtocolDataListVO> defaultProtocolList = new ArrayList<ProtocolDataListVO>();
									defaultProtocolList.add(new ProtocolDataListVO( "Normal","5","20","1","10","5","20","2"));
									deviceDetails.setProtocolData(defaultProtocolList);
								}
								
								ProtocolConstantsMonarch userProtocolConstantsMap = protocolMonarchService.getProtocolForPatientUserId(basicDTO.getUserId());
								monarchProtocolDuration = userProtocolConstantsMap.getMinMinutesPerTreatment()*userProtocolConstantsMap.getTreatmentsPerDay() * 1L ;

								// monarch HMR
								deviceDetails.setHMR(results.get("monarchHMR").toString());
								// last transmission date										
								String  monarch_last_transmission_date = results.get("monarch_last_transmission_date").toString();
								deviceDetails.setLast_transmission_date(monarch_last_transmission_date);
								if(Objects.nonNull(monarch_last_transmission_date))
								{
									Long deviceDateTime = Long.parseLong(monarch_last_transmission_date);
									if(deviceDateTime > lastTrasmission) {
										lastTrasmission = deviceDateTime;
										lastTransmissionDate = monarch_last_transmission_date;
									}
								}
							}else {
								if (protocolDataTitanList.size() > 0) {
									deviceDetails.setProtocolData(protocolDataTitanList);
								} else {
									List<ProtocolDataListVO> defaultProtocolList = new ArrayList<ProtocolDataListVO>();
									defaultProtocolList.add(new ProtocolDataListVO( "Normal","5","20","1","10","5","20","2"));
									deviceDetails.setProtocolData(defaultProtocolList);
								}
								
								ProtocolConstantsTitan userProtocolConstantsMap = protocolTitanService.getProtocolForPatientUserId(basicDTO.getUserId());
								titanProtocolDuration = userProtocolConstantsMap.getMinMinutesPerTreatment()*userProtocolConstantsMap.getTreatmentsPerDay() * 1L ;

								// titan HMR
								deviceDetails.setHMR(results.get("titanHMR").toString());
								// last transmission date										
								String  titan_last_transmission_date = results.get("titan_last_transmission_date").toString();
								deviceDetails.setLast_transmission_date(titan_last_transmission_date);
								if(Objects.nonNull(titan_last_transmission_date))
								{
									Long deviceDateTime = Long.parseLong(titan_last_transmission_date);
									if(deviceDateTime > lastTrasmission) {
										lastTrasmission = deviceDateTime;
										lastTransmissionDate = titan_last_transmission_date;
									}
								}
							}

							deviceDetailsList.add(deviceDetails);
						}

						basicInfoDetailsVO.setLast_therapy_date(lastTransmissionDate);
						basicInfoDetailsVO.setDevice_details(deviceDetailsList);

						ProfileSupportVO profileSupportVO = new ProfileSupportVO();
						AwardAndBadgesVersionNumberVO awardAndBadgesVersionNumberVO = new AwardAndBadgesVersionNumberVO();
						profileSupportVO.setCustomerServiceNo(env.getProperty("spring.support.customerServiceNo"));
						profileSupportVO.setPrivacyPolicy(env.getProperty("spring.support.privacyPolicyUrl"));
						profileSupportVO.setSupportEmail(env.getProperty("spring.support.supportEmail"));
						awardAndBadgesVersionNumberVO.setAwardAndBadgesVersionNumber(env.getProperty("spring.awardAndBadgesVersion.awardAndBadgesVersionNumber"));
						profileSupportVO.setTechnicalSupportNumber(env.getProperty("spring.support.technicalSupportNumber"));

						Map<String, String> userManualMap = profileSupportVO.getUserManualUrl();
						userManualMap.put("english", env.getProperty("spring.support.en-userManualUrl"));
						userManualMap.put("spanish", env.getProperty("spring.support.sp-userManualUrl"));

						MobileAppVO mobileAppVO= new MobileAppVO();
						FirstTransmissionVO firstTransmissionVO = new FirstTransmissionVO();
						ChartbasicsVO chartbasicsVO = new ChartbasicsVO();
						LegalTermsAndConditionsVO legalTermsAndConditionsVO = new LegalTermsAndConditionsVO();
						//SerialNumberAssociatedToTheUUIDVO serialNumberAssociatedToTheUUIDVO = new SerialNumberAssociatedToTheUUIDVO();
						legalTermsAndConditionsVO.setLegalTermsandConditionsURL(env.getProperty("spring.legalTermsandConditions.legalTermsandConditionsURL"));

						mobileAppVO.setForceUpdate(Boolean.toString(false));						
						JSONObject forceUpgrade  = forceUpgradeApp(basicDTO.getVersion(), basicDTO.getDevice_type());
						
						mobileAppVO.setForceUpgrade(Boolean.parseBoolean(forceUpgrade.get("forceUpgrade").toString()));
						mobileAppVO.setIsUpdateOptional(Boolean.parseBoolean(forceUpgrade.get("isUpdateOptional").toString()));
						
						basicInfoDetailsVO.setMobileApp(mobileAppVO);
						basicInfoDetailsVO.setFirstTransmission(firstTransmissionVO);
						basicInfoDetailsVO.setAwardorBadgesVersionNumber(awardAndBadgesVersionNumberVO);
						basicInfoDetailsVO.setLegalTermsAndConditionsurl(legalTermsAndConditionsVO);
						basicInfoDetailsVO.setSupport(profileSupportVO);
						
					
						basicInfoDetailsVO.setPatientID(patientInfo.getId());

						if(Objects.nonNull(results.get("firsttransmission_Airway"))){
							String firsttransmission_Airway = results.get("firsttransmission_Airway").toString();
							if (!(firsttransmission_Airway.equals("0"))) {
								firstTransmissionVO.setFirsttransmission_Airway(firsttransmission_Airway);
							}
						}
						
						if(Objects.nonNull(results.get("firsttransmission_Vest"))){
							String  firsttransmission_Vest = results.get("firsttransmission_Vest").toString();
							if (!(firsttransmission_Vest.equals("0"))) {
								DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
								long firsttransmission_Vest_utc=formatter.parseMillis(firsttransmission_Vest+" "+"00:00:00");
								firstTransmissionVO.setFirsttransmission_Vest(String.valueOf(firsttransmission_Vest_utc));
						
							} 
						}
						
						if(Objects.nonNull(results.get("firsttransmission_Monarch"))){
							String  firsttransmission_Monarch = results.get("firsttransmission_Monarch").toString();
							if(!(firsttransmission_Monarch.equals("0"))){
					        	DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
								long firsttransmission_Monarch_utc=formatter.parseMillis(firsttransmission_Monarch+" "+"00:00:00"); 
								firstTransmissionVO.setFirsttransmission_Monarch(String.valueOf(firsttransmission_Monarch_utc));
							}
						}
						
						if(Objects.nonNull(results.get("firsttransmission_Titan"))){
							String  firsttransmission_Titan = results.get("firsttransmission_Titan").toString();
							if(!(firsttransmission_Titan.equals("0"))){
					        	DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
								long firsttransmission_Titan_utc=formatter.parseMillis(firsttransmission_Titan+" "+"00:00:00"); 
								firstTransmissionVO.setFirsttransmission_Titan(String.valueOf(firsttransmission_Titan_utc));
							}
						}
						
						if (Objects.nonNull(results.get("firsttransmission_Medication"))) {
							String firsttransmission_Medication = results.get("firsttransmission_Medication").toString();
							if (!(firsttransmission_Medication.equals("0"))) {
								String date = firsttransmission_Medication.substring(0, 19);
								DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
								long firsttransmission_Medication_utc = formatter.parseMillis(date);
								firstTransmissionVO.setFirsttransmission_Medication(String.valueOf(firsttransmission_Medication_utc));
							}
						}
					
						if(Objects.nonNull(results.get("firsttransmission_Exercise_history"))){
							String firsttransmission_Exercise_history = results.get("firsttransmission_Exercise_history").toString();
	                        if(!(firsttransmission_Exercise_history.equals("0"))) {
	                        	 Long result= Long.parseLong(firsttransmission_Exercise_history);
	                        	 firstTransmissionVO.setFirsttransmission_Exercise_history(result.toString());
	                        }
						}

					
						if(Objects.nonNull(results.get("firsttransmission_Weight_history"))){
							String  firsttransmission_Weight_history = results.get("firsttransmission_Weight_history").toString();
							if(!(firsttransmission_Weight_history.equals("0"))){
                            	Long result= Long.parseLong(firsttransmission_Weight_history);
                            	firstTransmissionVO.setFirsttransmission_Weight_history(result.toString());
							}
						}
						
						if(Objects.nonNull(results.get("firsttransmission_Nutrition_history"))){
							String firsttransmission_Nutrition_history = results.get("firsttransmission_Nutrition_history").toString();
							if(! (firsttransmission_Nutrition_history.equals("0"))){
                            	Long result= Long.parseLong(firsttransmission_Nutrition_history);
                            	firstTransmissionVO.setFirsttransmission_Nutrition_history(result.toString());
					        }
						}
						
						chartbasicsVO.setLatest_Adherence_score(Objects.nonNull( results.get("latest_Adherence_score")) ? results.get("latest_Adherence_score").toString() : null);
						chartbasicsVO.setLatest_pulmonary_value(Objects.nonNull(results.get("latest_pulmonary_value")) ? results.get("latest_pulmonary_value").toString() : null);
						
						chartbasicsVO.setMedication_count(Objects.nonNull(results.get("medication_count")) ? results.get("medication_count").toString() : null);
						
						chartbasicsVO.setAirway_therapy_count(Objects.nonNull(results.get("airway_therapy_count")) ? results.get("airway_therapy_count").toString() : null);
						basicInfoDetailsVO.setChartbasics(chartbasicsVO);
						
						/*
						 * if(Objects.nonNull(results.get("weight"))){ String weight =
						 * results.get("weight").toString(); if(! (weight.equals("0"))){
						 * basicInfoDetailsVO.setWeight(results.get("weight").toString()); }
						 * 
						 * long activityTypeId =
						 * hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode("WeightGoal").
						 * get(0) .getId();
						 * 
						 * List<PatientActivityAssociation> paaList =
						 * patientActivityAssociationRepository
						 * .findActiveActivityByPatientIdandActivityTypeId(patientInfo.getId(),
						 * activityTypeId); if(!paaList.isEmpty()) { PatientActivityHistory
						 * currentActivityHistory = patientActivityHistoryRepository
						 * .findTop1ByPatientIdAndPatientActivityAssocId(patientInfo.getId(),
						 * paaList.get(0).getId());
						 * 
						 * if (Objects.nonNull(currentActivityHistory)) {
						 * basicInfoDetailsVO.setWeight(currentActivityHistory.getCurrentValue()); }
						 * else { basicInfoDetailsVO.setWeight(paaList.get(0).getIntialValue()); } } }
						 */
						
						basicInfoDetailsVO.setWeight(patientInfo.getWeight());
						
						if(Objects.nonNull(results.get("height"))){
							basicInfoDetailsVO.setHeight(results.get("height").toString());									
						}
						
						if(Objects.nonNull(results.get("gender"))){
							basicInfoDetailsVO.setGender(results.get("gender").toString());								
						}
						
						if(Objects.nonNull(results.get("origin"))){
							basicInfoDetailsVO.setOrigin(results.get("origin").toString());
						}
						
						
						if(Objects.nonNull(results.get("last_pft_result_date"))){
							String  last_pft_result_date = results.get("last_pft_result_date").toString();
							if(! (last_pft_result_date.equals("0"))){
								basicInfoDetailsVO.setLast_pft_result_date(results.get("last_pft_result_date").toString());		
					       }
						}
						
						if (Objects.nonNull(results.get("test_result_first_transmission_date"))) {
							String  firt_pft_result_date = results.get("test_result_first_transmission_date").toString();
							if(! (firt_pft_result_date.equals("0"))){
								basicInfoDetailsVO.setFirt_pft_result_date(results.get("test_result_first_transmission_date").toString());		
					       }
						}
						
						Long vestDuration = 0L;
						Long monarchDuration = 0L;
						Long titanDuration = 0L;

						if (Objects.nonNull(results.get("monarch_therapy_duration"))) {
							String monarch_therapy_duration = results.get("monarch_therapy_duration").toString();
							if(! (monarch_therapy_duration.equals("0"))){
								monarchDuration = Long.parseLong(results.get("monarch_therapy_duration").toString());		
					       }
						}
						
						if (Objects.nonNull(results.get("vest_therapy_duration"))) {
							String vest_therapy_duration = results.get("vest_therapy_duration").toString();
							if(! (vest_therapy_duration.equals("0"))){
								vestDuration = Long.parseLong(results.get("vest_therapy_duration").toString());		
					       }
						}
						
						if (Objects.nonNull(results.get("titan_therapy_duration"))) {
							String titan_therapy_duration = results.get("titan_therapy_duration").toString();
							if(! (titan_therapy_duration.equals("0"))){
								titanDuration = Long.parseLong(results.get("titan_therapy_duration").toString());		
					       }
						}
						
						vestDuration = vestDuration+monarchDuration+titanDuration;
						basicInfoDetailsVO.setTherapy_duration(vestDuration.toString());

						if((vestProtocolDuration !=0 ) && (monarchProtocolDuration != 0) && (titanProtocolDuration != 0)){
							if((vestProtocolDuration < monarchProtocolDuration) && (vestProtocolDuration < titanProtocolDuration)) {
								basicInfoDetailsVO.setTherapy_protocol(vestProtocolDuration.toString());
							}else if((monarchProtocolDuration < vestProtocolDuration) && (monarchProtocolDuration < titanProtocolDuration)) {
								basicInfoDetailsVO.setTherapy_protocol(monarchProtocolDuration.toString());
							}else {
								basicInfoDetailsVO.setTherapy_protocol(titanProtocolDuration.toString());							}
						} else {
							basicInfoDetailsVO.setTherapy_protocol("" + (vestProtocolDuration + monarchProtocolDuration + titanProtocolDuration));
						}
						
						RevisionInfo revInfo = new RevisionInfo();
						revInfo.setDesign("Designed in Singapore");
						revInfo.setPartNo("PartNo: XXXXXX Rev:XX");
						revInfo.setVersion("Version: XX.XX.XX.XX");
						revInfo.setUdi("GTIN: XXXXXXXXXXXX");
						
						basicInfoDetailsVO.setRevInfo(revInfo);

					}
					// set mobile device authentication flag to true
					MobileDeviceInfo mobDev = mobileDeviceInfoRepository.findByPatientIdAndUUID(patientInfo.getId(),basicDTO.getDevice_UUID());
					if (Objects.nonNull(mobDev)) {
						basicInfoDetailsVO.setFirstTimeLoginInPhone(false);
						
						//Set serial Number and Authentication flag 
						basicInfoDetailsVO.setSerialNumberAssociatedToTheUUID(new SerialNumberAssociatedToTheUUIDVO(mobDev.getSeraial_number(), mobDev.getAuthentication_flag()));
					}else {
						basicInfoDetailsVO.setFirstTimeLoginInPhone(true);
						
						//Set serial Number and Authentication flag with default values 
						basicInfoDetailsVO.setSerialNumberAssociatedToTheUUID(new SerialNumberAssociatedToTheUUIDVO(null, false));
					}
					
					basicInfoDetailsVO.setUnReadNotifications(userPushNotificationRepository.findUnreadNotificationCountByPatientId(patientInfo.getId()));
					jsonObject.put("BasicInfo",basicInfoDetailsVO);
				}
			} else {
				jsonObject.put("ERROR",ExceptionConstants.HR_512);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		logger.info("jsonObject getallBasicDetails response : "+jsonObject);
		return jsonObject;
	}

public JSONObject getPatientDetails(Long userId){

	PatientProfileDetailsDTO patientProfileDetails = new PatientProfileDetailsDTO();
	JSONObject jsonObject = new JSONObject();
		User associatedUser = userRepository.findOne(userId);
		if(Objects.nonNull(associatedUser)) {
			List<String> careGiverNameList = new ArrayList<String>();
			List<String> patientIdList = new ArrayList<String>();
			List<String> patientNameList = new ArrayList<String>();
			List<String> emailList = new ArrayList<String>();
			List<String> profilePictureList = new ArrayList<String>();
			List<String> timeZoneList = new ArrayList<String>();
			List<String> mailingAddressList = new ArrayList<String>();
			List<String> primaryPhoneList = new ArrayList<String>();
			List<String> secondaryPhoneList = new ArrayList<String>();
			List<String> deviceNameList = new ArrayList<String>();
			List<String> deviceAssocTypeList = new ArrayList<String>();
			List<String> deviceSerialNumberList = new ArrayList<String>();
			List<String> deviceColorList = new ArrayList<String>();
			List<String> deviceSizeList = new ArrayList<String>();
			List<String> garmentTypeList = new ArrayList<String>();
			List<Boolean> isManualList = new ArrayList<Boolean>();
			List<Boolean> isActiveList = new ArrayList<Boolean>();
			List<String> clinicCSVList = new ArrayList<String>();
			List<String> caCSVList = new ArrayList<String>();
			List<String> hcpCSVList = new ArrayList<String>();
			List<Boolean> reminderNotificationList = new ArrayList<Boolean>();
			List<Boolean> notificationSettingsList = new ArrayList<Boolean>();
			List<Boolean> deviationSettingsList = new ArrayList<Boolean>();
			List<Boolean> rtuSettingsList = new ArrayList<Boolean>();
			List<Boolean> newTherapySettingsList = new ArrayList<Boolean>();
			List<String> protocolTypeList = new ArrayList<String>();
			List<String> minFreqList = new ArrayList<String>();
			List<String> maxFreqList = new ArrayList<String>();
			List<String> minMptList = new ArrayList<String>();
			List<String> maxMptList = new ArrayList<String>();
			List<String> minPressureList = new ArrayList<String>();
			List<String> maxPressureList = new ArrayList<String>();
			List<String> tpdList = new ArrayList<String>();
			List<String> deviceTypeList = new ArrayList<String>();
			List<Boolean> is_byod = new ArrayList<Boolean>();
			List<Boolean> is_dnd = new ArrayList<Boolean>();
			List<String> dnd_device_identifier = new ArrayList<String>();
			List<String> byod_state = new ArrayList<String>();
			List<Long> byod_last_updated = new ArrayList<Long>();
			List<String> byod_device_identifier = new ArrayList<String>();
			List<Long> opt_out_requested_date = new ArrayList<Long>();
			List<String> opt_out_device_identifier = new ArrayList<String>();
			List<Long> opt_out_agreed_date = new ArrayList<Long>();
			List<String> opt_out_reason = new ArrayList<String>();
			List<String> opt_out_feedback = new ArrayList<String>();
			List<String> deviceAddress = new ArrayList<String>();
		
			String BaseQuery = QueryConstants.QUERY_PATIENTDETAILS;
			String finalQuery = BaseQuery.replaceAll(":user_id", userId.toString());
			Query query = entityManager.createNativeQuery(finalQuery);
			logger.debug(finalQuery);
			@SuppressWarnings("unchecked")
			List<Object[]> results = query.getResultList();
			if(results.size() == 0 ){
				jsonObject.put("message", ExceptionConstants.HR_512);
				return jsonObject;
			}
			List<ProtocolDataListVO> protocolDtaList = new ArrayList<ProtocolDataListVO>(); 
			results.stream().forEach((record) -> {
				
				if(Objects.nonNull((String) record[0])){
					patientIdList.add((String) record[0]);
				}
				
				
				if(Objects.nonNull((String) record[2]) && Objects.nonNull((String) record[1])){
					patientNameList.add(((String) record[2])+","+((String) record[1])); // lastName, firstName
				}
				if(Objects.nonNull((String) record[3]) ){
					emailList.add((String) record[3]);
				}
				if(Objects.nonNull((String) record[4]) ){
					profilePictureList.add((String) record[4]);
				}
				if(Objects.nonNull((String) record[5]) ){
					timeZoneList.add((String) record[5]);
				}
				if(Objects.nonNull((String) record[6]) ){
					mailingAddressList.add((String) record[6]);
				}
				if(Objects.nonNull((String) record[7]) ){
					primaryPhoneList.add((String) record[7]);
				}
				if(Objects.nonNull((String) record[8]) ){
					secondaryPhoneList.add((String) record[8]);
				}
				
				
				if(Objects.nonNull((String) record[28]) && Objects.nonNull((String) record[27])){
					careGiverNameList.add((((String) record[28])+","+((String) record[27])));
				}
				deviceAssocTypeList.add((String) record[9]);
				deviceSerialNumberList.add((String) record[10]);
				deviceColorList.add((String) record[11]);
				deviceSizeList.add((String) record[12]);
				garmentTypeList.add((String) record[13]); // device garment type
				isManualList.add((Boolean) record[14]);
				isActiveList.add((Boolean) record[15]);
				
				if (Objects.nonNull((String) record[54]) && Objects.nonNull((String) record[16]) &&
						Objects.nonNull((String) record[17]) && Objects.nonNull((String) record[18])) {
					clinicCSVList.add(((String) record[54]) + "##" + ((String) record[16]) 
							+ "##" + ((String) record[17]) + "##" + ((String) record[18]) );
				}
			
				if(Objects.nonNull((String) record[20]) && Objects.nonNull((String) record[19]) &&
						Objects.nonNull((String) record[55]) /*&& Objects.nonNull((String) record[19]) && Objects.nonNull((String) record[20])*/){
					caCSVList.add(((String) record[55]) + "##" + (((String) record[20])+"##"+((String) record[19])) 
							+ "##" + ((String) record[21]) + "##" + ((String) record[22]));
				}
				
				if (Objects.nonNull((String) record[24])
						&& Objects.nonNull((String) record[23]) /*
																 * && Objects.nonNull((String) record[25]) &&
																 * Objects.nonNull((String) record[26])
																 */ && Objects.nonNull((String) record[56])){
					hcpCSVList.add(((((String) record[56]) + "##" +(String) record[24]) + "##" + ((String) record[23])) + 
							"##"+((String) record[25]) + "##"+((String) record[26]));
				}
				
				reminderNotificationList.add((Boolean) record[29]);
				notificationSettingsList.add((Boolean) record[30]);
				deviationSettingsList.add((Boolean) record[31]);
				rtuSettingsList.add((Boolean) record[32]);
				newTherapySettingsList.add((Boolean) record[33]);			
				String minFreq = (String) record[34];
				String maxFreq = (String) record[35];
				String minMpt = (String) record[36];
				String maxMpt = (String) record[37];
				String minPressure = (String) record[38];
				String maxPressure = (String) record[39];
				String tpd = (String) record[40];
				String protocolType = (String) record[41];
				String deviceType = (String) record[42];
				deviceNameList.add((String) record[43]);
				is_byod.add((Boolean)record[44]);
				is_dnd.add((Boolean)record[45]);
				dnd_device_identifier.add((String) record[46]);
				byod_state.add((String) record[47]);
				if(Objects.nonNull(record[48])) {
					byod_last_updated.add(((BigInteger) record[48]).longValue());
				}else {
					byod_last_updated.add(null);
				}
				byod_device_identifier.add((String) record[49]);
				if(Objects.nonNull(record[50])) {
					opt_out_requested_date.add(((BigInteger) record[50]).longValue());
				}else {
					opt_out_requested_date.add(null);
				}
				opt_out_device_identifier.add((String) record[51]);
				if(Objects.nonNull(record[52])) {
					opt_out_agreed_date.add(((BigInteger) record[52]).longValue());
				}else{
					opt_out_agreed_date.add(null);
				}
				opt_out_reason.add((String) record[53]);
				opt_out_feedback.add((String) record[54]);
				deviceAddress.add((String) record[55]);

				ProtocolDataListVO protocolData = new ProtocolDataListVO(protocolType, minFreq, maxFreq,
						minPressure, maxPressure, minMpt, maxMpt, 
						tpd,deviceType);
				protocolDtaList.add(protocolData);
			});
			if(!(patientIdList.contains(null)) && (patientIdList.size()>0)) {
				patientProfileDetails.setPatient_Id((patientIdList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(patientNameList.contains(null)) && (patientNameList.size()>0)) {
				patientProfileDetails.setPatientName((patientNameList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
		
			if(!(emailList.contains(null)) && emailList.size()>0) {
				patientProfileDetails.setEmail((emailList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(profilePictureList.contains(null)) && (profilePictureList.size()>0)) {	
				patientProfileDetails.setProfilePictureURL((profilePictureList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));

			}
			if(!(timeZoneList.contains(null)) && (timeZoneList.size()>0)) {
				patientProfileDetails.setTimeZone((timeZoneList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(careGiverNameList.contains(null)) && (careGiverNameList.size()>0)) {
				patientProfileDetails.setCareGiverList(careGiverNameList.stream().distinct().collect(Collectors.toList()));
			}
	
			if(!(mailingAddressList.contains(null))&& (mailingAddressList.size()>0) ) {
				patientProfileDetails.setMailingAddress((mailingAddressList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(primaryPhoneList.contains(null))&& (primaryPhoneList.size()>0)) {
				patientProfileDetails.setPrimaryPhoneNumber((primaryPhoneList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(secondaryPhoneList.contains(null))&& (secondaryPhoneList.size()>0)) {
				patientProfileDetails.setMobilePhoneNumber((secondaryPhoneList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")));
			}
			if(!(reminderNotificationList.contains(null)) && (reminderNotificationList.size()>0)) {
				patientProfileDetails.setReminderSettings(Boolean.valueOf(((reminderNotificationList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")))));
			}
			if(!(notificationSettingsList.contains(null))&&(notificationSettingsList.size()>0)) {
				patientProfileDetails.setNotificationSettings(Boolean.valueOf(((notificationSettingsList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")))));
			}
			if(!(deviationSettingsList.contains(null))&& (deviationSettingsList.size()>0)) {
				patientProfileDetails.setDeviationAlerts(Boolean.valueOf(((deviationSettingsList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")))));
			}
			if(!(rtuSettingsList.contains(null))&& (rtuSettingsList.size()>0)) {
				patientProfileDetails.setRtuSettings(Boolean.valueOf(((rtuSettingsList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")))));
			}
			if(!(newTherapySettingsList.contains(null))&& (newTherapySettingsList.size()>0)) {
				patientProfileDetails.setNewTherapySettings(Boolean.valueOf(((newTherapySettingsList.stream().distinct().collect(Collectors.toList()))
						.stream().map(Object :: toString).collect(Collectors.joining(", ")))));
			}
			

			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMinFrequency())) {
			minFreqList = Arrays.asList((protocolDtaList.get(0).getMinFrequency()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMaxFrequency())) {
			maxFreqList = Arrays.asList((protocolDtaList.get(0).getMaxFrequency()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMin_minutes_per_treatment())) {
			minMptList = Arrays.asList((protocolDtaList.get(0).getMin_minutes_per_treatment()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMax_minutes_per_treatment())) {
			maxMptList = Arrays.asList((protocolDtaList.get(0).getMax_minutes_per_treatment()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMinPressure())) {
			minPressureList = Arrays.asList((protocolDtaList.get(0).getMinPressure()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getMaxPressure())) {
			maxPressureList = Arrays.asList((protocolDtaList.get(0).getMaxPressure()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getTreatments_per_day())) {
			tpdList = Arrays.asList((protocolDtaList.get(0).getTreatments_per_day()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getProtocolType())) {
			protocolTypeList = Arrays.asList((protocolDtaList.get(0).getProtocolType()).split("\\s*,\\s*"));
			}
			if(StringUtils.isNotBlank(protocolDtaList.get(0).getDeviceType())) {
				deviceTypeList = Arrays.asList((protocolDtaList.get(0).getDeviceType()).split("\\s*,\\s*"));
				}

			
			Map<String, List<ProtocolDataListVO>> protocolDataMap = new HashMap<String, List<ProtocolDataListVO>>();

			protocolDataMap = getProtocolList(minFreqList,maxFreqList,minMptList,maxMptList,minPressureList,
					maxPressureList,tpdList,protocolTypeList,deviceTypeList);

			List<DeviceDetailsDataVO> deviceDetailsList = null;
			for(int i=0; i< deviceAssocTypeList.size(); i++) {
				Boolean found = false;
				
				if (Objects.nonNull(deviceDetailsList)) {
					for (DeviceDetailsDataVO deviceDetailsVO : deviceDetailsList) {
						if(deviceDetailsVO.getDeviceType().equals(deviceAssocTypeList.get(i)) && deviceDetailsVO.getSerialNumber().equals(deviceSerialNumberList.get(i)))
						{
							found = true;
							break;
						}
					}
				}

				if(found) {
					continue;
				}
				
				DeviceDetailsDataVO deviceDetails = new DeviceDetailsDataVO();
				deviceDetails.setDeviceName((i < deviceNameList.size()) ? deviceNameList.get(i) : null);
		    	deviceDetails.setDeviceType(deviceAssocTypeList.get(i));
		    	deviceDetails.setSerialNumber((i < deviceSerialNumberList.size()) ? ("null".equalsIgnoreCase(deviceSerialNumberList.get(i)) ? null : deviceSerialNumberList.get(i)) : null);
		    	deviceDetails.setDeviceColor((i < deviceColorList.size()) ? deviceColorList.get(i) : null);
		    	deviceDetails.setDeviceSize((i < deviceSizeList.size()) ? deviceSizeList.get(i): null);
		    	deviceDetails.setGarmentType((i < garmentTypeList.size()) ? ("null".equalsIgnoreCase(garmentTypeList.get(i)) ? null : garmentTypeList.get(i)) : null);
		    	deviceDetails.setIsManual((i < isManualList.size()) ? (Objects.isNull(isManualList.get(i))?false:isManualList.get(i)) : false);
				deviceDetails.setIsActive((i < isActiveList.size()) ? isActiveList.get(i) : false);
				deviceDetails.setIsByod((i < is_byod.size()) ? is_byod.get(i) : false );
				deviceDetails.setDeviceAddress((i < deviceAddress.size()) ? (Objects.isNull(deviceAddress.get(i)) ? null : deviceAddress.get(i)) : null);
				deviceDetails.setIsDnd((i < is_dnd.size()) ? is_dnd.get(i): false );
				deviceDetails.setDndDeviceIdentifier((i < dnd_device_identifier.size()) ? (Objects.isNull(dnd_device_identifier.get(i)) ? null : dnd_device_identifier.get(i)) : null);
				deviceDetails.setByodState((i < byod_state.size()) ? (Objects.isNull(byod_state.get(i)) ? null : byod_state.get(i)) : null);
				if(Objects.nonNull(deviceDetails.getByodState())) {
					if ((deviceDetails.getByodState().equals(Constants.BYOD_PAIRED) || deviceDetails.getByodState().equals(Constants.BYOD_OPT_OUT_REQUESTED))) {
						BYODPairInfo pairInfo = new BYODPairInfo();
						pairInfo.setDeviceIdentifier((i < byod_device_identifier.size()) ? (Objects.isNull(byod_device_identifier.get(i)) ? null : byod_device_identifier.get(i)) : null);
						pairInfo.setLastUpdated((i < byod_last_updated.size()) ? (Objects.isNull(byod_last_updated.get(i)) ? null : byod_last_updated.get(i)) : null);
						deviceDetails.setPairInfo(pairInfo);
					}
					if(deviceDetails.getByodState().equals(Constants.BYOD_OPTED_OUT) || deviceDetails.getByodState().equals(Constants.BYOD_OPT_OUT_REQUESTED) )
					{
						BYODOptOutInfo optOutInfo = new BYODOptOutInfo();
						optOutInfo.setDeviceIdentifier((i < opt_out_device_identifier.size()) ? (Objects.isNull(opt_out_device_identifier.get(i)) ? null : opt_out_device_identifier.get(i)) : null);
						optOutInfo.setAgreedDate((i < opt_out_agreed_date.size()) ? (Objects.isNull(opt_out_agreed_date.get(i)) ? null : opt_out_agreed_date.get(i)) : null);
						optOutInfo.setFeedback((i < opt_out_feedback.size()) ? (Objects.isNull(opt_out_feedback.get(i)) ? null : opt_out_feedback.get(i)) : null);
						optOutInfo.setReason((i < opt_out_reason.size()) ? (Objects.isNull(opt_out_reason.get(i)) ? null : opt_out_reason.get(i)) : null);
						optOutInfo.setRequestedDate((i < opt_out_requested_date.size()) ? (Objects.isNull(opt_out_requested_date.get(i)) ? null : opt_out_requested_date.get(i)) : null);										
						deviceDetails.setOptOutInfo(optOutInfo);
					}
				}
				
				for(Map.Entry<String, List<ProtocolDataListVO>> entry : protocolDataMap.entrySet()) {
					if((entry.getKey().equalsIgnoreCase((deviceAssocTypeList.get(i))))) {
						if (Objects.nonNull(entry.getValue())) {
							List<ProtocolDataListVO> protocolDataList = entry.getValue();
							if (protocolDataList.isEmpty()) {
								protocolDataList.add(new ProtocolDataListVO( "Normal","5","20","1","10","5","20","2"));
								deviceDetails.setProtocolData(protocolDataList);
							} else {
								deviceDetails.setProtocolData(entry.getValue());
							}
						}
					} 
				}
				if(Objects.isNull(deviceDetailsList)) {
					deviceDetailsList = new ArrayList<DeviceDetailsDataVO>();
				}
				deviceDetailsList.add(deviceDetails);
			}

			// CA LIST
			List<ClinicAdminVO> clinicAdminList = null;
			for(int i = 0; i < (caCSVList.stream().distinct().collect(Collectors.toList())).size();i++) {
				String caCSV = (caCSVList.stream().distinct().collect(Collectors.toList())).get(i);
				if (Objects.nonNull(caCSV)) {
					ClinicAdminVO clinicAdminDetails = new ClinicAdminVO();
					clinicAdminDetails.setClinicAdminName(("null".equalsIgnoreCase(caCSV.split("##")[1]) ? null : caCSV.split("##")[1]) + "," 
					+ ("null".equalsIgnoreCase(caCSV.split("##")[2]) ? null : caCSV.split("##")[2]));
					clinicAdminDetails.setClinicAdmincredentials("null".equalsIgnoreCase(caCSV.split("##")[3]) ? null : caCSV.split("##")[3]);
					clinicAdminDetails.setClinicAdminPhoneNumber("null".equalsIgnoreCase(caCSV.split("##")[4]) ? null : caCSV.split("##")[4]);
					
					if(Objects.isNull(clinicAdminList)) {
						clinicAdminList = new ArrayList<ClinicAdminVO>();
					}					
					clinicAdminList.add(clinicAdminDetails);
				}
				
			}
			// HCP LIST --> CA LIST
			List<ClinicAdminVO> hcpList = null;
			Map<String, List<ClinicAdminVO>> clinicWiseHCPList = null;
			for(int i = 0; i < (hcpCSVList.stream().distinct().collect(Collectors.toList())).size();i++) {
				String hcpCSV = (hcpCSVList.stream().distinct().collect(Collectors.toList())).get(i);
				if(Objects.nonNull(hcpCSV)) {
					
					if (Objects.isNull(clinicWiseHCPList)) {
						clinicWiseHCPList = new HashMap<String, List<ClinicAdminVO>>();
					}
					hcpList = clinicWiseHCPList.get(hcpCSV.split("##")[0]); 
					if(Objects.isNull(hcpList)) {
						hcpList = new ArrayList<ClinicAdminVO>();
					}

					//HcpDetailsVO hcpDetails = new HcpDetailsVO();
					ClinicAdminVO hcpDetails = new ClinicAdminVO();
					//hcpDetails.setHcpClinicId(hcpCSV.split("##")[0]);
					hcpDetails.setClinicAdminName(("null".equalsIgnoreCase(hcpCSV.split("##")[1]) ? null : hcpCSV.split("##")[1]) + "," 
					+ ("null".equalsIgnoreCase(hcpCSV.split("##")[2]) ? null : hcpCSV.split("##")[2]));
					hcpDetails.setClinicAdmincredentials("null".equalsIgnoreCase(hcpCSV.split("##")[3]) ? null : hcpCSV.split("##")[3]);
					hcpDetails.setClinicAdminPhoneNumber("null".equalsIgnoreCase(hcpCSV.split("##")[4]) ? null : hcpCSV.split("##")[4]);
					
					hcpList.add(hcpDetails);
					clinicWiseHCPList.put(hcpCSV.split("##")[0], hcpList);
				}
			}

			// CLINIC LIST
			List<MedicalTeamVO> medicalTeamList = null;
			for(int i = 0; i < (clinicCSVList.stream().distinct().collect(Collectors.toList())).size();i++) {
				String clinicCSV = (clinicCSVList.stream().distinct().collect(Collectors.toList())).get(i);
				if(Objects.nonNull(clinicCSV)) {
					MedicalTeamVO medicalTeamDetails = new MedicalTeamVO();
					medicalTeamDetails.setClinicId("null".equalsIgnoreCase(clinicCSV.split("##")[0]) ? null : clinicCSV.split("##")[0]);
					medicalTeamDetails.setClinicName("null".equalsIgnoreCase(clinicCSV.split("##")[1]) ? null : clinicCSV.split("##")[1]);
					medicalTeamDetails.setClinicAddress("null".equalsIgnoreCase(clinicCSV.split("##")[2]) ? null : clinicCSV.split("##")[2]);
					medicalTeamDetails.setClinicPhoneNumber("null".equalsIgnoreCase(clinicCSV.split("##")[3]) ? null : clinicCSV.split("##")[3]);
					
					// Add HCPs clinic Admin List
					//medicalTeamDetails.setHcpList((Objects.isNull(clinicWiseHCPList)) ? null : clinicWiseHCPList.get(medicalTeamDetails.getClinicId()));
					if (Objects.nonNull(clinicWiseHCPList) && Objects.nonNull(clinicWiseHCPList.get(medicalTeamDetails.getClinicId()))) {
						if(Objects.isNull(clinicAdminList)) {
							clinicAdminList = new ArrayList<ClinicAdminVO>();									
						}
						clinicAdminList.addAll(clinicWiseHCPList.get(medicalTeamDetails.getClinicId()));
					}

					medicalTeamDetails.setClinicAdminList(clinicAdminList);
					if(Objects.isNull(medicalTeamList)) {
						medicalTeamList = new ArrayList<MedicalTeamVO>();
					}
					medicalTeamList.add(medicalTeamDetails);
				}
				
			}
			
			if(Objects.nonNull(deviceDetailsList)) {
				patientProfileDetails.setDevicesDetails(deviceDetailsList);
			}
			if(Objects.nonNull(medicalTeamList)) {
				patientProfileDetails.setClinicsAndMedicalTeam(medicalTeamList);	
			}
			jsonObject.put("patientDetails", patientProfileDetails);
		} else {
			jsonObject.put("message", ExceptionConstants.HR_512);
		}
		
		
	return jsonObject;
}

private  Map<String, List<ProtocolDataListVO>> getProtocolList(List<String> minFreqList, List<String> maxFreqList, List<String> minMptList, 
		List<String> maxMptList, List<String> minPressureList, List<String> maxPressureList, List<String> tpdList, 
		List<String> protocolTypeList,List<String> deviceTypeList){
	Map<String,List<ProtocolDataListVO>> protocolMap = new HashMap<String,List<ProtocolDataListVO>>();
	//List<ProtocolDataListVO> protocolList = new ArrayList<ProtocolDataListVO>();
	List<ProtocolDataListVO> vestProtocolList = new ArrayList<ProtocolDataListVO>();
	List<ProtocolDataListVO> monarchProtocolList = new ArrayList<ProtocolDataListVO>();
	List<ProtocolDataListVO> titanProtocolList = new ArrayList<ProtocolDataListVO>();
	int i = 0;
	for(String deviceType:deviceTypeList) {
		if(deviceType.equalsIgnoreCase("v")) {
			ProtocolDataListVO protocolDataList = new ProtocolDataListVO();
			protocolDataList.setMinFrequency(minFreqList.get(i));
			protocolDataList.setMaxFrequency(maxFreqList.get(i));
			protocolDataList.setMinPressure(minPressureList.get(i));
			protocolDataList.setMaxPressure(maxPressureList.get(i));
			protocolDataList.setMin_minutes_per_treatment(minMptList.get(i));
			protocolDataList.setMax_minutes_per_treatment(maxMptList.get(i));
			protocolDataList.setTreatments_per_day(tpdList.get(i));
			protocolDataList.setProtocolType(protocolTypeList.get(i));
			i++;
			vestProtocolList.add(protocolDataList);
		} else if(deviceType.equalsIgnoreCase("m")) {
			ProtocolDataListVO protocolDataList = new ProtocolDataListVO();
			protocolDataList.setMinFrequency(minFreqList.get(i));
			protocolDataList.setMaxFrequency(maxFreqList.get(i));
			protocolDataList.setMinPressure(minPressureList.get(i));
			protocolDataList.setMaxPressure(maxPressureList.get(i));
			protocolDataList.setMin_minutes_per_treatment(minMptList.get(i));
			protocolDataList.setMax_minutes_per_treatment(maxMptList.get(i));
			protocolDataList.setTreatments_per_day(tpdList.get(i));
			protocolDataList.setProtocolType(protocolTypeList.get(i));
			i++;
			monarchProtocolList.add(protocolDataList);
		}
		else {
			ProtocolDataListVO protocolDataList = new ProtocolDataListVO();
			protocolDataList.setMinFrequency(minFreqList.get(i));
			protocolDataList.setMaxFrequency(maxFreqList.get(i));
			protocolDataList.setMinPressure(minPressureList.get(i));
			protocolDataList.setMaxPressure(maxPressureList.get(i));
			protocolDataList.setMin_minutes_per_treatment(minMptList.get(i));
			protocolDataList.setMax_minutes_per_treatment(maxMptList.get(i));
			protocolDataList.setTreatments_per_day(tpdList.get(i));
			protocolDataList.setProtocolType(protocolTypeList.get(i));
			i++;
			titanProtocolList.add(protocolDataList);
		}
	}
	protocolMap.put("Vest", vestProtocolList);
	protocolMap.put("Monarch", monarchProtocolList);
	protocolMap.put("Titan", titanProtocolList);
	return protocolMap;
}

private List<ProtocolDataListVO> getProtocolListForBasicInfo(List<String> minFreqList, List<String> maxFreqList, List<String> minMptList, 
		List<String> maxMptList, List<String> minPressureList, List<String> maxPressureList, List<String> tpdList, 
		List<String> protocolTypeList){
	List<ProtocolDataListVO> protocolList = new ArrayList<ProtocolDataListVO>();
	int i = 0;
	for(String protocolType:protocolTypeList) {
			ProtocolDataListVO protocolDataList = new ProtocolDataListVO();
			protocolDataList.setMinFrequency(minFreqList.get(i).equals("null") ? null : minFreqList.get(i));
			protocolDataList.setMaxFrequency(maxFreqList.get(i).equals("null") ? null : maxFreqList.get(i));
			protocolDataList.setMinPressure(minPressureList.get(i).equals("null") ? null : minPressureList.get(i));
			protocolDataList.setMaxPressure(maxPressureList.get(i).equals("null") ? null : maxPressureList.get(i));
			protocolDataList.setMin_minutes_per_treatment(minMptList.get(i).equals("null") ? null : minMptList.get(i));
			protocolDataList.setMax_minutes_per_treatment(maxMptList.get(i).equals("null") ? null : maxMptList.get(i));
			protocolDataList.setTreatments_per_day(tpdList.get(i).equals("null") ? null : tpdList.get(i));
			protocolDataList.setProtocolType(protocolType);
			i++;
			protocolList.add(protocolDataList);
	}
	return protocolList;

}

private List<ProtocolDataListVO> getProtocolListForBasicInfoTitan(List<String> minFreqList, List<String> maxFreqList, List<String> minMptList, 
		List<String> maxMptList, List<String> minIntensityList, List<String> maxIntensityList, List<String> tpdList, 
		List<String> protocolTypeList){
	List<ProtocolDataListVO> protocolList = new ArrayList<ProtocolDataListVO>();
	int i = 0;
	for(String protocolType:protocolTypeList) {
			ProtocolDataListVO protocolDataList = new ProtocolDataListVO();
			protocolDataList.setMinFrequency(minFreqList.get(i).equals("null") ? null : minFreqList.get(i));
			protocolDataList.setMaxFrequency(maxFreqList.get(i).equals("null") ? null : maxFreqList.get(i));
			protocolDataList.setMinPressure(minIntensityList.get(i).equals("null") ? null : minIntensityList.get(i));
			protocolDataList.setMaxPressure(maxIntensityList.get(i).equals("null") ? null : maxIntensityList.get(i));
			protocolDataList.setMin_minutes_per_treatment(minMptList.get(i).equals("null") ? null : minMptList.get(i));
			protocolDataList.setMax_minutes_per_treatment(maxMptList.get(i).equals("null") ? null : maxMptList.get(i));
			protocolDataList.setTreatments_per_day(tpdList.get(i).equals("null") ? null : tpdList.get(i));
			protocolDataList.setProtocolType(protocolType);
			i++;
			protocolList.add(protocolDataList);
	}
	return protocolList;

}


private long retrieveVersion(String ver)
{
	long actual = 0L;
	String[] splits = ver.split("\\.");
	actual += Long.parseLong(splits[3]);
	actual += Long.parseLong(splits[2]) * 100;
	actual += Long.parseLong(splits[1]) * 10000;
	actual += Long.parseLong(splits[0]) * 1000000;		
	return actual;
}

public JSONObject forceUpgradeApp(String version, String deviceType) {
	JSONObject jsonObject = new JSONObject();
	boolean forceUpgrade = false;
	List<HillromTypeCodeFormat> typeCodeList;
	
	if(deviceType.equalsIgnoreCase("ios")) {
		typeCodeList = hillromTypeCodeFormatRepository
			.findCodeValuesListByTypeCode("ios");
	}else {
		typeCodeList = hillromTypeCodeFormatRepository
				.findCodeValuesListByTypeCode("android");		
	}

	Long deviceTypeCode = typeCodeList.get(0).getId();

	ManageAppVersion mav = manageAppVersionRepository.findOneByVersionAndType(deviceTypeCode.toString());	
			
	if(Objects.nonNull(mav)) {
		String activeVersion = mav.getVersion();			
		Long devVersion  = retrieveVersion(version);
		Long actVersion = retrieveVersion(activeVersion);
		if(actVersion > devVersion) {
			forceUpgrade = mav.isIs_force_upgrade();
			if(forceUpgrade) {
				jsonObject.put("forceUpgrade", true);
				jsonObject.put("isUpdateOptional", false);
			}else {
				jsonObject.put("forceUpgrade", true);
				jsonObject.put("isUpdateOptional", true);
			}
		}else {
			jsonObject.put("forceUpgrade", false);
			jsonObject.put("isUpdateOptional", false);			
		}		
	}else {
		jsonObject.put("forceUpgrade", false);
		jsonObject.put("isUpdateOptional", false);
	}
	
	return jsonObject;
}

private void reSendEmailNotificationForMobileUser(String baseUrl, UserExtension user) {
	user.setActivationKey(RandomUtil.generateActivationKey());
	user.setActivated(false);
	user.setActivationLinkSentDate(DateTime.now());
	userRepository.saveAndFlush(user);
	mailService.reSendActivationEmail(user, baseUrl);
	eventPublisher.publishEvent(new OnCredentialsChangeEvent(user.getId()));
}


/**
 * validates password of logged-in user
 *
  * @param password
 * @return
 * @throws HillromException
 */
 public JSONObject validatePassword(String username, String password)
               throws HillromException {
        JSONObject jsonObject = new JSONObject();
        boolean isValid = false;

        if (Objects.isNull(password))
               jsonObject.put("message", ExceptionConstants.HR_714);

        if (Objects.isNull(username))
               jsonObject.put("message", ExceptionConstants.HR_714);
       
        Optional<User> userFromDatabase = userService
                     .findOneByEmailOrHillromId(username);
        User user = null;
        if (userFromDatabase.isPresent()) {
               user = userFromDatabase.get();
        } else {
               jsonObject.put("message", ExceptionConstants.HR_704);
               return jsonObject;
        }
        if (passwordEncoder.matches(password, user.getPassword()))
               isValid= true;
       
               jsonObject.put("status",isValid);

        return jsonObject;

 	}
 
	public JSONObject getTherapyReminderList(String pid) {
		JSONObject jsonObject = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOne(pid);
		if (Objects.nonNull(patientInfo)) {
			jsonObject.put("reminders", patientInfo.getExtended_info());
		} else {
			jsonObject.put("message", ExceptionConstants.HR_915);
		}
		return jsonObject;
	}

	public JSONObject updateTherapyReminderList(TherapyReminderDTO therapyReminder) {
		JSONObject jsonObject = new JSONObject();
		PatientInfo patientInfo = patientInfoRepository.findOne(therapyReminder.getPid());
		if (Objects.nonNull(patientInfo)) {
			patientInfo.setExtended_info(therapyReminder.getReminders());
			jsonObject.put("message", ExceptionConstants.HR_937);
		} else {
			jsonObject.put("message", ExceptionConstants.HR_915);
		}
		return jsonObject;
	}

	public JSONObject updateBYOD(Long userId, BYODUpdateDTO dto)
	{
		JSONObject jsonObject = new JSONObject();
		User associatedUser = userRepository.findOne(userId);
		if(Objects.nonNull(associatedUser)) {
			List<UserPatientAssoc> associations = userPatientRepository.findOneByUserId(userId);
			UserPatientAssoc userPatientAssoc;
			if(associations.isEmpty()){
				jsonObject.put("ERROR",ExceptionConstants.HR_512);
				return jsonObject;
			} else {
				userPatientAssoc =associations.get(0);
				if(Objects.isNull(userPatientAssoc)){
					jsonObject.put("ERROR",ExceptionConstants.HR_915);
					return jsonObject;
				}
			}
			
			if(dto.getDnd()) {
				List<PatientDevicesAssoc> patientDevicesAssocList = patientDevicesAssocRepository.findByPatientId(userPatientAssoc.getPatient().getId());
				for (PatientDevicesAssoc patientDevicesAssoc : patientDevicesAssocList) {
					if(patientDevicesAssoc.getDeviceType().equals(Constants.VEST)) {
						Optional<PatientVestDeviceHistory> patientVestDeviceHistory = patientVestDeviceRepository.findOneByPatientIdAndSerialNumberAndStatusActive(patientDevicesAssoc.getPatientId(), patientDevicesAssoc.getSerialNumber());
						
						if(patientVestDeviceHistory.isPresent()) {
							PatientVestDeviceHistory patientVestDevice = patientVestDeviceHistory.get();
							patientVestDevice.setDndIdentifier(dto.getPhoneIdentifier());
							patientVestDevice.setIsDnd(dto.getDnd());
							patientVestDeviceRepository.saveAndFlush(patientVestDevice);
						}
					}else if(patientDevicesAssoc.getDeviceType().equals(Constants.MONARCH)) {
						Optional<PatientVestDeviceHistoryMonarch> patientMonarchDeviceHistory = patientMonarchDeviceRepository.findOneByPatientIdAndSerialNumberAndStatusActive(patientDevicesAssoc.getPatientId(), patientDevicesAssoc.getSerialNumber());
						
						if(patientMonarchDeviceHistory.isPresent()) {
							PatientVestDeviceHistoryMonarch patientMonarchDevice = patientMonarchDeviceHistory.get();
							patientMonarchDevice.setDndIdentifier(dto.getPhoneIdentifier());
							patientMonarchDevice.setIsDnd(dto.getDnd());
							patientMonarchDeviceRepository.saveAndFlush(patientMonarchDevice);
						}						
					}
					patientDevicesAssoc.setIsDnd(dto.getDnd());
					patientDevicesAssoc.setDndIdentifier(dto.getPhoneIdentifier());
					patientDevicesAssocRepository.saveAndFlush(patientDevicesAssoc);
				}
			}
			
			if(Objects.nonNull(dto.getDeviceInfo())) 
			{
				for(int i=0; i < dto.getDeviceInfo().size(); i++) {
					BYODUpdateDeviceInfo deviceInfo = dto.getDeviceInfo().get(i);
					Optional<PatientDevicesAssoc> deviceAssoc = patientDevicesAssocRepository.findOneBySerialNumberAndDeviceType(deviceInfo.getSerialNo(), deviceInfo.getDeviceType());
					if(deviceAssoc.isPresent())
					{
						PatientDevicesAssoc  device = deviceAssoc.get();
						PatientVestDeviceHistory patientVestDevice = null;
						PatientVestDeviceHistoryMonarch patientMonarchDevice = null;
						if(device.getDeviceType().equals(Constants.VEST)) {
							Optional<PatientVestDeviceHistory> patientVestDeviceHistory = patientVestDeviceRepository.findOneByPatientIdAndSerialNumberAndStatusActive(device.getPatientId(), device.getSerialNumber());
							if(patientVestDeviceHistory.isPresent()) {
								patientVestDevice = patientVestDeviceHistory.get();
							}
						}else if(device.getDeviceType().equals(Constants.MONARCH)) {
							Optional<PatientVestDeviceHistoryMonarch> patientMonarchDeviceHistory = patientMonarchDeviceRepository.findOneByPatientIdAndSerialNumberAndStatusActive(device.getPatientId(), device.getSerialNumber());
							
							if(patientMonarchDeviceHistory.isPresent()) {
								patientMonarchDevice = patientMonarchDeviceHistory.get();
							}						
						}

						if (deviceInfo.getByodState().equalsIgnoreCase(Constants.BYOD_PAIRED)) {
							if(Objects.nonNull(patientVestDevice)) {
								patientVestDevice.setByodState(Constants.BYOD_PAIRED);
								patientVestDevice.setByodLastUpdated(DateTime.now().getMillis());
								patientVestDevice.setByodDeviceIdentifier(dto.getPhoneIdentifier());
								patientVestDevice.setDndIdentifier(null);
								patientVestDevice.setIsDnd(false);
								patientVestDeviceRepository.save(patientVestDevice);
							}
							if(Objects.nonNull(patientMonarchDevice)) {
								patientMonarchDevice.setByodState(Constants.BYOD_PAIRED);
								patientMonarchDevice.setByodLastUpdated(DateTime.now().getMillis());
								patientMonarchDevice.setByodDeviceIdentifier(dto.getPhoneIdentifier());
								patientMonarchDevice.setDndIdentifier(null);
								patientMonarchDevice.setIsDnd(false);
								patientMonarchDeviceRepository.save(patientMonarchDevice);
							}
							device.setByodState(Constants.BYOD_PAIRED);
							device.setByodLastUpdated(DateTime.now().getMillis());
							device.setByodDeviceIdentifier(dto.getPhoneIdentifier());
							device.setDndIdentifier(dto.getPhoneIdentifier());
							device.setDndIdentifier(null);
							device.setIsDnd(false);
							patientDevicesAssocRepository.save(device);
						}else if(deviceInfo.getByodState().equalsIgnoreCase(Constants.BYOD_OPT_OUT_REQUESTED)) {
							if(Objects.nonNull(patientVestDevice)) {
								patientVestDevice.setByodState(Constants.BYOD_OPT_OUT_REQUESTED);
								patientVestDevice.setOptOutRequestedDate(DateTime.now().getMillis());								
								patientVestDeviceRepository.save(patientVestDevice);
							}
							if(Objects.nonNull(patientMonarchDevice)) {
								patientMonarchDevice.setByodState(Constants.BYOD_OPT_OUT_REQUESTED);
								patientMonarchDevice.setOptOutRequestedDate(DateTime.now().getMillis());								
								patientMonarchDeviceRepository.save(patientMonarchDevice);
							}
							device.setByodState(Constants.BYOD_OPT_OUT_REQUESTED);
							device.setOptOutRequestedDate(DateTime.now().getMillis());								
							patientDevicesAssocRepository.save(device);
						}else if(deviceInfo.getByodState().equalsIgnoreCase(Constants.BYOD_OPTED_OUT)) {
							if(Objects.nonNull(patientVestDevice)) {
								patientVestDevice.setByodState(Constants.BYOD_OPTED_OUT);
								patientVestDevice.setOptOutAgreedDate(DateTime.now().getMillis());
								patientVestDevice.setOptOutReason(deviceInfo.getReason());
								patientVestDevice.setOptOutFeedback(deviceInfo.getFeedback());
								patientVestDevice.setOptOutDeviceIdentifier(dto.getPhoneIdentifier());
								patientVestDeviceRepository.save(patientVestDevice);
							}
							if(Objects.nonNull(patientMonarchDevice)) {
								patientMonarchDevice.setByodState(Constants.BYOD_OPTED_OUT);
								patientMonarchDevice.setOptOutAgreedDate(DateTime.now().getMillis());
								patientMonarchDevice.setOptOutReason(deviceInfo.getReason());
								patientMonarchDevice.setOptOutFeedback(deviceInfo.getFeedback());
								patientMonarchDevice.setOptOutDeviceIdentifier(dto.getPhoneIdentifier());
								patientMonarchDeviceRepository.save(patientMonarchDevice);
							}
							device.setByodState(Constants.BYOD_OPTED_OUT);
							device.setOptOutAgreedDate(DateTime.now().getMillis());
							device.setOptOutReason(deviceInfo.getReason());
							device.setOptOutFeedback(deviceInfo.getFeedback());
							device.setOptOutDeviceIdentifier(dto.getPhoneIdentifier());
							patientDevicesAssocRepository.save(device);
						}else if(deviceInfo.getByodState().equalsIgnoreCase(Constants.BYOD_NOT_PAIRED)) {
							if(Objects.nonNull(patientVestDevice)) {
								patientVestDevice.setByodState(Constants.BYOD_NOT_PAIRED);
								patientVestDevice.setByodLastUpdated(DateTime.now().getMillis());
								patientVestDevice.setByodDeviceIdentifier(null);
								patientVestDeviceRepository.save(patientVestDevice);
							}
							if(Objects.nonNull(patientMonarchDevice)) {
								patientMonarchDevice.setByodState(Constants.BYOD_NOT_PAIRED);
								patientMonarchDevice.setByodLastUpdated(DateTime.now().getMillis());
								patientMonarchDevice.setByodDeviceIdentifier(null);
								patientMonarchDeviceRepository.save(patientMonarchDevice);
							}
							device.setByodState(Constants.BYOD_NOT_PAIRED);
							device.setByodLastUpdated(DateTime.now().getMillis());
							device.setByodDeviceIdentifier(null);
							patientDevicesAssocRepository.save(device);
						}
					}
				}
			}
			
			jsonObject.put("message", ExceptionConstants.HR_937);
		}else {
			jsonObject.put("ERROR", ExceptionConstants.HR_512);
		}
		return jsonObject;
	}
}
