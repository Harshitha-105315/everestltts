package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.MobileDeviceInfo;

@Repository
public interface MobileDeviceInfoRepository extends JpaRepository<MobileDeviceInfo, Long> {

	/*@Query("from MobileDeviceInfo mdi where mdi.patient_id = ?1 ORDER BY mdi.mobile_registration_datetime LIMIT 1")
	MobileDeviceInfo findOneByPatientIdAndMobileRegistrationDate(String patientId);*/
	
	@Query(nativeQuery=true,value=" SELECT * from MOBILE_DEVICE_INFO mdi where mdi.patient_id = ?1 ORDER BY mdi.mobile_registration_datetime LIMIT 1")
	MobileDeviceInfo findOneByPatientIdAndMobileRegistrationDate(String patientId);
	
	@Query("from MobileDeviceInfo mdi where mdi.patientId = ?1 group by concat(mdi.patientId, mdi.device_UUID, mdi.device_token)")
	List<MobileDeviceInfo> findByPatientIdAndGroupByPatientIDUUIDAndDeviceToken(String patientId );
	
	@Query("from MobileDeviceInfo mdi where mdi.patientId = ?1 and mdi.device_UUID = ?2 and mdi.platform_type = ?3 ")
	MobileDeviceInfo findByPatientIdAndUUIDAndDeviceType(String patientId,String UUID ,Long deviceType );
	
	@Query("from MobileDeviceInfo mdi where mdi.patientId = ?1 and mdi.device_UUID = ?2 ")
	MobileDeviceInfo findByPatientIdAndUUID(String patientId,String UUID);
	
	@Query("from MobileDeviceInfo mdi where mdi.device_UUID = ?1 ")
	MobileDeviceInfo findByUUID(String UUID);
	
	@Query("from MobileDeviceInfo mdi where mdi.device_UUID = ?1 and mdi.authentication_flag='1'")
	MobileDeviceInfo findByUUIDAndAuthenticationFlag(String UUID);
	
	@Query("from MobileDeviceInfo mdi where mdi.device_token = ?1 ")
	MobileDeviceInfo findByDeviceToken(String deviceToken);
	
	@Query("from MobileDeviceInfo mdi where mdi.patientId = ?1 and mdi.auth_token=?2")
	MobileDeviceInfo findByPatientIdAndXAuthToken(String patientId,String authToken);
	
	@Query("from MobileDeviceInfo mdi where mdi.auth_token=?1")
	MobileDeviceInfo findByXAuthToken(String authToken);

}
