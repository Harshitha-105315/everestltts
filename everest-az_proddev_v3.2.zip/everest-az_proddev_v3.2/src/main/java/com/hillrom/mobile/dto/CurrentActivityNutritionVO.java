package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class CurrentActivityNutritionVO {
	@ApiModelProperty(notes="Target Calorie Intake per day (Long stored as String)", required=true, example="2000")
	private String caloriesTargetInTake;
	@ApiModelProperty(notes="Goal start date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalStartDate;
	@ApiModelProperty(notes="Goal end date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalEndDate;
	@ApiModelProperty(notes="Goal name", required=true, example="Foodie!!!")
	private String name;
	@ApiModelProperty(notes="Activity Id (Long)", required=true, example="2")
	private Long activityId;
	
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getCaloriesTargetInTake() {
		return caloriesTargetInTake;
	}
	public void setCaloriesTargetInTake(String caloriesTargetInTake) {
		this.caloriesTargetInTake = caloriesTargetInTake;
	}
	public Long getGoalEndDate() {
		return goalEndDate;
	}
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getGoalStartDate() {
		return goalStartDate;
	}
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	
	
}