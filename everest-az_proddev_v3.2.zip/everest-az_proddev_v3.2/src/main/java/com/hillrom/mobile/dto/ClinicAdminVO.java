package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class ClinicAdminVO {

	@ApiModelProperty(notes="clinicAdminName (String)", dataType="java.lang.String", required=true)
	private String clinicAdminName;
	@ApiModelProperty(notes="clinicAdmincredentials (String)", dataType="java.lang.String", required=true)
	private String clinicAdmincredentials;
	@ApiModelProperty(notes="clinicAdminPhoneNumber (String)", dataType="java.lang.String", required=true)
	private String clinicAdminPhoneNumber;
	
	public String getClinicAdminName() {
		return clinicAdminName;
	}
	public void setClinicAdminName(String clinicAdminName) {
		this.clinicAdminName = clinicAdminName;
	}
	public String getClinicAdmincredentials() {
		return clinicAdmincredentials;
	}
	public void setClinicAdmincredentials(String clinicAdmincredentials) {
		this.clinicAdmincredentials = clinicAdmincredentials;
	}
	public String getClinicAdminPhoneNumber() {
		return clinicAdminPhoneNumber;
	}
	public void setClinicAdminPhoneNumber(String clinicAdminPhoneNumber) {
		this.clinicAdminPhoneNumber = clinicAdminPhoneNumber;
	}
	public ClinicAdminVO(String clinicAdminName, String clinicAdmincredentials, String clinicAdminPhoneNumber) {
		super();
		this.clinicAdminName = clinicAdminName;
		this.clinicAdmincredentials = clinicAdmincredentials;
		this.clinicAdminPhoneNumber = clinicAdminPhoneNumber;
	}
	public ClinicAdminVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ClinicAdminVO [clinicAdminName=" + clinicAdminName + ", clinicAdmincredentials="
				+ clinicAdmincredentials + ", clinicAdminPhoneNumber=" + clinicAdminPhoneNumber + "]";
	}
	
	
}
