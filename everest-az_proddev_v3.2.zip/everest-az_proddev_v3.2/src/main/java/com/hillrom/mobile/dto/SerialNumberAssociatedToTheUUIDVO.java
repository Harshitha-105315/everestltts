package com.hillrom.mobile.dto;

public class SerialNumberAssociatedToTheUUIDVO {
	
	private String serialNumber;
	private Boolean authentication_flag;

	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Boolean getAuthentication_flag() {
		return authentication_flag;
	}
	public void setAuthentication_flag(Boolean authentication_flag) {
		this.authentication_flag = authentication_flag;
	}
	@Override
	public String toString() {
		return "SerialNumberAssociatedToTheUUIDVO [serialNumber=" + serialNumber + ", authentication_flag="
				+ authentication_flag + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((authentication_flag == null) ? 0 : authentication_flag.hashCode());
		result = prime * result + ((serialNumber == null) ? 0 : serialNumber.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SerialNumberAssociatedToTheUUIDVO other = (SerialNumberAssociatedToTheUUIDVO) obj;
		if (authentication_flag == null) {
			if (other.authentication_flag != null)
				return false;
		} else if (!authentication_flag.equals(other.authentication_flag))
			return false;
		if (serialNumber == null) {
			if (other.serialNumber != null)
				return false;
		} else if (!serialNumber.equals(other.serialNumber))
			return false;
		return true;
	}
	public SerialNumberAssociatedToTheUUIDVO(String serialNumber, Boolean authentication_flag) {
		super();
		this.serialNumber = serialNumber;
		this.authentication_flag = authentication_flag;
	}
	
}
