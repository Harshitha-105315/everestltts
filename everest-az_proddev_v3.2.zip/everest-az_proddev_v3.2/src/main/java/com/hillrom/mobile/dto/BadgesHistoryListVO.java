package com.hillrom.mobile.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class BadgesHistoryListVO {

	@ApiModelProperty(notes="badgesUnlockedList (List)", required=true)
	private List<BadgesUnlockedVO> badgesUnlockedList;
	@ApiModelProperty(notes="badgesLockedList (List)", required=true)
	private List<BadgesLockedVO> badgesLockedList;
	public List<BadgesUnlockedVO> getBadgesUnlockedList() {
		return badgesUnlockedList;
	}
	public void setBadgesUnlockedList(List<BadgesUnlockedVO> badgesUnlockedList) {
		this.badgesUnlockedList = badgesUnlockedList;
	}
	public List<BadgesLockedVO> getBadgesLockedList() {
		return badgesLockedList;
	}
	public void setBadgesLockedList(List<BadgesLockedVO> badgesLockedList) {
		this.badgesLockedList = badgesLockedList;
	}
	
	@Override
	public String toString() {
		return "BadgesHistoryListVO [badgesUnlockedList=" + badgesUnlockedList + ", badgesLockedList="
				+ badgesLockedList + "]";
	}
}
