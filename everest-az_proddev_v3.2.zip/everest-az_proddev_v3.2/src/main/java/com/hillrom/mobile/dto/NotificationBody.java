package com.hillrom.mobile.dto;

public class NotificationBody {
	//@SerializedName("category")
    private String category;
    
    //@SerializedName("type")
    private String type;
    
    //@SerializedName("title")
    private String title;
    
    //@SerializedName("description")
    private String description;
    
    //@SerializedName("badgeId")
    private String badgeId;
    
    //@SerializedName("badgeCategory")
    private String badgeCategory;
    
    //@SerializedName("badgeType")
    private String badgeType;

	public String getCategory() {
		return category;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBadgeId() {
		return badgeId;
	}

	public void setBadgeId(String badgeId) {
		this.badgeId = badgeId;
	}

	public String getBadgeCategory() {
		return badgeCategory;
	}

	public void setBadgeCategory(String badgeCategory) {
		this.badgeCategory = badgeCategory;
	}

	public String getBadgeType() {
		return badgeType;
	}

	public void setBadgeType(String badgeType) {
		this.badgeType = badgeType;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public NotificationBody() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "NotificationBody [category=" + category + ", type=" + type + ", title=" + title + ", description="
				+ description + ", badgeId=" + badgeId + ", badgeCategory=" + badgeCategory + ", badgeType=" + badgeType
				+ "]";
	}
	

}
