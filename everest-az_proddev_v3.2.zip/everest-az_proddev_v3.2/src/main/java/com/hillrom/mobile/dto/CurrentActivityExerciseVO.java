package com.hillrom.mobile.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class CurrentActivityExerciseVO {
	@ApiModelProperty(notes="Exercise Days - Example[\"Monday\",\"Tuesday\"]", required=true)
	private List<String> execiseDays;
	@ApiModelProperty(notes="Exercise Duration", required=true, example="30")
	private String duration;
	@ApiModelProperty(notes="Goal start date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalStartDate;
	@ApiModelProperty(notes="Goal end date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalEndDate;
	@ApiModelProperty(notes="Name of the goal", required=true, example="My running")
	private String name;
	@ApiModelProperty(notes="Activity Id (Long)", dataType="java.lang.Long", required=true, example="1")
	private Long activityId;
	
	public Long getActivityId() {		
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public List<String> getExeciseDays() {
		return execiseDays;
	}
	public void setExeciseDays(List<String> execiseDays) {
		this.execiseDays = execiseDays;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Long getGoalEndDate() {
		return goalEndDate;
	}
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}
	public Long getGoalStartDate() {
		return goalStartDate;
	}
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
