package com.hillrom.mobile.rest;

import java.math.BigInteger;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.mobile.dto.UserPushNotificationDTO;
import com.hillrom.mobile.dto.UserPushNotificationVO;
import com.hillrom.mobile.dto.UserPushNotifictionStatusDTO;
import com.hillrom.mobile.service.PushNotificationService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.util.ExceptionConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import net.minidev.json.JSONObject;

@RestController
@Api(value = "NotificationsResource", description = "Notification RESOURCE")
@RequestMapping("/api/patient/"+ Constants.ApiVersion)
public class NotificationsResource {

	private final Logger logger = LoggerFactory.getLogger(NotificationsResource.class);
	
	@Inject
	public PushNotificationService pushNotificationService;

	@Inject
	private EntityManager entityManager;
	
	@RequestMapping(value = "/notifications/triggerTestNotification", 
			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> pushTestNotification(@RequestBody UserPushNotificationDTO upnDTO) {
		JSONObject jsonObject = new JSONObject();
		try {
			String message = pushNotificationService.pushTestNotificationToUser(upnDTO.getPid(), 
					upnDTO.getDevice_UUID(), upnDTO.getCategory(), upnDTO.getType());
			if (!StringUtils.isBlank(message)) {
				jsonObject.put("message", message);
			}
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		} catch (Exception e) {
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}

	}

	public static final String TEST_AWARD_ID =""
			+ "SELECT "
			+ "    paa.patient_id AS patient_id, "
			+ "    pah.id AS award_id, "
			+ "    paa.id AS activity_id, "
			+ "    htcv.type_code_value AS activity_type, "
			+ "    am.award_description AS award_description, "
			+ "    am.award_name AS award_name "
			+ "FROM "
			+ "    USER_EXTENSION uex "
			+ "        JOIN "
			+ "    USER_PATIENT_ASSOC upa ON uex.user_id = upa.user_id "
			+ "        JOIN "
			+ "    PATIENT_ACTIVITY_ASSOCIATION paa ON upa.patient_id = paa.patient_id "
			+ "        JOIN "
			+ "    PATIENT_AWARD_HISTORY pah ON paa.AWARD_ASSOC_ID = pah.id "
			+ "        JOIN "
			+ "    AWARD_MASTER am ON pah.AWARD_MASTER_ID = am.id "
			+ "        JOIN "
			+ "    HILLROM_TYPE_CODE_VALUES htcv ON paa.activity_type_id = htcv.id "
			+ "WHERE "
			+ "        upa.user_role = 'PATIENT' "
			+ "        AND paa.AWARD_ASSOC_ID IS NOT NULL ";

	@RequestMapping(value = "/test/awardNotification", 
			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> pushAwardNotification(@RequestParam(value = "activityId", required = true) String activityId) {
		JSONObject jsonObject = new JSONObject();
		try {
			String query = TEST_AWARD_ID;
			if (StringUtils.isBlank(query)) {
				logger.debug("QUERY_AWARDS_UNLOCKED_PATIENTS is null : " + query);
				return null;
			}
			String finalQuery = query + " AND paa.id=" + activityId + ";" ;
			Query nativeQuery = entityManager.createNativeQuery(finalQuery);
			@SuppressWarnings("unchecked")
			List<Object[]> resultSet = nativeQuery.getResultList();
			resultSet.stream().forEach((record) -> {
				String patient_id = record[0].toString();
				Long award_id = ((BigInteger) record[1]).longValue();
				Long activity_id = ((BigInteger) record[2]).longValue();
				String activityType = record[3].toString();
				String awardDescription = record[4].toString();
				String  awardName = record[5].toString();
				pushNotificationService.testPushNotificationForAward(patient_id, award_id, activity_id, activityType, awardDescription, awardName);
			});
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		} catch (Exception e) {
			jsonObject.put("message", e.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	
	
	@RequestMapping(value = "/notifications/retrieve/{pid}", method = RequestMethod.GET,
            	produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(httpMethod = "GET", value = "Get User Push Notfications",
				notes = "All values are required fields", responseContainer = "List")
    @ApiImplicitParams({
    @ApiImplicitParam(name = "pid", value = "patient Id", required = true, dataType = "String") })
    @ApiResponses(value = {	@ApiResponse(code = 200, message =  ExceptionConstants.HR_915
		    		+ " or \r\n" + ExceptionConstants.HR_916)})
	public ResponseEntity<Object> getUserPushNotifications(@PathVariable String pid){
	     logger.debug("REST request fetch user push notifications for patient : {}" + pid);
	     JSONObject jsonObject = new JSONObject();
	     try {
    	 List<UserPushNotificationVO> upnl = pushNotificationService.getUserPushNotifications(pid);
			if(upnl.isEmpty()) {
				jsonObject.put("message",ExceptionConstants.HR_953);
			} else {
				jsonObject.put("notificationList", upnl);
			}
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	     } catch (Exception hre){
			jsonObject.put("message",hre.getMessage());
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value="/notifications/medicationRefill", method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> executePushMedicationRefillCron(){
		JSONObject jsonObject = new JSONObject();
		pushNotificationService.medicationRefillReminderNotificationJob(true);
		jsonObject.put("Message", "Success");
		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/notifications/readStatus/update", method = RequestMethod.POST,
        	produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(httpMethod = "POST", value = "updatet Notfication read status",
	notes = "All values are required fields")
	@ApiResponses(value = {	@ApiResponse(code = 200, message =  ExceptionConstants.HR_937)})
	public ResponseEntity<Object> updateNotificationReadStatus(@RequestBody UserPushNotifictionStatusDTO upnsDTO) {
		JSONObject jsonObject = new JSONObject();
		if(upnsDTO.getPid() != null && upnsDTO.getNotificationReadStatusList().size() > 0) {
			try {
				String message = pushNotificationService.updateNotificationReadStatus(upnsDTO);
				if (!StringUtils.isBlank(message)) {
					jsonObject.put("message", message);
				}
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			} catch (Exception e) {
				jsonObject.put("message", e.getMessage());
				return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} else {
			jsonObject.put("message", ExceptionConstants.HR_916);
			return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);

		}
	}
	
	
	// TODO update read/unread status notification pushed

}
