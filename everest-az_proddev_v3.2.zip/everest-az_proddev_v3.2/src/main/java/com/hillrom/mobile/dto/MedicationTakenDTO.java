package com.hillrom.mobile.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class MedicationTakenDTO {
	
	@ApiModelProperty(notes="medicationId (Long)", dataType="java.lang.Long", required=true)
	private Long medicationId;
	@ApiModelProperty(notes="reminderId (Long)", dataType="java.lang.Long", required=true)
	private Long reminderId;
	
	private List<MedicationTakenTimeStampDTO> reminderUpdateTakenList;
	
	public Long getMedicationId() {
		return medicationId;
	}
	public void setMedicationId(Long medicationId) {
		this.medicationId = medicationId;
	}
	public Long getReminderId() {
		return reminderId;
	}
	public void setReminderId(Long reminderId) {
		this.reminderId = reminderId;
	}
	public List<MedicationTakenTimeStampDTO> getReminderUpdateTakenList() {
		return reminderUpdateTakenList;
	}
	public void setReminderUpdateTakenList(List<MedicationTakenTimeStampDTO> reminderUpdateTakenList) {
		this.reminderUpdateTakenList = reminderUpdateTakenList;
	}
	

}
