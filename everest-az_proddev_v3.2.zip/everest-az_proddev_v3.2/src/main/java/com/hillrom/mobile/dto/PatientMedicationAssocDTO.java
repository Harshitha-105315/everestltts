package com.hillrom.mobile.dto;

import org.joda.time.DateTime;

import com.hillrom.mobile.domain.MedicationsRecordings;
import com.hillrom.vest.domain.PatientInfo;

public class PatientMedicationAssocDTO {
	
	
	private Long id;
	
	private MedicationsRecordings medicationId;
	
	private PatientInfo patient;

	private DateTime createdTime = DateTime.now();
	
	private boolean isArchive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MedicationsRecordings getMedicationId() {
		return medicationId;
	}

	public void setMedicationId(MedicationsRecordings medicationId) {
		this.medicationId = medicationId;
	}

	public PatientInfo getPatient() {
		return patient;
	}

	public void setPatient(PatientInfo patient) {
		this.patient = patient;
	}

	public DateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(DateTime createdTime) {
		this.createdTime = createdTime;
	}

	public boolean isArchive() {
		return isArchive;
	}

	public void setArchive(boolean isArchive) {
		this.isArchive = isArchive;
	}

	@Override
	public String toString() {
		return "PatientMedicalAssocDto [id=" + id + ", medicationId="
				+ medicationId + ", patient=" + patient + ", createdTime="
				+ createdTime + ", isArchive=" + isArchive + "]";
	}

	public PatientMedicationAssocDTO(Long id, MedicationsRecordings medicationId,
			PatientInfo patient, DateTime createdTime, boolean isArchive) {
		super();
		this.id = id;
		this.medicationId = medicationId;
		this.patient = patient;
		this.createdTime = createdTime;
		this.isArchive = isArchive;
	}

	public PatientMedicationAssocDTO() {
		super();
	}

}