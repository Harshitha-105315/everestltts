package com.hillrom.mobile.dto;

import java.util.List;

public class BasicInfoDetailsVO {

	public BasicInfoDetailsVO() {
		super();
	}	
	
private	String patientID;
private List<DeviceDetailsVO> device_details;
private ProfileSupportVO support;
private MobileAppVO mobileApp;
private FirstTransmissionVO  firstTransmission;
private ChartbasicsVO chartbasics;
private  AwardAndBadgesVersionNumberVO awardorBadgesVersionNumber;
private LegalTermsAndConditionsVO legalTermsAndConditionsurl;
private SerialNumberAssociatedToTheUUIDVO serialNumberAssociatedToTheUUID;
private String weight;
private String height;
private String Origin;
private String gender;
private String last_pft_result_date;
private String therapy_duration;
private String therapy_protocol;
private String last_therapy_date;
private String firt_pft_result_date;
private Long unReadNotifications;
private Boolean firstTimeLoginInPhone;
private RevisionInfo revInfo;

public Boolean getFirstTimeLoginInPhone() {
	return firstTimeLoginInPhone;
}
public void setFirstTimeLoginInPhone(Boolean firstTimeLoginInPhone) {
	this.firstTimeLoginInPhone = firstTimeLoginInPhone;
}
public Long getUnReadNotifications() {
	return unReadNotifications;
}
public void setUnReadNotifications(Long unReadNotifications) {
	this.unReadNotifications = unReadNotifications;
}
public String getLast_pft_result_date() {
	return last_pft_result_date;
}
public void setLast_pft_result_date(String last_test_result_date) {
	this.last_pft_result_date = last_test_result_date;
}

public String getFirt_pft_result_date() {
	return firt_pft_result_date;
}
public void setFirt_pft_result_date(String firt_pft_result_date) {
	this.firt_pft_result_date = firt_pft_result_date;
}
public String getPatientID() {
	return patientID;
}
public void setPatientID(String patientID) {
	this.patientID = patientID;
}
public List<DeviceDetailsVO> getDevice_details() {
	return device_details;
}
public void setDevice_details(List<DeviceDetailsVO> device_details) {
	this.device_details = device_details;
}
public ProfileSupportVO getSupport() {
	return support;
}
public void setSupport(ProfileSupportVO support) {
	this.support = support;
}
public MobileAppVO getMobileApp() {
	return mobileApp;
}
public void setMobileApp(MobileAppVO mobileApp) {
	this.mobileApp = mobileApp;
}
public FirstTransmissionVO getFirstTransmission() {
	return firstTransmission;
}
public void setFirstTransmission(FirstTransmissionVO firstTransmission) {
	this.firstTransmission = firstTransmission;
}
public ChartbasicsVO getChartbasics() {
	return chartbasics;
}
public void setChartbasics(ChartbasicsVO chartbasics) {
	this.chartbasics = chartbasics;
}
public AwardAndBadgesVersionNumberVO getAwardorBadgesVersionNumber() {
	return awardorBadgesVersionNumber;
}
public void setAwardorBadgesVersionNumber(
		AwardAndBadgesVersionNumberVO awardorBadgesVersionNumber) {
	this.awardorBadgesVersionNumber = awardorBadgesVersionNumber;
}
public LegalTermsAndConditionsVO getLegalTermsAndConditionsurl() {
	return legalTermsAndConditionsurl;
}
public void setLegalTermsAndConditionsurl(
		LegalTermsAndConditionsVO legalTermsAndConditionsurl) {
	this.legalTermsAndConditionsurl = legalTermsAndConditionsurl;
}
public String getWeight() {
	return weight;
}
public void setWeight(String weight) {
	this.weight = weight;
}
public String getHeight() {
	return height;
}
public void setHeight(String height) {
	this.height = height;
}
public String getOrigin() {
	return Origin;
}
public void setOrigin(String origin) {
	Origin = origin;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public SerialNumberAssociatedToTheUUIDVO getSerialNumberAssociatedToTheUUID() {
	return serialNumberAssociatedToTheUUID;
}
public void setSerialNumberAssociatedToTheUUID(
		SerialNumberAssociatedToTheUUIDVO serialNumberAssociatedToTheUUID) {
	this.serialNumberAssociatedToTheUUID = serialNumberAssociatedToTheUUID;
}
public String getTherapy_duration() {
	return therapy_duration;
}
public void setTherapy_duration(String therapy_duration) {
	this.therapy_duration = therapy_duration;
}
public String getTherapy_protocol() {
	return therapy_protocol;
}
public void setTherapy_protocol(String therapy_protocol) {
	this.therapy_protocol = therapy_protocol;
}
public String getLast_therapy_date() {
	return last_therapy_date;
}
public void setLast_therapy_date(String last_therapy_date) {
	this.last_therapy_date = last_therapy_date;
}
public RevisionInfo getRevInfo() {
	return revInfo;
}
public void setRevInfo(RevisionInfo revInfo) {
	this.revInfo = revInfo;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((Origin == null) ? 0 : Origin.hashCode());
	result = prime * result + ((awardorBadgesVersionNumber == null) ? 0 : awardorBadgesVersionNumber.hashCode());
	result = prime * result + ((chartbasics == null) ? 0 : chartbasics.hashCode());
	result = prime * result + ((device_details == null) ? 0 : device_details.hashCode());
	result = prime * result + ((firstTimeLoginInPhone == null) ? 0 : firstTimeLoginInPhone.hashCode());
	result = prime * result + ((firstTransmission == null) ? 0 : firstTransmission.hashCode());
	result = prime * result + ((firt_pft_result_date == null) ? 0 : firt_pft_result_date.hashCode());
	result = prime * result + ((gender == null) ? 0 : gender.hashCode());
	result = prime * result + ((height == null) ? 0 : height.hashCode());
	result = prime * result + ((last_pft_result_date == null) ? 0 : last_pft_result_date.hashCode());
	result = prime * result + ((last_therapy_date == null) ? 0 : last_therapy_date.hashCode());
	result = prime * result + ((legalTermsAndConditionsurl == null) ? 0 : legalTermsAndConditionsurl.hashCode());
	result = prime * result + ((mobileApp == null) ? 0 : mobileApp.hashCode());
	result = prime * result + ((patientID == null) ? 0 : patientID.hashCode());
	result = prime * result + ((revInfo == null) ? 0 : revInfo.hashCode());
	result = prime * result
			+ ((serialNumberAssociatedToTheUUID == null) ? 0 : serialNumberAssociatedToTheUUID.hashCode());
	result = prime * result + ((support == null) ? 0 : support.hashCode());
	result = prime * result + ((therapy_duration == null) ? 0 : therapy_duration.hashCode());
	result = prime * result + ((therapy_protocol == null) ? 0 : therapy_protocol.hashCode());
	result = prime * result + ((unReadNotifications == null) ? 0 : unReadNotifications.hashCode());
	result = prime * result + ((weight == null) ? 0 : weight.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	BasicInfoDetailsVO other = (BasicInfoDetailsVO) obj;
	if (Origin == null) {
		if (other.Origin != null)
			return false;
	} else if (!Origin.equals(other.Origin))
		return false;
	if (awardorBadgesVersionNumber == null) {
		if (other.awardorBadgesVersionNumber != null)
			return false;
	} else if (!awardorBadgesVersionNumber.equals(other.awardorBadgesVersionNumber))
		return false;
	if (chartbasics == null) {
		if (other.chartbasics != null)
			return false;
	} else if (!chartbasics.equals(other.chartbasics))
		return false;
	if (device_details == null) {
		if (other.device_details != null)
			return false;
	} else if (!device_details.equals(other.device_details))
		return false;
	if (firstTimeLoginInPhone == null) {
		if (other.firstTimeLoginInPhone != null)
			return false;
	} else if (!firstTimeLoginInPhone.equals(other.firstTimeLoginInPhone))
		return false;
	if (firstTransmission == null) {
		if (other.firstTransmission != null)
			return false;
	} else if (!firstTransmission.equals(other.firstTransmission))
		return false;
	if (firt_pft_result_date == null) {
		if (other.firt_pft_result_date != null)
			return false;
	} else if (!firt_pft_result_date.equals(other.firt_pft_result_date))
		return false;
	if (gender == null) {
		if (other.gender != null)
			return false;
	} else if (!gender.equals(other.gender))
		return false;
	if (height == null) {
		if (other.height != null)
			return false;
	} else if (!height.equals(other.height))
		return false;
	if (last_pft_result_date == null) {
		if (other.last_pft_result_date != null)
			return false;
	} else if (!last_pft_result_date.equals(other.last_pft_result_date))
		return false;
	if (last_therapy_date == null) {
		if (other.last_therapy_date != null)
			return false;
	} else if (!last_therapy_date.equals(other.last_therapy_date))
		return false;
	if (legalTermsAndConditionsurl == null) {
		if (other.legalTermsAndConditionsurl != null)
			return false;
	} else if (!legalTermsAndConditionsurl.equals(other.legalTermsAndConditionsurl))
		return false;
	if (mobileApp == null) {
		if (other.mobileApp != null)
			return false;
	} else if (!mobileApp.equals(other.mobileApp))
		return false;
	if (patientID == null) {
		if (other.patientID != null)
			return false;
	} else if (!patientID.equals(other.patientID))
		return false;
	if (revInfo == null) {
		if (other.revInfo != null)
			return false;
	} else if (!revInfo.equals(other.revInfo))
		return false;
	if (serialNumberAssociatedToTheUUID == null) {
		if (other.serialNumberAssociatedToTheUUID != null)
			return false;
	} else if (!serialNumberAssociatedToTheUUID.equals(other.serialNumberAssociatedToTheUUID))
		return false;
	if (support == null) {
		if (other.support != null)
			return false;
	} else if (!support.equals(other.support))
		return false;
	if (therapy_duration == null) {
		if (other.therapy_duration != null)
			return false;
	} else if (!therapy_duration.equals(other.therapy_duration))
		return false;
	if (therapy_protocol == null) {
		if (other.therapy_protocol != null)
			return false;
	} else if (!therapy_protocol.equals(other.therapy_protocol))
		return false;
	if (unReadNotifications == null) {
		if (other.unReadNotifications != null)
			return false;
	} else if (!unReadNotifications.equals(other.unReadNotifications))
		return false;
	if (weight == null) {
		if (other.weight != null)
			return false;
	} else if (!weight.equals(other.weight))
		return false;
	return true;
}
@Override
public String toString() {
	return "BasicInfoDetailsVO [patientID=" + patientID + ", device_details=" + device_details + ", support=" + support
			+ ", mobileApp=" + mobileApp + ", firstTransmission=" + firstTransmission + ", chartbasics=" + chartbasics
			+ ", awardorBadgesVersionNumber=" + awardorBadgesVersionNumber + ", legalTermsAndConditionsurl="
			+ legalTermsAndConditionsurl + ", serialNumberAssociatedToTheUUID=" + serialNumberAssociatedToTheUUID
			+ ", weight=" + weight + ", height=" + height + ", Origin=" + Origin + ", gender=" + gender
			+ ", last_pft_result_date=" + last_pft_result_date + ", therapy_duration=" + therapy_duration
			+ ", therapy_protocol=" + therapy_protocol + ", last_therapy_date=" + last_therapy_date
			+ ", firt_pft_result_date=" + firt_pft_result_date + ", unReadNotifications=" + unReadNotifications
			+ ", firstTimeLoginInPhone=" + firstTimeLoginInPhone + ", revInfo=" + revInfo + "]";
}


}
