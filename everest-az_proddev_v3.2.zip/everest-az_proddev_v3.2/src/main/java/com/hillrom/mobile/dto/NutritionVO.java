package com.hillrom.mobile.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "isGoalAchieved",
        "awardName",
        "targetNutritionGoal",
        "initialNutrition",
        "currentNutrition",
        "goalHistory"
})
public class NutritionVO {

    @JsonProperty("isGoalAchieved")
    private boolean isGoalAchieved;
    @JsonProperty("awardName")
    private String awardName;
    @JsonProperty("targetNutritionGoal")
    private int targetNutritionGoal;
    @JsonProperty("initialNutrition")
    private int initialNutrition;
    @JsonProperty("currentNutrition")
    private int currentNutrition;
    @JsonProperty("goalHistory")
    private List<NutritionHistoryDTO> goalNutritionHistory = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("isGoalAchieved")
    public boolean isIsGoalAchieved() {
        return isGoalAchieved;
    }

    @JsonProperty("isGoalAchieved")
    public void setIsGoalAchieved(boolean isGoalAchieved) {
        this.isGoalAchieved = isGoalAchieved;
    }

    @JsonProperty("awardName")
    public String getAwardName() {
        return awardName;
    }

    @JsonProperty("awardName")
    public void setAwardName(String awardName) {
        this.awardName = awardName;
    }

    @JsonProperty("targetNutritionGoal")
    public int getTargetNutritionGoal() {
        return targetNutritionGoal;
    }

    @JsonProperty("targetNutritionGoal")
    public void setTargetNutritionGoal(int targetNutritionGoal) {
        this.targetNutritionGoal = targetNutritionGoal;
    }

    @JsonProperty("initialNutrition")
    public int getInitialNutrition() {
        return initialNutrition;
    }

    @JsonProperty("initialNutrition")
    public void setInitialNutrition(int initialNutrition) {
        this.initialNutrition = initialNutrition;
    }

    @JsonProperty("currentNutrition")
    public int getCurrentNutrition() {
        return currentNutrition;
    }

    @JsonProperty("currentNutrition")
    public void setCurrentNutrition(int currentNutrition) {
        this.currentNutrition = currentNutrition;
    }

    @JsonProperty("goalHistory")
    public List<NutritionHistoryDTO> getGoalHistory() {
        return goalNutritionHistory;
    }

    @JsonProperty("goalHistory")
    public void setGoalHistory(List<NutritionHistoryDTO> goalHistory) {
        this.goalNutritionHistory = goalHistory;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}