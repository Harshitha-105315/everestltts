package com.hillrom.mobile.service;

import java.io.File;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.hillrom.mobile.dto.NotificationDataDTO;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.util.Profile;

import com.eatthepath.pushy.apns.ApnsClient;
import com.eatthepath.pushy.apns.ApnsClientBuilder;
import com.eatthepath.pushy.apns.PushNotificationResponse;
import com.eatthepath.pushy.apns.util.ApnsPayloadBuilder;
import com.eatthepath.pushy.apns.util.SimpleApnsPayloadBuilder;
import com.eatthepath.pushy.apns.util.SimpleApnsPushNotification;
import com.eatthepath.pushy.apns.util.concurrent.PushNotificationFuture;

@Service
public class IOSPushService {
	private final Logger logger = LoggerFactory.getLogger(IOSPushService.class);


    @Inject
	private Environment env;
    
	private final ApnsPayloadBuilder payloadBuilder = new SimpleApnsPayloadBuilder();


    public String SendNotification(String deviceToken, NotificationDataDTO data) {
    	logger.debug("IOS SendNotification:" + deviceToken);
    	try {
    		String cert_path = env.getProperty("spring.mobileapp.ios.certPath");
    		logger.debug("cert_path:" + cert_path);
    		if (StringUtils.isBlank(cert_path)) {
    			return "Certficate File path is Null";
    		}
    		
    		String cert_pwd = env.getProperty("spring.mobileapp.ios.certPassword");
    		logger.debug("cert_pwd:" + cert_pwd);
    		if (StringUtils.isBlank(cert_pwd)) {
    			return "Certficate password is Null";
    		}
    		
    		File file = ResourceUtils.getFile("classpath:" + Constants.CERTIFICATE_DIR + "/" + cert_path);
            if (!file.exists()) {
                  return "Certficate File does not exists";
            }

    		ApnsClient apnsClient = null;
    		SimpleApnsPushNotification pushNotification;
    		
    		if(env.getProperty("spring.profiles.active") != null && env.getProperty("spring.profiles.active").equals(Profile.prod.toString())) {
    			logger.debug("spring profile :"+env.getProperty("spring.profiles.active"));

    			//Create the object that handles the sending of push notifications.
    			apnsClient = new ApnsClientBuilder().setApnsServer(ApnsClientBuilder.PRODUCTION_APNS_HOST)
    					.setClientCredentials(file, cert_pwd).build();

    		} else {
    			apnsClient = new ApnsClientBuilder().setApnsServer(ApnsClientBuilder.DEVELOPMENT_APNS_HOST)
    					.setClientCredentials(file, cert_pwd).build();
    		}

    		//builds the apns payload for the push notification
    		String payload =  payloadBuilder.setAlertBody(data.getMessage().getDescription()).setAlertTitle(data.getMessage().getTitle())
    				.setSound("default").addCustomProperty("data", data).build();
    		logger.debug("IOS payload:" + payload);

    		//Creating the push notification object using the push token, 
    		pushNotification = new SimpleApnsPushNotification(deviceToken, Constants.APP_BUNDLE_ID, payload);
    		logger.debug("pushNotification:" + pushNotification);
    		
    		try {
    			final PushNotificationFuture<SimpleApnsPushNotification, PushNotificationResponse<SimpleApnsPushNotification>> sendNotificationFuture = apnsClient.sendNotification(pushNotification);
    			final PushNotificationResponse<SimpleApnsPushNotification> pushNotificationResponse = sendNotificationFuture.get();
    			logger.debug("pushNotificationResponse:" + pushNotificationResponse);
    			
    			if(pushNotificationResponse.isAccepted()) {
    				logger.debug("Push Notification accepted by APNS gateway.");
    				return "Success";
    			}else {
    				logger.debug("Push Notification rejected by APNS gateway "+pushNotificationResponse.getRejectionReason());
    			}
    		}catch(Exception e) {
    			logger.debug(e.getMessage(), "Failed to send push notification.");
    		}
    	} catch (Exception e) {
    		logger.debug(e.getMessage());
    	}
		return "Fail";
    }
}
