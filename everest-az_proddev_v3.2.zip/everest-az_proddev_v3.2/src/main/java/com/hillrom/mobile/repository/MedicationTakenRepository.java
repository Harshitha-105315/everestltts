package com.hillrom.mobile.repository;

import java.util.LinkedList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.mobile.domain.MedicationTaken;

public interface MedicationTakenRepository extends
		JpaRepository<MedicationTaken, String> {

	@Query("from MedicationTaken mt where mt.medicationReminderDetailsId = ?1 ")
	MedicationTaken findByMedicationId(Long medicationReminderDetailsId);

	@Query("from MedicationTaken mt where mt.medicationReminderDetailsId = ?1 ")
	MedicationTaken findByMedicationReminderId(Long medicationReminderDetailsId);

	@Query("from MedicationTaken mt where mt.medicationReminderDetailsId = ?1  and mt.med_taken_date_time = ?2")
	MedicationTaken findByReminderIdAndTimeStamp(Long reminderId, Long takenTimestamp);

	@Query("from MedicationTaken mt where mt.medicationReminderDetailsId = ?1  and mt.med_taken_date_time between ?2 and ?3")
	LinkedList<MedicationTaken> findByReminderIdWithinRange(Long reminderId, Long start, Long end);
	
	MedicationTaken findOneById(Long id);
}
