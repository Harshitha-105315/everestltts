package com.hillrom.mobile.service;

import java.util.List;
import java.util.Objects;

import javax.inject.Inject;
import javax.transaction.Transactional;

import net.minidev.json.JSONObject;

import org.springframework.stereotype.Service;

import com.hillrom.mobile.dto.PatientTestResultsDTO;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientTestResult;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientTestResultRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;

@Service
@Transactional
public class PateintTestResultMobileService {

	@Inject
	private UserRepository userRepository;

	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientTestResultRepository patientTestResultRepository;
	
	@Inject 
	private AwardsAndBadgesCalculatorService awardsAndBadgesCalculatorService;

	
	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for (UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()) {
			if (RelationshipLabelConstants.SELF.equals(patientAssoc
					.getRelationshipLabel())) {
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}

	public JSONObject createPatientTestResult(
			PatientTestResultsDTO patientTestResultsDTO, Long userId,
			String baseURL) throws HillromException {

		JSONObject jsonObject = new JSONObject();
		
		Boolean isValidDate = DateUtil.isDateTimeWithin90Days(patientTestResultsDTO.getTestResultDate());
		if (!isValidDate) {
			jsonObject.put("message", ExceptionConstants.HR_954);
			return jsonObject;
		}
		
		List<UserPatientAssoc> upaList = userPatientRepository.findByUserIdAndUserRole(userId, AuthoritiesConstants.PATIENT);
		if (Objects.isNull(upaList) || upaList.isEmpty()) {
			jsonObject.put("message", ExceptionConstants.HR_956);
			return jsonObject;
		}

		PatientInfo patientInfo = getPatientInfoObjFromPatientUser(upaList.get(0).getUser());
		PatientTestResult patientTestResult = new PatientTestResult();

		patientTestResult.setComments(patientTestResultsDTO.getComments());
		patientTestResult.setFEV1_L(patientTestResultsDTO.getFev1_L() == null ? 0.0 : patientTestResultsDTO.getFev1_L());
		patientTestResult.setFEV1_P(patientTestResultsDTO.getFev1_P() == null ? 0.0 : patientTestResultsDTO.getFev1_P());
		patientTestResult.setFEV1_TO_FVC_RATIO(patientTestResultsDTO.getFev1_TO_FVC_RATIO() == null ? 0.0 : patientTestResultsDTO.getFev1_TO_FVC_RATIO());
		patientTestResult.setFVC_L(patientTestResultsDTO.getFvc_L() == null ? 0.0 : patientTestResultsDTO.getFvc_L());
		patientTestResult.setFVC_P(patientTestResultsDTO.getFvc_P() == null ? 0.0 : patientTestResultsDTO.getFvc_P());
		patientTestResult.setPEF_L_Min(patientTestResultsDTO.getPef_L_Min() == null ? 0.0 : patientTestResultsDTO.getPef_L_Min());
		patientTestResult.setPEF_P(patientTestResultsDTO.getPef_P() == null ? 0.0 : patientTestResultsDTO.getPef_P());
		patientTestResult.setTestResultDate(patientTestResultsDTO.getTestResultDate());
		patientTestResult.setType(patientTestResultsDTO.getType());

		patientTestResult.setPatientInfo(patientInfo);
		patientTestResult.setUser(upaList.get(0).getUser());
		patientTestResult.setLastUpdatedBy(new StringBuilder(upaList.get(0).getUser().getLastName()).append(" ").append(upaList.get(0).getUser().getFirstName()).toString());

		patientTestResultRepository.save(patientTestResult);
		awardsAndBadgesCalculatorService.spiroLogMetrics(patientInfo.getId());

		jsonObject.put("Id", patientTestResult.getId());
		return jsonObject;
	}
}
