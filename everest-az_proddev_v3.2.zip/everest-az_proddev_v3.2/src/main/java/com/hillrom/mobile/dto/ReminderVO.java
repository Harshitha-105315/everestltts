package com.hillrom.mobile.dto;

public class ReminderVO {
	private Long reminderId;
	private String reminderTime;
	private boolean isTaken;
	public Long getReminderId() {
		return reminderId;
	}
	public void setReminderId(Long reminderId) {
		this.reminderId = reminderId;
	}
	public String getReminderTime() {
		return reminderTime;
	}
	public void setReminderTime(String reminderTime) {
		this.reminderTime = reminderTime;
	}
	public boolean isTaken() {
		return isTaken;
	}
	public void setTaken(boolean isTaken) {
		this.isTaken = isTaken;
	}
	public ReminderVO(Long reminderId, String reminderTime, boolean isTaken) {
		super();
		this.reminderId = reminderId;
		this.reminderTime = reminderTime;
		this.isTaken = isTaken;
	}
	public ReminderVO() {
		super();
	}
	@Override
	public String toString() {
		return "ReminderVO [reminderId=" + reminderId + ", reminderTime=" + reminderTime + ", isTaken=" + isTaken + "]";
	}
	
		
	
}
