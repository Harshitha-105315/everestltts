package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonPropertyOrder({
	"awardId",
	"activityName",
	"achievedDate",
	"activityId",
	"awardName",
	"isAchieved",
	"title",
	"message",
	"header",
	"image",
	"thumbNail",
	"activityType"
})
@ApiModel
public class AwardsHistoryVO {

	@JsonProperty(value="awardId")
	@ApiModelProperty(notes="Award ID", required=true, example="1")
	private Long awardId;
	
	@JsonProperty("activityName")
	@ApiModelProperty(notes="Activity name", required=true, example="My activity")
	private String activityName;
	
	@JsonProperty("achievedDate")
	@ApiModelProperty(notes="Date achieved(Long)", required=true, example="1535384304000" )
	private Long achievedDate;
	
	@JsonProperty("activityId")
	@ApiModelProperty(notes="Activity id (Long)", required=true, example="1")
	private Long activityId;
	
	@JsonProperty("awardName")
	@ApiModelProperty(notes="Award name", required=true, example="Perfection")
	private String awardName;
	
	@JsonProperty("isAchieved")
	@ApiModelProperty(notes="Is achieved", required=true, example="false")
	private Boolean isAchieved;
	
	@JsonProperty("title")
	@ApiModelProperty(notes="Awrad title ", required=true, example="perfection")
	private String title;
	
	@JsonProperty("message")
	@ApiModelProperty(notes="message", required=true, example="Award recieved for completing the Goal 100%")
	private String message;
	
	@JsonProperty("header")
	@ApiModelProperty(notes="header", required=true, example="Award unlocked")
	private String header;

	@JsonProperty("image")
	@ApiModelProperty(notes="image", required=true, example="/path/image.png")
	private String image;

	@JsonProperty("thumbNail")
	@ApiModelProperty(notes="thumbNail", required=true, example="/path/thumbNail.png")
	private String thumbNail;
	
	@JsonProperty("activityType")
	@ApiModelProperty(notes="Activity Type", required=true, example="My activity Type")
	private String activityType;
	
	@JsonProperty("image")
	public String getImage() {
		return image;
	}

	@JsonProperty("image")
	public void setImage(String image) {
		this.image = image;
	}

	@JsonProperty("thumbNail")
	public String getThumbNail() {
		return thumbNail;
	}

	@JsonProperty("thumbNail")
	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	@JsonProperty("awardId")
	public Long getAwardId() {
		return awardId;
	}

	@JsonProperty("awardId")
	public void setAwardId(Long awardId) {
		this.awardId = awardId;
	}

	@JsonProperty(value="activityName")
	public String getActivityName() {
		return activityName;
	}

	@JsonProperty("activityName")
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getHeader() {
		return header;
	}

	@JsonProperty("header")
	public void setHeader(String header) {
		this.header = header;
	}

	@JsonProperty("achievedDate")
	public Long getAchievedDate() {
		return achievedDate;
	}

	@JsonProperty("achievedDate")
	public void setAchievedDate(Long date) {
		this.achievedDate = date;
	}

	@JsonProperty("activityId")
	public Long getActivityId() {
		return activityId;
	}

	@JsonProperty("awardName")
	public String getAwardName() {
		return awardName;
	}

	@JsonProperty("awardName")
	public void setAwardName(String awardName) {
		this.awardName = awardName;
	}

	@JsonProperty("isAchieved")
	public Boolean getIsAchieved() {
		return isAchieved;
	}

	@JsonProperty("isAchieved")
	public void setIsAchieved(Boolean isAchieved) {
		this.isAchieved = isAchieved;
	}

	@JsonProperty("activityId")
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	
	@JsonProperty("title")
	public String getTitle() {
		return title;
	}
 	@JsonProperty("title")
	public void setTitle(String title) {
		this.title = title;
	}
 	@JsonProperty("message")
	public String getMessage() {
		return message;
	}
 	@JsonProperty("message")
	public void setMessage(String message) {
		this.message = message;
	}
 	@JsonProperty("activityType")
	public String getActivityType() {
		return activityType;
	}
 	@JsonProperty("activityType")
	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}
 	
 	
}