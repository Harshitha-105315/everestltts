package com.hillrom.mobile.domain;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

/**
 * A BADGES_MASTER.
 */
@Entity
@Table(name = "BADGES_MASTER")
public class BadgesMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    @ApiModelProperty(notes="ID of badge", dataType="java.lang.Long", required=true)
    private Long id;

    @JsonIgnore
    @Column(name = "ACTIVITY_TYPE_ID")
    private Long activityTypeId;

    @Column(name = "BADGE_NAME")
    @ApiModelProperty(notes="Name of badge", required=true)
    private String badgeName;

    @JsonIgnore
    @Column(name = "BADGE_THRESHOLD_VALUE")
    private String badgeThersholdValue;

    @Column(name = "BADGE_DESCRIPTION")
    @ApiModelProperty(notes="Description of badge", required=true)
    private String badgeDescription;

    @Column(name = "THUMBNAIL")
    @ApiModelProperty(notes="File path of thumnail image", required=true)
    private String thumbnail;

    @Column(name = "IMAGE")
    @ApiModelProperty(notes="File path of fullsize image", required=true)
    private String image;
    
    @Column(name = "category")
    @ApiModelProperty(notes="category", required=true)
    private String category;
    
    @Column(name = "type")
    @ApiModelProperty(notes="type", required=true)
    private String  type;
    
    @Column(name = "progress_description")
    @ApiModelProperty(notes="progress message", required=true)
    private String  progressDescription;
    
    @Column(name = "completed_description")
    @ApiModelProperty(notes="completion message", required=true)
    private String  completedDescription;
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getActivityTypeId() {
        return activityTypeId;
    }

    public void setActivityTypeId(Long activityTypeId) {
        this.activityTypeId = activityTypeId;
    }

    public String getBadgeName() {
        return badgeName;
    }

    public void setBadgeName(String badgeName) {
        this.badgeName = badgeName;
    }

    public String getBadgeThersholdValue() {
        return badgeThersholdValue;
    }

    public void setBadgeThersholdValue(String badgeThersholdValue) {
        this.badgeThersholdValue = badgeThersholdValue;
    }

    public String getBadgeDescription() {
        return badgeDescription;
    }

    public void setBadgeDescription(String badgeDescription) {
        this.badgeDescription = badgeDescription;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
    public String getProgressDescription() {
		return progressDescription;
	}

	public void setProgressDescription(String progressDescription) {
		this.progressDescription = progressDescription;
	}

	public String getCompletedDescription() {
		return completedDescription;
	}

	public void setCompletedDescription(String completedDescription) {
		this.completedDescription = completedDescription;
	}

	public BadgesMaster() {
    }

    public BadgesMaster(Long activityTypeId, String badgeName, String badgeThersholdValue, String badgeDescription,String thumbnail, String image) {
        this.activityTypeId = activityTypeId;
        this.badgeName = badgeName;
        this.badgeThersholdValue = badgeThersholdValue;
        this.badgeDescription = badgeDescription;
        this.thumbnail = thumbnail;
        this.image = image;
    }

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityTypeId == null) ? 0 : activityTypeId.hashCode());
		result = prime * result + ((badgeDescription == null) ? 0 : badgeDescription.hashCode());
		result = prime * result + ((badgeName == null) ? 0 : badgeName.hashCode());
		result = prime * result + ((badgeThersholdValue == null) ? 0 : badgeThersholdValue.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((completedDescription == null) ? 0 : completedDescription.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + ((progressDescription == null) ? 0 : progressDescription.hashCode());
		result = prime * result + ((thumbnail == null) ? 0 : thumbnail.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BadgesMaster other = (BadgesMaster) obj;
		if (activityTypeId == null) {
			if (other.activityTypeId != null)
				return false;
		} else if (!activityTypeId.equals(other.activityTypeId))
			return false;
		if (badgeDescription == null) {
			if (other.badgeDescription != null)
				return false;
		} else if (!badgeDescription.equals(other.badgeDescription))
			return false;
		if (badgeName == null) {
			if (other.badgeName != null)
				return false;
		} else if (!badgeName.equals(other.badgeName))
			return false;
		if (badgeThersholdValue == null) {
			if (other.badgeThersholdValue != null)
				return false;
		} else if (!badgeThersholdValue.equals(other.badgeThersholdValue))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (completedDescription == null) {
			if (other.completedDescription != null)
				return false;
		} else if (!completedDescription.equals(other.completedDescription))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (progressDescription == null) {
			if (other.progressDescription != null)
				return false;
		} else if (!progressDescription.equals(other.progressDescription))
			return false;
		if (thumbnail == null) {
			if (other.thumbnail != null)
				return false;
		} else if (!thumbnail.equals(other.thumbnail))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

    @Override
    public String toString() {
        return "BadgesMaster{" +
                "id=" + id +
                ", activityTypeId=" + activityTypeId +
                ", badgeName='" + badgeName + '\'' +
                ", badgeThersholdValue='" + badgeThersholdValue + '\'' +
                ", badgeDescription='" + badgeDescription + '\'' +
                ", thumbnail=" +thumbnail +
                ", image=" +image +
                '}';
    }

}
