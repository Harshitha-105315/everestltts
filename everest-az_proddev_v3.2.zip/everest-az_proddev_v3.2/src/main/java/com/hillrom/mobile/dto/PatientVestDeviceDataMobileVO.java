package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class PatientVestDeviceDataMobileVO {
	@ApiModelProperty(value="Serial Number",required=true)
	private String serialNumber;
	
	@ApiModelProperty(value="Created Date",required=false)
	private Long createdDate;
	
	@ApiModelProperty(value="Duration",required=true)
	private Integer duration;
	
	@ApiModelProperty(value="Frequency",required=false)
	private Integer frequency;
	
	@ApiModelProperty(value="Pressure",required=false)
	private Integer pressure;
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public Integer getFrequency() {
		return frequency;
	}
	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}
	public Integer getPressure() {
		return pressure;
	}
	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}
	
	@Override
	public String toString() {
		return "PatientVestDeviceDataMobileVO [serialNumber=" + serialNumber + ", dateTime=" + createdDate + ", duration="
				+ duration + ", frequency=" + frequency + ", pressure=" + pressure + "]";
	}

}
