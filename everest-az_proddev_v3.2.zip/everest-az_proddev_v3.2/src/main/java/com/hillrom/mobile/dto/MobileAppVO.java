package com.hillrom.mobile.dto;

public class MobileAppVO {

	public MobileAppVO() {
		super();
	}
	private String forceUpdate = "false"; // setting default value;
	private String version;
	private Boolean forceUpgrade;
	private Boolean isUpdateOptional;
	
	
	public Boolean getForceUpgrade() {
		return forceUpgrade;
	}
	public void setForceUpgrade(Boolean forceUpgrade) {
		this.forceUpgrade = forceUpgrade;
	}
	public Boolean getIsUpdateOptional() {
		return isUpdateOptional;
	}
	public void setIsUpdateOptional(Boolean isUpdateOptional) {
		this.isUpdateOptional = isUpdateOptional;
	}
	
	public String getForceUpdate() {
		return forceUpdate;
	}
	public void setForceUpdate(String forceUpdate) {
		this.forceUpdate = forceUpdate;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((forceUpdate == null) ? 0 : forceUpdate.hashCode());
		result = prime * result + ((forceUpgrade == null) ? 0 : forceUpgrade.hashCode());
		result = prime * result + ((isUpdateOptional == null) ? 0 : isUpdateOptional.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MobileAppVO other = (MobileAppVO) obj;
		if (forceUpdate == null) {
			if (other.forceUpdate != null)
				return false;
		} else if (!forceUpdate.equals(other.forceUpdate))
			return false;
		if (forceUpgrade == null) {
			if (other.forceUpgrade != null)
				return false;
		} else if (!forceUpgrade.equals(other.forceUpgrade))
			return false;
		if (isUpdateOptional == null) {
			if (other.isUpdateOptional != null)
				return false;
		} else if (!isUpdateOptional.equals(other.isUpdateOptional))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	
	
}
