package com.hillrom.mobile.service;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hillrom.mobile.domain.MedicationReminderDetails;
import com.hillrom.mobile.domain.MedicationTaken;
import com.hillrom.mobile.domain.MedicationsRecordings;
import com.hillrom.mobile.domain.PatientMedicationAssoc;
import com.hillrom.mobile.domain.PharmacyDetails;
import com.hillrom.mobile.dto.MedicationRemindersVO;
import com.hillrom.mobile.dto.MedicationTakenDTO;
import com.hillrom.mobile.dto.MedicationTakenListDTO;
import com.hillrom.mobile.dto.MedicationTakenTimeStampDTO;
import com.hillrom.mobile.dto.MedicationVO;
import com.hillrom.mobile.dto.PaientMedicationVO;
import com.hillrom.mobile.dto.PatientMedicationForTheDayVO;
import com.hillrom.mobile.dto.ReminderVO;
import com.hillrom.mobile.repository.MedicationReminderDetailsRepository;
import com.hillrom.mobile.repository.MedicationTakenRepository;
import com.hillrom.mobile.repository.MedicationsRecordingsRepository;
import com.hillrom.mobile.repository.PatientMedicationAssocRepository;
import com.hillrom.mobile.repository.PharmacyDetailsRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;


@Service
@Component
@Transactional
public class PatientMedicationService {
	private static final Logger logger = LoggerFactory.getLogger(PatientMedicationService.class);

	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	@Inject
	private PharmacyDetailsRepository pharmacyDetailsRepository;
	
	@Inject
	private PatientMedicationAssocRepository patientMedicationAssocRepository;
	
	@Inject
	private MedicationReminderDetailsRepository medicationReminderDetailsRepository;
	
	@Inject
	private MedicationsRecordingsRepository medicationsRecordingsRepository;
	
	@Inject
	private MedicationTakenRepository medicationTakenRepository;
	
	public Long createPatientMedicationWithPictureUpload(MultipartFile file,String picture,String pid,String medicationType,String medicationName,String medicationNote, List<MedicationRemindersVO> medicationReminder,				
			 boolean medicationReminderFlag, String medicationPrescriptionNo, String medicationPharmacyName,
			 String medicationPharmacyAddress,String medicationPharmacyPhoneNumber,	String medicationPharmacyLocationCoordinates,
			LocalDate medicationRefillReminderDate, boolean medicationRefillReminderFlag) throws IOException {
		
		PaientMedicationVO paientMedicationVO = new PaientMedicationVO();
		
		paientMedicationVO.setPid(pid);
		paientMedicationVO.setMedicationType(medicationType);
		paientMedicationVO.setMedicationName(medicationName);
		paientMedicationVO.setMedicationNote(medicationNote);
		paientMedicationVO.setMedicationReminder(medicationReminder);
		paientMedicationVO.setMedicationReminderFlag(medicationReminderFlag);
		paientMedicationVO.setMedicationPrescriptionNo(medicationPrescriptionNo);
		paientMedicationVO.setMedicationPharmacyName(medicationPharmacyName);
		paientMedicationVO.setMedicationPharmacyAddress(medicationPharmacyAddress);
		paientMedicationVO.setMedicationPharmacyLocationCoordinates(medicationPharmacyLocationCoordinates);
		paientMedicationVO.setMedicationPharmacyPhoneNumber(medicationPharmacyPhoneNumber);
		paientMedicationVO.setMedicationRefillReminderFlag(medicationRefillReminderFlag);
		paientMedicationVO.setMedicationRefillReminderDate(medicationRefillReminderDate);
		if(Objects.nonNull(file)) {
			paientMedicationVO.setPhoto(file.getBytes());
		}
		
		Long id = 0L;
		if (!isDuplicateMed(paientMedicationVO)) {
			try {
				id = createPatientMedication(file,paientMedicationVO);
			} catch (Exception e) {
				logger.debug("Exception in createPatientMedicationWithPictureUpload:" + e.getMessage());
			}
		}
		return id;
		
	}
	
	public boolean isDuplicateMed(String pid, MedicationVO medVO) {
		boolean isDuplicate = true;

		List<BigInteger> medIdList = medicationsRecordingsRepository.getMedicationIdList(pid, 
				medVO.getMedicationType(), 
				medVO.getMedicationName());
 		
		if (medIdList.size() == 0 || ((medIdList.size() == 1) && (medIdList.get(0).longValue() == medVO.getMedicationId()))) {
 			isDuplicate = false;
 		}
		return isDuplicate;
	}
	
	public boolean isDuplicateMed(PaientMedicationVO paientMedication) {
		boolean isDuplicate = false;

		Long medCnt = medicationsRecordingsRepository.getMedicationCount(paientMedication.getPid(), 
				paientMedication.getMedicationType(), 
				paientMedication.getMedicationName());
		if (Objects.nonNull(medCnt) && medCnt.intValue() > 0) {
			isDuplicate =  true;
		}
		return isDuplicate;
	}
	
	public Long createPatientMedication(MultipartFile file, PaientMedicationVO patientMedication) throws SQLException, IOException{

		logger.debug("Adding new contact with information: {}", patientMedication);
		Long id = 0L;		

		MedicationsRecordings medicationsRecordings = new MedicationsRecordings();
		PatientMedicationAssoc patientMedicalAssoc = new PatientMedicationAssoc();
		PharmacyDetails pharmacyDetails = new PharmacyDetails();

		PatientInfo patientUser = patientInfoRepository.findOneById(String.valueOf(patientMedication.getPid()));
		if(Objects.nonNull(patientUser)) {
			boolean pharmacy = false;
			if(Objects.nonNull(patientMedication.getMedicationPharmacyName())) {
				pharmacyDetails.setPharmacyName(patientMedication.getMedicationPharmacyName());
				pharmacy = true;
			}
			if(Objects.nonNull(patientMedication.getMedicationPharmacyAddress())) {
				pharmacyDetails.setPharmacyAddress(patientMedication.getMedicationPharmacyAddress());
				pharmacy = true;
			}
			if(Objects.nonNull(patientMedication.getMedicationPharmacyPhoneNumber())) {
				pharmacyDetails.setPhoneNumber(patientMedication.getMedicationPharmacyPhoneNumber());
				pharmacy = true;
			}
			if(Objects.nonNull(patientMedication.getMedicationPharmacyLocationCoordinates())) {
				String coordinates = patientMedication.getMedicationPharmacyLocationCoordinates();
				coordinates = coordinates.substring(1, coordinates.length()-1);
				String split[]= coordinates.split(",");
				pharmacyDetails.setLatitude(split[0]);
				pharmacyDetails.setLongitude(split[1]);
				pharmacy = true;
			}
			
			if(pharmacy) {
				pharmacyDetailsRepository.save(pharmacyDetails);
			}

			medicationsRecordings.setMedicationTypeId(patientMedication.getMedicationType());
			medicationsRecordings.setName(patientMedication.getMedicationName());
			medicationsRecordings.setNote(patientMedication.getMedicationNote());
			medicationsRecordings.setMedicationTimeReminderFlag(patientMedication.isMedicationReminderFlag());
			medicationsRecordings.setRefillReminderFlag(patientMedication.isMedicationRefillReminderFlag());
			medicationsRecordings.setRefillReminderDate(patientMedication.getMedicationRefillReminderDate());
			medicationsRecordings.setMedicationPrescriptionNo(patientMedication.getMedicationPrescriptionNo());
			if(Objects.nonNull(file)) {
				medicationsRecordings.setPhoto(file.getBytes());
			}
			if(Objects.nonNull(patientMedication.getMedicationPharmacyName())) {
				medicationsRecordings.setPharmacyDetailsId(pharmacyDetails.getId());
			}

			medicationsRecordingsRepository.save(medicationsRecordings);

			if(patientMedication.isMedicationReminderFlag()) {
				for(MedicationRemindersVO medicationReminder : patientMedication.getMedicationReminder()) {
					//	Long reminderDayId = hillromTypeCodeFormatRepository.findCodeValuesListByTypeCode(medicationReminder.getReminderDay()).get(0).getId();	
					String reminderDayId = medicationReminder.getReminderDay();// get type code & insert
					for(ReminderVO reminder : medicationReminder.getReminderList()){
						MedicationReminderDetails medicationReminderDetails = new MedicationReminderDetails();
						medicationReminderDetails.setReminderDay(reminderDayId);
						medicationReminderDetails.setReminderTime(reminder.getReminderTime());
						medicationReminderDetails.setMedicationRecordingsId(medicationsRecordings.getId());
						medicationReminderDetailsRepository.save(medicationReminderDetails);
					}
				}
			}

			patientMedicalAssoc.setPatient(patientUser.getId());
			patientMedicalAssoc.setArchive(false);	// isArchieve false
			patientMedicalAssoc.setActive(true);	// isActive true
			patientMedicalAssoc.setMedicationRecordingsId(medicationsRecordings.getId());
			patientMedicationAssocRepository.save(patientMedicalAssoc);
			id = patientMedicalAssoc.getId();
		}
		return id;
	}
		
	public JSONObject getAllPatientMedicationDetails(String patientId, String date) {

		JSONObject jsonObject = new JSONObject();
		List<MedicationVO> patientMedicationList = new ArrayList<MedicationVO>();
	
			List<PatientMedicationAssoc> medicationList = patientMedicationAssocRepository.findByPatientId(patientId);
			if(medicationList != null && !medicationList.isEmpty()) {
				for(PatientMedicationAssoc medication:medicationList) {
					if(medication.isActive())
					{
						MedicationsRecordings medicationRecordings = medicationsRecordingsRepository.
								findOneById(medication.getMedicationRecordingsId());
						PharmacyDetails pharmacyDetails = pharmacyDetailsRepository.
								findOneById(medicationRecordings.getPharmacyDetailsId());
	
						List<MedicationReminderDetails> medicationRemainderDetails = null;
						if(medicationRecordings.getMedicationTimeReminderFlag()) {
							medicationRemainderDetails = medicationReminderDetailsRepository.findByMedicationIdByDTO(medicationRecordings.getId());
						} 
						MedicationVO patientMedication = new MedicationVO();
	
						if(Objects.nonNull(medicationRecordings.getMedicationTypeId())) {
							patientMedication.setMedicationId(medication.getId());
							patientMedication.setMedicationType(medicationRecordings.getMedicationTypeId());
							patientMedication.setMedicationName(medicationRecordings.getName());
							patientMedication.setMedicationNote(medicationRecordings.getNote());
							patientMedication.setMedicationReminderFlag(medicationRecordings.getMedicationTimeReminderFlag());
							patientMedication.setMedicationPrescriptionNo(medicationRecordings.getMedicationPrescriptionNo());
							patientMedication.setMedicationRefillReminderFlag(medicationRecordings.getRefillReminderFlag());
							if(medicationRecordings.getRefillReminderFlag()) {
								patientMedication.setMedicationRefillReminderDate(medicationRecordings.getRefillReminderDate().toString());
							}
	
						}
						if(Objects.nonNull(medicationRemainderDetails)) {
							if (StringUtils.isBlank(date)) {
                                DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd");
                                date = LocalDate.now().toString(fmt);
							}
							patientMedication.setMedicationReminder(getMedicationRemainderDeatils(medicationRemainderDetails, date));
						}
						if(Objects.nonNull(pharmacyDetails)) {
							patientMedication.setMedicationPharmacyName(pharmacyDetails.getPharmacyName());
							patientMedication.setMedicationPharmacyAddress(pharmacyDetails.getPharmacyAddress());
							patientMedication.setMedicationPharmacyPhoneNumber(pharmacyDetails.getPhoneNumber());
 
							if (!((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).contains("null,null") 
									|| (pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).equals(" , "))) {
								patientMedication.setMedicationPharmacyLocationCoordinates((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()));
							}
						}
						patientMedication.setMedicationIsArchiveFlag(medication.isArchive());
						
						if (Objects.nonNull(medicationRecordings.getPhoto())) {
							patientMedication.setPhoto_available(true);
						} else {
							patientMedication.setPhoto_available(false);
						}
						patientMedicationList.add(patientMedication);
						jsonObject.put("pid",patientId);
						jsonObject.put("medicationList",patientMedicationList);
					}
				}
				return jsonObject;  
			}else {
				jsonObject.put("ERROR",ExceptionConstants.HR_922);
			}
			return jsonObject;
		}
	 
	public List<MedicationVO> getAllPatientMedicationDetailsLst(String patientId, Long medicationId) {
        
        List<MedicationVO> patientMedicationList = new ArrayList<MedicationVO>();
        
        List<PatientMedicationAssoc> medicationList = patientMedicationAssocRepository.findByPatientIdAndMedicationIdList(patientId,medicationId);
        if(Objects.nonNull(medicationList)) {
        for(PatientMedicationAssoc medication:medicationList) {
        	 MedicationsRecordings medicationRecordings = medicationsRecordingsRepository.
                     findOneById(medication.getMedicationRecordingsId());
        	 PharmacyDetails pharmacyDetails = pharmacyDetailsRepository.
          		   findOneById(medicationRecordings.getPharmacyDetailsId());
        	 
        	 List<MedicationReminderDetails> medicationRemainderDeatils = null;
        	 if(medicationRecordings.getMedicationTimeReminderFlag()) {
                 medicationRemainderDeatils = medicationReminderDetailsRepository.
                		 findByMedicationIdByDTO(medicationRecordings.getId());
             } 
        	 MedicationVO patientMedication = new MedicationVO();
        	 
        	 if(Objects.nonNull(medicationRecordings.getMedicationTypeId())) {
        		 patientMedication.setMedicationId(medication.getId());
        		 patientMedication.setMedicationRecordingId(medicationRecordings.getId());
        		 patientMedication.setMedicationType(medicationRecordings.getMedicationTypeId());
        		 patientMedication.setMedicationName(medicationRecordings.getName());
        		 patientMedication.setMedicationNote(medicationRecordings.getNote());
        		 patientMedication.setMedicationReminderFlag(medicationRecordings.getMedicationTimeReminderFlag());
        		 patientMedication.setMedicationPrescriptionNo(medicationRecordings.getMedicationPrescriptionNo());
        		 patientMedication.setMedicationRefillReminderFlag(medicationRecordings.getRefillReminderFlag());
        		 if(medicationRecordings.getRefillReminderFlag()) {
        			 patientMedication.setMedicationRefillReminderDate(medicationRecordings.getRefillReminderDate().toString());
        		 }
        		 	 patientMedication.setPhoto(medicationRecordings.getPhoto());      
        		
        	 }
        	 
            		 if(Objects.nonNull(medicationRemainderDeatils)) {     				
     					patientMedication.setMedicationReminder(getMedicationRemainderDeatils(medicationRemainderDeatils, null));
     				}
				
        	 if(Objects.nonNull(pharmacyDetails)) {
        		 patientMedication.setMedicationPharmacyName(pharmacyDetails.getPharmacyName());
        		 patientMedication.setMedicationPharmacyAddress(pharmacyDetails.getPharmacyAddress());
        		 patientMedication.setMedicationPharmacyPhoneNumber(pharmacyDetails.getPhoneNumber());
				if (!((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).contains("null,null") 
						|| (pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).equals(" , "))) {
        			 patientMedication.setMedicationPharmacyLocationCoordinates((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()));
        		 }
        	 }
        	 	patientMedication.setMedicationIsArchiveFlag(medication.isArchive());
        	 	patientMedicationList.add(patientMedication);
        	 
             }
        }
        return patientMedicationList;        
 }
	
	public  MedicationVO getPatientMedicationDetails(String patientId,String medicationId) {
		MedicationVO patientMedication = new MedicationVO();
		if(patientId != null && medicationId != null) {
			PatientMedicationAssoc medication = patientMedicationAssocRepository.
					findByPatientIdAndMedicationId(patientId, Long.parseLong(medicationId));
			if(Objects.nonNull(medication)) {
				if(medication.isActive())
				{
					MedicationsRecordings medicationRecordings = medicationsRecordingsRepository.
							findOneById(medication.getMedicationRecordingsId());
					
					PharmacyDetails pharmacyDetails = null;
					if(Objects.nonNull(medicationRecordings.getPharmacyDetailsId())) {
						pharmacyDetails = pharmacyDetailsRepository.
								findOneById(medicationRecordings.getPharmacyDetailsId());
					}
					
					List<MedicationReminderDetails> medicationRemainderDeatils = null;
					if(medicationRecordings.getMedicationTimeReminderFlag()) {
						medicationRemainderDeatils = medicationReminderDetailsRepository.
								findByMedicationIdByDTO(medicationRecordings.getId());			
					}
		
					patientMedication.setMedicationId(medication.getId());
	
					if(Objects.nonNull(medicationRecordings.getMedicationTypeId())) {
						patientMedication.setMedicationType(medicationRecordings.getMedicationTypeId());
						patientMedication.setMedicationName(medicationRecordings.getName());
						patientMedication.setMedicationNote(medicationRecordings.getNote());
						patientMedication.setMedicationReminderFlag(medicationRecordings.getMedicationTimeReminderFlag());        	
						patientMedication.setMedicationPrescriptionNo(medicationRecordings.getMedicationPrescriptionNo());
						patientMedication.setMedicationRefillReminderFlag(medicationRecordings.getRefillReminderFlag());
						if(medicationRecordings.getRefillReminderFlag()) {
							patientMedication.setMedicationRefillReminderDate(medicationRecordings.getRefillReminderDate().toString());
						}
		
						patientMedication.setPhoto(medicationRecordings.getPhoto());
						
					}
					if(Objects.nonNull(pharmacyDetails)) {
						patientMedication.setMedicationPharmacyName(pharmacyDetails.getPharmacyName());
						patientMedication.setMedicationPharmacyAddress(pharmacyDetails.getPharmacyAddress());
						patientMedication.setMedicationPharmacyPhoneNumber(pharmacyDetails.getPhoneNumber());
						if (!((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).contains("null,null") 
								|| (pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()).equals(" , "))) {
							patientMedication.setMedicationPharmacyLocationCoordinates((pharmacyDetails.getLatitude()+","+pharmacyDetails.getLongitude()));
						}
					}
					if(Objects.nonNull(medicationRemainderDeatils)) {
						patientMedication.setMedicationReminder(getMedicationRemainderDeatils(medicationRemainderDeatils,null));
					}
					patientMedication.setMedicationIsArchiveFlag(medication.isArchive());
					return patientMedication;
				}else {
					return null;
				}
				
			}else {
				return null;			
			}
		} else {
			return null;
        }
		
	}

	public JSONObject deletePatientMedicationDetails(String patientId,String medicationId, boolean isActiveFlag) {

		JSONObject jsonObject = new JSONObject();
		PatientMedicationAssoc medication = patientMedicationAssocRepository.
				findByPatientIdAndMedicationId(patientId, Long.parseLong(medicationId));	

		if(patientId != null  &&  medicationId != null && medication != null) {
			medication.setActive(isActiveFlag);

			patientMedicationAssocRepository.save(medication);

			if(isActiveFlag && Objects.nonNull(medication)) {
				jsonObject.put("status",Constants.SUCCESS_ACTIVE_STATUS );
			} else if(!isActiveFlag && Objects.nonNull(medication)) {
				jsonObject.put("status",Constants.SUCCESS_ACTIVE_STATUS );
			} else {	
				jsonObject.put("status", Constants.FAILURE_ACTIVE_STATUS);
			}
		}
		else 
		{	jsonObject.put("status", Constants.FAILURE_ACTIVE_STATUS);
		}
		return jsonObject;
	}
	
	public JSONObject archiveDetails(String patientId,Long medicationId,boolean archive) {

		//findByPatientIdAndMedicationId
		JSONObject jsonObject = new JSONObject();
		PatientMedicationAssoc pMedicalAss=patientMedicationAssocRepository.findByPatientIdAndMedicationId(patientId, medicationId);

		if(patientId != null  && medicationId != null && pMedicalAss != null) {
			pMedicalAss.setArchive(archive);
			patientMedicationAssocRepository.save(pMedicalAss);

			if(archive && Objects.nonNull(pMedicalAss)) {
				jsonObject.put("status",Constants.SUCCESS_ARCHIVE_STATUS );
			}else if(!archive && Objects.nonNull(pMedicalAss)) {
				jsonObject.put("status",Constants.SUCCESS_ARCHIVE_STATUS );
			}else 
			{	jsonObject.put("status", Constants.FAILURE_ARCHIVE_STATUS);
			}
		}else 
		{  	jsonObject.put("status", Constants.FAILURE_ARCHIVE_STATUS);
		}
		return jsonObject;
	}

	public List<MedicationVO> updatePatientMedicationDetails(String patientId,List<MedicationVO> paientMedicationVO, boolean isPictureUpdated) {

		List<MedicationVO> updatedPatientMedicationList = new ArrayList<MedicationVO>();
		List<MedicationVO> existingPatinetMedicationList = getAllPatientMedicationDetailsLst(patientId,paientMedicationVO.get(0).getMedicationId());
		List<MedicationVO> updatePatientMedicationList = paientMedicationVO;
		MedicationsRecordings existingMedicationRecording= new MedicationsRecordings();
		
		if(!existingPatinetMedicationList.isEmpty()) {
		for(int i=0;i<=existingPatinetMedicationList.size()-1;i++){
			
			for(MedicationVO updatePatientMedication:updatePatientMedicationList) {

				if(((existingPatinetMedicationList.get(i).getMedicationId()).equals(updatePatientMedication.getMedicationId()))) {


					existingMedicationRecording = medicationsRecordingsRepository.
							findOneById(existingPatinetMedicationList.get(i).getMedicationRecordingId());

					if(Objects.nonNull(existingMedicationRecording)) {
						existingMedicationRecording.setName(updatePatientMedication.getMedicationName());
						existingMedicationRecording.setMedicationTypeId(updatePatientMedication.getMedicationType());
						existingMedicationRecording.setNote(updatePatientMedication.getMedicationNote());
						existingMedicationRecording.setMedicationTimeReminderFlag(updatePatientMedication.isMedicationReminderFlag());
						existingMedicationRecording.setMedicationPrescriptionNo(updatePatientMedication.getMedicationPrescriptionNo());
						existingMedicationRecording.setRefillReminderFlag(updatePatientMedication.isMedicationRefillReminderFlag());
						if(updatePatientMedication.isMedicationRefillReminderFlag()) {
							existingMedicationRecording.setRefillReminderDate(new LocalDate(updatePatientMedication.getMedicationRefillReminderDate()));
						}else {
							existingMedicationRecording.setRefillReminderDate(null);
						}
						if(isPictureUpdated) {
							existingMedicationRecording.setPhoto(updatePatientMedication.getPhoto());
						}
						medicationsRecordingsRepository.save(existingMedicationRecording);
					}

					PharmacyDetails existingPharmacyDetails = pharmacyDetailsRepository.
							findOneById(existingMedicationRecording.getPharmacyDetailsId());

					if(Objects.nonNull(existingPharmacyDetails)) {
						boolean pharmacy = false;
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyName())) {
							existingPharmacyDetails.setPharmacyName(updatePatientMedication.getMedicationPharmacyName());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyAddress())) {
							existingPharmacyDetails.setPharmacyAddress(updatePatientMedication.getMedicationPharmacyAddress());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyPhoneNumber())) {
							existingPharmacyDetails.setPhoneNumber(updatePatientMedication.getMedicationPharmacyPhoneNumber());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyLocationCoordinates())) {
							String coordinates = updatePatientMedication.getMedicationPharmacyLocationCoordinates();
							coordinates = coordinates.substring(1, coordinates.length()-1);
							String split[]= coordinates.split(",");
							existingPharmacyDetails.setLatitude(split[0]);
							existingPharmacyDetails.setLongitude(split[1]);
							pharmacy = true;
						}
						
						if(pharmacy) {
							pharmacyDetailsRepository.save(existingPharmacyDetails);
						}else {
							pharmacyDetailsRepository.delete(existingPharmacyDetails);
							existingMedicationRecording.setPharmacyDetailsId(null);
						}							
					}  
					else
					{
						PharmacyDetails pharmacyDetails = new PharmacyDetails();
						boolean pharmacy = false;
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyName())) {
							pharmacyDetails.setPharmacyName(updatePatientMedication.getMedicationPharmacyName());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyAddress())) {
							pharmacyDetails.setPharmacyAddress(updatePatientMedication.getMedicationPharmacyAddress());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyPhoneNumber())) {
							pharmacyDetails.setPhoneNumber(updatePatientMedication.getMedicationPharmacyPhoneNumber());
							pharmacy = true;
						}
						if(Objects.nonNull(updatePatientMedication.getMedicationPharmacyLocationCoordinates())) {
							String coordinates = updatePatientMedication.getMedicationPharmacyLocationCoordinates();
							coordinates = coordinates.substring(1, coordinates.length()-1);
							String split[]= coordinates.split(",");
							pharmacyDetails.setLatitude(split[0]);
							pharmacyDetails.setLongitude(split[1]);
							pharmacy = true;
						}
						
						if(pharmacy) {
							pharmacyDetailsRepository.save(pharmacyDetails);
							existingMedicationRecording.setPharmacyDetailsId(pharmacyDetails.getId());
						}					
					}

					int count = medicationReminderDetailsRepository.getCountByMedicationId(existingPatinetMedicationList.get(i).getMedicationRecordingId());
					List<MedicationReminderDetails> medicationReminderList = medicationReminderDetailsRepository.findByMedicationIdByDTO(existingPatinetMedicationList.get(i).getMedicationRecordingId());
					int temp = 0;							

					if(updatePatientMedication.isMedicationReminderFlag()) {

						for(MedicationRemindersVO medicationReminder : updatePatientMedication.getMedicationReminder()) {
							for(ReminderVO reminder : medicationReminder.getReminderList()){
								if(temp < count)
								{
									MedicationReminderDetails existingRemainder = medicationReminderList.get(temp);
									
									existingRemainder.setReminderDay(medicationReminder.getReminderDay());
									existingRemainder.setReminderTime(reminder.getReminderTime());
									
									medicationReminderDetailsRepository.save(existingRemainder);
								}
								else
								{
									MedicationReminderDetails existingRemainder = new MedicationReminderDetails();
									
									existingRemainder.setMedicationRecordingsId(existingPatinetMedicationList.get(i).getMedicationRecordingId());
									existingRemainder.setReminderDay(medicationReminder.getReminderDay());
									existingRemainder.setReminderTime(reminder.getReminderTime());
									
									medicationReminderDetailsRepository.save(existingRemainder);
								}
								temp++;
							}							
						}
						
					}

					if(temp < count)
					{
						for(int delIdx = temp; delIdx < count; delIdx++)
						{
							medicationReminderDetailsRepository.delete(medicationReminderList.get(delIdx));
						}
					}
					updatedPatientMedicationList.add(updatePatientMedication);

				} else {
					continue;
				}
			}
		}
		return updatedPatientMedicationList;
		}
		return null;
	}

	public List<MedicationRemindersVO> getMedicationRemainderDeatils(List<MedicationReminderDetails> medicationRemainderDeatils, String date) {
		
		List<MedicationRemindersVO> medicationVoList = new ArrayList<MedicationRemindersVO>();
		
		Set<String> hashSet = new LinkedHashSet<>();
		
		for (MedicationReminderDetails mrdt : medicationRemainderDeatils) {
			hashSet.add(mrdt.getReminderDay());
		}
		
		for (String day : hashSet) {
			MedicationRemindersVO medicationRemindersVO = new MedicationRemindersVO();
			medicationRemindersVO.setReminderDay(day);
			List<ReminderVO> reminderVOList = new ArrayList<ReminderVO>();

			for( MedicationReminderDetails mrdt : medicationRemainderDeatils) {
				if (day.equalsIgnoreCase(mrdt.getReminderDay())) {
					ReminderVO reminderVO = new ReminderVO();
					reminderVO.setReminderId(mrdt.getId());
					reminderVO.setReminderTime(mrdt.getReminderTime());
					reminderVOList.add(reminderVO);
					if(Objects.nonNull(date)) {
						int dayOfWeek = LocalDate.parse(date).getDayOfWeek();
				        String dayName = DateUtil.dayOfTheWeeks(dayOfWeek); // day name coming one day less
				        
				        if (dayName.equalsIgnoreCase(mrdt.getReminderDay())) {
							Long start = LocalDate.parse(date).toDateTimeAtStartOfDay(DateTimeZone.UTC).getMillis();
							Long end = LocalDate.parse(date).plusDays(1).toDateTimeAtStartOfDay(DateTimeZone.UTC).getMillis();
							//MedicationTaken medicationTaken = medicationTakenRepository.findByReminderIdWithinRange(mrdt.getId(), start, end);
							LinkedList<MedicationTaken> medicationTakenList = medicationTakenRepository.
									findByReminderIdWithinRange(mrdt.getId(), start, end);
							if (medicationTakenList.size() > 0) {	// save updated time stamp & status
								reminderVO.setTaken(medicationTakenList.peekLast().getMedicationTakenStatus());
							} else {
								reminderVO.setTaken(false);
							}
				        } else {
				        	reminderVO.setTaken(false);
				        }
					}
				}
				
			}
			medicationRemindersVO.setReminderList(reminderVOList);
			medicationVoList.add(medicationRemindersVO);
		}

		
			
		/*for( MedicationReminderDetails mrdt : medicationRemainderDeatils) {
			if(medicationVoList.size() > 0) {
				for(MedicationRemindersVO mvot : medicationVoList ) {
					if(mvot.getReminderDay().equals(mrdt.getReminderDay())) {
						if(mvot.getReminderList().size() > 0) {
							ReminderVO reminderVO = new ReminderVO();
							reminderVO.setReminderId(mrdt.getId());
							reminderVO.setReminderTime(mrdt.getReminderTime());
							mvot.getReminderList().add(reminderVO);
						} else {
							List<ReminderVO> reminderVOList = new ArrayList<ReminderVO>();
							ReminderVO reminderVO = new ReminderVO();
							reminderVO.setReminderId(mrdt.getId());
							reminderVO.setReminderTime(mrdt.getReminderTime());
							reminderVOList.add(reminderVO);
							mvot.setReminderList(reminderVOList);
						}
					} else {
						MedicationRemindersVO medicationRemindersVO = new MedicationRemindersVO();
						medicationRemindersVO.setReminderDay(mrdt.getReminderDay());
						List<ReminderVO> reminderVOList = new ArrayList<ReminderVO>();
						ReminderVO reminderVO = new ReminderVO();
						reminderVO.setReminderId(mrdt.getId());
						reminderVO.setReminderTime(mrdt.getReminderTime());
						reminderVOList.add(reminderVO);
						medicationRemindersVO.setReminderList(reminderVOList);
						medicationVoList.add(medicationRemindersVO);
					}
				} 
			} else {
				MedicationRemindersVO medicationRemindersVO = new MedicationRemindersVO();
				medicationRemindersVO.setReminderDay(mrdt.getReminderDay());
				List<ReminderVO> reminderVOList = new ArrayList<ReminderVO>();
				ReminderVO reminderVO = new ReminderVO();
				reminderVO.setReminderId(mrdt.getId());
				reminderVO.setReminderTime(mrdt.getReminderTime());
				reminderVOList.add(reminderVO);
				medicationRemindersVO.setReminderList(reminderVOList);
				medicationVoList.add(medicationRemindersVO);
			}
		}*/
		return medicationVoList;
	}
	
	public List<PatientMedicationForTheDayVO> getAllPatientMedicationForTheDay(String patientId, LocalDate date ) {
		
		List<PatientMedicationForTheDayVO> patientMedicationList = new ArrayList<PatientMedicationForTheDayVO>();		

        int day = date.getDayOfWeek();
        String dayName = DateUtil.dayOfTheWeeks(day);
        
		List<PatientMedicationAssoc> medicationList = patientMedicationAssocRepository.findByPatientIdAndIsActive(patientId);
		if(!medicationList.isEmpty()) {
			for(PatientMedicationAssoc medication:medicationList) {
				MedicationsRecordings medicationRecordings = medicationsRecordingsRepository.
						findActiveMedicationsByPatientId(medication.getMedicationRecordingsId());


				List<MedicationReminderDetails> medicationRemainderDetails = null;
				if(Objects.nonNull(medicationRecordings)){
					if(Objects.nonNull(medicationRecordings.getMedicationTimeReminderFlag())){
						if(medicationRecordings.getMedicationTimeReminderFlag()) {
							medicationRemainderDetails = medicationReminderDetailsRepository.
									findByMedicationIdAndDayName(medicationRecordings.getId(),dayName);
						} 

						PatientMedicationForTheDayVO patientMedication = new PatientMedicationForTheDayVO();
						if(Objects.nonNull(medicationRecordings.getMedicationTypeId())) {
							patientMedication.setMedicationId(medicationRecordings.getId());
							patientMedication.setMedicationType(medicationRecordings.getMedicationTypeId());
							patientMedication.setMedicationName(medicationRecordings.getName());
							patientMedication.setMedicationNote(medicationRecordings.getNote());
							patientMedication.setMedicationTakenStatus(false);
						}

						if(Objects.nonNull(medicationRemainderDetails)) { 
							String medDay = DateUtil.dayOfTheWeeks(day);
							List<ReminderVO> reminderList = new ArrayList<ReminderVO>();
							for(MedicationReminderDetails mrdetails : medicationRemainderDetails){								
								if(medDay.equalsIgnoreCase(mrdetails.getReminderDay())){
									ReminderVO reminderVO = new ReminderVO();
									reminderVO.setReminderId(mrdetails.getId());
									reminderVO.setReminderTime(mrdetails.getReminderTime());      
									reminderList.add(reminderVO);
								}
								patientMedication.setMedicationReminder(reminderList);
							}
						}
						patientMedicationList.add(patientMedication);
					}
					
				}

			}
			return patientMedicationList; 
		}
		return null;        
}

	public JSONObject updateMedicationTakenListForPatient(MedicationTakenListDTO medTakenList) {
	JSONObject jsonObject = new JSONObject();
	
	List<String> responseList = new LinkedList<String>();
	for (MedicationTakenDTO medTaken : medTakenList.getMedicationTakenList()) {	// TODO
		
		PatientMedicationAssoc pma = patientMedicationAssocRepository.findOneById(medTaken.getMedicationId());
				
		if (Objects.nonNull(pma)) {
			MedicationReminderDetails medicationReminder = medicationReminderDetailsRepository.
					findByMedicationIdAndReminderId(pma.getMedicationRecordingsId(),medTaken.getReminderId());
	
			boolean isMedTakenUpdated = false;
			//boolean isTimeStampNotInValidDataRange = false;
			if(Objects.isNull(medicationReminder)){
				List<MedicationTakenTimeStampDTO> medicationTakenTimeStampList = medTaken.getReminderUpdateTakenList();
				for (MedicationTakenTimeStampDTO medicationTakenTimeStamp : medicationTakenTimeStampList) {
					if(Objects.nonNull(medicationTakenTimeStamp.getTakenTimestamp())
							//&& DateUtil.isDateTimeWithin90Days(medicationTakenTimeStamp.getTakenTimestamp())) {
							&& Objects.nonNull(medicationTakenTimeStamp.getIsTaken())) {
						Long start = LocalDate.fromDateFields(new Date(medicationTakenTimeStamp.getTakenTimestamp())).toDateTimeAtStartOfDay(DateTimeZone.UTC).getMillis();
						Long end = LocalDate.fromDateFields(new Date(medicationTakenTimeStamp.getTakenTimestamp())).plusDays(1).toDateTimeAtStartOfDay(DateTimeZone.UTC).getMillis();
						//logger.debug("start : " + start + "en : " + end);
						LinkedList<MedicationTaken> medicationTakenList = medicationTakenRepository.
								findByReminderIdWithinRange(medTaken.getReminderId(), start, end);
						if (Objects.nonNull(medicationTakenList) && medicationTakenList.size() > 0) {	// save updated time stamp & status
							medicationTakenList.peekLast().setMedicationTakenStatus(medicationTakenTimeStamp.getIsTaken());
							medicationTakenList.peekLast().setMed_taken_date_time(medicationTakenTimeStamp.getTakenTimestamp());
						} else {
							MedicationTaken medicationTakenForPatient= new MedicationTaken();
							medicationTakenForPatient.setMedicationTakenStatus(medicationTakenTimeStamp.getIsTaken());
							medicationTakenForPatient.setMedicationReminderDetailsId(medTaken.getReminderId());
							medicationTakenForPatient.setMed_taken_date_time(medicationTakenTimeStamp.getTakenTimestamp());
							medicationTakenRepository.save(medicationTakenForPatient);
						}
						isMedTakenUpdated = true;
					} /*else {
						isTimeStampNotInValidDataRange = true;
					}*/
				}
			}
			if (isMedTakenUpdated) {
				//responseList.add(isTimeStampNotInValidDataRange == false ? Constants.MED_TAKEN_SUCCESS : (Constants.MED_TAKEN_SUCCESS + ";" + ExceptionConstants.HR_954));
				responseList.add(Constants.MED_TAKEN_SUCCESS);
			} else {
				//responseList.add(isTimeStampNotInValidDataRange == false ? Constants.MED_FAILURE : (Constants.MED_FAILURE + ";" + ExceptionConstants.HR_954));
				responseList.add(Constants.MED_FAILURE);
			}
		} else {
			responseList.add(Constants.MED_FAILURE);
		}
	}
	jsonObject.put("RESPONSE", responseList);
	return jsonObject;
}

	public JSONObject updateMedicationTakenForPatient(String patientId, Long medicationId,Long reminderId, boolean medicationTakenStatus ) {
		
		JSONObject jsonObject = new JSONObject();
		MedicationTaken medicationTaken= new MedicationTaken();
			
		
		PatientMedicationAssoc medication = patientMedicationAssocRepository.
				findByPatientIdAndMedicationId(patientId,medicationId);
		
		if(Objects.nonNull(medication)){
			List<MedicationReminderDetails> medicationRemainderDeatils = medicationReminderDetailsRepository.
					findByMedicationIdByDTO(medication.getMedicationRecordingsId());

			//		PatientMedicationAssoc pMedicalAss=patientMedicationAssocRepository.findByPatientIdAndMedicationId(patientId, medicationId);

			medicationTaken = medicationTakenRepository.findByMedicationId(reminderId);

			MedicationTaken medicationTakenForPatient=null;
			boolean flag=false;

			if(Objects.nonNull(medicationRemainderDeatils)){
				for(MedicationReminderDetails mrd : medicationRemainderDeatils){
					if(mrd.getId().equals(reminderId)){
						if(Objects.isNull(medicationTaken)){
							medicationTakenForPatient= new MedicationTaken();
							medicationTakenForPatient.setMedicationTakenStatus(medicationTakenStatus);
							medicationTakenForPatient.setMedicationReminderDetailsId(reminderId);
							//medicationTakenForPatient.setReminderDate(DateUtil.dateFormat(medication.getCreatedTime()).toString());
							flag=true;
						}else{					
							medicationTaken.setMedicationTakenStatus(medicationTakenStatus);					
						}		

						if(flag){
							medicationTakenRepository.save(medicationTakenForPatient);				 
						}else{
							medicationTakenRepository.save(medicationTaken);
						}
						if(medicationTakenStatus){
							jsonObject.put("MESSAGE",Constants.MED_TAKEN_SUCCESS);
						}else{
							jsonObject.put("MESSAGE",Constants.MED_NOT_TAKEN_SUCCESS);
						}					 
					}
				}
			}else{
				jsonObject.put("ERROR",Constants.MED_FAILURE);
			}
		}else{
			jsonObject.put("ERROR",Constants.MED_FAILURE);
		}
		return jsonObject;

	}

}


