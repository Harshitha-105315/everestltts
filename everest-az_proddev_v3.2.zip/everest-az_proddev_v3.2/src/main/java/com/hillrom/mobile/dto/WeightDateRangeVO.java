package com.hillrom.mobile.dto;

public class WeightDateRangeVO {

	
}
