package com.hillrom.mobile.domain;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Audited
@Table(name="MEDICATIONS_RECORDINGS")
public class MedicationsRecordings{
	
	@JsonIgnore
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="medication_type_id")
	private String medicationTypeId;
	
	@Column(name="note")
	private String note;
	
	@Column(name="medication_time_reminder_flag")
	private Boolean medicationTimeReminderFlag;
	
	@Column(name="medication_prescription_no")
	private String medicationPrescriptionNo;
	
	@JsonIgnore
	//@OneToOne(optional=false,targetEntity=PharmacyDetails.class)
	@Column(name="Pharmacy_details_Id")
	private Long pharmacyDetailsId;
	
	@Column(name="refill_reminder_flag")
	private Boolean refillReminderFlag;
		
	@Column(name="refill_reminder_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate refillReminderDate;
	
	@Lob
	private byte[] photo;
	
	public MedicationsRecordings() {
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMedicationTypeId() {
		return medicationTypeId;
	}


	public void setMedicationTypeId(String medicationTypeId) {
		this.medicationTypeId = medicationTypeId;
	}


	public String getNote() {
		return note;
	}


	public void setNote(String note) {
		this.note = note;
	}


	public Boolean getMedicationTimeReminderFlag() {
		return medicationTimeReminderFlag;
	}


	public void setMedicationTimeReminderFlag(Boolean medicationTimeReminderFlag) {
		this.medicationTimeReminderFlag = medicationTimeReminderFlag;
	}


	public String getMedicationPrescriptionNo() {
		return medicationPrescriptionNo;
	}


	public void setMedicationPrescriptionNo(String medicationPrescriptionNo) {
		this.medicationPrescriptionNo = medicationPrescriptionNo;
	}


	public Long getPharmacyDetailsId() {
		return pharmacyDetailsId;
	}


	public void setPharmacyDetailsId(Long pharmacyDetailsId) {
		this.pharmacyDetailsId = pharmacyDetailsId;
	}


	public Boolean getRefillReminderFlag() {
		return refillReminderFlag;
	}


	public void setRefillReminderFlag(Boolean refillReminderFlag) {
		this.refillReminderFlag = refillReminderFlag;
	}


	public LocalDate getRefillReminderDate() {
		return refillReminderDate;
	}


	public void setRefillReminderDate(LocalDate dateTime) {
		this.refillReminderDate = dateTime;
	}
	
	
	@Override
	public String toString() {
		return "MedicationsRecordings [id=" + id + ", name=" + name
				+ ", medicationTypeId=" + medicationTypeId + ", note=" + note
				+ ", medicationTimeReminderFlag=" + medicationTimeReminderFlag
				+ ", medicationPrescriptionNo=" + medicationPrescriptionNo
				+ ", pharmacyDetailsId=" + pharmacyDetailsId
				+ ", refillReminderFlag=" + refillReminderFlag
				+ ", refillReminderDate=" + refillReminderDate + ", photo="
				+ Arrays.toString(photo) + "]";
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public MedicationsRecordings(String name, String medicationTypeId, String note, Boolean medicationTimeReminderFlag,
			String medicationPrescriptionNo, Long pharmacyDetailsId, Boolean refillReminderFlag,
			LocalDate refillReminderDate, byte[] photo) {
		super();
		this.name = name;
		this.medicationTypeId = medicationTypeId;
		this.note = note;
		this.medicationTimeReminderFlag = medicationTimeReminderFlag;
		this.medicationPrescriptionNo = medicationPrescriptionNo;
		this.pharmacyDetailsId = pharmacyDetailsId;
		this.refillReminderFlag = refillReminderFlag;
		this.refillReminderDate = refillReminderDate;
		this.photo = photo;
	}


	public MedicationsRecordings(Long id, String name, String medicationTypeId, String note,
			Boolean medicationTimeReminderFlag, String medicationPrescriptionNo, Long pharmacyDetailsId,
			Boolean refillReminderFlag, LocalDate refillReminderDate, byte[] photo) {
		super();
		this.id = id;
		this.name = name;
		this.medicationTypeId = medicationTypeId;
		this.note = note;
		this.medicationTimeReminderFlag = medicationTimeReminderFlag;
		this.medicationPrescriptionNo = medicationPrescriptionNo;
		this.pharmacyDetailsId = pharmacyDetailsId;
		this.refillReminderFlag = refillReminderFlag;
		this.refillReminderDate = refillReminderDate;
		this.photo = photo;		
	}

}
