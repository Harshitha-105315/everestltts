package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "MEDICATION_TAKEN")
public class MedicationTaken{

	@Id
	@JsonIgnore
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	/*@JsonIgnore
	@ManyToOne(optional=false,targetEntity=MedicationReminderDetails.class,fetch=FetchType.LAZY)
	@JoinColumn(name="medication_reminder_details_id",referencedColumnName="id")*/
	@Column(name="medication_reminder_details_id")
	private Long medicationReminderDetailsId;
	
	@Column(name="med_taken_date_time")
	private Long med_taken_date_time;
	
	@Column(name="medication_taken_status")
	private boolean medicationTakenStatus;

	public MedicationTaken(Long medicationReminderDetailsId,
			Long medication_taken_status, boolean medicationTakenStatus) {
		super();
		this.medicationReminderDetailsId = medicationReminderDetailsId;
		this.med_taken_date_time = medication_taken_status;
		this.medicationTakenStatus = medicationTakenStatus;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMedicationReminderDetailsId() {
		return medicationReminderDetailsId;
	}

	public void setMedicationReminderDetailsId(Long medicationReminderDetailsId) {
		this.medicationReminderDetailsId = medicationReminderDetailsId;
	}

	public Long getMed_taken_date_time() {
		return med_taken_date_time;
	}

	public void setMed_taken_date_time(Long med_taken_date_time) {
		this.med_taken_date_time = med_taken_date_time;
	}

	public boolean getMedicationTakenStatus() {
		return medicationTakenStatus;
	}

	public void setMedicationTakenStatus(boolean medicationTakenStatus) {
		this.medicationTakenStatus = medicationTakenStatus;
	}

	public MedicationTaken() {
		super();
	}

	@Override
	public String toString() {
		return "MedicationTaken [id=" + id + ", medicationReminderDetailsId="
				+ medicationReminderDetailsId + ", reminderDate="
				+ med_taken_date_time + ", medicationTakenStatus="
				+ medicationTakenStatus + "]";
	}
}
