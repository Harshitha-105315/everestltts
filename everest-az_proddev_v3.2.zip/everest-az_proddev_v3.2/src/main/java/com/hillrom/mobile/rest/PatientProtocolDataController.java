package com.hillrom.mobile.rest;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.mobile.dto.PatientProtocolDataDTO;
import com.hillrom.mobile.service.PatientProtocolDataService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api")
public class PatientProtocolDataController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PatientProtocolDataController.class);

	@Autowired
	private PatientProtocolDataService patientProtocolDataService;

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	public void setDefaultFRequencyAndPressureForNull(PatientProtocolDataDTO protocolDTO) {
		try {
			if (Objects.isNull(protocolDTO.getMinFrequency())) {
				protocolDTO.setMinFrequency(Constants.MIN_FREQUENCY);
			}
			if (Objects.isNull(protocolDTO.getMaxFrequency())) {
				protocolDTO.setMaxFrequency(Constants.MAX_FREQUENCY);
			}
			if (Objects.isNull(protocolDTO.getMinPressure())) {
				protocolDTO.setMinPressure(Constants.MIN_PRESSURE);
			}
			if (Objects.isNull(protocolDTO.getMaxPressure())) {
				protocolDTO.setMaxPressure(Constants.MAX_PRESSURE);
			}
		} catch (Exception ex) {
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter(writer);
			ex.printStackTrace(printWriter);
		}
	}
	/**
	 * POST /patient/:id/protocol -> add protocol with patient {id} for Unconnected
	 * Vest.
	 * 
	 * @return
	 * @throws HillromException
	 * @throws JSONException
	 * 
	 */
	@RequestMapping(value = "/patient/v1.0/setupDevice/add",

			method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> addProtocol(@RequestBody PatientProtocolDataDTO dto) throws HillromException {
		JSONObject jsonObject = new JSONObject();
		try {
			if (dto.getDuration() != null & dto.getNoOfTimesaDay() != null & dto.getPid() != null & dto.getDeviceName() != null) {

				setDefaultFRequencyAndPressureForNull(dto);
				List<PatientProtocolData> ppdList = patientProtocolDataService.createProtocol(dto);
				if (ppdList.isEmpty()) {
					jsonObject.put("message", ExceptionConstants.HR_902);
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
				} else {
					jsonObject.put("did", ppdList.get(0).getPatient().getSerialNumber());
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.CREATED);
				}

			}
			else {

				jsonObject.put("Message", "Missing Parameters");
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}

		} catch (HillromException hre) {
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * UPDATE /patient/:id/protocol -> edit protocol for patient for Unconnected
	 * Vest.
	 * 
	 * @return
	 * @throws HillromException
	 * @throws JSONException
	 * 
	 */
	@RequestMapping(value = "/patient/v1.0/setupDevice/update",

			method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> updateProtocol(@RequestBody PatientProtocolDataDTO dto) throws HillromException {
		JSONObject jsonObject = new JSONObject();
		try {
			if (dto.getDid() != null & dto.getDuration() != null & 
					dto.getNoOfTimesaDay() != null & dto.getPid() != null & 
					dto.getDeviceName() != null) {
				setDefaultFRequencyAndPressureForNull(dto);
				List<PatientProtocolData> ppdList = patientProtocolDataService.updateProtocol(dto);
				Optional<PatientDevicesAssoc> activeDevice = patientDevicesAssocRepository
						.findOneBySerialNumberAndDeviceType(dto.getDid(), "VEST");
				if (ppdList.isEmpty()) {
					jsonObject.put("message", ExceptionConstants.HR_906);
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
				} else {
					jsonObject.put("did", ppdList.get(0).getPatient().getSerialNumber()); // Serial Number
					jsonObject.put("pid", ppdList.get(0).getPatient().getId()); // PatientID
					jsonObject.put("noOfTimesaDay", ppdList.get(0).getTreatmentsPerDay()); // Treatments per day
					jsonObject.put("minFrequency", ppdList.get(0).getMinFrequency()); // Min. frequency
					jsonObject.put("maxFrequency", ppdList.get(0).getMaxFrequency()); // Max. frequency
					jsonObject.put("minPressure", ppdList.get(0).getMinPressure()); // Min. Pressure
					jsonObject.put("maxPressure", ppdList.get(0).getMaxPressure()); // Max. Pressure
					jsonObject.put("duration", ppdList.get(0).getMinMinutesPerTreatment()); // Duration (Min. Minutes
																							// per Treatment)
					if (activeDevice.isPresent()) {
						jsonObject.put("deviceName", activeDevice.get().getName()); // Device Name
					}
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
				}
			} else {

				jsonObject.put("Message", "Missing Parameters");
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}

		} catch (HillromException hre) {
			jsonObject.put("ERROR", hre.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * DELETE /patient/v1.0/setupDevice/remove -> delete manually setup device.
	 * 
	 * @throws JSONException
	 * 
	 */
	@RequestMapping(value = "/patient/v1.0/setupDevice/remove", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> deleteProtocolForPatient(@RequestBody Map<String, String> did)
			throws JSONException {
		LOGGER.debug("REST request to delete protocol for patient user : {}", did);
		JSONObject jsonObject = new JSONObject();

		try {
			String serialNumber = did.get("did");

			jsonObject = patientProtocolDataService.deactivateUnconnectedVestFromPatient(serialNumber);

			if (jsonObject.containsKey("ERROR")) {
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);
			} else {
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.OK);
			}
		} catch (HillromException e) {
			jsonObject.put("ERROR", e.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);
		}

	}
}
