package com.hillrom.mobile.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"RetrieveDateRangeWeightHistoryVO",
"RetrieveDateRangeWeightAwardsHistoryVO",
"anyActiveGoal",
"currentGoal"
})
public class RetrieveDateRangeActivityVO {

	@JsonProperty("weightHistory")
	private List<PatientActivityHistoryVO> weightHistory = null;
	@JsonProperty("awardsHistory")
	private List<AwardsHistoryVO> awardsHistory = null;
	@JsonProperty("anyActiveGoal")
	private Boolean anyActiveGoal;
	@JsonProperty("currentGoal")
	private CurrentGoalVO currentGoal;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("weightHistory")
	public List<PatientActivityHistoryVO> getWeightHistory() {
	return weightHistory;
	}

	@JsonProperty("weightHistory")
	public void setWeightHistory(List<PatientActivityHistoryVO> weightHistory) {
	this.weightHistory = weightHistory;
	}

	@JsonProperty("awardsHistory")
	public List<AwardsHistoryVO> getAwardsHistory() {
	return awardsHistory;
	}

	@JsonProperty("awardsHistory")
	public void setAwardsHistory(List<AwardsHistoryVO> awardsHistory) {
	this.awardsHistory = awardsHistory;
	}

	@JsonProperty("anyActiveGoal")
	public Boolean getAnyActiveGoal() {
	return anyActiveGoal;
	}

	@JsonProperty("anyActiveGoal")
	public void setAnyActiveGoal(Boolean anyActiveGoal) {
	this.anyActiveGoal = anyActiveGoal;
	}

	@JsonProperty("currentGoal")
	public CurrentGoalVO getCurrentGoal() {
	return currentGoal;
	}

	@JsonProperty("currentGoal")
	public void setCurrentGoal(CurrentGoalVO currentGoal) {
	this.currentGoal = currentGoal;
	}

}
