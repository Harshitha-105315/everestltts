package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hillrom.mobile.domain.BadgesMaster;

@Repository
public interface BadgesMasterRepository extends JpaRepository<BadgesMaster, Long> {

	@Query("from BadgesMaster bm where bm.activityTypeId = ?1")
	List<BadgesMaster> findOneByActivityTypeId(Long activityTypeId);

	@Query("from BadgesMaster")
	List<BadgesMaster> getAll();
	
	@Query("from BadgesMaster bm where bm.category = ?1 and bm.type = ?2 and bm.badgeThersholdValue = '1'")
	BadgesMaster findOneByCategoryTypeForFirstLog(String category,String type);
}
