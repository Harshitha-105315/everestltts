package com.hillrom.mobile.dto;

public class BYODOptOutInfo {
	private Long requestedDate;
	private String deviceIdentifier;
	private Long agreedDate;
	private String reason;
	private String feedback;
	/**
	 * @return the requestedDate
	 */
	public Long getRequestedDate() {
		return requestedDate;
	}
	/**
	 * @param requestedDate the requestedDate to set
	 */
	public void setRequestedDate(Long requestedDate) {
		this.requestedDate = requestedDate;
	}
	/**
	 * @return the deviceIdentifier
	 */
	public String getDeviceIdentifier() {
		return deviceIdentifier;
	}
	/**
	 * @param deviceIdentifier the deviceIdentifier to set
	 */
	public void setDeviceIdentifier(String deviceIdentifier) {
		this.deviceIdentifier = deviceIdentifier;
	}
	/**
	 * @return the agreedDate
	 */
	public Long getAgreedDate() {
		return agreedDate;
	}
	/**
	 * @param agreedDate the agreedDate to set
	 */
	public void setAgreedDate(Long agreedDate) {
		this.agreedDate = agreedDate;
	}
	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}
	/**
	 * @param reason the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 * @return the feedback
	 */
	public String getFeedback() {
		return feedback;
	}
	/**
	 * @param feedback the feedback to set
	 */
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agreedDate == null) ? 0 : agreedDate.hashCode());
		result = prime * result + ((deviceIdentifier == null) ? 0 : deviceIdentifier.hashCode());
		result = prime * result + ((feedback == null) ? 0 : feedback.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + ((requestedDate == null) ? 0 : requestedDate.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BYODOptOutInfo other = (BYODOptOutInfo) obj;
		if (agreedDate == null) {
			if (other.agreedDate != null)
				return false;
		} else if (!agreedDate.equals(other.agreedDate))
			return false;
		if (deviceIdentifier == null) {
			if (other.deviceIdentifier != null)
				return false;
		} else if (!deviceIdentifier.equals(other.deviceIdentifier))
			return false;
		if (feedback == null) {
			if (other.feedback != null)
				return false;
		} else if (!feedback.equals(other.feedback))
			return false;
		if (reason == null) {
			if (other.reason != null)
				return false;
		} else if (!reason.equals(other.reason))
			return false;
		if (requestedDate == null) {
			if (other.requestedDate != null)
				return false;
		} else if (!requestedDate.equals(other.requestedDate))
			return false;
		return true;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BYODOptOutInfo [requestedDate=" + requestedDate + ", deviceIdentifier=" + deviceIdentifier
				+ ", agreedDate=" + agreedDate + ", reason=" + reason + ", feedback=" + feedback + "]";
	}
	public BYODOptOutInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
