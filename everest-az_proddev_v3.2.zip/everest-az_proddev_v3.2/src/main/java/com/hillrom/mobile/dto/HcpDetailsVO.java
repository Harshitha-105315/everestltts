package com.hillrom.mobile.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class HcpDetailsVO {
	@JsonIgnore
	private String hcpClinicId;
	@ApiModelProperty(notes="hcpName (String)", dataType="java.lang.String", required=true)
	private String hcpName;
	@ApiModelProperty(notes="hcpCredentials (String)", dataType="java.lang.String", required=true)
	private String hcpCredentials;
	@ApiModelProperty(notes="hcpPhoneNumber (String)", dataType="java.lang.String", required=true)
	private String hcpPhoneNumber;
	
	public String getHcpClinicId() {
		return hcpClinicId;
	}
	public void setHcpClinicId(String hcpClinicId) {
		this.hcpClinicId = hcpClinicId;
	}
	public String getHcpName() {
		return hcpName;
	}
	public void setHcpName(String hcpName) {
		this.hcpName = hcpName;
	}
	public String getHcpCredentials() {
		return hcpCredentials;
	}
	public void setHcpCredentials(String hcpCredentials) {
		this.hcpCredentials = hcpCredentials;
	}
	public String getHcpPhoneNumber() {
		return hcpPhoneNumber;
	}
	public void setHcpPhoneNumber(String hcpPhoneNumber) {
		this.hcpPhoneNumber = hcpPhoneNumber;
	}
	@Override
	public String toString() {
		return "HcpDetailsVO [hcpClinicId=" + hcpClinicId + ", hcpName=" + hcpName + ", hcpCredentials="
				+ ""+ hcpCredentials + ", hcpPhoneNumber=" + hcpPhoneNumber + "]";
	}
	public HcpDetailsVO(String hcpClinicId, String hcpName, String hcpCredentials, String hcpPhoneNumber) {
		super();
		this.hcpClinicId = hcpClinicId;
		this.hcpName = hcpName;
		this.hcpCredentials = hcpCredentials;
		this.hcpPhoneNumber = hcpPhoneNumber;
	}
	public HcpDetailsVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
