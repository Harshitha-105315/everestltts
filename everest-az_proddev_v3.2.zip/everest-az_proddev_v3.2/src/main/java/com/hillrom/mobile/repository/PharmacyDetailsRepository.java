package com.hillrom.mobile.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.mobile.domain.PharmacyDetails;

public interface PharmacyDetailsRepository extends
		JpaRepository<PharmacyDetails, String> {

	@Query("from PharmacyDetails ppd where ppd.pharmacyName = ?1 ")
	List<PharmacyDetails> findByPatientId(String pharmacyName);
	
	PharmacyDetails findOneById(Long id);
}
