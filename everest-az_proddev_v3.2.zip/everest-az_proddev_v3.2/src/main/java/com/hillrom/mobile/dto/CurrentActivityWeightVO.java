package com.hillrom.mobile.dto;

import io.swagger.annotations.ApiModelProperty;

public class CurrentActivityWeightVO {

	@ApiModelProperty(notes="Target weight (Long stored as string)", required=true, example="150")
	private String targetWeight;
	@ApiModelProperty(notes="Current weight (Long stored as string)", required=true, example="100")
	private String currentWeight;
	@ApiModelProperty(notes="Goal start date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalStartDate;
	@ApiModelProperty(notes="Goal end date - Unix timestamp in milliseconds (Long)", required=true, example="1535384304000")
	private Long goalEndDate;
	@ApiModelProperty(notes="Goal name", required=true, example="Gain")
	private String name;
	@ApiModelProperty(notes="Activity Id (Long)", required=true, example="3")
	private Long activityId;
	
	
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getTargetWeight() {
		return targetWeight;
	}
	public void setTargetWeight(String targetWeight) {
		this.targetWeight = targetWeight;
	}
	public String getCurrentWeight() {
		return currentWeight;
	}
	public void setCurrentWeight(String currentWeight) {
		this.currentWeight = currentWeight;
	}
	public Long getGoalEndDate() {
		return goalEndDate;
	}
	public void setGoalEndDate(Long goalEndDate) {
		this.goalEndDate = goalEndDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getGoalStartDate() {
		return goalStartDate;
	}
	public void setGoalStartDate(Long goalStartDate) {
		this.goalStartDate = goalStartDate;
	}
	
	
}
