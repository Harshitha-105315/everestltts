package com.hillrom.mobile.dto;

import org.joda.time.DateTime;

import com.hillrom.mobile.domain.MedicationReminderDetails;
import com.hillrom.mobile.domain.PharmacyDetails;

public class MedicationsRecordingsDTO{
	
	private Long id;
	
	private Integer medicationTypeId;
	
	private String name;
	
	private String note;
	
	private Double rxNumber;
	
	private PharmacyDetails pharmacyId;
	
	private Boolean refillReminderFlag;
	
	private Boolean medicationTimeReminderFlag;
	
	private MedicationReminderDetails medicationReminderDetailsId;
	
	private DateTime refillReminder;
	
	private DateTime entryAdded;
	
	private String picture;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getMedicationTypeId() {
		return medicationTypeId;
	}

	public void setMedicationTypeId(Integer medicationTypeId) {
		this.medicationTypeId = medicationTypeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Double getRxNumber() {
		return rxNumber;
	}

	public void setRxNumber(Double rxNumber) {
		this.rxNumber = rxNumber;
	}

	public PharmacyDetails getPharmacyId() {
		return pharmacyId;
	}

	public void setPharmacyId(PharmacyDetails pharmacyId) {
		this.pharmacyId = pharmacyId;
	}

	public Boolean getRefillReminderFlag() {
		return refillReminderFlag;
	}

	public void setRefillReminderFlag(Boolean refillReminderFlag) {
		this.refillReminderFlag = refillReminderFlag;
	}

	public Boolean getMedicationTimeReminderFlag() {
		return medicationTimeReminderFlag;
	}

	public void setMedicationTimeReminderFlag(Boolean medicationTimeReminderFlag) {
		this.medicationTimeReminderFlag = medicationTimeReminderFlag;
	}

	public DateTime getRefillReminder() {
		return refillReminder;
	}

	public void setRefillReminder(DateTime refillReminder) {
		this.refillReminder = refillReminder;
	}

	public DateTime getEntryAdded() {
		return entryAdded;
	}

	public void setEntryAdded(DateTime entryAdded) {
		this.entryAdded = entryAdded;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public MedicationReminderDetails getMedicationReminderDetailsId() {
		return medicationReminderDetailsId;
	}

	public void setMedicationReminderDetailsId(
			MedicationReminderDetails medicationReminderDetailsId) {
		this.medicationReminderDetailsId = medicationReminderDetailsId;
	}

	@Override
	public String toString() {
		return "MedicationsRecordingsDto [id=" + id + ", medicationTypeId="
				+ medicationTypeId + ", name=" + name + ", note=" + note
				+ ", rxNumber=" + rxNumber + ", pharmacyId=" + pharmacyId
				+ ", refillReminderFlag=" + refillReminderFlag
				+ ", medicationTimeReminderFlag=" + medicationTimeReminderFlag
				+ ", medicationReminderDetailsId="
				+ medicationReminderDetailsId + ", refillReminder="
				+ refillReminder + ", entryAdded=" + entryAdded + ", picture="
				+ picture + "]";
	}

	public MedicationsRecordingsDTO(Integer medicationTypeId, String name,
			String note, Double rxNumber, PharmacyDetails pharmacyId,
			Boolean refillReminderFlag, Boolean medicationTimeReminderFlag,
			MedicationReminderDetails medicationReminderDetailsId,
			DateTime refillReminder, DateTime entryAdded, String picture) {
		super();
		this.medicationTypeId = medicationTypeId;
		this.name = name;
		this.note = note;
		this.rxNumber = rxNumber;
		this.pharmacyId = pharmacyId;
		this.refillReminderFlag = refillReminderFlag;
		this.medicationTimeReminderFlag = medicationTimeReminderFlag;
		this.medicationReminderDetailsId = medicationReminderDetailsId;
		this.refillReminder = refillReminder;
		this.entryAdded = entryAdded;
		this.picture = picture;
	}

	public MedicationsRecordingsDTO() {
		// TODO Auto-generated constructor stub
	}
	
}
