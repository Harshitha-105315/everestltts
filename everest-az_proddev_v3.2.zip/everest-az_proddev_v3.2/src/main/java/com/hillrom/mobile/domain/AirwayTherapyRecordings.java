package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "AIRWAY_THERAPY_RECORDINGS")
public class AirwayTherapyRecordings {

	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "patient_id")
	private String pid;

	@Column(name = "date_of_recording")
	//@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private Long dateTime;

	@Column(name = "duration")
	private String duration;

	@Column(name = "name")
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public Long getDateTime() {
		return dateTime;
	}

	public void setDateTime(Long dateTime) {
		this.dateTime = dateTime;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "AirwayTherapyRecordings [id=" + id + ", pid=" + pid
				+ ", dateTime=" + dateTime + ", duration=" + duration
				+ ", name=" + name + "]";
	}

	public AirwayTherapyRecordings(String pid, Long dateTime, String duration,
			String name, Long tid) {
		super();
		this.pid = pid;
		this.dateTime = dateTime;
		this.duration = duration;
		this.name = name;
	}

	public AirwayTherapyRecordings() {
		super();
	}
	
}
