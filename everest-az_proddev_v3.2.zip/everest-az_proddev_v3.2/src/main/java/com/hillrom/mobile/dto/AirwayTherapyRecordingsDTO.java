package com.hillrom.mobile.dto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "AirwayTherapyRecordingsDTO", description = "Airway Therapy Recording Log")
public class AirwayTherapyRecordingsDTO {

	@ApiModelProperty(value = "Patient Info", required = true)
	private String pid;
	
	@ApiModelProperty(value = "Therapy name", required = true)
	private String name;
	
	@ApiModelProperty(value = "Therapy record dateTime", required = true)
	private Long dateTime;
	
	@ApiModelProperty(value = "Therapy duration", required = true)
	private String duration;
	
	private Long tid;

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getDateTime() {
		return dateTime;
	}

	public void setDateTime(Long dateTime) {
		this.dateTime = dateTime;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Long getTid() {
		return tid;
	}

	public void setTid(Long tid) {
		this.tid = tid;
	}

}
