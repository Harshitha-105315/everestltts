package com.hillrom.mobile.rest;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hillrom.mobile.dto.MedicationRemindersVO;
import com.hillrom.mobile.dto.MedicationTakenListDTO;
import com.hillrom.mobile.dto.MedicationVO;
import com.hillrom.mobile.dto.PatientMedicationForTheDayVO;
import com.hillrom.mobile.service.PatientMedicationService;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.util.ExceptionConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import net.minidev.json.JSONObject;


@Api(value = "PatientMedicationResource", description = "PATIENT MEDICATION RESOURCE")
@RestController
@RequestMapping("/api/patient/"+ Constants.ApiVersion)
public class PatientMedicationResource {

	private final Logger log = LoggerFactory.getLogger(PatientMedicationResource.class);
	
	@Inject
	private PatientMedicationService patientMedicationService;	
	

	@ApiOperation(httpMethod = "GET", value = "Retrieve medication with pid ", response = MedicationVO.class, responseContainer = "List")
	@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String") ,
						@ApiImplicitParam(name = "date", value = "Date in YYYY-MM-DD", required = false, dataType = "String") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RetrieveAll medication successfull "),
			@ApiResponse(code = 400, message = "BAD REQUEST") })
	
	 @RequestMapping(value = "/medication/retrieveAll/{pid}", 
	            method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<?> getAllMedicationsForPatient(@PathVariable String pid,
		@RequestParam(value = "date", required = false) String date) {
			
			log.debug("REST request to retreive all medications nd reminders for Patient : {}", pid);
			JSONObject jsonObject = new JSONObject();
			try {
				jsonObject = patientMedicationService.getAllPatientMedicationDetails(pid, date);	    
				if(Objects.nonNull(jsonObject)) {
					return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			    }
			} catch(Exception e) {
			   jsonObject.put("ERROR", e.getMessage());
			   return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);
	 }
	 
	
	@ApiOperation(httpMethod = "GET", value = "Retrieve medication with pid and medicationId ", response = MedicationVO.class)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "medicationId", value = "Medication Id", required = true, dataType = "String") })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Retrieve a medication"),
			@ApiResponse(code = 200, message = "Cannot perform any operation : Wrong input !!") })
	
	 @RequestMapping(value = "/medication/retrieve/{pid}/{medicationId}",
	            method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> getMedicationForPatient(@PathVariable String pid, @PathVariable String medicationId) {
	    	
	    	log.debug("REST request to retreive medications nd reminders for Patient : {}");
	        MedicationVO medicationVO = new MedicationVO();
	     	JSONObject jsonObject = new JSONObject();
	        try {
	         medicationVO = patientMedicationService.getPatientMedicationDetails(pid,medicationId);
        
           if(medicationVO != null) {
                 return new ResponseEntity<>(medicationVO, HttpStatus.OK);
             }else {
					jsonObject.put("ERROR",ExceptionConstants.HR_923);
				} 
         } catch(Exception e) {
                   jsonObject.put("ERROR", e.getMessage());
                          return new ResponseEntity<JSONObject>(jsonObject,
                                        HttpStatus.BAD_REQUEST);
              }
	        return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);
	 }
	 
	 @ApiOperation(httpMethod = "POST", value = "Add medication")
		@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "medicationType", value = "Medication Type", required = true, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationName", value = "Medication  Name", required = true, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationNote", value = "Medication Note", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationReminder", value = "Medication Reminder", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationReminderFlag", value = "Medication Reminder Flag", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPrescriptionNo", value = "Medication PrescriptionNo", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyName", value = "Medication PharmacyName", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyAddress", value = "Medication PharmacyAddress", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyPhoneNumber", value = "Medication PharmacyPhoneNumber", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyLocationCoordinates", value = "Medication PharmacyLocationCoordinates", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationRefillReminderDate", value = "Medication RefillReminderDate", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationRefillReminderFlag", value = "Medication RefillReminderFlag", required = false, dataType = "boolean", example = "20")})
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Log Medication successfull"),
			@ApiResponse(code = 400, message = "LOG_MEDICATION_FAIL"),
			@ApiResponse(code = 200, message = "Cannot perform any operation : Wrong input !!") })
	 
	 @RequestMapping(value = "/medication/add", method = RequestMethod.POST)
		public ResponseEntity<?> addMedicationForPatientAndUpload(@RequestParam(value = "photo", required = false) MultipartFile file,
				@RequestParam(value = "pid", required = true) String pid,
				@RequestParam(value = "medicationType", required = true) String medicationType,				
				@RequestParam(value = "medicationName", required = true) String medicationName,
				@RequestParam(value = "medicationNote", required = false) String medicationNote,
				@RequestParam(value = "medicationReminder", required = false) String medicationReminder,				
				@RequestParam(value = "medicationReminderFlag", required = false) boolean medicationReminderFlag,
				@RequestParam(value = "medicationPrescriptionNo", required = false) String medicationPrescriptionNo,
				@RequestParam(value = "medicationPharmacyName", required = false) String medicationPharmacyName,
				@RequestParam(value = "medicationPharmacyAddress", required = false) String medicationPharmacyAddress,
				@RequestParam(value = "medicationPharmacyPhoneNumber", required = false) String medicationPharmacyPhoneNumber,				
				@RequestParam(value = "medicationPharmacyLocationCoordinates", required = false) String medicationPharmacyLocationCoordinates,
				@RequestParam(value = "medicationRefillReminderDate", required = false) String medicationRefillReminderDateStr,
				@RequestParam(value = "medicationRefillReminderFlag", required = false) boolean medicationRefillReminderFlag)
				throws IOException {
			
				log.debug("REST request to add medications nd reminders for Patient : {}");
				JSONObject jsonObject = new JSONObject();				
				String fileName = null;

				try {
					if(Objects.nonNull(file)) {
						fileName = StringUtils.cleanPath(file.getOriginalFilename());

						try {
							// Check if the file's name contains invalid characters
							if(fileName.contains("..")) {
								throw new Exception("Sorry! Filename contains invalid path sequence " + fileName);
							}					
						} catch (IOException e) {
							jsonObject.put("message", "LOG_MEDICATION_FAIL");
							return new ResponseEntity<JSONObject>(jsonObject,
									HttpStatus.BAD_REQUEST);
						}	
					}
			    	List<MedicationRemindersVO> medicationRemindersList = null;
			    	if(medicationReminderFlag)
			    	{
				        if(!StringUtils.isEmpty(medicationReminder)) {
		 		        		ObjectMapper objmap = new ObjectMapper();
				        		TypeReference<List<MedicationRemindersVO>> mapType = new TypeReference<List<MedicationRemindersVO>>() {};
				            	try {
				            		medicationRemindersList = objmap.readValue(medicationReminder, mapType);		
				            		
				        		} catch (Exception e) {
									jsonObject.put("message", "LOG_MEDICATION_FAIL");
									return new ResponseEntity<JSONObject>(jsonObject,
											HttpStatus.BAD_REQUEST);
				        		} 
					    	}else {
								jsonObject.put("message", "LOG_MEDICATION_FAIL");
								return new ResponseEntity<JSONObject>(jsonObject,
										HttpStatus.BAD_REQUEST);
					    	}
				    }
			    	
			        LocalDate medicationRefillReminderDate = null;
			        if(medicationRefillReminderFlag)
			        {
				        if(Objects.nonNull(medicationRefillReminderDateStr)) {
				        		medicationRefillReminderDate = LocalDate.parse(medicationRefillReminderDateStr);
				        }
				        else
				        {
							jsonObject.put("message", "LOG_MEDICATION_FAIL");
							return new ResponseEntity<JSONObject>(jsonObject,
									HttpStatus.BAD_REQUEST);				        	
				        }
			        }
					Long id = patientMedicationService.createPatientMedicationWithPictureUpload(file,fileName,pid, medicationType, medicationName, medicationNote, medicationRemindersList,				
							medicationReminderFlag,  medicationPrescriptionNo,  medicationPharmacyName,
							medicationPharmacyAddress, medicationPharmacyPhoneNumber,	 medicationPharmacyLocationCoordinates,
							medicationRefillReminderDate,  medicationRefillReminderFlag);
					if(id != 0 ) {
						jsonObject.put("medicationId",id);
						return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
					} else if ( id == 0 ) {
						jsonObject.put("ERROR",ExceptionConstants.HR_924);
						return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.CONFLICT);
					} else {
						jsonObject.put("ERROR",ExceptionConstants.HR_923);
					}
				}catch (Exception ex) {
					jsonObject.put("ERROR", ex.getMessage());
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
				}
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);				
		}
		
	 
	 @ApiOperation(httpMethod = "DELETE", value = "Delete medication")
		@ApiImplicitParams({
				@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
				@ApiImplicitParam(name = "medicationId", value = "Medication Id", required = true, dataType = "String"),
				@ApiImplicitParam(name = "isActive", value = "Is Active", required = true, dataType = "String") })
		@ApiResponses(value = {
				@ApiResponse(code = 200, message = "MED_ISACTIVE_SUCCESS "),
				@ApiResponse(code = 400, message = "MED_ISACTIVE_FAIL") })
		@RequestMapping(value = "/medication/remove", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<JSONObject> deleteMedicationForPatient(@RequestBody Map<String,Object> patientMedicationIdMap) {
	    	
	    	log.debug("REST request to delete medications nd reminders for Patient : {}");
	        JSONObject jsonObject = new JSONObject();
	        try {
	        	String patientId = (String) patientMedicationIdMap.get("patientId");
	        	String medicationId = String.valueOf(patientMedicationIdMap.get("medicationId"));
	        	String isActiveFlag = (String) patientMedicationIdMap.get("isActive");
	        	
	        	if(Objects.nonNull(patientId) && Objects.nonNull(medicationId) && Objects.nonNull(isActiveFlag)) {
	        		jsonObject = patientMedicationService.deletePatientMedicationDetails(patientId,medicationId,Boolean.parseBoolean(isActiveFlag));
	        	} else {	
	        		jsonObject.put("status", Constants.FAILURE_ACTIVE_STATUS);
    				return new ResponseEntity<>(jsonObject,HttpStatus.BAD_REQUEST);
	    		}
	        	if(Objects.nonNull(jsonObject)) {
	        		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	        	}
	        } catch(Exception ex) {
	        	jsonObject.put("ERROR", ex.getMessage());
	        	return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        }
			return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
	    }
	 
	 @ApiOperation(httpMethod = "POST", value = "Archive  medication")
		@ApiImplicitParams({
				@ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
				@ApiImplicitParam(name = "medicationId", value = "Medication Id", required = true, dataType = "String"),
				@ApiImplicitParam(name = "isArchive", value = "Is Archive", required = true, dataType = "String") })
		@ApiResponses(value = {
				@ApiResponse(code = 200, message = "MED_ARCHIEVE_UPDATE_SUCCESS "),
				@ApiResponse(code = 400, message = "MED_ARCHIEVE_UPDATE_FAIL") })
		@RequestMapping(value = "/medication/archive", method = RequestMethod.POST)
		@ResponseBody
		public ResponseEntity<?> archive(@RequestBody Map<String,Object> patientMedicationIdMap) {
			JSONObject jsonObject = new JSONObject();
			//findByPatientIdAndMedicationId
			String patientId = (String) patientMedicationIdMap.get("patientId");
			String medicationId = String.valueOf(patientMedicationIdMap.get("medicationId"));
			String archive = (String) patientMedicationIdMap.get("isArchive");

			if(Objects.nonNull(patientId) && Objects.nonNull(medicationId) && Objects.nonNull(archive)) {
				jsonObject = patientMedicationService.archiveDetails(patientId,Long.parseLong(medicationId),Boolean.parseBoolean(archive));
			}else 
			{  	jsonObject.put("status", Constants.FAILURE_ARCHIVE_STATUS);
			return new ResponseEntity<>(jsonObject,HttpStatus.BAD_REQUEST);
			}
			if(Objects.nonNull(jsonObject))  {
				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
			}
			return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		}
		
	 @ApiOperation(httpMethod = "PUT", value = "Edit Medication")
		@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String"),
			@ApiImplicitParam(name = "medicationType", value = "Medication Type", required = true, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationName", value = "Medication  Name", required = true, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationNote", value = "Medication Note", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationReminder", value = "Medication Reminder", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationReminderFlag", value = "Medication Reminder Flag", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPrescriptionNo", value = "Medication PrescriptionNo", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyName", value = "Medication PharmacyName", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyAddress", value = "Medication PharmacyAddress", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyPhoneNumber", value = "Medication PharmacyPhoneNumber", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationPharmacyLocationCoordinates", value = "Medication PharmacyLocationCoordinates", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationRefillReminderDate", value = "Medication RefillReminderDate", required = false, dataType = "String", example = "20"),
			@ApiImplicitParam(name = "medicationRefillReminderFlag", value = "Medication RefillReminderFlag", required = false, dataType = "boolean", example = "20")})
		@ApiResponses(value = { @ApiResponse(code = 200, message = "Medication Updated Successfully")  })
	 @RequestMapping(value = "/medication/update", method = RequestMethod.POST)
		public ResponseEntity<?> updateMedicationForPatient(@RequestParam(value = "photo", required = false) MultipartFile file,
				@RequestParam(value = "pid", required = true) String pid,
				@RequestParam(value = "medicationId", required = true) Long medicationID,
				@RequestParam(value = "medicationType", required = true) String medicationType,				
				@RequestParam(value = "medicationName", required = true) String medicationName,
				@RequestParam(value = "medicationNote", required = false) String medicationNote,
				@RequestParam(value = "medicationReminder", required = false) String medicationReminder,				
				@RequestParam(value = "medicationReminderFlag", required = false) boolean medicationReminderFlag,
				@RequestParam(value = "medicationPrescriptionNo", required = false) String medicationPrescriptionNo,
				@RequestParam(value = "medicationPharmacyName", required = false) String medicationPharmacyName,
				@RequestParam(value = "medicationPharmacyAddress", required = false) String medicationPharmacyAddress,
				@RequestParam(value = "medicationPharmacyPhoneNumber", required = false) String medicationPharmacyPhoneNumber,				
				@RequestParam(value = "medicationPharmacyLocationCoordinates", required = false) String medicationPharmacyLocationCoordinates,
				@RequestParam(value = "medicationRefillReminderDate", required = false) String medicationRefillReminderDateStr,
				@RequestParam(value = "medicationRefillReminderFlag", required = false) boolean medicationRefillReminderFlag,
				@RequestParam(value = "isPictureUpdated", required = false) boolean isPictureUpdated)
				{
			
				log.debug("REST request to update medications nd reminders for Patient : {}");
				JSONObject jsonObject = new JSONObject();				
				String fileName = null;

				try {
					if(Objects.nonNull(file)) {
						fileName = StringUtils.cleanPath(file.getOriginalFilename());

						try {
							// Check if the file's name contains invalid characters
							if(fileName.contains("..")) {
								throw new Exception("Sorry! Filename contains invalid path sequence " + fileName);
							}					
						} catch (IOException e) {
							e.printStackTrace();
						}	
					}
			    	List<MedicationRemindersVO> medicationRemindersList = null;
			        if(!StringUtils.isEmpty(medicationReminder)) {
	 		        		ObjectMapper objmap = new ObjectMapper();
			        		TypeReference<List<MedicationRemindersVO>> mapType = new TypeReference<List<MedicationRemindersVO>>() {};
			            	try {
			            		medicationRemindersList = objmap.readValue(medicationReminder, mapType);		
			            		
			        		} catch (Exception e) {
			        			e.printStackTrace();
			        		} 
			        	}
			        LocalDate medicationRefillReminderDate = null;
			        if(Objects.nonNull(medicationRefillReminderDateStr)) {
			        		medicationRefillReminderDate = LocalDate.parse(medicationRefillReminderDateStr);
			        }
			        
			        List<MedicationVO> medicationVOList = new ArrayList<>();
			        MedicationVO medicationVO = new MedicationVO();
					
			        medicationVO.setMedicationId(medicationID);
			        medicationVO.setMedicationType(medicationType);
			        medicationVO.setMedicationName(medicationName);
			        medicationVO.setMedicationNote(medicationNote);
			        medicationVO.setMedicationReminder(medicationRemindersList);
			        medicationVO.setMedicationReminderFlag(medicationReminderFlag);
			        medicationVO.setMedicationPrescriptionNo(medicationPrescriptionNo);
			        medicationVO.setMedicationPharmacyName(medicationPharmacyName);
			        medicationVO.setMedicationPharmacyAddress(medicationPharmacyAddress);
			        medicationVO.setMedicationPharmacyLocationCoordinates(medicationPharmacyLocationCoordinates);
			        medicationVO.setMedicationPharmacyPhoneNumber(medicationPharmacyPhoneNumber);
			        medicationVO.setMedicationRefillReminderFlag(medicationRefillReminderFlag);
			        if(medicationRefillReminderFlag) {
			        	medicationVO.setMedicationRefillReminderDate(medicationRefillReminderDate.toString());
			        }
			        
					if(Objects.nonNull(file) && isPictureUpdated) {
						medicationVO.setPhoto(file.getBytes());
					}
					
					if(patientMedicationService.isDuplicateMed(pid, medicationVO)) {
						jsonObject.put("ERROR",ExceptionConstants.HR_924);
						return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.CONFLICT);
					}
			        
					medicationVOList.add(medicationVO);

			        List<MedicationVO> patientMedicationDetails = patientMedicationService.updatePatientMedicationDetails(pid, medicationVOList,isPictureUpdated);
					
			        if(Objects.nonNull(patientMedicationDetails)) {
						jsonObject.put("medication details",Constants.SUCCESS_UPDATE_MESSAGE);
					}else {
						jsonObject.put("ERROR",ExceptionConstants.HR_923);
					}
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} catch(Exception e) {
					jsonObject.put("ERROR", e.getMessage());
					return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
				}			
		}
	 
	 @ApiOperation(httpMethod = "GET", value = "Retrieve medication for a day", response = PatientMedicationForTheDayVO.class)
		@ApiImplicitParams({ @ApiImplicitParam(name = "pid", value = "Patient Id", required = true, dataType = "String") })
		@ApiResponses(value = {
				@ApiResponse(code = 200, message = "RetrieveAll medication successfull "),
				@ApiResponse(code = 400, message = "BAD REQUEST") })
	 @RequestMapping(value = "/medication/retrieveforDay/{pid}",
	            method = RequestMethod.GET,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> getAllMedicationsForPatientForTheDay(@PathVariable String pid,
	    		@RequestParam(value = "date", required = true) String date) {
	    	
	    	log.debug("REST request to retrieve for the day for Patient : {}", pid);
	    	List<PatientMedicationForTheDayVO> patientMedicationForTheDayVO = new ArrayList<PatientMedicationForTheDayVO>();
	    	JSONObject jsonObject = new JSONObject();			
	    	try {
	    		if(Objects.nonNull(pid) && Objects.nonNull(date)){
	    			patientMedicationForTheDayVO = patientMedicationService.getAllPatientMedicationForTheDay(pid,LocalDate.parse(date));
	    			if(Objects.nonNull(patientMedicationForTheDayVO) && !patientMedicationForTheDayVO.isEmpty()) {
	    				jsonObject.put("pid", pid);
	    				jsonObject.put("medicationList", patientMedicationForTheDayVO);
	    				return new ResponseEntity<>(jsonObject, HttpStatus.OK);
	    			} else{
	    				jsonObject.put("ERROR", Constants.NO_PATIENTID);	    			
	    			return new ResponseEntity<>(jsonObject,
	    					HttpStatus.BAD_REQUEST);
	    			}
	    		}else{
	    			jsonObject.put("ERROR", Constants.NO_RETRIEVE);
	    			return new ResponseEntity<>(
	    					HttpStatus.BAD_REQUEST);
	    		}
	    	} catch(Exception e) {
	    		jsonObject.put("ERROR", e.getMessage());
	    		return new ResponseEntity<JSONObject>(jsonObject,
	    				HttpStatus.BAD_REQUEST);
	    	}	    
	 }
	 
	 
	 @ApiOperation(httpMethod = "POST", value = "Edit Medication Taken For Patient")
	 @ApiResponses(value = { @ApiResponse(code = 200, message = "MED_IS_TAKEN_SUCCESS")	})
	 @RequestMapping(value = "/medication/updateTaken",
	            method = RequestMethod.POST,
	            produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> updateMedicationTakenForPatient(@RequestBody MedicationTakenListDTO medicationTakenList) {
	    	
	    	log.debug("REST request to update taken for Patient : {}", medicationTakenList.getMedicationTakenList().toString());	    	
	    	JSONObject jsonObject = new JSONObject();			
	    	try {
	    			    		
	    		if (!(medicationTakenList.getMedicationTakenList().size() > 0)) {
	    			jsonObject.put("ERROR","NOTHING_TO_UPDATE");
	    			return new ResponseEntity<>(jsonObject,	HttpStatus.BAD_REQUEST);
	    		}

	    		jsonObject = patientMedicationService.updateMedicationTakenListForPatient(medicationTakenList);
	    		return new ResponseEntity<>(jsonObject, HttpStatus.OK);
		    	
	    	} catch(Exception e) {
	    		jsonObject.put("ERROR", e.getMessage());
	    		return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.FORBIDDEN);
	    	}
	 }
		 
}
