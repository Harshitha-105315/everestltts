package com.hillrom.mobile.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MANAGE_APP_VERSION")
public class ManageAppVersion {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
	
	@Column(name = "version")
    private String version;
	
	@Column(name = "type")
    private String type;

	@Column(name = "udi")
    private String udi;

	@Column(name = "is_force_upgrade", nullable = false)
	private boolean is_force_upgrade = false;
	
	@Column(name = "is_active", nullable = false)
	private boolean is_active = false;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUdi() {
		return udi;
	}

	public void setUdi(String udi) {
		this.udi = udi;
	}

	public boolean isIs_force_upgrade() {
		return is_force_upgrade;
	}

	public void setIs_force_upgrade(boolean is_force_upgrade) {
		this.is_force_upgrade = is_force_upgrade;
	}

	public boolean isIs_active() {
		return is_active;
	}

	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}
	
}
