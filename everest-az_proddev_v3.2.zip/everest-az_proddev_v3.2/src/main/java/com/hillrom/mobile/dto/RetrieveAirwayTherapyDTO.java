package com.hillrom.mobile.dto;

import java.util.List;

public class RetrieveAirwayTherapyDTO {
	List<AirwayTherapyDataDTO> data;

	public List<AirwayTherapyDataDTO> getData() {
		return data;
	}

	public void setData(List<AirwayTherapyDataDTO> data) {
		this.data = data;
	}	
}
