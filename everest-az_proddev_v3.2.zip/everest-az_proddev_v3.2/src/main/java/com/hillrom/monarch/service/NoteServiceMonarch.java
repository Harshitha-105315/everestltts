package com.hillrom.monarch.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.NoteMonarchRepository;
import com.hillrom.monarch.web.rest.dto.NoteMonarchVO;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.NoteMonarch;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.repository.util.QueryConstants;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.GraphUtils;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;
import com.hillrom.vest.web.rest.dto.PatientUserVO;
import com.hillrom.vest.web.rest.util.PaginationUtil;


@Service
@Transactional
public class NoteServiceMonarch {
	
	@Inject
	private NoteMonarchRepository noteMonarchRepository;
	
	@Inject
	private PatientNoEventMonarchService patientNoEventMonarchService;
	
	@Inject
	private UserRepository userRepository;
	
	@Inject
	private UserService userService;
	
	@Inject
	private UserPatientRepository userPatientRepository;
	
	@Inject
	private EntityManager entityManager;
	
	private static final String ORDER_BY_CLAUSE_START = " order by ";

	
	public Map<LocalDate,NoteMonarch> findByPatientUserIdAndCreatedOnBetweenGroupByCreatedOn(Long patientUserId,LocalDate from,LocalDate to,Boolean isDeleted){
		List<NoteMonarch> notes = noteMonarchRepository.findByPatientUserIdAndCreatedOnBetweenAndDeletedOrderByCreatedOnAsc(patientUserId, from, to, false);
		Map<LocalDate,NoteMonarch> dateNotesMap = new TreeMap<>();
		for(NoteMonarch note : notes){
			dateNotesMap.put(note.getCreatedOn(), note);
		}
		return dateNotesMap;
	}
	
	public Page<NoteMonarch> findByUserIdAndDateRange(Long userId,LocalDate from,LocalDate to,Boolean isDeleted,Pageable pageable){
		Page<NoteMonarch> notes = noteMonarchRepository.findByPatientUserIdAndCreatedOnBetweenAndDeletedOrderByCreatedOnDesc(userId,from,to,isDeleted,pageable);
		return notes;
	}

	public NoteMonarch findOneByUserIdAndDate(Long userId,LocalDate date){
		Optional<NoteMonarch> note =  noteMonarchRepository.findOneByPatientUserIdAndCreatedOn(userId, date);
		if(note.isPresent())
			return note.get();
		return null;
	}
	
	public NoteMonarch saveOrUpdateNoteByUserId(Long userId,String note,LocalDate date) throws HillromException{
		if(StringUtils.isBlank(note))
			return null;
		
		
		PatientNoEventMonarch patientNoEvent = patientNoEventMonarchService.findByPatientUserId(userId);
		
		if(Objects.isNull(patientNoEvent))
			throw new HillromException(ExceptionConstants.HR_585);
		//Start GIMP 11
		LocalDate firstTransmissionDateByType = GraphUtils.getFirstTransmissionDateMonarchByType(patientNoEvent);
		if(Objects.isNull(firstTransmissionDateByType) ||  date.isBefore(firstTransmissionDateByType))
			throw new HillromException(ExceptionConstants.HR_701);
		//Ends GIMP 11	
		NoteMonarch existingNote = findOneByUserIdAndDate(userId,date);
		if(Objects.isNull(existingNote)){
			existingNote = new NoteMonarch();
			User patientUser = userRepository.findOne(userId);
			PatientInfo patient = userService.getPatientInfoObjFromPatientUser(patientUser);
			if(Objects.isNull(patient))
				return null;
			existingNote.setPatient(patient);
			existingNote.setPatientUser(patientUser);
			existingNote.setNote(note);
			existingNote.setCreatedOn(date);
			noteMonarchRepository.save(existingNote);
		}else{
			existingNote.setNote(note);
			existingNote.setDeleted(false);
			noteMonarchRepository.save(existingNote);
		}
		return existingNote;
	}
	
	public NoteMonarch findOneByPatientIdAndDate(String patientId,LocalDate date){
		Optional<NoteMonarch> note =  noteMonarchRepository.findOneByPatientIdAndCreatedOn(patientId,date);
		if(note.isPresent())
			return note.get();
		return null;
	}
	
	public NoteMonarch saveOrUpdateNoteByPatientId(String patientId,String note,LocalDate date) throws HillromException{
		PatientNoEventMonarch patientNoEvent = patientNoEventMonarchService.findByPatientId(patientId);
		if(Objects.nonNull(patientNoEvent))
			throw new HillromException(ExceptionConstants.HR_585);
		//Start GIMP 11
		LocalDate firstTransmissionDateByType = GraphUtils.getFirstTransmissionDateMonarchByType(patientNoEvent);
		if(Objects.isNull(firstTransmissionDateByType) ||  date.isBefore(firstTransmissionDateByType))
			throw new HillromException(ExceptionConstants.HR_701);
		//Ends GIMP 11
		if(StringUtils.isBlank(note))
			return null;
		NoteMonarch existingNote = findOneByPatientIdAndDate(patientId,date);
		if(Objects.isNull(existingNote)){
			existingNote = new NoteMonarch();
			List<UserPatientAssoc> associations = userPatientRepository.findOneByPatientId(patientId);
			UserPatientAssoc userPatientAssoc = (UserPatientAssoc) associations.stream().filter(assoc -> 
				RelationshipLabelConstants.SELF.equalsIgnoreCase(assoc.getRelationshipLabel())
			);
			if(Objects.nonNull(userPatientAssoc)){				
				existingNote.setPatient(userPatientAssoc.getPatient());
				existingNote.setPatientUser(userPatientAssoc.getUser());
				existingNote.setNote(note);
				existingNote.setCreatedOn(date);
				noteMonarchRepository.save(existingNote);
			}
		}else{
			existingNote.setNote(note);
			existingNote.setDeleted(false);
			noteMonarchRepository.save(existingNote);
		}
		return existingNote;
	}
	
	public NoteMonarch update(Long id,String noteText){
		NoteMonarch existingNote = noteMonarchRepository.findOne(id);
		if(Objects.nonNull(existingNote)){
			existingNote.setNote(noteText);
			noteMonarchRepository.save(existingNote);
		}
		return existingNote;	
	}
	
	public void deleteNote(Long id){
		noteMonarchRepository.delete(id);
	}
	
	public NoteMonarch findMemoNotesForPatientId(Long userId, String patientId){
		Optional<NoteMonarch> note =  noteMonarchRepository.returnPatientMemo(userId, patientId);
		if(note.isPresent())
			return note.get();
		return null;
	}

	public Page<NoteMonarchVO> findByUserIdAndDateRangeForVestAndMonarch(Long userId,LocalDate from,LocalDate to,Boolean isDeleted, Integer offset, Integer limit){

        String queryVest = QueryConstants.QUERY_PATIENT_NOTES_VEST;
        String appendquery= queryVest+" where user_id = '"+ userId +"' and created_on between '"+from+"' and '"+to +"' and is_deleted= '"+isDeleted+"'";
        String queryMonarch = QueryConstants.QUERY_PATIENT_NOTES_MONARCH;
		String appendFinalQuery= appendquery + " UNION " + queryMonarch +" where user_id = '"+ userId +"' and created_on between '"+from+"' and '"+to +"' and is_deleted= '"
        +isDeleted+"'";

 //       Query nativeQuery = entityManager.createNativeQuery(appendFinalQuery);
                
        String countSqlQuery = "select count(user_id) from (" + appendFinalQuery + " ) patientUsers";

		Query countQuery = entityManager.createNativeQuery(countSqlQuery);
		BigInteger count = (BigInteger) countQuery.getSingleResult();
		
		String sortBy = "";
		Boolean isAscending=false;
		Pageable pageable = PaginationUtil.generatePageRequest(offset, limit);
		
		Map<String, Boolean> sortOrder = new HashMap<>();
		if (StringUtils.isNotBlank(sortBy)) {
			isAscending = (isAscending != null) ? isAscending : true;
			sortOrder.put(sortBy, isAscending);
		}
		
		Query query = getOrderedByQuery(appendFinalQuery, sortOrder);
		setPaginationParams(pageable, query);

        List<NoteMonarchVO> notes = new ArrayList<NoteMonarchVO>();
        List<Object[]> results = query.getResultList();
        results.stream().forEach((record) -> {
                Long id = ((BigInteger) record[0]).longValue();
                LocalDate createdOn = LocalDate.fromDateFields(((java.util.Date) record[1]));
                long patientUser = ((BigInteger) record[2]).longValue();
                String patient=(String) record[3];
                String note = (String) record[4];
                DateTime modifiedAt =new DateTime(((java.util.Date) record[5]));
                boolean deleted = (boolean) record[6];

               NoteMonarchVO noteMonarch = new NoteMonarchVO(id,createdOn,patientUser,patient,note,modifiedAt,deleted);

                notes.add(noteMonarch);

        });


        Page<NoteMonarchVO> page = new PageImpl<NoteMonarchVO>(notes, null, count.intValue());
        
        return page;
        }

	
	private void setPaginationParams(Pageable pageable, Query query) {

		int firstResult = pageable.getOffset();
		int maxResult = pageable.getPageSize();
		query.setFirstResult(firstResult);
		query.setMaxResults(maxResult);
	}
	
	
	private Query getOrderedByQuery(String queryString, Map<String, Boolean> columnNames) {

		StringBuilder sb = new StringBuilder();
		// Append order by only if there is any sort request.
		if (columnNames.keySet().size() > 0) {
			sb.append(ORDER_BY_CLAUSE_START);
		}

		int limit = columnNames.size();
		int i = 0;
		for (String columnName : columnNames.keySet()) {
			if(!Constants.ADHERENCE.equalsIgnoreCase(columnName))
				sb.append("lower(").append(columnName).append(")");
			else
				sb.append(columnName);

			if (columnNames.get(columnName))
				sb.append(" ASC");
			else
				sb.append(" DESC");

			if (i++ != (limit - 1)) {
				sb.append(", ");
			}
		}		
		
		Query jpaQuery = entityManager.createNativeQuery(queryString + sb.toString());
		return jpaQuery;
	}
}

	

