package com.hillrom.monarch.service;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.PatientMonarchDeviceRawLogRepository;
import com.hillrom.vest.domain.PatientVestDeviceRawLogMonarch;

@Service
@Transactional
public class PatientVestDeviceRawLogsMonarchService {
	
	@Inject
	private PatientMonarchDeviceRawLogRepository patientMonarchDeviceRawLogRepository;

	public Page<PatientVestDeviceRawLogMonarch> findAll(Pageable pageable,DateTime from, DateTime to){
		Page<PatientVestDeviceRawLogMonarch> chargerDataList =  patientMonarchDeviceRawLogRepository.findByCreatedTimeBetweenOrderByIdDesc(from, to,pageable);
			return chargerDataList;
	}

	public Page<PatientVestDeviceRawLogMonarch> findBySNo(Pageable pageable, String sno, DateTime from, DateTime to){
		Page<PatientVestDeviceRawLogMonarch> chargerDataList =  patientMonarchDeviceRawLogRepository.findByDeviceSerialNumberAndCreatedTimeBetweenOrderByIdDesc(sno, from, to,pageable);
			return chargerDataList;
	}
}
