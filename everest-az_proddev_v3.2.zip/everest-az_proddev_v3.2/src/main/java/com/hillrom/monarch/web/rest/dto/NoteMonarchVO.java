package com.hillrom.monarch.web.rest.dto;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.util.ISO8601LocalDateDeserializer;
import com.hillrom.vest.domain.util.MMDDYYYYLocalDateSerializer;


public class NoteMonarchVO {

	
	private Long id;
	
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	@JsonSerialize(using = MMDDYYYYLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
	private LocalDate createdOn;

	private Long patientUser;
	
	private String patient;

	private String note;

	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime modifiedAt = DateTime.now();
	
	private boolean deleted;

	@Override
	public String toString() {
		return "NoteMonarchVO [id=" + id + ", createdOn=" + createdOn
				+ ", patientUser=" + patientUser + ", patient=" + patient
				+ ", note=" + note + ", modifiedAt=" + modifiedAt
				+ ", deleted=" + deleted + "]";
	}

	public NoteMonarchVO(Long id, LocalDate createdOn, Long patientUser,
			String patient, String note, DateTime modifiedAt, boolean deleted) {
		super();
		this.id = id;
		this.createdOn = createdOn;
		this.patientUser = patientUser;
		this.patient = patient;
		this.note = note;
		this.modifiedAt = modifiedAt;
		this.deleted = deleted;
	}

	public NoteMonarchVO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public Long getPatientUser() {
		return patientUser;
	}

	public void setPatientUser(Long patientUser) {
		this.patientUser = patientUser;
	}

	public String getPatient() {
		return patient;
	}

	public void setPatient(String patient) {
		this.patient = patient;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public DateTime getModifiedAt() {
		return modifiedAt;
	}

	public void setModifiedAt(DateTime modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

}
