package com.hillrom.monarch.service;

import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateCumulativeDuration;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateHMRRunRatePerSession;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateHMRRunRatePerSessionBoth;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateWeightedAvg;
import static com.hillrom.vest.config.AdherenceScoreConstants.ADHERENCE_SETTING_DEFAULT_DAYS;
import static com.hillrom.vest.config.AdherenceScoreConstants.BONUS_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_MISSED_THERAPY_DAYS_COUNT;
import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_SETTINGS_DEVIATION_COUNT;
import static com.hillrom.vest.config.AdherenceScoreConstants.HMR_NON_COMPLIANCE_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.LOWER_BOUND_VALUE;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.MISSED_THERAPY;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.service.util.DateUtil.getPlusOrMinusTodayLocalDate;
import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateCumulativeDuration;
import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateHMRRunRatePerSession;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.repository.AdherenceResetMonarchRepository;
import com.hillrom.monarch.repository.ClinicMonarchRepository;
import com.hillrom.monarch.repository.NotificationMonarchRepository;
import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.vest.domain.AdherenceResetMonarch;
import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.NotificationMonarch;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.service.AdherenceCalculationService;
import com.hillrom.vest.service.ClinicPatientService;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.PatientNoEventService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.TherapySessionService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.GraphUtils;
import com.hillrom.vest.web.rest.dto.CareGiverStatsNotificationVO;
import com.hillrom.vest.web.rest.dto.ClinicStatsNotificationVO;
import com.hillrom.vest.web.rest.dto.PatientStatsVO;

@Service
@Transactional
public class AdherenceCalcMonarchNotificationHelper{

	private static final String TOTAL_DURATION = "totalDuration";

	private static final String WEIGHTED_AVG_INTESITY = "weightedAvgIntensity";

	private static final String WEIGHTED_AVG_FREQUENCY = "weightedAvgFrequency";
	
	private static final String DAILY = "Daily";

	@Inject
	private PatientProtocolMonarchService protocolMonarchService;
	
	@Inject
	private TherapySessionMonarchRepository therapySessionMonarchRepository;
	
	@Inject
	private PatientComplianceMonarchRepository patientComplianceMonarchRepository;
	
	@Inject
	private NotificationMonarchRepository notificationMonarchRepository;
	
	@Inject
	private MailService mailService;
	
	@Inject
	private NotificationMonarchService notificationMonarchService;
	
	@Inject
	private PatientComplianceMonarchService complianceMonarchService;
	
	@Inject
	private PatientNoEventMonarchService noEventMonarchService;
	
	@Inject
	private PatientNoEventService noEventMonarchServiceVest;
	
	@Inject
	private ClinicMonarchRepository clinicMonarchRepository;
	
	@Inject
	private ClinicPatientService clinicPatientService;
	
	@Inject
	private UserService userService;
	
	//hill-1956
	@Inject
	private AdherenceResetMonarchRepository adherenceResetMonarchRepository;
	//hill-1956
	
	@Inject
	@Lazy
	private AdherenceCalculationService adherenceCalculationService;
	
	
	@Inject
	private PatientProtocolService protocolVestService;
	
	@Inject
	@Lazy
	private TherapySessionService therapySessionService;
	
	@Inject
	@Lazy
	private TherapySessionServiceMonarch therapySessionMonarchService;
	
	private final Logger log = LoggerFactory.getLogger(AdherenceCalcMonarchNotificationHelper.class);
	
	/**
	 * Get Protocol Constants by loading Protocol data
	 * @param patientUserId
	 * @return
	 */
	public ProtocolConstantsMonarch getProtocolByPatientUserId(
			Long patientUserId) throws Exception{
		List<Long> patientUserIds = new LinkedList<>();
		patientUserIds.add(patientUserId);
		Map<Long,ProtocolConstantsMonarch> userIdProtolConstantsMap = protocolMonarchService.getProtocolByPatientUserIds(patientUserIds);
		return userIdProtolConstantsMap.get(patientUserId);
	}

	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsMonarch protocolConstant,
			double actualTotalDurationSettingDays, 
			Integer adherenceSettingDay) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstant
				.getMinDuration()) ? protocolConstant.getMinDuration()
				: protocolConstant.getTreatmentsPerDay()
						* protocolConstant.getMinMinutesPerTreatment();
		if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays/adherenceSettingDay)){
			return false;
		}
		return true;
	}
	
	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstantMonarch
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsMonarch protocolConstantMonarch,
			ProtocolConstants protocolConstantVest,
			double actualTotalDurationSettingDays, 
			Integer adherenceSettingDay) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstantMonarch
				.getMinDuration()) ? protocolConstantMonarch.getMinDuration()
				: protocolConstantMonarch.getTreatmentsPerDay()
						* protocolConstantMonarch.getMinMinutesPerTreatment();
		
		// Getting the minimum reading from the vest protocol		
		int minHMRReadingVest = Objects.nonNull(protocolConstantVest
				.getMinDuration()) ? protocolConstantVest.getMinDuration()
				: protocolConstantVest.getTreatmentsPerDay()
						* protocolConstantVest.getMinMinutesPerTreatment();

		// Take the least from both the protocols minimum HMR from Vest and Monarch
			if(minHMRReading > minHMRReadingVest){
				minHMRReading = minHMRReadingVest;
			}		
		if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays/adherenceSettingDay)){
			return false;
		}
		return true;
	}

	/**
	 * Checks Whether Settings deviated(protocol.minFrequency < actualWeightedAvgFreq)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isSettingsDeviated(ProtocolConstantsMonarch protocolConstant,
			double weightedAvgFrequency) {
		if((protocolConstant.getMinFrequency()* LOWER_BOUND_VALUE) > weightedAvgFrequency){
			return true;
		}
		return false;
	}

	/**
	 * Calculates Metrics such as weightedAvgFrequency,Intensity,treatmentsPerDay,duration for last adherence setting days
	 * @param therapySessionsPerDay
	 * @return
	 */
	public Map<String,Double> calculateTherapyMetricsPerSettingDays(
			List<TherapySessionMonarch> therapySessionsPerDay) {
		double totalDuration = calculateCumulativeDuration(therapySessionsPerDay);
		double weightedAvgFrequency = 0f;
		double weightedAvgIntensity = 0f;
		for(TherapySessionMonarch therapySession : therapySessionsPerDay){
			int durationInMinutes = therapySession.getDurationInMinutes(); 
			weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
			weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getIntensity());
		}
		Map<String,Double> actualMetrics = new HashMap<>();
		weightedAvgFrequency = Math.round(weightedAvgFrequency);
		weightedAvgIntensity = Math.round(weightedAvgIntensity);
		actualMetrics.put(WEIGHTED_AVG_FREQUENCY, weightedAvgFrequency);
		actualMetrics.put(WEIGHTED_AVG_INTESITY, weightedAvgIntensity);
		actualMetrics.put(TOTAL_DURATION, totalDuration);
		return actualMetrics;
	}

	/**
	 * Calculates Metrics such as weightedAvgFrequency,Intensity,treatmentsPerDay,duration for last adherence setting days
	 * @param therapySessionsPerDay
	 * @return
	 */
	public Map<String,Double> calculateTherapyMetricsPerSettingDaysBoth(
			Map<String, Object> combined) {
		
		List<TherapySessionMonarch> therapySessionsPerDay = (List<TherapySessionMonarch>) combined.get("Monarch");
		List<TherapySession> therapySessionsPerDayVest = (List<TherapySession>) combined.get("Vest");
		
		double totalDuration = calculateCumulativeDuration(therapySessionsPerDay) + calculateCumulativeDuration(therapySessionsPerDayVest);
		
		double weightedAvgFrequency = 0f;
		double weightedAvgIntensity = 0f;
		
		for(TherapySessionMonarch therapySession : therapySessionsPerDay){
			int durationInMinutes = therapySession.getDurationInMinutes(); 
			weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
			weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getIntensity());
		}
		
		for(TherapySession therapySession : therapySessionsPerDayVest){
			int durationInMinutes = therapySession.getDurationInMinutes(); 
			weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
			weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getPressure());
		}
		
		Map<String,Double> actualMetrics = new HashMap<>();
		weightedAvgFrequency = Math.round(weightedAvgFrequency);
		weightedAvgIntensity = Math.round(weightedAvgIntensity);
		actualMetrics.put(WEIGHTED_AVG_FREQUENCY, weightedAvgFrequency);
		actualMetrics.put(WEIGHTED_AVG_INTESITY, weightedAvgIntensity);
		actualMetrics.put(TOTAL_DURATION, totalDuration);
		
		return actualMetrics;
	}
	
	public void processMissedTherapySessionsMonarchImpl(LocalDate date){
		try{
			LocalDate today = date;
			log.debug("Started calculating missed therapy "+DateTime.now()+","+today);
			List<PatientComplianceMonarch> mstPatientComplianceList = patientComplianceMonarchRepository.findMissedTherapyPatientsRecords();
			Map<Long,PatientComplianceMonarch> mstNotificationMap = new HashMap<>();
			Map<Long,PatientComplianceMonarch> hmrNonComplianceMap = new HashMap<>();
			Map<Long,PatientComplianceMonarch> hmrNonComplianceMapBoth = new HashMap<>();
			Map<Long,ProtocolConstantsMonarch> userProtocolConstantsMap = new HashMap<>();
			Map<Long,ProtocolConstants> userProtocolConstantsVestMap = new HashMap<>();
			Map<Long,PatientComplianceMonarch> complianceMap = new HashMap<>();
			Map<Long,NotificationMonarch> notificationMap = new HashMap<>();
			Map<Long,PatientNoEventMonarch> userIdNoEventMap = noEventMonarchService.findAllGroupByPatientUserId();
			
			Map<Long,PatientNoEvent> userIdNoEventMapVest = noEventMonarchServiceVest.findAllGroupByPatientUserId();
			
			for(PatientComplianceMonarch compliance : mstPatientComplianceList){
				
				String deviceType = adherenceCalculationService.getDeviceTypeValue(compliance.getPatient().getId());
				
				if(deviceType.equals("MONARCH"))
					processForEachPatientMonarch(compliance, userIdNoEventMap, complianceMap, mstNotificationMap,hmrNonComplianceMap);
				else if(deviceType.equals("BOTH"))
					processForEachPatientBoth(compliance, userIdNoEventMap, userIdNoEventMapVest, complianceMap, mstNotificationMap,hmrNonComplianceMapBoth);
			}
			

			List<Long> patientUserIds =  new LinkedList<>(hmrNonComplianceMap.keySet());
			patientUserIds.addAll(new LinkedList<>(hmrNonComplianceMapBoth.keySet()));
			
			userProtocolConstantsMap = protocolMonarchService.getProtocolByPatientUserIds(patientUserIds);
			userProtocolConstantsVestMap = protocolVestService.getProtocolByPatientUserIds(patientUserIds);

			if(Objects.nonNull(hmrNonComplianceMapBoth)){
				// Update HMR for the Both device patients
				calculateHMRComplianceForMSTBoth(today, hmrNonComplianceMapBoth,
							userProtocolConstantsMap, userProtocolConstantsVestMap, complianceMap, notificationMap);
			}

			
			calculateHMRComplianceForMST(today, hmrNonComplianceMap,
						userProtocolConstantsMap, complianceMap, notificationMap);
			
			calculateMissedTherapy(today, mstNotificationMap,
					hmrNonComplianceMap, complianceMap, notificationMap);
			
			updateNotificationsOnMST(today, notificationMap);
			updateComplianceForMST(today, complianceMap);
			log.debug("Started calculating missed therapy "+DateTime.now()+","+today);
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("processMissedTherapySessionsMonarch",writer.toString());
		}
	}
	
	private void processForEachPatientMonarch(PatientComplianceMonarch compliance, Map<Long,PatientNoEventMonarch> userIdNoEventMap, 
			Map<Long,PatientComplianceMonarch> complianceMap, Map<Long,PatientComplianceMonarch> mstNotificationMap,
			Map<Long,PatientComplianceMonarch> hmrNonComplianceMap){
		
		LocalDate today = LocalDate.now();
		Long userId = compliance.getPatientUser().getId();
		PatientInfo patientInfo = compliance.getPatient();
		
		Integer adherenceSettingDay = getAdherenceSettingForPatient(patientInfo);
		
		PatientNoEventMonarch noEvent = userIdNoEventMap.get(compliance.getPatientUser().getId());
		
		//global counters
		int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
		int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
		int globalSettingsDeviationCounter = compliance.getGlobalSettingsDeviationCounter();
		
		// Start GIMP 11 changed to GraphUtils.getFirstTransmissionDateMonarchByType(noEvent) instead noEvent.geTransmissionDate()

		// For No transmission users , compliance shouldn't be updated until transmission happens
		if(Objects.nonNull(noEvent) && (Objects.isNull(GraphUtils
				.getFirstTransmissionDateMonarchByType(noEvent)))){
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(compliance.getScore(), today,
					compliance.getPatient(), compliance.getPatientUser(),compliance.getHmrRunRate(),true,
					false,0);
			newCompliance.setLatestTherapyDate(null);// since no transmission 
			complianceMap.put(userId, newCompliance);
			// HMR Compliance shouldn't be checked for Patients for initial adherence setting days of transmission date
		}else if(Objects.nonNull(noEvent)&& (Objects.nonNull(GraphUtils
				.getFirstTransmissionDateMonarchByType(noEvent)) && 
				DateUtil.getDaysCountBetweenLocalDates(GraphUtils
						.getFirstTransmissionDateMonarchByType(noEvent), today) < (adherenceSettingDay-1) &&
				adherenceSettingDay > 1 )){
			//Ends changes
			// For Transmitted users no notification till earlier day of adherence Setting day(s)
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(today,compliance.getPatient(),compliance.getPatientUser(),
					compliance.getHmrRunRate(),compliance.getMissedTherapyCount()+1,compliance.getLatestTherapyDate(),
					Objects.nonNull(compliance.getHmr())? compliance.getHmr():0.0d);
			newCompliance.setScore(compliance.getScore());
			updateGlobalCounters(++globalMissedTherapyCounter,
					globalHMRNonAdherenceCounter,
					globalSettingsDeviationCounter, newCompliance);
			complianceMap.put(userId, newCompliance);
		}else {
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(
					today,
					compliance.getPatient(),
					compliance.getPatientUser(),
					compliance.getHmrRunRate(),
					compliance.getMissedTherapyCount()+1,
					compliance.getLatestTherapyDate(),
					Objects.nonNull(compliance.getHmr())? compliance.getHmr():0.0d);
			newCompliance.setScore(compliance.getScore());
			newCompliance.setSettingsDeviatedDaysCount(0);
			// increment global missed therapy counter
			updateGlobalCounters(++globalMissedTherapyCounter,
					globalHMRNonAdherenceCounter,
					globalSettingsDeviationCounter, newCompliance);
			log.debug("Compliance before calc "+newCompliance);
			if(newCompliance.getMissedTherapyCount() >= adherenceSettingDay){ // missed Therapy for adherenceSetting day(s) or more than adherenceSetting day(s) days
				mstNotificationMap.put(compliance.getPatientUser().getId(), newCompliance);
			}else{ // missed therapy for less than adherence setting day(s) , might fall under hmrNonCompliance
				hmrNonComplianceMap.put(compliance.getPatientUser().getId(), newCompliance);
			}
		}
	}
	
	private void processForEachPatientBoth(PatientComplianceMonarch compliance, Map<Long,PatientNoEventMonarch> userIdNoEventMap, 
			Map<Long,PatientNoEvent> userIdNoEventMapVest, Map<Long,PatientComplianceMonarch> complianceMap, 
			Map<Long,PatientComplianceMonarch> mstNotificationMap, Map<Long,PatientComplianceMonarch> hmrNonComplianceMap){
		
		LocalDate today = LocalDate.now();
		Long userId = compliance.getPatientUser().getId();
		PatientInfo patientInfo = compliance.getPatient();
		
		Integer adherenceSettingDay = getAdherenceSettingForPatient(patientInfo);
		
		PatientNoEventMonarch noEvent = userIdNoEventMap.get(compliance.getPatientUser().getId());
		PatientNoEvent noEventVest = userIdNoEventMapVest.get(compliance.getPatientUser().getId());
		
		//global counters
		int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
		int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
		int globalSettingsDeviationCounter = compliance.getGlobalSettingsDeviationCounter();
		// Start GIMP 11 changed to GraphUtils.getFirstTransmissionDateMonarchByType(noEvent) instead noEvent.geTransmissionDate()
		LocalDate firstTransmissionDateMonarch = (Objects.nonNull(noEvent) && Objects.nonNull(GraphUtils.getFirstTransmissionDateMonarchByType(noEvent))) ? 
				GraphUtils.getFirstTransmissionDateMonarchByType(noEvent) : null; 
		
		// Start GIMP 11 changed to GraphUtils.getFirstTransmissionDateVestByType(noEventVest) instead noEventVest.geTransmissionDate()
		LocalDate firstTransmissionDateVest = (Objects.nonNull(noEventVest) && Objects.nonNull(GraphUtils.getFirstTransmissionDateVestByType(noEventVest))) ? 
				GraphUtils.getFirstTransmissionDateVestByType(noEventVest) : null;

		LocalDate firstTransmissionVestOrMonarch = null; 
		if( Objects.nonNull(firstTransmissionDateVest) && Objects.nonNull(firstTransmissionDateMonarch)){
			firstTransmissionVestOrMonarch = firstTransmissionDateVest.isBefore(firstTransmissionDateMonarch) ? 
														firstTransmissionDateVest : firstTransmissionDateMonarch;  
		}else if(Objects.isNull(firstTransmissionDateVest)){
			firstTransmissionVestOrMonarch = firstTransmissionDateMonarch;
		}else{
			firstTransmissionVestOrMonarch = firstTransmissionDateVest;
		}
		
		// For No transmission users , compliance shouldn't be updated until transmission happens		
		if( Objects.isNull(firstTransmissionDateVest) && Objects.isNull(firstTransmissionDateMonarch)){
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(compliance.getScore(), today,
					compliance.getPatient(), compliance.getPatientUser(),compliance.getHmrRunRate(),true,
					false,0);
			newCompliance.setLatestTherapyDate(null);// since no transmission 
			complianceMap.put(userId, newCompliance);
			// HMR Compliance shouldn't be checked for Patients for initial adherence setting days of transmission date
		}else if(Objects.nonNull(firstTransmissionVestOrMonarch) && 
				DateUtil.getDaysCountBetweenLocalDates(firstTransmissionVestOrMonarch, today) < (adherenceSettingDay-1) &&
				adherenceSettingDay > 1 ){
			// For Transmitted users no notification till earlier day of adherence Setting day(s)
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(today,compliance.getPatient(),compliance.getPatientUser(),
					compliance.getHmrRunRate(),compliance.getMissedTherapyCount()+1,compliance.getLatestTherapyDate(),
					Objects.nonNull(compliance.getHmr())? compliance.getHmr():0.0d);
			newCompliance.setScore(compliance.getScore());
			updateGlobalCounters(++globalMissedTherapyCounter,
					globalHMRNonAdherenceCounter,
					globalSettingsDeviationCounter, newCompliance);
			complianceMap.put(userId, newCompliance);
		}else {
			PatientComplianceMonarch newCompliance = new PatientComplianceMonarch(
					today,
					compliance.getPatient(),
					compliance.getPatientUser(),
					compliance.getHmrRunRate(),
					compliance.getMissedTherapyCount()+1,
					compliance.getLatestTherapyDate(),
					Objects.nonNull(compliance.getHmr())? compliance.getHmr():0.0d);
			newCompliance.setScore(compliance.getScore());
			newCompliance.setSettingsDeviatedDaysCount(0);
			// increment global missed therapy counter
			updateGlobalCounters(++globalMissedTherapyCounter,
					globalHMRNonAdherenceCounter,
					globalSettingsDeviationCounter, newCompliance);
			log.debug("Compliance before calc "+newCompliance);
			if(newCompliance.getMissedTherapyCount() >= adherenceSettingDay){ // missed Therapy for adherenceSetting day(s) or more than adherenceSetting day(s) days
				mstNotificationMap.put(compliance.getPatientUser().getId(), newCompliance);
			}else{ // missed therapy for less than adherence setting day(s) , might fall under hmrNonCompliance
				hmrNonComplianceMap.put(compliance.getPatientUser().getId(), newCompliance);
			}
		}
	}
	
	public LocalDate fineOneByPatientUserIdLatestResetStartDate(Long userId){    	
    	List<AdherenceResetMonarch> adherenceReset = adherenceResetMonarchRepository.findOneByPatientUserIdLatestResetStartDate(userId);
    	if(adherenceReset.size() > 0)
    		return adherenceReset.get(0).getResetStartDate();
    	else
    		return null;
    }
	
	// Getting the therapy data for the requested date
	public List<TherapySessionMonarch> getTherapyForDay(SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapySession,LocalDate curDate){		
		return sortedTherapySession.get(curDate);
	}
	
	// Getting the therapy data for the requested between period 
	public List<TherapySessionMonarch> getTherapyforBetweenDates(LocalDate fromDate, LocalDate toDate, SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapySession){
		List<TherapySessionMonarch> session = new LinkedList<>();
		
		List<LocalDate> allDates = DateUtil.getAllLocalDatesBetweenDates(fromDate, toDate);
		
		for(LocalDate date : allDates){
			
			if(Objects.nonNull(sortedTherapySession.get(date)))
				session.addAll(sortedTherapySession.get(date));
		}
		
		return session;
	}
	
	// Getting the compliance object for the previous date / previous record 
	public PatientComplianceMonarch returnPrevDayCompli(List<PatientComplianceMonarch> complianceList, LocalDate currDate){
		
		int j = -1;
		for(int i = 0; i <= (complianceList.size()-1); i++){
			if(complianceList.get(i).getDate() == currDate){				
				j = i;
			}
		}
		return (j > 0 ? complianceList.get(j-1) : null);
	}
	
	// Grouping the therapy data by date 
	public SortedMap<LocalDate,List<TherapySessionMonarch>> groupTherapySessionsByDate(List<TherapySessionMonarch> therapySessions){
		return new TreeMap<>(therapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch :: getDate)));
	}
	
	
	// Grouping the Patient Compliance Monarch data by date 
	public SortedMap<LocalDate,List<PatientComplianceMonarch>> groupPatientComplianceByDate(List<PatientComplianceMonarch> patientComplianceMonarch){
		return new TreeMap<>(patientComplianceMonarch.stream().collect(Collectors.groupingBy(PatientComplianceMonarch :: getDate)));
	}
		
	private PatientComplianceMonarch setPrevDayCompliance(PatientComplianceMonarch currentCompliance, Long userId, PatientComplianceMonarch preDayCompliance)
	{
		// Commented the repository call and getting the previous day compliance from the method parameter
		
		
		currentCompliance.setGlobalHMRNonAdherenceCounter(preDayCompliance.getGlobalHMRNonAdherenceCounter());
		currentCompliance.setGlobalMissedTherapyCounter(preDayCompliance.getGlobalMissedTherapyCounter());
		currentCompliance.setGlobalSettingsDeviationCounter(preDayCompliance.getGlobalSettingsDeviationCounter());
		currentCompliance.setHmr(preDayCompliance.getHmr());
		currentCompliance.setHmrCompliant(preDayCompliance.isHmrCompliant());
		currentCompliance.setHmrRunRate(preDayCompliance.getHmrRunRate());
		currentCompliance.setLatestTherapyDate(preDayCompliance.getLatestTherapyDate());
		currentCompliance.setMissedTherapyCount(preDayCompliance.getMissedTherapyCount());
		currentCompliance.setScore(preDayCompliance.getScore());
		currentCompliance.setSettingsDeviated(preDayCompliance.isSettingsDeviated());
		currentCompliance.setSettingsDeviatedDaysCount(preDayCompliance.getSettingsDeviatedDaysCount());
		
		
		return currentCompliance;
		
	}
	
	private void updateGlobalCounters(int globalMissedTherapyCounter,
			int globalHMRNonAdherenceCounter,
			int globalSettingsDeviationCounter, PatientComplianceMonarch newCompliance) {
		newCompliance.setGlobalMissedTherapyCounter(globalMissedTherapyCounter);
		newCompliance.setGlobalHMRNonAdherenceCounter(globalHMRNonAdherenceCounter);
		newCompliance.setGlobalSettingsDeviationCounter(globalSettingsDeviationCounter);
	}

	// Create or Update Adherence Score on Missed Therapy day
	private void updateComplianceForMST(LocalDate today,
			Map<Long, PatientComplianceMonarch> complianceMap) {
		Map<Long,List<PatientComplianceMonarch>> existingCompliances = complianceMonarchService.getPatientComplainceMapByPatientUserId(new LinkedList<>(complianceMap.keySet()),today,today);
		if(existingCompliances.isEmpty()){
			complianceMonarchService.saveAll(complianceMap.values());
		}else{
			for(Long puId : existingCompliances.keySet()){
				List<PatientComplianceMonarch> complianceForDay = existingCompliances.get(puId);
				if(complianceForDay.size() > 0){
					PatientComplianceMonarch existingCompliance = complianceForDay.get(0);
					PatientComplianceMonarch currentCompliance = complianceMap.get(puId);
					existingCompliance.setScore(currentCompliance.getScore());
					existingCompliance.setHmr(currentCompliance.getHmr());
					existingCompliance.setHmrRunRate(currentCompliance.getHmrRunRate());
					existingCompliance.setHmrCompliant(currentCompliance.isHmrCompliant());
					existingCompliance.setLatestTherapyDate(currentCompliance.getLatestTherapyDate());
					existingCompliance.setMissedTherapyCount(currentCompliance.getMissedTherapyCount());
					updateGlobalCounters(currentCompliance.getGlobalMissedTherapyCounter(), currentCompliance.getGlobalHMRNonAdherenceCounter(),currentCompliance.getGlobalSettingsDeviationCounter(), existingCompliance);
					complianceMap.put(puId, existingCompliance);
				} 
			}
			complianceMonarchService.saveAll(complianceMap.values());
		}
	}

	// Create or Update notifications on Missed Therapy
	private void updateNotificationsOnMST(LocalDate today,
			Map<Long, NotificationMonarch> notificationMap) {
		Map<Long,List<NotificationMonarch>> existingNotifications = notificationMonarchService.getNotificationMapByPatientIdsAndDate(new LinkedList<>(notificationMap.keySet()), today, today);
		if(existingNotifications.isEmpty()){
			notificationMonarchService.saveAll(notificationMap.values());
		}else{
			for(Long puId : existingNotifications.keySet()){
				List<NotificationMonarch> notificationsforDay = existingNotifications.get(puId);
				if(notificationsforDay.size() > 0){
					NotificationMonarch existingNotification = notificationsforDay.get(0);
					NotificationMonarch currentNotification = notificationMap.get(puId);
					existingNotification.setNotificationType(currentNotification.getNotificationType());
					notificationMap.put(puId, existingNotification);
				} 
			}
			notificationMonarchService.saveAll(notificationMap.values());
		}
	}

	// calculate missed therapies and points
	private void calculateMissedTherapy(LocalDate today,
			Map<Long, PatientComplianceMonarch> mstNotificationMap,
			Map<Long, PatientComplianceMonarch> hmrNonComplianceMap,
			Map<Long, PatientComplianceMonarch> complianceMap,
			Map<Long, NotificationMonarch> notificationMap) {
		for(Long patientUserId : mstNotificationMap.keySet()){
			PatientComplianceMonarch newCompliance = mstNotificationMap.get(patientUserId);
			int score = newCompliance.getScore();
			score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;
			notificationMap.put(patientUserId, new NotificationMonarch(MISSED_THERAPY,today,newCompliance.getPatientUser(), newCompliance.getPatient(),false,HMR_NON_COMPLIANCE));
			newCompliance.setHmrCompliant(false);
			newCompliance.setScore(score);
			newCompliance.setHmrRunRate(0);
			complianceMap.put(patientUserId, newCompliance);
		}
	}

	// calculate HMRCompliance on Missed Therapy Date
	private void calculateHMRComplianceForMST(LocalDate today,
			Map<Long, PatientComplianceMonarch> hmrNonComplianceMap,
			Map<Long, ProtocolConstantsMonarch> userProtocolConstantsMap,
			Map<Long, PatientComplianceMonarch> complianceMap,
			Map<Long, NotificationMonarch> notificationMap) {
		for(Long patientUserId : hmrNonComplianceMap.keySet()){
			PatientComplianceMonarch newCompliance = hmrNonComplianceMap.get(patientUserId);
			
			int score = newCompliance.getScore();
			int adherenceSettingDay = getAdherenceSettingForUserId(patientUserId);
			List<TherapySessionMonarch> therapySessions = getLastSettingDaysTherapiesForUserId(patientUserId,getPlusOrMinusTodayLocalDate(-(adherenceSettingDay-1)),today); 
			
			if(Objects.isNull(therapySessions)){
				therapySessions = new LinkedList<>();
			}
			
			int hmrRunRate = calculateHMRRunRatePerSession(therapySessions);
			newCompliance.setHmrRunRate(hmrRunRate);
			double durationForSettingDays = hmrRunRate*therapySessions.size(); // runrate*totalsessions = total duration
			ProtocolConstantsMonarch protocolConstant = userProtocolConstantsMap.get(patientUserId);

			String complianceType="";
			if(!isHMRCompliant(protocolConstant, durationForSettingDays, adherenceSettingDay)){
				score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;
				newCompliance.setHmrCompliant(false);
				complianceType=HMR_NON_COMPLIANCE;
				// increment HMR Non Adherence Counter
				/*int globalHMRNonAdherenceCounter = newCompliance.getGlobalHMRNonAdherenceCounter();
				newCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);*/
				notificationMap.put(patientUserId, new NotificationMonarch(HMR_NON_COMPLIANCE,today,newCompliance.getPatientUser(), newCompliance.getPatient(),false,complianceType));
			}else if (StringUtils.isBlank(complianceType)){
				score = score <=  DEFAULT_COMPLIANCE_SCORE - BONUS_POINTS ? score + BONUS_POINTS : DEFAULT_COMPLIANCE_SCORE;
				newCompliance.setHmrCompliant(true);
			}
			newCompliance.setScore(score);
			// reset settings deviated count and flag on missed therapy
			newCompliance.setSettingsDeviatedDaysCount(0);
			newCompliance.setSettingsDeviated(false);
			complianceMap.put(patientUserId, newCompliance);
		}
	}
	
	// calculate HMRCompliance on Missed Therapy Date
		private void calculateHMRComplianceForMSTBoth(LocalDate today,
				Map<Long, PatientComplianceMonarch> hmrNonComplianceMap,
				Map<Long, ProtocolConstantsMonarch> userProtocolConstantsMap,
				Map<Long, ProtocolConstants> userProtocolConstantsVestMap,
				Map<Long, PatientComplianceMonarch> complianceMap,
				Map<Long, NotificationMonarch> notificationMap) {
			
			for(Long patientUserId : hmrNonComplianceMap.keySet()){
				
				PatientComplianceMonarch newCompliance = hmrNonComplianceMap.get(patientUserId);
				
				int score = newCompliance.getScore();
				int adherenceSettingDay = getAdherenceSettingForUserId(patientUserId);
				List<TherapySessionMonarch> therapySessions = getLastSettingDaysTherapiesForUserId(patientUserId,getPlusOrMinusTodayLocalDate(-(adherenceSettingDay-1)),today); 
				
				List<TherapySession> therapySessionsVest = adherenceCalculationService.getLastSettingDaysTherapiesForUserId(patientUserId,getPlusOrMinusTodayLocalDate(-(adherenceSettingDay-1)),today);
				
				if(Objects.isNull(therapySessions)){
					therapySessions = new LinkedList<>();
				}
				
				if(Objects.isNull(therapySessionsVest)){
					therapySessionsVest = new LinkedList<>();
				}
				
				int hmrRunRateVest = calculateHMRRunRatePerSession(therapySessionsVest);
				int hmrRunRateMonarch = calculateHMRRunRatePerSession(therapySessions);
				
				int hmrRunRateBoth = calculateHMRRunRatePerSessionBoth(therapySessions, therapySessionsVest);
				newCompliance.setHmrRunRate(hmrRunRateBoth);
				
				double durationForSettingDaysVest = hmrRunRateVest*therapySessions.size() + hmrRunRateMonarch*therapySessions.size(); // runrate*totalsessions = total duration
				
				ProtocolConstantsMonarch protocolConstant = userProtocolConstantsMap.get(patientUserId);
				ProtocolConstants protocolConstantVest = userProtocolConstantsVestMap.get(patientUserId);


				boolean isHmrCompliant = true; 
				String complianceType="",notificationType="";
				
				if(!therapySessionsVest.isEmpty() || !therapySessions.isEmpty()){
					isHmrCompliant = isHMRCompliant(protocolConstant,protocolConstantVest, durationForSettingDaysVest, adherenceSettingDay);
				}
				
				if(!isHmrCompliant){
					score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;
					newCompliance.setHmrCompliant(false);
					// increment HMR Non Adherence Counter
					/*int globalHMRNonAdherenceCounter = newCompliance.getGlobalHMRNonAdherenceCounter();
					newCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);*/
					
					notificationType = HMR_NON_COMPLIANCE;
					complianceType = HMR_NON_COMPLIANCE;
									
				}else if(StringUtils.isBlank(complianceType)){
					score = score <=  DEFAULT_COMPLIANCE_SCORE - BONUS_POINTS ? score + BONUS_POINTS : DEFAULT_COMPLIANCE_SCORE;
					newCompliance.setHmrCompliant(true);
				}
				newCompliance.setScore(score);
				// reset settings deviated count and flag on missed therapy
				newCompliance.setSettingsDeviatedDaysCount(0);
				newCompliance.setSettingsDeviated(false);
				complianceMap.put(patientUserId, newCompliance);
			}
		}
		
	/**
	 * Get the therapy data between days and user ids
	 * @param patientUserId, from date and to date
	 * @return
	 */
	public List<TherapySessionMonarch> getLastSettingDaysTherapiesForUserId(Long patientUserId,LocalDate from,LocalDate to){
		List<TherapySessionMonarch> therapySessions = therapySessionMonarchRepository.findByDateBetweenAndPatientUserId(from, to, patientUserId);
		return therapySessions;
	}	
	
	/**
	 * Calculate HMRRunRate For PatientUsers
	 * @param patientUserIds
	 * @return
	 */
	public Map<Long,List<TherapySessionMonarch>> getLastSettingDaysTherapiesGroupByUserId(List<Long> patientUserIds,LocalDate from,LocalDate to){
		Map<Long,List<TherapySessionMonarch>> patientUserTherapyMap = new HashMap<>();
		List<TherapySessionMonarch> therapySessions = therapySessionMonarchRepository.findByDateBetweenAndPatientUserIdIn(from, to, patientUserIds);
		Map<User,List<TherapySessionMonarch>> therapySessionsPerPatient = therapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch::getPatientUser));
		for(User patientUser : therapySessionsPerPatient.keySet()){
			List<TherapySessionMonarch> sessions = therapySessionsPerPatient.get(patientUser);
			patientUserTherapyMap.put(patientUser.getId(), sessions);
		}
		return patientUserTherapyMap;
	}
	
	public void processPatientNotificationsMonarchImpl(){
		LocalDate yesterday = LocalDate.now().minusDays(1);
		LocalDate weekTime = LocalDate.now().minusDays(7);
		Set<User> patientEmailSent = new HashSet<User>();
		
		List<NotificationMonarch> notifications = notificationMonarchRepository.findByDate(yesterday);
		if(notifications.size() > 0){
			
			List<Long> patientUserIds = new LinkedList<>();
			for(NotificationMonarch notification : notifications){
				
				patientUserIds.add(notification.getPatientUser().getId());
			}
			
			List<PatientComplianceMonarch> complianceList = patientComplianceMonarchRepository.findByDateBetweenAndPatientUserIdIn(yesterday,
					yesterday,patientUserIds);
			Map<User,Integer> complianceMap = new HashMap<>();
			for(PatientComplianceMonarch compliance : complianceList){
				complianceMap.put(compliance.getPatientUser(), compliance.getMissedTherapyCount());
			}
			try{
					List<NotificationMonarch> existingNotifications = notificationMonarchRepository.findByDateBetweenAndIsAcknowledgedAndPatientUserIdIn(weekTime,yesterday,false,patientUserIds);
					existingNotifications.forEach(existingNotification -> {
					User patientUser = existingNotification.getPatientUser();
					if(Objects.nonNull(patientUser.getEmail())){
						// integrated Accepting mail notifications
						String notificationType = existingNotification.getNotificationType();
			//			int missedTherapyCount = complianceMap.get(patientUser);
						if(isPatientUserAcceptNotification(patientUser,
								notificationType) && isPatientUserAcceptNotificationFreq(patientUser, notificationType))
							patientEmailSent.add(patientUser);			
					}
				});	
				
				for(User emailPatient : patientEmailSent) {
					mailService.sendNotificationMailToPatientBasedOnFreq(emailPatient);	
				}
			}catch(Exception ex){
				StringWriter writer = new StringWriter();
				PrintWriter printWriter = new PrintWriter( writer );
				ex.printStackTrace( printWriter );
				mailService.sendJobFailureNotificationMonarch("processPatientNotificationsMonarch",writer.toString());
			}
		}
	}
	
	public boolean isPatientUserAcceptNotificationFreq(User patientUser, String notificationType) {
		return getIsPatientTrueNotification(patientUser,notificationType);
	}
	
	private boolean getIsPatientTrueNotification(User patientUser, String notificationType ) {
		boolean isPatientNotification = false;
		String dayOfWeek = DateUtil.getDayOfTheWeek();

		if (Objects.nonNull(patientUser)) {
			if (Objects.nonNull(patientUser.getMissedTherapyNotificationFreq())){
				if(notificationType.equals(MISSED_THERAPY) && (patientUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(DAILY))) {
					isPatientNotification = true; }
				}
		   else if (Objects.nonNull(patientUser.getNonHMRNotificationFreq())) {
			    if(notificationType.equals(HMR_NON_COMPLIANCE) && (patientUser.getNonHMRNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getNonHMRNotificationFreq().equalsIgnoreCase(DAILY))) {
			    		isPatientNotification = true;}		
			    }
		 else if (Objects.nonNull(patientUser.getSettingDeviationNotificationFreq())){
			 	if(notificationType.endsWith(SETTINGS_DEVIATION) && (patientUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(DAILY))) {
							isPatientNotification = true;	}
								}
				}		
		return isPatientNotification;
	}

	private boolean isPatientUserAcceptNotification(User patientUser,
			String notificationType) {
	
		return isNonHMRNotificationCheck(patientUser, notificationType) ||
				isSettingDeviationNotificationCheck(patientUser, notificationType) ||
				(patientUser.isMissedTherapyNotification() && MISSED_THERAPY.equalsIgnoreCase(notificationType)) ||
				isNonHMRSettingDeviationNotificationCheck(patientUser, notificationType); 
			}
	
	
	private boolean isNonHMRNotificationCheck(User patientUser,
			String notificationType){
		return patientUser.isNonHMRNotification() && 
					(HMR_NON_COMPLIANCE.equalsIgnoreCase(notificationType) ||
					HMR_NON_COMPLIANCE_VEST.equalsIgnoreCase(notificationType) ||
					HMR_NON_COMPLIANCE_MONARCH.equalsIgnoreCase(notificationType)); 
	}
	
	private boolean isSettingDeviationNotificationCheck(User patientUser,
			String notificationType){
		return patientUser.isSettingDeviationNotification() && 
					(SETTINGS_DEVIATION.equalsIgnoreCase(notificationType) ||
					SETTINGS_DEVIATION_VEST.equalsIgnoreCase(notificationType) ||
					SETTINGS_DEVIATION_MONARCH.equalsIgnoreCase(notificationType)); 
	}
	
	private boolean isNonHMRSettingDeviationNotificationCheck(User patientUser,
			String notificationType){
		return (HMR_AND_SETTINGS_DEVIATION.equalsIgnoreCase(notificationType) ||
				
				HMR_AND_SETTINGS_DEVIATION_VEST.equalsIgnoreCase(notificationType) ||
				HMR_AND_SETTINGS_DEVIATION_MONARCH.equalsIgnoreCase(notificationType) ||
				
				HMR_VEST_AND_SETTINGS_DEVIATION.equalsIgnoreCase(notificationType) ||
				HMR_MONARCH_AND_SETTINGS_DEVIATION.equalsIgnoreCase(notificationType) ||
				
				HMR_MONARCH_AND_SETTINGS_DEVIATION_VEST.equalsIgnoreCase(notificationType) ||
				HMR_VEST_AND_SETTINGS_DEVIATION_VEST.equalsIgnoreCase(notificationType) ||
				
				HMR_MONARCH_AND_SETTINGS_DEVIATION_MONARCH.equalsIgnoreCase(notificationType) ||
				HMR_VEST_AND_SETTINGS_DEVIATION_MONARCH.equalsIgnoreCase(notificationType)  &&
				
				(patientUser.isNonHMRNotification() || patientUser.isSettingDeviationNotification()));
				
	}


	public void processHcpClinicAdminNotificationsMonarchImpl() throws HillromException{
		try{
			List<ClinicStatsNotificationVO> statsNotificationVOs = getPatientStatsWithHcpAndClinicAdminAssociation();
			Map<BigInteger, User> idUserMap = getIdUserMapFromPatientStats(statsNotificationVOs);
			Map<String, String> clinicIdNameMap = getClinicIdNameMapFromPatientStats(statsNotificationVOs);
			Map<BigInteger, Map<String, Map<String, Integer>>> adminOrHcpClinicStats = getPatientStatsWithClinicAdminClinicAssociation(statsNotificationVOs);
			

			Map<User, Map<String, Map<String, Integer>>> adminOrHcpClinicStatsMap = getProcessedUserClinicStatsMap(idUserMap,
					clinicIdNameMap, adminOrHcpClinicStats);
			
		
			Set<User> userHcpsOrAdmins = mailServiceNotificationForHcpandAdmin(adminOrHcpClinicStatsMap);

			if (Objects.nonNull(userHcpsOrAdmins)) {
				for (User usrHcpOrAdmin : userHcpsOrAdmins) {

				mailService.sendNotificationMailToHCPAndClinicAdminBasedOnFreq(usrHcpOrAdmin);
				}
			}	
			
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("processHcpClinicAdminNotificationsMonarch",writer.toString());
		}
	}
	
	public void processCareGiverNotificationsMonarchImpl() throws HillromException{
		try{
			List<CareGiverStatsNotificationVO> statsNotificationVOs = findPatientStatisticsCareGiver();

			Map<String,CareGiverStatsNotificationVO> cgIdNameMap = new HashMap<>();
			
			Map<String,List<PatientStatsVO>> cgIdPatientStatsMap = new HashMap<>();
			
			for(CareGiverStatsNotificationVO statsNotificationVO : statsNotificationVOs){
				cgIdNameMap.put(statsNotificationVO.getCGEmail(), statsNotificationVO);
				BigInteger patientUserId = statsNotificationVO.getPatientUserid();
				String pFirstName = statsNotificationVO.getPatientFirstname();
				String pLastName = statsNotificationVO.getPatientLastname();
				int missedTherapyCount = statsNotificationVO.getMissedTherapyCount();
				boolean isSettingsDeviated = statsNotificationVO.isSettingsDeviated();
				boolean isHMRCompliant = statsNotificationVO.isHMRCompliant();
				
				List<PatientStatsVO> patientStatsList = cgIdPatientStatsMap.get(statsNotificationVO.getCGEmail());
				if(Objects.isNull(patientStatsList))
					patientStatsList = new LinkedList<>();
				patientStatsList.add(new PatientStatsVO(patientUserId, pFirstName, pLastName, missedTherapyCount, isSettingsDeviated, isHMRCompliant));
				cgIdPatientStatsMap.put(statsNotificationVO.getCGEmail(), patientStatsList);
			}
			
			for(CareGiverStatsNotificationVO careGiverStatsNotificationFreqStatus : careGiverStatsNotificationFreq(cgIdNameMap)){
				mailService.sendNotificationCareGiverBasedOnFreq(careGiverStatsNotificationFreqStatus); 
			}			
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("processHcpClinicAdminNotificationsMonarch",writer.toString());
		}
	}
	
	public static boolean careGiverStatsNotification(Map<String,CareGiverStatsNotificationVO> cgIdNameMap){

		for(String cgEmail : cgIdNameMap.keySet()){
			CareGiverStatsNotificationVO careGiverStatsNotificationVO = cgIdNameMap.get(cgEmail);
			return(careGiverStatsNotificationVO.getIsHcpAcceptHMRNotification()|
					careGiverStatsNotificationVO.getIsHcpAcceptSettingsNotification()|
					careGiverStatsNotificationVO.getIsHcpAcceptTherapyNotification());
		}
		return false;
	}
	
	public static Set<CareGiverStatsNotificationVO> careGiverStatsNotificationFreq(Map<String,CareGiverStatsNotificationVO> cgIdNameMap){
		
		String dayOfWeek = DateUtil.getDayOfTheWeek();
		Set<CareGiverStatsNotificationVO> userCGList = new HashSet<CareGiverStatsNotificationVO>();

		if(Objects.nonNull(cgIdNameMap)){
			for(String cgEmail : cgIdNameMap.keySet()){
				CareGiverStatsNotificationVO careGiverStatsNotificationVO = cgIdNameMap.get(cgEmail);

				if(Objects.nonNull(careGiverStatsNotificationVO.getMissedTherapyNotificationFreq()))
				{
					if(careGiverStatsNotificationVO.getIsHcpAcceptTherapyNotification() && (careGiverStatsNotificationVO.getMissedTherapyCount() > 0)){					
						if(careGiverStatsNotificationVO.getMissedTherapyNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userCGList.add(careGiverStatsNotificationVO);
					}else if(careGiverStatsNotificationVO.getMissedTherapyNotificationFreq().equalsIgnoreCase(DAILY)){
						userCGList.add(careGiverStatsNotificationVO);
					}
				  }
				}
				if(Objects.nonNull(careGiverStatsNotificationVO.getNonHMRNotificationFreq()))
				{
					if(careGiverStatsNotificationVO.getIsHcpAcceptHMRNotification() && (careGiverStatsNotificationVO.isHMRCompliant())){		
					   if(careGiverStatsNotificationVO.getNonHMRNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userCGList.add(careGiverStatsNotificationVO);
					}else if(careGiverStatsNotificationVO.getNonHMRNotificationFreq().equalsIgnoreCase(DAILY)){
						userCGList.add(careGiverStatsNotificationVO);
					}
				  }
				}
				if(Objects.nonNull(careGiverStatsNotificationVO.getSettingDeviationNotificationFreq()))
				{
					if(careGiverStatsNotificationVO.getIsHcpAcceptSettingsNotification() && (careGiverStatsNotificationVO.isSettingsDeviated())){
						if(careGiverStatsNotificationVO.getSettingDeviationNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userCGList.add(careGiverStatsNotificationVO);
					}else if(careGiverStatsNotificationVO.getSettingDeviationNotificationFreq().equalsIgnoreCase(DAILY)){
						userCGList.add(careGiverStatsNotificationVO);
					}
				  }
				}

			}
			return userCGList;
		}
		return null;
	}	
	
   public static Set<User> mailServiceNotificationForHcpandAdmin(Map<User, Map<String, Map<String, Integer>>> hcpOrAdminClinicStatsMap){
		
		String dayOfWeek = DateUtil.getDayOfTheWeek();
		Set<User> userList = new HashSet<User>();
		if(Objects.nonNull(hcpOrAdminClinicStatsMap)){
			for(User hcpOrAdminUser : hcpOrAdminClinicStatsMap.keySet()){
				if(Objects.nonNull(hcpOrAdminUser.getMissedTherapyNotificationFreq()))
				{
					if(hcpOrAdminUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userList.add(hcpOrAdminUser);
					}else if(hcpOrAdminUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(DAILY)){
						userList.add(hcpOrAdminUser);
					}
				}
				if(Objects.nonNull(hcpOrAdminUser.getNonHMRNotificationFreq()))
				{
					if(hcpOrAdminUser.getNonHMRNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userList.add(hcpOrAdminUser);
					}else if(hcpOrAdminUser.getNonHMRNotificationFreq().equalsIgnoreCase(DAILY)){
						userList.add(hcpOrAdminUser);
					}
				}
				if(Objects.nonNull(hcpOrAdminUser.getSettingDeviationNotificationFreq()))
				{
					if(hcpOrAdminUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(dayOfWeek)){
						userList.add(hcpOrAdminUser);
					}else if(hcpOrAdminUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(DAILY)){
						userList.add(hcpOrAdminUser);
					}
				}

			}
			return userList;
		}
		return null;
		
	}


	public static List<User> mailServiceNotificationForHcpandAdminDaily(Map<User, Map<String, Map<String, Integer>>> hcpOrAdminClinicStatsMap){
	List<User> UserList = null;
	if(Objects.nonNull(hcpOrAdminClinicStatsMap)){
		for(User hcpOrAdminUser : hcpOrAdminClinicStatsMap.keySet()){
			if(Objects.nonNull(hcpOrAdminUser.getMissedTherapyNotificationFreq()))
			{
				if(hcpOrAdminUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(DAILY)){
					UserList.add(hcpOrAdminUser);
				}
			}
			if(Objects.nonNull(hcpOrAdminUser.getNonHMRNotificationFreq()))
			{
				if(hcpOrAdminUser.getNonHMRNotificationFreq().equalsIgnoreCase(DAILY)){
					UserList.add(hcpOrAdminUser);
				}
			}
			if(Objects.nonNull(hcpOrAdminUser.getSettingDeviationNotificationFreq()))
			{
				if(hcpOrAdminUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(DAILY)){
					UserList.add(hcpOrAdminUser);
				}
			}
			
		}
		return UserList;
	}
	return null;
	
}

	private Map<User, Map<String, Map<String, Integer>>> getProcessedUserClinicStatsMap(
			Map<BigInteger, User> idUserMap,
			Map<String, String> clinicIdNameMap,
			Map<BigInteger, Map<String, Map<String, Integer>>> userClinicStats
			) {
		int settingsDeviatedPatients =0; int hmrNonCompliantPatients =0; int missedTherapyPatients=0;
		Map<User, Map<String, Map<String, Integer>>> userClinicStatsMap = new HashMap<>();
		for(BigInteger userId: userClinicStats.keySet()){
			User user = idUserMap.get(userId);
			Map<String,Map<String,Integer>> clinicidStats =  userClinicStats.get(userId);
			for(String clinicId : clinicidStats.keySet()){
				String clinicName = clinicIdNameMap.get(clinicId);
				Map<String,Integer> stats = clinicidStats.get(clinicId);
				if(Objects.nonNull(user.isMissedTherapyNotification()) && user.isMissedTherapyNotification()){
					missedTherapyPatients = Objects.nonNull(stats.get("patientsWithMissedTherapy"))?
						stats.get("patientsWithMissedTherapy"):0;
				}
				if(Objects.nonNull(user.isSettingDeviationNotification()) && user.isSettingDeviationNotification()){					
				    settingsDeviatedPatients = Objects.nonNull(stats.get("patientsWithSettingDeviation"))?
						stats.get("patientsWithSettingDeviation"):0;
				}
				if(Objects.nonNull(user.isNonHMRNotification()) && user.isNonHMRNotification()){
					hmrNonCompliantPatients = Objects.nonNull(stats.get("patientsWithHmrNonCompliance"))?
						stats.get("patientsWithHmrNonCompliance"):0;
				}
				if(missedTherapyPatients > 0 || settingsDeviatedPatients > 0
						|| hmrNonCompliantPatients > 0){
					Map<String,Map<String,Integer>> clinicNameStatsMap = new HashMap<>();
					clinicNameStatsMap.put(clinicName, stats);
					userClinicStatsMap.put(user, clinicNameStatsMap);
				}
			}
		}
		return userClinicStatsMap;
	}

	private Map<BigInteger, Map<String, Map<String, Integer>>> getPatientStatsWithClinicAdminClinicAssociation(
			List<ClinicStatsNotificationVO> statsNotificationVOs) {
		List<ClinicStatsNotificationVO> statsNotificationVOsForAdmin = statsNotificationVOs.stream().filter(statsNotificationVO -> 
			Objects.nonNull(statsNotificationVO.getHcpIdOrclinicAdminId())
		).collect(Collectors.toList());
		Map<BigInteger,List<ClinicStatsNotificationVO>> adminClinicStatsMap = statsNotificationVOsForAdmin.stream()
				.collect(Collectors.groupingBy(ClinicStatsNotificationVO :: getHcpIdOrclinicAdminId));
		Map<BigInteger,Map<String,Map<String,Integer>>> adminClinicStats = getClinicWiseStatistics(adminClinicStatsMap,statsNotificationVOsForAdmin);
		return adminClinicStats;
	}

	private Map<String, String> getClinicIdNameMapFromPatientStats(
			List<ClinicStatsNotificationVO> statsNotificationVOs) {
		Map<String,String> clinicIdNameMap = new HashMap<>();
		for(ClinicStatsNotificationVO statsNotificationVO : statsNotificationVOs){
			clinicIdNameMap.put(statsNotificationVO.getClinicId(), statsNotificationVO.getClinicName());
		}
		return clinicIdNameMap;
	}

	private Map<BigInteger, User> getIdUserMapFromPatientStats(
			List<ClinicStatsNotificationVO> statsNotificationVOs) {
		Map<BigInteger,User> idUserMap = new HashMap<>();
		for(ClinicStatsNotificationVO statsNotificationVO : statsNotificationVOs){
			idUserMap.put(statsNotificationVO.getHcpIdOrclinicAdminId(),new User(statsNotificationVO.getHcpFirstnameOrCaFirstname(),
					statsNotificationVO.getHcpLastnameOrCaLastname(),statsNotificationVO.getHcpEmailOrCaEmail(),
					statsNotificationVO.isHcpOrIsCAAcceptTherapyNotification(),statsNotificationVO.isHcpOrIsCAAcceptHMRNotification(),
					statsNotificationVO.isHcpOrIsCAAcceptSettingsNotification(),statsNotificationVO.getNonHmrNotificationFreq(),
					statsNotificationVO.getMissedTherapyNotificationFreq(),statsNotificationVO.getSettingDeviationNotificationFreq()));
			
		}
		return idUserMap;
	}

	private List<ClinicStatsNotificationVO> getPatientStatsWithHcpAndClinicAdminAssociation() {
		List<Object[]> results =  clinicMonarchRepository.findPatientStatisticsClinicForActiveClinics();
		List<ClinicStatsNotificationVO> statsNotificationVOs = new LinkedList<>();
		for(Object[] result : results){			
			Integer adherenceSetting = DEFAULT_SETTINGS_DEVIATION_COUNT;
			if(Objects.nonNull(result[19])){
				adherenceSetting = (Integer)result[19];
			}			
			statsNotificationVOs.add(new ClinicStatsNotificationVO((BigInteger)result[1],
					(String)result[2],(String)result[3],(BigInteger)result[4],(String)result[5],
					(String)result[6],(String)result[7],(Integer)result[9],(Boolean)result[10], (Boolean)result[11],
					(Boolean)result[12],(Boolean)result[13],(Boolean)result[14], (String)result[15],
					(String)result[16],(String)result[17],(String)result[18],
					adherenceSetting));
			}
		return statsNotificationVOs;
	}
	private List<CareGiverStatsNotificationVO> findPatientStatisticsCareGiver() {
		List<Object[]> results =  clinicMonarchRepository.findPatientStatisticsCareGiverDetails();
		List<CareGiverStatsNotificationVO> statsNotificationVOs = new LinkedList<>();
		for(Object[] result : results){
			statsNotificationVOs.add(new CareGiverStatsNotificationVO((BigInteger)result[0], (String) result[1], (String)result[2],
					(BigInteger)result[3],(String)result[4], (Integer)result[5],
					(Boolean)result[6], (Boolean)result[7], (String)result[8],
					(Boolean)result[9], (Boolean)result[10], (Boolean)result[11],
					(String)result[12], (String)result[13], (String)result[14]));
		}		
		return statsNotificationVOs;
	}

	private Map<BigInteger,Map<String,Map<String,Integer>>> getClinicWiseStatistics(
			Map<BigInteger,List<ClinicStatsNotificationVO>> userClinicStatsMap,
			List<ClinicStatsNotificationVO> statsNotificationVOs) {
		Map<BigInteger,Map<String,Map<String,Integer>>> userClinicStats = new HashMap<>();
		for(BigInteger userId : userClinicStatsMap.keySet()){
			List<ClinicStatsNotificationVO> clinicStatsNVO = userClinicStatsMap.get(userId);
			Map<String,Map<String,Integer>> clinicWiseStats = userClinicStats.get(userId);
			for(ClinicStatsNotificationVO cNotificationVO : clinicStatsNVO){
				if(Objects.isNull(clinicWiseStats))
					clinicWiseStats = new HashMap<>();
				Map<String,Integer> stats = clinicWiseStats.get(cNotificationVO.getClinicId());
				if(Objects.isNull(stats))
					stats = new HashMap<>();
				int missedTherapyPatients = Objects.isNull(stats
						.get("patientsWithMissedTherapy")) ? 0 : stats
						.get("patientsWithMissedTherapy");
				int settingsDeviatedPatients = Objects.isNull(stats
						.get("patientsWithSettingDeviation")) ? 0 : stats
						.get("patientsWithSettingDeviation");
				int hmrNonCompliantPatients = Objects.isNull(stats
						.get("patientsWithHmrNonCompliance")) ? 0 : stats
						.get("patientsWithHmrNonCompliance");
				if(!cNotificationVO.isHMRCompliant())
					hmrNonCompliantPatients++;
				if(cNotificationVO.isSettingsDeviated())
					settingsDeviatedPatients++;
				if(cNotificationVO.getMissedTherapyCount() >= DEFAULT_MISSED_THERAPY_DAYS_COUNT)
					missedTherapyPatients++;
				
				stats.put("patientsWithMissedTherapy", missedTherapyPatients);
				stats.put("patientsWithSettingDeviation", settingsDeviatedPatients);
				stats.put("patientsWithHmrNonCompliance", hmrNonCompliantPatients);
				clinicWiseStats.put(cNotificationVO.getClinicId(), stats);
			}
			userClinicStats.put(userId, clinicWiseStats);
		}
		return userClinicStats;
	}

	public synchronized void saveOrUpdateComplianceMap(
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap) {
		// Save or update all compliance
		List<PatientComplianceMonarch> compliances = new LinkedList<>(existingComplianceMap.values());
		Long patientUserId = compliances.get(0).getPatientUser().getId();
		SortedMap<LocalDate, PatientComplianceMonarch>  complainceMapFromDB = complianceMonarchService.getPatientComplainceMapByPatientUserId(patientUserId);
		for(LocalDate date: existingComplianceMap.keySet()){
			//	complianceService.createOrUpdate(existingComplianceMap.get(date));
			PatientComplianceMonarch existingCompliance = complainceMapFromDB.get(date);
			PatientComplianceMonarch newCompliance = existingComplianceMap.get(date);
			if(Objects.nonNull(existingCompliance)){
				newCompliance.setId(existingCompliance.getId());
				existingComplianceMap.put(date,newCompliance);
			}	
		}
		complianceMonarchService.saveAll(existingComplianceMap.values());
	}

	public PatientComplianceMonarch getLatestCompliance(User patientUser,
			PatientInfo patient,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap,
			LocalDate therapyDate) throws Exception {
			SortedMap<LocalDate,PatientComplianceMonarch> mostRecentComplianceMap = existingComplianceMap.headMap(therapyDate);
			PatientComplianceMonarch latestCompliance = null;
			if(mostRecentComplianceMap.size() > 0){
				latestCompliance = mostRecentComplianceMap.get(mostRecentComplianceMap.lastKey());
				return buildPatientCompliance(therapyDate, latestCompliance,latestCompliance.getMissedTherapyCount());
			}else{
				return new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE, therapyDate,
						patient, patientUser,0,true,false,0d);
			}
	}
	
	public LocalDate getLatestTransmissionDate(
			SortedMap<LocalDate, List<TherapySession>> existingTherapySessionMapVest,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMapMonarch,
			LocalDate date) throws Exception{
		LocalDate lastTransmissionDateVest = null;
		LocalDate lastTransmissionDateMonarch = null;
		
		// Get Latest TransmissionDate for Monarch, if data has not been transmitted for the day get mostRecent date
		if(existingTherapySessionMapMonarch.size()>0) {
			if(Objects.isNull(existingTherapySessionMapMonarch.get(date))){
				SortedMap<LocalDate,List<TherapySessionMonarch>> mostRecentTherapySessionMap = existingTherapySessionMapMonarch.headMap(date);
				if(mostRecentTherapySessionMap.size()>0)
					lastTransmissionDateMonarch = mostRecentTherapySessionMap.lastKey();
			}else {
				lastTransmissionDateMonarch = date;
			}
		}
		
		// Get Latest TransmissionDate for Vest, if data has not been transmitted for the day get mostRecent date
		if(existingTherapySessionMapVest.size()>0) {
			if(Objects.isNull(existingTherapySessionMapVest.get(date))){
				SortedMap<LocalDate,List<TherapySession>> mostRecentTherapySessionMap = existingTherapySessionMapVest.headMap(date);
				if(mostRecentTherapySessionMap.size()>0)
					lastTransmissionDateVest = mostRecentTherapySessionMap.lastKey();
			}else {
				lastTransmissionDateVest = date;
			}
		}
		
		LocalDate lastTransmissionDate = null;
		
		if(Objects.nonNull(lastTransmissionDateVest)) {
			if(Objects.nonNull(lastTransmissionDateMonarch)) {
				lastTransmissionDate = lastTransmissionDateMonarch.isAfter(lastTransmissionDateVest) ? lastTransmissionDateMonarch : lastTransmissionDateVest;
			}
			else {
				lastTransmissionDate = lastTransmissionDateVest;
			}
		}else if(Objects.nonNull(lastTransmissionDateMonarch)) {
			lastTransmissionDate = lastTransmissionDateMonarch;
		}
		return lastTransmissionDate;
//		return (lastTransmissionDateMonarch.isAfter(lastTransmissionDateVest) ? lastTransmissionDateMonarch : lastTransmissionDateVest);
	}

	private PatientComplianceMonarch buildPatientCompliance(LocalDate date,
			PatientComplianceMonarch latestcompliance,int missedTherapyCount) {
		PatientComplianceMonarch compliance = new PatientComplianceMonarch();
		compliance.setDate(date);
		compliance.setPatient(latestcompliance.getPatient());
		compliance.setPatientUser(latestcompliance.getPatientUser());
		compliance.setScore(latestcompliance.getScore());
		compliance.setHmr(latestcompliance.getHmr());
		compliance.setHmrRunRate(latestcompliance.getHmrRunRate());
		compliance.setSettingsDeviated(latestcompliance.isSettingsDeviated());
		compliance.setMissedTherapyCount(missedTherapyCount);
		compliance.setHmrCompliant(latestcompliance.isHmrCompliant());
		compliance.setLatestTherapyDate(latestcompliance.getLatestTherapyDate());
		compliance.setSettingsDeviatedDaysCount(latestcompliance.getSettingsDeviatedDaysCount());
		updateGlobalCounters(latestcompliance.getGlobalMissedTherapyCounter(), latestcompliance.getGlobalHMRNonAdherenceCounter(), latestcompliance.getGlobalSettingsDeviationCounter(), compliance);
		return compliance;
	}

	public void applySettingsDeviatedDaysCount(
			PatientComplianceMonarch latestCompliance,
			SortedMap<LocalDate, PatientComplianceMonarch> complianceMap,
			boolean isSettingsDeviated, Integer adherenceSettingDay) throws Exception{
		int settingsDeviatedDaysCount;
		if(isSettingsDeviated){
			int previousSettingsDeviatedDaysCount = 0;
			SortedMap<LocalDate,PatientComplianceMonarch> mostRecentComplianceMap = complianceMap.headMap(latestCompliance.getDate());
			if(mostRecentComplianceMap.size() > 0){
				PatientComplianceMonarch previousCompliance = mostRecentComplianceMap.get(mostRecentComplianceMap.lastKey());
				previousSettingsDeviatedDaysCount = previousCompliance.getSettingsDeviatedDaysCount();
			}
			// If settingsDeviationDaysCount is 0 for previous date, settingsDeviationDaysCount would be default value. increments thereafter
			//settingsDeviatedDaysCount =  previousSettingsDeviatedDaysCount == 0 ? adherenceSettingDay :++previousSettingsDeviatedDaysCount;
			settingsDeviatedDaysCount =  ++previousSettingsDeviatedDaysCount;
			latestCompliance.setSettingsDeviatedDaysCount(settingsDeviatedDaysCount);
		}
	} 
	
	public boolean isSettingsDeviatedForSettingDays(List<TherapySessionMonarch> lastSettingDaysTherapySessions,
			ProtocolConstantsMonarch protocol, Integer adherenceSettingDay){
		Map<LocalDate, List<TherapySessionMonarch>> lastSettingDaysTherapySessionMap = lastSettingDaysTherapySessions
				.stream().collect(
						Collectors.groupingBy(TherapySessionMonarch::getDate));
		boolean isSettingsDeviated = false;
		// This is for checking settings deviation, settings deviation should be calculated for consecutive adherence setting days
		//(exclusive missed therapy)
		if(lastSettingDaysTherapySessionMap.keySet().size() == adherenceSettingDay){
			for(LocalDate d : lastSettingDaysTherapySessionMap.keySet()){
				List<TherapySessionMonarch> therapySeesionsPerDay = lastSettingDaysTherapySessionMap.get(d);
				double weightedFrequency = calculateTherapyMetricsPerSettingDays(therapySeesionsPerDay).get(WEIGHTED_AVG_FREQUENCY);
				if(!isSettingsDeviated(protocol, weightedFrequency)){
					isSettingsDeviated = false;
					break;
				}else{
					isSettingsDeviated = true;
				}
			}
		}else{
			return false;
		}
		return isSettingsDeviated;
	}

	
	private Integer getAdherenceSettingForPatient(PatientInfo patient){		
		Clinic clinic = clinicPatientService.getAssociatedClinic(patient);
		if(Objects.nonNull(clinic))
			return clinic.getAdherenceSetting();
		else
			return ADHERENCE_SETTING_DEFAULT_DAYS;
	}
	
	private Integer getAdherenceSettingForUserId(Long patientUserId){
		PatientInfo patient = userService.getPatientInfoObjFromPatientUserId(patientUserId);		
		return getAdherenceSettingForPatient(patient);		
	}
	
	
	// To get the notification object for the specific notification date
	public PatientComplianceMonarch getComplianceForDay(List<PatientComplianceMonarch> complianceMonarchList, LocalDate reqDate) {
		List<PatientComplianceMonarch> complianceMonarchFilter = complianceMonarchList.stream().filter(PatientComplianceMonarch->PatientComplianceMonarch.getDate().equals(reqDate)).collect(Collectors.toList());
		if(!complianceMonarchFilter.isEmpty())
			return complianceMonarchFilter.get(0);
		else
			return null;
	}
}
