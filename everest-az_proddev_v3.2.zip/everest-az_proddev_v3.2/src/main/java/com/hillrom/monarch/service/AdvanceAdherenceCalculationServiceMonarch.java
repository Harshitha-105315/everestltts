package com.hillrom.monarch.service;

import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.config.AdherenceScoreConstants.HMR_NON_COMPLIANCE_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.LOWER_BOUND_VALUE;
import static com.hillrom.vest.config.AdherenceScoreConstants.MISSED_THERAPY_DAYS_COUNT_THRESHOLD;
import static com.hillrom.vest.config.NotificationTypeConstants.ADHERENCE_SCORE_RESET;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE;
import static com.hillrom.vest.config.NotificationTypeConstants.MISSED_THERAPY;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.repository.AdherenceResetMonarchRepository;
import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.monarch.repository.PatientNoEventsMonarchRepository;
import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.repository.ProtocolConstantsMonarchRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.AdherenceResetMonarch;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.repository.PatientComplianceRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientNoEventsRepository;
import com.hillrom.vest.service.AdvanceAdherenceCalculationService;
import com.hillrom.vest.service.MissTherapySettingDeviationNotifier;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;


@Service
@Transactional
public class AdvanceAdherenceCalculationServiceMonarch {

	@Inject 
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject 
	private TherapySessionMonarchRepository therapySessionMonarchRepository;

	@Inject 
	private PatientComplianceMonarchRepository complianceMonarchRepository;

	@Inject
	private AdvanceAdherenceCalculationService advanceAdherenceCalculationService;

	@Inject
	private NotificationMonarchService notificationServiceMonarch;

	@Inject
	private PatientNoEventsMonarchRepository patientNoEventMonarchRepository;

	@Inject
	private PatientNoEventMonarchService noEventMonarchService;

	@Inject
	private PatientNoEventsRepository patientNoEventRepository;

	@Inject
	private PatientComplianceRepository complianceRepository;

	@Inject
	private ProtocolConstantsMonarchRepository protocolConstantsMonarchRepository;

	@Inject
	private PatientProtocolMonarchRepository patientProtocolMonarchRepository;

	@Inject
	private PatientProtocolMonarchService patientProtocolMonarchService;
	
	@Inject
	private AdherenceResetMonarchRepository adherenceResetMonarchRepository;
	
	@Inject
	private MissTherapySettingDeviationNotifier missTherapySettingDeviationNotifier;
	
	@Inject
	@Lazy
	private TherapySessionServiceMonarch therapySessionMonarchService;
	
	@Inject
	private UserService userService;
	
	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	public List<TherapySessionMonarch> saveOrUpdate(List<TherapySessionMonarch> therapySessions) throws Exception{

		if(therapySessions.size() > 0){		
			LocalDate minTherapySessionDate = null;
			LocalDate maxTherapySessiondate = LocalDate.now();
			User patientUser = therapySessions.get(0).getPatientUser();
			PatientInfo patient = therapySessions.get(0).getPatientInfo();
			boolean resetFlag = false;
			LocalDate resetDate = null;
			Map<LocalDate, List<TherapySessionMonarch>> groupedTherapySessions = therapySessions
					.stream()
					.collect(
							Collectors
							.groupingBy(TherapySessionMonarch::getDate));

			SortedMap<LocalDate,List<TherapySessionMonarch>> receivedTherapySessionMap = new TreeMap<>(groupedTherapySessions);
			minTherapySessionDate = receivedTherapySessionMap.firstKey();
			SortedMap<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap = getAllTherapySessionsMapByPatientUserIdForMonarchBetweenDates(
					minTherapySessionDate,maxTherapySessiondate,patientUser.getId());
			SortedMap<LocalDate,PatientComplianceMonarch> existingComplianceMap = getPatientComplainceMapByPatientUserIdForMonarchBetweenDates(
					minTherapySessionDate.minusDays(1),maxTherapySessiondate,patientUser.getId());
			String deviceType = advanceAdherenceCalculationService.getDeviceTypeValue(patient.getId());

			if(deviceType.equals("MONARCH")){
				processAdherenceScoreForMonarch(receivedTherapySessionMap,existingTherapySessionMap,existingComplianceMap,patientUser,patient,resetFlag,resetDate);
			}else if(deviceType.equals("BOTH")){
				processAdherenceScoreForBoth(receivedTherapySessionMap,existingTherapySessionMap,existingComplianceMap,patientUser,patient,resetFlag,resetDate);
			}
			
			if(receivedTherapySessionMap.size() > 0) {
				receivedTherapySessionMap = convertTherapySessionToLocalDate(receivedTherapySessionMap);
				if(Objects.nonNull(receivedTherapySessionMap.get(LocalDate.now()))){
					missTherapySettingDeviationNotifier.pushNotificationForProtocolDeviationMonarchSessions(receivedTherapySessionMap.get(LocalDate.now()), patient.getId());
				}
				receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMap);
			}
		}

		return therapySessions;
	}



	public void processAdherenceScoreForBoth(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap, User patientUser,
			PatientInfo patient, boolean resetFlag, LocalDate resetDate) throws Exception {

		LocalDate firstTransmissionDate = null;
		boolean isHMRCompliant = true;
		int missedTherapyCount = 0;
		boolean missTherapy = true;
		LocalDate trainingDate  = null; 
		LocalDate latestComplianceDate;
		int totalCumulativeDuration = 0;
		LocalDate lastTransmissionDate = null;
		LocalDate minOfTherapySessions = null;

		PatientNoEvent patientNoEvent = patientNoEventRepository.findByPatientUserId(patientUser.getId());
		SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionMapTemp = convertTherapySessionToLocalDate(receivedTherapySessionMap);
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		PatientNoEventMonarch patientNoEventMonarch = patientNoEventMonarchRepository.findByPatientUserId(patientUser.getId());
		
		if(resetFlag) {
			minOfTherapySessions = resetDate;
			latestComplianceDate = LocalDate.now();
		} else{
			minOfTherapySessions = receivedTherapySessionMapTemp.firstKey();
		}

		
		LocalDate today = LocalDate.now();

		SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = advanceAdherenceCalculationService.
				getAllTherapySessionsMapByPatientUserIdForVestBetweenDates(minOfTherapySessions, today, patientUser.getId());
		
		existingTherapySessionMapVest = advanceAdherenceCalculationService.convertTherapySessionToLocalDate(existingTherapySessionMapVest);

		SortedMap<LocalDate,PatientCompliance> existingComplianceVestMap = 
				getPatientComplainceMapByPatientUserIdForVestBetweenDates(minOfTherapySessions.minusDays(1),today,patientUser.getId());

		latestComplianceDate = LocalDate.now();
		if(!resetFlag) {
			if(Objects.nonNull(existingComplianceMap) && existingComplianceMap.size()>0){
				latestComplianceDate = existingComplianceMap.lastKey();
			}else if (Objects.nonNull(existingComplianceVestMap) && existingComplianceVestMap.size()>0){
				latestComplianceDate = existingComplianceVestMap.lastKey();
			}			
		}
		

		List<LocalDate> allDates;

		if(latestComplianceDate.isBefore(minOfTherapySessions)) {
			minOfTherapySessions = latestComplianceDate;
		}
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(minOfTherapySessions, LocalDate.now());

		Map<LocalDate,ProtocolConstants> vestProtocolMap = advanceAdherenceCalculationService.getProtocolForGivenDateTimeRangeForVest(patientUser,patient,allDates);
		Map<LocalDate,ProtocolConstantsMonarch> monarchProtocolMap = getProtocolForGivenDateTimeRangeForMonarch(patientUser, patient, allDates);

		firstTransmissionDate = calculateFirstTransmissionDate(patientNoEvent,patientNoEventMonarch);

		if(Objects.isNull(firstTransmissionDate) || (Objects.nonNull(firstTransmissionDate) && firstTransmissionDate.isAfter(minOfTherapySessions))) {
			noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
			firstTransmissionDate = minOfTherapySessions;
		}

		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient.getId());

		for(PatientDevicesAssoc eachDevice:activeDevices) {
			if(eachDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
				trainingDate  = eachDevice.getTrainingDate();
			}
		}

		for(LocalDate therapyDate : allDates){				
			if(therapyDate.equals(resetDate)) {
				PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,allDates.get(0),patient,patientUser,
						0,true,false,0,allDates.get(0),0.0);
				existingComplianceMap.put(allDates.get(0), currentCompliance);
				notificationServiceMonarch.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
						currentCompliance.getDate(), ADHERENCE_SCORE_RESET,false,null);
			} else {
				List<TherapySessionMonarch> sessionsTobeSaved = receivedTherapySessionMapTemp.get(therapyDate);

				if(Objects.nonNull(sessionsTobeSaved)) {
					existingTherapySessionMap.put(therapyDate, sessionsTobeSaved);
				}
				
				List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySession> currentVestTherapySessions = existingTherapySessionMapVest.get(therapyDate);

					List<TherapySessionMonarch> currentMonarchTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceMonarch complianceMonarch = existingComplianceMap.get(therapyDate);

					if(Objects.nonNull(trainingDate) && (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {
						PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,therapyDate,patient,patientUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {

						if(currentVestTherapySessions != null && currentMonarchTherapySessions != null) {
							totalCumulativeDuration = calculateCumulativeDurationVest(currentVestTherapySessions) + calculateCumulativeDurationForMonarch(currentMonarchTherapySessions); 
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									totalCumulativeDuration);
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentVestTherapySessions != null ) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationVest(currentVestTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentMonarchTherapySessions != null) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationForMonarch(currentMonarchTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else {
							isHMRCompliant = false;
							missTherapy = true;

						}
						
						complianceMonarch = advanceAdherenceCalculationService.getLatestComplianceMonarch(patientUser, patient,existingComplianceMap, therapyDate);

						missedTherapyCount = complianceMonarch.getMissedTherapyCount();

						advanceAdherenceCalculationService.calculateAdherenceForTheDayForBoth(complianceMonarch,isHMRCompliant,existingComplianceMap,
								patient,patientUser,therapyDate,missedTherapyCount,missTherapy,lastTransmissionDate);
					}	
				} else{
					lastTransmissionDate = therapyDate;
				}					
			}			
		}

		if(!resetFlag) {
			receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMapTemp);
			saveOrUpdateTherapySessions(receivedTherapySessionMap);
		}
		
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForMonarch(existingComplianceMap);

	}


	public LocalDate calculateFirstTransmissionDate(PatientNoEvent patientNoEvent,
			PatientNoEventMonarch patientNoEventMonarch) {
		LocalDate firstTransmittedDate = null;
		if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate()) && 
				Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())) {
			if((patientNoEvent.getFirstTransmissionDate()).isBefore(patientNoEventMonarch.getFirstTransmissionDate())) {
				firstTransmittedDate = patientNoEvent.getFirstTransmissionDate();
			} else {
				firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
			}
		} else if(Objects.isNull(patientNoEvent.getFirstTransmissionDate()) && Objects.nonNull(patientNoEventMonarch) &&
				Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())) {
			firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
		} else {
			firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
		}
		return firstTransmittedDate;
	}



	public void processAdherenceScoreForMonarch(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap, User patientUser,
			PatientInfo patient, boolean resetFlag, LocalDate resetDate) throws Exception {

		boolean isHMRCompliant = true;
		boolean missTherapy = true;
		int missedTherapyCount = 0;
		LocalDate trainingDate = null;
		LocalDate lastTransmissionDate = null;
		LocalDate minOfTherapySessions = null;
		LocalDate latestComplianceDate = null;

		SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionMapTemp = convertTherapySessionToLocalDate(receivedTherapySessionMap);
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		PatientNoEventMonarch patientNoEventMonarch = patientNoEventMonarchRepository.findByPatientUserId(patientUser.getId());

		if(resetFlag) {
			minOfTherapySessions = resetDate;
			latestComplianceDate = LocalDate.now();
		} else{
			minOfTherapySessions = receivedTherapySessionMap.firstKey();
			if(Objects.nonNull(existingComplianceMap) && !existingComplianceMap.isEmpty()) {
				latestComplianceDate = existingComplianceMap.lastKey();
			} else {
				latestComplianceDate = LocalDate.now();
			}
		}
		

		List<LocalDate> allDates;

		if(latestComplianceDate.isBefore(minOfTherapySessions)) {
			minOfTherapySessions = latestComplianceDate;
		}
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(minOfTherapySessions, LocalDate.now());

		// First Transmission Date to be updated
		if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())) {
			if((patientNoEventMonarch.getFirstTransmissionDate()).isAfter(minOfTherapySessions)) {
				noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
			} 
		} else {
			noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
		}

		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient.getId());

		for(PatientDevicesAssoc eachDevice:activeDevices) {
			if(eachDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
				trainingDate  = eachDevice.getTrainingDate();
			}
		}

		Map<LocalDate,ProtocolConstantsMonarch> protocolMap = getProtocolForGivenDateTimeRangeForMonarch(patientUser,patient,allDates);

		for(LocalDate therapyDate : allDates) {
			
			if(therapyDate.equals(resetDate)) {
				PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,allDates.get(0),patient,patientUser,
						0,true,false,0,allDates.get(0),0.0);
				existingComplianceMap.put(allDates.get(0), currentCompliance);
				notificationServiceMonarch.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
						currentCompliance.getDate(), ADHERENCE_SCORE_RESET,false,null);
			} else {

				List<TherapySessionMonarch> sessionsTobeSaved = receivedTherapySessionMap.get(therapyDate);

				if(Objects.nonNull(sessionsTobeSaved)) {
					existingTherapySessionMap.put(therapyDate, sessionsTobeSaved);
				}
				
				List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySessionMonarch> currentTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceMonarch compliance = existingComplianceMap.get(therapyDate);


					if(Objects.nonNull(trainingDate)&& (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {

						PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,therapyDate,patient,patientUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {
						if(currentTherapySessions != null) {
							isHMRCompliant = isHMRCompliant(protocolMap.get(therapyDate), calculateCumulativeDurationForMonarch(currentTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;
						} else {
							isHMRCompliant = false;
							missTherapy = true;
						}

						compliance = advanceAdherenceCalculationService.getLatestComplianceMonarch(patientUser, patient,
								existingComplianceMap, therapyDate);

						missedTherapyCount = compliance.getMissedTherapyCount();

						calculateAdherenceForTheDayMoanrch(compliance,isHMRCompliant,existingTherapySessionMap,existingComplianceMap,
								patient,patientUser,missedTherapyCount,missTherapy,lastTransmissionDate);
					}
				} else {
					lastTransmissionDate = therapyDate;
				}
			}

		}
		if(!resetFlag) {
			receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMapTemp);
			saveOrUpdateTherapySessions(receivedTherapySessionMap);
		} 
		
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForMonarch(existingComplianceMap);

	}
	
	private void calculateAdherenceForTheDayMoanrch(PatientComplianceMonarch compliance, boolean isHMRCompliant,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap,
			PatientInfo patient, User patientUser, int missedTherapyCount, boolean missTherapy, LocalDate lastTransmissionDate) {
		String notificationType = "";
		String complianceType="";
		int currentScore=0;

		if(Objects.nonNull(compliance)) {
			currentScore = compliance.getScore();
			if(missedTherapyCount < MISSED_THERAPY_DAYS_COUNT_THRESHOLD) {
				if(!missTherapy) {
					if(!isHMRCompliant) {
						currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
						complianceType =  HMR_NON_COMPLIANCE;	
						notificationType = HMR_NON_COMPLIANCE;
						compliance.setHmrCompliant(false);
						compliance.setMissedTherapyCount(0);

						int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
						compliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
					} else {
						currentScore = currentScore < 100 ? currentScore + 1 : DEFAULT_COMPLIANCE_SCORE;
						notificationType = null;
						compliance.setHmrCompliant(true);
						compliance.setMissedTherapyCount(0);
					}
				} else {
					currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
					complianceType =  null;	
					notificationType = MISSED_THERAPY;
					compliance.setHmrCompliant(false);
					compliance.setMissedTherapyCount(missedTherapyCount+1);

					int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
					compliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);
				}
			} else {
				currentScore = DEFAULT_COMPLIANCE_SCORE;	
				notificationType = ADHERENCE_SCORE_RESET;
				compliance.setHmrCompliant(false);
				compliance.setMissedTherapyCount(0);
			}
		} else {
			currentScore = DEFAULT_COMPLIANCE_SCORE;
			if(!missTherapy) {
				if(!isHMRCompliant) {
					currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
					complianceType =  HMR_NON_COMPLIANCE;	
					notificationType = HMR_NON_COMPLIANCE;
					compliance.setHmrCompliant(false);
					compliance.setMissedTherapyCount(0);

					int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
					compliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
				} else {
					currentScore = currentScore < 100 ? currentScore + 1 : DEFAULT_COMPLIANCE_SCORE;
					notificationType = null;
					compliance.setHmrCompliant(true);
					compliance.setMissedTherapyCount(0);
				}
			} else {
				currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
				complianceType =  null;	
				notificationType = MISSED_THERAPY;
				compliance.setHmrCompliant(false);
				compliance.setMissedTherapyCount(missedTherapyCount+1);

				int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
				compliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);	
			}

		}

		compliance.setScore(currentScore);
		compliance.setSettingsDeviated(false);
		compliance.setLatestTherapyDate(lastTransmissionDate);

		if(StringUtils.isNotBlank(notificationType)){
			notificationServiceMonarch.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
					compliance.getDate(), notificationType,false,complianceType);
		}  else {
			advanceAdherenceCalculationService.deleteNotificationIfExistsForBoth(patientUser.getId(), compliance.getDate());
		}
		existingComplianceMap.put(compliance.getDate(), compliance);

	}
	
	
	public void ProcessAdherenceResetCalculationForBoth(PatientInfo patientInfo, User user, PatientInfo patientInfoOld,
			User userOld, LocalDate firstTransmissionDateVest, LocalDate firstTransmissionDateMonarch, int resetScore, String currentDeviceType,
			String oldDeviceType) {
		// TODO Auto-generated method stub
		List<LocalDate> allDates;
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(firstTransmissionDateVest, LocalDate.now());
		
		LocalDate firstTransmissionDate = null;
		boolean isHMRCompliant = true;
		int missedTherapyCount = 0;
		boolean missTherapy = true;
		LocalDate trainingDate  = null; 
		LocalDate latestComplianceDate;
		int totalCumulativeDuration = 0;
		LocalDate lastTransmissionDate = null;
		LocalDate minDateFromRecievedTherapies = null;
		PatientInfo monarchPatientInfo = null;
		User monarchUser = null;
		PatientInfo vestPatientInfo = null;
		User vestUser = null;
		
		
		if(currentDeviceType.equalsIgnoreCase("MONARCH")) {
			vestPatientInfo = patientInfo;
			vestUser = user;
			monarchPatientInfo = patientInfoOld;
			monarchUser = userOld;
		}else {
			vestPatientInfo = patientInfoOld;
			vestUser = userOld;
			monarchPatientInfo = patientInfo;
			monarchUser = user;
		}
			
		
		minDateFromRecievedTherapies = firstTransmissionDateVest;
		latestComplianceDate = LocalDate.now();

		PatientNoEvent patientNoEvent = patientNoEventRepository.findByPatientUserId(vestUser.getId());

		PatientNoEventMonarch patientNoEventMonarch = patientNoEventMonarchRepository.findByPatientUserId(monarchUser.getId());
			
		SortedMap<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap = 
					getAllTherapySessionsMapByPatientUserIdForMonarchBetweenDates(allDates.get(0),LocalDate.now(),monarchUser.getId());
		
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		SortedMap<LocalDate,PatientComplianceMonarch> existingComplianceMap = getPatientComplainceMapByPatientUserIdForMonarchBetweenDates(
					minDateFromRecievedTherapies.minusDays(1),latestComplianceDate,monarchUser.getId());
			
		SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = advanceAdherenceCalculationService.
					getAllTherapySessionsMapByPatientUserIdForVestBetweenDates(minDateFromRecievedTherapies, latestComplianceDate, vestUser.getId());
		
		existingTherapySessionMapVest = advanceAdherenceCalculationService.convertTherapySessionToLocalDate(existingTherapySessionMapVest);
			
		Map<LocalDate,ProtocolConstants> vestProtocolMap = advanceAdherenceCalculationService.getProtocolForGivenDateTimeRangeForVest(vestUser, patientInfoOld,allDates);
		Map<LocalDate,ProtocolConstantsMonarch> monarchProtocolMap = getProtocolForGivenDateTimeRangeForMonarch(monarchUser,patientInfo, allDates);
			
		firstTransmissionDate = calculateFirstTransmissionDate(patientNoEvent,patientNoEventMonarch);
		
		for(LocalDate therapyDate : allDates) {
				
				List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDate(monarchUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySession> currentVestTherapySessions = existingTherapySessionMapVest.get(therapyDate);

					List<TherapySessionMonarch> currentMonarchTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceMonarch complianceMonarch = existingComplianceMap.get(therapyDate);

					

					if(firstTransmissionDate.equals(null) || firstTransmissionDate.isAfter(therapyDate)) {
						noEventMonarchService.updatePatientFirstTransmittedDate(monarchUser.getId(), therapyDate, monarchPatientInfo.getId());
						firstTransmissionDate = therapyDate;
					}

					List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(monarchPatientInfo.getId());

					for(PatientDevicesAssoc eachDevice:activeDevices) {
						if(eachDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
							trainingDate  = eachDevice.getTrainingDate();
						}
					}

					if(Objects.nonNull(trainingDate) && (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {
						PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,therapyDate,monarchPatientInfo,monarchUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {

						if(currentVestTherapySessions != null && currentMonarchTherapySessions != null) {
							totalCumulativeDuration = calculateCumulativeDurationVest(currentVestTherapySessions) + calculateCumulativeDurationForMonarch(currentMonarchTherapySessions); 
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									totalCumulativeDuration);
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentVestTherapySessions != null ) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationVest(currentVestTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentMonarchTherapySessions != null) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(monarchProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationForMonarch(currentMonarchTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else {
							isHMRCompliant = false;
							missTherapy = true;

						}
						
						try {
							complianceMonarch = advanceAdherenceCalculationService.getLatestComplianceMonarch(monarchUser, monarchPatientInfo,existingComplianceMap, therapyDate);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						missedTherapyCount = complianceMonarch.getMissedTherapyCount();

						advanceAdherenceCalculationService.calculateAdherenceForTheDayForBoth(complianceMonarch,isHMRCompliant,existingComplianceMap,
								monarchPatientInfo,monarchUser,therapyDate,missedTherapyCount,missTherapy,lastTransmissionDate);
					}	
				} else{
					lastTransmissionDate = therapyDate;
				}
		}
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForMonarch(existingComplianceMap);

		}


	public SortedMap<LocalDate,List<TherapySessionMonarch>> getAllTherapySessionsMapByPatientUserIdForMonarchBetweenDates(LocalDate minTherapySessionDate,
			LocalDate maxTherapySessiondate, Long patientUserId){
		List<TherapySessionMonarch> therapySessions =  therapySessionMonarchRepository.findByDateBetweenAndPatientUserId(minTherapySessionDate,maxTherapySessiondate,patientUserId);
		return groupTherapySessionsByDate(therapySessions);
	}

	public SortedMap<LocalDate,List<TherapySessionMonarch>> convertTherapySessionToLocalDate(SortedMap<LocalDate,List<TherapySessionMonarch>> inputSessions){
		List<TherapySessionMonarch> therapySessions = new ArrayList<>();
		Collection<List<TherapySessionMonarch>> collection = inputSessions.values();
		for (List<TherapySessionMonarch> list : collection) {
			for (TherapySessionMonarch therapySessionMonarch : list) {
				if (DateUtil.isDSTOn(therapySessionMonarch.getStartTime().getMillis(),Constants.CST_STR)) {
					therapySessionMonarch.setDate(therapySessionMonarch.getStartTime().minusHours(4).toLocalDate());
				}else {
					therapySessionMonarch.setDate(therapySessionMonarch.getStartTime().minusHours(5).toLocalDate());
				}
			}
			therapySessions.addAll(list);
		}
		return groupTherapySessionsByDate(therapySessions);
	}
	
	public SortedMap<LocalDate,List<TherapySessionMonarch>> convertTherapySessionToOriginalDate(SortedMap<LocalDate,List<TherapySessionMonarch>> inputSessions){
		List<TherapySessionMonarch> therapySessions = new ArrayList<>();
		Collection<List<TherapySessionMonarch>> collection = inputSessions.values();
		for (List<TherapySessionMonarch> list : collection) {
			for (TherapySessionMonarch therapySessionMonarch : list) {
				if (DateUtil.isDSTOn(therapySessionMonarch.getStartTime().getMillis(),Constants.CST_STR)) {
					therapySessionMonarch.setDate(therapySessionMonarch.getStartTime().plusHours(4).toLocalDate());
				}else {
					therapySessionMonarch.setDate(therapySessionMonarch.getStartTime().plusHours(5).toLocalDate());
				}
			}
			therapySessions.addAll(list);
		}
		return groupTherapySessionsByDate(therapySessions);
	}
	
	public SortedMap<LocalDate,List<TherapySessionMonarch>> groupTherapySessionsByDate(List<TherapySessionMonarch> therapySessions){
		return new TreeMap<>(therapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch :: getDate)));
	}

	public static int calculateHMRRunRatePerSession(List<TherapySessionMonarch> therapySessions){
		float sessionsCount = therapySessions.isEmpty()?1:therapySessions.size();
		return Math.round(calculateCumulativeDurationForMonarch(therapySessions)/sessionsCount);
	}

	public static int calculateCumulativeDurationForMonarch(List<TherapySessionMonarch> therapySessions){
		return therapySessions.stream().collect(Collectors.summingInt(TherapySessionMonarch::getDurationInMinutes));
	}

	public static int calculateHMRRunRatePerSessionVest(List<TherapySession> therapySessions){
		float sessionsCount = therapySessions.isEmpty()?1:therapySessions.size();
		return Math.round(calculateCumulativeDurationVest(therapySessions)/sessionsCount);
	}

	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsMonarch protocolConstant,
			double actualTotalDurationSettingDays) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstant
				.getMinDuration()) ? protocolConstant.getMinDuration()
						: protocolConstant.getTreatmentsPerDay()
						* protocolConstant.getMinMinutesPerTreatment();
				if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays)){
					return false;
				}
				return true;
	}

	private synchronized void saveOrUpdateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap) {
		Map<LocalDate, List<TherapySessionMonarch>> allTherapySessionMap = eleminateDuplicateTherapySessions(receivedTherapySessionsMap);

		List<TherapySessionMonarch> newTherapySessions = new LinkedList<>();
		for(LocalDate date : allTherapySessionMap.keySet()){
			List<TherapySessionMonarch> sessionsTobeSaved = allTherapySessionMap.get(date);
			newTherapySessions.addAll(sessionsTobeSaved);
		}
		therapySessionMonarchRepository.save(newTherapySessions);
	}

	private Map<LocalDate, List<TherapySessionMonarch>> eleminateDuplicateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap) {
		List<List<TherapySessionMonarch>> therapySessionsList = new LinkedList<>(receivedTherapySessionsMap.values());
		Long patientUserId = therapySessionsList.get(0).get(0).getPatientUser().getId();
		LocalDate from = receivedTherapySessionsMap.firstKey();
		LocalDate to = receivedTherapySessionsMap.lastKey();
		List<TherapySessionMonarch> existingTherapySessions = therapySessionMonarchRepository.findByPatientUserIdAndDateRange(patientUserId, from, to);
		Map<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap = existingTherapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch::getDate));
		Map<LocalDate,List<TherapySessionMonarch>> allTherapySessionMap = new HashMap<>();
		for(LocalDate date : receivedTherapySessionsMap.keySet()){
			List<TherapySessionMonarch> therapySessionsPerDate = existingTherapySessionMap.get(date);
			if(Objects.nonNull(therapySessionsPerDate)){
				List<TherapySessionMonarch> receivedTherapySessions = receivedTherapySessionsMap.get(date);
				for(TherapySessionMonarch existingSession : therapySessionsPerDate){
					Iterator<TherapySessionMonarch> itr = receivedTherapySessions.iterator();
					while(itr.hasNext()){
						TherapySessionMonarch receivedSession = itr.next();
						if(existingSession.getDate().equals(receivedSession.getDate()) &&
								existingSession.getStartTime().equals(receivedSession.getStartTime()) &&
								existingSession.getEndTime().equals(receivedSession.getEndTime()) &&
								existingSession.getFrequency().equals(receivedSession.getFrequency()) && 
								existingSession.getIntensity().equals(receivedSession.getIntensity()) &&
								existingSession.getHmr().equals(receivedSession.getHmr())){
							itr.remove();
						}
					}
				}
				therapySessionsPerDate.addAll(receivedTherapySessionsMap.get(date));
				Collections.sort(therapySessionsPerDate);
				int sessionNo = 0;
				for(TherapySessionMonarch session : therapySessionsPerDate){
					session.setSessionNo(++sessionNo);
				}
				allTherapySessionMap.put(date, therapySessionsPerDate);
			}else{
				for(LocalDate receivedDate : receivedTherapySessionsMap.keySet()){
					allTherapySessionMap.put(receivedDate, receivedTherapySessionsMap.get(receivedDate));
				}
			}
		}
		return allTherapySessionMap;
	}

	public static int calculateCumulativeDurationVest(List<TherapySession> therapySessions){
		return therapySessions.stream().collect(Collectors.summingInt(TherapySession::getDurationInMinutes));
	}

	public SortedMap<LocalDate,PatientComplianceMonarch> getPatientComplainceMapByPatientUserIdForMonarchBetweenDates(LocalDate minTherapySessionDate, 
			LocalDate maxTherapySessiondate, Long patientUserId){
		List<PatientComplianceMonarch> complianceList = complianceMonarchRepository.
				findByDateBetweenAndPatientUserId(minTherapySessionDate,maxTherapySessiondate,patientUserId);
		SortedMap<LocalDate,PatientComplianceMonarch> existingComplainceMap = new TreeMap<>(); 
		for(PatientComplianceMonarch compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}

	public SortedMap<LocalDate,PatientCompliance> getPatientComplainceMapByPatientUserIdForVestBetweenDates(LocalDate minDateFromRecievedTherapies,
			LocalDate today, Long patientUserId){

		List<PatientCompliance> complianceList = complianceRepository.findByDateBetweenAndPatientUserId(minDateFromRecievedTherapies,today,patientUserId);
		SortedMap<LocalDate,PatientCompliance> existingComplainceMap = new TreeMap<>(); 
		for(PatientCompliance compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}


	public Map<LocalDate,ProtocolConstantsMonarch> getProtocolForGivenDateTimeRangeForMonarch(User patientUser,
			PatientInfo patient, List<LocalDate> allDates) {
		Map<LocalDate,ProtocolConstantsMonarch> protocolMap = new HashMap<LocalDate,ProtocolConstantsMonarch>();
		Long startTime = 0L;

		List<PatientProtocolDataMonarch>  protocolList = patientProtocolMonarchRepository.findByPatientIdOrderByCreatedDateAsc(patient.getId());
		if(!protocolList.isEmpty()) {
		for(LocalDate currentDate : allDates) {
			startTime = currentDate.toDateTimeAtStartOfDay().getMillis();
			
				for (PatientProtocolDataMonarch ppd : protocolList) {
					if (patientProtocolMonarchService.isProtocolValidForDate(ppd, startTime)) { 
						List<PatientProtocolDataMonarch> protocol = patientProtocolMonarchRepository.findByProtocolKey(ppd.getProtocolKey());
						if(Objects.nonNull(protocol) && protocol.size() > 0){			
							String protocolType = protocol.get(0).getType();
							if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(protocolType)){
								protocolMap.put(currentDate,patientProtocolMonarchService.getProtocolConstantFromNormalProtocol(protocol));
							}else{
								protocolMap.put(currentDate,patientProtocolMonarchService.getProtocolConstantFromCustomProtocol(protocol));
							}
						}else{
							protocolMap.put(currentDate,protocolConstantsMonarchRepository.findOne(1L));
						}
					} else{
						protocolMap.put(currentDate,protocolConstantsMonarchRepository.findOne(1L));
					}
				}
			} 
		} else{
			for(LocalDate currentDate : allDates) {
			protocolMap.put(currentDate,protocolConstantsMonarchRepository.findOne(1L));
			}
		}

		return protocolMap;
	}
	
	
	public void processAdherenceScoreForSwapCaseMonarch(
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap, User patientUser, PatientInfo patient){ 

		boolean isHMRCompliant = true;
		boolean missTherapy = true;
		int missedTherapyCount = 0;
		LocalDate trainingDate = null;
		LocalDate lastTransmissionDate = null;
		LocalDate minOfTherapySessions = existingTherapySessionMap.firstKey();
		LocalDate latestComplianceDate = null;
		List<LocalDate> allDates;

		
		PatientNoEventMonarch patientNoEventMonarch = patientNoEventMonarchRepository.findByPatientUserId(patientUser.getId());
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		latestComplianceDate = LocalDate.now();
		

		if(latestComplianceDate.isBefore(minOfTherapySessions)) {
			minOfTherapySessions = latestComplianceDate;
		}
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(minOfTherapySessions, LocalDate.now());

		// First Transmission Date to be updated
		if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())) {
			if((patientNoEventMonarch.getFirstTransmissionDate()).isAfter(minOfTherapySessions)) {
				noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
			} 
		} else {
			noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
		}

		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient.getId());

		for(PatientDevicesAssoc eachDevice:activeDevices) {
			if(eachDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
				trainingDate  = eachDevice.getTrainingDate();
			}
		}

		Map<LocalDate,ProtocolConstantsMonarch> protocolMap = getProtocolForGivenDateTimeRangeForMonarch(patientUser,patient,allDates);
		

		for(LocalDate therapyDate : allDates) {
				
				List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySessionMonarch> currentTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceMonarch compliance = existingComplianceMap.get(therapyDate);


					if(Objects.nonNull(trainingDate)&& (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {

						PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE,therapyDate,patient,patientUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {
						if(currentTherapySessions != null) {
							isHMRCompliant = isHMRCompliant(protocolMap.get(therapyDate), calculateCumulativeDurationForMonarch(currentTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;
						} else {
							isHMRCompliant = false;
							missTherapy = true;
						}

						try {
						compliance = advanceAdherenceCalculationService.getLatestComplianceMonarch(patientUser, patient,
								existingComplianceMap, therapyDate);
						} catch (Exception e) {
							e.printStackTrace();
						}

						missedTherapyCount = compliance.getMissedTherapyCount();

						calculateAdherenceForTheDayMoanrch(compliance,isHMRCompliant,existingTherapySessionMap,existingComplianceMap,
								patient,patientUser,missedTherapyCount,missTherapy,lastTransmissionDate);
					}
				} else {
					lastTransmissionDate = therapyDate;
				}
		}
		
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForMonarch(existingComplianceMap);
	}

	public void executeSwapMonarchDevice(PatientDevicesAssoc patDevice){
		
		List<TherapySessionMonarch> sessionsToBeSaved = new ArrayList<TherapySessionMonarch>();
		
		List<LocalDate> allDates;
		// Get Patient and User object
		PatientInfo patientInfo = patientInfoRepository.findOneById(patDevice.getPatientId());
		User user = userService.getUserObjFromPatientInfo(patientInfo);

		// Get the Patient & User of old shell details
		PatientInfo patientInfoOld = patientInfoRepository.findOneById(patDevice.getSwappedPatientId());
		User userOld = userService.getUserObjFromPatientInfo(patientInfoOld);
		
		List<TherapySessionMonarch> shellPatientTherapySessions = therapySessionMonarchRepository.findByPatientUserId(userOld.getId());
		
		for(TherapySessionMonarch eachTherapySession:shellPatientTherapySessions) {
			eachTherapySession.setPatientInfo(patientInfo);
			eachTherapySession.setPatientUser(user);
			sessionsToBeSaved.add(eachTherapySession);
		}
		therapySessionMonarchService.saveAll(sessionsToBeSaved);
		
		PatientNoEventMonarch patientNoEvent = patientNoEventMonarchRepository.findByPatientId(patientInfo.getId());
		PatientNoEventMonarch patientNoEventOld = patientNoEventMonarchRepository.findByPatientId(patientInfoOld.getId());
		
		if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEventOld)) {
			if(Objects.nonNull(patientNoEvent.getFirstTransmissionDate()) && 
					Objects.nonNull(patientNoEventOld.getFirstTransmissionDate())) {
				if(patientNoEvent.getFirstTransmissionDate().isAfter(patientNoEventOld.getFirstTransmissionDate()) ||
						patientNoEvent.getFirstTransmissionDate().isEqual(patientNoEventOld.getFirstTransmissionDate())) {
					
					patientNoEvent.setFirstTransmissionDate(patientNoEventOld.getFirstTransmissionDate());
					noEventMonarchService.save(patientNoEvent);
				}
			} else if(Objects.isNull(patientNoEvent.getFirstTransmissionDate()) && 
					Objects.nonNull(patientNoEventOld.getFirstTransmissionDate())){
				
				patientNoEvent.setFirstTransmissionDate(patientNoEventOld.getFirstTransmissionDate());
				noEventMonarchService.save(patientNoEvent);
			}
			
		} else if(Objects.isNull(patientNoEvent) && Objects.nonNull(patientNoEventOld)) {
			
			PatientNoEventMonarch noEventMonarchToSave = new PatientNoEventMonarch(LocalDate.now(),
					patientNoEventOld.getFirstTransmissionDate(), patientInfo, user);
			
			noEventMonarchService.save(noEventMonarchToSave);
		}
		
		LocalDate firstTransmissionDate  = patientNoEventMonarchRepository.findByPatientId(patientInfo.getId()).getFirstTransmissionDate();
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(firstTransmissionDate, LocalDate.now());
		
		SortedMap<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap = getAllTherapySessionsMapByPatientUserIdForMonarchBetweenDates
				(allDates.get(0),LocalDate.now(),user.getId());

		SortedMap<LocalDate,PatientComplianceMonarch> existingComplianceMap = getPatientComplainceMapByPatientUserIdForMonarchBetweenDates(
				allDates.get(0),LocalDate.now(),user.getId());
		
		processAdherenceScoreForSwapCaseMonarch(existingTherapySessionMap,existingComplianceMap,user,patientInfo);
		
	}
}
	
