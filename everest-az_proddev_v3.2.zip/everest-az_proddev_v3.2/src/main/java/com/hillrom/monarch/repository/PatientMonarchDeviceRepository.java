package com.hillrom.monarch.repository;

import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.PatientVestDevicePK;

public interface PatientMonarchDeviceRepository extends
		JpaRepository<PatientVestDeviceHistoryMonarch, PatientVestDevicePK> {

	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1")
	List<PatientVestDeviceHistoryMonarch> findByPatientId(String patientId);

	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and ((pvd.active = false and pvd.createdDate < ?2 and pvd.lastModifiedDate >?2) or (pvd.active=1))")
	List<PatientVestDeviceHistoryMonarch> findByPatientIdWithinRange(String patientId, DateTime from);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.serialNumber = ?1")
	List<PatientVestDeviceHistoryMonarch> findBySerialNumber(String serialNumber);

	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.patientVestDevicePK.serialNumber = ?2")
	Optional<PatientVestDeviceHistoryMonarch> findOneByPatientIdAndSerialNumber(
			String patientId, String serialNumber);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.patientVestDevicePK.serialNumber = ?2 and pvd.active = false")
	Optional<PatientVestDeviceHistoryMonarch> findOneByPatientIdAndSerialNumberAndStatusInActive(
			String patientId, String serialNumber);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.patientVestDevicePK.serialNumber = ?2 and pvd.active = true")
	Optional<PatientVestDeviceHistoryMonarch> findOneByPatientIdAndSerialNumberAndStatusActive(
			String patientId, String serialNumber);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.active = ?2")
	Optional<PatientVestDeviceHistoryMonarch> findOneByPatientIdAndActiveStatus(
			String patientId, Boolean active);

	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.wifiId = ?1 or pvd.lteId = ?1 and pvd.active = true")
	List<PatientVestDeviceHistoryMonarch> findByWifiIdAndStatusActive(
			String wifiId);

	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 order by pvd.lastModifiedDate desc")
	List<PatientVestDeviceHistoryMonarch> findLatestDeviceForPatient(String patientId);

	@Query(nativeQuery = true, value = "SELECT * FROM PATIENT_VEST_DEVICE_HISTORY_MONARCH pvd where patient_id = :patientId and is_active = :isActive order by last_modified_by desc limit 1 ")
	PatientVestDeviceHistoryMonarch findLatestInActiveDeviceByPatientId(
			@Param("patientId")String pateitnId, @Param("isActive")Boolean active);
	
	@Query(nativeQuery = true, value = "SELECT * FROM PATIENT_VEST_DEVICE_HISTORY_MONARCH pvd where patient_id = :patientId and is_active = :isActive limit 1 ")
	PatientVestDeviceHistoryMonarch findLatestActiveDeviceByPatientId(
			@Param("patientId")String pateitnId, @Param("isActive")Boolean active);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.pending = ?2")
	Optional<PatientVestDeviceHistoryMonarch> findOneByPatientIdAndPendingStatus(
			String patientId, Boolean pending);
	
	@Query("from PatientVestDeviceHistoryMonarch pvd where pvd.patientVestDevicePK.serialNumber = ?1  and pvd.active = true")
	List<PatientVestDeviceHistoryMonarch> findOneBySerialNumberAndStatusActive(String serialNumber);
	
}
