package com.hillrom.monarch.service;


import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.audit.service.PatientProtocolDataAuditMonarchService;
import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.monarch.repository.PatientNoEventsMonarchRepository;
import com.hillrom.monarch.web.rest.dto.AdherenceTrendMonarchVO;
import com.hillrom.monarch.web.rest.dto.ProtocolRevisionMonarchVO;
import com.hillrom.titan.repository.PatientNoEventsTitanRepository;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientNoEventsRepository;

@Service
@Transactional
public class PatientComplianceMonarchService {

	@Inject
	private PatientComplianceMonarchRepository complianceMonarchRepository;

	@Inject
	@Qualifier("patientProtocolDataAuditMonarchService")
	private PatientProtocolDataAuditMonarchService protocolAuditMonarchService;
	
	@Inject
	private PatientNoEventsMonarchRepository patientNoEventsMonarchRepository;
	
	@Inject
	private PatientNoEventsRepository patientNoEventsRepository;
	
	@Inject
	private PatientNoEventsTitanRepository patientNoEventsTitanRepository;
	
	/**
	 * Creates Or Updates Compliance 
	 * @param compliance
	 * @return
	 */
	public PatientComplianceMonarch createOrUpdate(PatientComplianceMonarch compliance){
		LocalDate date = compliance.getDate();
		Long patientUserId = compliance.getPatientUser().getId();
		PatientComplianceMonarch existingCompliance = complianceMonarchRepository.findByPatientUserIdAndDate(patientUserId, date);
		if(Objects.nonNull(existingCompliance)){
			existingCompliance.setScore(compliance.getScore());
			existingCompliance.setHmrRunRate(compliance.getHmrRunRate());
			existingCompliance.setMissedTherapyCount(compliance.getMissedTherapyCount());
			existingCompliance.setSettingsDeviatedDaysCount(compliance.getSettingsDeviatedDaysCount());
			compliance = complianceMonarchRepository.save(existingCompliance);
		}else{
			complianceMonarchRepository.save(compliance);
		}
		return compliance;
	}
	
	public PatientComplianceMonarch findLatestComplianceByPatientUserId(Long patientUserId){
		return complianceMonarchRepository.findTop1ByPatientUserIdOrderByDateDesc(patientUserId);
	}
	
	public SortedMap<LocalDate,PatientComplianceMonarch> getPatientComplainceMapByPatientUserId(Long patientUserId){
		List<PatientComplianceMonarch> complianceList = complianceMonarchRepository.findByPatientUserId(patientUserId);
		SortedMap<LocalDate,PatientComplianceMonarch> existingComplainceMap = new TreeMap<>(); 
		for(PatientComplianceMonarch compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}
	
	public int getMissedTherapyCountByPatientUserId(Long patientUSerId){
		PatientComplianceMonarch existingCompliance = complianceMonarchRepository.findByPatientUserIdAndDate(patientUSerId,LocalDate.now());
		if (Objects.nonNull(existingCompliance))
			return existingCompliance.getMissedTherapyCount();
		else
			return 0;
	}
	
	public void saveAll(Collection<PatientComplianceMonarch> complainces){
		complianceMonarchRepository.save(complainces);
	}
	
	public List<ProtocolRevisionMonarchVO> findAdherenceTrendByUserIdAndDateRange(Long patientUserId,LocalDate from,LocalDate to)
	throws HillromException{
		List<Long> patientUserIds = new LinkedList<>();
		patientUserIds.add(patientUserId);
		LocalDate toDate = to;
		LocalDate fromDateM = from.minusDays(1);
		LocalDate fromDateV = from.minusDays(1);
		LocalDate fromDateT = from.minusDays(1);
		LocalDate fromDate = from.minusDays(1);
		PatientNoEventMonarch patientNoEventMonarch = patientNoEventsMonarchRepository
				.findByPatientUserId(patientUserId);

		if (Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(fromDateM) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())){
			if (patientNoEventMonarch.getFirstTransmissionDate().isAfter(
				fromDateM)) 
			{
				fromDateM = patientNoEventMonarch.getFirstTransmissionDate();
			}
		}
		PatientNoEventTitan patientNoEventTitan= patientNoEventsTitanRepository
				.findByPatientUserId(patientUserId);

		if (Objects.nonNull(patientNoEventTitan) && Objects.nonNull(fromDateM) && Objects.nonNull(patientNoEventTitan.getFirstTransmissionDate())){
			if (patientNoEventTitan.getFirstTransmissionDate().isAfter(
				fromDateM)) 
			{
				fromDateT =patientNoEventTitan.getFirstTransmissionDate();
			}
		}

		PatientNoEvent patientNoEventVest = patientNoEventsRepository
				.findByPatientUserId(patientUserId);

		if (Objects.nonNull(patientNoEventVest) && Objects.nonNull(fromDateV) && Objects.nonNull(patientNoEventVest.getFirstTransmissionDate())){
			if (patientNoEventVest.getFirstTransmissionDate().isAfter(
				fromDateV)) 
			{
				fromDateV = patientNoEventVest.getFirstTransmissionDate();
			}
		}
		
		if(fromDateV.isBefore(fromDateM)&&fromDateV.isBefore(fromDateT)) {
			fromDate = fromDateV;
		}else if(fromDateM.isBefore(fromDateV)&&fromDateM.isBefore(fromDateT)) {
			fromDate = fromDateM;
		}else {
			fromDate=fromDateT;
		}
		
		// Ends GIMP 11
		List<PatientComplianceMonarch> complianceList = complianceMonarchRepository.findByDateBetweenAndPatientUserIdIn(fromDate, toDate, patientUserIds);
		if(complianceList.isEmpty()){
			throw new HillromException("No Data Available");
		}
		SortedMap<LocalDate,PatientComplianceMonarch> complianceMap = new TreeMap<>();
		for(PatientComplianceMonarch compliance : complianceList){
			complianceMap.put(compliance.getDate(), compliance);
		}
			
		SortedMap<LocalDate,PatientComplianceMonarch> actualMapRequested = complianceMap.tailMap(from);
		
		PatientComplianceMonarch lastCompliance = actualMapRequested.get(actualMapRequested.lastKey());
		SortedMap<DateTime,ProtocolRevisionMonarchVO> revisionData = new TreeMap<>();
		// if no revisions found,create a dummy revision with isValid = false
		if(revisionData.isEmpty()){
			ProtocolRevisionMonarchVO revisionVO = new ProtocolRevisionMonarchVO(lastCompliance.getPatientUser().getCreatedDate(),null);
			revisionData.put(lastCompliance.getPatientUser().getCreatedDate().minusSeconds(1), revisionVO);
		}else{
			ProtocolRevisionMonarchVO revisionVO = new ProtocolRevisionMonarchVO(lastCompliance.getPatientUser().getCreatedDate(),revisionData.firstKey());
			revisionData.put(lastCompliance.getPatientUser().getCreatedDate().minusSeconds(1), revisionVO);
		}

		for(LocalDate date: actualMapRequested.keySet()){
			AdherenceTrendMonarchVO trendVO = new AdherenceTrendMonarchVO();
			PatientComplianceMonarch compliance = complianceMap.get(date);
			trendVO.setDate(date);
			trendVO.setUpdatedScore(compliance.getScore());
			ProtocolRevisionMonarchVO revisionVO = getProtocolRevisionByCompliance(
					revisionData, compliance);
			revisionVO.addAdherenceTrend(trendVO);
		}
		List<ProtocolRevisionMonarchVO> revisions = revisionData.values().stream().filter(rev -> rev.getAdherenceTrends().size() > 0).collect(Collectors.toList());		
		return revisions;
	}

	private ProtocolRevisionMonarchVO getProtocolRevisionByCompliance(
			SortedMap<DateTime, ProtocolRevisionMonarchVO> revisionData,
			PatientComplianceMonarch compliance) {
		DateTime processedTime = Objects.nonNull(compliance.getLastModifiedDate()) ? compliance.getLastModifiedDate() : compliance.getDate().toDateTimeAtStartOfDay().plusHours(23).plusMinutes(59);
		// Get the recent protocol revisions before the processed time of compliance
		SortedMap<DateTime,ProtocolRevisionMonarchVO> recentRevisionMap = revisionData.headMap(processedTime);
		ProtocolRevisionMonarchVO revisionVO = null;
		// if there is revision use the revision else use the default revision
		if(Objects.nonNull(recentRevisionMap) && recentRevisionMap.size() > 0){
			revisionVO = recentRevisionMap.get(recentRevisionMap.lastKey());
		}else{
			revisionVO = revisionData.get(revisionData.firstKey());
		}
		return revisionVO;
	}
	
	public Map<Long,List<PatientComplianceMonarch>> getPatientComplainceMapByPatientUserId(List<Long> patientUserIds,LocalDate from,LocalDate to){
		List<PatientComplianceMonarch> complianceList = complianceMonarchRepository.findByDateBetweenAndPatientUserIdIn(from, to, patientUserIds);
		Map<Long,List<PatientComplianceMonarch>> complianceMap = new HashMap<>();
		for(PatientComplianceMonarch compliance: complianceList){
			List<PatientComplianceMonarch> complianceListForUserId = complianceMap.get(compliance.getPatientUser().getId());
			if(Objects.isNull(complianceListForUserId)){
				complianceListForUserId = new LinkedList<>();
			}
			complianceListForUserId.add(compliance);
			complianceMap.put(compliance.getPatientUser().getId(), complianceListForUserId);
		}
		return complianceMap;
	}
	
}
