package com.hillrom.monarch.service;

import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateCumulativeDuration;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateHMRRunRatePerSession;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateHMRRunRatePerSessionBoth;
import static com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch.calculateWeightedAvg;
import static com.hillrom.vest.config.AdherenceScoreConstants.ADHERENCE_SETTING_DEFAULT_DAYS;
import static com.hillrom.vest.config.AdherenceScoreConstants.BONUS_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.config.AdherenceScoreConstants.HMR_NON_COMPLIANCE_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.LOWER_BOUND_VALUE;
import static com.hillrom.vest.config.AdherenceScoreConstants.MISSED_THERAPY_DAYS_COUNT_THRESHOLD;
import static com.hillrom.vest.config.Constants.MONARCH;
import static com.hillrom.vest.config.Constants.VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.ADHERENCE_SCORE_RESET;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_MONARCH_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_VEST_AND_SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.config.NotificationTypeConstants.MISSED_THERAPY;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION_MONARCH;
import static com.hillrom.vest.config.NotificationTypeConstants.SETTINGS_DEVIATION_VEST;
import static com.hillrom.vest.service.util.DateUtil.getDateBeforeSpecificDays;
import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateCumulativeDuration;
import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateHMRRunRatePerSession;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.repository.AdherenceResetMonarchRepository;
import com.hillrom.monarch.repository.NotificationMonarchRepository;
import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.monarch.repository.PatientMonarchDeviceRepository;
import com.hillrom.monarch.repository.PatientNoEventsMonarchRepository;
import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.vest.domain.AdherenceResetMonarch;
import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.Notification;
import com.hillrom.vest.domain.NotificationMonarch;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.NotificationRepository;
import com.hillrom.vest.repository.PatientComplianceRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientNoEventsRepository;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.service.AdherenceCalculationService;
import com.hillrom.vest.service.AdvanceAdherenceCalculationService;
import com.hillrom.vest.service.ClinicPatientService;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.PatientComplianceService;
import com.hillrom.vest.service.PatientNoEventService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.TherapySessionService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.web.rest.dto.AdherenceResetDTO;

@Service
@Transactional
public class AdherenceCalculationServiceMonarch{

	private static final String TOTAL_DURATION = "totalDuration";

	private static final String WEIGHTED_AVG_INTESITY = "weightedAvgIntensity";

	private static final String WEIGHTED_AVG_FREQUENCY = "weightedAvgFrequency";
	
	private static final String DAILY = "Daily";

	@Inject
	private PatientProtocolMonarchService protocolMonarchService;
	
	@Inject
	private TherapySessionMonarchRepository therapySessionMonarchRepository;
	
	@Inject
	private PatientComplianceMonarchRepository patientComplianceMonarchRepository;
	
	@Inject
	private NotificationMonarchRepository notificationMonarchRepository;
	
	@Inject
	private MailService mailService;
	
	@Inject
	private NotificationMonarchService notificationMonarchService;
	
	@Inject
	private PatientComplianceMonarchService complianceMonarchService;
	
	@Inject
	private PatientNoEventMonarchService noEventMonarchService;
	
	@Inject
	private PatientNoEventService noEventMonarchServiceVest;
	
	@Inject
	private ClinicPatientService clinicPatientService;
	
	@Inject
	private UserService userService;
	
	//hill-1956
	@Inject
	private AdherenceResetMonarchRepository adherenceResetMonarchRepository;
	//hill-1956
	
	@Inject
	@Lazy
	private AdherenceCalculationService adherenceCalculationService;
	
	@Inject
	private PatientComplianceService complianceService;
	
	@Inject
	private PatientNoEventsRepository patientNoEventRepository;

	@Inject
	private PatientProtocolService protocolVestService;
	
	@Inject
	@Lazy
	private TherapySessionService therapySessionService;
	
	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;
	
	@Inject
	private PatientComplianceRepository patientComplianceRepository;
	
	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	@Inject
	private NotificationRepository notificationRepository;
	
	@Inject
	private TherapySessionRepository therapySessionRepository;
	
	@Inject
	@Lazy
	private TherapySessionServiceMonarch therapySessionMonarchService;
	

	@Inject
	private PatientNoEventsRepository noEventRepository;
	
	@Inject
	private PatientNoEventsMonarchRepository noEventRepositoryMonarch;

	@Inject
    private PatientMonarchDeviceRepository patientMonarchDeviceRepository;
	
	@Inject
    private PatientNoEventService noEventService;
  
@Inject
    private PatientProtocolMonarchRepository patientProtocolMonarchRepository;
	
	@Inject
    private PatientProtocolRepository patientProtocolRepository;
	
	@Inject
	private AdherenceCalcMonarchNotificationHelper adherenceCalcMonarchNotificationHelper;
	
	@Inject
	private AdvanceAdherenceCalculationService advanceAdherenceCalculationService;
	
	@Inject 
	private AdvanceAdherenceCalculationServiceMonarch advanceAdherenceCalculationServiceMonarch;
	
	private final Logger log = LoggerFactory.getLogger(AdherenceCalculationServiceMonarch.class);
	
	/**
	 * Get Protocol Constants by loading Protocol data
	 * @param patientUserId
	 * @return
	 */
	public ProtocolConstantsMonarch getProtocolByPatientUserId(
			Long patientUserId) throws Exception{
		List<Long> patientUserIds = new LinkedList<>();
		patientUserIds.add(patientUserId);
		Map<Long,ProtocolConstantsMonarch> userIdProtolConstantsMap = protocolMonarchService.getProtocolByPatientUserIds(patientUserIds);
		return userIdProtolConstantsMap.get(patientUserId);
	}

	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsMonarch protocolConstant,
			double actualTotalDurationSettingDays, 
			Integer adherenceSettingDay) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstant
				.getMinDuration()) ? protocolConstant.getMinDuration()
				: protocolConstant.getTreatmentsPerDay()
						* protocolConstant.getMinMinutesPerTreatment();
		if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays/adherenceSettingDay)){
			return false;
		}
		return true;
	}
	
	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstantMonarch
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsMonarch protocolConstantMonarch,
			ProtocolConstants protocolConstantVest,
			double actualTotalDurationSettingDays, 
			Integer adherenceSettingDay) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstantMonarch
				.getMinDuration()) ? protocolConstantMonarch.getMinDuration()
				: protocolConstantMonarch.getTreatmentsPerDay()
						* protocolConstantMonarch.getMinMinutesPerTreatment();
		
		// Getting the minimum reading from the vest protocol		
		int minHMRReadingVest = Objects.nonNull(protocolConstantVest
				.getMinDuration()) ? protocolConstantVest.getMinDuration()
				: protocolConstantVest.getTreatmentsPerDay()
						* protocolConstantVest.getMinMinutesPerTreatment();

		// Take the least from both the protocols minimum HMR from Vest and Monarch
			if(minHMRReading > minHMRReadingVest){
				minHMRReading = minHMRReadingVest;
			}		
		if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays/adherenceSettingDay)){
			return false;
		}
		return true;
	}

	/**
	 * Checks Whether Settings deviated(protocol.minFrequency < actualWeightedAvgFreq)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isSettingsDeviated(ProtocolConstantsMonarch protocolConstant,
			double weightedAvgFrequency) {
		if((protocolConstant.getMinFrequency()* LOWER_BOUND_VALUE) > weightedAvgFrequency){
			return true;
		}
		return false;
	}

	/**
	 * Calculates Metrics such as weightedAvgFrequency,Intensity,treatmentsPerDay,duration for last adherence setting days
	 * @param therapySessionsPerDay
	 * @return
	 */
	public Map<String,Double> calculateTherapyMetricsPerSettingDays(
			List<TherapySessionMonarch> therapySessionsPerDay) {
		double totalDuration = calculateCumulativeDuration(therapySessionsPerDay);
		double weightedAvgFrequency = 0f;
		double weightedAvgIntensity = 0f;
		for(TherapySessionMonarch therapySession : therapySessionsPerDay){
			int durationInMinutes = therapySession.getDurationInMinutes(); 
			weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
			weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getIntensity());
		}
		Map<String,Double> actualMetrics = new HashMap<>();
		weightedAvgFrequency = Math.round(weightedAvgFrequency);
		weightedAvgIntensity = Math.round(weightedAvgIntensity);
		actualMetrics.put(WEIGHTED_AVG_FREQUENCY, weightedAvgFrequency);
		actualMetrics.put(WEIGHTED_AVG_INTESITY, weightedAvgIntensity);
		actualMetrics.put(TOTAL_DURATION, totalDuration);
		return actualMetrics;
	}

	/**
	 * Calculates Metrics such as weightedAvgFrequency,Intensity,treatmentsPerDay,duration for last adherence setting days
	 * @param therapySessionsPerDay
	 * @return
	 */
	public Map<String,Double> calculateTherapyMetricsPerSettingDaysBoth(
			Map<String, Object> combined) {
		
		@SuppressWarnings("unchecked")
		List<TherapySessionMonarch> therapySessionsPerDay = (List<TherapySessionMonarch>) combined.get("Monarch");
		@SuppressWarnings("unchecked")
		List<TherapySession> therapySessionsPerDayVest = (List<TherapySession>) combined.get("Vest");
		
		int durationVest = 0,durationMonarch=0;
		
		if(Objects.nonNull(therapySessionsPerDay) && therapySessionsPerDay.size() != 0)
			durationMonarch = calculateCumulativeDuration(therapySessionsPerDay);
		
		if(Objects.nonNull(therapySessionsPerDayVest) && therapySessionsPerDayVest.size() != 0)
			durationVest = calculateCumulativeDuration(therapySessionsPerDayVest);
		
		double totalDuration = durationVest + durationMonarch;
		
		double weightedAvgFrequency = 0f;
		double weightedAvgIntensity = 0f;
		
		if(Objects.nonNull(therapySessionsPerDay) && therapySessionsPerDay.size() != 0){
			for(TherapySessionMonarch therapySession : therapySessionsPerDay){
				int durationInMinutes = therapySession.getDurationInMinutes(); 
				weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
				weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getIntensity());
			}
		}
		
		if(Objects.nonNull(therapySessionsPerDayVest) && therapySessionsPerDayVest.size() != 0){
			for(TherapySession therapySession : therapySessionsPerDayVest){
				int durationInMinutes = therapySession.getDurationInMinutes(); 
				weightedAvgFrequency += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getFrequency());
				weightedAvgIntensity += calculateWeightedAvg(totalDuration,durationInMinutes,therapySession.getPressure());
			}
		}
		
		Map<String,Double> actualMetrics = new HashMap<>();
		weightedAvgFrequency = Math.round(weightedAvgFrequency);
		weightedAvgIntensity = Math.round(weightedAvgIntensity);
		actualMetrics.put(WEIGHTED_AVG_FREQUENCY, weightedAvgFrequency);
		actualMetrics.put(WEIGHTED_AVG_INTESITY, weightedAvgIntensity);
		actualMetrics.put(TOTAL_DURATION, totalDuration);
		
		return actualMetrics;
	}
	
	/**
	 * Runs every midnight deducts the compliance score by 5 if therapy hasn't been done for adherence setting day(s)
	 */
	@Scheduled(cron="${cron.adherence.monarch.missedtherapy}")	
	public void processMissedTherapySessionsMonarch(){
		LocalDate date = LocalDate.now();
		adherenceCalcMonarchNotificationHelper.processMissedTherapySessionsMonarchImpl(date);
	}
	
	public LocalDate fineOneByPatientUserIdLatestResetStartDate(Long userId){    	
    	List<AdherenceResetMonarch> adherenceReset = adherenceResetMonarchRepository.findOneByPatientUserIdLatestResetStartDate(userId);
    	if(adherenceReset.size() > 0)
    		return adherenceReset.get(0).getResetStartDate();
    	else
    		return null;
    }
	
	// Getting the therapy data for the requested date
	public List<TherapySessionMonarch> getTherapyForDay(SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapySession,LocalDate curDate){		
		return sortedTherapySession.get(curDate);
	}
	
	// Getting the therapy data for the requested between period 
	public List<TherapySessionMonarch> getTherapyforBetweenDates(LocalDate fromDate, LocalDate toDate, SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapySession){
		List<TherapySessionMonarch> session = new LinkedList<>();
		
		List<LocalDate> allDates = DateUtil.getAllLocalDatesBetweenDates(fromDate, toDate);
		
		for(LocalDate date : allDates){
			
			if(Objects.nonNull(sortedTherapySession.get(date)))
				session.addAll(sortedTherapySession.get(date));
		}
		
		return session;
	}
	
	// Getting the compliance object for the previous date / previous record 
	public PatientComplianceMonarch returnPrevDayCompli(List<PatientComplianceMonarch> complianceList, LocalDate currDate){
		
		int j = -1;
		for(int i = 0; i <= (complianceList.size()-1); i++){
			if(complianceList.get(i).getDate() == currDate){				
				j = i;
			}
		}
		return (j > 0 ? complianceList.get(j-1) : null);
	}
	
	// Grouping the therapy data by date 
	public SortedMap<LocalDate,List<TherapySessionMonarch>> groupTherapySessionsByDate(List<TherapySessionMonarch> therapySessions){
		return new TreeMap<>(therapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch :: getDate)));
	}
	
	// Resetting the adherence score for the specific user from the adherence reset start date	
	public String adherenceResetForPatient(Long userId, String patientId, LocalDate adherenceStartDate, Integer adherenceScore, Integer resetFlag){
		try{
			
			// Adherence Start date in string for query
			String sAdherenceStDate = adherenceStartDate.toString();
			
			LocalDate todayDate = LocalDate.now();
			LocalDate prevDate = DateUtil.getPlusOrMinusTodayLocalDate(-1);
			
			LocalDate prevAdherenceStartDate = DateUtil.getPlusOrMinusDate(-1, adherenceStartDate);
			String prevAdherenceStartDateString = prevAdherenceStartDate.toString();
			
			// Get the list of rows for the user id from the adherence reset start date 
			List<PatientComplianceMonarch> patientComplianceList = patientComplianceMonarchRepository.returnComplianceForPatientIdDates((resetFlag == 3 ? prevAdherenceStartDateString : sAdherenceStDate), userId);
			
			List<PatientComplianceMonarch> complianceListToStore = new LinkedList<>();
			
			// Getting the protocol constants for the user
			ProtocolConstantsMonarch userProtocolConstant = protocolMonarchService.getProtocolForPatientUserId(userId);
			
			// Getting all the sessions of user from the repository 
			List<TherapySessionMonarch> therapySessionData = therapySessionMonarchRepository.findByPatientUserId(userId);
			// grouping all the therapy sessions to the date
			SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapy = groupTherapySessionsByDate(therapySessionData);
			
			// Getting all the notification for the user 
			List<NotificationMonarch> userNotifications = notificationMonarchRepository.findByPatientUserId(userId);			
			
			int adherenceSettingDay = getAdherenceSettingForUserId(userId);
			
			for(PatientComplianceMonarch currentCompliance : patientComplianceList){
				
				if(resetFlag == 0 || resetFlag == 1 || resetFlag == 2 || (resetFlag == 3 && !currentCompliance.getDate().isBefore(adherenceStartDate))){
				
					PatientInfo patient = currentCompliance.getPatient();
					User patientUser = currentCompliance.getPatientUser();
					int initialPrevScoreFor1Day = 0;
					
					NotificationMonarch existingNotificationofTheDay = notificationMonarchService.getNotificationForDay(userNotifications, currentCompliance.getDate());
					
					if( ( adherenceStartDate.isBefore(currentCompliance.getDate()) || adherenceStartDate.equals(currentCompliance.getDate())) &&
							DateUtil.getDaysCountBetweenLocalDates(adherenceStartDate, currentCompliance.getDate()) < (adherenceSettingDay-1) && 
							adherenceSettingDay > 1 && resetFlag != 3){
								
						// Check whether the adherence start days is the compliance date
						if(adherenceStartDate.equals(currentCompliance.getDate())){
							if(resetFlag == 1 || (resetFlag == 2 && adherenceSettingDay != 1)){							 
								notificationMonarchService.createOrUpdateNotification(patientUser, patient, userId,
																			currentCompliance.getDate(), ADHERENCE_SCORE_RESET, false, existingNotificationofTheDay,ADHERENCE_SCORE_RESET);
							}else{
								if(Objects.nonNull(existingNotificationofTheDay))
									notificationMonarchRepository.delete(existingNotificationofTheDay);
							}
							currentCompliance.setSettingsDeviatedDaysCount(0);
							currentCompliance.setMissedTherapyCount(0);
						} else {
							
							// Commenting the existing repository call and calling the the new method for getting the previous day compliance
							
							PatientComplianceMonarch prevCompliance = returnPrevDayCompli(patientComplianceList, currentCompliance.getDate());
							if(Objects.isNull(prevCompliance)){
								prevCompliance = new PatientComplianceMonarch();
								prevCompliance.setScore(adherenceScore);
								prevCompliance.setSettingsDeviatedDaysCount(0);
								prevCompliance.setMissedTherapyCount(0);
							}
							
							if(currentCompliance.getMissedTherapyCount() > 0){
								currentCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
							}
							if(isSettingDeviatedForUserOnDay(userId, currentCompliance.getDate() ,adherenceSettingDay, userProtocolConstant)){
								currentCompliance.setSettingsDeviatedDaysCount(prevCompliance.getSettingsDeviatedDaysCount()+1);
							}
							
							// Commenting the existing repository call and calling the new method for getting the current day notification at beginning of for loop
							
							
							if(Objects.nonNull(existingNotificationofTheDay)){
								notificationMonarchRepository.delete(existingNotificationofTheDay);
							}
						}
						currentCompliance.setScore(adherenceScore);
						
						complianceListToStore.add(currentCompliance);
					}else{
						
						
						PatientComplianceMonarch prevCompliance = returnPrevDayCompli(patientComplianceList, currentCompliance.getDate());
						if(Objects.isNull(prevCompliance)){
							prevCompliance = new PatientComplianceMonarch();
							prevCompliance.setScore(adherenceScore);
							prevCompliance.setSettingsDeviatedDaysCount(0);
							prevCompliance.setMissedTherapyCount(0);
						}
						
						// Commenting the existing repository call and calling the the new method for getting the current day therapy details				
										
						List<TherapySessionMonarch> therapyData = new LinkedList<>();
						therapyData = getTherapyForDay(sortedTherapy, currentCompliance.getDate());
						
						if(adherenceSettingDay == 1 && adherenceStartDate.equals(currentCompliance.getDate())){
							initialPrevScoreFor1Day = adherenceScore;
						}
						// Verifying missed therapy count is greater than the adherence window and not having therapy for today  
						if(currentCompliance.getMissedTherapyCount() >= adherenceSettingDay && 
								!currentCompliance.getDate().equals(todayDate) && 
									( Objects.isNull(therapyData) || 
											(Objects.nonNull(therapyData) && therapyData.isEmpty()) )){
							// Adding the prevCompliance object for previous day compliance and existingNotificationofTheDay object for the current date Notification object
							// Missed therapy days
				//			complianceListToStore.add(calculateUserMissedTherapy(currentCompliance,currentCompliance.getDate(), userId, patient, patientUser, initialPrevScoreFor1Day, prevCompliance, existingNotificationofTheDay));
							complianceListToStore.add(calculateUserHMROnMissedTherapyDays(currentCompliance,currentCompliance.getDate(), userId, patient, patientUser, initialPrevScoreFor1Day, prevCompliance, 
									existingNotificationofTheDay,adherenceSettingDay,userProtocolConstant,sortedTherapy));					
						}else if( ( Objects.isNull(therapyData) || 
										(Objects.nonNull(therapyData) && therapyData.isEmpty()) ) && 
											currentCompliance.getDate().equals(todayDate) ){
							// Passing prevCompliance for avoiding the repository call to retrieve the previous day compliance
							// Setting the previous day compliance details for the no therapy done for today 
							complianceListToStore.add(setPrevDayCompliance(currentCompliance, userId, prevCompliance));
						}else{
							// Adding the sortedTherapy for all the therapies & prevCompliance object for previous day compliance and existingNotificationofTheDay object for the current date Notification object
							// HMR Non Compliance / Setting deviation & therapy data available
							complianceListToStore.add(calculateUserHMRComplianceForMST(currentCompliance, userProtocolConstant, currentCompliance.getDate(), userId, 
									patient, patientUser, adherenceSettingDay, initialPrevScoreFor1Day,sortedTherapy, prevCompliance, existingNotificationofTheDay, resetFlag));
						}
					}
				}
			}
			complianceMonarchService.saveAll(complianceListToStore);
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("resetAdherenceCalculationPatientMonarch",writer.toString());
		}
		return "Adherence score reset successfully";
	}

	// Grouping the Patient Compliance Monarch data by date 
	public SortedMap<LocalDate,List<PatientComplianceMonarch>> groupPatientComplianceByDate(List<PatientComplianceMonarch> patientComplianceMonarch){
		return new TreeMap<>(patientComplianceMonarch.stream().collect(Collectors.groupingBy(PatientComplianceMonarch :: getDate)));
	}
		

	public String adherenceCalculationBoth(Long userId, String patientId, LocalDate adherenceStartDate, 
			LocalDate firstTransmissionOfOldDevice, Integer adherenceScore, Long oldUserId, Integer flag){
		// flag 1 - for adherence reset
		// flag 2 - for adherence setting / window
		// flag 3 - vest ingestion
		// flag 4 - monarch ingestion		
		
		try{			
			// Adherence Start date in string for query
			String sAdherenceStDate = adherenceStartDate.toString();
			
			LocalDate todayDate = LocalDate.now();
			
			LocalDate prevAdherenceStartDate = DateUtil.getPlusOrMinusDate(-1, adherenceStartDate);
			String prevAdherenceStartDateString = prevAdherenceStartDate.toString();
						
			// Get the list of rows for the user id from the adherence reset start date 
			List<PatientComplianceMonarch> patientComplianceList = patientComplianceMonarchRepository.returnComplianceForPatientIdDates((flag == 3 || flag == 4 ? prevAdherenceStartDateString : sAdherenceStDate), userId);
			
			List<PatientComplianceMonarch> complianceListToStore = new LinkedList<>();
			
			// Getting the protocol constants for the user
			ProtocolConstantsMonarch userProtocolConstant = protocolMonarchService.getProtocolForPatientUserId(oldUserId);
			
			// Getting all the sessions of user from the repository 
			List<TherapySessionMonarch> therapySessionData = therapySessionMonarchRepository.findByPatientUserId(oldUserId);
			// grouping all the therapy sessions to the date
			SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapy = groupTherapySessionsByDate(therapySessionData);
			
			// Getting all the notification for the user 
			List<NotificationMonarch> userNotifications = notificationMonarchRepository.findByPatientUserId(userId);			
			
			
			// Getting the protocol constants for the user for vest
			ProtocolConstants userProtocolConstantVest = protocolVestService.getProtocolForPatientUserId(userId);
			
				
			// Getting all the sessions of user from the repository for vest 
			List<TherapySession> therapySessionDataVest = therapySessionRepository.findByPatientUserId(userId);
			// grouping all the therapy sessions to the date for vest
			SortedMap<LocalDate,List<TherapySession>> sortedTherapyVest = adherenceCalculationService.groupTherapySessionsByDate(therapySessionDataVest);
			
			
			int adherenceSettingDay = getAdherenceSettingForUserId(userId);
			
			for(PatientComplianceMonarch currentCompliance : patientComplianceList){
				
				if(!currentCompliance.getDate().isBefore(adherenceStartDate)){
				
					PatientInfo patient = currentCompliance.getPatient();
					User patientUser = currentCompliance.getPatientUser();
					int initialPrevScoreFor1Day = 0;
					
					NotificationMonarch existingNotificationofTheDay = notificationMonarchService.getNotificationForDay(userNotifications, currentCompliance.getDate());						
					
					if( ( adherenceStartDate.isBefore(currentCompliance.getDate()) || adherenceStartDate.equals(currentCompliance.getDate())) &&
								DateUtil.getDaysCountBetweenLocalDates(adherenceStartDate, currentCompliance.getDate()) < (adherenceSettingDay-1) && 
								adherenceSettingDay > 1 && (flag != 3 && flag != 4)){		
						
						if(adherenceStartDate.equals(currentCompliance.getDate())){
							
							if(flag == 1 || (flag == 2 && adherenceSettingDay != 1)){
								notificationMonarchService.createOrUpdateNotification(patientUser, patient, userId,
										currentCompliance.getDate(), ADHERENCE_SCORE_RESET, false, existingNotificationofTheDay,ADHERENCE_SCORE_RESET);
							}else{
								if(Objects.nonNull(existingNotificationofTheDay))
									notificationMonarchRepository.delete(existingNotificationofTheDay);
							}
							
							currentCompliance.setSettingsDeviatedDaysCount(0);
							currentCompliance.setMissedTherapyCount(0);
						} else {							
							PatientComplianceMonarch prevCompliance = returnPrevDayCompli(patientComplianceList, currentCompliance.getDate());
							if(Objects.isNull(prevCompliance)){
								prevCompliance = new PatientComplianceMonarch();
								prevCompliance.setScore(adherenceScore);
								prevCompliance.setSettingsDeviatedDaysCount(0);
								prevCompliance.setMissedTherapyCount(0);
							}
							
							if(currentCompliance.getMissedTherapyCount() > 0){
								currentCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
							}
							if(isSettingDeviatedForUserOnDay(userId, currentCompliance.getDate() ,adherenceSettingDay, userProtocolConstant)){
								currentCompliance.setSettingsDeviatedDaysCount(prevCompliance.getSettingsDeviatedDaysCount()+1);
							}
							
							// Commenting the existing repository call and calling the new method for getting the current day notification at beginning of for loop
							
							
							if(Objects.nonNull(existingNotificationofTheDay)){
								notificationMonarchRepository.delete(existingNotificationofTheDay);
							}
						}
						currentCompliance.setScore(adherenceScore);						
						complianceListToStore.add(currentCompliance);
					}else{
				
						if((flag != 3 && flag != 4) || ((flag == 3 || flag == 4) && 
								(DateUtil.getDaysCountBetweenLocalDates(adherenceStartDate, currentCompliance.getDate()) > (adherenceSettingDay-1) || 
								DateUtil.getDaysCountBetweenLocalDates(firstTransmissionOfOldDevice, currentCompliance.getDate()) > (adherenceSettingDay-1)))){
							
							PatientComplianceMonarch prevCompliance = returnPrevDayCompli(patientComplianceList, currentCompliance.getDate());
							if(Objects.isNull(prevCompliance)){
								prevCompliance = new PatientComplianceMonarch();
								prevCompliance.setScore(adherenceScore);
								prevCompliance.setSettingsDeviatedDaysCount(0);
								prevCompliance.setMissedTherapyCount(0);
							}
							
							List<TherapySessionMonarch> therapyData = new LinkedList<>();
							List<TherapySession> therapyDataVest = new LinkedList<>();
							
							therapyData = getTherapyForDay(sortedTherapy, currentCompliance.getDate());
							therapyDataVest = adherenceCalculationService.getTherapyForDay(sortedTherapyVest, currentCompliance.getDate());
							
							if((flag != 3 && flag != 4) && adherenceSettingDay == 1 && adherenceStartDate.equals(currentCompliance.getDate())){
								initialPrevScoreFor1Day = adherenceScore;
							}
							if(prevCompliance.getMissedTherapyCount() >= (adherenceSettingDay-1) && 
									currentCompliance.getMissedTherapyCount() >= adherenceSettingDay && 
									!currentCompliance.getDate().equals(todayDate) && 
									(Objects.isNull(therapyDataVest) || therapyDataVest.isEmpty()) && 
									(Objects.isNull(therapyData) || therapyData.isEmpty()) ){							
								// Adding the prevCompliance object for previous day compliance and existingNotificationofTheDay object for the current date Notification object
								// Missed therapy days
								/*complianceListToStore.add(calculateUserMissedTherapy(currentCompliance,currentCompliance.getDate(), userId, patient, 
										patientUser, initialPrevScoreFor1Day, prevCompliance, existingNotificationofTheDay));*/
								complianceListToStore.add(calculateUserHMROnMissedTherapyDays(currentCompliance,currentCompliance.getDate(), userId, patient, 
										patientUser, initialPrevScoreFor1Day, prevCompliance, existingNotificationofTheDay,adherenceSettingDay,userProtocolConstant,sortedTherapy));
							}else if( (Objects.isNull(therapyData) || therapyData.isEmpty()) && 
									(Objects.isNull(therapyDataVest) || therapyDataVest.isEmpty()) && 
									currentCompliance.getDate().equals(todayDate)){						
								// Passing prevCompliance for avoiding the repository call to retrieve the previous day compliance
								// Setting the previous day compliance details for the no therapy done for today 
								complianceListToStore.add(setPrevDayCompliance(currentCompliance, userId, prevCompliance));
							}else{
								// Adding the sortedTherapy for all the therapies & prevCompliance object for previous day compliance and existingNotificationofTheDay object for the current date Notification object
								// HMR Non Compliance / Setting deviation & therapy data available
								complianceListToStore.add(calculateUserHMRComplianceForMSTBoth(currentCompliance, userProtocolConstant, 
										userProtocolConstantVest, currentCompliance.getDate(), userId,patient, patientUser, adherenceSettingDay, 
										initialPrevScoreFor1Day,sortedTherapy, sortedTherapyVest, prevCompliance, existingNotificationofTheDay, flag));
							}
						
						}
					}
				
				}
			}
			complianceMonarchService.saveAll(complianceListToStore);
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("adherenceCalculationBoth",writer.toString());
		}
		return "Adherence score reset successfully";
		
	}
	
	// Setting the previous day compliance
	
	private PatientComplianceMonarch setPrevDayCompliance(PatientComplianceMonarch currentCompliance, Long userId, PatientComplianceMonarch preDayCompliance)
	{
		// Commented the repository call and getting the previous day compliance from the method parameter
		
		
		currentCompliance.setGlobalHMRNonAdherenceCounter(preDayCompliance.getGlobalHMRNonAdherenceCounter());
		currentCompliance.setGlobalMissedTherapyCounter(preDayCompliance.getGlobalMissedTherapyCounter());
		currentCompliance.setGlobalSettingsDeviationCounter(preDayCompliance.getGlobalSettingsDeviationCounter());
		currentCompliance.setHmr(preDayCompliance.getHmr());
		currentCompliance.setHmrCompliant(preDayCompliance.isHmrCompliant());
		currentCompliance.setHmrRunRate(preDayCompliance.getHmrRunRate());
		currentCompliance.setLatestTherapyDate(preDayCompliance.getLatestTherapyDate());
		currentCompliance.setMissedTherapyCount(preDayCompliance.getMissedTherapyCount());
		currentCompliance.setScore(preDayCompliance.getScore());
		currentCompliance.setSettingsDeviated(preDayCompliance.isSettingsDeviated());
		currentCompliance.setSettingsDeviatedDaysCount(preDayCompliance.getSettingsDeviatedDaysCount());
		
		
		return currentCompliance;
		
	}
	
	private void updateGlobalCounters(int globalMissedTherapyCounter,
			int globalHMRNonAdherenceCounter,
			int globalSettingsDeviationCounter, PatientComplianceMonarch newCompliance) {
		newCompliance.setGlobalMissedTherapyCounter(globalMissedTherapyCounter);
		newCompliance.setGlobalHMRNonAdherenceCounter(globalHMRNonAdherenceCounter);
		newCompliance.setGlobalSettingsDeviationCounter(globalSettingsDeviationCounter);
	}
	
	// calculate HMRCompliance on Missed Therapy Date for Per UserId
	//private void calculateUserHMRComplianceForMST(
	private PatientComplianceMonarch calculateUserHMRComplianceForMST(
			PatientComplianceMonarch newCompliance,
			ProtocolConstantsMonarch userProtocolConstants,
			LocalDate complianceDate,
			Long userId,
			PatientInfo patient,
			User patientUser,
			Integer adherenceSettingDay,
			int initialPrevScoreFor1Day,
			SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapy,
			PatientComplianceMonarch prevCompliance,
			NotificationMonarch existingNotificationofTheDay,
			Integer resetFlag) {
		
		// Commented the repository call for previous day compliance and getting the prevCompliance from the method parameter
		// Getting previous day score or adherence reset score for the adherence setting value as 1
		
		int score = initialPrevScoreFor1Day == 0 ? prevCompliance.getScore() : initialPrevScoreFor1Day;
		
		// Get earlier third day to finding therapy session
		LocalDate adherenceSettingDaysEarlyDate = getDateBeforeSpecificDays(complianceDate,(adherenceSettingDay-1));
		
		//Commented the repository call for current day therapy session and getting the same from the method parameter and the calling method
		// Get therapy session for last adherence Setting days
		
		List<TherapySessionMonarch> therapySessions = getTherapyforBetweenDates(adherenceSettingDaysEarlyDate, complianceDate, sortedTherapy);
				
		if(Objects.isNull(therapySessions)){
			therapySessions = new LinkedList<>();
		}
		
		int hmrRunRate = calculateHMRRunRatePerSession(therapySessions);
		newCompliance.setHmrRunRate(hmrRunRate);
		double durationForSettingDays = hmrRunRate*therapySessions.size(); // runrate*totalsessions = total duration
		
		String notification_type = "";
		String complianceType = "";
		boolean isSettingsDeviated = isSettingsDeviatedForSettingDays(therapySessions, userProtocolConstants, adherenceSettingDay);
		
		// validating the last adherence setting days therapies with respect to the user protocol
		if(!isHMRCompliant(userProtocolConstants, durationForSettingDays, adherenceSettingDay)){
			score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;
			
			complianceType = HMR_NON_COMPLIANCE;
			
			int globalHMRNonAdhrenceCounter = prevCompliance.getGlobalHMRNonAdherenceCounter();
			newCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdhrenceCounter);
			
			notification_type = HMR_NON_COMPLIANCE;

			newCompliance.setHmrCompliant(false);
			
			if(isSettingsDeviated){
				notification_type = HMR_AND_SETTINGS_DEVIATION;				
			}

		}else if(isSettingsDeviated){
	//		score = score < SETTING_DEVIATION_POINTS ? 0 : score - SETTING_DEVIATION_POINTS;
			notification_type = SETTINGS_DEVIATION;
			
			// Previous day setting deviation count / 0 for 1 day adherence setting 
			int setDeviationCount = initialPrevScoreFor1Day == 0 ? prevCompliance.getSettingsDeviatedDaysCount() : 0;			
			newCompliance.setSettingsDeviatedDaysCount(setDeviationCount+1);
			
			int globalSettingsDeviationCounter = prevCompliance.getGlobalSettingsDeviationCounter();
			newCompliance.setGlobalSettingsDeviationCounter(++globalSettingsDeviationCounter);
		}else if(StringUtils.isBlank(complianceType)){
			score = score <=  DEFAULT_COMPLIANCE_SCORE - BONUS_POINTS ? score + BONUS_POINTS : DEFAULT_COMPLIANCE_SCORE;
			//notification_type = ADHERENCE_SCORE_RESET;
			
			if(Objects.nonNull(existingNotificationofTheDay))
				notificationMonarchRepository.delete(existingNotificationofTheDay);
			newCompliance.setScore(score);
			newCompliance.setMissedTherapyCount(0);
			return newCompliance;
		}
		
		if(resetFlag == 1 || (resetFlag == 2 && adherenceSettingDay != 1)){
			notification_type = initialPrevScoreFor1Day == 0 ? notification_type : ADHERENCE_SCORE_RESET;
		}			
		
		// Added the existingNotificationofTheDay param for passing the notification object for the current date
		notificationMonarchService.createOrUpdateNotification(patientUser, patient, userId,
				complianceDate, notification_type, false, existingNotificationofTheDay,complianceType);
		
		// Setting the new score with respect to the compliance deduction
		newCompliance.setScore(score);
		
		if(Objects.isNull(sortedTherapy.get(complianceDate))){
			// Setting the missed therapy count to 0, since having therapy
			newCompliance.setMissedTherapyCount(0);
		}
		
		// Saving the updated score for the specific date of compliance		
		return newCompliance;
	}
	
	/**
	 * Calculate HMR on Missed therapy Days
	 * @param newCompliance
	 * @param complianceDate
	 * @param userId
	 * @param patient
	 * @param patientUser
	 * @param initialPrevScoreFor1Day
	 * @param prevCompliance
	 * @param existingNotificationofTheDay
	 * @param adherenceSettingDay
	 * @param userProtocolConstants
	 * @param sortedTherapy
	 * @return
	 */
	private PatientComplianceMonarch calculateUserHMROnMissedTherapyDays(
			PatientComplianceMonarch newCompliance,
			LocalDate complianceDate,
			Long userId,
			PatientInfo patient,
			User patientUser,
			int initialPrevScoreFor1Day,
			PatientComplianceMonarch prevCompliance,
			NotificationMonarch existingNotificationofTheDay,
			Integer adherenceSettingDay,
			ProtocolConstantsMonarch userProtocolConstants,
			SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapy) {
				
		String notification_type = null;
		String compliance_type = null;
		
		
		// Commenting the repository call for previous day compliance by passing prevCompliance in the parameter
		// Getting previous day score or adherence reset score for the adherence setting value as 1
		//PatientCompliance prevCompliance = patientComplianceRepository.returnPrevDayScore(complianceDate.toString(),userId);
		
		int score = initialPrevScoreFor1Day == 0 ? prevCompliance.getScore() : initialPrevScoreFor1Day; 
		
		LocalDate adherenceSettingDaysEarlyDate = getDateBeforeSpecificDays(complianceDate,(adherenceSettingDay-1));
		
		//Commented the repository call for current day therapy session and getting the same from the method parameter and the calling method
		// Get therapy session for last adherence Setting days
		// List<TherapySession> therapySessions = therapySessionRepository.findByDateBetweenAndPatientUserId(adherenceSettingDaysEarlyDate, complianceDate, userId);
		List<TherapySessionMonarch> therapySessions = getTherapyforBetweenDates(adherenceSettingDaysEarlyDate, complianceDate, sortedTherapy);
				
		if(Objects.isNull(therapySessions)){
			therapySessions = new LinkedList<>();
		}
		
		int hmrRunRate = calculateHMRRunRatePerSession(therapySessions);
		newCompliance.setHmrRunRate(hmrRunRate);
		double durationForSettingDays = hmrRunRate*therapySessions.size(); // runrate*totalsessions = total duration
		
		int missedTherapyCount = 0;
		int globalMissedTherapyCounter = 0;
		int globalHMRNonAdhrenceCounter = 0;
		
	
		if(therapySessions.isEmpty()){

			notification_type = MISSED_THERAPY;
			missedTherapyCount = initialPrevScoreFor1Day == 0 ? prevCompliance.getMissedTherapyCount() : 0;
			newCompliance.setMissedTherapyCount(++missedTherapyCount);

			globalMissedTherapyCounter = newCompliance.getGlobalMissedTherapyCounter();
			newCompliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);

			// validating the last adherence setting days therapies with respect to the user protocol
			if(!isHMRCompliant(userProtocolConstants, durationForSettingDays, adherenceSettingDay)){

				score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;


				globalHMRNonAdhrenceCounter = prevCompliance.getGlobalHMRNonAdherenceCounter();
				newCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdhrenceCounter);

				//	notification_type = HMR_NON_COMPLIANCE;
				compliance_type= HMR_NON_COMPLIANCE;
				newCompliance.setHmrCompliant(false);
			}
		}		
		
		// existingNotificationofTheDay object of Notification is sent to avoid repository call
		// userNotifications list object is sent to the method for getting the current day object
		notificationMonarchService.createOrUpdateNotification(patientUser, patient, userId,
			complianceDate, (initialPrevScoreFor1Day == 0 ? notification_type : ADHERENCE_SCORE_RESET) , false, existingNotificationofTheDay,compliance_type);
			
		// Setting the new score with respect to the compliance deduction
		newCompliance.setScore(score);
		
		return newCompliance;
	}
	
	
	// calculate HMRCompliance on Missed Therapy Date for both devices		
	private PatientComplianceMonarch calculateUserHMRComplianceForMSTBoth(
			PatientComplianceMonarch newCompliance,
			ProtocolConstantsMonarch userProtocolConstants,
			ProtocolConstants userProtocolConstantsVest,
			LocalDate complianceDate,
			Long userId,
			PatientInfo patient,
			User patientUser,
			Integer adherenceSettingDay,
			int initialPrevScoreFor1Day,
			SortedMap<LocalDate,List<TherapySessionMonarch>> sortedTherapy,
			SortedMap<LocalDate,List<TherapySession>> sortedTherapyVest,
			PatientComplianceMonarch prevCompliance,
			NotificationMonarch existingNotificationofTheDay,
			Integer resetFlag) {
		
		// Commented the repository call for previous day compliance and getting the prevCompliance from the method parameter
		// Getting previous day score or adherence reset score for the adherence setting value as 1
		String complianceType="";
		
		int score = initialPrevScoreFor1Day == 0 ? prevCompliance.getScore() : initialPrevScoreFor1Day;
		
		// Get earlier third day to finding therapy session
		LocalDate adherenceSettingDaysEarlyDate = getDateBeforeSpecificDays(complianceDate,(adherenceSettingDay-1));
		
		//Commented the repository call for current day therapy session and getting the same from the method parameter and the calling method
		// Get therapy session for last adherence Setting days
		List<TherapySessionMonarch> therapySessions = new LinkedList<>();
		therapySessions = getTherapyforBetweenDates(adherenceSettingDaysEarlyDate, complianceDate, sortedTherapy);
		
		// Get therapy session for last adherence Setting days
		List<TherapySession> therapySessionsVest = new LinkedList<>(); 
		therapySessionsVest = adherenceCalculationService.getTherapyforBetweenDates(adherenceSettingDaysEarlyDate, complianceDate, sortedTherapyVest);
		
		int hmrRunRate = calculateHMRRunRatePerSession(therapySessions);
		
		int hmrRunRateBoth = calculateHMRRunRatePerSessionBoth(therapySessions, therapySessionsVest);
		newCompliance.setHmrRunRate(hmrRunRateBoth);
		
//		double durationForSettingDays = hmrRunRate*therapySessions.size(); // runrate*totalsessions = total duration
		
		int hmrRunRateVest = calculateHMRRunRatePerSession(therapySessionsVest);
		double durationForSettingDaysForBoth = hmrRunRateVest*therapySessionsVest.size() + hmrRunRate*therapySessions.size(); // runrate*totalsessions = total duration
		
		String notification_type = null;
		boolean isSettingsDeviatedMonarch = isSettingsDeviatedForSettingDays(therapySessions, userProtocolConstants, adherenceSettingDay);
		
		boolean isSettingsDeviatedVest = adherenceCalculationService.isSettingsDeviatedForSettingDays(therapySessionsVest, userProtocolConstantsVest, adherenceSettingDay);
		
		
//		boolean isHMRCompliantMonarch = isHMRCompliant(userProtocolConstants,userProtocolConstantsVest, durationForSettingDays, adherenceSettingDay);
		boolean isHMRCompliant = isHMRCompliant(userProtocolConstants,userProtocolConstantsVest, durationForSettingDaysForBoth, adherenceSettingDay);
		
		// validating the last adherence setting days therapies with respect to the user protocol
		if(!isHMRCompliant){
			score = score < HMR_NON_COMPLIANCE_POINTS ? 0 : score - HMR_NON_COMPLIANCE_POINTS;
			
			complianceType=HMR_NON_COMPLIANCE;
			/*int globalHMRNonAdhrenceCounter = prevCompliance.getGlobalHMRNonAdherenceCounter();
			newCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdhrenceCounter);*/
			notification_type=HMR_NON_COMPLIANCE;
			newCompliance.setHmrCompliant(false);
	
		}else if(isSettingsDeviatedMonarch){
			// Previous day setting deviation count / 0 for 1 day adherence setting 
			int setDeviationCount = initialPrevScoreFor1Day == 0 ? prevCompliance.getSettingsDeviatedDaysCount() : 0;			
			newCompliance.setSettingsDeviatedDaysCount(setDeviationCount+1);
			
/*			int globalSettingsDeviationCounter = prevCompliance.getGlobalSettingsDeviationCounter();
			newCompliance.setGlobalSettingsDeviationCounter(++globalSettingsDeviationCounter);*/
		}else if(StringUtils.isBlank(complianceType)){
			score = score <=  DEFAULT_COMPLIANCE_SCORE - BONUS_POINTS ? score + BONUS_POINTS : DEFAULT_COMPLIANCE_SCORE;
			
			if(Objects.nonNull(existingNotificationofTheDay))
				notificationMonarchRepository.delete(existingNotificationofTheDay);
			newCompliance.setScore(score);
			newCompliance.setMissedTherapyCount(0);
			return newCompliance;
		}
		
		String notificationType = (isSettingsDeviatedMonarch && isSettingsDeviatedVest) ? SETTINGS_DEVIATION : 
			( (!isSettingsDeviatedMonarch && isSettingsDeviatedVest) ? SETTINGS_DEVIATION_VEST : 
				( (isSettingsDeviatedMonarch && !isSettingsDeviatedVest) ? SETTINGS_DEVIATION_MONARCH : "" ) );
		
		// Added the existingNotificationofTheDay param for passing the notification object for the current date
		notificationMonarchService.createOrUpdateNotification(patientUser, patient, userId,
				complianceDate, notification_type, false, existingNotificationofTheDay,complianceType);
		
		// Setting the new score with respect to the compliance deduction
		newCompliance.setScore(score);
		
		// Setting to missed therapy count as 0 for any of the device is having therapy
		if( (resetFlag == 3 || resetFlag == 4 || resetFlag == 1) ){
			if(( Objects.nonNull(sortedTherapy.get(complianceDate)) || Objects.nonNull(sortedTherapyVest.get(complianceDate))))
				newCompliance.setMissedTherapyCount(0);
			else
				newCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
		}
		
		// Saving the updated score for the specific date of compliance
		
		return newCompliance;
	}
	
	/**
	 * Get the therapy data between days and user ids
	 * @param patientUserId, from date and to date
	 * @return
	 */
	public List<TherapySessionMonarch> getLastSettingDaysTherapiesForUserId(Long patientUserId,LocalDate from,LocalDate to){
		List<TherapySessionMonarch> therapySessions = therapySessionMonarchRepository.findByDateBetweenAndPatientUserId(from, to, patientUserId);
		return therapySessions;
	}	
	
	/**
	 * Calculate HMRRunRate For PatientUsers
	 * @param patientUserIds
	 * @return
	 */
	public Map<Long,List<TherapySessionMonarch>> getLastSettingDaysTherapiesGroupByUserId(List<Long> patientUserIds,LocalDate from,LocalDate to){
		Map<Long,List<TherapySessionMonarch>> patientUserTherapyMap = new HashMap<>();
		List<TherapySessionMonarch> therapySessions = therapySessionMonarchRepository.findByDateBetweenAndPatientUserIdIn(from, to, patientUserIds);
		Map<User,List<TherapySessionMonarch>> therapySessionsPerPatient = therapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch::getPatientUser));
		for(User patientUser : therapySessionsPerPatient.keySet()){
			List<TherapySessionMonarch> sessions = therapySessionsPerPatient.get(patientUser);
			patientUserTherapyMap.put(patientUser.getId(), sessions);
		}
		return patientUserTherapyMap;
	}
	
	/**
	 * Runs every midnight , sends the notifications to Patient User.
	 */
	@Async
	@Scheduled(cron="${cron.adherence.monarch.notification.patient}")	
	public void processPatientNotificationsMonarch(){
		
		adherenceCalcMonarchNotificationHelper.processPatientNotificationsMonarchImpl();
	}
	
	public boolean isPatientUserAcceptNotificationFreq(User patientUser, String notificationType) {
		return getIsPatientTrueNotification(patientUser,notificationType);
	}
	
	private boolean getIsPatientTrueNotification(User patientUser, String notificationType ) {
		boolean isPatientNotification = false;
		String dayOfWeek = DateUtil.getDayOfTheWeek();

		if (Objects.nonNull(patientUser)) {
			if (Objects.nonNull(patientUser.getMissedTherapyNotificationFreq())){
				if(notificationType.equals(MISSED_THERAPY) && (patientUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getMissedTherapyNotificationFreq().equalsIgnoreCase(DAILY))) {
					isPatientNotification = true; }
				}
		   else if (Objects.nonNull(patientUser.getNonHMRNotificationFreq())) {
			    if(notificationType.equals(HMR_NON_COMPLIANCE) && (patientUser.getNonHMRNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getNonHMRNotificationFreq().equalsIgnoreCase(DAILY))) {
			    		isPatientNotification = true;}		
			    }
		 else if (Objects.nonNull(patientUser.getSettingDeviationNotificationFreq())){
			 	if(notificationType.endsWith(SETTINGS_DEVIATION) && (patientUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(dayOfWeek) || patientUser.getSettingDeviationNotificationFreq().equalsIgnoreCase(DAILY))) {
							isPatientNotification = true;	}
								}
				}		
		return isPatientNotification;
	}

	/**
	 * Runs every midnight , sends the statistics notifications to Clinic Admin and HCP.
	 * @throws HillromException 
	 */
	@Scheduled(cron="${cron.adherence.monarch.notification.cahcp}")	
	public void processHcpClinicAdminNotificationsMonarch() throws HillromException{
		
		adherenceCalcMonarchNotificationHelper.processHcpClinicAdminNotificationsMonarchImpl();
	}
	
	@Scheduled(cron="${cron.adherence.monarch.notification.caregiver}")	
	public void processCareGiverNotificationsMonarch() throws HillromException{
		
		adherenceCalcMonarchNotificationHelper.processCareGiverNotificationsMonarchImpl();
	}
	
	public void processAdherenceScore(PatientNoEventMonarch patientNoEventMonarch,
			SortedMap<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate,List<TherapySessionMonarch>> receivedTherapySessionsMap,
			SortedMap<LocalDate,PatientComplianceMonarch> existingComplianceMap,
			ProtocolConstantsMonarch protocolConstant) throws Exception{
		for(LocalDate currentTherapySessionDate : receivedTherapySessionsMap.keySet()){
			List<TherapySessionMonarch> receivedTherapySessions = receivedTherapySessionsMap.get(currentTherapySessionDate);
			LocalDate firstTransmittedDate = null;
			LocalDate latestTherapyDate = null;
			PatientInfo patient = null;
			User patientUser = null;
			
			if(receivedTherapySessions.size() > 0){
				patient = receivedTherapySessions.get(0).getPatientInfo();
				patientUser = receivedTherapySessions.get(0).getPatientUser();						
				
				if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate()))
					firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
				else
					firstTransmittedDate = currentTherapySessionDate;
			}
			
			int adherenceSettingDay = getAdherenceSettingForPatient(patient);
			
			int totalDuration = calculateCumulativeDuration(receivedTherapySessions);		
			// Existing User First Time Transmission Data OR New User First Time Transmission Data
			if(existingTherapySessionMap.isEmpty()){
				handleFirstTimeTransmit(existingTherapySessionMap,
						receivedTherapySessionsMap, existingComplianceMap,
						protocolConstant, currentTherapySessionDate,
						firstTransmittedDate, patient, patientUser,
						totalDuration, adherenceSettingDay);
			}else{ // User Transmitting data in Subsequent requests
				// data is sent in sorted order
				latestTherapyDate = existingTherapySessionMap.lastKey();
				if (Objects.nonNull(firstTransmittedDate) && Objects.nonNull(currentTherapySessionDate)
						&& firstTransmittedDate.isBefore(currentTherapySessionDate)){
					// Data sent in sorted order
					calculateAdherenceScoreForTheDuration(patientUser,patient,firstTransmittedDate,
							currentTherapySessionDate,protocolConstant,existingComplianceMap,
							existingTherapySessionMap,receivedTherapySessionsMap, adherenceSettingDay);
				}else{
					// Older data sent
					firstTransmittedDate = currentTherapySessionDate;
					handleFirstTimeTransmit(existingTherapySessionMap,
							receivedTherapySessionsMap, existingComplianceMap,
							protocolConstant, currentTherapySessionDate,
							firstTransmittedDate, patient, patientUser,
							totalDuration, adherenceSettingDay);
				}
			}

 		}
		saveOrUpdateComplianceMap(existingComplianceMap);
		saveOrUpdateTherapySessions(receivedTherapySessionsMap);
	}

	public void processAdherenceScore(PatientNoEventMonarch patientNoEventMonarch,
			SortedMap<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate,List<TherapySessionMonarch>> receivedTherapySessionsMap,
			SortedMap<LocalDate,PatientComplianceMonarch> existingComplianceMap,
			ProtocolConstantsMonarch protocolConstant, Long patientUserId) throws Exception{
					
		SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = therapySessionService.getAllTherapySessionsMapByPatientUserId(patientUserId);		
		
		for(LocalDate currentTherapySessionDate : receivedTherapySessionsMap.keySet()){
			List<TherapySessionMonarch> receivedTherapySessions = receivedTherapySessionsMap.get(currentTherapySessionDate);
			LocalDate firstTransmittedDate = null;
			LocalDate latestTherapyDate = null;
			PatientInfo patient = null;
			User patientUser = null;
			
			if(receivedTherapySessions.size() > 0){
				patient = receivedTherapySessions.get(0).getPatientInfo();
				patientUser = receivedTherapySessions.get(0).getPatientUser();						
				
				PatientNoEvent patientNoEventVest = patientNoEventRepository.findByPatientUserId(patientUser.getId());
				
				if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate()) 
						&& Objects.nonNull(patientNoEventVest) && Objects.nonNull(patientNoEventVest.getFirstTransmissionDate()))
					firstTransmittedDate = patientNoEventVest.getFirstTransmissionDate().isBefore(patientNoEventMonarch.getFirstTransmissionDate()) ? 
							patientNoEventVest.getFirstTransmissionDate() : patientNoEventMonarch.getFirstTransmissionDate();
				else if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate()))
					firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
				else if(Objects.nonNull(patientNoEventVest) && Objects.nonNull(patientNoEventVest.getFirstTransmissionDate()))
					firstTransmittedDate = patientNoEventVest.getFirstTransmissionDate();
				else
					firstTransmittedDate = currentTherapySessionDate;
			}
			
			int adherenceSettingDay = getAdherenceSettingForPatient(patient);
			
			int totalDuration = calculateCumulativeDuration(receivedTherapySessions);		
			// Existing User First Time Transmission Data OR New User First Time Transmission Data
			//if(existingTherapySessionMap.isEmpty() && existingTherapySessionMapVest.isEmpty() ){
			if(Objects.nonNull(existingTherapySessionMap) && existingTherapySessionMap.isEmpty()){
				handleFirstTimeTransmit(existingTherapySessionMap,
						receivedTherapySessionsMap, existingComplianceMap,
						protocolConstant, currentTherapySessionDate,
						firstTransmittedDate, patient, patientUser,
						totalDuration, adherenceSettingDay);
			}else { // User Transmitting data in Subsequent requests
				// data is sent in sorted order
				if (Objects.nonNull(firstTransmittedDate) && Objects.nonNull(currentTherapySessionDate)
						&& firstTransmittedDate.isBefore(currentTherapySessionDate)){
					// Data sent in sorted order
					calculateAdherenceScoreForTheDuration(patientUser,patient,firstTransmittedDate,
							currentTherapySessionDate,protocolConstant,existingComplianceMap,
							existingTherapySessionMap,receivedTherapySessionsMap, adherenceSettingDay);
				}else{
					// Older data sent
					firstTransmittedDate = currentTherapySessionDate;
					handleFirstTimeTransmit(existingTherapySessionMap,
							receivedTherapySessionsMap, existingComplianceMap,
							protocolConstant, currentTherapySessionDate,
							firstTransmittedDate, patient, patientUser,
							totalDuration, adherenceSettingDay);
				}
			}
 		}
		saveOrUpdateComplianceMap(existingComplianceMap);
		saveOrUpdateTherapySessions(receivedTherapySessionsMap);
	}
	
	private synchronized void saveOrUpdateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap) {
		Map<LocalDate, List<TherapySessionMonarch>> allTherapySessionMap = eleminateDuplicateTherapySessions(receivedTherapySessionsMap);
		
		List<TherapySessionMonarch> newTherapySessions = new LinkedList<>();
		for(LocalDate date : allTherapySessionMap.keySet()){
			List<TherapySessionMonarch> sessionsTobeSaved = allTherapySessionMap.get(date);
			newTherapySessions.addAll(sessionsTobeSaved);
		}
		therapySessionMonarchRepository.save(newTherapySessions);
	}

	private Map<LocalDate, List<TherapySessionMonarch>> eleminateDuplicateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap) {
		List<List<TherapySessionMonarch>> therapySessionsList = new LinkedList<>(receivedTherapySessionsMap.values());
		Long patientUserId = therapySessionsList.get(0).get(0).getPatientUser().getId();
		LocalDate from = receivedTherapySessionsMap.firstKey();
		LocalDate to = receivedTherapySessionsMap.lastKey();
		List<TherapySessionMonarch> existingTherapySessions = therapySessionMonarchRepository.findByPatientUserIdAndDateRange(patientUserId, from, to);
		Map<LocalDate,List<TherapySessionMonarch>> existingTherapySessionMap = existingTherapySessions.stream().collect(Collectors.groupingBy(TherapySessionMonarch::getDate));
		Map<LocalDate,List<TherapySessionMonarch>> allTherapySessionMap = new HashMap<>();
		for(LocalDate date : receivedTherapySessionsMap.keySet()){
			List<TherapySessionMonarch> therapySessionsPerDate = existingTherapySessionMap.get(date);
			if(Objects.nonNull(therapySessionsPerDate)){
				List<TherapySessionMonarch> receivedTherapySessions = receivedTherapySessionsMap.get(date);
				for(TherapySessionMonarch existingSession : therapySessionsPerDate){
					Iterator<TherapySessionMonarch> itr = receivedTherapySessions.iterator();
					while(itr.hasNext()){
						TherapySessionMonarch receivedSession = itr.next();
						if(existingSession.getDate().equals(receivedSession.getDate()) &&
								existingSession.getStartTime().equals(receivedSession.getStartTime()) &&
								existingSession.getEndTime().equals(receivedSession.getEndTime()) &&
								existingSession.getFrequency().equals(receivedSession.getFrequency()) && 
								existingSession.getIntensity().equals(receivedSession.getIntensity()) &&
								existingSession.getHmr().equals(receivedSession.getHmr())){
							itr.remove();
						}
					}
				}
				therapySessionsPerDate.addAll(receivedTherapySessionsMap.get(date));
				Collections.sort(therapySessionsPerDate);
				int sessionNo = 0;
				for(TherapySessionMonarch session : therapySessionsPerDate){
					session.setSessionNo(++sessionNo);
				}
				allTherapySessionMap.put(date, therapySessionsPerDate);
			}else{
				for(LocalDate receivedDate : receivedTherapySessionsMap.keySet()){
					allTherapySessionMap.put(receivedDate, receivedTherapySessionsMap.get(receivedDate));
				}
			}
		}
		return allTherapySessionMap;
	}

	public synchronized void saveOrUpdateComplianceMap(
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap) {
		// Save or update all compliance
		List<PatientComplianceMonarch> compliances = new LinkedList<>(existingComplianceMap.values());
		Long patientUserId = compliances.get(0).getPatientUser().getId();
		SortedMap<LocalDate, PatientComplianceMonarch>  complainceMapFromDB = complianceMonarchService.getPatientComplainceMapByPatientUserId(patientUserId);
		for(LocalDate date: existingComplianceMap.keySet()){
			//	complianceService.createOrUpdate(existingComplianceMap.get(date));
			PatientComplianceMonarch existingCompliance = complainceMapFromDB.get(date);
			PatientComplianceMonarch newCompliance = existingComplianceMap.get(date);
			if(Objects.nonNull(existingCompliance)){
				newCompliance.setId(existingCompliance.getId());
				existingComplianceMap.put(date,newCompliance);
			}	
		}
		complianceMonarchService.saveAll(existingComplianceMap.values());
	}

	private void handleFirstTimeTransmit(
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap,
			ProtocolConstantsMonarch protocolConstant,
			LocalDate currentTherapySessionDate,
			LocalDate firstTransmittedDate, PatientInfo patient,
			User patientUser, int totalDuration, int adherenceSettingDay) throws Exception{
		noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(), currentTherapySessionDate,patient.getId());
		PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE, currentTherapySessionDate,
				patient, patientUser,totalDuration/adherenceSettingDay,true,false,0d);
		existingComplianceMap.put(currentTherapySessionDate, currentCompliance);
		calculateAdherenceScoreForTheDuration(patientUser,patient,firstTransmittedDate,
				currentTherapySessionDate,protocolConstant,existingComplianceMap,
				existingTherapySessionMap,receivedTherapySessionsMap,adherenceSettingDay);
	}

	private void calculateAdherenceScoreForTheDuration(
			User patientUser,
			PatientInfo patient,
			LocalDate firstTransmittedDate,
			LocalDate currentTherapyDate,
			ProtocolConstantsMonarch protocolConstant,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap,
			Integer adherenceSettingDay) throws Exception{
		
		LocalDate latestComplianceDate = LocalDate.now();
		PatientComplianceMonarch compliance = null;
		
		boolean isHMRCompliant = true;
//		boolean isHMRCompliantVest = true;
		Map<String,Double> therapyMetrics;

		int currentScore=0;
		SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = null; 
		List<TherapySession> latestSettingDaysTherapySessionsVest = null;
				
		String notificationType = null , complianceType = null;
		LocalDate today =LocalDate.now();
		
		if(Objects.nonNull(existingComplianceMap) && !existingComplianceMap.isEmpty()){
			latestComplianceDate = existingComplianceMap.lastKey();
		}else{
			SortedMap<LocalDate,PatientCompliance> existingComplianceVestMap = complianceService.getPatientComplainceMapByPatientUserId(patientUser.getId());
			if(Objects.nonNull(existingComplianceVestMap) && !existingComplianceVestMap.isEmpty()) {
				latestComplianceDate = existingComplianceVestMap.lastKey();
			}
		}
		
		List<TherapySessionMonarch> sessionsTobeSaved = receivedTherapySessionsMap.get(currentTherapyDate);
		// Get the therapy sessions for currentTherapyDate from existing therapies
		List<TherapySessionMonarch> existingTherapies = existingTherapySessionMap.get(currentTherapyDate);
		// add existing therapies to calculate metrics (HMR Run rate)
		if(Objects.nonNull(existingTherapies)){
			sessionsTobeSaved.addAll(existingTherapies);
		}
		existingTherapySessionMap.put(currentTherapyDate, sessionsTobeSaved);

		List<LocalDate> allDates = new LinkedList<>();
		// Older Data has been sent, hence recalculate compliance till date
		if(currentTherapyDate.isBefore(latestComplianceDate))
			allDates = DateUtil.getAllLocalDatesBetweenDates(currentTherapyDate, latestComplianceDate);
		else // Future Data has been sent 
			allDates = DateUtil.getAllLocalDatesBetweenDates(latestComplianceDate, currentTherapyDate);
		
		//hill-1956
		LocalDate firstresetDate = null;
		LocalDate lastresetDate = allDates.get(allDates.size()-1);
		//hill-1956
				
		for(LocalDate therapyDate : allDates){
			
			//hill-1956
			// query to find the adherence reset for the corresponding therapydate
			List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
			
			//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
			if(Objects.nonNull(adherenceResetList) && adherenceResetList.size() > 0)
			{
				firstresetDate = therapyDate;
				break;
			}
			//hill-1956
			
			
			// First Transmission Date to be updated
			if(firstTransmittedDate.isAfter(therapyDate)){
				noEventMonarchService.updatePatientFirstTransmittedDate(patientUser.getId(),therapyDate,patient.getId());
				firstTransmittedDate = therapyDate;
			}
			
			int daysBetween = DateUtil.getDaysCountBetweenLocalDates(firstTransmittedDate, therapyDate);
						
			List<TherapySessionMonarch> latestSettingDaysTherapySessions = prepareTherapySessionsForLastSettingdays(therapyDate,
					existingTherapySessionMap,adherenceSettingDay);
			
			/*List<TherapySession> latestSettingDaysTherapySessionsVest = adherenceCalculationService.prepareTherapySessionsForLastSettingdays(latestCompliance.getDate(),
					existingTherapySessionMapVest,adherenceSettingDay);*/
						
			double hmr = getLatestHMR(existingTherapySessionMap, receivedTherapySessionsMap,therapyDate,
					latestSettingDaysTherapySessions);
			
			int hmrRunrate = calculateHMRRunRatePerSession(latestSettingDaysTherapySessions);
			
			ProtocolConstants protocolConstantVest = adherenceCalculationService.getProtocolByPatientUserId(patientUser.getId()); 
			
			String deviceType = adherenceCalculationService.getDeviceTypeValue(patient.getId());
			
			if(deviceType.equals("BOTH")){				
				existingTherapySessionMapVest = 
						therapySessionService.getAllTherapySessionsMapByPatientUserId(patientUser.getId());
				
				latestSettingDaysTherapySessionsVest = adherenceCalculationService.prepareTherapySessionsForLastSettingdays(therapyDate,
						existingTherapySessionMapVest,adherenceSettingDay);
				
				hmrRunrate = calculateHMRRunRatePerSessionBoth(latestSettingDaysTherapySessions, latestSettingDaysTherapySessionsVest);				
			}
			
			LocalDate lastTransmissionDate = getLatestTransmissionDate(
					existingTherapySessionMap, therapyDate);
						
			if(deviceType.equals("BOTH")){
				existingTherapySessionMapVest = 
						therapySessionService.getAllTherapySessionsMapByPatientUserId(patientUser.getId());
				lastTransmissionDate = getLatestTransmissionDate(
						existingTherapySessionMapVest, existingTherapySessionMap, therapyDate);
			}
			
			therapyMetrics = calculateTherapyMetricsPerSettingDays(latestSettingDaysTherapySessions);				
			
			isHMRCompliant = isHMRCompliant(protocolConstant,protocolConstantVest, therapyMetrics.get(TOTAL_DURATION),adherenceSettingDay);
			
			int missedTherapyCount = 0;
			
			compliance = existingComplianceMap.get(therapyDate);
			
			if( (daysBetween <= 1 && adherenceSettingDay > 1 ) || (daysBetween == 0 && adherenceSettingDay == 1) ){ // first transmit
				
					compliance.setScore(DEFAULT_COMPLIANCE_SCORE);
					compliance.setHmrCompliant(true);
			
				if(Objects.nonNull(compliance) && adherenceSettingDay == 1){
					
					currentScore = compliance.getScore();
					if(!isHMRCompliant){
						if(!today.equals(compliance.getDate()) || missedTherapyCount == 0){
							currentScore -=  HMR_NON_COMPLIANCE_POINTS;
							complianceType =  HMR_NON_COMPLIANCE;					
						}
						
						compliance.setHmrCompliant(false);
						complianceType = HMR_NON_COMPLIANCE;
						notificationType = HMR_NON_COMPLIANCE;	
						compliance.setScore(currentScore);
						int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
						compliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
					}
					
					compliance.setHmr(hmr);
					compliance.setHmrRunRate(hmrRunrate);
					compliance.setMissedTherapyCount(0);	
						
					// Patient did therapy but point has been deducted due to Protocol violation
					if(StringUtils.isNotBlank(notificationType)){
						notificationMonarchService.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
								compliance.getDate(), notificationType,false,complianceType);
					}
				}
				else if(Objects.nonNull(compliance)){
					compliance.setScore(DEFAULT_COMPLIANCE_SCORE);
					compliance.setHmr(hmr);
					compliance.setHmrRunRate(hmrRunrate);
					compliance.setHmrCompliant(true);
					compliance.setSettingsDeviated(false);
					compliance.setMissedTherapyCount(0);
				}else{
					compliance = new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE, therapyDate,
							patient, patientUser,hmrRunrate,true,false,missedTherapyCount,lastTransmissionDate,hmr);
				}
				if(daysBetween >= 1 && daysBetween < adherenceSettingDay && adherenceSettingDay > 1){ // second day of the transmission to earlier day of adherence setting day
					missedTherapyCount = DateUtil.getDaysCountBetweenLocalDates(lastTransmissionDate, therapyDate);
					if(LocalDate.now().equals(therapyDate)){
						compliance.setMissedTherapyCount(0);
					}else{
						compliance.setMissedTherapyCount(missedTherapyCount);
						// increment global Missed Therapy counter
						compliance.setGlobalMissedTherapyCounter(missedTherapyCount);
					}
					compliance.setLatestTherapyDate(lastTransmissionDate);
				}
				existingComplianceMap.put(therapyDate, compliance);
			}else{
				missedTherapyCount = DateUtil.getDaysCountBetweenLocalDates(lastTransmissionDate, therapyDate);
				compliance = getLatestCompliance(patientUser, patient,
						existingComplianceMap, therapyDate);
				compliance.setLatestTherapyDate(lastTransmissionDate);
				compliance.setHmr(hmr);
				compliance.setHmrRunRate(hmrRunrate);
				calculateAdherenceScoreForTheDay(compliance, missedTherapyCount,firstTransmittedDate,
						existingComplianceMap,existingTherapySessionMap,
						receivedTherapySessionsMap, protocolConstant,adherenceSettingDay);
			}
		}
		
		//hill-1956
		if(Objects.nonNull(firstresetDate))
		{
			/* find the list of adherence reset for the specific duration
			 * firstresetDate is the first reset date found for the user
			 * lastresetDate is the last date in the request
			 */
			List<AdherenceResetMonarch> adherenceResetList = adherenceResetMonarchRepository.findOneByPatientUserIdAndResetStartDates(patientUser.getId(),firstresetDate,lastresetDate);
			
			if(Objects.nonNull(adherenceResetList) && adherenceResetList.size() > 0)
			{
				for(int i = 0; i < adherenceResetList.size(); i++)
				{
					adherenceResetForPatient(patientUser.getId(), patient.getId().toString(), adherenceResetList.get(i).getResetStartDate(), DEFAULT_COMPLIANCE_SCORE, 1);
				}
			}
		}
		//hill-1956
				
	}

	public PatientComplianceMonarch getLatestCompliance(User patientUser,
			PatientInfo patient,
			SortedMap<LocalDate, PatientComplianceMonarch> existingComplianceMap,
			LocalDate therapyDate) throws Exception {
			SortedMap<LocalDate,PatientComplianceMonarch> mostRecentComplianceMap = existingComplianceMap.headMap(therapyDate);
			PatientComplianceMonarch latestCompliance = null;
			if(mostRecentComplianceMap.size() > 0){
				latestCompliance = mostRecentComplianceMap.get(mostRecentComplianceMap.lastKey());
				return buildPatientCompliance(therapyDate, latestCompliance,latestCompliance.getMissedTherapyCount());
			}else{
				return new PatientComplianceMonarch(DEFAULT_COMPLIANCE_SCORE, therapyDate,
						patient, patientUser,0,true,false,0d);
			}
	}

	private LocalDate getLatestTransmissionDate(
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			LocalDate date) throws Exception{
		LocalDate lastTransmissionDate = date;
		// Get Latest TransmissionDate, if data has not been transmitted for the day get mostRecent date
		if(Objects.isNull(existingTherapySessionMap.get(date))){
			SortedMap<LocalDate,List<TherapySessionMonarch>> mostRecentTherapySessionMap = existingTherapySessionMap.headMap(date);
			if(mostRecentTherapySessionMap.size()>0)
				lastTransmissionDate = mostRecentTherapySessionMap.lastKey();
		}
		return lastTransmissionDate;
	}
	
	public LocalDate getLatestTransmissionDate(
			SortedMap<LocalDate, List<TherapySession>> existingTherapySessionMapVest,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMapMonarch,
			LocalDate date) throws Exception{
		LocalDate lastTransmissionDateVest = null;
		LocalDate lastTransmissionDateMonarch = null;
		
		// Get Latest TransmissionDate for Monarch, if data has not been transmitted for the day get mostRecent date
		if(existingTherapySessionMapMonarch.size()>0) {
			if(Objects.isNull(existingTherapySessionMapMonarch.get(date))){
				SortedMap<LocalDate,List<TherapySessionMonarch>> mostRecentTherapySessionMap = existingTherapySessionMapMonarch.headMap(date);
				if(mostRecentTherapySessionMap.size()>0)
					lastTransmissionDateMonarch = mostRecentTherapySessionMap.lastKey();
			}else {
				lastTransmissionDateMonarch = date;
			}
		}
		
		// Get Latest TransmissionDate for Vest, if data has not been transmitted for the day get mostRecent date
		if(existingTherapySessionMapVest.size()>0) {
			if(Objects.isNull(existingTherapySessionMapVest.get(date))){
				SortedMap<LocalDate,List<TherapySession>> mostRecentTherapySessionMap = existingTherapySessionMapVest.headMap(date);
				if(mostRecentTherapySessionMap.size()>0)
					lastTransmissionDateVest = mostRecentTherapySessionMap.lastKey();
			}else {
				lastTransmissionDateVest = date;
			}
		}
		
		LocalDate lastTransmissionDate = null;
		
		if(Objects.nonNull(lastTransmissionDateVest)) {
			if(Objects.nonNull(lastTransmissionDateMonarch)) {
				lastTransmissionDate = lastTransmissionDateMonarch.isAfter(lastTransmissionDateVest) ? lastTransmissionDateMonarch : lastTransmissionDateVest;
			}
			else {
				lastTransmissionDate = lastTransmissionDateVest;
			}
		}else if(Objects.nonNull(lastTransmissionDateMonarch)) {
			lastTransmissionDate = lastTransmissionDateMonarch;
		}
		return lastTransmissionDate;
//		return (lastTransmissionDateMonarch.isAfter(lastTransmissionDateVest) ? lastTransmissionDateMonarch : lastTransmissionDateVest);
	}

	private double getLatestHMR(
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap,
			LocalDate date, List<TherapySessionMonarch> latestSettingDaysTherapySessions) throws Exception{
		double hmr = 0;
		if(Objects.nonNull(receivedTherapySessionsMap.get(date))){
			List<TherapySessionMonarch> currentTherapySessions = receivedTherapySessionsMap.get(date);
			if(Objects.nonNull(currentTherapySessions) && currentTherapySessions.size() > 0)
				hmr = currentTherapySessions.get(currentTherapySessions.size()-1).getHmr();
		}else if(existingTherapySessionMap.size() > 0){
			SortedMap<LocalDate, List<TherapySessionMonarch>> previousTherapySessionMap = existingTherapySessionMap
					.headMap(date);
			if (previousTherapySessionMap.size() > 0) {
				List<TherapySessionMonarch> mostRecentTherapySessions = previousTherapySessionMap
						.get(previousTherapySessionMap.lastKey());
				hmr = mostRecentTherapySessions.get(
						mostRecentTherapySessions.size() - 1).getHmr();
			}
		}
		return hmr;
	}

	private PatientComplianceMonarch buildPatientCompliance(LocalDate date,
			PatientComplianceMonarch latestcompliance,int missedTherapyCount) {
		PatientComplianceMonarch compliance = new PatientComplianceMonarch();
		compliance.setDate(date);
		compliance.setPatient(latestcompliance.getPatient());
		compliance.setPatientUser(latestcompliance.getPatientUser());
		compliance.setScore(latestcompliance.getScore());
		compliance.setHmr(latestcompliance.getHmr());
		compliance.setHmrRunRate(latestcompliance.getHmrRunRate());
		compliance.setSettingsDeviated(latestcompliance.isSettingsDeviated());
		compliance.setMissedTherapyCount(missedTherapyCount);
		compliance.setHmrCompliant(latestcompliance.isHmrCompliant());
		compliance.setLatestTherapyDate(latestcompliance.getLatestTherapyDate());
		compliance.setSettingsDeviatedDaysCount(latestcompliance.getSettingsDeviatedDaysCount());
		updateGlobalCounters(latestcompliance.getGlobalMissedTherapyCounter(), latestcompliance.getGlobalHMRNonAdherenceCounter(), latestcompliance.getGlobalSettingsDeviationCounter(), compliance);
		return compliance;
	}

	public void calculateAdherenceScoreForTheDay(PatientComplianceMonarch latestCompliance,int currentMissedTherapyCount,
			LocalDate firstTransmissionDate,
			SortedMap<LocalDate,PatientComplianceMonarch> complianceMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionMonarch>> receivedTherapySessionsMap,
			ProtocolConstantsMonarch protocolConstant,
			Integer adherenceSettingDay) throws Exception{

		int currentScore = latestCompliance.getScore();
		String notificationType = "";
		User patientUser = latestCompliance.getPatientUser();
		Long patientUserId = patientUser.getId();
		PatientInfo patient = latestCompliance.getPatient();
		LocalDate today =LocalDate.now();
		
		int globalHMRNonAdherenceCounter;
		Map<String,Double> therapyMetrics; 
		
		boolean isHMRCompliant = true;
//		boolean isHMRCompliantVest = true;
		
		String complianceType=null; 
		
		List<TherapySessionMonarch> latestSettingDaysTherapySessions = prepareTherapySessionsForLastSettingdays(latestCompliance.getDate(),
				existingTherapySessionMap,adherenceSettingDay);
				
		String deviceType = adherenceCalculationService.getDeviceTypeValue(patient.getId());
		
		therapyMetrics = calculateTherapyMetricsPerSettingDays(latestSettingDaysTherapySessions);				
		isHMRCompliant = isHMRCompliant(protocolConstant, therapyMetrics.get(TOTAL_DURATION),adherenceSettingDay);
		

		// MISSED THERAPY
		if(currentMissedTherapyCount >= adherenceSettingDay){
			if(today.equals(latestCompliance.getDate())){
				currentScore = latestCompliance.getScore();
			}else{
				// deduct since therapy has been MISSED
//				currentScore = currentScore > MISSED_THERAPY_POINTS  ? currentScore - MISSED_THERAPY_POINTS : 0;
				notificationType = MISSED_THERAPY;
				
				if(!isHMRCompliant){
					if(!today.equals(latestCompliance.getDate()) || currentMissedTherapyCount == 0){
						currentScore -=  HMR_NON_COMPLIANCE_POINTS;
						complianceType =  HMR_NON_COMPLIANCE;					
					}
				}
			}
			
			latestCompliance.setHmrCompliant(false);
			latestCompliance.setSettingsDeviated(false);
			// reset settingsDeviatedDays count if patient miss therapy
			latestCompliance.setSettingsDeviatedDaysCount(0);			
		}else if(latestCompliance.getMissedTherapyCount() >= MISSED_THERAPY_DAYS_COUNT_THRESHOLD && currentMissedTherapyCount == 0){
			currentScore = DEFAULT_COMPLIANCE_SCORE;
			latestCompliance.setHmrCompliant(false);
			latestCompliance.setSettingsDeviated(false);
			latestCompliance.setSettingsDeviatedDaysCount(0);
			latestCompliance.setMissedTherapyCount(0);
			notificationType = ADHERENCE_SCORE_RESET; 
			if(!isHMRCompliant){
				if(!today.equals(latestCompliance.getDate())){
					currentScore -=  HMR_NON_COMPLIANCE_POINTS;								
				}		
				latestCompliance.setHmrCompliant(false);
				complianceType = HMR_NON_COMPLIANCE;				
			}else{			
				complianceType=null; 
			}
		}else{

			SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = null; 
					
			
			Map<String,Double> therapyMetricsVest;
				
			
			if(deviceType.equals("BOTH")){
				existingTherapySessionMapVest = 
						therapySessionService.getAllTherapySessionsMapByPatientUserId(patientUser.getId());
				
				ProtocolConstants protocolConstantVest = adherenceCalculationService.getProtocolByPatientUserId(patientUser.getId()); 
			
				List<TherapySession> latestSettingDaysTherapySessionsVest = adherenceCalculationService.prepareTherapySessionsForLastSettingdays(latestCompliance.getDate(),
						existingTherapySessionMapVest,adherenceSettingDay);
				
				therapyMetricsVest = adherenceCalculationService.calculateTherapyMetricsPerSettingDays(latestSettingDaysTherapySessionsVest);
//				isHMRCompliantVest = isHMRCompliant(protocolConstant,protocolConstantVest, therapyMetricsVest.get(TOTAL_DURATION),adherenceSettingDay);
				
				Map<String, Object> latestSettingDaysTherapySessionsBoth = prepareTherapySessionsForLastSettingdays(latestCompliance.getDate(),
						existingTherapySessionMap,existingTherapySessionMapVest,adherenceSettingDay);
				
				therapyMetrics = calculateTherapyMetricsPerSettingDaysBoth(latestSettingDaysTherapySessionsBoth);
				isHMRCompliant = isHMRCompliant(protocolConstant, protocolConstantVest, therapyMetrics.get(TOTAL_DURATION),adherenceSettingDay);
			}
			
			boolean isSettingsDeviated = false;
			boolean isSettingsDeviatedVest = false;
					
			// Settings deviated to be calculated only on Therapy done days
			if(currentMissedTherapyCount == 0){
				
				isSettingsDeviated = isSettingsDeviatedForSettingDays(latestSettingDaysTherapySessions, protocolConstant, adherenceSettingDay);
				
				if(deviceType.equals("BOTH")){
					List<TherapySession> latestSettingDaysTherapySessionsVest = adherenceCalculationService.prepareTherapySessionsForLastSettingdays(latestCompliance.getDate(),
							existingTherapySessionMapVest,adherenceSettingDay);
					
					ProtocolConstants protocolConstantVest = adherenceCalculationService.getProtocolByPatientUserId(patientUser.getId());

					isSettingsDeviatedVest = adherenceCalculationService.isSettingsDeviatedForSettingDays(latestSettingDaysTherapySessionsVest, protocolConstantVest, adherenceSettingDay);
				}
				
				applySettingsDeviatedDaysCount(latestCompliance, complianceMap,
						(isSettingsDeviated || isSettingsDeviatedVest), adherenceSettingDay);

				if(isSettingsDeviated || isSettingsDeviatedVest){
		//			currentScore -=  SETTING_DEVIATION_POINTS;
					
					if(isSettingsDeviated && (deviceType.equals(MONARCH) ||  isSettingsDeviatedVest)){
						notificationType =  SETTINGS_DEVIATION;
					}else if(isSettingsDeviated && !isSettingsDeviatedVest){
						notificationType =  SETTINGS_DEVIATION_MONARCH;
					}else if(!isSettingsDeviated && isSettingsDeviatedVest){
						notificationType =  SETTINGS_DEVIATION_VEST;
					}
					
					// increment global settings Deviation counter
					int globalSettingsDeviationCounter = latestCompliance.getGlobalSettingsDeviationCounter();
					latestCompliance.setGlobalSettingsDeviationCounter(++globalSettingsDeviationCounter);
				}else{
					// reset settingsDeviatedDays count if patient is adhere to settings
					latestCompliance.setSettingsDeviatedDaysCount(0);
				}
			}else{
				// reset settingsDeviatedDays count if patient missed therapy
				latestCompliance.setSettingsDeviatedDaysCount(0);
			}

			latestCompliance.setSettingsDeviated(isSettingsDeviated);
			
			if(!isHMRCompliant){
				if(!today.equals(latestCompliance.getDate()) || currentMissedTherapyCount == 0){
					currentScore -=  HMR_NON_COMPLIANCE_POINTS;
					complianceType =  HMR_NON_COMPLIANCE;
					
					if(deviceType.equals(MONARCH) || deviceType.equals("BOTH")){
						if(StringUtils.isBlank(notificationType))
							notificationType =  HMR_NON_COMPLIANCE;
						else{
							notificationType =  HMR_AND_SETTINGS_DEVIATION;
							complianceType =  HMR_NON_COMPLIANCE;
						}
							
					}					
					// increment global HMR Non Adherence Counter
					globalHMRNonAdherenceCounter = latestCompliance.getGlobalHMRNonAdherenceCounter();
					latestCompliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
				}
			}
			
			latestCompliance.setHmrCompliant(isHMRCompliant);
			// Delete existing notification if adherence to protocol
			notificationMonarchService.deleteNotificationIfExists(patientUserId,
					latestCompliance.getDate(), currentMissedTherapyCount,
					isHMRCompliant, isSettingsDeviated, adherenceSettingDay);
			
			// No Notification add +1
			if(StringUtils.isBlank(notificationType) || StringUtils.isBlank(complianceType)){
				if(!today.equals(latestCompliance.getDate()) || currentMissedTherapyCount == 0){
					currentScore = currentScore <=  DEFAULT_COMPLIANCE_SCORE - BONUS_POINTS ? currentScore + BONUS_POINTS : DEFAULT_COMPLIANCE_SCORE;
				}
			}
		}
		
		// Patient did therapy but point has been deducted due to Protocol violation
		if(StringUtils.isNotBlank(notificationType)){
			notificationMonarchService.createOrUpdateNotification(patientUser, patient, patientUserId,
					latestCompliance.getDate(), notificationType,false,complianceType);
		}

		// Compliance Score is non-negative
		currentScore = currentScore > 0? currentScore : 0;
		
		// Don't include today as missed Therapy day, This will be taken care by the job
		if(LocalDate.now().equals(latestCompliance.getDate())){
			latestCompliance.setMissedTherapyCount( currentMissedTherapyCount > 0 ? currentMissedTherapyCount-1:currentMissedTherapyCount);
		}else{
			latestCompliance.setMissedTherapyCount(currentMissedTherapyCount);
			if(currentMissedTherapyCount > 0){
				// increment global Missed Therapy counter
				int globalMissedTherapyCounter = latestCompliance.getGlobalMissedTherapyCounter();
				latestCompliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);
			}
		}
		
		latestCompliance.setScore(currentScore);
		complianceMap.put(latestCompliance.getDate(), latestCompliance);
	}

	public String getNotificationString(String notificationType,boolean isHMRCompliantMonarch,boolean isHMRCompliantVest)
	{	
		String retNotificationType = "";
		
		notificationType = StringUtils.isBlank(notificationType) ? "" : notificationType;  
		
		switch(notificationType){
		
			case "":
				// When there is no setting is deviated and HMR compliant / non compliant in either of the device combinations
				if(!isHMRCompliantMonarch){
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_NON_COMPLIANCE;	
					else
						retNotificationType =  HMR_NON_COMPLIANCE_MONARCH;					
				}else{
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_NON_COMPLIANCE_VEST;
				}
				break;
				
			case SETTINGS_DEVIATION:				
				// When both the device setting is deviated and HMR compliant / non compliant in either of the device combinations			
				if(!isHMRCompliantMonarch){
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_AND_SETTINGS_DEVIATION;
					else
						retNotificationType =  HMR_MONARCH_AND_SETTINGS_DEVIATION;					
				}else{
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_VEST_AND_SETTINGS_DEVIATION;
				}
				break;
			
			case SETTINGS_DEVIATION_VEST:				
				// When Vest device is setting deviated and HMR compliant / non compliant in either of the device combinations
				if(!isHMRCompliantMonarch){
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_AND_SETTINGS_DEVIATION_VEST;
					else
						retNotificationType =  HMR_MONARCH_AND_SETTINGS_DEVIATION_VEST;	
				}else{
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_VEST_AND_SETTINGS_DEVIATION_VEST;
				}
				break;
				
			case SETTINGS_DEVIATION_MONARCH:				
				// When Monarch device is setting deviated and HMR compliant / non compliant in either of the device combinations
				if(!isHMRCompliantMonarch)
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_AND_SETTINGS_DEVIATION_MONARCH;
					else 
						retNotificationType =  HMR_MONARCH_AND_SETTINGS_DEVIATION_MONARCH;
				else{
					if(!isHMRCompliantVest)
						retNotificationType =  HMR_VEST_AND_SETTINGS_DEVIATION_MONARCH;
				}
				break;
		}
		
		return retNotificationType;
	}
	public void applySettingsDeviatedDaysCount(
			PatientComplianceMonarch latestCompliance,
			SortedMap<LocalDate, PatientComplianceMonarch> complianceMap,
			boolean isSettingsDeviated, Integer adherenceSettingDay) throws Exception{
		int settingsDeviatedDaysCount;
		if(isSettingsDeviated){
			int previousSettingsDeviatedDaysCount = 0;
			SortedMap<LocalDate,PatientComplianceMonarch> mostRecentComplianceMap = complianceMap.headMap(latestCompliance.getDate());
			if(mostRecentComplianceMap.size() > 0){
				PatientComplianceMonarch previousCompliance = mostRecentComplianceMap.get(mostRecentComplianceMap.lastKey());
				previousSettingsDeviatedDaysCount = previousCompliance.getSettingsDeviatedDaysCount();
			}
			// If settingsDeviationDaysCount is 0 for previous date, settingsDeviationDaysCount would be default value. increments thereafter
			//settingsDeviatedDaysCount =  previousSettingsDeviatedDaysCount == 0 ? adherenceSettingDay :++previousSettingsDeviatedDaysCount;
			settingsDeviatedDaysCount =  ++previousSettingsDeviatedDaysCount;
			latestCompliance.setSettingsDeviatedDaysCount(settingsDeviatedDaysCount);
		}
	} 
	
	public List<TherapySessionMonarch> prepareTherapySessionsForLastSettingdays(
			LocalDate currentTherapyDate,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			Integer adherenceSettingDay) {
		List<TherapySessionMonarch> therapySessions = new LinkedList<>();
		for(int i = 0;i < adherenceSettingDay;i++){
			List<TherapySessionMonarch> previousExistingTherapySessions = existingTherapySessionMap.get(currentTherapyDate.minusDays(i));
			if(Objects.nonNull(previousExistingTherapySessions))
				therapySessions.addAll(previousExistingTherapySessions);
		}
		return therapySessions;
	}
	
	public Map<String,Object> prepareTherapySessionsForLastSettingdays(
			LocalDate currentTherapyDate,
			SortedMap<LocalDate, List<TherapySessionMonarch>> existingTherapySessionMap,
			SortedMap<LocalDate, List<TherapySession>> existingTherapySessionMapVest,			
			Integer adherenceSettingDay) {
		
		List<Object> therapySessions = new LinkedList<>();
		Map<String,Object> combined = new HashMap<String,Object>();
		
		for(int i = 0;i < adherenceSettingDay;i++){
			List<TherapySessionMonarch> previousExistingTherapySessions = existingTherapySessionMap.get(currentTherapyDate.minusDays(i));
			if(Objects.nonNull(previousExistingTherapySessions))
				therapySessions.addAll(previousExistingTherapySessions);
			combined.put("Monarch", previousExistingTherapySessions);
				
			
			List<TherapySession> previousExistingTherapySessionsVest = existingTherapySessionMapVest.get(currentTherapyDate.minusDays(i));
			if(Objects.nonNull(previousExistingTherapySessionsVest))
				therapySessions.addAll( previousExistingTherapySessionsVest);
			combined.put("Vest", previousExistingTherapySessionsVest);
			
		}
		return combined;
	}
	
	public boolean isSettingsDeviatedForSettingDays(List<TherapySessionMonarch> lastSettingDaysTherapySessions,
			ProtocolConstantsMonarch protocol, Integer adherenceSettingDay){
		Map<LocalDate, List<TherapySessionMonarch>> lastSettingDaysTherapySessionMap = lastSettingDaysTherapySessions
				.stream().collect(
						Collectors.groupingBy(TherapySessionMonarch::getDate));
		boolean isSettingsDeviated = false;
		// This is for checking settings deviation, settings deviation should be calculated for consecutive adherence setting days
		//(exclusive missed therapy)
		if(lastSettingDaysTherapySessionMap.keySet().size() == adherenceSettingDay){
			for(LocalDate d : lastSettingDaysTherapySessionMap.keySet()){
				List<TherapySessionMonarch> therapySeesionsPerDay = lastSettingDaysTherapySessionMap.get(d);
				double weightedFrequency = calculateTherapyMetricsPerSettingDays(therapySeesionsPerDay).get(WEIGHTED_AVG_FREQUENCY);
				if(!isSettingsDeviated(protocol, weightedFrequency)){
					isSettingsDeviated = false;
					break;
				}else{
					isSettingsDeviated = true;
				}
			}
		}else{
			return false;
		}
		return isSettingsDeviated;
	}
	
	private boolean isSettingDeviatedForUserOnDay(Long userId, LocalDate complianceDate,Integer adherenceSettingDay, ProtocolConstantsMonarch userProtocolConstant){
		// Get earlier third day to finding therapy session
		LocalDate adherenceSettingDaysEarlyDate = getDateBeforeSpecificDays(complianceDate,(adherenceSettingDay-1));
		
		// Get therapy session for last adherence Setting days
		List<TherapySessionMonarch> therapySessions = therapySessionMonarchRepository.findByDateBetweenAndPatientUserId(adherenceSettingDaysEarlyDate, complianceDate, userId);
				
		if(Objects.isNull(therapySessions)){
			therapySessions = new LinkedList<>();
		}
				
		return isSettingsDeviatedForSettingDays(therapySessions, userProtocolConstant, adherenceSettingDay);
	}
	
	private Integer getAdherenceSettingForPatient(PatientInfo patient){		
		Clinic clinic = clinicPatientService.getAssociatedClinic(patient);
		if(Objects.nonNull(clinic))
			return clinic.getAdherenceSetting();
		else
			return ADHERENCE_SETTING_DEFAULT_DAYS;
	}
	
	private Integer getAdherenceSettingForUserId(Long patientUserId){
		PatientInfo patient = userService.getPatientInfoObjFromPatientUserId(patientUserId);		
		return getAdherenceSettingForPatient(patient);		
	}
	
	
	/**

	 * Runs every morning 9AM after the TIMS job executed to integrate the patient who is using both devices after identified

	 */
	@Scheduled(cron="${cron.adherence.monarch.processdevicedetails}")
	public void processDeviceDetails(){
		try{
			LocalDate today = LocalDate.now();
			log.debug("Started Device details "+DateTime.now()+","+today);

			
			List<PatientDevicesAssoc> patDevAssList = patientDevicesAssocRepository.findByModifiedDate(today.toString());			
			
			// Looping through all the patient device association, for device update only once loop will be executed
			for(PatientDevicesAssoc patDevice : patDevAssList){
				executeMergingProcessLoop(patDevice);
			}
			
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("processDeviceDetails",writer.toString());
		}
	}

	
	public void executeMergingProcess(List<PatientDevicesAssoc> patDevAssList, int flag){
		// Passing the flag 1 for device update  and 2 for cron job, merging processing
		Map<Long,PatientNoEventMonarch> userIdNoEventMap = noEventMonarchService.findAllGroupByPatientUserId();			
		Map<Long,PatientNoEvent> userIdNoEventMapVest = noEventMonarchServiceVest.findAllGroupByPatientUserId();
	
		// Looping through all the patient device association, for device update only once loop will be executed
		for(PatientDevicesAssoc patDevice : patDevAssList){
			executeMergingProcessLoop(userIdNoEventMap, userIdNoEventMapVest, patDevice, flag);	
		}
	}

	// To get the notification object for the specific notification date
	public PatientComplianceMonarch getComplianceForDay(List<PatientComplianceMonarch> complianceMonarchList, LocalDate reqDate) {
		List<PatientComplianceMonarch> complianceMonarchFilter = complianceMonarchList.stream().filter(PatientComplianceMonarch->PatientComplianceMonarch.getDate().equals(reqDate)).collect(Collectors.toList());
		if(!complianceMonarchFilter.isEmpty())
			return complianceMonarchFilter.get(0);
		else
			return null;
	}

	public void executeMergingProcessLoop(Map<Long,PatientNoEventMonarch> userIdNoEventMap,
			Map<Long,PatientNoEvent> userIdNoEventMapVest,
			PatientDevicesAssoc patDevice, int flag){
		
		// Identifying both device patient by the size more than 1
		List<PatientDevicesAssoc> devAssForPatientList = patientDevicesAssocRepository.findByPatientId(patDevice.getPatientId());
		if(Objects.nonNull(patDevice.getOldPatientId())){
			if(devAssForPatientList.size()>1 && !patDevice.getOldPatientId().equals(patDevice.getPatientId())){
			LocalDate vestCreatedDate = null;
			LocalDate monarchCreatedDate = null;
			String vestSerialNumber = null;
			String monarchSerialNumber = null;
			
			// Looping through the patient devices
			for(PatientDevicesAssoc device : devAssForPatientList){
				if(VEST.equals(device.getDeviceType())){
					vestCreatedDate = device.getCreatedDate();
					vestSerialNumber = device.getSerialNumber();
				}else if(MONARCH.equals(device.getDeviceType())){
					monarchCreatedDate = device.getCreatedDate();
					monarchSerialNumber = device.getSerialNumber();
				}
				if(Objects.isNull(vestCreatedDate) && Objects.isNull(monarchCreatedDate)){
					vestCreatedDate = DateUtil.getPlusOrMinusTodayLocalDate(-1);
					monarchCreatedDate = LocalDate.now();
				}
			}
			
			// Get the Patient details
			PatientInfo patientInfo = patientInfoRepository.findOneById(patDevice.getPatientId());
			User user = userService.getUserObjFromPatientInfo(patientInfo);
			
			LocalDate firstTransmissionDateMonarch = null;
			LocalDate firstTransmissionDateVest = null;
			User userOld = null;
			
			// Added for the Monarch/Vest creation scenario from TIMS
			if(flag == 2 && Objects.isNull(patDevice.getOldPatientId())){
				flag = 1;
			}
			// End of added for the Monarch/Vest creation scenario from TIMS
			
			if(flag == 2){
				// Get the Patient old details
				PatientInfo patientInfoOld = patientInfoRepository.findOneById(patDevice.getOldPatientId());
				userOld = userService.getUserObjFromPatientInfo(patientInfoOld);
				
				if(MONARCH.equals(patDevice.getDeviceType())){
					PatientNoEventMonarch noEventMonarch = userIdNoEventMap.get(userOld.getId());
					
					if(Objects.nonNull(noEventMonarch) && (Objects.nonNull(noEventMonarch.getFirstTransmissionDate()))){
						firstTransmissionDateMonarch = noEventMonarch.getFirstTransmissionDate();
					}
				}else if(VEST.equals(patDevice.getDeviceType())){
					PatientNoEvent noEvent = userIdNoEventMapVest.get(userOld.getId());
					
					if(Objects.nonNull(noEvent) && (Objects.nonNull(noEvent.getFirstTransmissionDate()))){
						firstTransmissionDateVest = noEvent.getFirstTransmissionDate();
					}
				}
			}
			
			
			if(MONARCH.equals(patDevice.getDeviceType())){
				PatientNoEvent noEventVest = userIdNoEventMapVest.get(user.getId());
			
				if(Objects.nonNull(noEventVest) && (Objects.nonNull(noEventVest.getFirstTransmissionDate()))){
					firstTransmissionDateVest = noEventVest.getFirstTransmissionDate();
				}
			}else if(VEST.equals(patDevice.getDeviceType())){
				PatientNoEventMonarch noEventMonarch = userIdNoEventMap.get(user.getId());
			
				if(Objects.nonNull(noEventMonarch) && (Objects.nonNull(noEventMonarch.getFirstTransmissionDate()))){
					firstTransmissionDateMonarch = noEventMonarch.getFirstTransmissionDate();
				}
			}
			
			// Identifying the new device is Monarch and old device is Vest
			if(Objects.nonNull(vestCreatedDate) && Objects.nonNull(monarchCreatedDate) && 
					(vestCreatedDate.isBefore(monarchCreatedDate) || (vestCreatedDate.isEqual(monarchCreatedDate) 
								&& MONARCH.equals(patDevice.getDeviceType())) )){
				
				List<PatientCompliance> patientComplianceList = patientComplianceRepository.findByPatientUserId(user.getId());
				List <PatientComplianceMonarch> complianceListToSave = new LinkedList<>();
				
				List<PatientComplianceMonarch> patientComplianceMonarchList = null;

				if(flag == 2){
					Optional<PatientVestDeviceHistoryMonarch> monarchDevice = patientMonarchDeviceRepository.findOneByPatientIdAndSerialNumber(patDevice.getOldPatientId(),monarchSerialNumber);
					
					// During merging the devices during the cron job
					if(monarchDevice.isPresent()){
		     			if(monarchDevice.get().isActive()) {
		     				
		     				PatientVestDeviceHistoryMonarch monarchDeviceHist = monarchDevice.get();
		     				monarchDeviceHist.setActive(false);
		     				patientMonarchDeviceRepository.save(monarchDeviceHist);
		     				
		     				PatientVestDeviceHistoryMonarch patientVestDeviceAssoc = new PatientVestDeviceHistoryMonarch(
		    		 				new PatientVestDevicePK(patientInfo, monarchDeviceHist.getSerialNumber()), 
		    		 				monarchDeviceHist.getWifiId(), 
		    		 				monarchDeviceHist.getHubId(), true, monarchDeviceHist.getIsByod());
		     				patientVestDeviceAssoc.setCreatedBy(monarchDeviceHist.getCreatedBy());
		     				patientVestDeviceAssoc.setCreatedDate(monarchDeviceHist.getCreatedDate());
		     				patientVestDeviceAssoc.setHmr(monarchDeviceHist.getHmr());
		     				
		     				patientVestDeviceAssoc.setDevBt(monarchDeviceHist.getDevBt());
		     				patientVestDeviceAssoc.setWifiId(monarchDeviceHist.getWifiId());
		     				patientVestDeviceAssoc.setLteId(monarchDeviceHist.getLteId());
		     				patientVestDeviceAssoc.setGarmentColor(monarchDeviceHist.getGarmentColor());
		     				patientVestDeviceAssoc.setGarmentSize(monarchDeviceHist.getGarmentSize());
		     				patientVestDeviceAssoc.setGarmentType(monarchDeviceHist.getGarmentType());
		     				
		    		 		patientMonarchDeviceRepository.saveAndFlush(patientVestDeviceAssoc);
		     			}
		     		}
					patientComplianceMonarchList = patientComplianceMonarchRepository.findByPatientUserId(userOld.getId());
				}
				
				for(PatientCompliance patientCompliance : patientComplianceList){
					
					Double hmrMonarch = 0.0;
					if(flag == 2){
						// Updating HMR for monarch
						PatientComplianceMonarch complianceMonarch = getComplianceForDay(patientComplianceMonarchList, patientCompliance.getDate());
						if(Objects.nonNull(complianceMonarch))
							hmrMonarch = complianceMonarch.getHmr();
					}
					PatientComplianceMonarch compliance = new PatientComplianceMonarch(patientCompliance.getScore(),
							patientCompliance.getDate(),
							patientCompliance.getPatient(),
							patientCompliance.getPatientUser(),
							patientCompliance.getHmrRunRate(),
							hmrMonarch,
							patientCompliance.isHmrCompliant(),
							patientCompliance.isSettingsDeviated(),
							patientCompliance.getMissedTherapyCount(),
							patientCompliance.getLatestTherapyDate(),
							patientCompliance.getSettingsDeviatedDaysCount(),
							patientCompliance.getGlobalHMRNonAdherenceCounter(),
							patientCompliance.getGlobalSettingsDeviationCounter(),
							patientCompliance.getGlobalMissedTherapyCounter(),
							patientCompliance.getHmr());
					 		
					complianceListToSave.add(compliance);

				}
				complianceMonarchService.saveAll(complianceListToSave);
				
				List<Notification> notificationList = notificationRepository.findByPatientUserId(user.getId());
				
				List <NotificationMonarch> notificationListToSave = new LinkedList<>();
				
				for(Notification patientNotification : notificationList){
					NotificationMonarch notification = new NotificationMonarch(
							patientNotification.getNotificationType(),
							patientNotification.getDate(),
							patientNotification.getPatientUser(),
							patientNotification.getPatient(),
							patientNotification.isAcknowledged(),"");
							
					notificationListToSave.add(notification);
				}
				notificationMonarchService.saveAll(notificationListToSave);
				
				if(flag == 2){
					
					List<PatientProtocolDataMonarch> oldProtocolList = patientProtocolMonarchRepository.findByPatientId(patDevice.getOldPatientId());
					
					List<PatientProtocolDataMonarch> newProtocolList = new LinkedList<>();
					for(PatientProtocolDataMonarch oldProtocol : oldProtocolList){
						
						PatientProtocolDataMonarch newProtocol = new PatientProtocolDataMonarch(oldProtocol.getType(), patientInfo, user,
								oldProtocol.getTreatmentsPerDay(), oldProtocol.getMinMinutesPerTreatment(), oldProtocol.getTreatmentLabel(),
								oldProtocol.getMinFrequency(), oldProtocol.getMaxFrequency(), oldProtocol.getMinIntensity(),
								oldProtocol.getMaxIntensity());
						
						String protocolKey = patientProtocolMonarchRepository.id();
						
						newProtocol.setId(protocolKey);
						newProtocol.setProtocolKey(protocolKey);
						
						newProtocolList.add(newProtocol);
					}
					protocolMonarchService.saveAll(newProtocolList);							
					
					List<TherapySessionMonarch> therapySessionMonarchList = therapySessionMonarchRepository.findByPatientUserId(userOld.getId());
					
					List <TherapySessionMonarch> therapySessionListToSave = new LinkedList<>();
					
					for(TherapySessionMonarch patientTherapySession : therapySessionMonarchList){
						TherapySessionMonarch therapySession = new TherapySessionMonarch(patientInfo, user, 
								patientTherapySession.getDate(), patientTherapySession.getSessionNo(),
								patientTherapySession.getSessionType(), patientTherapySession.getStartTime(), patientTherapySession.getEndTime(),
								patientTherapySession.getFrequency(), patientTherapySession.getIntensity(), patientTherapySession.getDurationInMinutes(),
								patientTherapySession.getProgrammedCaughPauses(), patientTherapySession.getNormalCaughPauses(),
								patientTherapySession.getCaughPauseDuration(), patientTherapySession.getHmr(), patientTherapySession.getSerialNumber(),
								patientTherapySession.getBluetoothId(), patientTherapySession.getTherapyIndex(),
								patientTherapySession.getStartBatteryLevel(), patientTherapySession.getEndBatteryLevel(),
								patientTherapySession.getNumberOfEvents(), patientTherapySession.getNumberOfPods(), patientTherapySession.getDevWifi(),
								patientTherapySession.getDevLte(),patientTherapySession.getDevBt(),
								patientTherapySession.getDevVersion());
							
						therapySessionListToSave.add(therapySession);
					}
					therapySessionMonarchService.saveAll(therapySessionListToSave);
					
					
					PatientNoEventMonarch patientNoEventMonarch = noEventRepositoryMonarch.findByPatientUserId(userOld.getId());
					
					PatientNoEventMonarch patientNoEventExist = noEventRepositoryMonarch.findByPatientUserId(user.getId());
					if(Objects.isNull(patientNoEventExist)){
						
						PatientNoEventMonarch noEventMonarchToSave = new PatientNoEventMonarch(patientNoEventMonarch.getUserCreatedDate(),
								patientNoEventMonarch.getFirstTransmissionDate(), patientInfo, user);
						
						noEventMonarchService.save(noEventMonarchToSave);
					}
					
					if(Objects.nonNull(firstTransmissionDateMonarch) && Objects.nonNull(firstTransmissionDateVest))
						adherenceCalculationBoth(user.getId(), null, firstTransmissionDateMonarch, firstTransmissionDateVest, DEFAULT_COMPLIANCE_SCORE, userOld.getId(), 4);
				}
			}else if( Objects.nonNull(vestCreatedDate) && Objects.nonNull(monarchCreatedDate) && (vestCreatedDate.isAfter(monarchCreatedDate) 
													|| (vestCreatedDate.isEqual(monarchCreatedDate) && VEST.equals(patDevice.getDeviceType())) )){
				if(flag == 2){
					
					List<PatientProtocolData> oldProtocolList = patientProtocolRepository.findByPatientId(patDevice.getOldPatientId());
					
					List<PatientProtocolData> newProtocolList = new LinkedList<>();
					for(PatientProtocolData oldProtocol : oldProtocolList){
						
						PatientProtocolData newProtocol = new PatientProtocolData(oldProtocol.getType(), patientInfo, user,
								oldProtocol.getTreatmentsPerDay(), oldProtocol.getMinMinutesPerTreatment(), oldProtocol.getTreatmentLabel(),
								oldProtocol.getMinFrequency(), oldProtocol.getMaxFrequency(), oldProtocol.getMinPressure(),
								oldProtocol.getMaxPressure());

						String protocolKey = patientProtocolRepository.id();
						newProtocol.setId(protocolKey);
						newProtocol.setProtocolKey(protocolKey);
						
						newProtocolList.add(newProtocol);
					}
					protocolVestService.saveAll(newProtocolList);
					
					
					List<TherapySession> therapySessionList = therapySessionRepository.findByPatientUserId(userOld.getId());
					
					List <TherapySession> therapySessionListToSave = new LinkedList<>();
					
					for(TherapySession patientTherapySession : therapySessionList){
						TherapySession therapySession = new TherapySession(patientInfo, user, 
								patientTherapySession.getDate(), patientTherapySession.getSessionNo(),
								patientTherapySession.getSessionType(), patientTherapySession.getStartTime(), patientTherapySession.getEndTime(),
								patientTherapySession.getFrequency(), patientTherapySession.getPressure(), patientTherapySession.getDurationInMinutes(),
								patientTherapySession.getProgrammedCaughPauses(), patientTherapySession.getNormalCaughPauses(),
								patientTherapySession.getCaughPauseDuration(), patientTherapySession.getHmr(), patientTherapySession.getSerialNumber(),
								patientTherapySession.getBluetoothId());
							
						therapySessionListToSave.add(therapySession);
					}
					therapySessionService.saveAll(therapySessionListToSave);
					
					
					PatientNoEvent patientNoEvent = noEventRepository.findByPatientUserId(userOld.getId());
					
					PatientNoEvent patientNoEventExist = noEventRepository.findByPatientUserId(user.getId());
					if(Objects.isNull(patientNoEventExist)){
					
						PatientNoEvent noEventToSave = new PatientNoEvent(patientNoEvent.getUserCreatedDate(),
								patientNoEvent.getFirstTransmissionDate(), patientInfo, user);
					
						noEventService.save(noEventToSave);
					}
					
					if(Objects.nonNull(firstTransmissionDateVest) && Objects.nonNull(firstTransmissionDateMonarch))
						adherenceCalculationBoth(user.getId(), null, firstTransmissionDateVest, firstTransmissionDateMonarch, DEFAULT_COMPLIANCE_SCORE, userOld.getId(), 3);
				}	
					
			}
		}
	}
	}
	
	
	public void executeMergingProcessLoop(PatientDevicesAssoc patDevice){
		
		PatientNoEventMonarch patientNoEventMonarch = null;
		PatientNoEvent patientNoEvent = null;
		LocalDate firstTransmissionDateMonarch = null;
		LocalDate firstTransmissionDateVest = null;
		LocalDate vestCreatedDate = null;
		LocalDate monarchCreatedDate = null;
		String oldDeviceType = "";
		String currentDeviceType = "";
		int resetScore = 100;
		
		if(Objects.nonNull(patDevice.getOldPatientId())){

			List<PatientDevicesAssoc> devAssForPatientList = patientDevicesAssocRepository.findByPatientId(patDevice.getPatientId());
			
			if(devAssForPatientList.size()>1 && !patDevice.getOldPatientId().equals(patDevice.getPatientId())){
				
				//Get the current Patient details
				PatientInfo patientInfo = patientInfoRepository.findOneById(patDevice.getPatientId());
				User user = userService.getUserObjFromPatientInfo(patientInfo);
				
				// Get the Patient old details
				PatientInfo patientInfoOld = patientInfoRepository.findOneById(patDevice.getOldPatientId());
				User userOld = userService.getUserObjFromPatientInfo(patientInfoOld);
				
				if(patDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
					patientNoEventMonarch = noEventRepositoryMonarch.findByPatientUserId(userOld.getId());
					patientNoEvent = noEventRepository.findByPatientUserId(user.getId());	
					currentDeviceType = "MONARCH";
					oldDeviceType = "VEST";
				} else {
					patientNoEventMonarch = noEventRepositoryMonarch.findByPatientUserId(user.getId());
					patientNoEvent = noEventRepository.findByPatientUserId(userOld.getId());
					currentDeviceType = "VEST";
					oldDeviceType = "MONARCH";
				}
				
				// Looping through the patient devices
				for(PatientDevicesAssoc device : devAssForPatientList){
					if(VEST.equals(device.getDeviceType())){
						vestCreatedDate = device.getCreatedDate();
					}else if(MONARCH.equals(device.getDeviceType())){
						monarchCreatedDate = device.getCreatedDate();
					}
				}
				
				if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate())) {
					firstTransmissionDateVest = patientNoEvent.getFirstTransmissionDate();
				} else {
					firstTransmissionDateVest = vestCreatedDate;
				}
				
				if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate())) {
					firstTransmissionDateMonarch = patientNoEventMonarch.getFirstTransmissionDate();
				} else {
					firstTransmissionDateMonarch = monarchCreatedDate;
				}
				
				advanceAdherenceCalculationServiceMonarch.ProcessAdherenceResetCalculationForBoth(
						patientInfo,user,patientInfoOld,userOld,firstTransmissionDateVest,firstTransmissionDateMonarch,resetScore,currentDeviceType,oldDeviceType);

			}
		}
				
	}

	/**
	 * Runs every morning 9:15AM after the TIMS job executed to integrate the old patient who is swapped after identified from swapped date
	 */	
	@Scheduled(cron="${cron.adherence.monarch.mergeswap}")
	public void processMergeSwapDeviceDetails(){
		try{
			LocalDate today = LocalDate.now();
			log.debug("Started Device details "+DateTime.now()+","+today);
			
			// Get list of patient device assoc from the todays swapped date
			List<PatientDevicesAssoc> swapPatDevAssList = patientDevicesAssocRepository.findBySwappedDate(today.toString());
			
			// Calling swap process
			if(!swapPatDevAssList.isEmpty() && !swapPatDevAssList.equals(null)) {
				for(PatientDevicesAssoc patDevice : swapPatDevAssList){
					executeSwapMergingProcessLoop(patDevice);
				}
			}
			List<PatientDevicesAssoc> mergeDevAssList = patientDevicesAssocRepository.findByModifiedDate(today.toString());	

			// Looping through all the patient device association, for device update only once loop will be executed
			
			if(!mergeDevAssList.isEmpty() && !mergeDevAssList.equals(null)) {
				for(PatientDevicesAssoc patDevice : mergeDevAssList){
					executeMergingProcessLoop(patDevice);
				}
			}		
		}catch(Exception ex){
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			ex.printStackTrace( printWriter );
			mailService.sendJobFailureNotificationMonarch("processDeviceDetails",writer.toString());
		}
	}

	public void executeSwapMergingProcessLoop(PatientDevicesAssoc patDevice){
		
		// Verification of the device type
		if(patDevice.getDeviceType().equals("MONARCH")){
			advanceAdherenceCalculationServiceMonarch.executeSwapMonarchDevice(patDevice);			
		}else if(patDevice.getDeviceType().equals("VEST")){			
			advanceAdherenceCalculationService.executeSwapVestDevice(patDevice);
		}
	}
	
}
