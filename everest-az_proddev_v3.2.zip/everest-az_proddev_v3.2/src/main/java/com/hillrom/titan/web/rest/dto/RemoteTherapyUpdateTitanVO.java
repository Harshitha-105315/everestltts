package com.hillrom.titan.web.rest.dto;

import org.joda.time.DateTime;

public class RemoteTherapyUpdateTitanVO {
	private long id;
	private String patient_id;
	private DateTime createDate;
	private DateTime updateDate;
	private String therapyName;
	private Integer step;
	private Integer frequency;
	private Integer intensity;
	private Integer duration;
	private Integer caughPauseDuration;
	private Integer caughPauseEnable;
	private Integer caughIntervalMode;
	private Integer caughAutoEnable;
	private Integer caughPauseInterval;
	private String status;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getPatient_id() {
		return patient_id;
	}
	public void setPatient_id(String patient_id) {
		this.patient_id = patient_id;
	}
	public DateTime getCreateDate() {
		return createDate;
	}
	public void setCreateDate(DateTime createDate) {
		this.createDate = createDate;
	}
	public DateTime getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(DateTime updateDate) {
		this.updateDate = updateDate;
	}
	public String getTherapyName() {
		return therapyName;
	}
	public void setTherapyName(String therapyName) {
		this.therapyName = therapyName;
	}
	public Integer getStep() {
		return step;
	}
	public void setStep(Integer step) {
		this.step = step;
	}
	public Integer getFrequency() {
		return frequency;
	}
	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}
	public Integer getIntensity() {
		return intensity;
	}
	public void setIntensity(Integer intensity) {
		this.intensity = intensity;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public Integer getCaughPauseDuration() {
		return caughPauseDuration;
	}
	public void setCaughPauseDuration(Integer caughPauseDuration) {
		this.caughPauseDuration = caughPauseDuration;
	}
	public Integer getCaughPauseEnable() {
		return caughPauseEnable;
	}
	public void setCaughPauseEnable(Integer caughPauseEnable) {
		this.caughPauseEnable = caughPauseEnable;
	}
	public Integer getCaughIntervalMode() {
		return caughIntervalMode;
	}
	public void setCaughIntervalMode(Integer caughIntervalMode) {
		this.caughIntervalMode = caughIntervalMode;
	}
	public Integer getCaughAutoEnable() {
		return caughAutoEnable;
	}
	public void setCaughAutoEnable(Integer caughAutoEnable) {
		this.caughAutoEnable = caughAutoEnable;
	}
	public Integer getCaughPauseInterval() {
		return caughPauseInterval;
	}
	public void setCaughPauseInterval(Integer caughPauseInterval) {
		this.caughPauseInterval = caughPauseInterval;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "RemoteTherapyUpdateTitanVO [id=" + id + ", patient_id=" + patient_id + ", createDate=" + createDate
				+ ", updateDate=" + updateDate + ", therapyName=" + therapyName + ", step=" + step + ", frequency="
				+ frequency + ", intensity=" + intensity + ", duration=" + duration + ", caughPauseDuration="
				+ caughPauseDuration + ", caughPauseEnable=" + caughPauseEnable + ", caughIntervalMode="
				+ caughIntervalMode + ", caughAutoEnable=" + caughAutoEnable + ", caughPauseInterval="
				+ caughPauseInterval + ", status=" + status + "]";
	}
	
	
}