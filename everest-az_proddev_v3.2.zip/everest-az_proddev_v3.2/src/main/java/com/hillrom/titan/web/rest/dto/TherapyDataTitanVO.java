package com.hillrom.titan.web.rest.dto;


import java.io.Serializable;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hillrom.vest.domain.Note;
import com.hillrom.vest.domain.NoteTitan;
import com.hillrom.vest.domain.util.DateTimeSerializer;

public class TherapyDataTitanVO implements Serializable,Comparable<TherapyDataTitanVO> {

	@JsonSerialize(using= DateTimeSerializer.class)
	private DateTime timestamp;
	private int treatmentsPerDay;
	private int sessionNo;
	private int frequency;
	private int pressure;
	private int programmedCoughPauses;
	private int normalCoughPauses;
	private int coughPauses;
	//private Note note;
	@JsonSerialize(using= DateTimeSerializer.class)
	private DateTime start;
	@JsonSerialize(using= DateTimeSerializer.class)
	private DateTime end;
	private int coughPauseDuration;
	private int duration;
	private double hmr;
	private boolean missedTherapy;
	private NoteTitan note;
	private int intensity;
	

	List <Integer> errorList = null;
	List <Integer> bluetoothSource = null;
	List <String> powerConnectStatus = null;


	public TherapyDataTitanVO(DateTime timestamp, int treatmentsPerDay,int sessionNo,
			int frequency, int intensity, int coughPauses, NoteTitan note, DateTime start,
			DateTime end, int coughPauseDuration, int duration, double hmr,boolean missedTherapy,
			List <Integer> errorList, List <Integer> bluetoothSource, List <String> powerConnectStatus ) {
		super();
		this.timestamp = timestamp;
		this.treatmentsPerDay = treatmentsPerDay;
		this.sessionNo = sessionNo;
		this.frequency = frequency;
		this.intensity = intensity;
		this.coughPauses = coughPauses;
		this.note = note;
		this.start = start;
		this.end = end;
		this.coughPauseDuration = coughPauseDuration;
		this.duration = duration;
		this.hmr = hmr;
		this.missedTherapy = missedTherapy;
		this.errorList = errorList;
		this.bluetoothSource = bluetoothSource;
		this.powerConnectStatus = powerConnectStatus;
	}

	public TherapyDataTitanVO(DateTime timestamp, int frequency, int intensity, int coughPauses,
			NoteTitan note, DateTime start, DateTime end, int coughPauseDuration,
			int duration, double hmr, boolean missedTherapy) {
		super();
		this.timestamp = timestamp;
		this.frequency = frequency;
		this.intensity = intensity;
		this.coughPauses = coughPauses;
		this.note = note;
		this.start = start;
		this.end = end;
		this.coughPauseDuration = coughPauseDuration;
		this.duration = duration;
		this.hmr = hmr;
		this.missedTherapy = missedTherapy;
	}



	/**
	 * @return the errorList
	 */
	public List<Integer> getErrorList() {
		return errorList;
	}

	/**
	 * @param errorList the errorList to set
	 */
	public void setErrorList(List<Integer> errorList) {
		this.errorList = errorList;
	}

	/**
	 * @return the bluetoothSource
	 */
	public List<Integer> getBluetoothSource() {
		return bluetoothSource;
	}

	/**
	 * @param bluetoothSource the bluetoothSource to set
	 */
	public void setBluetoothSource(List<Integer> bluetoothSource) {
		this.bluetoothSource = bluetoothSource;
	}

	/**
	 * @return the powerConnectStatus
	 */
	public List<String> getPowerConnectStatus() {
		return powerConnectStatus;
	}

	/**
	 * @param powerConnectStatus the powerConnectStatus to set
	 */
	public void setPowerConnectStatus(List<String> powerConnectStatus) {
		this.powerConnectStatus = powerConnectStatus;
	}


	public TherapyDataTitanVO() {
		super();
	}

	public DateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(DateTime timestamp) {
		this.timestamp = timestamp;
	}

	public int getTreatmentsPerDay() {
		return treatmentsPerDay;
	}

	public void setTreatmentsPerDay(int treatmentsPerDay) {
		this.treatmentsPerDay = treatmentsPerDay;
	}

	public int getSessionNo() {
		return sessionNo;
	}

	public void setSessionNo(int sessionNo) {
		this.sessionNo = sessionNo;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public int getPressure() {
		return pressure;
	}

	public void setPressure(int pressure) {
		this.pressure = pressure;
	}

	public int getCoughPauses() {
		return coughPauses;
	}

	public void setCoughPauses(int coughPauses) {
		this.coughPauses = coughPauses;
	}

	public NoteTitan getNote() {
		return note;
	}

	public void setNote(NoteTitan note) {
		this.note = note;
	}

	public DateTime getStart() {
		return start;
	}

	public void setStart(DateTime start) {
		this.start = start;
	}

	public DateTime getEnd() {
		return end;
	}

	public void setEnd(DateTime end) {
		this.end = end;
	}

	public int getCoughPauseDuration() {
		return coughPauseDuration;
	}

	public void setCoughPauseDuration(int coughPauseDuration) {
		this.coughPauseDuration = coughPauseDuration;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getHmr() {
		return hmr;
	}

	public void setHmr(double hmr) {
		this.hmr = hmr;
	}

	public boolean isMissedTherapy() {
		return missedTherapy;
	}

	public void setMissedTherapy(boolean missedTherapy) {
		this.missedTherapy = missedTherapy;
	}

	public NoteTitan getNoteTitan() {
		return note;
	}

	public void setNoteTitan(NoteTitan noteTitan) {
		this.note = noteTitan;
	}
	public int getIntensity() {
		return intensity;
	}

	public void setIntensity(int intensity) {
		this.intensity = intensity;
	}

	@Override
	public String toString() {
		return "TherapyDataTitanVO [timestamp=" + timestamp + ", treatmentsPerDay=" + treatmentsPerDay + ", sessionNo="
				+ sessionNo + ", frequency=" + frequency + ", pressure=" + pressure + ", programmedCoughPauses="
				+ programmedCoughPauses + ", normalCoughPauses=" + normalCoughPauses + ", coughPauses=" + coughPauses
				+ ", start=" + start + ", end=" + end + ", coughPauseDuration=" + coughPauseDuration + ", duration="
				+ duration + ", hmr=" + hmr + ", missedTherapy=" + missedTherapy + ", note=" + note + ", intensity="
				+ intensity + ", errorList=" + errorList + ", bluetoothSource=" + bluetoothSource
				+ ", powerConnectStatus=" + powerConnectStatus + "]";
	}

	@Override
	public int compareTo(TherapyDataTitanVO o) {
		return this.timestamp.compareTo(o.getTimestamp());
	}

	@JsonIgnore
	public LocalDate getDate(){
		return this.timestamp.toLocalDate();
	}
}