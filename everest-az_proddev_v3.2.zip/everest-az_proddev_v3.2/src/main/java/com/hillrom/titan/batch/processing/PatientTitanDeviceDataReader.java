package com.hillrom.titan.batch.processing;

import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.security.AuthoritiesConstants.PATIENT;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.mobile.service.AwardsAndBadgesCalculatorService;
import com.hillrom.titan.repository.PatientTitanDeviceDataRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRawLogRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.titan.service.AdvanceAdherenceCalculationServiceTitan;
import com.hillrom.titan.service.PatientComplianceTitanService;
import com.hillrom.titan.service.PatientNoEventTitanService;
import com.hillrom.titan.service.PatientVestDeviceDataServiceTitan;
import com.hillrom.titan.service.TherapySessionServiceTitan;
import com.hillrom.titan.service.util.PatientVestDeviceTherapyUtilTitan;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.PatientVestDeviceRawLogTitan;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.domain.UserPatientAssocPK;
import com.hillrom.vest.repository.AuthorityRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.DeviceLogTitanParser;
import com.hillrom.vest.service.PatientInfoService;
import com.hillrom.vest.util.RelationshipLabelConstants;

public class PatientTitanDeviceDataReader implements ItemReader<List<PatientVestDeviceDataTitan>> {

	private final Logger log = LoggerFactory.getLogger(PatientTitanDeviceDataReader.class);
	
	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject
	private UserExtensionRepository userExtensionRepository;

	@Inject
	private AuthorityRepository authorityRepository;

	@Inject
	private DeviceLogTitanParser deviceLogTitanParser;

	@Inject
	private PatientNoEventTitanService noEventServiceTitan;

	@Inject
	private TherapySessionServiceTitan therapySessionServiceTitan;

	@Inject
	private PatientComplianceTitanService complianceTitanService;
	
	@Inject
	private PatientTitanDeviceRawLogRepository deviceRawLogRepositoryTitan;

	@Inject
    private PatientTitanDeviceRepository patientTitanDeviceRepository;
	
	@Inject
    private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject
	PatientVestDeviceDataServiceTitan patientVestDeviceDataServiceTitan;
	
	@Inject
	private PatientTitanDeviceDataRepository titanDeviceDataRepository;
	
	@Inject
    private PatientInfoService patientInfoService;
	
	@Inject
	private AwardsAndBadgesCalculatorService awardsAndBadgesCalculatorService;
	
	@Inject
	private AdvanceAdherenceCalculationServiceTitan advanceAdherenceCalculationServiceTitan;
	
	private String patientDeviceRawData;
	
	private boolean isReadComplete;

	@Value("#{jobParameters['rawData']}")
	public void setRawData(final String rawData) {
		this.patientDeviceRawData = rawData;
		this.isReadComplete = false;
	}

	@Transactional
	private synchronized List<PatientVestDeviceDataTitan> parseRawData() throws Exception{
		log.debug("Parsing started rawData : ",patientDeviceRawData);
		PatientVestDeviceRawLogTitan deviceRawLogTitan= null;

		List<PatientVestDeviceDataTitan> patientVestDeviceEventsTitan = null;
		deviceRawLogTitan = deviceLogTitanParser.parseBase64StringToPatientTitanDeviceRawLog(patientDeviceRawData);

		deviceRawLogRepositoryTitan.save(deviceRawLogTitan);

		patientVestDeviceEventsTitan = deviceLogTitanParser.parseBase64StringToPatientTitanDeviceLogEntry(patientDeviceRawData,deviceRawLogTitan.getId());


		String deviceSerialNumber = deviceRawLogTitan.getDeviceSerialNumber();


		if(!patientVestDeviceEventsTitan.isEmpty())
		{
			UserPatientAssoc userPatientAssoc = createPatientUserIfNotExists(deviceRawLogTitan, deviceSerialNumber,patientVestDeviceEventsTitan);
			log.debug("userPatientAssoc created : "+userPatientAssoc);
			assignDefaultValuesToVestDeviceDataTempTitan(deviceRawLogTitan, patientVestDeviceEventsTitan, userPatientAssoc);
		}
		return patientVestDeviceEventsTitan;
	}
	
	@Transactional
	private synchronized UserPatientAssoc createPatientUserIfNotExists(PatientVestDeviceRawLogTitan deviceRawLog,
			String deviceSerialNumber,List<PatientVestDeviceDataTitan> patientVestDeviceEventsTitan) throws Exception{

		log.debug("createPatientUserIfNotExists serial number : "+deviceSerialNumber);
		
		Optional<PatientDevicesAssoc> patientDevicesFromDB = patientDevicesAssocRepository.findOneBySerialNumber(deviceSerialNumber);
		PatientInfo patientInfo = null;
		String devBT=null; 
		String dev_wifi=null; 

		List<PatientVestDeviceHistoryTitan> patientTitanDeviceHistoryList = new LinkedList<>();
		patientTitanDeviceHistoryList = patientTitanDeviceRepository.findBySerialNumber(deviceSerialNumber);

		if(!patientVestDeviceEventsTitan.isEmpty()){
			devBT = patientVestDeviceEventsTitan.get(0).getDevBt();
			dev_wifi = patientVestDeviceEventsTitan.get(0).getDevWifi();
		}

		if (patientDevicesFromDB.isPresent()) {

			if(!patientTitanDeviceHistoryList.isEmpty()){
				for(PatientVestDeviceHistoryTitan patientTitanDevicePatient : patientTitanDeviceHistoryList){
					if(Objects.nonNull(patientTitanDevicePatient) && patientTitanDevicePatient.isPending() 
							&& deviceSerialNumber.equalsIgnoreCase(patientTitanDevicePatient.getSerialNumber())){
						patientTitanDevicePatient.setPending(false);
						patientTitanDeviceRepository.save(patientTitanDevicePatient);
					}
					if(Objects.nonNull(patientTitanDevicePatient) && patientTitanDevicePatient.isActive() 
							&& deviceSerialNumber.equalsIgnoreCase(patientTitanDevicePatient.getSerialNumber())){
						patientTitanDevicePatient.setDevBt(devBT);
						patientTitanDevicePatient.setWifiId(dev_wifi);
						patientTitanDeviceRepository.save(patientTitanDevicePatient);
					}
				}
			}

			return retrieveUserPatientAssoc(patientDevicesFromDB.get().getPatientId());
		} else {
			if(!patientTitanDeviceHistoryList.isEmpty()){
				PatientVestDeviceHistoryTitan patientTitanDevicePatient = patientTitanDeviceHistoryList.get(0);

				Optional<PatientVestDeviceHistoryTitan> patientTitanDeviceHistory = patientTitanDeviceRepository.findOneByPatientIdAndPendingStatus(patientTitanDevicePatient.getPatient().getId(), true);

				if (patientTitanDeviceHistory.isPresent()){
					return retrieveUserPatientAssoc(patientTitanDevicePatient.getPatient().getId());
				}
			}

			patientInfo = new PatientInfo();
			// Assigns the next hillromId for the patient
			String hillromId = patientInfoRepository.id();
			patientInfo.setId(hillromId);
			patientInfo.setHillromId(hillromId);
			patientInfo.setBluetoothId(deviceRawLog.getDeviceAddress());
			//patientInfo.setHubId(deviceRawLog.getHubId());
			patientInfo.setSerialNumber(deviceRawLog.getDeviceSerialNumber());
			patientInfo.setDeviceAssocDate(new DateTime());
			//String customerName = deviceRawLog.getCustomerName();
			// Hardcoded the patient name to Hill-Rom Titan for Titan users
			setNameToPatient(patientInfo, "Hill-Rom Titan");
			patientInfo = patientInfoRepository.save(patientInfo);
			log.debug("create patientInfo : "+patientInfo);

			UserExtension userExtension = new UserExtension();
			userExtension.setHillromId(patientInfo.getHillromId());
			userExtension.setActivated(true);
			userExtension.setDeleted(false);
			userExtension.setFirstName(patientInfo.getFirstName());
			userExtension.setLastName(patientInfo.getLastName());
			userExtension.setMiddleName(patientInfo.getMiddleName());
			userExtension.getAuthorities().add(authorityRepository.findOne(PATIENT));
			userExtensionRepository.save(userExtension);
			log.debug("create userExtention : "+userExtension);
			
			UserPatientAssoc userPatientAssoc = new UserPatientAssoc(new UserPatientAssocPK(patientInfo, userExtension),
					AuthoritiesConstants.PATIENT, RelationshipLabelConstants.SELF);

			userPatientRepository.save(userPatientAssoc);

			userExtension.getUserPatientAssoc().add(userPatientAssoc);
			patientInfo.getUserPatientAssoc().add(userPatientAssoc);

			userExtensionRepository.save(userExtension);
			patientInfoRepository.save(patientInfo);
			LocalDate createdOrTransmittedDate = userExtension.getCreatedDate().toLocalDate();
			noEventServiceTitan.createIfNotExists(
					new PatientNoEventTitan(createdOrTransmittedDate, createdOrTransmittedDate, patientInfo, userExtension));
			PatientComplianceTitan compliance = new PatientComplianceTitan();
			compliance.setPatient(patientInfo);
			compliance.setPatientUser(userExtension);
			compliance.setDate(userExtension.getCreatedDate().toLocalDate());
			compliance.setScore(DEFAULT_COMPLIANCE_SCORE);
			compliance.setLatestTherapyDate(createdOrTransmittedDate);
			complianceTitanService.createOrUpdate(compliance);
			
			// Create Patient Device History
			PatientVestDeviceHistoryTitan deviceHistoryTitan = new PatientVestDeviceHistoryTitan(new PatientVestDevicePK(patientInfo, patientInfo.getSerialNumber()),
					patientInfo.getBluetoothId(), patientInfo.getHubId(), true, false);
			deviceHistoryTitan.setDevBt(devBT);
			deviceHistoryTitan.setWifiId(dev_wifi);
			patientTitanDeviceRepository.save(deviceHistoryTitan);
			log.debug("deviceHistoryTitan : "+deviceHistoryTitan);
			
			PatientDevicesAssoc deviceAssoc = new PatientDevicesAssoc(patientInfo.getId(), "Titan", true, deviceSerialNumber);
			deviceAssoc.setHillromId(patientInfo.getHillromId());			
			patientDevicesAssocRepository.save(deviceAssoc);
			log.debug("deviceAssoc : "+deviceAssoc);

			return userPatientAssoc;
		}
	}
	

	@Override
	public List<PatientVestDeviceDataTitan> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		log.debug("ItemReader started");
		if (isReadComplete)
			return null;

		List<PatientVestDeviceDataTitan> patientVestDeviceEventsTitan = parseRawData();
		log.debug("patientVestDeviceEventsTitan after parseRawData :: "+patientVestDeviceEventsTitan);
		
		Long patientUserId = 0l, from,to;
		String serialNumber = "";
		String patientId = "";
		if(patientVestDeviceEventsTitan.isEmpty()){
		// this is required to let reader to know there is nothing to be read further
			isReadComplete = true;  
			return patientVestDeviceEventsTitan; // spring batch reader to skip reading
		}
		
		patientUserId = patientVestDeviceEventsTitan.get(0).getPatientUser().getId();
		patientId = patientVestDeviceEventsTitan.get(0).getPatient().getId();
		log.debug("patientUserId :: "+patientUserId + "patientId ::"+patientId);
		Collections.sort(patientVestDeviceEventsTitan);
		from = patientVestDeviceEventsTitan.get(0).getTimestamp();
		to = patientVestDeviceEventsTitan.get(patientVestDeviceEventsTitan.size()-1).getTimestamp();
		log.debug("from :: "+from + "to ::"+to);
		serialNumber = patientVestDeviceEventsTitan.get(0).getSerialNumber();
		
		int therapyIndex = patientVestDeviceEventsTitan.get(0).getTherapyIndex();
		int fragTotal = patientVestDeviceEventsTitan.get(0).getFragTotal();
		int fragCurr = patientVestDeviceEventsTitan.get(0).getFragCurrent();			
					
		// Commenting the code to get the existing events to make the diff with current events
		List<PatientVestDeviceDataTitan> existingEvents = titanDeviceDataRepository.findByPatientUserIdAndTimestampBetween(patientUserId, from, to);
		log.debug("existingEvents :: "+existingEvents);

		log.debug("Calculating the Delta ");
		List<PatientVestDeviceDataTitan> patientVestDeviceRecords = getDelta(existingEvents, patientVestDeviceEventsTitan);
		
		// If no new events available , return empty list
		if(patientVestDeviceRecords.isEmpty()){
			log.debug("NO NEW EVENTS FOUND");
			return patientVestDeviceRecords;
		}
		
		if(fragTotal == 1 || (fragTotal != 1 && fragTotal == fragCurr)){		
			List<PatientVestDeviceDataTitan> patientVestDeviceRecordsTitan = new LinkedList<>();
			
			if(fragTotal != 1 && fragTotal == fragCurr){
				List<PatientVestDeviceDataTitan> existingVestDeviceEventsTitan = patientVestDeviceDataServiceTitan.getDeviceDataForAllFragments(patientUserId, serialNumber, therapyIndex);
				
				patientVestDeviceRecordsTitan.addAll(existingVestDeviceEventsTitan);
				patientVestDeviceRecordsTitan.addAll(patientVestDeviceEventsTitan);
			}else{
				patientVestDeviceRecordsTitan = patientVestDeviceEventsTitan;
			}
			
			PatientVestDeviceHistoryTitan latestInActiveDevice = patientTitanDeviceRepository.findLatestInActiveDeviceByPatientId(patientId, false);
			log.debug("latestInActiveDevice :: "+latestInActiveDevice);
			List<TherapySessionTitan> therapySessionsTitan = PatientVestDeviceTherapyUtilTitan
					.prepareTherapySessionFromDeviceDataTitan(patientVestDeviceRecordsTitan,latestInActiveDevice,patientDeviceRawData);
	
			if(therapySessionsTitan.isEmpty()){
				log.debug("Could not make session out of the events received, discarding to get delta");
				isReadComplete = true;
				return new LinkedList<PatientVestDeviceDataTitan>();
			}
			//therapySessionServiceTitan.saveOrUpdate(therapySessionsTitan);
			advanceAdherenceCalculationServiceTitan.saveOrUpdate(therapySessionsTitan);
			awardsAndBadgesCalculatorService.vestLogMetrics(patientId);
			
			PatientInfo patient = patientVestDeviceEventsTitan.get(0).getPatient();		
			patient.setLastTitan(therapySessionServiceTitan.getLatestEndTime(patientId));
			patientInfoRepository.saveAndFlush(patient);
		}
		
		isReadComplete = true;
		return patientVestDeviceEventsTitan;
	}

	private synchronized void assignDefaultValuesToVestDeviceDataTempTitan(PatientVestDeviceRawLogTitan deviceRawLogTitan,
			List<PatientVestDeviceDataTitan> patientVestDeviceRecordsTitan, UserPatientAssoc userPatientAssoc) throws Exception{
		patientVestDeviceRecordsTitan.stream().forEach(deviceData -> {
			//deviceData.setHubId(deviceRawLog.getHubId());
			deviceData.setSerialNumber(deviceRawLogTitan.getDeviceSerialNumber());
			deviceData.setPatient(userPatientAssoc.getPatient());
			deviceData.setPatientUser(userPatientAssoc.getUser());
			//deviceData.setBluetoothId(deviceRawLog.getDeviceAddress());
		});
	}

	
	public UserPatientAssoc retrieveUserPatientAssoc(String patientId){
		PatientInfo patientInfo = patientInfoService.findOneById(patientId);
		List<UserPatientAssoc> associations = new ArrayList<UserPatientAssoc> (patientInfo.getUserPatientAssoc());
		List<UserPatientAssoc> userPatientAssociations = associations.stream()
				.filter(assoc -> RelationshipLabelConstants.SELF.equalsIgnoreCase(assoc.getRelationshipLabel()))
				.collect(Collectors.toList());
		return userPatientAssociations.get(0);
	}

	private void setNameToPatient(PatientInfo patientInfo, String customerName) {
		String names[] = customerName.split(" ");
		if (names.length == 2) {
			assignNameToPatient(patientInfo, names[1], names[0], null);
		}
		if (names.length == 3) {
			assignNameToPatient(patientInfo, names[2], names[1], names[0]);
		}
		if (names.length == 1) {
			assignNameToPatient(patientInfo, names[0], null, null);
		}
	}

	private void assignNameToPatient(PatientInfo patientInfo, String firstName, String lastName, String middleName) {
		patientInfo.setFirstName(firstName);
		patientInfo.setLastName(lastName);
		patientInfo.setMiddleName(middleName);
	}
	
	private List<PatientVestDeviceDataTitan> getDelta(List<PatientVestDeviceDataTitan> existingEvents, List<PatientVestDeviceDataTitan> newEvents){
		isReadComplete = true;
		if(Objects.isNull(existingEvents) || existingEvents.isEmpty())
			return newEvents;
		else{
			Iterator<PatientVestDeviceDataTitan> itr = newEvents.iterator();
			while(itr.hasNext()){
				PatientVestDeviceDataTitan newEvent = itr.next();
				for(PatientVestDeviceDataTitan existingData : existingEvents){
					if(newEvent.getTimestamp().equals(existingData.getTimestamp()) &&
					   newEvent.getBluetoothId().equals(existingData.getBluetoothId()) && 
					   newEvent.getEventCode().equals(existingData.getEventCode())){
						itr.remove();
						break;
					}
				}
			}
			Collections.sort(newEvents);
			return newEvents;
		}
	}
}
