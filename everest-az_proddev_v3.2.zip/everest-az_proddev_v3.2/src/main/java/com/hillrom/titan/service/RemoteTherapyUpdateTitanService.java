package com.hillrom.titan.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.hillrom.mobile.service.PushNotificationService;
import com.hillrom.titan.dto.TherapySettingDTO;
import com.hillrom.titan.dto.TherapyTypeDTO;
import com.hillrom.titan.repository.RemoteTherapyUpdateHistoryTitanRepository;
import com.hillrom.titan.repository.RemoteTherapyUpdateTitanRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants;
import com.hillrom.vest.domain.RemoteTherapyUpdateHistoryTitan;
import com.hillrom.vest.domain.RemoteTherapyUpdateTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.util.ExceptionConstants;

@Service
@Transactional
public class RemoteTherapyUpdateTitanService {
	
	private final Logger log = LoggerFactory.getLogger(RemoteTherapyUpdateTitanService.class);

	 @Inject
	 private RemoteTherapyUpdateTitanRepository remoteTherapyUpdateTitanRepository;
	 
	 @Inject
	private PushNotificationService pushNotificationService;
	 
	@Inject
	private RemoteTherapyUpdateHistoryTitanRepository remoteTherapyUpdateHistoryTitanRepository;
	
	@Inject
	private TitanDataService titanDataService;
	
	
	 public TherapySettingDTO prepareTherapySettingData(Map<String, String> paraMap,String patientId) throws HillromException {
		 TherapySettingDTO tsDTO = new TherapySettingDTO();
		 Map<String,TherapyTypeDTO> mtherapyDto = new HashMap<String,TherapyTypeDTO>();
		 List<RemoteTherapyUpdateTitan> listRtpDetails = null;

		 listRtpDetails = remoteTherapyUpdateTitanRepository.findByPatientId(patientId);	
		 log.info("remoteTherapyUpdateTitan : "+listRtpDetails);

		 tsDTO.setRequestId(paraMap.get(PatientVestDeviceRawLogModelConstants.REQ_ID));
		 tsDTO.setResult(Constants.OK);
		 tsDTO.setRecordId(paraMap.get(PatientVestDeviceRawLogModelConstants.COMMAND_PARAM));

		 if(listRtpDetails.get(0).isDeleted())
		 {
			 tsDTO.setResult(Constants.FAIL);
			 return tsDTO;
		 }
		 else if(!listRtpDetails.get(0).isAccepted())
		 {
		 if(!listRtpDetails.isEmpty()){
			 Map<Integer,List<RemoteTherapyUpdateTitan>> hThearpyType = listRtpDetails.stream().collect(Collectors.groupingBy(RemoteTherapyUpdateTitan :: getTherapyType));
			 log.info("RemoteTherapyUpdateTitan grouped by therapy type : "+hThearpyType);

			 for(Map.Entry<Integer, List<RemoteTherapyUpdateTitan>> entryMap:hThearpyType.entrySet() ) {
				 TherapyTypeDTO therapyTypeDTO =  new TherapyTypeDTO();
				 StringBuilder therapyParam = new StringBuilder();

				 String therapyType = entryMap.getKey() == 1 ? PatientVestDeviceRawLogModelConstants.BASIC : entryMap.getKey() == 2 ? PatientVestDeviceRawLogModelConstants.PROGRAM5 : PatientVestDeviceRawLogModelConstants.PROGRAMMYTHERAPY;
				 log.info("therapyType : "+therapyType);

				 listRtpDetails = entryMap.getValue();

				 for (RemoteTherapyUpdateTitan remoteTherapyUpdateTitan : listRtpDetails) {
					 therapyTypeDTO.setTherapyName(remoteTherapyUpdateTitan.getTherapyName());
					 if(remoteTherapyUpdateTitan.getDuration() > 0) {
						 therapyTypeDTO.setThearpyParamCount(remoteTherapyUpdateTitan.getStep());
					 }

					 List<Integer> listParam = setThearpyParam(remoteTherapyUpdateTitan);
					 therapyParam.append(listParam).append(",");

					 therapyTypeDTO.setTherapyParam(therapyParam.toString());

					 String therapyCoughPause = new StringBuilder().append(remoteTherapyUpdateTitan.getCaughPauseEnable()).append(",").append(remoteTherapyUpdateTitan.getCaughIntervalMode()).append(",").append(remoteTherapyUpdateTitan.getCaughAutoEnable())
							 .append(",").append(remoteTherapyUpdateTitan.getCaughPauseDuration()).append(",").append(remoteTherapyUpdateTitan.getCaughPauseInterval()).toString();

					 therapyTypeDTO.setTherapyCoughPause(therapyCoughPause);

					 mtherapyDto.put(therapyType, therapyTypeDTO);

					 tsDTO.setTheraptData(mtherapyDto);
				 }

			 }
		 }
		 else {
			 throw new HillromException(ExceptionConstants.HR_962);
		 }
		 }else {
			 tsDTO.setResult(Constants.FAIL);
			 return tsDTO;
		 }
		 log.info("tsDTO : "+tsDTO);
		 return tsDTO;
	 }
	
	public List<Integer> setThearpyParam(RemoteTherapyUpdateTitan remoteTherapyUpdateTitan) {
		List<Integer> listParam = new ArrayList<>();
		
		listParam.add(remoteTherapyUpdateTitan.getDuration());
		listParam.add(remoteTherapyUpdateTitan.getFrequency());
		listParam.add(remoteTherapyUpdateTitan.getIntensity());
		
		return listParam;
	}

	public TherapySettingDTO updateTherapySettingStatusToAccepted(Map<String, String> paraMap,String patientId) throws HillromException {
		List<RemoteTherapyUpdateTitan > results =remoteTherapyUpdateTitanRepository.findByPatientId(patientId);
		TherapySettingDTO tsDTO = new TherapySettingDTO();
		tsDTO.setRequestId(paraMap.get(PatientVestDeviceRawLogModelConstants.REQ_ID));
		tsDTO.setResult(Constants.OK);
		tsDTO.setRecordId(paraMap.get(PatientVestDeviceRawLogModelConstants.COMMAND_PARAM));
		if(results.isEmpty()) {
			throw new HillromException(ExceptionConstants.HR_960);	
		}else {
			if(!results.get(0).isAccepted()) {
				// Push notifications for Remote Therapy Update Accepted
				pushNotificationService.pushNotificationForRemoteTherapyUpdate(patientId, "Therapy settings have been updated on the Vest® APX System", "RemoteTherapyUpdateAccepted");
			}
			for(RemoteTherapyUpdateTitan remoteTherapyUpdate : results) {
				if(!remoteTherapyUpdate.isAccepted()) {
					if(!remoteTherapyUpdate.isDeleted()) {
						remoteTherapyUpdate.setAccepted(true);
						remoteTherapyUpdate.setStatus(PatientVestDeviceRawLogModelConstants.ACCEPTED);
						remoteTherapyUpdateTitanRepository.save(remoteTherapyUpdate);
					}else {
						 tsDTO.setResult(Constants.FAIL);
						 return tsDTO;
					}
				}
				else {
					tsDTO.setResult(Constants.FAIL);
				}
			}
			
			//Save ACCEPTED code changes to rtu history table (REMOTE_THERAPY_UPDATE_HISTORY_TITAN)
			if(!Constants.FAIL.equalsIgnoreCase(tsDTO.getResult())) {
				//Get All RTU History records by Patient Id and Status with PENDING
				List<RemoteTherapyUpdateHistoryTitan> lstRemoteTherapyHistoryData = remoteTherapyUpdateHistoryTitanRepository.findByPatientIdAndStatus(patientId, PatientVestDeviceRawLogModelConstants.PENDING);
				log.debug("rtu history data ::"+lstRemoteTherapyHistoryData);

				if (!CollectionUtils.isEmpty(lstRemoteTherapyHistoryData)) {
					for (RemoteTherapyUpdateHistoryTitan remoteTherapyUpdateHistoryTitan : lstRemoteTherapyHistoryData) {
						remoteTherapyUpdateHistoryTitan.setStatus(PatientVestDeviceRawLogModelConstants.ACCEPTED);
						remoteTherapyUpdateHistoryTitan.setUpdateDate(new DateTime());
						remoteTherapyUpdateHistoryTitanRepository.save(remoteTherapyUpdateHistoryTitan);
					}
				}
			}
		}
		return tsDTO;
	}

	public TherapySettingDTO updateTherapySettingStatusToRejected(Map<String, String> paraMap,String patientId) throws HillromException {
		List<RemoteTherapyUpdateTitan > results =remoteTherapyUpdateTitanRepository.findByPatientId(patientId);
		TherapySettingDTO tsDTO = new TherapySettingDTO();
		tsDTO.setRequestId(paraMap.get(PatientVestDeviceRawLogModelConstants.REQ_ID));
		tsDTO.setResult(Constants.OK);
		tsDTO.setRecordId(paraMap.get(PatientVestDeviceRawLogModelConstants.COMMAND_PARAM));
		if(results.isEmpty()) {
			throw new HillromException(ExceptionConstants.HR_960);	
		}else {
			for(RemoteTherapyUpdateTitan remoteTherapyUpdate : results) {
				if(!remoteTherapyUpdate.isDeleted()) {
					remoteTherapyUpdate.setDeleted(true);
					remoteTherapyUpdate.setStatus(PatientVestDeviceRawLogModelConstants.REJECTED);
					remoteTherapyUpdate.setUpdateDate(new DateTime());
					remoteTherapyUpdateTitanRepository.save(remoteTherapyUpdate);
					
				}else {
					tsDTO.setResult(Constants.FAIL);
					return tsDTO;
				}
			}
			// Push notifications for Remote Therapy Update Rejected
			pushNotificationService.pushNotificationForRemoteTherapyUpdate(patientId, "Request to update therapy settings has been rejected on the Vest® APX System", "RemoteTherapyUpdateRejected");
		}
		
		//Save REJECTED code changes to rtu history table (REMOTE_THERAPY_UPDATE_HISTORY_TITAN)
		if(!Constants.FAIL.equalsIgnoreCase(tsDTO.getResult())) {
			//Get All RTU History records by Patient Id and Status with PENDING
			List<RemoteTherapyUpdateHistoryTitan> rtuHistoryRecords = remoteTherapyUpdateHistoryTitanRepository.findByPatientIdAndStatus(patientId, PatientVestDeviceRawLogModelConstants.PENDING);

			if (CollectionUtils.isEmpty(rtuHistoryRecords)) {
				titanDataService.createRtuHistory(patientId, results);
			} else {
				updateRTUHistory(PatientVestDeviceRawLogModelConstants.REJECTED, rtuHistoryRecords);
			}
		}
		log.debug("TherapySettingDTO result----------"+tsDTO);
		return tsDTO;
	}
	
	private void updateRTUHistory(String status, List<RemoteTherapyUpdateHistoryTitan> remoteTherapyHistory)
			throws HillromException {

		for (RemoteTherapyUpdateHistoryTitan rtuh : remoteTherapyHistory) {
			// need to check on delete property
			rtuh.setStatus(status);
			rtuh.setUpdateDate(new DateTime());
		}
		
		remoteTherapyUpdateHistoryTitanRepository.save(remoteTherapyHistory);

	}
}
