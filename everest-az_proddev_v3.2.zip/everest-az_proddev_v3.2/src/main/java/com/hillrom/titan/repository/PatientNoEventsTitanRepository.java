package com.hillrom.titan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hillrom.vest.domain.PatientNoEventTitan;


public interface PatientNoEventsTitanRepository extends JpaRepository<PatientNoEventTitan, Long>{
	
	PatientNoEventTitan findByPatientUserId(Long patientUserId);

}
