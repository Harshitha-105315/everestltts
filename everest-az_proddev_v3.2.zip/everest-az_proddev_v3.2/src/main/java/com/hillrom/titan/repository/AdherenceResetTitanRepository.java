package com.hillrom.titan.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.AdherenceReset;
import com.hillrom.vest.domain.AdherenceResetTitan;

public interface AdherenceResetTitanRepository extends
		JpaRepository<AdherenceResetTitan, Long> {

	AdherenceResetTitan findOneById(Long Id);
	
	@Query("from AdherenceResetTitan reset where  reset.patientUser.id = ?1  and reset.createdBy = ?2 and reset.resetDate = ?3")
	Optional<AdherenceResetTitan> findOneByPatientUserIdAndCreatedByAndResetDate(Long patientUserId, Long createdByUserId, DateTime resetDate);


	@Query("from AdherenceResetTitan reset where  reset.patient.id = ?1 ORDER BY reset.resetDate desc")
	List<AdherenceResetTitan> findAllByPatientId(String patientId);

	@Query("from AdherenceResetTitan reset where  reset.patientUser.id = ?1 ORDER BY reset.resetDate desc")
	List<AdherenceResetTitan> findAllByPatientUserId(Long userId);
	
	//hill-1956
	 @Query("from AdherenceResetTitan reset where  reset.patientUser.id = ?1  and reset.resetStartDate = ?2")
	 List<AdherenceResetTitan> findOneByPatientUserIdAndResetStartDate(Long patientUserId, LocalDate resetStartDate);
	
	 @Query("from AdherenceResetTitan reset where  reset.patientUser.id = ?1  and reset.resetStartDate between  ?2 and  ?3 ORDER BY reset.resetStartDate asc")
	 List<AdherenceResetTitan> findOneByPatientUserIdAndResetStartDates(Long patientUserId, LocalDate firstStartDate, LocalDate lastStartDate);
	//hill-1956
	
	@Query("from AdherenceResetTitan reset where reset.patientUser.id = ?1 ORDER BY reset.resetStartDate desc")
	List<AdherenceResetTitan> findOneByPatientUserIdLatestResetStartDate(Long patientUserId);
}