package com.hillrom.titan.web.rest.dto;
import javax.validation.constraints.Size;
import io.swagger.annotations.ApiModelProperty;

public class ProtocolEntryTitanDTO {
	
	@Size(max = 50)
	@ApiModelProperty(value="treatment Label",required=true)
	private String treatmentLabel;
	
	@Size(max = 50)
	@ApiModelProperty(value="min Minutes Per Treatment",required=true)
	private int minMinutesPerTreatment;
	
	@Size(max = 50)
	@ApiModelProperty(value="max Minutes Per Treatment",required=true)
	private int maxMinutesPerTreatment;
	
	@Size(max = 50)
	@ApiModelProperty(value="min Frequency",required=true)
	private Integer minFrequency;
	
	@Size(max = 50)
	@ApiModelProperty(value="max Frequency",required=true)
	private Integer maxFrequency;
	
	@Size(max = 50)
	@ApiModelProperty(value="min Intensity",required=true)
	private Integer minIntensity;
	
	@Size(max = 50)
	@ApiModelProperty(value="max Intensity",required=true)
	private Integer maxIntensity;

	/*@ApiModelProperty(value="hmr",required=true)
	private String hmr;

	public String getHmr() {
		return hmr;
	}

	public void setHmr(String hmr) {
		this.hmr = hmr;
	}*/

	public ProtocolEntryTitanDTO() {
		super();
	}

	public ProtocolEntryTitanDTO(String treatmentLabel, int minMinutesPerTreatment,
			int maxMinutesPerTreatment, Integer minFrequency,
			Integer maxFrequency, Integer minIntensity, Integer maxIntensity) {
		super();
		this.treatmentLabel = treatmentLabel;
		this.minMinutesPerTreatment = minMinutesPerTreatment;
		this.maxMinutesPerTreatment = maxMinutesPerTreatment;
		this.minFrequency = minFrequency;
		this.maxFrequency = maxFrequency;
		this.minIntensity = minIntensity;
		this.maxIntensity = maxIntensity;
	}

	//public ProtocolEntryTitanDTO(int minMinutesPerTreatment,Integer minFrequency,Integer minIntensity, String hmr) 
	public ProtocolEntryTitanDTO(int minMinutesPerTreatment,Integer minFrequency,Integer minIntensity) {
		super();
		this.minMinutesPerTreatment = minMinutesPerTreatment;
		this.minFrequency = minFrequency;
		this.minIntensity = minIntensity;
		//this.hmr = hmr;
	}

	public String getTreatmentLabel() {
		return treatmentLabel;
	}

	public void setTreatmentLabel(String treatmentLabel) {
		this.treatmentLabel = treatmentLabel;
	}

	public int getMinMinutesPerTreatment() {
		return minMinutesPerTreatment;
	}

	public void setMinMinutesPerTreatment(int minMinutesPerTreatment) {
		this.minMinutesPerTreatment = minMinutesPerTreatment;
	}

	public int getMaxMinutesPerTreatment() {
		return maxMinutesPerTreatment;
	}

	public void setMaxMinutesPerTreatment(int maxMinutesPerTreatment) {
		this.maxMinutesPerTreatment = maxMinutesPerTreatment;
	}

	public Integer getMinFrequency() {
		return minFrequency;
	}

	public void setMinFrequency(Integer minFrequency) {
		this.minFrequency = minFrequency;
	}

	public Integer getMaxFrequency() {
		return maxFrequency;
	}

	public void setMaxFrequency(Integer maxFrequency) {
		this.maxFrequency = maxFrequency;
	}

	public Integer getMinIntensity() {
		return minIntensity;
	}

	public void setMinIntensity(Integer minIntensity) {
		this.minIntensity = minIntensity;
	}

	public Integer getMaxIntensity() {
		return maxIntensity;
	}

	public void setMaxIntensity(Integer maxIntensity) {
		this.maxIntensity = maxIntensity;
	}

	@Override
	public String toString() {
		return "ProtocolEntryTitanDTO [treatmentLabel=" + treatmentLabel + ", minMinutesPerTreatment="
				+ minMinutesPerTreatment + ", maxMinutesPerTreatment=" + maxMinutesPerTreatment + ", minFrequency="
				+ minFrequency + ", maxFrequency=" + maxFrequency + ", minIntensity=" + minIntensity + ", maxIntensity="
				+ maxIntensity + "]";
	}

}
