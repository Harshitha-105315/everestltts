package com.hillrom.titan.service;

import static com.hillrom.vest.config.AdherenceScoreConstants.FIRST_TRANSMISSION_FIRTS_TYPE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.hillrom.titan.repository.PatientNoEventsTitanRepository;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.service.util.GraphUtils;
import com.hillrom.vest.util.ExceptionConstants;

@Service
@Transactional
public class PatientNoEventTitanService {
	
	private final Logger log = LoggerFactory.getLogger(PatientNoEventTitanService.class);

	@Inject
	public PatientNoEventsTitanRepository noEventsTitanRepository;
	
	@Inject
	PatientDevicesAssocRepository patientDevicesAssocRepository;
	
	public PatientNoEventTitan createIfNotExists(PatientNoEventTitan newPatientWithNoEvent){
		PatientNoEventTitan patientNoEvent = noEventsTitanRepository.findByPatientUserId(newPatientWithNoEvent.getPatientUser().getId());
		if(Objects.nonNull(patientNoEvent)){
			return patientNoEvent;
		}else{
			patientNoEvent = noEventsTitanRepository.save(newPatientWithNoEvent);
		}
		return patientNoEvent;
	}
	
	public PatientNoEventTitan updatePatientFirstTransmittedDate(Long patientUserId,LocalDate transmittedDate,String patientId){
		PatientNoEventTitan patientNoEvent = noEventsTitanRepository.findByPatientUserId(patientUserId);
		/*if(Objects.nonNull(patientNoEvent)){
			patientNoEvent.setFirstTransmissionDate(transmittedDate);
			noEventsMonarchRepository.save(patientNoEvent);
		}*/
		
		LocalDate trainingDate = getTrainingDateForAdherence(patientId);
		if(Objects.nonNull(patientNoEvent)){
			if(Objects.nonNull(trainingDate) && trainingDate.isAfter (transmittedDate)){
				patientNoEvent.setFirstTransmissionDate(trainingDate);
				if ((Objects.nonNull(trainingDate)) && (Objects.isNull(patientNoEvent.getFirstTransmissionDateBeforeUpdate()))) {
					patientNoEvent.setFirstTransmissionDateBeforeUpdate(transmittedDate);
					patientNoEvent.setDateFirstTransmissionDateUpdated(new LocalDate());
				}else if((Objects.nonNull(trainingDate)) && (patientNoEvent.getFirstTransmissionDateBeforeUpdate()).isAfter(transmittedDate)){
					patientNoEvent.setFirstTransmissionDateBeforeUpdate(transmittedDate);
					//patientNoEvent.setDateFirstTransmissionDateUpdated(new LocalDate());
				}
			}else if(Objects.nonNull(trainingDate) && trainingDate.equals(transmittedDate)){ 
				//patientNoEvent.setFirstTransmissionDate(transmittedDate);
				if(Objects.isNull(patientNoEvent.getFirstTransmissionDateBeforeUpdate())){
				patientNoEvent.setFirstTransmissionDateBeforeUpdate(transmittedDate);
				}
			}else if(Objects.nonNull(trainingDate) && trainingDate.isBefore(transmittedDate)){
				patientNoEvent.setFirstTransmissionDate(transmittedDate);
				patientNoEvent.setFirstTransDateType(FIRST_TRANSMISSION_FIRTS_TYPE);
				patientNoEvent.setDateFirstTransmissionDateUpdated(new LocalDate());
			}else{
				patientNoEvent.setFirstTransmissionDate(transmittedDate);
				patientNoEvent.setFirstTransDateType(FIRST_TRANSMISSION_FIRTS_TYPE);
			}
			
			noEventsTitanRepository.save(patientNoEvent);
		}
		
		return patientNoEvent;
	}
	
	private LocalDate getTrainingDateForAdherence(String id) {
		LocalDate trainingDate = patientDevicesAssocRepository.findOneByPatientIdAndDeviceType(id,"TITAN").getTrainingDate();
		return trainingDate;
	}

	public PatientNoEventTitan findByPatientUserId(Long patientUserId){
		return noEventsTitanRepository.findByPatientUserId(patientUserId);
	}
	public LocalDate getPatientFirstTransmittedDate(Long patientUserId) throws HillromException{
		PatientNoEventTitan patientNoEvent = noEventsTitanRepository
				.findByPatientUserId(patientUserId);
		if (Objects.nonNull(patientNoEvent)) {
			return GraphUtils.getFirstTransmissionDateTitanByType(patientNoEvent);
		} else
			return null;
	}
	public List<PatientNoEventTitan> findAll(){
		return noEventsTitanRepository.findAll();
	}
	
	public Map<Long,PatientNoEventTitan> findAllGroupByPatientUserId(){
		List<PatientNoEventTitan> patientNoEvents = findAll();
		Map<Long,PatientNoEventTitan> userIdNoEventsMap = new HashMap<>();
		for(PatientNoEventTitan patientNoEvent : patientNoEvents){
			userIdNoEventsMap.put(patientNoEvent.getPatientUser().getId(), patientNoEvent);
		}
		return userIdNoEventsMap;
	}
	
}
