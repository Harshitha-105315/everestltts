package com.hillrom.titan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.PatientProtocolDataTitan;

public interface PatientProtocolTitanRepository extends
		JpaRepository<PatientProtocolDataTitan, String> {

	
	@Query("from PatientProtocolDataTitan ppd where ppd.protocolKey = ?1")
	List<PatientProtocolDataTitan> findByProtocolKey(String protocolKey);
	
	/**
	 * This returns hillromId of the protocol from stored procedure.
	 * @return String hillromId
	 */
	@Procedure(outputParameterName="hillrom_id",procedureName="get_next_protocol_hillromid") // SP to be created
	String id();
		
	@Query("from PatientProtocolDataTitan ppd where ppd.patient.id = ?1 and ppd.deleted = false group by ppd.protocolKey")
	List<PatientProtocolDataTitan> findByPatientIdAndActiveStatus(String patientId);
	List<PatientProtocolDataTitan> findByPatientIdOrderByCreatedDateAsc(String patientId);
	List<PatientProtocolDataTitan> findByPatientUserIdAndDeleted(Long patientId,boolean deleted);
	List<PatientProtocolDataTitan> findByDeletedAndPatientUserIdIn(boolean deleted,List<Long> patientUserId);
	}
