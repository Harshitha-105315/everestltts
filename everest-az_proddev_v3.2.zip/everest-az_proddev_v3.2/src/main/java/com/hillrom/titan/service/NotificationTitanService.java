package com.hillrom.titan.service;

import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;

import com.hillrom.titan.repository.NotificationTitanRepository;
import com.hillrom.vest.domain.NotificationTitan;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.User;

@Service
@Transactional
public class NotificationTitanService {
	
	@Inject
	private NotificationTitanRepository notificationTitanRepository;

	/**
	 * Creates or Updates Notification with provided details
	 * @param patientUser
	 * @param patient
	 * @param patientUserId
	 * @param currentTherapyDate
	 * @param notificationType
	 * @param isAcknowledged
	 * @return
	 */
	public NotificationTitan createOrUpdateNotification(User patientUser,
			PatientInfo patient, Long patientUserId,
			LocalDate currentTherapyDate, String notificationType,boolean isAcknowledged,String complianceType) {
		
		List<NotificationTitan> existingNotificationofTheDayList = notificationTitanRepository.findAllByPatientUserIdAndDate(patientUserId, currentTherapyDate);
		NotificationTitan existingNotificationofTheDay = null;
		// Update missed therapy notification if exists for the day
		if(!existingNotificationofTheDayList.isEmpty()){
			int counter = 0;
			for(NotificationTitan existingNotificationofTheDayUpdate : existingNotificationofTheDayList){
				if(existingNotificationofTheDayList.size() > 1 && counter == 0){
					notificationTitanRepository.delete(existingNotificationofTheDayUpdate);
				}else{
					existingNotificationofTheDayUpdate.setNotificationType(notificationType);
					existingNotificationofTheDayUpdate.setComplianceType(complianceType);
					existingNotificationofTheDayUpdate.setAcknowledged(isAcknowledged);
					notificationTitanRepository.save(existingNotificationofTheDayUpdate);
				}
				counter++;
			}
		}else{
			existingNotificationofTheDay = new NotificationTitan(notificationType,currentTherapyDate,patientUser,patient,false,complianceType);
			notificationTitanRepository.save(existingNotificationofTheDay);
		}
		return existingNotificationofTheDay;
	}
}
