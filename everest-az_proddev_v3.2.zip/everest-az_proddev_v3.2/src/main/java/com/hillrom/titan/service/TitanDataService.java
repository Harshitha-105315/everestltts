package com.hillrom.titan.service;

import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import com.hillrom.mobile.service.PushNotificationService;
import com.hillrom.titan.dto.CaughPauseSetting;
import com.hillrom.titan.dto.RemoteTherapyUpdateDataDTO;
import com.hillrom.titan.dto.TherapyParamDTO;
import com.hillrom.titan.dto.TherapySettingDTO;
import com.hillrom.titan.dto.TherapyTypeDTO;
import com.hillrom.titan.repository.CorruptedTitanDeviceDataEventsRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRawLogRepository;
import com.hillrom.titan.repository.RemoteTherapyUpdateHistoryTitanRepository;
import com.hillrom.titan.repository.RemoteTherapyUpdateTitanRepository;
import com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants;
import com.hillrom.vest.domain.CorruptedTitanDeviceDataEvents;
import com.hillrom.vest.domain.PatientVestDeviceRawLogTitan;
import com.hillrom.vest.domain.RemoteTherapyUpdateHistoryTitan;
import com.hillrom.vest.domain.RemoteTherapyUpdateTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.util.ParserUtil;
import com.hillrom.vest.service.util.RandomUtil;
import com.hillrom.vest.util.ExceptionConstants;

import net.minidev.json.JSONObject;

@Service
public class TitanDataService {
	
	private final Logger log = LoggerFactory.getLogger(TitanDataService.class);
	
	@Inject
	private ApplicationContext applicationContextTitan;
	
	@Inject
	private JobLauncher jobLauncherTitan;
	
	@Inject
	private Environment env;
	
	@Inject
	private MailService mailService;
	
	@Inject
	private PatientTitanDeviceRawLogRepository patientTitanDeviceRawLogRepository;
	
	@Inject
	private CorruptedTitanDeviceDataEventsRepository corruptedTitanDeviceDataEventsRepository;
	
	@Inject
	RemoteTherapyUpdateTitanRepository remoteTherapyUpdateTitanRepository;
	
	@Inject
	private PushNotificationService pushNotificationService;
	
	@Inject
	RemoteTherapyUpdateHistoryTitanRepository remoteTherapyUpdateHistoryTitanRepository;
	
	
	
	public String decodeData(final String rawMessage){
		byte[] decoded = java.util.Base64.getDecoder().decode(rawMessage);

		String decoded_string = new String(decoded);
		log.info("Decoded value is " + decoded_string);
		return decoded_string;
	}
	
	public ExitStatus saveData(final String rawData) throws Exception {
		log.debug("Titan saveData has been called , rawData length",rawData.length());

		validateRequest(rawData);

		Job addNewDataIngestionJobTitan = applicationContextTitan.getBean("processTitanTherapySessionsAndCompliance", Job.class);
		JobParameters jobParametersTitan = new JobParametersBuilder()
				.addLong("TIME", System.currentTimeMillis())
				.addString("rawData", rawData)
				.toJobParameters();
		JobExecution jobExecution = jobLauncherTitan.run(addNewDataIngestionJobTitan, jobParametersTitan);
		log.debug("Job triggered @ Time ",System.currentTimeMillis());
		ExitStatus exitStatus = jobExecution.getExitStatus();
		String shouldTriggerMail = env.getProperty("sendmail.for.valid.data.ingestion");
		// Sending mail Notification on Job Status (ON Success), this code should be removed later
		log.debug("Job triggered @ Time ",exitStatus);
		if(ExitStatus.COMPLETED.equals(exitStatus) && shouldTriggerMail.equalsIgnoreCase("true")){
			mailService.sendStatusOnDataIngestionRequest(rawData, exitStatus.getExitCode(), !ExitStatus.COMPLETED.equals(exitStatus), "");
		}
		return exitStatus;
	}

	private void validateRequest(final String rawData) throws HillromException {
		log.debug("Encoded Base64 Received Data for ingestion : ",rawData);
		String decodedData = decodeData(rawData);
		log.info("Decoded value is " + decodedData);
				
		JSONObject titanJsonData = ParserUtil.getChargerJsonDataFromRawMessage(decodedData);
		String reqParams[] = new String[]{DEVICE_MODEL,DEVICE_SN,DEVICE_WIFI,DEVICE_BT,DEVICE_VER,FRAG_TOTAL,FRAG_CURRENT,DEVICE_DATA,CRC};
		if(Objects.isNull(titanJsonData) || titanJsonData.keySet().isEmpty()){
			throw new HillromException("Missing Params : "+String.join(",",reqParams));
			//throw new HillromException("Missing Params");
		}else if(Objects.nonNull(titanJsonData)){
			List<String> missingParams = RandomUtil.getDifference(Arrays.asList(reqParams), new ArrayList<String>(titanJsonData.keySet()));
			
			// To check either WIFI  / BT is available
			if(!missingParams.contains(DEVICE_WIFI) && missingParams.contains(DEVICE_BT)){
				missingParams.remove(DEVICE_BT);
			}else if(missingParams.contains(DEVICE_WIFI) && !missingParams.contains(DEVICE_BT)){
				missingParams.remove(DEVICE_WIFI);
			}
			
			if(missingParams.size() > 0) {
				if(missingParams.contains(DEVICE_MODEL) || missingParams.contains(DEVICE_SN)  || missingParams.contains(DEVICE_VER) || missingParams.contains(DEVICE_DATA) || missingParams.contains(CRC) ||
						missingParams.contains(FRAG_TOTAL) || missingParams.contains(FRAG_CURRENT)
						) {
					throw new HillromException("Missing Params : "+String.join(",",missingParams));
					//throw new HillromException("Missing Params");
				}
			}
		}
		if(!calculateCRC(rawData)){
			throw new HillromException("CRC Validation Failed");
		}
	}
	
	
	private boolean calculateCRC(String base64String) {

		log.error("Inside  calculateCRC : " ,base64String);
	    int nCheckSum = 0;

	    byte[] decoded = java.util.Base64.getDecoder().decode(base64String);
	    
	    int nDecodeCount = 0;
	    for ( ; nDecodeCount < (decoded.length-2); nDecodeCount++ )
	    {
	      int nValue = (decoded[nDecodeCount] & 0xFF);
	      nCheckSum += nValue;
	    }
	    
	    
	    log.debug("Inverted Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);
	    
	    int nMSB = decoded[nDecodeCount+1] & 0xFF;
	    int nLSB = decoded[nDecodeCount] & 0xFF;
	    
	    log.debug("MSB = %d [0x%x]\r\n" ,nMSB, nMSB);
	    log.debug("LSB = %d [0x%x]\r\n" ,nLSB, nLSB);
	    log.error("Total Value = " + nCheckSum);
	    nCheckSum = ((~nCheckSum)& 0xFFFF) + 1;
	    log.debug("Checksum Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);
	    
	    String msb_digit = Integer.toHexString(nMSB);
	    String lsb_digit = Integer.toHexString(nLSB);
	    String checksum_num =  Integer.toHexString(nCheckSum);
	    
	    if(msb_digit.length()<2)
	    	msb_digit = "0"+msb_digit;
	    if(lsb_digit.length()<2)
	    	lsb_digit = "0"+lsb_digit;
	    
	    log.debug("MSB : " + msb_digit + " " +  "LSB : " + lsb_digit);
	    log.debug("Checksum : " + checksum_num);
	    
	    if((msb_digit+lsb_digit).equalsIgnoreCase(checksum_num)){
	    	return true;
	    }else{
	    	log.error("CRC VALIDATION FAILED :"); 
	    	return false;
	    }
	
	}

	public String getDeviceData(String encoded_string) throws HillromException{
		byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
        
        log.debug("Input Byte Array :"+sout);

        String deviceData = "";
        int start = returnMatch(b,DEVICE_DATA_FIELD_NAME);
        int end = returnMatch(b,CRC_FIELD_NAME)-CRC_FIELD_NAME.length;
        log.debug("start end : "+ start + " : " + end );
        
        byte[] deviceDataArray = new byte[end];
        int j=0;
        for(int i=start;i<end;i++) {
        	deviceDataArray[j++] = b[i];
        	int val = b[i] & 0xFF;
        	deviceData = deviceData + String.valueOf(Character.toChars(val));
        }
        log.debug("deviceData : "+ sout );
        
        if(deviceData.equalsIgnoreCase("PING_PONG_PING")){
        	return "PING_PONG_PING";
        }
    	log.debug("deviceData is NOT PING_PONG_PING" );
        
        
        byte[] session_index  = Arrays.copyOfRange(deviceDataArray, SESSION_INDEX_LOC, SESSION_INDEX_LOC + SESSION_INDEX_LEN);
        sout = "";
        
        for(int k=0;k<session_index.length;k++){
        	sout = sout + (session_index[k]  & 0xFF) + " ";
        }
        log.debug("session_index : "+ sout );
        
        log.debug("Combined session_index : "+ intergerCombinedFromHex(session_index));
              
        byte[] start_time  = Arrays.copyOfRange(deviceDataArray, START_TIME_LOC, START_TIME_LOC + START_TIME_LEN);
        sout = "";
        for(int k=0;k<start_time.length;k++){
        	sout = sout + (start_time[k]  & 0xFF) + " ";
        }
        log.debug("start_time : "+ sout );
        
        byte[] end_time  = Arrays.copyOfRange(deviceDataArray, END_TIME_LOC, END_TIME_LOC + END_TIME_LEN);        
        sout = "";
        for(int k=0;k<end_time.length;k++){
        	sout = sout + (end_time[k]  & 0xFF) + " ";
        }
        log.debug("end_time : "+ sout );
        
        /*byte[] start_battery_level  = Arrays.copyOfRange(deviceDataArray, START_BATTERY_LEVEL_LOC, START_BATTERY_LEVEL_LOC + START_BATTERY_LEVEL_LEN);
        sout = "";
        for(int k=0;k<start_battery_level.length;k++){
        	sout = sout + (start_battery_level[k]  & 0xFF) + " ";
        }
        log.debug("start_battery_level : "+ sout );
        
        byte[] end_battery_level  = Arrays.copyOfRange(deviceDataArray, END_BATTERY_LEVEL_LOC, END_BATTERY_LEVEL_LOC + END_BATTERY_LEVEL_LEN);
        sout = "";
        for(int k=0;k<end_battery_level.length;k++){
        	sout = sout + (end_battery_level[k]  & 0xFF) + " ";
        }
        log.debug("end_battery_level : "+ sout );*/
        
        byte[] number_of_events  = Arrays.copyOfRange(deviceDataArray, NUMBER_OF_EVENTS_LOC, NUMBER_OF_EVENTS_LOC + NUMBER_OF_EVENTS_LEN);
        sout = "";
        for(int k=0;k<number_of_events.length;k++){
        	sout = sout + (number_of_events[k]  & 0xFF) + " ";
        }
        log.debug("number_of_events : "+ sout );
        
        /*byte[] number_of_pods  = Arrays.copyOfRange(deviceDataArray, NUMBER_OF_PODS_LOC, NUMBER_OF_PODS_LOC + NUMBER_OF_PODS_LEN);
        sout = "";
        for(int k=0;k<number_of_pods.length;k++){
        	sout = sout + (number_of_pods[k]  & 0xFF) + " ";
        }
        log.debug("number_of_pods : "+ sout );*/
        
        byte[] hmr_seconds  = Arrays.copyOfRange(deviceDataArray, HMR_SECONDS_LOC, HMR_SECONDS_LOC + HMR_SECONDS_LEN);
        sout = "";
        for(int k=0;k<hmr_seconds.length;k++){
        	sout = sout + (hmr_seconds[k]  & 0xFF) + " ";
        }
        log.debug("hmr_seconds : "+ sout );
        log.debug("Combined hmr_seconds : "+ intergerCombinedFromHex(hmr_seconds));
        
        //log.debug("Value of deviceDataArray.length : "+ j );
        for(int i=EVENT_LOG_START_POS+1;i<j;i=i+EVENT_LOG_LEN){
        	
        	//log.debug("Value of i : "+ i );
	        byte[] event_timestamp  = Arrays.copyOfRange(deviceDataArray, i + EVENT_TIMESTAMP_LOC-1, (i+EVENT_TIMESTAMP_LOC-1) + EVENT_TIMESTAMP_LEN);
	        sout = "";
	        for(int k=0;k<event_timestamp.length;k++){
	        	sout = sout + (event_timestamp[k]  & 0xFF) + " ";
	        }
	        log.debug("event_timestamp : "+ sout );
	        
	        byte[] event_code  = Arrays.copyOfRange(deviceDataArray, i+EVENT_CODE_LOC-1, (i+EVENT_CODE_LOC-1) + EVENT_CODE_LEN);        
	        sout = "";
	        for(int k=0;k<event_code.length;k++){
	        	sout = sout + (event_code[k]  & 0xFF) + " ";
	        }
	        log.debug("event_code : "+ sout );
	        
	        byte[] frequency  = Arrays.copyOfRange(deviceDataArray, i+FREQUENCY_LOC-1, (i+FREQUENCY_LOC-1) + FREQUENCY_LEN);
	        sout = "";
	        for(int k=0;k<frequency.length;k++){
	        	sout = sout + (frequency[k]  & 0xFF) + " ";
	        }
	        log.debug("frequency : "+ sout );

	        
	        byte[] intensity  = Arrays.copyOfRange(deviceDataArray, i+INTENSITY_LOC-1, (i+INTENSITY_LOC-1) + INTENSITY_LEN);
	        sout = "";
	        for(int k=0;k<intensity.length;k++){
	        	sout = sout + (intensity[k]  & 0xFF) + " ";
	        }
	        log.debug("intensity : "+ sout );

	        
	        byte[] duration  = Arrays.copyOfRange(deviceDataArray, i+DURATION_LOC-1, (i+DURATION_LOC-1) + DURATION_LEN);
	        sout = "";
	        for(int k=0;k<duration.length;k++){
	        	sout = sout + (duration[k]  & 0xFF) + " ";
	        }
	        log.debug("duration : "+ sout );
        }
        
        return "NOT_PING_PONG_PING";

	}

	public String getDevSN(String encoded_string,String decoded_string) throws HillromException{
		String devSn = decoded_string.indexOf(DEVICE_SN) < 0 ? null : decoded_string.substring(decoded_string.indexOf(DEVICE_SN)+DEVICE_SN.length()+1, getNextIndex(decoded_string,DEVICE_SN));
		return devSn;
	}
	
	public int getFragTotal(String encoded_string) throws HillromException{
        byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
        
        //log.debug("Input Byte Array in getFragTotal :"+sout);
        int start = returnMatch(b,FRAG_TOTAL_FIELD_NAME);
        log.debug("start : "+ start  );
        
        int fragTotal = b[start] & 0xFF;
        
        log.debug("Total number of fragments : "+ fragTotal );
        return fragTotal;
        
	}
	
	public int getFragCurrent(String encoded_string) throws HillromException{
        byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
        
        //log.debug("Input Byte Array in getFragCurrent :"+sout);
        int start = returnMatch(b,FRAG_CURRENT_FIELD_NAME);
        log.debug("start : "+ start  );
        
        int fragCurrent = b[start] & 0xFF;
        
        log.debug("Current fragment number : "+ fragCurrent );
        return fragCurrent;
        
	}
    
    private int returnMatch(byte[] inputArray,byte[] matchArray){
        for(int i=0;i<inputArray.length;i++){
        	int val = inputArray[i] & 0xFF;
        	boolean found = false;
        	
        	if((val == 38) && !found){
        		int j=i;int k=0;
        		while((inputArray[j++]==matchArray[k++]) && (k<matchArray.length)){
        			
        		}
        		if(k==matchArray.length){
        			found = true;
        			return j;
        		}
        	}
        }
        return -1;
    }

	public int intergerCombinedFromHex(byte[] input)
	{
	    int hexTotal = 0;
	    for (int t = 0; t < input.length; t++)
	    {
	    	hexTotal = hexTotal + Integer.parseInt(Integer.toHexString(input[t]& 0xFF), 16);
	    }
	    log.debug("hexTotal : " + hexTotal);
	    return hexTotal;
	}

	public static Integer getNextIndex(String rawMessage,String namePair){
		switch(namePair){
		case DEVICE_MODEL:
			return rawMessage.indexOf(DEVICE_SN) < 0 ? getNextIndex(rawMessage, DEVICE_SN) :  rawMessage.indexOf(DEVICE_SN)-1;			
		case DEVICE_SN:
			return rawMessage.indexOf(DEVICE_WIFI) < 0 ? getNextIndex(rawMessage, DEVICE_WIFI) :  rawMessage.indexOf(DEVICE_WIFI)-1;
		case DEVICE_WIFI:
			return rawMessage.indexOf(DEVICE_LTE) < 0 ? getNextIndex(rawMessage, DEVICE_LTE) :  rawMessage.indexOf(DEVICE_LTE)-1;
		case DEVICE_LTE:
			return rawMessage.indexOf(DEVICE_BT) < 0 ? getNextIndex(rawMessage, DEVICE_BT) :  rawMessage.indexOf(DEVICE_BT)-1;
		case DEVICE_BT:
			return rawMessage.indexOf(DEVICE_VER) < 0 ? getNextIndex(rawMessage, DEVICE_VER) :  rawMessage.indexOf(DEVICE_VER)-1;	
		case DEVICE_VER:
			return rawMessage.indexOf(FRAG_TOTAL) < 0 ? getNextIndex(rawMessage, FRAG_TOTAL) :  rawMessage.indexOf(FRAG_TOTAL)-1;
		case FRAG_TOTAL:
			return rawMessage.indexOf(FRAG_CURRENT) < 0 ? getNextIndex(rawMessage, FRAG_CURRENT) :  rawMessage.indexOf(FRAG_CURRENT)-1;
		case FRAG_CURRENT:
			return rawMessage.indexOf(DEVICE_DATA) < 0 ? getNextIndex(rawMessage, DEVICE_DATA) :  rawMessage.indexOf(DEVICE_DATA)-1;
		case DEVICE_DATA:
			return rawMessage.indexOf(CRC) < 0 ? rawMessage.length() :  rawMessage.indexOf(CRC)-1;
		default:
			return -1;
		}		
	}

	//public String getUserInfo(String deviceSerialNumber, String requestId, String cmd, String cmdParam, String crc) {
	public String getUserInfo(Map paraMap) {	
		String userInfoResponse = "[BEGIN]__REQID=3500__RESULT=OK__RECID=30001__INFO={__USERID=50012}__CRC=32311[END]";
		return userInfoResponse;
	}

	//public String updateTherapySettings(String deviceSerialNumber, String requestId, String cmd, String cmdParam, String crc) {
	public String updateTherapySettings(Map paraMap) {
		String therapySettingResponse = "[BEGIN]__REQID=2002__RESULT=OK__RECID=10001__CRC=1223[END]";
		return therapySettingResponse;
	}
	
	public int createCrc(String rawMwessage) {
		int nCheckSum = 0;
		int nDecodeCount = 0;
		byte[] decoded = rawMwessage.getBytes();
		for (; nDecodeCount < (decoded.length); nDecodeCount++) {
			int nValue = (decoded[nDecodeCount] & 0xFF);
			nCheckSum += nValue;
		}
		nCheckSum = ((~nCheckSum) & 0xFFFF) + 1;
		log.debug("createCrc checksum ::"+nCheckSum);
		return nCheckSum;
	}

	public void writeToExternalFile(StringBuilder stringToWrite, File file) throws IOException {
		FileWriter writer = new FileWriter(file);
		writer.write(stringToWrite.toString());
		writer.close();
	}

	public void clearOldFile(String path) throws IOException {
		Path fileToDeletePath = Paths.get(path);
		Files.delete(fileToDeletePath);
	}
	

	public String readTitanSettings (String deviceSerialNumber) {
		InputStream is = null;
		StringBuilder content = new StringBuilder();
		String fileName = "titanTestBed.txt";
		
		is = getClass().getClassLoader().getResourceAsStream("public/mobile-images/" + deviceSerialNumber + ".txt");
		if (Objects.isNull(is))
			is = getClass().getClassLoader().getResourceAsStream("public/mobile-images/" + fileName);
		
		BufferedReader r = new BufferedReader(new InputStreamReader(is));
		String line = "";
		try {
			while ((line = r.readLine()) != null) {
				content.append(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return content.toString();
	}
	
	public String formatResponseString(TherapySettingDTO therapySetting){
		StringBuilder deviceStting = new StringBuilder();
		
		deviceStting.append("__REQID=").append(therapySetting.getRequestId())
		.append("__RESULT=").append(therapySetting.getResult())
		.append("__RECID=").append(therapySetting.getRecordId());

		if(!therapySetting.getTheraptData().isEmpty()) {
			for(Map.Entry<String,TherapyTypeDTO> entry : therapySetting.getTheraptData().entrySet()) {
				deviceStting.append("__"+entry.getKey()+"={")
				.append("THERAPY_NAME=").append(entry.getValue().getTherapyName())
				.append("THERAPY_PARAM_COUNT=").append(entry.getValue().getThearpyParamCount())
				.append("THERAPY_PARAM=").append(StringUtils.chop(entry.getValue().getTherapyParam()))
				.append("THERAPY_COUGHPAUSE=").append(entry.getValue().getTherapyCoughPause())
				.append("}");
			}
		}
		deviceStting.append("__CRC=");
		int crcCalculated = createCrc(deviceStting.toString());
		deviceStting.append(crcCalculated);

		return "[BEGIN]" + deviceStting.toString() + "[END]";
	}
	public String formatStatusResponseString(TherapySettingDTO therapySetting){
		StringBuilder deviceStting = new StringBuilder();
		
		deviceStting.append("\n").append("__REQID=").append(therapySetting.getRequestId()).append("\n")
		.append("__RESULT=").append(therapySetting.getResult()).append("\n")
		.append("__RECID=").append(therapySetting.getRecordId());
		deviceStting.append("\n").append("__CRC=");
		int crcCalculated = createCrc(deviceStting.toString());
		deviceStting.append(crcCalculated).append("\n");

		return "[BEGIN]"  +deviceStting.toString() + "[END]";
	}

	public String clearTherapySettingUpdateRTP(TherapySettingDTO setting) {
		
		StringBuilder deviceStting = new StringBuilder();
		deviceStting.append("__REQID=").append(setting.getRequestId())
					.append("__RESULT=").append(setting.getResult())
					.append("__RECID=").append(setting.getRecordId());
		
		deviceStting.append("__CRC=");

		int crcCalculated = createCrc(deviceStting.toString());
		deviceStting.append(crcCalculated);
		
		String filePath = "public/mobile-images/" + setting.getDevSN() + ".txt";
		File file = null;
		try {
			file = ResourceUtils.getFile("classpath:" + filePath);
			log.debug("file path = " + file.getPath());
	        if (!file.exists()) {
	        	log.debug("file path1 = " + file.getPath());
	        	file = ResourceUtils.getFile("classpath:" + "public/mobile-images/titanTestBed.txt");
	        }
	        
			StringBuilder contentToWrite = new StringBuilder("##" + setting.getRequestId())		// request ID
					.append("##" + setting.getResult())	// result
					.append("##" + setting.getRecordId()) // record DI
					.append("##" )	// therapy setting
					.append("##" + crcCalculated); // CRC
			clearOldFile(file.getPath());
			writeToExternalFile(contentToWrite, new File(file.getPath()));
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "[BEGIN]" + deviceStting.toString() + "[END]";
	}
	
	@Async
	@Transactional
	public void invalidDataRequestTitan(List<CorruptedTitanDeviceDataEvents> corruptedTitanDeviceDataEventsList) throws Exception{

		if(!corruptedTitanDeviceDataEventsList.isEmpty()) {
		for(CorruptedTitanDeviceDataEvents corruptedTitanDeviceDataEvent: corruptedTitanDeviceDataEventsList) {
			corruptedTitanDeviceDataEventsRepository.save(corruptedTitanDeviceDataEvent);
		}
		}
	}
	
	public Page<PatientVestDeviceRawLogTitan> findAll(Pageable pageable,DateTime from, DateTime to){
		
		Page<PatientVestDeviceRawLogTitan> titanDataList =  patientTitanDeviceRawLogRepository.findByCreatedTimeBetweenOrderByIdDesc(from, to,pageable);
			return titanDataList;
	}

	public Page<PatientVestDeviceRawLogTitan> findBySNo(Pageable pageable, String sno, DateTime from, DateTime to){
		Page<PatientVestDeviceRawLogTitan> titanDataList =  patientTitanDeviceRawLogRepository.findByDeviceSerialNumberAndCreatedTimeBetweenOrderByIdDesc( sno, from, to, pageable);
			return titanDataList;
	}
	
	@Transactional
	public RemoteTherapyUpdateDataDTO getTherapyHistoryById(String patientId) throws HillromException {

		RemoteTherapyUpdateDataDTO remoteTherapyUpdateDataDTO= new RemoteTherapyUpdateDataDTO();
		CaughPauseSetting caughPauseSetting = new CaughPauseSetting();
		List<TherapyParamDTO> lstTherapyParamDTO =new ArrayList<>();
		
		List<RemoteTherapyUpdateTitan> results =remoteTherapyUpdateTitanRepository.findByPatientId(patientId);
		log.debug("request rtu----------"+results);
		DateTimeFormatter fmt = DateTimeFormat.forPattern("MM-dd-yyyy HH:mm:ss");
		
		if(!Objects.isNull(results)) {
			for(RemoteTherapyUpdateTitan remoteTherapySettings : results) {
				remoteTherapyUpdateDataDTO.setTherapyName(remoteTherapySettings.getTherapyName());
				
				TherapyParamDTO therapyParamDTO = new TherapyParamDTO();
				therapyParamDTO.setDuration(remoteTherapySettings.getDuration());
				therapyParamDTO.setFrequency(remoteTherapySettings.getFrequency());
				therapyParamDTO.setIntensity(remoteTherapySettings.getIntensity());
				therapyParamDTO.setStep(remoteTherapySettings.getStep());
				lstTherapyParamDTO.add(therapyParamDTO);
				remoteTherapyUpdateDataDTO.setTherapyParam(lstTherapyParamDTO);
				
				caughPauseSetting.setCaughPauseEnable(remoteTherapySettings.getCaughAutoEnable());
				caughPauseSetting.setAfterEachStepStatus(remoteTherapySettings.getCaughIntervalMode());
				caughPauseSetting.setAutoRestartStatus(remoteTherapySettings.getCaughAutoEnable());
				caughPauseSetting.setCaughPauseInterval(remoteTherapySettings.getCaughPauseInterval());
				caughPauseSetting.setCaughPauseDuration(remoteTherapySettings.getCaughPauseDuration());
				remoteTherapyUpdateDataDTO.setCaughPauseSetting(caughPauseSetting);
				
				remoteTherapyUpdateDataDTO.setTherapyType(remoteTherapySettings.getTherapyType());
				remoteTherapyUpdateDataDTO.setDeviceType(remoteTherapySettings.getDeviceType());
				remoteTherapyUpdateDataDTO.setStatus(remoteTherapySettings.getStatus());
				remoteTherapyUpdateDataDTO.setPatientId(remoteTherapySettings.getPatientId());
				remoteTherapyUpdateDataDTO.setEmailId(remoteTherapySettings.getEmailId());				
				remoteTherapyUpdateDataDTO.setCreateDate(fmt.print(remoteTherapySettings.getCreateDate()));
				remoteTherapyUpdateDataDTO.setUpdateDate(fmt.print(remoteTherapySettings.getUpdateDate()));
				remoteTherapyUpdateDataDTO.setDeleted(remoteTherapySettings.isDeleted());
				
			}
		}else {
			throw new HillromException(ExceptionConstants.HR_959);
		}
		log.debug("response rtu----------"+results);
		return remoteTherapyUpdateDataDTO;

	}
	
	@Transactional
	public List<RemoteTherapyUpdateTitan> saveOrUpdateRTUDataByPatientId(RemoteTherapyUpdateDataDTO rtuDto) throws HillromException {
		log.debug("saveOrUpdateRTUDataByPatientId started");		
		List<RemoteTherapyUpdateTitan> rtuResult = null;
		List<RemoteTherapyUpdateTitan> lstRtuTitan =remoteTherapyUpdateTitanRepository.findByPatientId(rtuDto.getPatientId());
		log.debug("list from rt table by patientId = "+lstRtuTitan);		

		if(Objects.isNull(lstRtuTitan) || lstRtuTitan.isEmpty()) {
			rtuResult = saveRTUSetting(rtuDto);
		}else {
			//Update the record in REMOTE_THERAPY_UPDATE_TITAN table
			rtuResult = updateRTUSetting(rtuDto,lstRtuTitan);
			//Update the record in REMOTE_THERAPY_UPDATE_HISTORY_TITAN table
			updateRTUHistory(rtuDto);
		}
		
		if(rtuResult !=null && !rtuResult.isEmpty()) {
			// Push notifications for New Therapy Setting Avaliable
			pushNotificationService.pushNotificationForNewTherapySetting(rtuDto.getPatientId(),"New therapy settings available. Power on the Vest® APX System to update the therapy settings.", "PowerOnDevice");
		}
	
		log.debug("saveOrUpdateRTUDataByPatientId rtuResult ::"+rtuResult);
		return rtuResult;	
	}
	
	
	@Transactional
	public List<RemoteTherapyUpdateTitan> saveRTUSetting(RemoteTherapyUpdateDataDTO rtuDto) throws HillromException{
		log.debug("saveRTUSetting started");		

		List<RemoteTherapyUpdateTitan> lstRemoteTherapyUpdateTitan = new ArrayList<RemoteTherapyUpdateTitan>();
		RemoteTherapyUpdateTitan rtuTitanCreate =  null;
		
		List<TherapyParamDTO>  lstTherapyParamDTO = rtuDto.getTherapyParam();
		log.debug("lstTherapyParamDTO size ="+lstTherapyParamDTO.size());
		log.debug("lstTherapyParamDTO  ="+lstTherapyParamDTO);
		
		int lstTherapyParamDTOSize = lstTherapyParamDTO.size();
			
		if(lstTherapyParamDTOSize<8) {
			for(int i=lstTherapyParamDTOSize+1; i<=8; i++) {
				lstTherapyParamDTO.add(new TherapyParamDTO(0,0,0,i));
			}
		}
		log.debug("new lstTherapyParamDTO  ="+lstTherapyParamDTO);



		for(TherapyParamDTO therapyParamDTO : lstTherapyParamDTO) {
			rtuTitanCreate =  new RemoteTherapyUpdateTitan();

			rtuTitanCreate.setPatientId(rtuDto.getPatientId());

			rtuTitanCreate.setCreateDate(new DateTime());
			rtuTitanCreate.setUpdateDate(null);
			rtuTitanCreate.setTherapyName(rtuDto.getTherapyName());
			rtuTitanCreate.setTherapyType(rtuTitanCreate.getTherapyType());
			rtuTitanCreate.setDeviceType(rtuDto.getDeviceType());

			rtuTitanCreate.setFrequency(therapyParamDTO.getFrequency());
			rtuTitanCreate.setIntensity(therapyParamDTO.getIntensity());
			rtuTitanCreate.setDuration(therapyParamDTO.getDuration());
			rtuTitanCreate.setStep(therapyParamDTO.getStep());

			rtuTitanCreate.setCaughPauseDuration(rtuDto.getCaughPauseSetting().getCaughPauseDuration());
			rtuTitanCreate.setCaughPauseEnable(rtuDto.getCaughPauseSetting().getCaughPauseEnable());
			rtuTitanCreate.setCaughIntervalMode(rtuDto.getCaughPauseSetting().getAfterEachStepStatus());
			rtuTitanCreate.setCaughAutoEnable(rtuDto.getCaughPauseSetting().getAutoRestartStatus());
			rtuTitanCreate.setCaughPauseInterval(rtuDto.getCaughPauseSetting().getCaughPauseInterval());

			rtuTitanCreate.setStatus(rtuDto.getStatus());
			rtuTitanCreate.setEmailId(rtuDto.getEmailId());
			rtuTitanCreate.setDeleted(false);
			rtuTitanCreate.setAccepted(false);

			lstRemoteTherapyUpdateTitan.add(rtuTitanCreate);
		}
		log.debug("save list of RemoteTherapyUpdateTitan = "+lstRemoteTherapyUpdateTitan);
		
		lstRemoteTherapyUpdateTitan = remoteTherapyUpdateTitanRepository.save(lstRemoteTherapyUpdateTitan);
		createRtuHistory(rtuDto.getPatientId(),lstRemoteTherapyUpdateTitan);
		return lstRemoteTherapyUpdateTitan;
	}
	
	public List<RemoteTherapyUpdateTitan> updateRTUSetting(RemoteTherapyUpdateDataDTO rtuDto,List<RemoteTherapyUpdateTitan> lstRtuTitan){
		log.debug("updateRTUSetting started");		

		List<RemoteTherapyUpdateTitan> lstRemoteTherapyUpdateTitan = new ArrayList<RemoteTherapyUpdateTitan>();
		RemoteTherapyUpdateTitan rtuTitanUpdate =  null;
		
		List<TherapyParamDTO>  lstTherapyParamDTO = rtuDto.getTherapyParam();
		log.debug("lstTherapyParamDTO size ="+lstTherapyParamDTO.size());
		log.debug("lstTherapyParamDTO  ="+lstTherapyParamDTO);
		
		int lstTherapyParamDTOSize = lstTherapyParamDTO.size();
			
		if(lstTherapyParamDTOSize<8) {
			for(int i=lstTherapyParamDTOSize+1; i<=8; i++) {
				lstTherapyParamDTO.add(new TherapyParamDTO(0,0,0,i));
			}
		}
		log.debug("new lstTherapyParamDTO  ="+lstTherapyParamDTO);
		
		for(int i=0; i<lstTherapyParamDTO.size(); i++) {
			rtuTitanUpdate = new RemoteTherapyUpdateTitan();
			
			rtuTitanUpdate.setId(lstRtuTitan.get(i).getId());
			
			rtuTitanUpdate.setPatientId(rtuDto.getPatientId());

			rtuTitanUpdate.setCreateDate(lstRtuTitan.get(i).getCreateDate());
			rtuTitanUpdate.setUpdateDate(new DateTime());
			rtuTitanUpdate.setTherapyName(rtuDto.getTherapyName());
			rtuTitanUpdate.setTherapyType(rtuDto.getTherapyType());
			rtuTitanUpdate.setDeviceType(rtuDto.getDeviceType());
			
			rtuTitanUpdate.setFrequency(lstTherapyParamDTO.get(i).getFrequency());
			rtuTitanUpdate.setIntensity(lstTherapyParamDTO.get(i).getIntensity());
			rtuTitanUpdate.setDuration(lstTherapyParamDTO.get(i).getDuration());
			rtuTitanUpdate.setStep(lstTherapyParamDTO.get(i).getStep());
			
			rtuTitanUpdate.setCaughPauseDuration(rtuDto.getCaughPauseSetting().getCaughPauseDuration());
			rtuTitanUpdate.setCaughPauseEnable(rtuDto.getCaughPauseSetting().getCaughPauseEnable());
			rtuTitanUpdate.setCaughIntervalMode(rtuDto.getCaughPauseSetting().getAfterEachStepStatus());
			rtuTitanUpdate.setCaughAutoEnable(rtuDto.getCaughPauseSetting().getAutoRestartStatus());
			rtuTitanUpdate.setCaughPauseInterval(rtuDto.getCaughPauseSetting().getCaughPauseInterval());

			rtuTitanUpdate.setStatus(rtuDto.getStatus());
			rtuTitanUpdate.setEmailId(rtuDto.getEmailId());
			rtuTitanUpdate.setDeleted(false);
			rtuTitanUpdate.setAccepted(false);

			lstRemoteTherapyUpdateTitan.add(rtuTitanUpdate);
			
		}
		log.debug("updated list of RemoteTherapyUpdateTitan = "+lstRemoteTherapyUpdateTitan);
       
		lstRemoteTherapyUpdateTitan = remoteTherapyUpdateTitanRepository.save(lstRemoteTherapyUpdateTitan);
		return lstRemoteTherapyUpdateTitan;
				
	}
	
	public void createRtuHistory(String patientId, List<RemoteTherapyUpdateTitan> lstRemoteTherapyUpdateTitan) throws HillromException {
		List<RemoteTherapyUpdateHistoryTitan> remoteTherapyUpdateHistoryTitanList = new ArrayList<RemoteTherapyUpdateHistoryTitan>();
		RemoteTherapyUpdateHistoryTitan remoteTherapyUpdateHistoryTitan = null;
		List<RemoteTherapyUpdateTitan> remoteTherapyData = remoteTherapyUpdateTitanRepository.findByPatientId(patientId);
		
		if(!Objects.isNull(remoteTherapyData)) {
			for(int i=0; i<remoteTherapyData.size(); i++) {
				remoteTherapyUpdateHistoryTitan = new RemoteTherapyUpdateHistoryTitan();
				remoteTherapyUpdateHistoryTitan.setPatientId(remoteTherapyData.get(i).getPatientId());
				remoteTherapyUpdateHistoryTitan.setCreateDate(remoteTherapyData.get(i).getCreateDate());
				remoteTherapyUpdateHistoryTitan.setUpdateDate(remoteTherapyData.get(i).getUpdateDate());
				remoteTherapyUpdateHistoryTitan.setTherapyName(remoteTherapyData.get(i).getTherapyName());
				remoteTherapyUpdateHistoryTitan.setTherapyType(remoteTherapyData.get(i).getTherapyType());
				remoteTherapyUpdateHistoryTitan.setDeviceType(remoteTherapyData.get(i).getDeviceType());

				remoteTherapyUpdateHistoryTitan.setStep(remoteTherapyData.get(i).getStep());
				remoteTherapyUpdateHistoryTitan.setFrequency(remoteTherapyData.get(i).getFrequency());
				remoteTherapyUpdateHistoryTitan.setIntensity(remoteTherapyData.get(i).getIntensity());
				remoteTherapyUpdateHistoryTitan.setDuration(remoteTherapyData.get(i).getDuration());

				remoteTherapyUpdateHistoryTitan.setCaughPauseDuration(remoteTherapyData.get(i).getCaughPauseDuration());
				remoteTherapyUpdateHistoryTitan.setCaughAutoEnable(remoteTherapyData.get(i).getCaughAutoEnable());
				remoteTherapyUpdateHistoryTitan.setCaughIntervalMode(remoteTherapyData.get(i).getCaughIntervalMode());
				remoteTherapyUpdateHistoryTitan.setCaughPauseEnable(remoteTherapyData.get(i).getCaughPauseEnable());
				remoteTherapyUpdateHistoryTitan.setCaughPauseInterval(remoteTherapyData.get(i).getCaughPauseInterval());

				remoteTherapyUpdateHistoryTitan.setStatus(remoteTherapyData.get(i).getStatus());
				remoteTherapyUpdateHistoryTitan.setEmailId(remoteTherapyData.get(i).getEmailId());
				remoteTherapyUpdateHistoryTitan.setRtuId(remoteTherapyData.get(i).getId());
				remoteTherapyUpdateHistoryTitanList.add(remoteTherapyUpdateHistoryTitan);

			}
			remoteTherapyUpdateHistoryTitanRepository.save(remoteTherapyUpdateHistoryTitanList);
		}else {
			throw new HillromException(ExceptionConstants.HR_959);
		}

	}
	
	@Transactional
	private void updateRTUHistory(RemoteTherapyUpdateDataDTO rtuDto) throws HillromException {
		
		List<RemoteTherapyUpdateHistoryTitan> remoteTherapyHistory = remoteTherapyUpdateHistoryTitanRepository.findByPatientIdAndStatus(rtuDto.getPatientId(), PENDING);
		List<RemoteTherapyUpdateTitan> remoteTherapyData = remoteTherapyUpdateTitanRepository.findByPatientId(rtuDto.getPatientId());

		if( Objects.nonNull(remoteTherapyHistory) && !remoteTherapyHistory.isEmpty()) {

			for(int i=0; i<remoteTherapyData.size(); i++) {

				remoteTherapyHistory.get(i).setRtuId(remoteTherapyData.get(i).getId());

				remoteTherapyHistory.get(i).setPatientId(remoteTherapyData.get(i).getPatientId());

				remoteTherapyHistory.get(i).setUpdateDate(remoteTherapyData.get(i).getUpdateDate());
				remoteTherapyHistory.get(i).setUpdateDate(remoteTherapyData.get(i).getUpdateDate());
				remoteTherapyHistory.get(i).setTherapyName(remoteTherapyData.get(i).getTherapyName());
				remoteTherapyHistory.get(i).setTherapyType(remoteTherapyData.get(i).getTherapyType());
				remoteTherapyHistory.get(i).setDeviceType(remoteTherapyData.get(i).getDeviceType());

				remoteTherapyHistory.get(i).setFrequency(remoteTherapyData.get(i).getFrequency());
				remoteTherapyHistory.get(i).setIntensity(remoteTherapyData.get(i).getIntensity());
				remoteTherapyHistory.get(i).setDuration(remoteTherapyData.get(i).getDuration());
				remoteTherapyHistory.get(i).setStep(remoteTherapyData.get(i).getStep());

				remoteTherapyHistory.get(i).setCaughPauseDuration(remoteTherapyData.get(i).getCaughPauseDuration());
				remoteTherapyHistory.get(i).setCaughPauseEnable(remoteTherapyData.get(i).getCaughPauseEnable());
				remoteTherapyHistory.get(i).setCaughIntervalMode(remoteTherapyData.get(i).getCaughAutoEnable());
				remoteTherapyHistory.get(i).setCaughAutoEnable(remoteTherapyData.get(i).getCaughIntervalMode());
				remoteTherapyHistory.get(i).setCaughPauseInterval(remoteTherapyData.get(i).getCaughPauseInterval());

				remoteTherapyHistory.get(i).setStatus(remoteTherapyData.get(i).getStatus());
				remoteTherapyHistory.get(i).setEmailId(remoteTherapyData.get(i).getEmailId());

			}

			remoteTherapyUpdateHistoryTitanRepository.save(remoteTherapyHistory);
		}else {
			createRtuHistory(rtuDto.getPatientId(),remoteTherapyData);
		}
	}

	public List<RemoteTherapyUpdateDataDTO> getRTUHistoryByPatientId(String patientId) throws HillromException {
		RemoteTherapyUpdateDataDTO remoteTherapyUpdateDataDTO = null;
		CaughPauseSetting caughPauseSetting = null;
		List<TherapyParamDTO> lstTherapyParamDTO = null;
		List<RemoteTherapyUpdateDataDTO>  lstremoteTherapyUpdateHistoryTitanResponse = new ArrayList<RemoteTherapyUpdateDataDTO>();

		DateTime currentDateTime = new DateTime();
		log.debug("currentDateTime >>> : "+currentDateTime);
		
		DateTimeFormatter fmt = DateTimeFormat.forPattern("MM-dd-yyyy HH:mm:ss");
		List<RemoteTherapyUpdateHistoryTitan> sortedLstRemoteTherapyHistoryDataBAyId =remoteTherapyUpdateHistoryTitanRepository.findByPatientId(patientId).stream().sorted(Comparator.comparingLong(RemoteTherapyUpdateHistoryTitan::getId)).collect(Collectors.toList());
		log.debug("sort by Id rtu history data ----------"+sortedLstRemoteTherapyHistoryDataBAyId);

		if(!Objects.isNull(sortedLstRemoteTherapyHistoryDataBAyId)) {
			Map<DateTime, List<RemoteTherapyUpdateHistoryTitan>> mapRtuHistoryDataGroupByUpdateDate = sortedLstRemoteTherapyHistoryDataBAyId.stream().collect(Collectors.groupingBy(o -> o.getUpdateDate() == null ? currentDateTime : o.getUpdateDate()));				
			log.debug("Group by updatedDate rtu history data ----------"+mapRtuHistoryDataGroupByUpdateDate);

			if(mapRtuHistoryDataGroupByUpdateDate !=null && !mapRtuHistoryDataGroupByUpdateDate.isEmpty()) {
				for(Map.Entry<DateTime, List<RemoteTherapyUpdateHistoryTitan>> entry : mapRtuHistoryDataGroupByUpdateDate.entrySet()) {
					lstTherapyParamDTO =new ArrayList<>();
					
					remoteTherapyUpdateDataDTO= new RemoteTherapyUpdateDataDTO();

					List<RemoteTherapyUpdateHistoryTitan> lstRtuHistoryData = entry.getValue();
					log.debug("key >>> : "+entry.getKey());
					log.debug("Value >>> : "+entry.getValue());

					if(lstRtuHistoryData !=null && !lstRtuHistoryData.isEmpty()) {
						for (RemoteTherapyUpdateHistoryTitan remoteTherapyUpdateHistoryTitan : lstRtuHistoryData) {
							DateTime updatedDate = remoteTherapyUpdateHistoryTitan.getUpdateDate() == null ? currentDateTime : remoteTherapyUpdateHistoryTitan.getUpdateDate(); 
							if(updatedDate.equals(entry.getKey())) {
								remoteTherapyUpdateDataDTO.setTherapyName(remoteTherapyUpdateHistoryTitan.getTherapyName());

								TherapyParamDTO therapyParamDTO = new TherapyParamDTO();
								therapyParamDTO.setDuration(remoteTherapyUpdateHistoryTitan.getDuration());
								therapyParamDTO.setFrequency(remoteTherapyUpdateHistoryTitan.getFrequency());
								therapyParamDTO.setIntensity(remoteTherapyUpdateHistoryTitan.getIntensity());
								therapyParamDTO.setStep(remoteTherapyUpdateHistoryTitan.getStep());
								lstTherapyParamDTO.add(therapyParamDTO);
								remoteTherapyUpdateDataDTO.setTherapyParam(lstTherapyParamDTO);
								
								caughPauseSetting = new CaughPauseSetting();
								caughPauseSetting.setCaughPauseEnable(remoteTherapyUpdateHistoryTitan.getCaughPauseEnable());
								caughPauseSetting.setAfterEachStepStatus(remoteTherapyUpdateHistoryTitan.getCaughIntervalMode());
								caughPauseSetting.setAutoRestartStatus(remoteTherapyUpdateHistoryTitan.getCaughAutoEnable());
								caughPauseSetting.setCaughPauseInterval(remoteTherapyUpdateHistoryTitan.getCaughPauseInterval());
								caughPauseSetting.setCaughPauseDuration(remoteTherapyUpdateHistoryTitan.getCaughPauseDuration());
								remoteTherapyUpdateDataDTO.setCaughPauseSetting(caughPauseSetting);

								remoteTherapyUpdateDataDTO.setTherapyType(remoteTherapyUpdateHistoryTitan.getTherapyType());
								remoteTherapyUpdateDataDTO.setDeviceType(remoteTherapyUpdateHistoryTitan.getDeviceType());
								remoteTherapyUpdateDataDTO.setStatus(remoteTherapyUpdateHistoryTitan.getStatus());
								remoteTherapyUpdateDataDTO.setPatientId(remoteTherapyUpdateHistoryTitan.getPatientId());
								remoteTherapyUpdateDataDTO.setEmailId(remoteTherapyUpdateHistoryTitan.getEmailId());				
								remoteTherapyUpdateDataDTO.setCreateDate(fmt.print(remoteTherapyUpdateHistoryTitan.getCreateDate()));
								remoteTherapyUpdateDataDTO.setUpdateDate(fmt.print(remoteTherapyUpdateHistoryTitan.getUpdateDate()));

							}
						}
						lstremoteTherapyUpdateHistoryTitanResponse.add(remoteTherapyUpdateDataDTO);
					}
				}
			}
		}else {
			throw new HillromException(ExceptionConstants.HR_959);
		}
		log.debug("rtu history response ----------"+lstremoteTherapyUpdateHistoryTitanResponse);
		return lstremoteTherapyUpdateHistoryTitanResponse;
	}
}