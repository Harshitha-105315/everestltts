package com.hillrom.titan.batch.processing;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.inject.Inject;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.titan.repository.VestDeviceBadDataRepositoryTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.VestDeviceBadDataTitan;
import com.hillrom.vest.service.MailService;

public class CustomItemReaderListenerTitan implements ItemReadListener<List<PatientVestDeviceDataTitan>>{

	String patientDeviceRawDataTitan;
	
	@Inject
	VestDeviceBadDataRepositoryTitan badDataRepositoryTitan;
	
	@Inject
	MailService mailServie;
	@Override
	public void beforeRead() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterRead(List<PatientVestDeviceDataTitan> item) {
		// TODO Auto-generated method stub
		
	}

	@Override	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void onReadError(Exception ex) {
		badDataRepositoryTitan.save(new VestDeviceBadDataTitan(patientDeviceRawDataTitan));
		StringWriter writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter( writer );
		ex.printStackTrace( printWriter );
		mailServie.sendStatusOnDataIngestionRequest(patientDeviceRawDataTitan,"FAILED" ,true, writer.toString());
	}
	
	@Value("#{jobParameters['rawData']}")
	public void setRawData(final String rawData) {
		this.patientDeviceRawDataTitan = rawData;

	}

}
