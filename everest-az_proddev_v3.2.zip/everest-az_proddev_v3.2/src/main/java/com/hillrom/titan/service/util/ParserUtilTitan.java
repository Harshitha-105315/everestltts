package com.hillrom.titan.service.util;

import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.CRC_FIELD_NAME;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_DATA_FIELD_NAME;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEV_BT;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEV_SN;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEV_VER;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEV_WIFI;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.FRAG_CURRENT_FIELD_NAME;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.FRAG_TOTAL_FIELD_NAME;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hillrom.vest.config.Constants.CONNECTIONTYPE;
import com.hillrom.vest.exceptionhandler.HillromException;

import net.minidev.json.JSONObject;

public class ParserUtilTitan {

	private static final Logger log = LoggerFactory.getLogger(ParserUtilTitan.class);

	private ParserUtilTitan(){

	}

	public static String getValueFromQclJsonDataTitan(JSONObject qclJsonDataTitan,String key){
		String value = "";
		String valuePropertiesNew = (String) qclJsonDataTitan.get(key);
		if(Objects.nonNull(valuePropertiesNew)){
			return valuePropertiesNew;
		}
		log.debug(""+ key + " : " + value );
		return value;
	}

	public static String getTitanDeviceData(String rawMessage){

		byte[] b = java.util.Base64.getDecoder().decode(rawMessage);

		String deviceData = "";
		int start = returnMatch(b,DEVICE_DATA_FIELD_NAME);
		int end = returnMatch(b,CRC_FIELD_NAME)-CRC_FIELD_NAME.length;
		log.debug("start end : "+ start + " : " + end );

		byte[] deviceDataArray = new byte[end];
		int j=0;
		for(int i=start;i<end;i++) {
			deviceDataArray[j++] = b[i];
			int val = b[i] & 0xFF;
			deviceData = deviceData + String.valueOf(val) + " ";
		}
		return deviceData;        
	}

	public static int getFragTotal(String encoded_string) throws HillromException{
		byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
		String sout = "";
		for(int i=0;i<b.length;i++) {
			int val = b[i] & 0xFF;
			sout = sout + val + " ";
		}

		//log.debug("Input Byte Array in getFragTotal :"+sout);


		int start = returnMatch(b,FRAG_TOTAL_FIELD_NAME);
		log.debug("start : "+ start  );
		if(start < 0){
			return 0;
		}
		int fragTotal = b[start] & 0xFF;

		log.debug("Total number of fragments : "+ fragTotal );
		return fragTotal;

	}

	public static int getFragCurrent(String encoded_string) throws HillromException{
		byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
		String sout = "";
		for(int i=0;i<b.length;i++) {
			int val = b[i] & 0xFF;
			sout = sout + val + " ";
		}

		//log.debug("Input Byte Array in getFragCurrent :"+sout);


		int start = returnMatch(b,FRAG_CURRENT_FIELD_NAME);
		log.debug("start : "+ start  );
		if(start < 0){
			return 0;
		}
		int fragCurrent = b[start] & 0xFF;

		log.debug("Current fragment number : "+ fragCurrent );
		return fragCurrent;
	}

	public static String getCRCChecksum(String encoded_string)
	{

		log.debug("Inside  getCRCChecksum : " ,encoded_string);

		int nCheckSum = 0;

		byte[] decoded = java.util.Base64.getDecoder().decode(encoded_string);

		int nDecodeCount = 0;
		for ( ; nDecodeCount < (decoded.length-2); nDecodeCount++ )
		{
			int nValue = (decoded[nDecodeCount] & 0xFF);
			nCheckSum += nValue;
		}

		log.debug("Inverted Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);

		int nMSB = decoded[nDecodeCount+1] & 0xFF;
		int nLSB = decoded[nDecodeCount] & 0xFF;

		log.debug("MSB = %d [0x%x]\r\n" ,nMSB, nMSB);
		log.debug("LSB = %d [0x%x]\r\n" ,nLSB, nLSB);
		log.info("Total Value = " + nCheckSum);
		nCheckSum = ((~nCheckSum)& 0xFFFF) + 1;
		log.debug("Checksum Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);

		String msb_digit = Integer.toHexString(nMSB);
		String lsb_digit = Integer.toHexString(nLSB);
		String checksum_num =  Integer.toHexString(nCheckSum);

		if(msb_digit.length()<2)
			msb_digit = "0"+msb_digit;
		if(lsb_digit.length()<2)
			lsb_digit = "0"+lsb_digit;

		log.debug("MSB : " + msb_digit + " " +  "LSB : " + lsb_digit);
		log.debug("Checksum : " + checksum_num);

		return checksum_num;
	}
	
	public static String devWifiOrBtString(String encoded_string, CONNECTIONTYPE flagWifiBt) throws HillromException{
		
        byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
                        
        // Flag 1-WIFI & 2-BT 
        int start = flagWifiBt.equals(CONNECTIONTYPE.devWIFI) ? returnMatch(b,DEV_WIFI) :  (flagWifiBt.equals(CONNECTIONTYPE.devBT) ? returnMatch(b,DEV_BT) : -1);
        
        int end = returnMatch(b,DEV_VER)-DEV_VER.length;
        log.debug("start end : "+ start + " : " + end );
        if(start < 0 || end < 0){
        	return null;
        }
        byte[] devWifiOrBtArray = new byte[end];
        int j=0;
        sout = "";
        String stringValue = "";
        for(int i=start;i<end;i++) {
        	devWifiOrBtArray[j++] = b[i];
        	int val = b[i] & 0xFF;
        	stringValue += (char)val;
        }
        
    	log.debug("Value of devWifiBt : "+ stringValue );
    	return stringValue;
        	
	}
	
	public static String getDevVerString(String encoded_string) throws HillromException{
        byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
        
        String devVer = "";
        int start = returnMatch(b,DEV_VER);
        int end = returnMatch(b,FRAG_TOTAL_FIELD_NAME)-FRAG_TOTAL_FIELD_NAME.length;
        log.debug("start end : "+ start + " : " + end );
        if(start < 0 || end < 0){
        	return null;
        }
        byte[] devVerArray = new byte[end];
        int j=0;
        sout = "";
        for(int i=start;i<end;i++) {
        	devVerArray[j++] = b[i];
        	int val = b[i] & 0xFF;
        	devVer = devVer + val + " ";
        }

        log.debug("Value of devVer : "+ devVer );
        return devVer;
        
	}
	
	public static String getDevSN(String encoded_string) throws HillromException{
        byte[] b = java.util.Base64.getDecoder().decode(encoded_string);
        String sout = "";
        String devserialNO= "";
        for(int i=0;i<b.length;i++) {
        	int val = b[i] & 0xFF;
        	sout = sout + val + " ";
        }
        
        String devSN = "";
        int start = returnMatch(b,DEV_SN);
        int end = returnMatch(b,DEV_WIFI) == -1 ? 
        					returnMatch(b,DEV_BT)-DEV_BT.length : 
        		returnMatch(b,DEV_WIFI)-DEV_WIFI.length;
        log.debug("start end : "+ start + " : " + end );
        if(start < 0 || end < 0){
        	return null;
        }
        byte[] devSNArray = new byte[end];
        int j=0;
        sout = "";
        for(int i=start;i<end;i++) {
        	devSNArray[j++] = b[i];
        	int val = b[i] & 0xFF;
        	devserialNO += (char)val;
        	devSN = devSN + val + " ";
        }
        
        log.debug("Value of devSN : "+ devSN );
        return devserialNO;
        
	}

	public static int intergerCombinedFromHex(byte[] input)
	{
	    int hexTotal = 0;
	    for (int t = 0; t < input.length; t++)
	    {
	    	hexTotal = hexTotal + Integer.parseInt(Integer.toHexString(input[t]& 0xFF), 16);
	    }
	    
	    log.debug("hexTotal : " + hexTotal);
	    return hexTotal;
	}
	
	public static int intergerCombinedFromHexForHMR(byte[] input)
	{	    
	    String hexTotal = "";
	    for (int t = 0; t < input.length; t++){
	    	String integerToHex = Integer.toHexString(input[t]& 0xFF);
	    	hexTotal = hexTotal + (integerToHex.length() == 1 ? "0"+integerToHex : integerToHex);
	    }
	    log.debug("hexTotal : " + Integer.parseInt(hexTotal, 16));
	    return Integer.parseInt(hexTotal, 16);
	}
	
	public static int returnMatch(byte[] inputArray,byte[] matchArray){

		for(int i=0;i<inputArray.length;i++){
			int val = inputArray[i] & 0xFF;
			boolean found = false;

			if((val == 38) && !found){
				int j=i;int k=0;
				while((inputArray[j++]==matchArray[k++]) && (k<matchArray.length)){

				}
				if(k==matchArray.length){
					found = true;
					return j;
				}
			}
		}

		return -1;

	}




}
