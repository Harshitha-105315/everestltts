package com.hillrom.titan.repository;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hillrom.titan.domain.TitanData;
	
@Repository
public interface TitanDataRepository extends JpaRepository<TitanData,String> {
	
	Page<TitanData> findByCreatedTimeBetweenOrderByIdDesc(DateTime from, DateTime to, Pageable pageable);
	
	Page<TitanData> findBySerialNumberAndCreatedTimeBetweenOrderByIdDesc(String serialNumber, DateTime from, DateTime to, Pageable pageable);	
}
