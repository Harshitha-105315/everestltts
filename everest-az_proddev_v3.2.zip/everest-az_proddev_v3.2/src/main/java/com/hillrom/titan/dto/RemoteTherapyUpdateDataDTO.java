package com.hillrom.titan.dto;

import java.util.List;

import org.joda.time.DateTime;

public class RemoteTherapyUpdateDataDTO {
	
	private String therapyName;
	private List<TherapyParamDTO> therapyParam;
	private CaughPauseSetting caughPauseSetting;
	private Integer therapyType;
	private String deviceType;
	private String status;
	private String patientId;
	private String emailId;
	private String createDate;
	private String updateDate;
	private boolean isDeleted;
	
	public String getTherapyName() {
		return therapyName;
	}
	public void setTherapyName(String therapyName) {
		this.therapyName = therapyName;
	}
	public List<TherapyParamDTO> getTherapyParam() {
		return therapyParam;
	}
	public void setTherapyParam(List<TherapyParamDTO> therapyParam) {
		this.therapyParam = therapyParam;
	}
	public CaughPauseSetting getCaughPauseSetting() {
		return caughPauseSetting;
	}
	public void setCaughPauseSetting(CaughPauseSetting caughPauseSetting) {
		this.caughPauseSetting = caughPauseSetting;
	}
	public Integer getTherapyType() {
		return therapyType;
	}
	public void setTherapyType(Integer therapyType) {
		this.therapyType = therapyType;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	@Override
	public String toString() {
		return "RemoteTherapyUpdateDataDTO [therapyName=" + therapyName + ", therapyParam=" + therapyParam
				+ ", caughPauseSetting=" + caughPauseSetting + ", therapyType=" + therapyType + ", deviceType="
				+ deviceType + ", status=" + status + ", patientId=" + patientId + ", emailId=" + emailId
				+ ", createDate=" + createDate + ", updateDate=" + updateDate + ", isDeleted=" + isDeleted + "]";
	}

}