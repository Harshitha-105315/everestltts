package com.hillrom.titan.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Size;

public class ProtocolTitanDTO {
	
	@Size(max = 20)
	private String type;
	
	@Size(max = 50)
	private int treatmentsPerDay;
	
	private List<ProtocolEntryTitanDTO> protocolEntries = new ArrayList<>();
	
	public ProtocolTitanDTO() {
		super();
	}

	public ProtocolTitanDTO(String type, int treatmentsPerDay,
			List<ProtocolEntryTitanDTO> protocolEntries) {
		super();
		this.type = type;
		this.treatmentsPerDay = treatmentsPerDay;
		this.protocolEntries = protocolEntries;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getTreatmentsPerDay() {
		return treatmentsPerDay;
	}

	public void setTreatmentsPerDay(int treatmentsPerDay) {
		this.treatmentsPerDay = treatmentsPerDay;
	}

	public List<ProtocolEntryTitanDTO> getProtocolEntries() {
		return protocolEntries;
	}

	public void setProtocolEntries(List<ProtocolEntryTitanDTO> protocolEntries) {
		this.protocolEntries = protocolEntries;
	}

	@Override
	public String toString() {
		return "ProtocolTitanDTO [type=" + type + ", treatmentsPerDay=" + treatmentsPerDay + ", protocolEntries="
				+ protocolEntries + "]";
	}

}
