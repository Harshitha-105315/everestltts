package com.hillrom.titan.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitanPK;

@Repository
public interface PatientTitanDeviceDataRepository extends
JpaRepository<PatientVestDeviceDataTitan, PatientVestDeviceDataTitanPK>{

	@Query("Select pvdd from PatientVestDeviceDataTitan pvdd where pvdd.patientUser.id = ?1 and pvdd.patientVestDeviceDataTitanPK.timestamp between ?2 and ?3 ")
	public List<PatientVestDeviceDataTitan> findByPatientUserIdAndTimestampBetween(Long id,Long from,Long to);
	
	public List<PatientVestDeviceDataTitan> findByPatientUserIdAndSerialNumberAndTherapyIndex(Long id,String serialNumber,Integer therapyIndex);
	
	public PatientVestDeviceDataTitan findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(Long id,String serialNumber);

	@Query("Select pvdd from PatientVestDeviceDataTitan pvdd where pvdd.patientVestDeviceDataTitanPK.patient.id = ?1 and pvdd.patientVestDeviceDataTitanPK.timestamp between ?2 and ?3 ")
	public List<PatientVestDeviceDataTitan> findByPatientIdAndTimestampBetween(String patientId,Long from,Long to);
	
}
