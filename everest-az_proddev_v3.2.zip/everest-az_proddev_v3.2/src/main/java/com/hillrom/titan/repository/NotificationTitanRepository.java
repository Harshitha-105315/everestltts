package com.hillrom.titan.repository;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.NotificationTitan;

public interface NotificationTitanRepository extends JpaRepository<NotificationTitan, Long>  {
	
	@Query("from NotificationTitan nf where nf.patientUser.id = ?1 and nf.date = ?2")
	List<NotificationTitan> findAllByPatientUserIdAndDate(Long patientUserId, LocalDate date);

}
