package com.hillrom.titan.web.rest;

import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hillrom.titan.TitanParseUtil;
import com.hillrom.titan.dto.RemoteTherapyUpdateDataDTO;
import com.hillrom.titan.dto.TherapySettingDTO;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.titan.service.RemoteTherapyUpdateTitanService;
import com.hillrom.titan.service.TitanDataService;
import com.hillrom.titan.web.rest.dto.RemoteTherapyUpdateTitanVO;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.RemoteTherapyUpdateHistoryTitan;
import com.hillrom.vest.domain.RemoteTherapyUpdateTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;

import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api")
public class TitanDeviceDataResource {

	@Inject
	private TitanDataService titanDataService;
	
	@Inject
	private PatientTitanDeviceRepository patientTitanDeviceRepository;
	 
	@Inject
	private RemoteTherapyUpdateTitanService remoteTherapyUpdateTitanService;
	
	@Inject
	private UserService userService;
	
	private final Logger log = LoggerFactory.getLogger(TitanDeviceDataResource.class);
	
	@RequestMapping(value = "/receiveDataTitan",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> receiveDataTitan(@RequestBody(required=true)String rawMessage){
		try{
			log.info("Base64 Received Data for ingestion in receiveDataCharger : ",rawMessage);
			JSONObject chargerJsonData = new JSONObject();
			ExitStatus exitStatus = titanDataService.saveData(rawMessage);
			if(ExitStatus.COMPLETED.equals(exitStatus)){
				chargerJsonData.put(RESULT, "OK - ");
				return new ResponseEntity<>(chargerJsonData,HttpStatus.CREATED);
			}
			else{
				chargerJsonData.put(RESULT, "NOT OK - UnKnown Error");
				return new ResponseEntity<>(chargerJsonData,HttpStatus.PARTIAL_CONTENT);

			}
		}catch(Exception e){
			e.printStackTrace();
			JSONObject error = new JSONObject();
			error.put(RESULT, "NOT OK - "+e.getMessage());
			return new ResponseEntity<>(error,HttpStatus.PARTIAL_CONTENT);
		}
	}
	
	// device_model_type=HillRom_Titan&devSN=1234567890&request_id=2002&command=THERAPY_SETTINGS_UPDATE_COMPLETE&command_param=10001&crc=2512
	@RequestMapping(value = "/titanDevice",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> therapySettingDetail(@RequestBody(required=true)String rawMessage) {
		JSONObject jsonObject = new JSONObject();
		String patientId = null;
		String content = "";

		try {
			log.info("therapySettingDetail rawMessage : "+rawMessage);
			Map<String, String> paraMap = TitanParseUtil.parseMessage(rawMessage);
			log.info("paraMap from rawMessage : "+paraMap);
			
			//CRC validation
			int crcValue = titanDataService.createCrc(rawMessage.substring(0, (rawMessage.length() - paraMap.get(CRC).length())));
			if(Integer.parseInt(paraMap.get(CRC)) != crcValue) {
				return new ResponseEntity<>("Error : CRC Validation Failed", HttpStatus.BAD_REQUEST);
			}

			if (Objects.nonNull(paraMap.get(COMMAND))) {
				if ("TITAN_GET_THERAPY_SETTINGS".equalsIgnoreCase(paraMap.get(COMMAND))) { // TITAN_GET_THERAPY_SETTINGS

					List<PatientVestDeviceHistoryTitan> patientTitanDeviceHistoryList = patientTitanDeviceRepository.findBySerialNumber(paraMap.get(DEVICE_SN));
					if(patientTitanDeviceHistoryList.isEmpty()){
						throw new HillromException(paraMap.get(DEVICE_SN)+" "+ExceptionConstants.HR_571);
					}else {
						for(PatientVestDeviceHistoryTitan patientTitanDevicePatient : patientTitanDeviceHistoryList){
							if(Objects.nonNull(patientTitanDevicePatient)){
								patientId = patientTitanDevicePatient.getPatient().getId();
							}
						}
						log.info("patientId : "+patientId);
						TherapySettingDTO setting = remoteTherapyUpdateTitanService.prepareTherapySettingData(paraMap,patientId);
						if(setting.getTheraptData()==null) {
							content=titanDataService.formatStatusResponseString(setting);
						}
						else {
							content = titanDataService.formatResponseString(setting);
						}
					}
				}else if ("THERAPY_SETTINGS_UPDATE_COMPLETE".equalsIgnoreCase(paraMap.get(COMMAND))) { 

					List<PatientVestDeviceHistoryTitan> patientTitanDeviceHistoryList = patientTitanDeviceRepository.findBySerialNumber(paraMap.get(DEVICE_SN));
					if(patientTitanDeviceHistoryList.isEmpty()){
						throw new HillromException(paraMap.get(DEVICE_SN)+" "+ExceptionConstants.HR_571);
					}else {
						for(PatientVestDeviceHistoryTitan patientTitanDevicePatient : patientTitanDeviceHistoryList){
							if(Objects.nonNull(patientTitanDevicePatient)){
								patientId = patientTitanDevicePatient.getPatient().getId();
							}
						}
						log.info("patientId : "+patientId);
						TherapySettingDTO setting = remoteTherapyUpdateTitanService.updateTherapySettingStatusToAccepted(paraMap,patientId);
						content = titanDataService.formatStatusResponseString(setting);
					}
				}  else if ("THERAPY_SETTINGS_UPDATE_CANCEL".equalsIgnoreCase(paraMap.get(COMMAND))) { 

					List<PatientVestDeviceHistoryTitan> patientTitanDeviceHistoryList = patientTitanDeviceRepository.findBySerialNumber(paraMap.get(DEVICE_SN));
					if(patientTitanDeviceHistoryList.isEmpty()){
						throw new HillromException(paraMap.get(DEVICE_SN)+" "+ExceptionConstants.HR_571);
					}else {
						for(PatientVestDeviceHistoryTitan patientTitanDevicePatient : patientTitanDeviceHistoryList){
							if(Objects.nonNull(patientTitanDevicePatient)){
								patientId = patientTitanDevicePatient.getPatient().getId();
							}
						}
						log.info("patientId : "+patientId);
						TherapySettingDTO setting = remoteTherapyUpdateTitanService.updateTherapySettingStatusToRejected(paraMap,patientId);
						content = titanDataService.formatStatusResponseString(setting);
						log.debug("content---------"+content);
					}
				}  	else {
					return new ResponseEntity<>("Error : Invalid command : " + paraMap.get(COMMAND), HttpStatus.BAD_REQUEST);
				}
				return new ResponseEntity<>(content, HttpStatus.OK);
			}else {
				return new ResponseEntity<>("Error : Required paramter missing", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception ex) {
			jsonObject.put("ERROR", ex.getMessage());
			return new ResponseEntity<>(jsonObject,HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/titan/therapySetting", method = RequestMethod.POST)
	public ResponseEntity<?> GetTitanTherapySetting(@RequestBody(required = true) Map<String, String> rawMessage) {

		JSONObject jsonObject = new JSONObject();
		InputStream is = null;
		String content = "";

		try {
			Map<String, String> paraMap = TitanParseUtil.parseMessage(rawMessage.get("body"));
			log.debug("COMMAND :" + paraMap.get(COMMAND));
			switch (paraMap.get(COMMAND)) {
				case "THERAPY_SETTINGS_UPDATE_COMPLETE":
					content = titanDataService.updateTherapySettings(paraMap);
				case "GET_USER_INFO":
					content = titanDataService.getUserInfo(paraMap);
				case "TITAN_GET_THERAPY_SETTINGS":
					is = getClass().getClassLoader().getResourceAsStream("public/mobile-images/" + paraMap.get("devSN") + ".txt");
					if (Objects.isNull(is))
						is = getClass().getClassLoader().getResourceAsStream("public/mobile-images/titanTestBed.txt");
					
					BufferedReader r = new BufferedReader(new InputStreamReader(is));
					String line = "";
					while ((line = r.readLine()) != null) {
						content = content + line;
					}
					is.close();
	
					log.debug("FILE content " + content);
					TherapySettingDTO tsdto = TitanParseUtil.parseTherapySettingContent(content, paraMap.get("devSN"));
					//log.debug("tsdto = " + tsdto.toString());
					
				return new ResponseEntity<>(tsdto, HttpStatus.OK);
			default:
				return new ResponseEntity<>("Error : Required paramter missing", HttpStatus.BAD_REQUEST);
			}

		} catch (Exception ex) {
			jsonObject.put("ERROR", ex.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	/**
	 * Update therapy setting.
	 * 
	 * @param setting which have updates.
	 * @return status.
	 */
	@RequestMapping(value = "/titan/therapysetting", method = RequestMethod.PUT)
	public ResponseEntity<?> updateTitanTherapySetting(@RequestBody(required = true) TherapySettingDTO setting) {
		
		StringBuilder deviceStting = new StringBuilder();
		deviceStting.append("__REQID=").append(setting.getRequestId())
		.append("__RESULT=").append(setting.getResult())
				.append("__RECID=").append(setting.getRecordId());
		
		if(!setting.getTherapySetting().isEmpty()) {
			//deviceStting.append("__").append(setting.getTherapySetting());
			deviceStting.append(setting.getTherapySetting());
		}
		
		deviceStting.append("__CRC=").append(titanDataService.createCrc(deviceStting.toString()));

		String filePath = "public/mobile-images/" + setting.getDevSN() + ".txt";
		File file = null;
		try {
			file = ResourceUtils.getFile("classpath:" + filePath);
			log.debug("file path = " + file.getPath());
	        if (!file.exists()) {
	        	log.debug("file path1 = " + file.getPath());
	        	file = ResourceUtils.getFile("classpath:" + "public/mobile-images/titanTestBed.txt");
	        }
	        
			StringBuilder contentToWrite = new StringBuilder("##" + setting.getRequestId())		// request ID
					.append("##" + setting.getResult())	// result
					.append("##" + setting.getRecordId()) // record DI
					.append("##" + setting.getTherapySetting())	// therapy setting
					.append("##" + setting.getCrc()); // CRC
			titanDataService.clearOldFile(file.getPath());
			titanDataService.writeToExternalFile(contentToWrite, new File(file.getPath()));
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return new ResponseEntity<>(null, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/rtuHistory/{patientId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getTherapyHistoryById(@PathVariable String patientId) {
		RemoteTherapyUpdateDataDTO remoteTherapySettings =null;
		try {
			remoteTherapySettings =titanDataService.getTherapyHistoryById(patientId);
		} catch (HillromException e) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("ERROR", e.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.NOT_FOUND);
		}
		remoteTherapySettings.setEmailId(userService.encryptData(remoteTherapySettings.getEmailId()));
		return new ResponseEntity<>(remoteTherapySettings, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/uploadRTU",
			method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> uploadRTUData(@RequestBody RemoteTherapyUpdateDataDTO rtuDto) throws HillromException {
		log.debug("REST request to uploat RTU : "+rtuDto);
		JSONObject jsonObject = new JSONObject();

		if(Objects.isNull(rtuDto) || rtuDto.getTherapyName().equals(null) || rtuDto.getTherapyParam().isEmpty() || Objects.isNull(rtuDto.getCaughPauseSetting())){
			jsonObject.put("ERROR", "Required Param missing for uploading Remote Therapy Update.");
			return new ResponseEntity<>(jsonObject,HttpStatus.BAD_REQUEST);
		}else {
			List<RemoteTherapyUpdateTitan> rtuResult = titanDataService.saveOrUpdateRTUDataByPatientId(rtuDto);

			if (Objects.nonNull(rtuResult)) {
				List<RemoteTherapyUpdateDataDTO>  lstRemoteTherapyHistory = titanDataService.getRTUHistoryByPatientId(rtuDto.getPatientId());
				lstRemoteTherapyHistory.forEach(x->x.setEmailId(userService.encryptData(x.getEmailId())));
				jsonObject.put("message", MessageConstants.HR_320);
				jsonObject.put("therapyData", lstRemoteTherapyHistory);

				return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);				
			} else {
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		}
	}
	@RequestMapping(value = "/getRtuHistory/{patientId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getRTUHistoryByPatientId(@PathVariable String patientId) {
		List<RemoteTherapyUpdateDataDTO> remoteTherapyHistory =null;
		try {
			remoteTherapyHistory = titanDataService.getRTUHistoryByPatientId(patientId);
			remoteTherapyHistory.forEach(x->x.setEmailId(userService.encryptData(x.getEmailId())));
			if(!remoteTherapyHistory.isEmpty()) {
				Collections.sort(remoteTherapyHistory, new Comparator<RemoteTherapyUpdateDataDTO>() {
					public int compare(RemoteTherapyUpdateDataDTO r1, RemoteTherapyUpdateDataDTO r2) {
						return r2.getUpdateDate().compareTo(r1.getUpdateDate());
					}
				});
			}
		} catch (HillromException e) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("ERROR", e.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(remoteTherapyHistory, HttpStatus.OK);
	}

}
