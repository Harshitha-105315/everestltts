package com.hillrom.titan;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.hillrom.titan.dto.TherapySettingDTO;


public class TitanParseUtil {

	// device_model_type=Hillrom_Titan&devSN=123456&request_id=1&command=THERAPY_SETTINGS_UPDATE_COMPLETE&command_param=0&crc=1234

	public static Map<String, String> parseMessage(String rawMessage) {

		Map<String, String> paraMap = new LinkedHashMap<>();
		List<String> paramList = Arrays.asList(rawMessage.split("&"));
		for (String param : paramList) {
			paraMap.put(param.substring(0,param.indexOf("=")), param.substring(param.indexOf("=") + 1));
		}
		return paraMap;
	}
	
	public static TherapySettingDTO parseTherapySettingContent(String content, String devSN) {
		TherapySettingDTO tsDTO = new TherapySettingDTO();
		tsDTO.setRequestId(content.split("##")[1]);
		tsDTO.setRecordId(content.split("##")[3]);
		tsDTO.setResult(content.split("##")[2]);
		tsDTO.setTherapySetting(content.split("##")[4]);
		tsDTO.setCrc(content.split("##")[5]);
		tsDTO.setDevSN(devSN);
		return tsDTO;
	}

}
