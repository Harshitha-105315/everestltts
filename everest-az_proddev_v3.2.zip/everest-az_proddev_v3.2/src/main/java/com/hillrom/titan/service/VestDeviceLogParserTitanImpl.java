package com.hillrom.titan.service;

import static com.hillrom.vest.config.Constants.MAX_DURATION;
import static com.hillrom.vest.config.Constants.MAX_FREQUENCY;
import static com.hillrom.vest.config.Constants.MAX_INTESITY;
import static com.hillrom.vest.config.Constants.MIN_DURATION;
import static com.hillrom.vest.config.Constants.MIN_FREQUENCY;
import static com.hillrom.vest.config.Constants.MIN_INTESITY;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hillrom.titan.service.util.ParserUtilTitan;
import com.hillrom.vest.batch.processing.PatientVestDeviceDataDeltaReader;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.CorruptedTitanDeviceDataEvents;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitanPK;
import com.hillrom.vest.domain.PatientVestDeviceRawLogTitan;
import com.hillrom.vest.domain.PingPongPing;
import com.hillrom.vest.repository.PingPongPingRepository;
import com.hillrom.vest.service.DeviceLogTitanParser;
import com.hillrom.vest.service.util.ParserUtil;

import net.minidev.json.JSONObject;

@Component
public class VestDeviceLogParserTitanImpl implements DeviceLogTitanParser{

	String strClassName = "VestDeviceLogParserTitanImpl";
	
	@Inject
	private PingPongPingRepository pingpongpingrepository;
	
	@Inject 
	private TitanDataService titanDataService;
	
	private final Logger log = LoggerFactory.getLogger(PatientVestDeviceDataDeltaReader.class);

	
	@Override
	public PatientVestDeviceRawLogTitan parseBase64StringToPatientTitanDeviceRawLog(String rawMessageTitan)
			throws Exception {
		String strMethodName = "parseBase64StringToPatientTitanDeviceRawLog";

		String decodedString = decodeData(rawMessageTitan);
		
		JSONObject jsonDataTitan = ParserUtil.getChargerJsonDataFromRawMessage(decodedString);

		PatientVestDeviceRawLogTitan patientVestDeviceRawLogTitan = createPatientVestDeviceRawLogTitan(rawMessageTitan,jsonDataTitan);
		
		try {
			if(StringUtils.isBlank(patientVestDeviceRawLogTitan.getDeviceSerialNumber()) ||
						StringUtils.isBlank(patientVestDeviceRawLogTitan.getDeviceData())){	
				throw new IllegalArgumentException("Could not parse data, Bad Content");
			}
		} catch (Exception e) {
			throw new IllegalArgumentException("Could not parse data, Bad Content");
		}
		log.debug(strClassName , strMethodName, "PatientVestDeviceRawLog : "+patientVestDeviceRawLogTitan);
		return patientVestDeviceRawLogTitan;
	}
	
	public String decodeData(final String rawMessage){
		byte[] decoded = java.util.Base64.getDecoder().decode(rawMessage);

		String decoded_string = new String(decoded);
		log.info("Decoded value is " + decoded_string);
		return decoded_string;
	}
	
	private PatientVestDeviceRawLogTitan createPatientVestDeviceRawLogTitan(
			String rawMessageTitan,JSONObject qclJsonDataTitan)  throws Exception{
		PatientVestDeviceRawLogTitan patientVestDeviceRawLogTitan = new PatientVestDeviceRawLogTitan();
		
		log.info( "rawMessageTitan :" + rawMessageTitan + " qclJsonDataTitan :" +qclJsonDataTitan);
		
		patientVestDeviceRawLogTitan.setRawMessage(rawMessageTitan);

		// TO BE ELEMINATED : CUC version no longer used in Monarch
		patientVestDeviceRawLogTitan.setCucVersion(ParserUtilTitan.getDevVerString(rawMessageTitan));

		patientVestDeviceRawLogTitan.setDeviceData(ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_DATA));

		patientVestDeviceRawLogTitan.setDeviceModelType(ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_MODEL));
		patientVestDeviceRawLogTitan.setDeviceSerialNumber(ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_SN));
		patientVestDeviceRawLogTitan.setDeviceType(Constants.TITAN);

		patientVestDeviceRawLogTitan.setTotalFragments(ParserUtilTitan.getFragTotal(rawMessageTitan)+"");
		patientVestDeviceRawLogTitan.setCurrentFragment(ParserUtilTitan.getFragCurrent(rawMessageTitan)+"");
		patientVestDeviceRawLogTitan.setChecksum(ParserUtilTitan.getCRCChecksum(rawMessageTitan)+"");
		patientVestDeviceRawLogTitan.setDeviceAddress(ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_WIFI).equals("") ?
				ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_BT) : 
					ParserUtilTitan.getValueFromQclJsonDataTitan(qclJsonDataTitan,DEVICE_WIFI) );
		
		log.debug("patientVestDeviceRawLogTitan :" + patientVestDeviceRawLogTitan);

		return patientVestDeviceRawLogTitan;
	}

	@Override
	public List<PatientVestDeviceDataTitan> parseBase64StringToPatientTitanDeviceLogEntry(String base64String, Long rawLogId)
			throws Exception {
		
		log.debug("base64String :" + base64String);
		
		List<CorruptedTitanDeviceDataEvents> corruptedTitanDeviceDataEventsList = new ArrayList<CorruptedTitanDeviceDataEvents>();
		List <PatientVestDeviceDataTitan> titanDeviceData = new LinkedList<>();

		String decodedString = decodeData(base64String);
		JSONObject jsonDataTitan = ParserUtil.getChargerJsonDataFromRawMessage(decodedString);
		log.info("jsonDataTitan :" + jsonDataTitan);

		String deviceData = "";
		deviceData = ParserUtilTitan.getValueFromQclJsonDataTitan(jsonDataTitan,DEVICE_DATA);
		log.info("Device Data :" + deviceData);

		int fragTotal = ParserUtilTitan.getFragTotal(base64String);
		int fragCurr = ParserUtilTitan.getFragCurrent(base64String);

		String devsnbt = ParserUtilTitan.getValueFromQclJsonDataTitan(jsonDataTitan,DEVICE_SN);

		String deviceSerNo = devsnbt;

		// Flag 1 for WIFI
		String wifiSerNo = ParserUtilTitan.getValueFromQclJsonDataTitan(jsonDataTitan,DEVICE_WIFI);

		String btSerNo = ParserUtilTitan.getValueFromQclJsonDataTitan(jsonDataTitan,DEVICE_BT);

		String deviceVer = ParserUtilTitan.getDevVerString(base64String);

		if(Objects.nonNull(injectPingPongData(deviceData, deviceSerNo, wifiSerNo, btSerNo))){
			return titanDeviceData;
		}

		String[] deviceDataArray = deviceData.split("__");
		String startDateTime= "";
		double hmrSeconds = 0;

		for(String data : deviceDataArray) {
			if(data.contains(STDT)) {

				String dateString = data.split("\\[")[0];
				startDateTime = dateString.split("=")[1];
				log.info("startDateTime :" + startDateTime);
			}

			if(data.contains(SUMMARY)) {
				String [] combinedHmr = data.split("_");
				hmrSeconds = Double.parseDouble(combinedHmr[6]);
				log.info("hmrSeconds :" + hmrSeconds);
			}
		}

		for (String dataEvent : deviceDataArray) {
			if(dataEvent.contains(STDT)) {
				String [] eventDataArray = dataEvent.split(Pattern.quote("["));
				log.info("eventDataArray :" + Arrays.toString(eventDataArray));
				for(int i=1 ;i<eventDataArray.length;i++ ) {
					String eventCode = eventDataArray[i].split(",")[0];
					String elapseTime = eventDataArray[i].split(",")[1];
					String intensityVal = eventDataArray[i].split(",")[3];
					String freqValue = eventDataArray[i].split(",")[4];
					String durationVal = StringUtils.chop(eventDataArray[i].split(",")[5]);

					boolean eventStatusFlag = getValidEventData(eventCode,durationVal,intensityVal,freqValue);

					if(eventStatusFlag && !eventCode.equals("13")) {

						PatientVestDeviceDataTitan titanDeviceDataVal = new PatientVestDeviceDataTitan();
						PatientVestDeviceDataTitanPK patientVestDeviceDataTitanPK = new PatientVestDeviceDataTitanPK();

						titanDeviceDataVal.setPatientVestDeviceDataTitanPK(patientVestDeviceDataTitanPK);

						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
						Date startDate = sdf.parse(startDateTime);
						Calendar cal = Calendar.getInstance();
						cal.setTime(startDate);
						cal.add(Calendar.SECOND, Integer.parseInt(elapseTime));
						long tsTime2 = cal.getTime().getTime();

						titanDeviceDataVal.setTimestamp(tsTime2);
						// TO BE ELIMINATED : Not used in monarch todo : hardcoded for temporary
						titanDeviceDataVal.setSequenceNumber(1);
						titanDeviceDataVal.setEventCode(eventCode);
						titanDeviceDataVal.setSerialNumber(deviceSerNo);
						titanDeviceDataVal.setHmr(hmrSeconds);

						titanDeviceDataVal.setFrequency(Integer.parseInt(freqValue));
						titanDeviceDataVal.setIntensity(Integer.parseInt(intensityVal));
						titanDeviceDataVal.setDuration(Integer.parseInt(durationVal));

						// TO BE ELIMINATED : Bluetooth Id needs to be deleted from Monarch table. which is not applicable in Monarch
						titanDeviceDataVal.setBluetoothId(Objects.nonNull(wifiSerNo) ? wifiSerNo : 
							(Objects.nonNull(btSerNo) ? btSerNo : "Dummy_bluetooth_id"));

						titanDeviceDataVal.setFragTotal(fragTotal);			
						titanDeviceDataVal.setFragCurrent(fragCurr);

						titanDeviceDataVal.setTherapyIndex(1);	        
						titanDeviceDataVal.setNumberOfEvents(eventDataArray.length -1);

						if(Objects.nonNull(wifiSerNo))
							titanDeviceDataVal.setDevWifi(wifiSerNo);
						else 
							titanDeviceDataVal.setDevBt(btSerNo);	

						titanDeviceDataVal.setDevVersion(deviceVer);

						titanDeviceData.add(titanDeviceDataVal);
					}
					/*else {
						CorruptedTitanDeviceDataEvents corruptedTitanEvents  = new CorruptedTitanDeviceDataEvents();
						corruptedTitanEvents = invalidData(deviceSerNo,startDateTime,rawLogId);
						corruptedTitanDeviceDataEventsList.add(corruptedTitanEvents);

					}*/
				}
			}
		}

		log.info("titanDeviceData :" + titanDeviceData);

		//titanDataService.invalidDataRequestTitan(corruptedTitanDeviceDataEventsList);
		return titanDeviceData;
	}

	public CorruptedTitanDeviceDataEvents invalidData(String deviceSerialNumber,String createdDateTime,Long rawLogId) {
		
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
		DateTime createdDate = formatter.parseDateTime(createdDateTime);
		
		CorruptedTitanDeviceDataEvents corruptedTitanEvents  = new CorruptedTitanDeviceDataEvents();
		corruptedTitanEvents.setRawLogDate(createdDate.toDateTime());
		corruptedTitanEvents.setSerialNumber(deviceSerialNumber);
		corruptedTitanEvents.setDeviceRawLogId(rawLogId);
		
	 return corruptedTitanEvents;
				
	}

	private String injectPingPongData(String deviceData,String slNo,String wifiSerNo,String btSerNo) {		
		try{
			if(deviceData.equals("PING_PONG_PING")) {
				log.debug("deviceData is PING_PONG_PING" + " Insert into PING_PONG_PING table");
				PingPongPing pingPongPingData = new PingPongPing();
				pingPongPingData.setCreatedTime(new DateTime());				
				if(Objects.isNull(btSerNo)){
					pingPongPingData.setDevWifi(wifiSerNo);	
				}else if(Objects.isNull(wifiSerNo)){
					pingPongPingData.setDevBt(btSerNo);
				} 
				pingPongPingData.setSerialNumber(slNo);
				pingpongpingrepository.save(pingPongPingData);
				return "OK";
			}
		}catch(Exception e){
			e.printStackTrace();			
		}	
		return null;
	}
	
	private Boolean getValidEventData(String eventCode,String duration,String intensity,String frequency) {
		Boolean eventFlag = true;
		if(!eventCode.equals("13")) {
			if( (Integer.parseInt(frequency)) >= MIN_FREQUENCY && (Integer.parseInt(frequency)) <= MAX_FREQUENCY) {
				if((Integer.parseInt(intensity)) >= MIN_INTESITY && (Integer.parseInt(intensity)) <= MAX_INTESITY) {
					if((Integer.parseInt(duration)) >= MIN_DURATION && (Integer.parseInt(duration)) <= MAX_DURATION) {
						eventFlag = true;
					} else {
						eventFlag = false;
					}
				}else {
					eventFlag = false;
				}
			} else {
				eventFlag = false;
			}
		}
		return eventFlag;
	}
}
