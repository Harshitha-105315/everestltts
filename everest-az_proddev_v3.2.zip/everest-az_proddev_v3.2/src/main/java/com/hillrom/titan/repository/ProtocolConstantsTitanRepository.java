package com.hillrom.titan.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsTitan;

public interface ProtocolConstantsTitanRepository extends
		JpaRepository<ProtocolConstantsTitan, Long> {

}
