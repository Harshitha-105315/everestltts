package com.hillrom.titan.dto;

import java.util.Map;

public class TherapySettingDTO {
	String requestId;
	String result;
	String recordId;
	//TherapyTypeDTO therapyType;
	Map<String,TherapyTypeDTO> theraptData;
	String crc;
	String devSN;
	String therapySetting;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	
	public Map<String, TherapyTypeDTO> getTheraptData() {
		return theraptData;
	}
	public void setTheraptData(Map<String, TherapyTypeDTO> theraptData) {
		this.theraptData = theraptData;
	}
	public String getCrc() {
		return crc;
	}
	public void setCrc(String crc) {
		this.crc = crc;
	}
	public String getDevSN() {
		return devSN;
	}
	public void setDevSN(String devSN) {
		this.devSN = devSN;
	}
	public String getTherapySetting() {
		return therapySetting;
	}
	public void setTherapySetting(String therapySetting) {
		this.therapySetting = therapySetting;
	}
	@Override
	public String toString() {
		return "TherapySettingDTO [requestId=" + requestId + ", result=" + result + ", recordId=" + recordId
				+ ", theraptData=" + theraptData + ", crc=" + crc + ", devSN=" + devSN + ", therapySetting="
				+ therapySetting + "]";
	}
	

}
