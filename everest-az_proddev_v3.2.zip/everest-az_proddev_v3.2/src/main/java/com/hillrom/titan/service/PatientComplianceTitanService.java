package com.hillrom.titan.service;



import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.audit.service.PatientProtocolDataAuditMonarchService;
import com.hillrom.titan.repository.PatientComplianceTitanRepository;
import com.hillrom.titan.repository.PatientNoEventsTitanRepository;
import com.hillrom.titan.web.rest.dto.AdherenceTrendTitanVO;
import com.hillrom.titan.web.rest.dto.ProtocolRevisionTitanVO;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.exceptionhandler.HillromException;

@Service
@Transactional
public class PatientComplianceTitanService {

	@Inject
	private PatientComplianceTitanRepository complianceTitanRepository;
	
	@Inject
	@Qualifier("patientProtocolDataAuditMonarchService")
	private PatientProtocolDataAuditMonarchService protocolAuditMonarchService;
	
	
	@Inject
	private PatientNoEventsTitanRepository patientNoEventsTitanRepository;
	
	
	
	public PatientComplianceTitan findLatestComplianceByPatientUserId(Long patientUserId){
		return complianceTitanRepository.findTop1ByPatientUserIdOrderByDateDesc(patientUserId);
	}
	
	/**
	 * Creates Or Updates Compliance 
	 * @param compliance
	 * @return
	 */
	public PatientComplianceTitan createOrUpdate(PatientComplianceTitan compliance){
		LocalDate date = compliance.getDate();
		Long patientUserId = compliance.getPatientUser().getId();
		PatientComplianceTitan existingCompliance = complianceTitanRepository.findByPatientUserIdAndDate(patientUserId, date);
		if(Objects.nonNull(existingCompliance)){
			existingCompliance.setScore(compliance.getScore());
			existingCompliance.setHmrRunRate(compliance.getHmrRunRate());
			existingCompliance.setMissedTherapyCount(compliance.getMissedTherapyCount());
			existingCompliance.setSettingsDeviatedDaysCount(compliance.getSettingsDeviatedDaysCount());
			compliance = complianceTitanRepository.save(existingCompliance);
		}else{
			complianceTitanRepository.save(compliance);
		}
		return compliance;
	}
	public SortedMap<LocalDate,PatientComplianceTitan> getPatientComplainceMapByPatientUserId(Long patientUserId){
		List<PatientComplianceTitan> complianceList = complianceTitanRepository.findByPatientUserId(patientUserId);
		SortedMap<LocalDate,PatientComplianceTitan> existingComplainceMap = new TreeMap<>(); 
		for(PatientComplianceTitan compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}
	public void saveAll(Collection<PatientComplianceTitan> complainces){
		complianceTitanRepository.save(complainces);
	}
	

	public List<ProtocolRevisionTitanVO> findAdherenceTrendByUserIdAndDateRange(Long patientUserId,LocalDate from,LocalDate to)
	throws HillromException{
		List<Long> patientUserIds = new LinkedList<>();
		patientUserIds.add(patientUserId);
		LocalDate toDate = to;
		LocalDate fromDate = from.minusDays(1);
		/*if(Objects.isNull(therapySession)){
			toDate = to.minusDays(1);
		} else if(!to.equals(therapySession.getDate()) && !from.equals(to)){
			toDate = to.minusDays(1);
		}*/
		
		// Starts GIMP 11
		PatientNoEventTitan patientNoEvent = patientNoEventsTitanRepository
				.findByPatientUserId(patientUserId);

		if (Objects.nonNull(patientNoEvent) && Objects.nonNull(fromDate) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate())) {
			if (patientNoEvent.getFirstTransmissionDate().isAfter(fromDate)) {
				fromDate = patientNoEvent.getFirstTransmissionDate();
			}
		}
		
		
		// Ends GIMP 11
		List<PatientComplianceTitan> complianceList = complianceTitanRepository.findByDateBetweenAndPatientUserIdIn(fromDate, toDate, patientUserIds);
		if(complianceList.isEmpty()){
			throw new HillromException("No Data Available");
		}
		SortedMap<LocalDate,PatientComplianceTitan> complianceMap = new TreeMap<>();
		for(PatientComplianceTitan compliance : complianceList){
			complianceMap.put(compliance.getDate(), compliance);
		}
			
		SortedMap<LocalDate,PatientComplianceTitan> actualMapRequested = complianceMap.tailMap(from);
		
		PatientComplianceTitan lastCompliance = actualMapRequested.get(actualMapRequested.lastKey());
		SortedMap<DateTime,ProtocolRevisionTitanVO> revisionData = new TreeMap<>();
		// if no revisions found,create a dummy revision with isValid = false
		if(revisionData.isEmpty()){
			ProtocolRevisionTitanVO revisionVO = new ProtocolRevisionTitanVO(lastCompliance.getPatientUser().getCreatedDate(),null);
			revisionData.put(lastCompliance.getPatientUser().getCreatedDate().minusSeconds(1), revisionVO);
		}else{
			ProtocolRevisionTitanVO revisionVO = new ProtocolRevisionTitanVO(lastCompliance.getPatientUser().getCreatedDate(),revisionData.firstKey());
			revisionData.put(lastCompliance.getPatientUser().getCreatedDate().minusSeconds(1), revisionVO);
		}

		for(LocalDate date: actualMapRequested.keySet()){
			AdherenceTrendTitanVO trendVO = new AdherenceTrendTitanVO();
			PatientComplianceTitan compliance = complianceMap.get(date);
			trendVO.setDate(date);
			trendVO.setUpdatedScore(compliance.getScore());
			ProtocolRevisionTitanVO revisionVO = getProtocolRevisionByCompliance(
					revisionData, compliance);
			revisionVO.addAdherenceTrend(trendVO);
		}
		List<ProtocolRevisionTitanVO> revisions = revisionData.values().stream().filter(rev -> rev.getAdherenceTrends().size() > 0).collect(Collectors.toList());		
		return revisions;
	}
	
	private ProtocolRevisionTitanVO getProtocolRevisionByCompliance(
			SortedMap<DateTime, ProtocolRevisionTitanVO> revisionData,
			PatientComplianceTitan compliance) {
		DateTime processedTime = Objects.nonNull(compliance.getLastModifiedDate()) ? compliance.getLastModifiedDate() : compliance.getDate().toDateTimeAtStartOfDay().plusHours(23).plusMinutes(59);
		// Get the recent protocol revisions before the processed time of compliance
		SortedMap<DateTime,ProtocolRevisionTitanVO> recentRevisionMap = revisionData.headMap(processedTime);
		ProtocolRevisionTitanVO revisionVO = null;
		// if there is revision use the revision else use the default revision
		if(Objects.nonNull(recentRevisionMap) && recentRevisionMap.size() > 0){
			revisionVO = recentRevisionMap.get(recentRevisionMap.lastKey());
		}else{
			revisionVO = revisionData.get(revisionData.firstKey());
		}
		return revisionVO;
	}
	
}
