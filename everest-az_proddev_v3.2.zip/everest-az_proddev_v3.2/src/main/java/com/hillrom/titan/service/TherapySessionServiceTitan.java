package com.hillrom.titan.service;


import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateWeightedAvg;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.titan.web.rest.dto.TherapyDataTitanVO;
import com.hillrom.vest.domain.NoteTitan;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.service.AdherenceCalculationService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.GraphUtils;
import com.hillrom.vest.web.rest.dto.TreatmentStatisticsVO;

@Service
@Transactional
public class TherapySessionServiceTitan {
	@Inject
	private EntityManager entityManager;

	@Inject
	TherapySessionTitanRepository therapySessionTitanRepository;

	@Inject
	@Lazy
	private AdherenceCalculationService adherenceCalculationService;

	@Inject
	PatientNoEventTitanService patientNoEventTitanService;

	private final static Logger log = LoggerFactory.getLogger(TherapySessionServiceTitan.class);

	/*public void removeExistingTherapySessions(
			List<TherapySessionMonarch> therapySessions, User patientUser) {
		TherapySession latestTherapySession =  therapySessionRepository.findTop1ByPatientUserIdOrderByEndTimeDesc(patientUser.getId());
		// Removing existing therapySessions from DB
		if(Objects.nonNull(latestTherapySession)){
			Iterator<TherapySessionMonarch> tpsIterator = therapySessions.iterator();
			while(tpsIterator.hasNext()){
				TherapySessionMonarch tps = tpsIterator.next();
				// Remove previous therapy Sessions
				if(tps.getDate().isBefore(latestTherapySession.getDate())){
					tpsIterator.remove();
					//Remove previous therapySessions of the same day.
				} else {
					DateTime tpsStartTime = tps.getStartTime();
					DateTime latestTpsEndTimeFromDB = latestTherapySession.getEndTime();
					if(tps.getDate().equals(latestTherapySession.getDate()) && tpsStartTime.isBefore(latestTpsEndTimeFromDB)){
						tpsIterator.remove();
					}
				}
			}
		}
	}*/

	public List<TherapyDataTitanVO> findByPatientUserIdAndDateRange(Long patientUserId,LocalDate from,LocalDate to){
		List<TherapySessionTitan> sessions = therapySessionTitanRepository
				.findByPatientUserIdAndDateRange(patientUserId,from,to);
		log.debug("findByPatientUserIdAndDateRange sessions : "+sessions);
		Map<LocalDate,List<TherapySessionTitan>> tpsGroupByDate = groupTherapySessionsByDate(sessions);
		log.debug("findByPatientUserIdAndDateRange tpsGroupByDate : "+tpsGroupByDate);

		return formatResponse(tpsGroupByDate, null, patientUserId, from, to);
	}

	public SortedMap<LocalDate,List<TherapySessionTitan>> groupTherapySessionsByDate(List<TherapySessionTitan> sessions){
		return new TreeMap<>(sessions.stream().collect(Collectors.groupingBy(TherapySessionTitan :: getDate)));
	}

	public List<TherapySessionTitan> findByPatientUserIdAndDate(Long id,LocalDate date){
		return  therapySessionTitanRepository.findByPatientUserIdAndDate(id,date);
	}	

	public Map<Long,List<TherapySessionTitan>> getTherapySessionsGroupByPatientUserId(List<Long> patientUserIds){
		List<TherapySessionTitan> therapySessions = therapySessionTitanRepository.findTop1ByPatientUserIdInOrderByEndTimeDesc(patientUserIds);
		return therapySessions.stream().collect(Collectors.groupingBy(TherapySessionTitan::getTherapySessionByPatientUserId));
	}

	public Collection<TreatmentStatisticsVO> getTreatmentStatisticsByPatientUserIdsAndDuration(
			List<Long> patientUserIds,
			LocalDate from,LocalDate to) {
		List<TherapySessionTitan> therapySessions = therapySessionTitanRepository.findByDateBetweenAndPatientUserIdIn(from, to, patientUserIds);
		Map<LocalDate,List<TherapySessionTitan>> tpsGroupedByDate = therapySessions.stream().collect(Collectors.groupingBy(TherapySessionTitan :: getDate));
			return getAvgTreatmentStatisticsForTherapiesGroupedByDate(patientUserIds, tpsGroupedByDate);
	}

	public LinkedList<TreatmentStatisticsVO> getAvgTreatmentStatisticsForTherapiesGroupedByDate(List<Long> patientUserIds,
			Map<LocalDate, List<TherapySessionTitan>> tpsGroupedByDate) {
		Map<LocalDate, TreatmentStatisticsVO> statisticsMap = new TreeMap<>();
		TreatmentStatisticsVO statisticsVO;
		for(LocalDate date : tpsGroupedByDate.keySet()){
			List<TherapySessionTitan> tpsOnDate = tpsGroupedByDate.get(date);
			statisticsVO = calculateAvgTreatmentStatistics(patientUserIds,
						tpsOnDate);
			statisticsMap.put(date, statisticsVO);
		}
		return new LinkedList<>(statisticsMap.values());
	}

	public TreatmentStatisticsVO calculateAvgTreatmentStatistics(
			List<Long> patientUserIds, List<TherapySessionTitan> tpsInDuration) {
		TreatmentStatisticsVO statisticsVO;
		int avgTreatment = tpsInDuration.size()/patientUserIds.size();
		int avgDuration = tpsInDuration
				.stream()
				.collect(
						Collectors
								.summingInt(TherapySessionTitan::getDurationInMinutes))
				/ patientUserIds.size();
		DateTime startTime = tpsInDuration.get(0).getStartTime();
		DateTime endTime = tpsInDuration.get(tpsInDuration.size()-1).getEndTime();
		statisticsVO = new TreatmentStatisticsVO(avgTreatment,avgDuration,startTime,endTime);
		return statisticsVO;
	}

	/**
	 * prepare dummy therapy data for the week
	 * @param from
	 * @param to
	 * @param dummyData
	 */
	private List<TherapyDataTitanVO> prepareTherapySessionsAddMissedTherapyData(Long patientUserId,
			LocalDate from, LocalDate to,
			Map<LocalDate, List<TherapyDataTitanVO>> therapySessionMap,
			Map<LocalDate,NoteTitan> noteMap,
			TherapySessionTitan latestTherapySession) {
		int minutes = 60*60;
		// Get the latest HMR for the user before the requested duration
		double hmrInHours = Objects.nonNull(latestTherapySession)?latestTherapySession.getHmr()/minutes:0d;
		log.debug("prepareTherapySessionsAddMissedTherapyData hmrInHours : "+hmrInHours);
		
		// This is to discard the records if the user requested data beyond his/her first transmission date.
		PatientNoEventTitan patientNoEvent = patientNoEventTitanService.findByPatientUserId(patientUserId);
		/*if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate()))
			from = from.isAfter(patientNoEvent.getFirstTransmissionDate()) ? from : patientNoEvent.getFirstTransmissionDate();*/
		//Start GIMP 11
		if(Objects.nonNull(patientNoEvent)){
			LocalDate firstTransmissionDateByType = GraphUtils.getFirstTransmissionDateTitanByType(patientNoEvent);
			if(Objects.nonNull(firstTransmissionDateByType)){
				from = from.isAfter(patientNoEvent.getFirstTransmissionDate()) ? from : firstTransmissionDateByType;
			}
		}
		//End GIMP 11

		// Prepare the list of dates to which data has to be shown
		List<LocalDate> dates = DateUtil.getAllLocalDatesBetweenDates(from, to);
		log.debug("prepareTherapySessionsAddMissedTherapyData dates : "+dates);

		List<TherapyDataTitanVO> processedTherapies = new LinkedList<>();
		for(LocalDate date : dates){
			// insert therapy done by user
			if(Objects.nonNull(therapySessionMap.get(date))){
				List<TherapyDataTitanVO> therapySessions = therapySessionMap.get(date);
				therapySessions.forEach(therapy -> {
					processedTherapies.add(therapy);
				});
				// updating HMR from previous day to form step graph
				hmrInHours = therapySessions.get(therapySessions.size()-1).getHmr();
				
			}else if(date.isBefore(LocalDate.now())){ // Don't consider current date as missed therapy
				// add missed therapy if user misses the therapy
				TherapyDataTitanVO missedTherapy = createTherapyDataWithTimeStamp(date);
				missedTherapy.setHmr(hmrInHours);
				processedTherapies.add(missedTherapy);
			}
		}
		// Sort based on timestamp
		Collections.sort(processedTherapies);
		log.debug("prepareTherapySessionsAddMissedTherapyData processedTherapies : "+processedTherapies);

		return processedTherapies;
	}

	/**
	 * create Dummy therapy data object for missing therapy
	 * @param from
	 * @return
	 */
	private TherapyDataTitanVO createTherapyDataWithTimeStamp(LocalDate from) {
			TherapyDataTitanVO therapy = new TherapyDataTitanVO();
			therapy.setMissedTherapy(true);
			therapy.setTimestamp(from.toDateTimeAtCurrentTime());
			return therapy; 
	}

	private List<TherapyDataTitanVO> formatResponse(Map<LocalDate,List<TherapySessionTitan>> sessionMap,
			Map<LocalDate, NoteTitan> noteMap,Long patientUserId,LocalDate from,LocalDate to){
		TherapySessionTitan latestTherapySession = therapySessionTitanRepository.findTop1ByPatientUserIdAndDateBeforeOrderByEndTimeDesc(patientUserId,from);
		log.debug("formatResponse latestTherapySession : "+latestTherapySession);
		log.debug("formatResponse sessionMap : "+sessionMap);
		
		Map<LocalDate, List<TherapyDataTitanVO>> therapyDataMap = assignNotesToTherapySession(sessionMap);
		log.debug("formatResponse from : "+from + " to :"+to);
		if(sessionMap.isEmpty()){
			if(Objects.nonNull(latestTherapySession)){
				return prepareTherapySessionsAddMissedTherapyData(patientUserId,from, to, therapyDataMap,noteMap,latestTherapySession);
			}else{
				return new ArrayList<>();
			}
		}else {
			return prepareTherapySessionsAddMissedTherapyData(patientUserId,from, to, therapyDataMap,noteMap,latestTherapySession);
		}
	}

	private Map<LocalDate, List<TherapyDataTitanVO>> assignNotesToTherapySession(
			Map<LocalDate, List<TherapySessionTitan>> sessionMap) {
		Map<LocalDate,List<TherapyDataTitanVO>> therapyDataMap = new TreeMap<>();
		TherapyDataTitanVO therapyDataVO = null;
		int minutes = 60*60;
		for(LocalDate date : sessionMap.keySet()){
			List<TherapySessionTitan> sessionsPerDate = sessionMap.get(date);
			List<TherapyDataTitanVO> therapyDataVOs = therapyDataMap.get(date);
			if(Objects.isNull(therapyDataVOs))
				therapyDataVOs = new LinkedList<>();
			for(TherapySessionTitan session: sessionsPerDate){
				List <Integer> errorList = new LinkedList<>();
				List <Integer> bluetoothSource = new LinkedList<>();
				List <String> powerConnectStatus = new LinkedList<>();
				therapyDataVO = new TherapyDataTitanVO(session.getStartTime(), sessionsPerDate.size(),session.getSessionNo(), 
						session.getFrequency(),	session.getIntensity(), 0, null, session.getStartTime(),
						session.getEndTime(), session.getCaughPauseDuration(),
						session.getDurationInMinutes(), session.getHmr().doubleValue()/minutes,false,errorList,bluetoothSource,powerConnectStatus);
				therapyDataVOs.add(therapyDataVO);
			}
			therapyDataMap.put(date, therapyDataVOs);
		}
		log.debug("assignNotesToTherapySession therapyDataMap : "+therapyDataMap);
		return therapyDataMap;
	} 

	public SortedMap<LocalDate,List<TherapySessionTitan>> getAllTherapySessionsMapByPatientUserId(Long patientUserId){
		List<TherapySessionTitan> therapySessions =  therapySessionTitanRepository.findByPatientUserId(patientUserId);
		return groupTherapySessionsByDate(therapySessions);
	}



	public void saveAll(Collection<TherapySessionTitan> therapySessionTitan){
		therapySessionTitanRepository.save(therapySessionTitan);
	}

	public Long getLatestEndTime(String patient_id) {
		return DateTime.now().getMillis();	
	}

	public Map<LocalDate, List<Integer>> getTherapyDurationAndTreatmentsByDate(String patientId, LocalDate startDate, LocalDate endDate, String timeZone){
		Map<LocalDate, List<Integer>> result = null;
		String finalQuery = "SELECT date(convert_tz(pvtd.start_time, '-00:00', ':TIMEZONE')), duration_in_minutes FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtd WHERE pvtd.patient_id = ':PATIENTID' AND pvtd.duration_in_minutes > 0 AND convert_tz(pvtd.start_time, '-00:00', ':TIMEZONE') >= from_unixtime(:FROM) AND convert_tz(pvtd.end_time, '-00:00', ':TIMEZONE') <= from_unixtime(:TO)";
		finalQuery = finalQuery.replace(":PATIENTID", patientId);
		if(Objects.nonNull(timeZone)) {
			finalQuery = finalQuery.replace(":TIMEZONE", timeZone);
		}else {
			finalQuery = finalQuery.replace(":TIMEZONE", "+00:00");			
		}
		finalQuery = finalQuery.replace(":FROM", Long.toString(startDate.toDateTimeAtStartOfDay().getMillis()/1000));
		finalQuery = finalQuery.replace(":TO", Long.toString(endDate.toDateTimeAtStartOfDay().getMillis()/1000));
		Query query = entityManager.createNativeQuery(finalQuery);
		@SuppressWarnings("unchecked")
		List<Object[]> results = query.getResultList();
		for(Object[] record: results) {

			if(Objects.isNull(result)) {
				result = new HashMap<LocalDate, List<Integer>>();
			}

			LocalDate date = new LocalDate(record[0]);

			List<Integer> sessions = result.get(date);
			if(Objects.isNull(sessions)) {
				sessions = new ArrayList<Integer>();
			}
			sessions.add(((BigInteger)record[1]).intValue());

			result.put(date, sessions);
		}

		return result;
	}
	
	public List<TherapyDataTitanVO> getComplianceGraphData(Long patientUserId,LocalDate from,LocalDate to){
		List<TherapyDataTitanVO> therapyData = findByPatientUserIdAndDateRange(patientUserId, from, to);
		Map<LocalDate,List<TherapyDataTitanVO>> therapyDataMap = therapyData.stream().collect(Collectors.groupingBy(TherapyDataTitanVO::getDate));
		SortedMap<LocalDate,List<TherapyDataTitanVO>> therapyDataGroupByDate = new TreeMap<>(therapyDataMap);
		List<TherapyDataTitanVO> responseList = new LinkedList<>();
		for(LocalDate date : therapyDataGroupByDate.keySet()){
			List<TherapyDataTitanVO> therapies = therapyDataGroupByDate.get(date);
			int totalDuration = therapies.stream().collect(Collectors.summingInt(TherapyDataTitanVO::getDuration));
			int CoughPauses=0,coughPauseDuration=0;
			float weightedAvgFrequency = 0.0f,weightedAvgIntensity = 0.0f;
			NoteTitan noteForTheDay = null;
			int size = therapies.size();
			DateTime start = therapies.get(0).getStart();
			DateTime end = size > 0 ? therapies.get(size-1).getEnd(): null;
			double hmr = size > 0 ? therapies.get(size-1).getHmr(): 0;
			boolean isMissedTherapy = therapies.get(0).isMissedTherapy();
			for(TherapyDataTitanVO therapy : therapies){
				log.debug("therapydata-------------"+therapy.getCoughPauses());
				CoughPauses+=therapy.getCoughPauses();
				weightedAvgFrequency += calculateWeightedAvg(totalDuration, therapy.getDuration(), therapy.getFrequency());
				weightedAvgIntensity += calculateWeightedAvg(totalDuration, therapy.getDuration(), therapy.getIntensity());
				noteForTheDay = therapy.getNoteTitan();
			}
			int minutes = 60*60;
			TherapyDataTitanVO dataVO = new TherapyDataTitanVO(therapies.get(0).getTimestamp(), Math.round(weightedAvgFrequency), Math.round(weightedAvgIntensity),
					CoughPauses, noteForTheDay, start, end, coughPauseDuration,
					totalDuration, Math.round(hmr/minutes), isMissedTherapy);
			responseList.add(dataVO);
		}
		return responseList;
	}
}