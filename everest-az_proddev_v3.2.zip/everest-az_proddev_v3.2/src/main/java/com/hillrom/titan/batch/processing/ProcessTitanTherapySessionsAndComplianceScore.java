package com.hillrom.titan.batch.processing;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hillrom.titan.service.TitanDataService;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;

@Configuration
@EnableBatchProcessing
public class ProcessTitanTherapySessionsAndComplianceScore {
	
	private final Logger log = LoggerFactory.getLogger(TitanDataService.class);

	@Autowired
	private JobBuilderFactory jobBuildersTitan;
 
	@Autowired
	private StepBuilderFactory stepBuildersTitan;
	
	
	@Bean
	public Job processTitanTherapySessionsAndCompliance(){		
		log.debug("processTitanTherapySessionsAndCompliance started");

		return jobBuildersTitan.get("ProcessTitanTherapySessionsAndComplianceScore")
				.start(getPatientTitanDeviceDataDelta())
				.build();
	}
	
	@Bean
	public Step getPatientTitanDeviceDataDelta(){
		log.debug("getPatientTitanDeviceDataDelta started");

		return stepBuildersTitan.get("getPatientTitanDeviceDataDelta")
				.<List<PatientVestDeviceDataTitan>,List<PatientVestDeviceDataTitan>>chunk(2048)
				.reader(patientTitanDeviceDataReader())
				.listener(getCustomItemReaderListenerTitan())
				.writer(patientTitanDeviceDataWriter())
				.build();
	}	
	
	@Bean
	@StepScope
	public ItemReader<List<PatientVestDeviceDataTitan>> patientTitanDeviceDataReader(){
		log.debug("patientTitanDeviceDataReader started");

		return new PatientTitanDeviceDataReader();
	}
	
	@Bean
    public ItemWriter<List<PatientVestDeviceDataTitan>> patientTitanDeviceDataWriter() {
		log.debug("patientTitanDeviceDataWriter started");

    	return new PatientTitanDeviceDataWriter();
    }
	
	@Bean
	@StepScope
    public CustomItemReaderListenerTitan getCustomItemReaderListenerTitan() {
		log.debug("getCustomItemReaderListenerTitan started");

    	return new CustomItemReaderListenerTitan();
	}
	
}
