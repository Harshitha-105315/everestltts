package com.hillrom.titan.dto;

public class TherapyTypeDTO {
	String therapyName;
	int thearpyParamCount;
	String therapyParam;
	String therapyCoughPause;
	
	public String getTherapyName() {
		return therapyName;
	}
	public void setTherapyName(String therapyName) {
		this.therapyName = therapyName;
	}
	public int getThearpyParamCount() {
		return thearpyParamCount;
	}
	public void setThearpyParamCount(int thearpyParamCount) {
		this.thearpyParamCount = thearpyParamCount;
	}
	public String getTherapyParam() {
		return therapyParam;
	}
	public void setTherapyParam(String therapyParam) {
		this.therapyParam = therapyParam;
	}
	public String getTherapyCoughPause() {
		return therapyCoughPause;
	}
	public void setTherapyCoughPause(String therapyCoughPause) {
		this.therapyCoughPause = therapyCoughPause;
	}
	
	@Override
	public String toString() {
		return "TherapyTypeDTO [therapyName=" + therapyName + ", thearpyParamCount=" + thearpyParamCount
				+ ", therapyParam=" + therapyParam + ", therapyCoughPause=" + therapyCoughPause + "]";
	}
	
	
	
	

}
