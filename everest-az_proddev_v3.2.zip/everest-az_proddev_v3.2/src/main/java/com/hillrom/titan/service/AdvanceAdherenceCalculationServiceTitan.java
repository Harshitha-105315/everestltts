package com.hillrom.titan.service;


import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;
import static com.hillrom.vest.config.AdherenceScoreConstants.HMR_NON_COMPLIANCE_POINTS;
import static com.hillrom.vest.config.AdherenceScoreConstants.LOWER_BOUND_VALUE;
import static com.hillrom.vest.config.AdherenceScoreConstants.MISSED_THERAPY_DAYS_COUNT_THRESHOLD;
import static com.hillrom.vest.config.NotificationTypeConstants.ADHERENCE_SCORE_RESET;
import static com.hillrom.vest.config.NotificationTypeConstants.HMR_NON_COMPLIANCE;
import static com.hillrom.vest.config.NotificationTypeConstants.MISSED_THERAPY;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hillrom.monarch.repository.PatientNoEventsMonarchRepository;
import com.hillrom.monarch.service.AdvanceAdherenceCalculationServiceMonarch;
import com.hillrom.titan.repository.AdherenceResetTitanRepository;
import com.hillrom.titan.repository.PatientComplianceTitanRepository;
import com.hillrom.titan.repository.PatientNoEventsTitanRepository;
import com.hillrom.titan.repository.PatientProtocolTitanRepository;
import com.hillrom.titan.repository.ProtocolConstantsTitanRepository;
import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.AdherenceResetTitan;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientNoEvent;
import com.hillrom.vest.domain.PatientNoEventMonarch;
import com.hillrom.vest.domain.PatientNoEventTitan;
import com.hillrom.vest.domain.PatientProtocolDataTitan;
import com.hillrom.vest.domain.ProtocolConstants;
import com.hillrom.vest.domain.ProtocolConstantsMonarch;
import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.repository.PatientComplianceRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientNoEventsRepository;
import com.hillrom.vest.service.AdvanceAdherenceCalculationService;
import com.hillrom.vest.service.MissTherapySettingDeviationNotifier;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;


@Service
@Transactional
public class AdvanceAdherenceCalculationServiceTitan {

	@Inject 
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject 
	private TherapySessionTitanRepository therapySessionTitanRepository;

	@Inject 
	private PatientComplianceTitanRepository complianceTitanRepository;
	
	@Inject
	private NotificationTitanService notificationServiceTitan;

	@Inject
	private AdvanceAdherenceCalculationService advanceAdherenceCalculationService;

	@Inject
	private AdvanceAdherenceCalculationServiceMonarch advanceAdherenceCalculationServiceMonarch;

	@Inject
	private PatientNoEventsTitanRepository patientNoEventTitanRepository;
	
	@Inject
	private AdherenceResetTitanRepository adherenceResetTitanRepository;

	@Inject
	private PatientNoEventTitanService noEventTitanService;

	@Inject
	private PatientNoEventsRepository patientNoEventRepository;

	@Inject
	private PatientComplianceRepository complianceRepository;

	@Inject
	private ProtocolConstantsTitanRepository protocolConstantsTitanRepository;

	@Inject
	private PatientProtocolTitanRepository patientProtocolTitanRepository;

	@Inject
	private PatientProtocolTitanService patientProtocolTitanService;
	
	@Inject
	private MissTherapySettingDeviationNotifier missTherapySettingDeviationNotifier;
	
	@Inject
	@Lazy
	private TherapySessionServiceTitan therapySessionTitanService;
	
	@Inject
	private UserService userService;
	
	@Inject
	private PatientInfoRepository patientInfoRepository;
	
	

	@Inject
	private PatientNoEventsMonarchRepository patientNoEventMonarchRepository;

	private final static Logger log = LoggerFactory.getLogger(AdvanceAdherenceCalculationServiceTitan.class);

	
	public List<TherapySessionTitan> saveOrUpdate(List<TherapySessionTitan> therapySessions) throws Exception{
		log.debug("Inside saveOrUpdate method of AdvanceAdherenceCalculationServiceTitan : therapySessions :"+therapySessions);
		
		if(therapySessions.size() > 0){		
			LocalDate minTherapySessionDate = null;
			LocalDate maxTherapySessiondate = LocalDate.now();
			User patientUser = therapySessions.get(0).getPatientUser();
			PatientInfo patient = therapySessions.get(0).getPatientInfo();
			boolean resetFlag = false;
			LocalDate resetDate = null;
			Map<LocalDate, List<TherapySessionTitan>> groupedTherapySessions = therapySessions
					.stream()
					.collect(
							Collectors
							.groupingBy(TherapySessionTitan::getDate));

			SortedMap<LocalDate,List<TherapySessionTitan>> receivedTherapySessionMap = new TreeMap<>(groupedTherapySessions);
			minTherapySessionDate = receivedTherapySessionMap.firstKey();
			SortedMap<LocalDate,List<TherapySessionTitan>> existingTherapySessionMap = getAllTherapySessionsMapByPatientUserIdForTitanBetweenDates(
					minTherapySessionDate,maxTherapySessiondate,patientUser.getId());
			SortedMap<LocalDate,PatientComplianceTitan> existingComplianceMap = getPatientComplainceMapByPatientUserIdForTitanBetweenDates(
					minTherapySessionDate.minusDays(1),maxTherapySessiondate,patientUser.getId());
			String deviceType = advanceAdherenceCalculationService.getDeviceTypeValue(patient.getId());

			if(deviceType.equalsIgnoreCase("Titan")){
				log.debug("Going for processAdherenceScoreForTitan TITAN");
				processAdherenceScoreForTitan(receivedTherapySessionMap,existingTherapySessionMap,existingComplianceMap,patientUser,patient,resetFlag,resetDate);
			}else if(deviceType.equals("BOTH")){
				log.debug("Going for processAdherenceScoreForTitan BOTH");
				processAdherenceScoreForBoth(receivedTherapySessionMap,existingTherapySessionMap,existingComplianceMap,patientUser,patient,resetFlag,resetDate);
			}
			
			if(receivedTherapySessionMap.size() > 0) {
				receivedTherapySessionMap = convertTherapySessionToLocalDate(receivedTherapySessionMap);
				if(Objects.nonNull(receivedTherapySessionMap.get(LocalDate.now()))){
					missTherapySettingDeviationNotifier.pushNotificationForProtocolDeviationTitanSessions(receivedTherapySessionMap.get(LocalDate.now()), patient.getId());
				}
				receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMap);
			}
		}

		return therapySessions;
	}



	public void processAdherenceScoreForBoth(
			SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionTitan>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceTitan> existingComplianceMap, User patientUser,
			PatientInfo patient, boolean resetFlag, LocalDate resetDate) throws Exception {

		LocalDate firstTransmissionDate = null;
		boolean isHMRCompliant = true;
		int missedTherapyCount = 0;
		boolean missTherapy = true;
		LocalDate trainingDate  = null; 
		LocalDate latestComplianceDate;
		int totalCumulativeDuration = 0;
		LocalDate lastTransmissionDate = null;
		LocalDate minOfTherapySessions = null;

		PatientNoEvent patientNoEvent = patientNoEventRepository.findByPatientUserId(patientUser.getId());
		SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionMapTemp = convertTherapySessionToLocalDate(receivedTherapySessionMap);
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		PatientNoEventMonarch patientNoEventMonarch = patientNoEventMonarchRepository.findByPatientUserId(patientUser.getId());
		PatientNoEventTitan patientNoEventTitan = patientNoEventTitanRepository.findByPatientUserId(patientUser.getId());
		
		if(resetFlag) {
			minOfTherapySessions = resetDate;
			latestComplianceDate = LocalDate.now();
		} else{
			minOfTherapySessions = receivedTherapySessionMapTemp.firstKey();
		}

		
		LocalDate today = LocalDate.now();

		SortedMap<LocalDate,List<TherapySession>> existingTherapySessionMapVest = advanceAdherenceCalculationService.
				getAllTherapySessionsMapByPatientUserIdForVestBetweenDates(minOfTherapySessions, today, patientUser.getId());
		
		existingTherapySessionMapVest = advanceAdherenceCalculationService.convertTherapySessionToLocalDate(existingTherapySessionMapVest);

		SortedMap<LocalDate,PatientCompliance> existingComplianceVestMap = 
				getPatientComplainceMapByPatientUserIdForVestBetweenDates(minOfTherapySessions.minusDays(1),today,patientUser.getId());

		latestComplianceDate = LocalDate.now();
		if(!resetFlag) {
			if(Objects.nonNull(existingComplianceMap) && existingComplianceMap.size()>0){
				latestComplianceDate = existingComplianceMap.lastKey();
			}else if (Objects.nonNull(existingComplianceVestMap) && existingComplianceVestMap.size()>0){
				latestComplianceDate = existingComplianceVestMap.lastKey();
			}			
		}
		

		List<LocalDate> allDates;

		if(latestComplianceDate.isBefore(minOfTherapySessions)) {
			minOfTherapySessions = latestComplianceDate;
		}
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(minOfTherapySessions, LocalDate.now());

		Map<LocalDate,ProtocolConstants> vestProtocolMap = advanceAdherenceCalculationService.getProtocolForGivenDateTimeRangeForVest(patientUser,patient,allDates);
		Map<LocalDate,ProtocolConstantsMonarch> monarchProtocolMap = advanceAdherenceCalculationServiceMonarch.getProtocolForGivenDateTimeRangeForMonarch(patientUser, patient, allDates);
		Map<LocalDate,ProtocolConstantsTitan> titanProtocolMap = getProtocolForGivenDateTimeRangeForTitan(patientUser, patient, allDates);

		firstTransmissionDate = calculateFirstTransmissionDate(patientNoEvent,patientNoEventMonarch,patientNoEventTitan);

		if(Objects.isNull(firstTransmissionDate) || (Objects.nonNull(firstTransmissionDate) && firstTransmissionDate.isAfter(minOfTherapySessions))) {
			noEventTitanService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
			firstTransmissionDate = minOfTherapySessions;
		}

		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient.getId());

		for(PatientDevicesAssoc eachDevice:activeDevices) {
			if(eachDevice.getDeviceType().equalsIgnoreCase("MONARCH")) {
				trainingDate  = eachDevice.getTrainingDate();
			}
		}

		for(LocalDate therapyDate : allDates){				
			if(therapyDate.equals(resetDate)) {
				PatientComplianceTitan currentCompliance = new PatientComplianceTitan(DEFAULT_COMPLIANCE_SCORE,allDates.get(0),patient,patientUser,
						0,true,false,0,allDates.get(0),0.0);
				existingComplianceMap.put(allDates.get(0), currentCompliance);
				notificationServiceTitan.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
						currentCompliance.getDate(), ADHERENCE_SCORE_RESET,false,null);
			} else {
				List<TherapySessionTitan> sessionsTobeSaved = receivedTherapySessionMapTemp.get(therapyDate);

				if(Objects.nonNull(sessionsTobeSaved)) {
					existingTherapySessionMap.put(therapyDate, sessionsTobeSaved);
				}
				
				List<AdherenceResetTitan> adherenceResetList = adherenceResetTitanRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySession> currentVestTherapySessions = existingTherapySessionMapVest.get(therapyDate);

					List<TherapySessionTitan> currentTitanTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceTitan complianceTitan = existingComplianceMap.get(therapyDate);

					if(Objects.nonNull(trainingDate) && (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {
						PatientComplianceTitan currentCompliance = new PatientComplianceTitan(DEFAULT_COMPLIANCE_SCORE,therapyDate,patient,patientUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {

						if(currentVestTherapySessions != null && currentTitanTherapySessions != null) {
							totalCumulativeDuration = calculateCumulativeDurationVest(currentVestTherapySessions) + calculateCumulativeDurationForTitan(currentTitanTherapySessions); 
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(titanProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									totalCumulativeDuration);
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentVestTherapySessions != null ) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(titanProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationVest(currentVestTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else if(currentTitanTherapySessions != null) {
							isHMRCompliant = advanceAdherenceCalculationService.isHMRCompliant(titanProtocolMap.get(therapyDate),vestProtocolMap.get(therapyDate),
									calculateCumulativeDurationForTitan(currentTitanTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;

						} else {
							isHMRCompliant = false;
							missTherapy = true;

						}
						
						complianceTitan = advanceAdherenceCalculationService.getLatestComplianceTitan(patientUser, patient,existingComplianceMap, therapyDate);

						missedTherapyCount = complianceTitan.getMissedTherapyCount();

						advanceAdherenceCalculationService.calculateAdherenceForTheDayForBoth(complianceTitan,isHMRCompliant,existingComplianceMap,
								patient,patientUser,therapyDate,missedTherapyCount,missTherapy,lastTransmissionDate);
					}	
				} else{
					lastTransmissionDate = therapyDate;
				}					
			}			
		}

		if(!resetFlag) {
			receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMapTemp);
			saveOrUpdateTherapySessions(receivedTherapySessionMap);
		}
		
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForTitan(existingComplianceMap);

	}
	
	public SortedMap<LocalDate,PatientCompliance> getPatientComplainceMapByPatientUserIdForVestBetweenDates(LocalDate minDateFromRecievedTherapies,
			LocalDate today, Long patientUserId){

		List<PatientCompliance> complianceList = complianceRepository.findByDateBetweenAndPatientUserId(minDateFromRecievedTherapies,today,patientUserId);
		SortedMap<LocalDate,PatientCompliance> existingComplainceMap = new TreeMap<>(); 
		for(PatientCompliance compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}

	
	public LocalDate calculateFirstTransmissionDate(PatientNoEvent patientNoEvent,
			PatientNoEventMonarch patientNoEventMonarch ,PatientNoEventTitan patientNoEventTitan) {
		LocalDate firstTransmittedDate = null;
		
		log .debug("patientNoEvent :"+patientNoEvent + " patientNoEventMonarch :"+patientNoEventMonarch+" patientNoEventTitan:"+patientNoEventTitan);
		
		if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate()) && 
				Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate()) &&
				     Objects.nonNull(patientNoEventTitan) && Objects.nonNull(patientNoEventTitan.getFirstTransmissionDate())) {
			if((patientNoEvent.getFirstTransmissionDate()).isBefore(patientNoEventMonarch.getFirstTransmissionDate()) && (patientNoEvent.getFirstTransmissionDate()).isBefore(patientNoEventTitan.getFirstTransmissionDate())) {
				firstTransmittedDate = patientNoEvent.getFirstTransmissionDate();
			} else if((patientNoEventMonarch.getFirstTransmissionDate()).isBefore(patientNoEventTitan.getFirstTransmissionDate()) && (patientNoEventMonarch.getFirstTransmissionDate()).isBefore(patientNoEvent.getFirstTransmissionDate())){
				firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
			}else {
				firstTransmittedDate = patientNoEventTitan.getFirstTransmissionDate();
			}
		}else if(Objects.nonNull(patientNoEvent) && Objects.nonNull(patientNoEvent.getFirstTransmissionDate()) &&
				Objects.isNull(patientNoEventMonarch) &&  Objects.isNull(patientNoEventTitan)) {
			firstTransmittedDate = patientNoEvent.getFirstTransmissionDate();
		} else if(Objects.nonNull(patientNoEventMonarch) && Objects.nonNull(patientNoEventMonarch.getFirstTransmissionDate()) &&
				Objects.isNull(patientNoEvent) && Objects.isNull(patientNoEventTitan)){
			firstTransmittedDate = patientNoEventMonarch.getFirstTransmissionDate();
		} else if(Objects.nonNull(patientNoEventTitan) && Objects.nonNull(patientNoEventTitan.getFirstTransmissionDate())){
			firstTransmittedDate = patientNoEventTitan.getFirstTransmissionDate();
		}
		log .debug("firstTransmittedDate :"+firstTransmittedDate);
		return firstTransmittedDate;
	}

	
	public SortedMap<LocalDate,List<TherapySessionTitan>> convertTherapySessionToLocalDate(SortedMap<LocalDate,List<TherapySessionTitan>> inputSessions){
		List<TherapySessionTitan> therapySessions = new ArrayList<>();
		Collection<List<TherapySessionTitan>> collection = inputSessions.values();
		for (List<TherapySessionTitan> list : collection) {
			for (TherapySessionTitan therapySessionTitan : list) {
				if (DateUtil.isDSTOn(therapySessionTitan.getStartTime().getMillis(),Constants.CST_STR)) {
					therapySessionTitan.setDate(therapySessionTitan.getStartTime().minusHours(4).toLocalDate());
				}else {
					therapySessionTitan.setDate(therapySessionTitan.getStartTime().minusHours(5).toLocalDate());
				}
			}
			therapySessions.addAll(list);
		}
		return groupTherapySessionsByDate(therapySessions);
	}
	
	public SortedMap<LocalDate,List<TherapySessionTitan>> convertTherapySessionToOriginalDate(SortedMap<LocalDate,List<TherapySessionTitan>> inputSessions){
		List<TherapySessionTitan> therapySessions = new ArrayList<>();
		Collection<List<TherapySessionTitan>> collection = inputSessions.values();
		for (List<TherapySessionTitan> list : collection) {
			for (TherapySessionTitan therapySessionTitan : list) {
				if (DateUtil.isDSTOn(therapySessionTitan.getStartTime().getMillis(),Constants.CST_STR)) {
					therapySessionTitan.setDate(therapySessionTitan.getStartTime().plusHours(4).toLocalDate());
				}else {
					therapySessionTitan.setDate(therapySessionTitan.getStartTime().plusHours(5).toLocalDate());
				}
			}
			therapySessions.addAll(list);
		}
		return groupTherapySessionsByDate(therapySessions);
	}
	public SortedMap<LocalDate,List<TherapySessionTitan>> getAllTherapySessionsMapByPatientUserIdForTitanBetweenDates(LocalDate minTherapySessionDate,
			LocalDate maxTherapySessiondate, Long patientUserId){
		List<TherapySessionTitan> therapySessions =  therapySessionTitanRepository.findByDateBetweenAndPatientUserId(minTherapySessionDate,maxTherapySessiondate,patientUserId);
		return groupTherapySessionsByDate(therapySessions);
	}
	
	public SortedMap<LocalDate,List<TherapySessionTitan>> groupTherapySessionsByDate(List<TherapySessionTitan> therapySessions){
		return new TreeMap<>(therapySessions.stream().collect(Collectors.groupingBy(TherapySessionTitan :: getDate)));
	}

	public SortedMap<LocalDate,PatientComplianceTitan> getPatientComplainceMapByPatientUserIdForTitanBetweenDates(LocalDate minTherapySessionDate, 
			LocalDate maxTherapySessiondate, Long patientUserId){
		List<PatientComplianceTitan> complianceList = complianceTitanRepository.
				findByDateBetweenAndPatientUserId(minTherapySessionDate,maxTherapySessiondate,patientUserId);
		SortedMap<LocalDate,PatientComplianceTitan> existingComplainceMap = new TreeMap<>(); 
		for(PatientComplianceTitan compliance : complianceList){
			existingComplainceMap.put(compliance.getDate(),compliance);
		}
		return existingComplainceMap;
	}
	
	public void processAdherenceScoreForTitan(
			SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionMap,
			SortedMap<LocalDate, List<TherapySessionTitan>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceTitan> existingComplianceMap, User patientUser,
			PatientInfo patient, boolean resetFlag, LocalDate resetDate) throws Exception {

		boolean isHMRCompliant = true;
		boolean missTherapy = true;
		int missedTherapyCount = 0;
		LocalDate trainingDate = null;
		LocalDate lastTransmissionDate = null;
		LocalDate minOfTherapySessions = null;
		LocalDate latestComplianceDate = null;

		log.debug("Inside processAdherenceScoreForTitan");
		log.debug("receivedTherapySessionMap : "+receivedTherapySessionMap);
		log.debug("existingTherapySessionMap : "+existingTherapySessionMap);
		SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionMapTemp = convertTherapySessionToLocalDate(receivedTherapySessionMap);
		existingTherapySessionMap = convertTherapySessionToLocalDate(existingTherapySessionMap);
		
		PatientNoEventTitan patientNoEventTitan = patientNoEventTitanRepository.findByPatientUserId(patientUser.getId());

		if(resetFlag) {
			minOfTherapySessions = resetDate;
			latestComplianceDate = LocalDate.now();
		} else{
			minOfTherapySessions = receivedTherapySessionMap.firstKey();
			if(Objects.nonNull(existingComplianceMap) && !existingComplianceMap.isEmpty()) {
				latestComplianceDate = existingComplianceMap.lastKey();
			} else {
				latestComplianceDate = LocalDate.now();
			}
		}
		

		List<LocalDate> allDates;

		if(latestComplianceDate.isBefore(minOfTherapySessions)) {
			minOfTherapySessions = latestComplianceDate;
		}
		
		allDates = DateUtil.getAllLocalDatesBetweenDates(minOfTherapySessions, LocalDate.now());
		log.debug("allDates : "+allDates);
		
		// First Transmission Date to be updated
		if(Objects.nonNull(patientNoEventTitan) && Objects.nonNull(patientNoEventTitan.getFirstTransmissionDate())) {
			if((patientNoEventTitan.getFirstTransmissionDate()).isAfter(minOfTherapySessions)) {
				noEventTitanService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
			} 
		} else {
			noEventTitanService.updatePatientFirstTransmittedDate(patientUser.getId(), minOfTherapySessions, patient.getId());
		}

		List<PatientDevicesAssoc> activeDevices = patientDevicesAssocRepository.findByPatientId(patient.getId());
		log.debug("activeDevices : "+activeDevices);

		
		for(PatientDevicesAssoc eachDevice:activeDevices) {
			if(eachDevice.getDeviceType().equalsIgnoreCase("Titan")) {
				trainingDate  = eachDevice.getTrainingDate();
			}
		}

		Map<LocalDate,ProtocolConstantsTitan> protocolMap = getProtocolForGivenDateTimeRangeForTitan(patientUser,patient,allDates);

		log.debug("resetDate : "+resetDate);
		for(LocalDate therapyDate : allDates) {
			
			if(therapyDate.equals(resetDate)) {
				PatientComplianceTitan currentCompliance = new PatientComplianceTitan(DEFAULT_COMPLIANCE_SCORE,allDates.get(0),patient,patientUser,
						0,true,false,0,allDates.get(0),0.0);
				existingComplianceMap.put(allDates.get(0), currentCompliance);
				notificationServiceTitan.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
						currentCompliance.getDate(), ADHERENCE_SCORE_RESET,false,null);
			} else {

				List<TherapySessionTitan> sessionsTobeSaved = receivedTherapySessionMap.get(therapyDate);

				if(Objects.nonNull(sessionsTobeSaved)) {
					existingTherapySessionMap.put(therapyDate, sessionsTobeSaved);
				}
				
				List<AdherenceResetTitan> adherenceResetList = adherenceResetTitanRepository.findOneByPatientUserIdAndResetStartDate(patientUser.getId(),therapyDate);
				
				//if any adherence reset is found stop the adherence  calculation and set the therapy date as first resetdate
				if(adherenceResetList.isEmpty()){
					List<TherapySessionTitan> currentTherapySessions = existingTherapySessionMap.get(therapyDate);

					PatientComplianceTitan compliance = existingComplianceMap.get(therapyDate);


					if(Objects.nonNull(trainingDate)&& (therapyDate.isBefore(trainingDate) || therapyDate.equals(trainingDate))) {

						PatientComplianceTitan currentCompliance = new PatientComplianceTitan(DEFAULT_COMPLIANCE_SCORE,therapyDate,patient,patientUser,
								0,true,false,0,trainingDate,0.0);
						existingComplianceMap.put(therapyDate, currentCompliance);
					} else {
						if(currentTherapySessions != null) {
							isHMRCompliant = isHMRCompliant(protocolMap.get(therapyDate), calculateCumulativeDurationForTitan(currentTherapySessions));
							missTherapy = false;
							lastTransmissionDate = therapyDate;
						} else {
							isHMRCompliant = false;
							missTherapy = true;
						}

						compliance = advanceAdherenceCalculationService.getLatestComplianceTitan(patientUser, patient,
								existingComplianceMap, therapyDate);

						missedTherapyCount = compliance.getMissedTherapyCount();

						calculateAdherenceForTheDayTitan(compliance,isHMRCompliant,existingTherapySessionMap,existingComplianceMap,
								patient,patientUser,missedTherapyCount,missTherapy,lastTransmissionDate);
					}
				} else {
					lastTransmissionDate = therapyDate;
				}
			}

		}
		if(!resetFlag) {
			receivedTherapySessionMap = convertTherapySessionToOriginalDate(receivedTherapySessionMapTemp);
			log.debug("Going for saving theapy data : "+ receivedTherapySessionMap);
			saveOrUpdateTherapySessions(receivedTherapySessionMap);
		} 
		
		advanceAdherenceCalculationService.saveOrUpdateComplianceMapForTitan(existingComplianceMap);

	}
	
	private synchronized void saveOrUpdateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionsMap) {
		Map<LocalDate, List<TherapySessionTitan>> allTherapySessionMap = eleminateDuplicateTherapySessions(receivedTherapySessionsMap);

		List<TherapySessionTitan> newTherapySessions = new LinkedList<>();
		for(LocalDate date : allTherapySessionMap.keySet()){
			List<TherapySessionTitan> sessionsTobeSaved = allTherapySessionMap.get(date);
			newTherapySessions.addAll(sessionsTobeSaved);
		}
		log.debug("saveOrUpdateTherapySessions newTherapySessions : "+ newTherapySessions);
		therapySessionTitanRepository.save(newTherapySessions);
	}
	
	private Map<LocalDate, List<TherapySessionTitan>> eleminateDuplicateTherapySessions(
			SortedMap<LocalDate, List<TherapySessionTitan>> receivedTherapySessionsMap) {
		List<List<TherapySessionTitan>> therapySessionsList = new LinkedList<>(receivedTherapySessionsMap.values());
		Long patientUserId = therapySessionsList.get(0).get(0).getPatientUser().getId();
		LocalDate from = receivedTherapySessionsMap.firstKey();
		LocalDate to = receivedTherapySessionsMap.lastKey();
		List<TherapySessionTitan> existingTherapySessions = therapySessionTitanRepository.findByPatientUserIdAndDateRange(patientUserId, from, to);
		Map<LocalDate,List<TherapySessionTitan>> existingTherapySessionMap = existingTherapySessions.stream().collect(Collectors.groupingBy(TherapySessionTitan::getDate));
		Map<LocalDate,List<TherapySessionTitan>> allTherapySessionMap = new HashMap<>();
		for(LocalDate date : receivedTherapySessionsMap.keySet()){
			List<TherapySessionTitan> therapySessionsPerDate = existingTherapySessionMap.get(date);
			if(Objects.nonNull(therapySessionsPerDate)){
				List<TherapySessionTitan> receivedTherapySessions = receivedTherapySessionsMap.get(date);
				for(TherapySessionTitan existingSession : therapySessionsPerDate){
					Iterator<TherapySessionTitan> itr = receivedTherapySessions.iterator();
					while(itr.hasNext()){
						TherapySessionTitan receivedSession = itr.next();
						if(existingSession.getDate().equals(receivedSession.getDate()) &&
								existingSession.getStartTime().equals(receivedSession.getStartTime()) &&
								existingSession.getEndTime().equals(receivedSession.getEndTime()) &&
								existingSession.getFrequency().equals(receivedSession.getFrequency()) && 
								existingSession.getIntensity().equals(receivedSession.getIntensity()) &&
								existingSession.getHmr().equals(receivedSession.getHmr())){
							itr.remove();
						}
					}
				}
				therapySessionsPerDate.addAll(receivedTherapySessionsMap.get(date));
				Collections.sort(therapySessionsPerDate);
				int sessionNo = 0;
				for(TherapySessionTitan session : therapySessionsPerDate){
					session.setSessionNo(++sessionNo);
				}
				allTherapySessionMap.put(date, therapySessionsPerDate);
			}else{
				for(LocalDate receivedDate : receivedTherapySessionsMap.keySet()){
					allTherapySessionMap.put(receivedDate, receivedTherapySessionsMap.get(receivedDate));
				}
			}
		}
		return allTherapySessionMap;
	}

	public static int calculateCumulativeDurationVest(List<TherapySession> therapySessions){
		return therapySessions.stream().collect(Collectors.summingInt(TherapySession::getDurationInMinutes));
	}

	/**
	 * Checks whether HMR Compliance violated(minHMRReading < actual < maxHMRReading)
	 * @param protocolConstant
	 * @param actualMetrics
	 * @return
	 */
	public boolean isHMRCompliant(ProtocolConstantsTitan protocolConstant,
			double actualTotalDurationSettingDays) {
		// Custom Protocol, Min/Max Duration calculation is done
		int minHMRReading = Objects.nonNull(protocolConstant
				.getMinDuration()) ? protocolConstant.getMinDuration()
						: protocolConstant.getTreatmentsPerDay()
						* protocolConstant.getMinMinutesPerTreatment();
				if( Math.round(minHMRReading * LOWER_BOUND_VALUE) > Math.round(actualTotalDurationSettingDays)){
					return false;
				}
				return true;
	}

	private void calculateAdherenceForTheDayTitan(PatientComplianceTitan compliance, boolean isHMRCompliant,
			SortedMap<LocalDate, List<TherapySessionTitan>> existingTherapySessionMap,
			SortedMap<LocalDate, PatientComplianceTitan> existingComplianceMap,
			PatientInfo patient, User patientUser, int missedTherapyCount, boolean missTherapy, LocalDate lastTransmissionDate) {
		String notificationType = "";
		String complianceType="";
		int currentScore=0;

		if(Objects.nonNull(compliance)) {
			currentScore = compliance.getScore();
			if(missedTherapyCount < MISSED_THERAPY_DAYS_COUNT_THRESHOLD) {
				if(!missTherapy) {
					if(!isHMRCompliant) {
						currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
						complianceType =  HMR_NON_COMPLIANCE;	
						notificationType = HMR_NON_COMPLIANCE;
						compliance.setHmrCompliant(false);
						compliance.setMissedTherapyCount(0);

						int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
						compliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
					} else {
						currentScore = currentScore < 100 ? currentScore + 1 : DEFAULT_COMPLIANCE_SCORE;
						notificationType = null;
						compliance.setHmrCompliant(true);
						compliance.setMissedTherapyCount(0);
					}
				} else {
					currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
					complianceType =  null;	
					notificationType = MISSED_THERAPY;
					compliance.setHmrCompliant(false);
					compliance.setMissedTherapyCount(missedTherapyCount+1);

					int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
					compliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);
				}
			} else {
				currentScore = DEFAULT_COMPLIANCE_SCORE;	
				notificationType = ADHERENCE_SCORE_RESET;
				compliance.setHmrCompliant(false);
				compliance.setMissedTherapyCount(0);
			}
		} else {
			currentScore = DEFAULT_COMPLIANCE_SCORE;
			if(!missTherapy) {
				if(!isHMRCompliant) {
					currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
					complianceType =  HMR_NON_COMPLIANCE;	
					notificationType = HMR_NON_COMPLIANCE;
					compliance.setHmrCompliant(false);
					compliance.setMissedTherapyCount(0);

					int globalHMRNonAdherenceCounter = compliance.getGlobalHMRNonAdherenceCounter();
					compliance.setGlobalHMRNonAdherenceCounter(++globalHMRNonAdherenceCounter);
				} else {
					currentScore = currentScore < 100 ? currentScore + 1 : DEFAULT_COMPLIANCE_SCORE;
					notificationType = null;
					compliance.setHmrCompliant(true);
					compliance.setMissedTherapyCount(0);
				}
			} else {
				currentScore = currentScore <=  2 ? 0 : currentScore - HMR_NON_COMPLIANCE_POINTS;
				complianceType =  null;	
				notificationType = MISSED_THERAPY;
				compliance.setHmrCompliant(false);
				compliance.setMissedTherapyCount(missedTherapyCount+1);

				int globalMissedTherapyCounter = compliance.getGlobalMissedTherapyCounter();
				compliance.setGlobalMissedTherapyCounter(++globalMissedTherapyCounter);	
			}

		}

		compliance.setScore(currentScore);
		compliance.setSettingsDeviated(false);
		compliance.setLatestTherapyDate(lastTransmissionDate);

		if(StringUtils.isNotBlank(notificationType)){
			notificationServiceTitan.createOrUpdateNotification(patientUser, patient, patientUser.getId(),
					compliance.getDate(), notificationType,false,complianceType);
		}  else {
			advanceAdherenceCalculationService.deleteNotificationIfExistsForBoth(patientUser.getId(), compliance.getDate());
		}
		existingComplianceMap.put(compliance.getDate(), compliance);

	}
	
	public static int calculateCumulativeDurationForTitan(List<TherapySessionTitan> therapySessions){
		return therapySessions.stream().collect(Collectors.summingInt(TherapySessionTitan::getDurationInMinutes));
	}
	
	
	public Map<LocalDate,ProtocolConstantsTitan> getProtocolForGivenDateTimeRangeForTitan(User patientUser,
			PatientInfo patient, List<LocalDate> allDates) {
		Map<LocalDate,ProtocolConstantsTitan> protocolMap = new HashMap<LocalDate,ProtocolConstantsTitan>();
		Long startTime = 0L;

		List<PatientProtocolDataTitan>  protocolList = patientProtocolTitanRepository.findByPatientIdOrderByCreatedDateAsc(patient.getId());
		if(!protocolList.isEmpty()) {
		for(LocalDate currentDate : allDates) {
			startTime = currentDate.toDateTimeAtStartOfDay().getMillis();
			
				for (PatientProtocolDataTitan ppd : protocolList) {
					if (patientProtocolTitanService.isProtocolValidForDate(ppd, startTime)) { 
						List<PatientProtocolDataTitan> protocol = patientProtocolTitanRepository.findByProtocolKey(ppd.getProtocolKey());
						if(Objects.nonNull(protocol) && protocol.size() > 0){			
							String protocolType = protocol.get(0).getType();
							if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(protocolType)){
								protocolMap.put(currentDate,patientProtocolTitanService.getProtocolConstantFromNormalProtocol(protocol));
							}else{
								protocolMap.put(currentDate,patientProtocolTitanService.getProtocolConstantFromCustomProtocol(protocol));
							}
						}else{
							protocolMap.put(currentDate,protocolConstantsTitanRepository.findOne(1L));
						}
					} else{
						protocolMap.put(currentDate,protocolConstantsTitanRepository.findOne(1L));
					}
				}
			} 
		} else{
			for(LocalDate currentDate : allDates) {
			protocolMap.put(currentDate,protocolConstantsTitanRepository.findOne(1L));
			}
		}

		return protocolMap;
	}
	

	}



			