package com.hillrom.titan.batch.processing;

import java.util.List;

import javax.inject.Inject;

import org.springframework.batch.item.ItemWriter;

import com.hillrom.titan.repository.PatientTitanDeviceDataRepository;
import com.hillrom.titan.service.PatientVestDeviceTitanService;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.User;

public class PatientTitanDeviceDataWriter implements ItemWriter<List<PatientVestDeviceDataTitan>>{

	@Inject
	private PatientTitanDeviceDataRepository deviceDataRepositoryTitan;
	

	@Inject
	private PatientVestDeviceTitanService deviceServiceTitan;
	
	@Override
	public void write(List<? extends List<PatientVestDeviceDataTitan>> vestDeviceDataTitan) throws Exception {
		if(vestDeviceDataTitan.size() > 0){
			if(!vestDeviceDataTitan.get(0).isEmpty()){
				User patientUser = vestDeviceDataTitan.get(0).get(0).getPatientUser();
				PatientInfo patient = vestDeviceDataTitan.get(0).get(0).getPatient();
				for(List<PatientVestDeviceDataTitan> devDataTitan : vestDeviceDataTitan){
					deviceDataRepositoryTitan.save(devDataTitan);
				}
				deviceServiceTitan.updateHMR(patientUser, patient);

			}
		}
	}

}
