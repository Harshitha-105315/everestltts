package com.hillrom.titan.service;

import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.CRC;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_BT;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_DATA;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_LTE;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_MODEL;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_SN;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_VER;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.DEVICE_WIFI;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.FRAG_CURRENT;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.FRAG_TOTAL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.hillrom.titan.repository.PatientTitanDeviceDataRepository;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.service.util.ParserUtil;
import com.hillrom.vest.service.util.RandomUtil;

import net.minidev.json.JSONObject;

@Service
public class PatientVestDeviceDataServiceTitan {
	
	@Inject
	private PatientTitanDeviceDataRepository patientTitanDeviceDataRepository;
	
	@Inject
	private MailService mailService;
	
	@Inject
	private JobLauncher jobLauncherTitan;
	
	@Inject
	private ApplicationContext applicationContextTitan; 
	

	@Inject
	private Environment env;
	
	final Logger log = LoggerFactory.getLogger(PatientVestDeviceDataServiceTitan.class);
	
	
	public ExitStatus saveData(final String rawData) throws Exception {
		log.debug("saveData has been called , rawData length",rawData.length());
		
		validateRequest(rawData);
		
		Job addNewDataIngestionJobTitan = applicationContextTitan.getBean("processTitanTherapySessionsAndCompliance", Job.class);
		JobParameters jobParametersMonarch = new JobParametersBuilder()
		.addLong("TIME", System.currentTimeMillis())
		.addString("rawData", rawData)
		.toJobParameters();
		JobExecution jobExecution = jobLauncherTitan.run(addNewDataIngestionJobTitan, jobParametersMonarch);
		log.debug("Job triggered @ Time ",System.currentTimeMillis());
		ExitStatus exitStatus = jobExecution.getExitStatus();
		String shouldTriggerMail = env.getProperty("sendmail.for.valid.data.ingestion");
		// Sending mail Notification on Job Status (ON Success), this code should be removed later
		log.debug("Job triggered @ Time ",exitStatus);
		if(ExitStatus.COMPLETED.equals(exitStatus) && shouldTriggerMail.equalsIgnoreCase("true")){
			mailService.sendStatusOnDataIngestionRequest(rawData, exitStatus.getExitCode(), !ExitStatus.COMPLETED.equals(exitStatus), "");
		}
		return exitStatus;
	}
	
	private void validateRequest(final String rawData) throws HillromException {
		String decodedData = decodeData(rawData);
		JSONObject qclJsonData = ParserUtil.getChargerJsonDataFromRawMessage(decodedData);
		String reqParams[] = new String[]{DEVICE_MODEL,DEVICE_SN,
				DEVICE_WIFI,DEVICE_LTE,DEVICE_BT,DEVICE_VER,FRAG_TOTAL,FRAG_CURRENT,DEVICE_DATA,CRC};
		if(Objects.isNull(qclJsonData) || qclJsonData.keySet().isEmpty()){
			//throw new HillromException("Missing Params : "+String.join(",",reqParams));
			throw new HillromException("Missing Params");
		}else if(Objects.nonNull(qclJsonData)){
			//JSONObject allProperties = (JSONObject) qclJsonData.getOrDefault(TWO_NET_PROPERTIES, new JSONObject());
			List<String> missingParams = RandomUtil.getDifference(Arrays.asList(reqParams), new ArrayList<String>(qclJsonData.keySet()));
			
			// To check either WIFI / LTE / BT is available
			if( missingParams.contains(DEVICE_WIFI) && !missingParams.contains(DEVICE_LTE) && missingParams.contains(DEVICE_BT)){
				missingParams.remove(DEVICE_WIFI);
				missingParams.remove(DEVICE_BT);
			}else if(missingParams.contains(DEVICE_LTE) && !missingParams.contains(DEVICE_WIFI) && missingParams.contains(DEVICE_BT)){
				missingParams.remove(DEVICE_LTE);
				missingParams.remove(DEVICE_BT);
			}else if(missingParams.contains(DEVICE_LTE) && missingParams.contains(DEVICE_WIFI) && !missingParams.contains(DEVICE_BT)){
				missingParams.remove(DEVICE_LTE);
				missingParams.remove(DEVICE_WIFI);
			}
			
			if(missingParams.size() > 0)
				//throw new HillromException("Missing Params : "+String.join(",",missingParams));
				throw new HillromException("Missing Params");
		}
		if(!calculateCRC(rawData)){
			throw new HillromException("CRC Validation Failed");
		}
	}
	
	private boolean calculateCRC(String base64String)
	{	
		log.info("Inside  calculateCRC : " ,base64String);
	  
		int nCheckSum = 0;

		byte[] decoded = java.util.Base64.getDecoder().decode(base64String);
    
		int nDecodeCount = 0;
	    for ( ; nDecodeCount < (decoded.length-2); nDecodeCount++ )
	    {
	    	int nValue = (decoded[nDecodeCount] & 0xFF);
	    	nCheckSum += nValue;
	    }    
	    log.debug("Inverted Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);
    
	    
	    int nMSB = decoded[nDecodeCount+1] & 0xFF;
	    int nLSB = decoded[nDecodeCount] & 0xFF;
	    
	    log.debug("MSB = %d [0x%x]\r\n" ,nMSB, nMSB);
	    log.debug("LSB = %d [0x%x]\r\n" ,nLSB, nLSB);
	    log.info("Total Value = " + nCheckSum);
	    nCheckSum = ((~nCheckSum)& 0xFFFF) + 1;
	    log.debug("Checksum Value = %d [0X%x] \r\n" ,nCheckSum,nCheckSum);
	    
	    String msb_digit = Integer.toHexString(nMSB);
	    String lsb_digit = Integer.toHexString(nLSB);
	    String checksum_num =  Integer.toHexString(nCheckSum);
	    
	    if(msb_digit.length()<2)
	    	msb_digit = "0"+msb_digit;
	    if(lsb_digit.length()<2)
	    	lsb_digit = "0"+lsb_digit;
	    
	    log.debug("MSB : " + msb_digit + " " +  "LSB : " + lsb_digit);
	    log.debug("Checksum : " + checksum_num);
	    
	    if((msb_digit+lsb_digit).equalsIgnoreCase(checksum_num)){
	    	return true;
	    }else{
	    	log.info("CRC VALIDATION FAILED :"); 
	    	return false;
	    }
	}
	
	public List<PatientVestDeviceDataTitan> getDeviceDataForAllFragments(Long patientUserId, String serialNumber, int therapyIndex){
		
		List<PatientVestDeviceDataTitan> allDeviceData = 
				patientTitanDeviceDataRepository.findByPatientUserIdAndSerialNumberAndTherapyIndex(patientUserId, serialNumber, therapyIndex);
		
		return allDeviceData;
	}

	public String decodeData(final String rawMessage){
		byte[] decoded = java.util.Base64.getDecoder().decode(rawMessage);

		String decoded_string = new String(decoded);
		log.info("Decoded value is " + decoded_string);
		return decoded_string;
	}

}
