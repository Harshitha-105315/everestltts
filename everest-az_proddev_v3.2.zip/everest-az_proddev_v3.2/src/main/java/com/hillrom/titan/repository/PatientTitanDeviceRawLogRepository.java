package com.hillrom.titan.repository;

	import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hillrom.vest.domain.PatientVestDeviceRawLogTitan;

	/**
	 * Spring Data JPA repository for the PatientVestDeviceRawLog entity.
	 */

      public interface PatientTitanDeviceRawLogRepository  extends JpaRepository<PatientVestDeviceRawLogTitan,Long> {
		Page<PatientVestDeviceRawLogTitan> findByCreatedTimeBetweenOrderByIdDesc(DateTime from, DateTime to,Pageable pageable);
		
		Page<PatientVestDeviceRawLogTitan> findByDeviceSerialNumberAndCreatedTimeBetweenOrderByIdDesc(String deviceSerialNumber, DateTime from, DateTime to,Pageable pageable);
		
		List<PatientVestDeviceRawLogTitan> findTop15ByDeviceSerialNumberOrderByIdDesc(String deviceSerialNumber);
	}


