package com.hillrom.titan.dto;

public class CaughPauseSetting {
	private int caughPauseEnable;
	private int afterEachStepStatus;
	private int autoRestartStatus;
	private int caughPauseDuration;
	private int caughPauseInterval;
	
	public int getCaughPauseEnable() {
		return caughPauseEnable;
	}
	public void setCaughPauseEnable(int caughPauseEnable) {
		this.caughPauseEnable = caughPauseEnable;
	}
	public int getAfterEachStepStatus() {
		return afterEachStepStatus;
	}
	public void setAfterEachStepStatus(int afterEachStepStatus) {
		this.afterEachStepStatus = afterEachStepStatus;
	}
	public int getAutoRestartStatus() {
		return autoRestartStatus;
	}
	public void setAutoRestartStatus(int autoRestartStatus) {
		this.autoRestartStatus = autoRestartStatus;
	}
	public int getCaughPauseDuration() {
		return caughPauseDuration;
	}
	public void setCaughPauseDuration(int caughPauseDuration) {
		this.caughPauseDuration = caughPauseDuration;
	}
	public int getCaughPauseInterval() {
		return caughPauseInterval;
	}
	public void setCaughPauseInterval(int caughPauseInterval) {
		this.caughPauseInterval = caughPauseInterval;
	}
	
	@Override
	public String toString() {
		return "CaughPauseSetting [caughPauseEnable=" + caughPauseEnable + ", afterEachStepStatus="
				+ afterEachStepStatus + ", autoRestartStatus=" + autoRestartStatus + ", caughPauseDuration="
				+ caughPauseDuration + ", caughPauseInterval=" + caughPauseInterval + "]";
	}	

}
