package com.hillrom.titan.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hillrom.vest.domain.VestDeviceBadDataTitan;


@Repository
public interface VestDeviceBadDataRepositoryTitan extends JpaRepository<VestDeviceBadDataTitan, Long>{

}
