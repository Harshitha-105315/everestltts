package com.hillrom.titan.service.util;

import static com.hillrom.vest.config.Constants.DURATION;
import static com.hillrom.vest.config.PatientVestDeviceRawLogModelConstants.*;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientVestDeviceDataMonarch;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.service.util.ParserUtil;

import net.minidev.json.JSONObject;

public class PatientVestDeviceTherapyUtilTitan {

	private final static Logger log = LoggerFactory.getLogger(PatientVestDeviceTherapyUtilTitan.class);
	
	private static final String EVENT_CODE_START_THEARPY_TITAN = "1";
	private static final String EVENT_CODE_THEARPY_PAUSED_TITAN= "2";
	private static final String EVENT_CODE_THEARPY_RESUMED_TITAN= "3";
	private static final String EVENT_CODE_THEARPY_COMPLETE_TITAN = "12";
	private static final String EVENT_CODE_PAUSED_TIMEOUT_TITAN= "9";
	private static final String EVENT_CODE_ERROR_TITAN= "10";
	private static final String EVENT_CODE_COUGH_PAUSE_START_TITAN="6";
	private static final String EVENT_CODE_COUGH_PAUSE_END_TITAN="7";
	private static final String EVENT_CODE_THEARPY_INCOMPLETE_TITAN="8";
	private static final int SECONDS_PER_MINUTE = 60;
	private static final String SESSION_TYPE_PROGRAM = "Program";
	private static final String SESSION_TYPE_NORMAL = "Normal";
	private static final String SESSION_TYPE_MY_THERAPY = "My Therapy";
	private static final String CAUGH_PAUSE_DURATION = "caughPauseDuration";
	private static final String CAUGH_PAUSE_ENABLE = "caughPauseEnable";
	private static final String CAUGH_INTERVAL_MODE = "caughIntervalMode";
	private static final String CAUGH_AUTO_ENABLE = "caughAutoEnable";
	private static final String CAUGH_PAUSE_INTERVAL = "caughPauseInterval";

	private static final String FREQUENCY = "frequency";
	private static final String INTENSITY = "intensity";
	private static final String SESSION_TYPE = "session_type";
	private static final String SESSION_NO = "session_no";
	private static final String CAUGH_PAUSES = "caughpauses";
	
	private PatientVestDeviceTherapyUtilTitan(){

	}

	public static List<TherapySessionTitan> prepareTherapySessionFromDeviceDataTitan(List<PatientVestDeviceDataTitan> deviceDataTitan,PatientVestDeviceHistoryTitan latestInActiveDeviceHistory,String patientDeviceRawData) throws Exception{
		log.debug("Inside prepareTherapySessionFromDeviceDataTitan deviceDataTitan : "+deviceDataTitan);
		List<TherapySessionTitan> therapySessionsTitan = new LinkedList<>();
		therapySessionsTitan = groupEventsToPrepareTherapySessionTitan(deviceDataTitan,latestInActiveDeviceHistory,patientDeviceRawData);
		return groupTherapySessionsByDayTitan(therapySessionsTitan);
	}

	public static List<TherapySessionTitan> groupEventsToPrepareTherapySessionTitan(
			List<PatientVestDeviceDataTitan> deviceDataTitan,PatientVestDeviceHistoryTitan latestInActiveDeviceHistory, String patientDeviceRawData) throws Exception{
		log.debug("Inside groupEventsToPrepareTherapySessionTitan latestInActiveDeviceHistory : "+latestInActiveDeviceHistory);
		List<TherapySessionTitan> therapySessions = new LinkedList<TherapySessionTitan>();

		// This List will hold un-finished session events , will be discarded to get delta on next transmission 
		List<PatientVestDeviceDataTitan> eventsToBeDiscardedTitan = new LinkedList<>();

		for(int i = 0;i < deviceDataTitan.size() ; i++){
			PatientVestDeviceDataTitan vestDeviceDataTitan = deviceDataTitan.get(i);
			//String eventCode = vestDeviceData.getEventCode().split(EVENT_CODE_DELIMITER)[0];
			String eventCodeTitan = vestDeviceDataTitan.getEventCode();
			List<PatientVestDeviceDataTitan> groupEntriesTitan = new LinkedList<>();
			if(isStartEventForTherapySessionTitan(eventCodeTitan)){
				groupEntriesTitan.add(vestDeviceDataTitan);
				for(int j = i+1; j < deviceDataTitan.size() ; j++){
					PatientVestDeviceDataTitan nextEventEntryTitan = deviceDataTitan.get(j);
					String nextEventCodeTitan = nextEventEntryTitan.getEventCode();

					// Group entry if the nextEvent is not a start event
					if(!isStartEventForTherapySessionTitan(nextEventCodeTitan))
						groupEntriesTitan.add(nextEventEntryTitan);

					if(isCompleteOrInCompleteEventForTherapySessionTitan(nextEventCodeTitan)
							|| ( isErrorEventForTherapySessionTitan(nextEventCodeTitan) && (j == (deviceDataTitan.size()-1)) )
							|| isStartEventForTherapySessionTitan(nextEventCodeTitan)	){

						// subsequent start events indicate therapy is incomplete due to unexpected reason
						if(isStartEventForTherapySessionTitan(nextEventCodeTitan)){
							PatientVestDeviceDataTitan inCompleteEventTitan = (PatientVestDeviceDataTitan) groupEntriesTitan.get(groupEntriesTitan.size()-1).clone();
							if(groupEntriesTitan.get(0).getEventCode().equals(EVENT_CODE_THEARPY_COMPLETE_TITAN))
								inCompleteEventTitan.setEventCode(EVENT_CODE_THEARPY_PAUSED_TITAN);
							
							inCompleteEventTitan.setDuration(0);// DO NOT CHANGE: This is the indication, dummy event has been added for making session
							inCompleteEventTitan.setFrequency(0);
							inCompleteEventTitan.setIntensity(0);
							groupEntriesTitan.add(inCompleteEventTitan);// Add dummy incomplete event to finish the session
							deviceDataTitan.add(j, inCompleteEventTitan);
						}
						log.debug(" groupEntriesTitan : "+groupEntriesTitan);
						TherapySessionTitan therapySession = assignTherapyMatricsTitan(groupEntriesTitan,patientDeviceRawData);
						applyGlobalHMRTitan(therapySession,latestInActiveDeviceHistory);
						therapySessions.add(therapySession);
						log.debug(" therapySessions : "+therapySessions);
						i=j; // to skip the events iterated, shouldn't be removed in any case
						break;
					}else if(j == deviceDataTitan.size()-1){
						//will be discarded to get delta on next transmission

						eventsToBeDiscardedTitan.addAll(groupEntriesTitan);
						i=j; // to skip the events iterated, shouldn't be removed in any case
						break;
					}
				}
			}
		}
		// Discarding these events to make session from delta
		if(eventsToBeDiscardedTitan.size() > 0){
			deviceDataTitan.removeAll(eventsToBeDiscardedTitan);
		}
		return therapySessions;
	}
	private static boolean isCompleteOrInCompleteEventForTherapySessionTitan(
			String nextEventCode) {
		return EVENT_CODE_THEARPY_COMPLETE_TITAN.equals(nextEventCode) ||
				EVENT_CODE_THEARPY_PAUSED_TITAN.equals(nextEventCode) || 
				EVENT_CODE_THEARPY_RESUMED_TITAN.equals(nextEventCode);
	}


	private static boolean isErrorEventForTherapySessionTitan(
			String nextEventCode) {
		return EVENT_CODE_ERROR_TITAN.equals(nextEventCode) || 
				EVENT_CODE_PAUSED_TIMEOUT_TITAN.equals(nextEventCode);
	}	

	private static void applyGlobalHMRTitan(TherapySessionTitan therapySession,
			PatientVestDeviceHistoryTitan latestInActiveDeviceHistory)throws Exception {
		if( Objects.nonNull(latestInActiveDeviceHistory) ){
			if(!(latestInActiveDeviceHistory.getSerialNumber().equalsIgnoreCase(therapySession.getSerialNumber()))){
				therapySession.setHmr(therapySession.getHmr()+latestInActiveDeviceHistory.getHmr());
			}
		}
	}
	public static TherapySessionTitan assignTherapyMatricsTitan(
			List<PatientVestDeviceDataTitan> groupEntriesTitan, String patientDeviceRawData) {
		Long timestamp = groupEntriesTitan.get(0).getTimestamp();
		User patientUser = groupEntriesTitan.get(0).getPatientUser();
		PatientInfo patient = groupEntriesTitan.get(0).getPatient();
		Map<String,String> metricsMapTitan = getTherapyMetricsMapTitan(groupEntriesTitan,patientDeviceRawData);
		TherapySessionTitan therapySessionTitan = new TherapySessionTitan();
		therapySessionTitan.setSerialNumber(groupEntriesTitan.get(0).getSerialNumber());
		//therapySession.setBluetoothId(groupEntries.get(0).getBluetoothId());
		therapySessionTitan.setDate(LocalDate.fromDateFields(new Date(timestamp)));
		therapySessionTitan.setFrequency(Integer.valueOf(metricsMapTitan.get(FREQUENCY)));
		therapySessionTitan.setIntensity(Integer.valueOf(metricsMapTitan.get(INTENSITY)));
		therapySessionTitan.setDurationInMinutes(Integer.valueOf(metricsMapTitan.get(DURATION)));
		therapySessionTitan.setCaughPauseDuration(Integer.valueOf(metricsMapTitan.get(CAUGH_PAUSE_DURATION)));

		int size = groupEntriesTitan.size();
		therapySessionTitan.setHmr(groupEntriesTitan.get(size-1).getHmr());
		therapySessionTitan.setSessionType(metricsMapTitan.get(SESSION_TYPE));
		therapySessionTitan.setSessionNo(Integer.valueOf(metricsMapTitan.get(SESSION_NO)));
		therapySessionTitan.setStartTime(new DateTime(groupEntriesTitan.get(0).getTimestamp()));
		therapySessionTitan.setEndTime(new DateTime(groupEntriesTitan.get(size-1).getTimestamp()));
		therapySessionTitan.setPatientInfo(patient);
		therapySessionTitan.setPatientUser(patientUser);

		therapySessionTitan.setTherapyIndex(groupEntriesTitan.get(0).getTherapyIndex());
		therapySessionTitan.setNumberOfEvents(groupEntriesTitan.get(0).getNumberOfEvents());		
		therapySessionTitan.setDevWifi(groupEntriesTitan.get(0).getDevWifi());
		therapySessionTitan.setDevBt(groupEntriesTitan.get(0).getDevBt());
		therapySessionTitan.setDevVersion(groupEntriesTitan.get(0).getDevVersion());

		log.debug("assignTherapyMatricsTitan ::"+therapySessionTitan);
		return therapySessionTitan;
	}

	public static List<TherapySessionTitan> groupTherapySessionsByDayTitan(List<TherapySessionTitan> therapySessions)
			throws Exception{
		List<TherapySessionTitan> updatedTherapySessionsTitan = new LinkedList<>();
		Map<LocalDate,List<TherapySessionTitan>> groupByTherapyDate = therapySessions.stream()
				.collect(Collectors.groupingBy(TherapySessionTitan::getDate));
		Iterator<LocalDate> keySetItr = groupByTherapyDate.keySet().iterator();
		while(keySetItr.hasNext()){
			List<TherapySessionTitan> groupedTherapySessions = groupByTherapyDate.get(keySetItr.next());
			for(int i =0 ; i<groupedTherapySessions.size();i++){
				TherapySessionTitan therapySession = groupedTherapySessions.get(i);
				therapySession.setSessionNo(i+1);
				updatedTherapySessionsTitan.add(therapySession);

			}
		}
		return updatedTherapySessionsTitan;
	}

	private static boolean isStartEventForTherapySessionTitan(String eventCode) {
		return EVENT_CODE_START_THEARPY_TITAN.equals(eventCode) ;
	}	 
	
	public static Map<String,String> getTherapyMetricsMapTitan(
			List<PatientVestDeviceDataTitan> deviceEventRecordsTitan, String patientDeviceRawData) {
		Map<String,String> metricsMapTitan = new HashMap<>();

		String decodedString = decodeData(patientDeviceRawData);
		JSONObject jsonDataTitan = ParserUtil.getChargerJsonDataFromRawMessage(decodedString);

		String deviceData = "";
		deviceData = ParserUtilTitan.getValueFromQclJsonDataTitan(jsonDataTitan,DEVICE_DATA);
		log.info("Device Data :" + deviceData);
		
		String[] deviceDataArray = deviceData.split("__");
		
		for(String data : deviceDataArray) {
			if(data.contains(TYPE)) {
				String type = data.split("[=]")[1];
				if(type.equals("1")) {
					metricsMapTitan.put(SESSION_TYPE, SESSION_TYPE_NORMAL);
				}else if(type.equals("2")) {
					metricsMapTitan.put(SESSION_TYPE, SESSION_TYPE_PROGRAM);
				}else {
					metricsMapTitan.put(SESSION_TYPE, SESSION_TYPE_MY_THERAPY);
				}
			}

			if(data.contains(SUMMARY)) {
				String [] strSum = data.split("_");
				
				int durationOfSessionTitan = Integer.parseInt(strSum[1]);
				int totalMinutes = durationOfSessionTitan/SECONDS_PER_MINUTE;
				int remainingSeconds =  durationOfSessionTitan%SECONDS_PER_MINUTE;

				if(remainingSeconds > 50) {
					totalMinutes += 1;
				}
				metricsMapTitan.put(DURATION, String.valueOf(totalMinutes));
				
				String totalCoughPauseDuration = strSum[4];
				metricsMapTitan.put(CAUGH_PAUSE_DURATION, totalCoughPauseDuration);

			}
			
			if(data.contains(SCPS)) {
				
				String caughPauseEnable = data.split("[=,]")[1];
				String caughIntervalMode = data.split(",")[1];
				String caughAutoEnable = data.split(",")[2];
				String caughPauseInterval = data.split(",")[3];
				
				metricsMapTitan.put(CAUGH_PAUSE_ENABLE, caughPauseEnable);
				metricsMapTitan.put(CAUGH_INTERVAL_MODE, caughIntervalMode);
				metricsMapTitan.put(CAUGH_AUTO_ENABLE, caughAutoEnable);
				metricsMapTitan.put(CAUGH_PAUSE_INTERVAL, caughPauseInterval);
			}
			
			if(data.contains(UTNG)) {
				String sessionNo = data.split("[=,]")[1];
				String intensity = data.split(",")[1];
				String frequency = data.split(",")[2];
				
				metricsMapTitan.put(SESSION_NO, sessionNo);
				metricsMapTitan.put(FREQUENCY, frequency);
				metricsMapTitan.put(INTENSITY, intensity);
			}else if(data.contains(STNG)) {
				String sessionNo = data.split("[=,]")[1];
				String intensity = data.split(",")[1];
				String frequency = data.split(",")[2];
				
				metricsMapTitan.put(SESSION_NO, sessionNo);
				metricsMapTitan.put(FREQUENCY, frequency);
				metricsMapTitan.put(INTENSITY, intensity);
			}
		}
		log.info("metricsMapTitan : " + metricsMapTitan);
		return metricsMapTitan;

	}
	
	public static String decodeData(final String rawMessage){
		byte[] decoded = java.util.Base64.getDecoder().decode(rawMessage);

		String decoded_string = new String(decoded);
		log.info("Decoded value is " + decoded_string);
		return decoded_string;
	}
	public static int calculateCumulativeDuration(List<TherapySessionTitan> therapySessions){
		return therapySessions.stream().collect(Collectors.summingInt(TherapySessionTitan::getDurationInMinutes));
	}

	public static String getEventStringByEventCode(String eventId) {
		String retVal;
		int eventCode = Integer.parseInt(eventId);
		switch(eventCode) {
			case 1: 
				retVal = "User starts therapy";
				break;
			case 2:
				retVal = "User pauses the therapy";
				break;
			case 3:
				retVal = "User resumes the therapy";
				break;
			case 4:
				retVal = "User cancels the therapy";
				break;
			case 5:
				retVal = "User changed the therapy settings";
				break;
			case 6:
				retVal = "Cough Pause is activated";
				break;
			case 7:
				retVal = "Cough Pause done. Theapy resumes";
				break;
			case 8:
				retVal = "Cough Pause done. Therapy Pause activated";
				break;
			case 9:
				retVal = "Pause have timed-out.Therapy cancelled ";
				break;
			case 10:
				retVal = "Error was triggered. Therapy cancelled";
				break;
			case 11:
				retVal = "Program therapy step transition";
				break;
			case 12:
				retVal = "Therapy completed";
				break;
			case 13:
				retVal = "Diagnostic code was received";
				break;			
			default:
				retVal = "Unknown";
				break;
		}
		return retVal;
	}
	/**
	 * New excel format Implementation
	 * assignTherapyMatricsTitanExcel
	 * @param groupEntriesTitan
	 * @return
	 */
	private static Map<Long, List<PatientVestDeviceDataTitan>> assignTherapyMatricsTitanExcel(
			List<PatientVestDeviceDataTitan> groupEntriesTitan) {
		
		Map<Long,List<PatientVestDeviceDataTitan>> eventMap = new LinkedHashMap<>();
		long therapyCounter = 0;
		List<PatientVestDeviceDataTitan> therapy = new LinkedList<>();
		
		for(int i = 0;i < groupEntriesTitan.size(); i++){
			PatientVestDeviceDataTitan deviceEventRecord = groupEntriesTitan.get(i);
			log.debug("String Event code from DB:"+deviceEventRecord.getEventCode());
			therapy.add(deviceEventRecord);
		}
		eventMap.put(therapyCounter++,therapy);
		return eventMap;
	}
	/**
	 * new groupEventsToPrepareTherapySessionForTitanExcel
	 * @param deviceDataTitan
	 * @return
	 * @throws CloneNotSupportedException
	 */
	private static Map<DateTime, Map<Integer, Map<Long, List<PatientVestDeviceDataTitan>>>> groupEventsToPrepareTherapySessionForTitanExcel(
			List<PatientVestDeviceDataTitan> deviceDataTitan) throws CloneNotSupportedException {
		
		Collections.sort(deviceDataTitan,PatientVestDeviceDataTitan.titanDateAscComparator);
		  
		//vestTherapyDataMap
		Map<DateTime,Map<Integer,Map<Long,List<PatientVestDeviceDataTitan>>>> titanTherapyData = new LinkedHashMap<>();
		
		//Session Map
		Map<Integer,Map<Long,List<PatientVestDeviceDataTitan>>> outputForExcel = new LinkedHashMap<>();
		
		//Event Map
		Map<Long,List<PatientVestDeviceDataTitan>> therapySessionForDay = new LinkedHashMap<>();
		
		// This List will hold un-finished session events , will be discarded to get delta on next transmission 
		List<PatientVestDeviceDataTitan> eventsToBeDiscardedTitan = new LinkedList<>();
		int conter = 0;
		for(int i = 0;i < deviceDataTitan.size() ; i++){
			PatientVestDeviceDataTitan vestDeviceDataTitan = deviceDataTitan.get(i);
			//String eventCode = vestDeviceData.getEventCode().split(EVENT_CODE_DELIMITER)[0];
			String eventCodeTitan = vestDeviceDataTitan.getEventCode();
			List<PatientVestDeviceDataTitan> groupEntriesTitan = new LinkedList<>();
			if(isStartEventForTherapySessionTitan(eventCodeTitan)){
				groupEntriesTitan.add(vestDeviceDataTitan);
				for(int j = i+1; j < deviceDataTitan.size() ; j++){
					PatientVestDeviceDataTitan nextEventEntryTitan = deviceDataTitan.get(j);
					String nextEventCodeTitan = nextEventEntryTitan.getEventCode();
						// Group entry if the nextEvent is not a start event
						if(!isStartEventForTherapySessionTitan(nextEventCodeTitan))
							groupEntriesTitan.add(nextEventEntryTitan);
					if(isCompleteOrInCompleteEventForTherapySessionTitan(nextEventCodeTitan)
						|| isStartEventForTherapySessionTitan(nextEventCodeTitan)	){
						// subsequent start events indicate therapy is incomplete due to unexpected reason
						if(isStartEventForTherapySessionTitan(nextEventCodeTitan)){
							PatientVestDeviceDataTitan inCompleteEventTitan = (PatientVestDeviceDataTitan) groupEntriesTitan.get(groupEntriesTitan.size()-1).clone();
							if(groupEntriesTitan.get(0).getEventCode().equals(EVENT_CODE_THEARPY_COMPLETE_TITAN))
								inCompleteEventTitan.setEventCode(EVENT_CODE_THEARPY_PAUSED_TITAN);
							
							inCompleteEventTitan.setDuration(0);// DO NOT CHANGE: This is the indication, dummy event has been added for making session
							inCompleteEventTitan.setFrequency(0);
							inCompleteEventTitan.setIntensity(0);
							groupEntriesTitan.add(inCompleteEventTitan);// Add dummy incomplete event to finish the session
							deviceDataTitan.add(j, inCompleteEventTitan);
						}
						
						therapySessionForDay = assignTherapyMatricsTitanExcel(groupEntriesTitan);
						
						i=j; // to skip the events iterated, shouldn't be removed in any case
						break;
					}else if(j == deviceDataTitan.size()-1){
						//will be discarded to get delta on next transmission
						log.debug("Discarding the events to make session with delta on next transmission");
						log.debug("Events List"+groupEntriesTitan);
						eventsToBeDiscardedTitan.addAll(groupEntriesTitan);
						i=j; // to skip the events iterated, shouldn't be removed in any case
						break;
					}
				}
				outputForExcel.put(conter++, therapySessionForDay);
				log.debug("No. of Sessions for the Day : "+outputForExcel.size());
			}
		}
		// Discarding these events to make session from delta
		if (eventsToBeDiscardedTitan.size() > 0) {
			deviceDataTitan.removeAll(eventsToBeDiscardedTitan);
		}
		titanTherapyData.put(new DateTime(), outputForExcel);
		log.debug("No. of Session for Data Range : "+titanTherapyData.size());
		
		return titanTherapyData;
	}

	/**
	 * //new Excel method for Titan
	 * @param deviceEventsList
	 * @return
	 * @throws CloneNotSupportedException
	 */
	
	public static Map<DateTime, Map<Integer, Map<Long, List<PatientVestDeviceDataTitan>>>> prepareTherapySessionFromDeviceTitanDataForExcel(
			List<PatientVestDeviceDataTitan> deviceEventsList) throws CloneNotSupportedException {
		Map<DateTime,Map<Integer,Map<Long,List<PatientVestDeviceDataTitan>>>> therapySessions = groupEventsToPrepareTherapySessionForTitanExcel(deviceEventsList);
		return therapySessions;
	}
	private static Integer getTotalDurationForWeightedAvgCalculationTitan(
			List<PatientVestDeviceDataTitan> deviceEventRecords) {
		int totalDuration = 0;
		for(int i = 0;i <deviceEventRecords.size();i++ ){
			PatientVestDeviceDataTitan eventRecord = deviceEventRecords.get(i);
			totalDuration += eventRecord.getDuration();
		}
		return totalDuration;
	}
	public static double calculateWeightedAvg(double totalDuration,int durationInMinutes,
			Integer frequency) {
		if(totalDuration == 0) // safety check for divided by 0 exception
			return 0;
		return (durationInMinutes*frequency/totalDuration);
	}
	
	private static int calculateCoughPauseTitan(
			List<PatientVestDeviceDataTitan> deviceEventRecordsTitan,int startCoughPause, int endCoughPause) {
		// HMR Difference
		

		long endCoughPauseHMR = deviceEventRecordsTitan.get(endCoughPause).getTimestamp();
		long startCoughPauseHMR = deviceEventRecordsTitan.get(startCoughPause).getTimestamp();
		int coughPauseDuration = (int)Math.round((endCoughPauseHMR - startCoughPauseHMR)/1000);

		
		return coughPauseDuration;		
	}
	
	private static boolean isStartCoughPauseTitan(
			PatientVestDeviceDataTitan deviceEventRecord) {
		return deviceEventRecord.getEventCode().startsWith(EVENT_CODE_COUGH_PAUSE_START_TITAN);
	}
	
	private static boolean isEndCoughPauseTitan(
			PatientVestDeviceDataTitan deviceEventRecord) {
		return (deviceEventRecord.getEventCode().startsWith(EVENT_CODE_COUGH_PAUSE_END_TITAN) 
				|| deviceEventRecord.getEventCode().startsWith(EVENT_CODE_THEARPY_INCOMPLETE_TITAN) 
				|| deviceEventRecord.getEventCode().startsWith(EVENT_CODE_THEARPY_COMPLETE_TITAN) );
		
	}
	
	private static int calculateDurationOfSessionTitan(
			List<PatientVestDeviceDataTitan> deviceEventRecordsTitan) {
		// Duration of the device was run
		PatientVestDeviceDataTitan endOfSessionEvent = deviceEventRecordsTitan.get(deviceEventRecordsTitan.size()-1);
		long endTimestamp = endOfSessionEvent.getTimestamp();
		long startTimestamp = deviceEventRecordsTitan.get(0).getTimestamp();
		int totalDuration = (int) Math.round((endTimestamp-startTimestamp)/1000);
		
		
		// HILL-1384 : since it is observed , hmr being corrupted
		/*if(hmrDiff > totalDuration)
			return totalDuration;
		else
			return hmrDiff;*/
		
		// Not consider the HMR, and considering only the timestamp difference
		return totalDuration;
		
	}
	public static Map<String,Integer> getTherapyMetricsMapTitan(
			List<PatientVestDeviceDataTitan> deviceEventRecordsTitan) {
		Map<String,Integer> metricsMapTitan = new HashMap<>();
		//int durationOfSession = 0, normalCoughPauses = 0, programmedCoughPauses = 0, caughPauseDuration = 0;

		int totalCoughPauseDuration = 0;
		int durationOfSessionTitan = 0, coughPauses = 0, caughPauseDuration = 0;
		int durationForWeightedAvgCalcTitan = getTotalDurationForWeightedAvgCalculationTitan(deviceEventRecordsTitan);
		float frequency = 0, intensity = 0;
		int startCoughPause=-1, endCoughPause = -1;
		for(int i = 0;i < deviceEventRecordsTitan.size(); i ++){
			PatientVestDeviceDataTitan deviceEventRecordTitan = deviceEventRecordsTitan.get(i);
			frequency += calculateWeightedAvg( durationForWeightedAvgCalcTitan,deviceEventRecordTitan.getDuration(),deviceEventRecordTitan.getFrequency());
			intensity += calculateWeightedAvg(durationForWeightedAvgCalcTitan,deviceEventRecordTitan.getDuration(),deviceEventRecordTitan.getIntensity());

			
		
				if(isStartCoughPauseTitan(deviceEventRecordTitan)){			
					++coughPauses;
					startCoughPause = i;
				}
			
				if(isEndCoughPauseTitan(deviceEventRecordTitan))
				{
					endCoughPause = i;
				
			}
			
			if(startCoughPause>0 && endCoughPause>0 
					&& (endCoughPause == (startCoughPause+1) 
							|| endCoughPause == (startCoughPause+2))){
				caughPauseDuration = calculateCoughPauseTitan(deviceEventRecordsTitan,startCoughPause, endCoughPause);
				totalCoughPauseDuration += caughPauseDuration; 
				startCoughPause = -1;
			}
			
		
			
		}
		durationOfSessionTitan = calculateDurationOfSessionTitan(deviceEventRecordsTitan);
		
		int totalMinutes = (durationOfSessionTitan-totalCoughPauseDuration)/SECONDS_PER_MINUTE;
		int remainingSeconds =  (durationOfSessionTitan-totalCoughPauseDuration)%SECONDS_PER_MINUTE;
		
		if(remainingSeconds > 50) {
			totalMinutes += 1;
		}
		metricsMapTitan.put(FREQUENCY, Math.round(frequency));
		metricsMapTitan.put(INTENSITY, Math.round(intensity));
		metricsMapTitan.put(DURATION, totalMinutes);
		metricsMapTitan.put(CAUGH_PAUSES, coughPauses);
		metricsMapTitan.put(CAUGH_PAUSE_DURATION, totalCoughPauseDuration);

		return metricsMapTitan;
	}
		}
	
