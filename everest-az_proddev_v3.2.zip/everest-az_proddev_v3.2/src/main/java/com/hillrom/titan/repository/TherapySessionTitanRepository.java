package com.hillrom.titan.repository;


import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.TherapySessionTitan;

public interface TherapySessionTitanRepository extends
		JpaRepository<TherapySessionTitan, Long> {

	public TherapySessionTitan findTop1ByPatientUserIdOrderByEndTimeDesc(Long patientUserId);

	@Query("from TherapySessionTitan tps where tps.patientUser.id =?1 and duration_in_minutes > 0 and tps.date between ?2 and ?3")
	public List<TherapySessionTitan> findByPatientUserIdAndDateRange(Long patientUserId, LocalDate fromTimestamp,
			LocalDate toTimestamp);

	@Query("from TherapySessionTitan tps where tps.patientUser.id =?1 and tps.date = ?2")
	public List<TherapySessionTitan> findByPatientUserIdAndDate(Long patientUserId,
			LocalDate dateTime);

	public TherapySessionTitan findTop1ByPatientUserIdOrderByDateAsc(Long patientUserId);

	public List<TherapySessionTitan> findTop1ByPatientUserIdInOrderByEndTimeDesc(List<Long> patientUserIds);

	public List<TherapySessionTitan> findByDateBetweenAndPatientUserIdIn(LocalDate fromTimestamp,
			LocalDate toTimestamp,List<Long> patientUserIds);

	public List<TherapySessionTitan> findByDateBetweenAndPatientUserId(LocalDate fromTimestamp,
			LocalDate toTimestamp,Long patientUserId);

	public TherapySessionTitan findTop1ByPatientUserIdAndDateBeforeOrderByEndTimeDesc(Long patientUserId,LocalDate from);

	public List<TherapySessionTitan> findByPatientUserId(Long patientUserId);

	@Query(nativeQuery=true,value="SELECT count(*) FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtdm WHERE pvtdm.patient_id = ?3 and (pvtdm.date between ?1 AND ?2) and pvtdm.duration_in_minutes>=?4")
	public int findByDateBetweenAndPatientInfoIdByDuration(String fromTimestamp, String toTimestamp, String patientInfoId, int duration);

	@Query(nativeQuery=true,value="SELECT hmr from PATIENT_VEST_THERAPY_DATA_TITAN where id=(SELECT id from PATIENT_VEST_THERAPY_DATA_TITAN tps where tps.patient_id=?1 and tps.serial_number=?2 and CAST(convert_tz(start_time, '+00:00', ?4) as date) < ?3 order by convert_tz(start_time, '-00:00', ?4) DESC LIMIT 1)")
	Double findHmrByPatientIdAndSerialNumberBeforeDate(String patientId,String serialNo, String date, String timeZone);

	@Query(nativeQuery=true,value="SELECT * from PATIENT_VEST_THERAPY_DATA_TITAN where id=(SELECT id from PATIENT_VEST_THERAPY_DATA_TITAN tps where tps.patient_id=?1 and tps.serial_number=?2 and CAST(convert_tz(start_time, '+00:00', ?4) as date) < ?3 order by convert_tz(start_time, '-00:00', ?4) DESC LIMIT 1)")
	public Optional<TherapySessionTitan> findByPatientIdAndSerialNumberBeforeDate(String patientId,String serialNo, String date, String timeZone);

	@Query(nativeQuery=true,value=" SELECT count(*) from PATIENT_VEST_THERAPY_DATA_TITAN tpsm where tpsm.patient_id = ?1 and tpsm.date > ?2")
	 int findCountByPatientIdAndMobileRegistrtionDate(String patientId,String registrtionDate);
	@Query("from TherapySessionTitan tps where tps.patientInfo.id =?3 and tps.date between ?1 and ?2 and tps.durationInMinutes > 0")
	public List<TherapySessionTitan> findByDateBetweenAndPatientInfoId(LocalDate fromTimestamp,
            LocalDate toTimestamp,String patientInfoId);
	@Query(nativeQuery=true,value="SELECT * FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtdm WHERE pvtdm.patient_id = ?3 AND pvtdm.start_time >= from_unixtime(?1/1000) AND pvtdm.end_time <= from_unixtime(?2/1000) ORDER BY pvtdm.start_time DESC LIMIT ?4 OFFSET ?5")
	public List<TherapySessionTitan> findByDateBetweenAndPatientInfoIdOrderByStartTimeDesc(Long from, Long to, String patient_id, int pageSz, int offset);
	@Query(nativeQuery=true,value="SELECT * FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtdm WHERE pvtdm.patient_id = ?3 AND pvtdm.start_time >= from_unixtime(?1/1000) AND pvtdm.end_time <= from_unixtime(?2/1000) ORDER BY pvtdm.start_time ASC LIMIT ?4 OFFSET ?5")
	public List<TherapySessionTitan> findByDateBetweenAndPatientInfoIdOrderByStartTimeAsc(Long from, Long to, String patient_id, int pageSz, int offset);
	@Query(nativeQuery=true,value="SELECT * FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtd WHERE pvtd.patient_id = ?3 AND pvtd.start_time >= ?1 AND pvtd.end_time <= ?2 GROUP BY pvtd.session_type")
	public List<TherapySessionTitan> findByPatientIdAndDateBetween(DateTime dayStart, DateTime dayEnd, String patientId);
	public List<TherapySessionTitan> findByPatientInfoIdAndDate(String patientId, LocalDate date);
	@Query(nativeQuery=true,value="SELECT * FROM PATIENT_VEST_THERAPY_DATA_TITAN pvtd WHERE pvtd.patient_id = ?1 AND pvtd.start_time = from_unixtime(?2)")
	public List<TherapySessionTitan> findByPatientInfoIdAndStartTime(String patientId, Long start_time);
	@Query(nativeQuery=true,value="SELECT unix_timestamp(COALESCE(max(tps.start_time),'0000-00-00'))*1000 from PATIENT_VEST_THERAPY_DATA_TITAN tps where tps.patient_id =?1 and tps.date between ?2 and ?3")
	public Long findMaxByPatientIdBetweenDateRange(String patientId,String from, String to);

	@Query(nativeQuery=true,value="SELECT unix_timestamp(COALESCE(min(tps.start_time),'0000-00-00'))*1000 from PATIENT_VEST_THERAPY_DATA_TITAN tps where tps.patient_id =?1")
	public Long findMinDateByPatientId(String patientId);
}