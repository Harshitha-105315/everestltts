package com.hillrom.titan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.RemoteTherapyUpdateTitan;



public interface RemoteTherapyUpdateTitanRepository extends JpaRepository<RemoteTherapyUpdateTitan, String> {
	
	@Query("from RemoteTherapyUpdateTitan rtu where rtu.patientId= ?1")
		List<RemoteTherapyUpdateTitan> findByPatientId(String patientId);
}
