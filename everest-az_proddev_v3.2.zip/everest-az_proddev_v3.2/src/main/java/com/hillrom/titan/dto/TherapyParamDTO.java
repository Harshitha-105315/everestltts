package com.hillrom.titan.dto;

public class TherapyParamDTO {

	int duration;
	int frequency;
	int intensity;
	int step;
	
	public TherapyParamDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TherapyParamDTO(int duration, int frequency, int intensity, int step) {
		super();
		this.duration = duration;
		this.frequency = frequency;
		this.intensity = intensity;
		this.step = step;
	}

	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public int getIntensity() {
		return intensity;
	}
	public void setIntensity(int intensity) {
		this.intensity = intensity;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	
	@Override
	public String toString() {
		return "TherapyParamDTO [duration=" + duration + ", frequency=" + frequency + ", intensity=" + intensity
				+ ", step=" + step + "]";
	}
	
}
