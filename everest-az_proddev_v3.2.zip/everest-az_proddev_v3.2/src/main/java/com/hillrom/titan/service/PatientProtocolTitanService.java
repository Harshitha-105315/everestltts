package com.hillrom.titan.service;

import static com.hillrom.vest.config.AdherenceScoreConstants.UPPER_BOUND_VALUE;
import static com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil.calculateWeightedAvg;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hillrom.titan.repository.PatientProtocolTitanRepository;
import com.hillrom.titan.repository.ProtocolConstantsTitanRepository;
import com.hillrom.titan.web.rest.dto.ProtocolEntryTitanDTO;
import com.hillrom.titan.web.rest.dto.ProtocolTitanDTO;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolDataTitan;
import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.security.SecurityUtils;
import com.hillrom.vest.service.MailService;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;

/**
 * Service class for managing users.
 */
@Service
@Transactional
public class PatientProtocolTitanService { 

	private final Logger log = LoggerFactory.getLogger(PatientProtocolTitanService.class);
	
    @Inject
    private UserRepository userRepository;
    
    @Inject
    private PatientProtocolTitanRepository patientProtocolTitanRepository;
    
    @Inject
    private ProtocolConstantsTitanRepository protocolConstantsTitanRepository;
    
    @Inject
	private MailService mailService;
    
    public List<PatientProtocolDataTitan> updateProtocolToPatient(Long patientUserId, List<PatientProtocolDataTitan> ppdList)
			throws HillromException {
	User patientUser = userRepository.findOne(patientUserId);
	if (patientUser != null) {
		PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
		if (patientInfo != null) {
			List<PatientProtocolDataTitan> protocolList = new LinkedList<>();
			int treatmentsPerDay = ppdList.get(0).getTreatmentsPerDay();
			String type = ppdList.get(0).getType();
			String protocolKey = ppdList.get(0).getProtocolKey();
			// Check whether protocol type is same
			Boolean isFirstPoint = true;
			PatientProtocolDataTitan existingPPD = patientProtocolTitanRepository.findOne(ppdList.get(0).getId());
			//If not same
			if (Objects.nonNull(existingPPD)) {
				deleteProtocolForPatient(patientUserId, protocolKey);
			}
			
			String protocolId = null;

			for (PatientProtocolDataTitan ppd : ppdList) {
				if(!ppd.isDeleted())
				{
					if (isFirstPoint) {
						protocolKey = patientProtocolTitanRepository.id();
						protocolId = protocolKey;
						isFirstPoint = false;
					} else {
						protocolId = patientProtocolTitanRepository.id();
					}
					addProtocolByProtocolKey(patientUser, patientInfo, protocolList, treatmentsPerDay, type,
							protocolKey, ppd, protocolId);
				}
			}

			try {
				if(Objects.nonNull(patientUser.getEmail()))
					mailService.sendUpdateProtocolMailToPatientTitan(patientUser, protocolList);
				if(SecurityContextHolder.getContext().getAuthentication()
						.getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.HCP)) || SecurityContextHolder.getContext()
						.getAuthentication()
						.getAuthorities().contains(new SimpleGrantedAuthority(AuthoritiesConstants.CLINIC_ADMIN))){ 
					Optional<User> currentUser = userRepository
						.findOneByEmailOrHillromId(SecurityUtils.getCurrentLogin());
					mailService.sendUpdateProtocolMailToMailingListTitan(currentUser.get(), patientUser, protocolList);
				}
			} catch (Exception ex) {
				StringWriter writer = new StringWriter();
				PrintWriter printWriter = new PrintWriter(writer);
				ex.printStackTrace(printWriter);
			}
			return protocolList;
		} else {
			throw new HillromException(ExceptionConstants.HR_523);
		}
	} else
		throw new HillromException(ExceptionConstants.HR_512);
    }

    public List<PatientProtocolDataTitan> getActiveProtocolsAssociatedWithPatient(Long patientUserId) throws HillromException {
    	User patientUser = userRepository.findOne(patientUserId);
    	if(patientUser != null) {
	    	PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
	     	if(patientInfo != null){
	     		List<PatientProtocolDataTitan> protocolAssocList = patientProtocolTitanRepository.findByPatientIdAndActiveStatus(patientInfo.getId());
	     		if(protocolAssocList.isEmpty()){
	     			return new LinkedList<PatientProtocolDataTitan>();
	     		} else {
	     			return getProtocolDetails(patientUserId, protocolAssocList.get(0).getProtocolKey());
	     		}
	     	} else {
	     		throw new HillromException(ExceptionConstants.HR_523);
		 	}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);
     	}
    }
    
    public List<PatientProtocolDataTitan> getProtocolDetails(Long patientUserId, String protocolId) throws HillromException {
    	User patientUser = userRepository.findOne(patientUserId);
    	if(patientUser != null) {
	    	PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
	     	if(patientInfo != null){
	     		List<PatientProtocolDataTitan> protocolAssocList = patientProtocolTitanRepository.findByProtocolKey(protocolId);
	     		if(protocolAssocList.isEmpty()){
	     			return new LinkedList<PatientProtocolDataTitan>();
	     		} else {
	     			List<PatientProtocolDataTitan> protocolAssocListToSave = new LinkedList<>();
	     			for(PatientProtocolDataTitan protocolAssoc: protocolAssocList){
	     				protocolAssoc.setDeviceType("TITAN");
	     				patientProtocolTitanRepository.save(protocolAssoc);
	     				protocolAssocListToSave.add(protocolAssoc);
	     			}
	     			//return protocolAssocList;
	     			return protocolAssocListToSave;
	     		}
	     	} else {
	     		throw new HillromException(ExceptionConstants.HR_523);
		 	}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);
     	}
    }

	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for(UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()){
			if(RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())){
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}
	
	public String deleteProtocolForPatient(Long patientUserId, String protocolId) throws HillromException {
	User patientUser = userRepository.findOne(patientUserId);
	if(patientUser != null) {
    	PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
     	if(patientInfo != null){
     		List<PatientProtocolDataTitan> protocolList = patientProtocolTitanRepository.findByProtocolKey(protocolId);
     		if(protocolList.isEmpty()){
     			throw new HillromException(ExceptionConstants.HR_551);
     		} else {
     			protocolList.forEach(protocol -> {
     				protocol.setDeleted(true);
     				//When deleting last modified date needs to be updated
     				//one sec less than the new created Date to recognize 
     				//new and old separately
     				protocol.setLastModifiedDate(new DateTime().minusSeconds(1));
     				patientProtocolTitanRepository.save(protocol);
     			});
     			return MessageConstants.HR_244;
     		}
     	} else {
     		throw new HillromException(ExceptionConstants.HR_523);
	 	}
	} else {
		throw new HillromException(ExceptionConstants.HR_512);
 	}
	}
	/**
	 * Get Protocol Constants by loading Protocol data for user Id
	 * @param Long patientUserId
	 * @return ProtocolConstants
	 */
	public ProtocolConstantsTitan getProtocolForPatientUserId(
			Long patientUserId) throws Exception{
		List<PatientProtocolDataTitan> protocol =  findOneByPatientUserIdAndStatus(patientUserId,false);
		
		ProtocolConstantsTitan userIdProtocolConstant;
		
		if(Objects.nonNull(protocol) && protocol.size() > 0){			
			String protocolType = protocol.get(0).getType();
			if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(protocolType)){
				userIdProtocolConstant = getProtocolConstantFromNormalProtocol(protocol);
			}else{
				userIdProtocolConstant = getProtocolConstantFromCustomProtocol(protocol);
			}
		}else{
			userIdProtocolConstant = protocolConstantsTitanRepository.findOne(1L);
		}
		return userIdProtocolConstant;
	}

	public Boolean isProtocolValidForDate(PatientProtocolDataTitan ppd, Long date) {
		if(	(	ppd.isDeleted() 
					&& ppd.getCreatedDate().toLocalDate().toDateTimeAtStartOfDay().getMillis() <= date 
					&& ppd.getLastModifiedDate().toLocalDate().toDateTimeAtStartOfDay().getMillis() >= date )					
					|| 
					(	!ppd.isDeleted() && date > ppd.getCreatedDate().toLocalDate().toDateTimeAtStartOfDay().getMillis())
				)
		{
			return true;
		}
		return false;
	}
	
	public List<PatientProtocolDataTitan> findOneByPatientUserIdAndStatus(Long PatientUserId,boolean isDeleted){
		return patientProtocolTitanRepository.findByPatientUserIdAndDeleted(PatientUserId, isDeleted);
	} 
	private void addProtocolByProtocolKey(User patientUser, PatientInfo patientInfo,
			List<PatientProtocolDataTitan> protocolList, int treatmentsPerDay, String type, String protocolKey,
			PatientProtocolDataTitan ppd, String protocolId) {
		PatientProtocolDataTitan patientProtocolAssoc = new PatientProtocolDataTitan(type, patientInfo, patientUser,
				treatmentsPerDay, ppd.getMinMinutesPerTreatment(),ppd.getTreatmentLabel(),
				ppd.getMinFrequency(), ppd.getMaxFrequency(), ppd.getMinIntensity(),
				ppd.getMaxIntensity());
		if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(type))
			patientProtocolAssoc.setTreatmentLabel("");
		
		patientProtocolAssoc.setId(protocolId);
		patientProtocolAssoc.setProtocolKey(protocolKey);
		patientProtocolAssoc.setLastModifiedDate(DateTime.now().plusSeconds(1));
		patientProtocolTitanRepository.saveAndFlush(patientProtocolAssoc);
		protocolList.add(patientProtocolAssoc);
	}
	
	public List<PatientProtocolDataTitan> addProtocolToPatient(Long patientUserId, ProtocolTitanDTO protocolDTO) throws HillromException {
    	if(Constants.CUSTOM_PROTOCOL.equals(protocolDTO.getType())){
    		if(protocolDTO.getProtocolEntries().size() < 1 || protocolDTO.getProtocolEntries().size() > 7){
    			throw new HillromException(ExceptionConstants.HR_552);
    		}
    	}
    	User patientUser = userRepository.findOne(patientUserId);
		if(patientUser != null) {
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
		 	if(patientInfo != null){
		 		String protocolKey = patientProtocolTitanRepository.id();
		 	    List<PatientProtocolDataTitan> protocolList = new LinkedList<>();
		 	    Boolean isFirstPoint = true;
		 		for(ProtocolEntryTitanDTO protocolEntry : protocolDTO.getProtocolEntries()){
		 			PatientProtocolDataTitan patientProtocolAssoc = new PatientProtocolDataTitan(protocolDTO.getType(), patientInfo, patientUser,
		 					protocolDTO.getTreatmentsPerDay(), protocolEntry.getMinMinutesPerTreatment(), protocolEntry.getTreatmentLabel(),
		 					protocolEntry.getMinFrequency(), protocolEntry.getMaxFrequency(), protocolEntry.getMinIntensity(), protocolEntry.getMaxIntensity());
		 			if(isFirstPoint) {
		 				patientProtocolAssoc.setId(protocolKey);
		 				isFirstPoint = false;
		 			} else {
		 				patientProtocolAssoc.setId(patientProtocolTitanRepository.id());
		 			}
		 			patientProtocolAssoc.setProtocolKey(protocolKey);
		 			protocolList.add(patientProtocolAssoc);
		 		}
		 		patientProtocolTitanRepository.save(protocolList);
		 		return protocolList;
		 	} else {
		 		throw new HillromException(ExceptionConstants.HR_523);
		 	}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);
		}
    }

	public Map<LocalDate, Map<String, Integer>> getProtocolDurationAndTreatmentsByDate(String patientId, LocalDate startDate, LocalDate endDate)
	{
		ProtocolConstantsTitan constant = null;
		Map<LocalDate, Map<String, Integer>> result = new HashMap<LocalDate, Map<String, Integer>>();
		LocalDate tempStart = startDate;

		List<PatientProtocolDataTitan>  protocolList = patientProtocolTitanRepository.findByPatientIdOrderByCreatedDateAsc(patientId);
		
		constant = protocolConstantsTitanRepository.findOne(1L);

		while(tempStart.isBefore(endDate)) {
			Map<String, Integer> dayData =result.get(tempStart);  
			if(Objects.isNull(dayData)){
				dayData = new HashMap<String,Integer>();
			}

			dayData.put(Constants.DURATION, constant.getMinMinutesPerTreatment()*constant.getTreatmentsPerDay());
			dayData.put(Constants.TREATMENTS_PER_DAY, constant.getTreatmentsPerDay());
			result.put(tempStart, dayData);
			tempStart = tempStart.plusDays(1);
		}
		
		for (PatientProtocolDataTitan ppd : protocolList) {
			if (isProtocolValidForDate(ppd, startDate.toDateTimeAtStartOfDay().getMillis())) { 
				List<PatientProtocolDataTitan> protocol = patientProtocolTitanRepository.findByProtocolKey(ppd.getProtocolKey());
				if(Objects.nonNull(protocol) && protocol.size() > 0){			
					String protocolType = protocol.get(0).getType();
					if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(protocolType)){
						constant = getProtocolConstantFromNormalProtocol(protocol);
					}else{
						constant = getProtocolConstantFromCustomProtocol(protocol);
					}
				}else{
					constant = protocolConstantsTitanRepository.findOne(1L);
				}
				
				LocalDate ppdStartDate = ppd.getCreatedDate().toLocalDate();
				LocalDate ppdEndDate = ppd.isDeleted()?ppd.getLastModifiedDate().toLocalDate():LocalDate.now();
				
				LocalDate fromDate = ppdStartDate.isBefore(startDate)?startDate:ppdStartDate;
				LocalDate toDate = ppdEndDate.isBefore(endDate)?ppdEndDate:endDate;
				
				while(fromDate.isBefore(toDate)) {
					Map<String, Integer> dayData =result.get(fromDate);  
					if(Objects.isNull(dayData)){
						dayData = new HashMap<String,Integer>();
					}

					dayData.put(Constants.DURATION, constant.getMinMinutesPerTreatment());
					dayData.put(Constants.TREATMENTS_PER_DAY, constant.getTreatmentsPerDay());

					result.put(fromDate, dayData);
					fromDate = fromDate.plusDays(1);
				}
			}
		}
		return result;

	}
	
	public ProtocolConstantsTitan getProtocolConstantFromNormalProtocol(
			List<PatientProtocolDataTitan> protocolData) {
		int maxFrequency,minFrequency,minIntensity,maxIntensity,minDuration,treatmentsPerDay;
		PatientProtocolDataTitan protocol = protocolData.get(0); 
		maxFrequency = protocol.getMaxFrequency();
		minFrequency = protocol.getMinFrequency();
		maxIntensity = protocol.getMaxIntensity();
		minIntensity = protocol.getMinIntensity();
		treatmentsPerDay = protocol.getTreatmentsPerDay();
		minDuration = protocol.getMinMinutesPerTreatment() * protocol.getTreatmentsPerDay();
		return new ProtocolConstantsTitan(maxFrequency,minFrequency,maxIntensity,minIntensity,treatmentsPerDay,minDuration);
	}

	public ProtocolConstantsTitan getProtocolConstantFromCustomProtocol(
			List<PatientProtocolDataTitan> protocolData) {
		int maxFrequency,minFrequency,minIntensity,maxIntensity,minDuration,treatmentsPerDay;
		float weightedAvgFrequency = 0,weightedAvgIntensity = 0;
		double totalDuration = protocolData.stream().collect(Collectors.summingDouble(PatientProtocolDataTitan :: getMinMinutesPerTreatment));
		for(PatientProtocolDataTitan protocol : protocolData){
			weightedAvgFrequency += calculateWeightedAvg(totalDuration, protocol.getMinMinutesPerTreatment(), protocol.getMinFrequency());
			weightedAvgIntensity += calculateWeightedAvg(totalDuration, protocol.getMinMinutesPerTreatment(), protocol.getMinIntensity());
		}
		treatmentsPerDay = protocolData.get(0).getTreatmentsPerDay();
		minFrequency = Math.round(weightedAvgFrequency);
		maxFrequency = (int) Math.round(minFrequency*UPPER_BOUND_VALUE);
		minIntensity = Math.round(weightedAvgIntensity);
		maxIntensity = (int) Math.round(minIntensity*UPPER_BOUND_VALUE);
		minDuration = (int)(totalDuration*treatmentsPerDay);
		return new ProtocolConstantsTitan(maxFrequency,minFrequency,maxIntensity,minIntensity,treatmentsPerDay,minDuration);
	}
	
	private Map<Long, List<PatientProtocolDataTitan>> prepareUserIdProtocolMap(
			List<PatientProtocolDataTitan> protocolData) {
		Map<Long, List<PatientProtocolDataTitan>> userIdProtocolMap = new HashMap<>();
		for(PatientProtocolDataTitan protocol : protocolData){
			List<PatientProtocolDataTitan> protocolForUserId = userIdProtocolMap.get(protocol.getPatientUser().getId());
			if(Objects.isNull(protocolForUserId)){
				protocolForUserId = new LinkedList<>();
			}
			protocolForUserId.add(protocol);
			userIdProtocolMap.put(protocol.getPatientUser().getId(), protocolForUserId);
		}
		return userIdProtocolMap;
	}
	
	public List<PatientProtocolDataTitan> findByPatientUserIds(List<Long> patientUserIds){
		return patientProtocolTitanRepository.findByDeletedAndPatientUserIdIn(false,patientUserIds);
	}
	
	/**
	 * Get Protocol Constants by loading Protocol data
	 * @param List<Long> patientUserIds
	 * @return Map<Long,ProtocolConstants>
	 */
	public Map<Long,ProtocolConstantsTitan> getProtocolByPatientUserIds(
			List<Long> patientUserIds) throws Exception{
		List<PatientProtocolDataTitan> protocolData =  findByPatientUserIds(patientUserIds);
		
		Map<Long, List<PatientProtocolDataTitan>> userIdProtocolMap = prepareUserIdProtocolMap(protocolData);
		Map<Long,ProtocolConstantsTitan> userIdProtocolConstantsMap = new HashMap<>();
		for(Long patientUserId : patientUserIds){
			List<PatientProtocolDataTitan> protocol = userIdProtocolMap.get(patientUserId);
			if(Objects.nonNull(protocol) && protocol.size() > 0){			
				String protocolType = protocol.get(0).getType();
				if(Constants.NORMAL_PROTOCOL.equalsIgnoreCase(protocolType)){
					userIdProtocolConstantsMap.put(patientUserId,getProtocolConstantFromNormalProtocol(protocol));
				}else{
					userIdProtocolConstantsMap.put(patientUserId,getProtocolConstantFromCustomProtocol(protocol));
				}
			}else{
				userIdProtocolConstantsMap.put(patientUserId,protocolConstantsTitanRepository.findOne(1L));
			}
		}
		return userIdProtocolConstantsMap;
	}
	
	
	

}