package com.hillrom.titan.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hillrom.vest.domain.ProtocolConstantsTitan;
import com.hillrom.vest.service.AdherenceCalculationService;
import com.hillrom.vest.service.TherapySessionService;

@Service
@Transactional
public class AdherenceCalculationServiceTitan{

	@Inject
	private PatientProtocolTitanService protocolTitanService;
	
	@Inject
	@Lazy
	private AdherenceCalculationService adherenceCalculationService;
	
	@Inject
	@Lazy
	private TherapySessionService therapySessionService;


	
	
	private final Logger log = LoggerFactory.getLogger(AdherenceCalculationServiceTitan.class);
	
	/**
	 * Get Protocol Constants by loading Protocol data
	 * @param patientUserId
	 * @return
	 */
	public ProtocolConstantsTitan getProtocolByPatientUserId(
			Long patientUserId) throws Exception{
		List<Long> patientUserIds = new LinkedList<>();
		patientUserIds.add(patientUserId);
		Map<Long,ProtocolConstantsTitan> userIdProtolConstantsMap = protocolTitanService.getProtocolByPatientUserIds(patientUserIds);
		return userIdProtolConstantsMap.get(patientUserId);
	}

}