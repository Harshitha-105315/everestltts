package com.hillrom.titan.repository;

import java.util.List;
import java.util.Optional;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.PatientVestDevicePK;

public interface PatientTitanDeviceRepository extends
		JpaRepository<PatientVestDeviceHistoryTitan, PatientVestDevicePK> {
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.serialNumber = ?1  and pvd.active = true")
	List<PatientVestDeviceHistoryTitan> findOneBySerialNumberAndStatusActive(String serialNumber);
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1")
	List<PatientVestDeviceHistoryTitan> findByPatientId(String patientId);
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.serialNumber = ?1")
	List<PatientVestDeviceHistoryTitan> findBySerialNumber(String serialNumber);

	@Query(nativeQuery = true, value = "SELECT * FROM PATIENT_VEST_DEVICE_HISTORY_TITAN pvd where patient_id = :patientId and is_active = :isActive limit 1 ")
	PatientVestDeviceHistoryTitan findLatestActiveDeviceByPatientId(@Param("patientId")String pateitnId, @Param("isActive")Boolean active);
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.wifiId = ?1 and pvd.active = true")
	List<PatientVestDeviceHistoryTitan> findByWifiIdAndStatusActive(String wifiId);

	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.active = ?2")
	Optional<PatientVestDeviceHistoryTitan> findOneByPatientIdAndActiveStatus(String patientId, Boolean active);
	
	@Query(nativeQuery = true, value = "SELECT * FROM PATIENT_VEST_DEVICE_HISTORY_TITAN pvd where patient_id = :patientId and is_active = :isActive order by last_modified_by desc limit 1 ")
	PatientVestDeviceHistoryTitan findLatestInActiveDeviceByPatientId(@Param("patientId")String pateitnId, @Param("isActive")Boolean active);
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.pending = ?2")
	Optional<PatientVestDeviceHistoryTitan> findOneByPatientIdAndPendingStatus(String patientId, Boolean pending);

	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.patientVestDevicePK.serialNumber = ?2 and pvd.active = true")
	Optional<PatientVestDeviceHistoryTitan> findOneByPatientIdAndSerialNumberAndStatusActive(String patientId, String serialNumber);
	
	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1 and pvd.patientVestDevicePK.serialNumber = ?2")
	Optional<PatientVestDeviceHistoryTitan> findOneByPatientIdAndSerialNumber(String patientId, String serialNumber);

	@Query("from PatientVestDeviceHistoryTitan pvd where pvd.patientVestDevicePK.patient.id = ?1 and ((pvd.active = false and pvd.createdDate < ?2 and pvd.lastModifiedDate >?2) or (pvd.active=1))")
	List<PatientVestDeviceHistoryTitan> findByPatientIdWithinRange(String patientId, DateTime from);
	
}
