package com.hillrom.titan.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.titan.repository.PatientTitanDeviceDataRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.util.ExceptionConstants;
import com.hillrom.vest.util.MessageConstants;
import com.hillrom.vest.util.RelationshipLabelConstants;

/**
 * Service class for managing users.
 */
@Service
@Transactional
public class PatientVestDeviceTitanService {

    private final Logger log = LoggerFactory.getLogger(PatientVestDeviceTitanService.class);

    @Inject
    private UserRepository userRepository;
    
    @Inject
    private PatientTitanDeviceRepository patientTitanDeviceRepository;
    
    @Inject
    PatientDevicesAssocRepository patientDevicesAssoc;
    
    @Inject
    private PatientInfoRepository patientInfoRepository;
    
    @Inject
    private UserService userService;
    
    @Inject
    private PatientTitanDeviceDataRepository deviceDataRepository;

    
    public Object linkVestDeviceWithPatient(Long id, Map<String, Object> deviceData, String patientId) throws HillromException {
       	User alreadyLinkedPatientuser = new User();
        	List<PatientVestDeviceHistoryTitan> assocList = patientTitanDeviceRepository.findBySerialNumber(deviceData.get("serialNumber").toString());
        	PatientVestDeviceHistoryTitan activeAssocList = patientTitanDeviceRepository.findLatestActiveDeviceByPatientId(patientId,true);
        	List<PatientVestDeviceHistoryTitan> assocByWifiID = null;
        	if(Objects.nonNull(deviceData.get("wifiId"))){
        		assocByWifiID = patientTitanDeviceRepository.findByWifiIdAndStatusActive(deviceData.get("wifiId").toString());
        	}
        	PatientVestDeviceHistoryTitan patientVestDeviceAssoc = new PatientVestDeviceHistoryTitan();
        	if(Objects.nonNull(assocByWifiID) && 
        			assocByWifiID.size() > 0) {
        		alreadyLinkedPatientuser = (User) assocByWifiID.get(0).getPatient().getUserPatientAssoc().stream().filter(userPatientAssoc -> RelationshipLabelConstants.SELF.equals(userPatientAssoc.getRelationshipLabel())).collect(Collectors.toList()).get(0).getUser();
        		if(!alreadyLinkedPatientuser.getId().equals(id)){
        			return alreadyLinkedPatientuser;
    			}
        	}
        	if(assocList.isEmpty()) {
        		patientVestDeviceAssoc = assignDeviceToPatient(id, deviceData);
        	} else {
        		if(Objects.nonNull(activeAssocList))
        		{
        			activeAssocList.setActive(false);
        		}
        		List<PatientVestDeviceHistoryTitan> activeDeviceList = assocList.stream().filter(patientDevice -> patientDevice.isActive()).collect(Collectors.toList());
         		if(!activeDeviceList.isEmpty()){
         			PatientVestDeviceHistoryTitan activeDevice = activeDeviceList.get(0);
          			alreadyLinkedPatientuser = (User) activeDevice.getPatient().getUserPatientAssoc().stream().filter(userPatientAssoc -> RelationshipLabelConstants.SELF.equals(userPatientAssoc.getRelationshipLabel())).collect(Collectors.toList()).get(0).getUser();
        			if(alreadyLinkedPatientuser.getId().equals(id)){
        				patientVestDeviceAssoc = updateDeviceDetailsForPatient(activeDevice, deviceData);
        				return patientVestDeviceAssoc;
        			} else {
        				return alreadyLinkedPatientuser;
        			}
        		} else {
        			PatientInfo patientInfo = userService.getPatientInfoObjFromPatientUser(userRepository.getOne(id));
        			List<PatientVestDeviceHistoryTitan> patientDeviceList = assocList.stream().filter(patientDevice -> 
        			(patientDevice.getPatient().getId().equalsIgnoreCase(patientInfo.getId()) && !patientDevice.isActive())).collect(Collectors.toList());
        			if(patientDeviceList.isEmpty()) {
        				patientVestDeviceAssoc = assignDeviceToPatient(id, deviceData);	
        			} else {
        				patientVestDeviceAssoc = updateDeviceDetailsForPatient(patientDeviceList.get(0), deviceData);
        			}
        		}
        	}
        	return patientVestDeviceAssoc;
        }
    
    private PatientVestDeviceHistoryTitan assignDeviceToPatient(Long id, Map<String, Object> deviceData) throws HillromException {
		User patientUser = userRepository.findOne(id);
		if(Objects.nonNull(patientUser)) {
			PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
		 	if(Objects.nonNull(patientInfo)){
		 		patientInfo.setSerialNumber(Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null);
		 		patientInfo.setBluetoothId(Objects.nonNull(deviceData.get("wifiId")) ? deviceData.get("wifiId").toString() : null);
//		 		patientInfo.setHubId(Objects.nonNull(deviceData.get("hubId")) ? deviceData.get("hubId").toString() : null);
		 		patientInfo.setDeviceAssocDate(DateTime.now());
		 		patientInfoRepository.save(patientInfo);
		 		Optional<PatientVestDeviceHistoryTitan> currentAssoc = patientTitanDeviceRepository.findOneByPatientIdAndActiveStatus(patientInfo.getId(), true);
		 		if(currentAssoc.isPresent()){
	 				currentAssoc.get().setActive(false);
	 				patientTitanDeviceRepository.save(currentAssoc.get());
		 		}
		 		PatientVestDeviceHistoryTitan patientVestDeviceAssoc = new PatientVestDeviceHistoryTitan(
		 				new PatientVestDevicePK(patientInfo, Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null), 
		 				Objects.nonNull(deviceData.get("wifiId")) ? deviceData.get("wifiId").toString() : null, 
		 				Objects.nonNull(deviceData.get("hubId")) ? deviceData.get("hubId").toString() : null, true,
		 				Objects.nonNull(deviceData.get("bluetooth")) ? true : false);
		 		if(Objects.nonNull(deviceData.get("isByod")) && deviceData.get("isByod").toString().equalsIgnoreCase("true")) {
		 			patientVestDeviceAssoc.setIsByod(true);
		 			patientVestDeviceAssoc.setByodState(Constants.BYOD_NOT_PAIRED);
		 		}else {
		 			patientVestDeviceAssoc.setIsByod(false);
		 			patientVestDeviceAssoc.setByodState(null);
		 		}
		 		patientTitanDeviceRepository.saveAndFlush(patientVestDeviceAssoc);
		 		return patientVestDeviceAssoc;
		 	} else {
		 		throw new HillromException(ExceptionConstants.HR_523);//No such patient exist
		 	}
		} else {
			throw new HillromException(ExceptionConstants.HR_512);//No such user exist
		}
	}
    
    private PatientVestDeviceHistoryTitan updateDeviceDetailsForPatient(PatientVestDeviceHistoryTitan activeDevice, Map<String, Object> deviceData) throws HillromException {
		PatientInfo patientInfo = activeDevice.getPatient();
	 	if(Objects.nonNull(patientInfo)){
	 		patientInfo.setSerialNumber(Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null);
	 		patientInfo.setBluetoothId(Objects.nonNull(deviceData.get("wifiId")) ? deviceData.get("wifiId").toString() : null);
	 		patientInfo.setHubId(Objects.nonNull(deviceData.get("hubId")) ? deviceData.get("hubId").toString() : null);
	 		patientInfoRepository.save(patientInfo);
	 		activeDevice.setSerialNumber(Objects.nonNull(deviceData.get("serialNumber")) ? deviceData.get("serialNumber").toString() : null);
	 		activeDevice.setWifiId(Objects.nonNull(deviceData.get("wifiId")) ? deviceData.get("wifiId").toString() : null);
	 		activeDevice.setHubId(Objects.nonNull(deviceData.get("hubId")) ? deviceData.get("hubId").toString() : null);
	 		activeDevice.setActive(true);
	 		if(Objects.nonNull(deviceData.get("isByod")) && deviceData.get("isByod").toString().equalsIgnoreCase("true")) {
	 			activeDevice.setIsByod(true);
	 			if(Objects.nonNull(deviceData.get("byodState")))
	 			{	 			
	 				activeDevice.setByodState(deviceData.get("byodState").toString());
	 			}
	 		}else {
	 			activeDevice.setIsByod(false);
	 			activeDevice.setByodState(null);
	 		}
	 		patientTitanDeviceRepository.saveAndFlush(activeDevice);
	 		return activeDevice;
	 	} else {
	 		throw new HillromException(ExceptionConstants.HR_523);//No such patient exist
	 	}
	}

    public List<PatientVestDeviceHistoryTitan> getLinkedVestDeviceWithPatientTitan(Long id) throws HillromException {
    	List<PatientVestDeviceHistoryTitan> deviceList;
    	User patientUser = userRepository.findOne(id);
    	if(Objects.nonNull(patientUser)) {
	    	PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
	     	if(Objects.nonNull(patientInfo)){
	     		deviceList = patientTitanDeviceRepository.findByPatientId(patientInfo.getId());	     		
	     		/*if(Objects.nonNull(patientInfo.getSerialNumber())){
		     		PatientVestDeviceHistoryTitan activeDevice = new PatientVestDeviceHistoryTitan(new PatientVestDevicePK(patientInfo, patientInfo.getSerialNumber()),
		     				patientInfo.getBluetoothId(), patientInfo.getHubId(), true);
		     		activeDevice.setCreatedDate(patientInfo.getDeviceAssocDate());
		     		activeDevice.setLastModifiedDate(patientInfo.getDeviceAssocDate());
		     		deviceList.add(activeDevice);
	     		}*/
	     	} else {
	     		throw new HillromException(ExceptionConstants.HR_523);//No such patient exist
	     	}
    	} else {
    		throw new HillromException(ExceptionConstants.HR_512);//No such user exist
     	}
    	return deviceList;
    }

    public void updateHMR(User patientUser,PatientInfo patient)throws Exception{

    	Optional<PatientVestDeviceHistoryTitan>  deviceHistoryFromDB = 
    			patientTitanDeviceRepository.findOneByPatientIdAndSerialNumberAndStatusActive(patient.getId(),patient.getSerialNumber());

    	if(deviceHistoryFromDB.isPresent()){
    		PatientVestDeviceHistoryTitan history = deviceHistoryFromDB.get();
    		history.setHmr(getLatestHMR(patientUser.getId(),patient.getSerialNumber()));
    		patientTitanDeviceRepository.save(history);
    	}else{
    		PatientDevicesAssoc oldPatientDevicesAssoc = patientDevicesAssoc.findOneByPatientIdAndDeviceType(patient.getId(),"TITAN");
    		Optional<PatientVestDeviceHistoryTitan> oldDeviceHistoryFromDB = patientTitanDeviceRepository.findOneByPatientIdAndSerialNumber(patient.getId(),oldPatientDevicesAssoc.getSerialNumber());
    		if(oldDeviceHistoryFromDB.isPresent()){
    			PatientVestDeviceHistoryTitan history = oldDeviceHistoryFromDB.get();
    			history.setHmr(getLatestHMR(patientUser.getId(),oldPatientDevicesAssoc.getSerialNumber()));
    			patientTitanDeviceRepository.save(history);
    		}else{
    			PatientVestDeviceHistoryTitan history = new PatientVestDeviceHistoryTitan(new PatientVestDevicePK(patient, patient.getSerialNumber()),
    					patient.getBluetoothId(), patient.getHubId(), true);
    			history.setCreatedDate(patient.getDeviceAssocDate());
    			history.setLastModifiedDate(patient.getDeviceAssocDate());
    			history.setHmr(getLatestHMR(patientUser.getId(),patient.getSerialNumber()));
    			patientTitanDeviceRepository.save(history);
    		}
    	}
    }
    
    public Double getLatestHMR(Long id,String serialNumber){

    	PatientVestDeviceDataTitan deviceData = deviceDataRepository.findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(id, serialNumber);

		if(Objects.nonNull(deviceData))
			return deviceData.getHmr();
		else 
			return 0d;
	}

	private PatientInfo getPatientInfoObjFromPatientUser(User patientUser) {
		PatientInfo patientInfo = null;
		for(UserPatientAssoc patientAssoc : patientUser.getUserPatientAssoc()){
			if(RelationshipLabelConstants.SELF.equals(patientAssoc.getRelationshipLabel())){
				patientInfo = patientAssoc.getPatient();
			}
		}
		return patientInfo;
	}	
	
	public String deactivateVestDeviceFromPatient(Long id, String serialNumber) throws HillromException {
    	User patientUser = userRepository.findOne(id);
    	boolean deviceActive=true;
    	if(patientUser != null) {
	    	PatientInfo patientInfo = getPatientInfoObjFromPatientUser(patientUser);
	     	if(patientInfo != null){
	     		Optional<PatientVestDeviceHistoryTitan> patientDeviceHistoryTitan = patientTitanDeviceRepository.findOneByPatientIdAndSerialNumber(patientInfo.getId(), serialNumber);
	     		Optional<PatientDevicesAssoc> patientDevicesAssocList = patientDevicesAssoc.findOneBySerialNumber(serialNumber);
	     		if(patientDevicesAssocList.isPresent()){
	     			if(patientDevicesAssocList.get().getIsActive()){
	     				patientDevicesAssocList.get().setIsActive(false);
	     				patientDevicesAssocList.get().setIsActive(false);
	     				patientDevicesAssoc.saveAndFlush(patientDevicesAssocList.get());

	     				if(patientDevicesAssocList.get().getPatientType().equals("CD"))
	     				{
	     					List<PatientDevicesAssoc> patientDevicesAssocLst = patientDevicesAssoc.findByPatientId(patientInfo.getId());
	     					if(Objects.nonNull(patientDevicesAssocLst))
	     					{
	     						for (PatientDevicesAssoc patientDevicesAssocItem : patientDevicesAssocLst) {
	     							patientDevicesAssocItem.setPatientType("SD");
	     							patientDevicesAssoc.saveAndFlush(patientDevicesAssocItem);
								}
	     						
	     					}
	     				}
	     				deviceActive=false;
	     			}
	     		}	     		  		
	     		if(patientDeviceHistoryTitan.isPresent() && !deviceActive){
	     			if(patientDeviceHistoryTitan.get().isActive()) {
		     			patientDeviceHistoryTitan.get().setActive(false);
		     			// When dis-associated update the latest hmr
		     			patientDeviceHistoryTitan.get().setHmr(getLatestHMR(id, serialNumber));
		 				patientTitanDeviceRepository.save(patientDeviceHistoryTitan.get());
		 				patientInfo.setSerialNumber(null);
		 				patientInfo.setBluetoothId(null);
		 				patientInfo.setHubId(null);
		 				patientInfo.setDeviceAssocDate(null);
		 				patientInfoRepository.saveAndFlush(patientInfo);
		 				return MessageConstants.HR_283;
	     			} else {
	     				throw new HillromException(ExceptionConstants.HR_570);//Vest device is already in Inactive mode
	     			}
	     		} else {
	     			throw new HillromException(ExceptionConstants.HR_571);//Invalid Serial Number
	     		}
	     	} else {
	     		throw new HillromException(ExceptionConstants.HR_523);//No such patient exist
	     	}
    	} else {
    		throw new HillromException(ExceptionConstants.HR_512);//No such user exist
     	}
    }
}

