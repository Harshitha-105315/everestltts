package com.hillrom.titan.service;

import java.util.Optional;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hillrom.monarch.repository.AdherenceResetMonarchRepository;
import com.hillrom.monarch.service.AdherenceResetServiceMonarch;
import com.hillrom.titan.repository.AdherenceResetTitanRepository;
import com.hillrom.vest.domain.AdherenceResetTitan;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.EntityUserRepository;
import com.hillrom.vest.repository.UserExtensionRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.repository.UserSearchRepository;
import com.hillrom.vest.service.UserService;

/**
 * Service class for managing users.
 */
@Service
@Transactional
public class AdherenceResetServiceTitan {
	  private final Logger log = LoggerFactory.getLogger(AdherenceResetServiceTitan.class);

	    @Inject
	    private AdherenceResetTitanRepository adherenceResetTitanRepository;
	    
	    @Inject
	    private UserService userService;
	    
	    @Inject
	    private UserRepository userRepository;
	    
	    @Inject
	    private UserExtensionRepository userExtensionRepository;
	    
	    @Inject
	    private UserSearchRepository userSearchRepository;
	    
	    @Inject
	    private EntityUserRepository entityUserRepository;
	    
    //hill-1847
    public AdherenceResetTitan findOneByPatientUserIdAndCreatedByAndResetDate(Long patientUserId, Long createdById, DateTime resetDate){
    	Optional<AdherenceResetTitan> adherenceReset = adherenceResetTitanRepository.findOneByPatientUserIdAndCreatedByAndResetDate(patientUserId, createdById, resetDate);
    	if(adherenceReset.isPresent())
			return adherenceReset.get();
		return null;
	}
	 //hill-1847
    public AdherenceResetTitan createAdherenceReset(String patientId, Long patientUserId, DateTime resetDate, Integer resetScore, 
												LocalDate resetStartDate, String justification, Long createdById) throws HillromException {
    	
    	AdherenceResetTitan existAdherenceReset = findOneByPatientUserIdAndCreatedByAndResetDate(patientUserId, createdById, resetDate);
    	
		//hill-1847
    	
    		existAdherenceReset = new AdherenceResetTitan();
    		
    		User patientUser = userRepository.findOne(patientUserId);
    		existAdherenceReset.setPatientUser(patientUser);
    		
    		PatientInfo patient = userService.getPatientInfoObjFromPatientUser(patientUser);
    		existAdherenceReset.setPatient(patient);
    		
    		existAdherenceReset.setResetDate(resetDate);
    		existAdherenceReset.setResetScore(resetScore);
    		existAdherenceReset.setResetStartDate(resetStartDate);
    		existAdherenceReset.setJustification(justification);
    		existAdherenceReset.setCreatedBy(createdById);
    		
    		adherenceResetTitanRepository.save(existAdherenceReset);
    	//hill-1847
    	return existAdherenceReset;
    }


}
