package com.hillrom.titan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hillrom.vest.domain.RemoteTherapyUpdateHistoryTitan;

public interface RemoteTherapyUpdateHistoryTitanRepository
		extends JpaRepository<RemoteTherapyUpdateHistoryTitan, String> {

	@Query("from RemoteTherapyUpdateHistoryTitan rtu where rtu.patientId= ?1")
	List<RemoteTherapyUpdateHistoryTitan> findByPatientId(String patientId);

	@Query("from RemoteTherapyUpdateHistoryTitan rtu where rtu.patientId= ?1 and rtu.status= ?2")
	List<RemoteTherapyUpdateHistoryTitan> findByPatientIdAndStatus(String patientId, String status);

}
