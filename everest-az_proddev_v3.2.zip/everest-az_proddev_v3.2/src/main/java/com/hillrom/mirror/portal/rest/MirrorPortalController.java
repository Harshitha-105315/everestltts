package com.hillrom.mirror.portal.rest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Objects;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hillrom.mirror.portal.service.MirrorPortalDataCreationService;
import com.hillrom.vest.config.Constants;

import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api/v1.0")
public class MirrorPortalController {
	
	@Inject
	MirrorPortalDataCreationService mirrorPortalDataCreationService;
	
	@RequestMapping(value = "/data/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createData()
	{
		mirrorPortalDataCreationService.createDefaultData();
	}
	
	@RequestMapping(value = "/data/createPatient", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createDataForPatient(@RequestBody Map<String,String> params)
	{
		String hillromId = params.get("hillromId");
		
		LocalDate from = new LocalDate(params.get("from"));
		LocalDate to = new LocalDate(params.get("to"));

		mirrorPortalDataCreationService.createRawTherapyDataForPatient(hillromId, from, to);
	}
	
	@RequestMapping(value = "/mirror/createAE", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<JSONObject> createAE(@RequestParam(value = "uploadfile", required = true) MultipartFile uploadfile,
			@RequestParam(value = "deidentify", required = false) boolean deidentify)
	{
		JSONObject jsonObject = new JSONObject();

		try {

			if (!Objects.isNull(uploadfile)) {
				// Get the filename and build the local file path
				String filename = DateTime.now().toString("yyyy_MM_dd_hh_mm_ss").toString().replace(" ", "_")
						.replaceAll(":", "_") + "_" + uploadfile.getOriginalFilename();
				String directory = Constants.TIMS_CSV_FILE_PATH_MANUAL;
				File dir = new File(Constants.TIMS_CSV_FILE_PATH_MANUAL);

				if (!dir.exists()) {
					dir.mkdirs();
				}
				String filepath = Paths.get(directory, filename).toString();

				// Save the file locally
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
				stream.write(uploadfile.getBytes());
				stream.close();

				try {
					mirrorPortalDataCreationService.createAE(filepath, deidentify);
					jsonObject.put("timsMsg", "TIMSJob Executed Successfully");
					return new ResponseEntity<>(jsonObject, HttpStatus.CREATED);
				} catch (Exception ex) {

					jsonObject.put("timsMsg", "TIMSJob NOT Executed Successfully");
					return new ResponseEntity<>(jsonObject, HttpStatus.BAD_REQUEST);
				}
			} else {
				jsonObject.put("ERROR", "File not found");
				return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
			}
		} catch (FileNotFoundException ex) {
			jsonObject.put("ERROR", "The system cannot find the path/Directory specified");
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		} catch (Exception ex) {
			jsonObject.put("ERROR", ex.getMessage());
			return new ResponseEntity<JSONObject>(jsonObject, HttpStatus.BAD_REQUEST);
		}
	}
}
