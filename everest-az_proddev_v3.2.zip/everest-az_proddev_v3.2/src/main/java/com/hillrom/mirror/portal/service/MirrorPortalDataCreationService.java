package com.hillrom.mirror.portal.service;

import static com.hillrom.vest.config.AdherenceScoreConstants.DEFAULT_COMPLIANCE_SCORE;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.hillrom.mirror.portal.domain.MirrorPortalAEDTO;
import com.hillrom.monarch.repository.PatientComplianceMonarchRepository;
import com.hillrom.monarch.repository.PatientMonarchDeviceDataRepository;
import com.hillrom.monarch.repository.PatientMonarchDeviceRepository;
import com.hillrom.monarch.repository.PatientProtocolMonarchRepository;
import com.hillrom.monarch.repository.TherapySessionMonarchRepository;
import com.hillrom.monarch.service.PatientNoEventMonarchService;
import com.hillrom.monarch.service.PatientProtocolMonarchService;
import com.hillrom.monarch.service.TherapySessionServiceMonarch;
import com.hillrom.monarch.service.util.PatientVestDeviceTherapyUtilMonarch;
import com.hillrom.monarch.web.rest.dto.ProtocolEntryMonarchDTO;
import com.hillrom.monarch.web.rest.dto.ProtocolMonarchDTO;
import com.hillrom.titan.repository.PatientComplianceTitanRepository;
import com.hillrom.titan.repository.PatientProtocolTitanRepository;
import com.hillrom.titan.repository.PatientTitanDeviceDataRepository;
import com.hillrom.titan.repository.PatientTitanDeviceRepository;
import com.hillrom.titan.repository.TherapySessionTitanRepository;
import com.hillrom.titan.service.PatientNoEventTitanService;
import com.hillrom.titan.service.PatientProtocolTitanService;
import com.hillrom.titan.web.rest.dto.ProtocolEntryTitanDTO;
import com.hillrom.titan.web.rest.dto.ProtocolTitanDTO;
import com.hillrom.vest.config.Constants;
import com.hillrom.vest.domain.CityStateZipMap;
import com.hillrom.vest.domain.Clinic;
import com.hillrom.vest.domain.PatientCompliance;
import com.hillrom.vest.domain.PatientComplianceMonarch;
import com.hillrom.vest.domain.PatientComplianceTitan;
import com.hillrom.vest.domain.PatientDevicesAssoc;
import com.hillrom.vest.domain.PatientInfo;
import com.hillrom.vest.domain.PatientProtocolData;
import com.hillrom.vest.domain.PatientProtocolDataMonarch;
import com.hillrom.vest.domain.PatientProtocolDataTitan;
import com.hillrom.vest.domain.PatientTestResult;
import com.hillrom.vest.domain.PatientVestDeviceData;
import com.hillrom.vest.domain.PatientVestDeviceDataMonarch;
import com.hillrom.vest.domain.PatientVestDeviceDataMonarchPK;
import com.hillrom.vest.domain.PatientVestDeviceDataPK;
import com.hillrom.vest.domain.PatientVestDeviceDataTitan;
import com.hillrom.vest.domain.PatientVestDeviceDataTitanPK;
import com.hillrom.vest.domain.PatientVestDeviceHistory;
import com.hillrom.vest.domain.PatientVestDeviceHistoryMonarch;
import com.hillrom.vest.domain.PatientVestDeviceHistoryTitan;
import com.hillrom.vest.domain.PatientVestDevicePK;
import com.hillrom.vest.domain.TherapySession;
import com.hillrom.vest.domain.TherapySessionMonarch;
import com.hillrom.vest.domain.TherapySessionTitan;
import com.hillrom.vest.domain.User;
import com.hillrom.vest.domain.UserExtension;
import com.hillrom.vest.domain.UserPatientAssoc;
import com.hillrom.vest.exceptionhandler.HillromException;
import com.hillrom.vest.repository.CityStateZipMapRepository;
import com.hillrom.vest.repository.ClinicRepository;
import com.hillrom.vest.repository.PatientComplianceRepository;
import com.hillrom.vest.repository.PatientDevicesAssocRepository;
import com.hillrom.vest.repository.PatientInfoRepository;
import com.hillrom.vest.repository.PatientProtocolRepository;
import com.hillrom.vest.repository.PatientTestResultRepository;
import com.hillrom.vest.repository.PatientVestDeviceDataRepository;
import com.hillrom.vest.repository.PatientVestDeviceRepository;
import com.hillrom.vest.repository.TherapySessionRepository;
import com.hillrom.vest.repository.UserPatientRepository;
import com.hillrom.vest.repository.UserRepository;
import com.hillrom.vest.security.AuthoritiesConstants;
import com.hillrom.vest.service.ClinicPatientService;
import com.hillrom.vest.service.ClinicService;
import com.hillrom.vest.service.HCPClinicService;
import com.hillrom.vest.service.PatientHCPService;
import com.hillrom.vest.service.PatientNoEventService;
import com.hillrom.vest.service.PatientProtocolService;
import com.hillrom.vest.service.TherapySessionService;
import com.hillrom.vest.service.UserService;
import com.hillrom.vest.service.util.DateUtil;
import com.hillrom.vest.service.util.PatientVestDeviceTherapyUtil;
import com.hillrom.vest.web.rest.dto.ClinicDTO;
import com.hillrom.vest.web.rest.dto.ProtocolDTO;
import com.hillrom.vest.web.rest.dto.ProtocolEntryDTO;
import com.hillrom.vest.web.rest.dto.UserExtensionDTO;

@Service
@Transactional
public class MirrorPortalDataCreationService {

	@Inject
	private PatientDevicesAssocRepository patientDevicesAssocRepository;

	@Inject
	private PatientVestDeviceRepository patientVestDeviceRepository;

	@Inject
	private TherapySessionService therapySessionService;

	@Inject
	private TherapySessionServiceMonarch therapySessionServiceMonarch;

	@Inject
	private PatientMonarchDeviceRepository patientMonarchDeviceRepository;

	@Inject
	private PatientInfoRepository patientInfoRepository;

	@Inject 
	private PatientProtocolRepository patientProtocolRepository;

	@Inject
	private PatientProtocolMonarchRepository patientProtocolMonarchRepository;

	@Inject
	private PatientVestDeviceDataRepository patientVestDeviceDataRepository;

	@Inject
	private PatientMonarchDeviceDataRepository patientMonarchDeviceDataRepository;

	@Inject
	private UserPatientRepository userPatientRepository;

	@Inject
	private PatientProtocolService patientProtocolService;

	@Inject
	private PatientProtocolMonarchService patientProtocolMonarchService;

	@Inject
	private UserService userService;

	@Inject
	private UserRepository userRepository;

	@Inject
	private ClinicService clinicService;
	
	@Inject ClinicRepository clinicRepository;
	
	@Inject
	private CityStateZipMapRepository cityStateZipMapRepository;
	//@Scheduled(fixedDelay = 120000)

    @Inject
    private HCPClinicService hcpClinicService;

    @Inject
    private ClinicPatientService clinicPatientService;

    @Inject
    private TherapySessionMonarchRepository therapySessionMonarchRepository;
    
    @Inject
    private TherapySessionRepository therapySessionRepository;

    @Inject
    private PatientNoEventMonarchService noEventMonarchService;

    @Inject
    private PatientNoEventTitanService noEventTitanService;
    
    @Inject
    private PatientNoEventService noEventService;

    @Inject
    private PatientComplianceMonarchRepository patientComplianceMonarchRepository;

    @Inject
    private PatientComplianceRepository patientComplianceRepository;
    
    @Inject
    private PatientHCPService patientHCPService;
    
    @Inject
    private PatientTestResultRepository patientTestResultRepository;
    
    @Inject
	private PatientProtocolTitanService patientProtocolTitanService;
    
    @Inject
	private PatientTitanDeviceRepository patientTitanDeviceRepository;
    
    @Inject
	private PatientProtocolTitanRepository patientProtocolTitanRepository;
    
    @Inject
	private PatientTitanDeviceDataRepository patientTitanDeviceDataRepository;
    
    @Inject
    private TherapySessionTitanRepository therapySessionTitanRepository;
    
    @Inject
    private PatientComplianceTitanRepository patientComplianceTitanRepository;
    
    private String defaultClinicID = "CLINIC1";

    @Value( "${mirror.portal.user.creation}" )
    private String isMirror;

	public void createDefaultData()  {

		long count = userRepository.count();

		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}
		
		if(count == 1) 
		{
			try {
				Clinic clinic = createDefaultClinic(defaultClinicID);
				createDefaultCA("Bella","Rose", clinic);
				createDefaultCA("Leonard","Bernstein", clinic);
				UserExtension userHCP1 = createDefaultProvider("Tom","Sawyer",clinic);
				UserExtension userHCP2 = createDefaultProvider("Johanna","Berg",clinic);
				UserExtension userHCP3 = createDefaultProvider("Diego","Rivera",clinic);
				UserExtension userHCP4 = createDefaultProvider("Wanda","Wedge",clinic);
				createDefaultPatient("Ingrid",	"Bergman",null,	"82915","VEST,MONARCH","CD", "default", "custom",	"08/29/2015",	"1915 Casablanca Cove",	"32003", "50%", clinic, userHCP1);
				createDefaultPatient("Humphrey",	"Bogart",null,	"11457","VEST,MONARCH",	"CD","custom", "custom","01/14/2010",	"1957 Bacall Boulevard",	"90013", "80%", clinic, userHCP2);
				createDefaultPatient("Jack",	"Kerouac",null,	"31222","VEST,MONARCH",	"CD","custom", "default","03/12/2003",	"1962 Big Sur Avenue", "01854", "100%", clinic, userHCP3);
				createDefaultPatient("Judy",	"Garland",null,	"61022","MONARCH",	"SD",null, "custom","06/10/1996",	"1922 Liza Lane",	"55730", "100%", clinic, userHCP4);
				createDefaultPatient("Norman ",	"Rockwell",null,	"20394","MONARCH", "SD",null,"default","02/03/1994",	  "1894 Painting Place",	"10001", "50%", clinic, userHCP1);
				createDefaultPatient("Nelson",	"Mandela",null,	"71818","MONARCH",	"SD",	null, "custom","07/18/1985",	 "1918 Houghton Estate Rpad", "83701", "80%", clinic, userHCP2);
				createDefaultPatient("Frida",	"Kahlo",null,	"70607","VEST",	"SD",	"default", null,"07/06/1983",	 "1907 Coyoacan Circle",	"87103", "50%", clinic, userHCP3);
				createDefaultPatient("Felicia ",	"Montealegre",null,	"20622",	"VEST",	"SD", "custom", null, "02/06/1968",	"1922 Symphony Street",	"33023", "80%", clinic, userHCP4);
				createDefaultPatient("Salvatore",	"Ferragamo",null,	"50698",	"VEST",	"SD", "default", null, "05/06/1952",	"1898 Florence Way",	"60007", "100%", clinic, userHCP1);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

    private static CellProcessor[] getProcessors() {
        final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(),//private String firstName;
				new NotNull(),//private String lastName;
				new NotNull(),//private String timsID;
				new NotNull(),//private String password;
				new NotNull()//private String email;
        };
        return processors;
    }

    public void createAE(String filepath, boolean deidentify) {
		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}

		Optional<Clinic> clinic = clinicRepository.findOneByHillromId("CLINIC1");
		
		if(clinic.isPresent()) {
			try {
				ICsvBeanReader beanReader = new CsvBeanReader(new FileReader(filepath), CsvPreference.STANDARD_PREFERENCE);
			    // the header elements are used to map the values to the bean
				final String[] headers = {"FirstName","LastName","TimsID","Password","Email"};
			    final CellProcessor[] processors = getProcessors();
			    
			    MirrorPortalAEDTO mirrorPortalAEDTO = new MirrorPortalAEDTO();

				boolean valid = true;
			
				while(valid) {
			    	mirrorPortalAEDTO = beanReader.read(MirrorPortalAEDTO.class, headers, processors);
			    	
			    	if(Objects.nonNull(mirrorPortalAEDTO)) {
			    		Optional<User> user = userRepository.findOneByHillromId(mirrorPortalAEDTO.getTimsID());
			    		if(!user.isPresent()) {
			    			createDefaultAE(mirrorPortalAEDTO.getFirstName(),mirrorPortalAEDTO.getLastName(), mirrorPortalAEDTO.getEmail(), mirrorPortalAEDTO.getTimsID(), mirrorPortalAEDTO.getPassword(), clinic.get());
			    		}
			    	}else {
			    		valid = false;
			    	}
			    }
				beanReader.close();
			}catch (Exception e) {
				e.printStackTrace();
			}		
		}
	}

    public Clinic createDefaultClinic(String hillromId) throws Exception
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return null;
		}

		Optional<Clinic> clinic = clinicRepository.findOneByHillromId(hillromId);
		if(!clinic.isPresent()) {
			ClinicDTO clinicDTO = new ClinicDTO();
			clinicDTO.setName("Stockholm Pulmonary");
			clinicDTO.setAddress("1982 Chelsea Street");
			clinicDTO.setZipcode("60045");
			clinicDTO.setHillromId(hillromId);
			clinicDTO.setParent(true);
			List<CityStateZipMap> zipCodeList = cityStateZipMapRepository.findByZipCode(clinicDTO.getZipcode());
			clinicDTO.setCity(zipCodeList.get(0).getCity());
			clinicDTO.setState(zipCodeList.get(0).getState());
			return clinicService.createClinic(clinicDTO);
		}
		
		return clinic.get();
	}

    public UserExtension createDefaultProvider(String firstName, String lastName, Clinic clinic) throws Exception
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return null;
		}

		UserExtension user = null;
		UserExtensionDTO userExtensionDTO = new UserExtensionDTO();
		userExtensionDTO.setFirstName(firstName);
		userExtensionDTO.setLastName(lastName);
		userExtensionDTO.setRole(AuthoritiesConstants.HCP);
		user = userService.createHCPUser(userExtensionDTO);
		hcpClinicService.associateHCPToClinic(clinic.getId(), user.getId());
		return user;
	}

    public UserExtension createDefaultCA(String firstName, String lastName, Clinic clinic)  throws Exception
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return null;
		}

		UserExtension user = null;
		UserExtensionDTO userExtensionDTO = new UserExtensionDTO();
		userExtensionDTO.setFirstName(firstName);
		userExtensionDTO.setLastName(lastName);
		userExtensionDTO.setRole(AuthoritiesConstants.CLINIC_ADMIN);
		user = userService.createClinicAdminUser(userExtensionDTO);
		clinicService.associateClinicAdmin(clinic.getId(), user.getId());
		return user;
	}

	public void createDefaultAE(String firstName, 
			String lastName,
			String email,
			String hillromId,
			String password, 
			Clinic clinic) throws Exception {
		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}

		UserExtensionDTO userExtensionDTO = new UserExtensionDTO();
		userExtensionDTO.setFirstName(firstName);
		userExtensionDTO.setLastName(lastName);
		userExtensionDTO.setHillromId(hillromId);
		userExtensionDTO.setPassword(password);
		userExtensionDTO.setEmail(email);
		userExtensionDTO.setRole(AuthoritiesConstants.ASSOCIATE_EXECUTIVE);
		createAE(userExtensionDTO);
	}
    
	public UserExtension createAE(UserExtensionDTO userExtensionDTO) throws Exception
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return null;
		}

		String hillromId = userExtensionDTO.getHillromId();
		int positionSPChar =  userExtensionDTO.getEmail().indexOf("@");
		StringBuffer originalEmail =  new StringBuffer(userExtensionDTO.getEmail());
		Optional<Clinic> optClinic = clinicRepository.findOneByHillromId(defaultClinicID);
		if(Objects.nonNull(hillromId)) {
			if(hillromId.startsWith("D")) {
				hillromId = hillromId.substring(1);
				userExtensionDTO.setHillromId("D" + hillromId);
			}else {
				userExtensionDTO.setHillromId("D" + hillromId);
			}
		}
	
		List<Map<String,String>> clinicList =  new ArrayList<Map<String,String>>();
		Map<String,String> map = new HashMap<String, String>();
		map.put("id", optClinic.get().getId());
		clinicList.add(map);
		userExtensionDTO.setClinicList(clinicList);
		userExtensionDTO.setRole(AuthoritiesConstants.ASSOCIATE_EXECUTIVE);
		// Create AE role
		UserExtension userAE = userService.createAssocExecutiveUser(userExtensionDTO,true);		

		// Create CA role
		userExtensionDTO.setHillromId("C"+hillromId);
		String caEmail = originalEmail.insert(positionSPChar, "+CA").toString();
		userExtensionDTO.setEmail(caEmail);
		userExtensionDTO.setRole(AuthoritiesConstants.CLINIC_ADMIN);
		userService.createClinicAdminUser(userExtensionDTO);

		// Create Patient
		positionSPChar =  userExtensionDTO.getEmail().indexOf("@");
		originalEmail =  new StringBuffer(userExtensionDTO.getEmail());

		userExtensionDTO.setHillromId("P"+hillromId);
		userExtensionDTO.setDeviceType("VEST,MONARCH,TITAN");
		userExtensionDTO.setSpeciality("80%");
		String patientEmail = originalEmail.insert(positionSPChar, "+P").toString();
		userExtensionDTO.setEmail(patientEmail);
		userExtensionDTO.setRole(AuthoritiesConstants.PATIENT);
		UserExtension patientUser = userService.createPatientUser(userExtensionDTO);
		creatingVestDefaultProtocol(patientUser);
		creatingMonarchCustomProtocol(patientUser);
		creatingTitanCustomProtocol(patientUser);
		creatingDeviceHistory(patientUser);
		List<UserPatientAssoc> patientInfo = userPatientRepository.findByUserIdAndUserRole(patientUser.getId(), "PATIENT");
		createRawTherapyData(LocalDate.now().minusMonths(6).minusDays(LocalDate.now().getDayOfMonth()-1), LocalDate.now(), patientInfo.get(0).getPatient(), patientInfo.get(0).getUser());
		createSpiroData(LocalDate.now().minusMonths(6).minusDays(LocalDate.now().getDayOfMonth()-1), LocalDate.now(), patientInfo.get(0).getPatient().getId(), patientInfo.get(0).getUser().getId());
		return userAE;
	}
    
	public void createDefaultPatient(
				String firstName, 
				String lastName, 
				String email, 
				String hillromId, 
				String deviceType,
				String patientType,
				String vestProtocol,
				String monProtocol,
				String dob,
				String address,
				String zipCode,
				String speciality,
				Clinic clinic,
				UserExtension hcp)
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}

		try {
			//creating a patient
			UserExtensionDTO patinetUserExtensionDTO = new UserExtensionDTO();
			patinetUserExtensionDTO.setFirstName(firstName);
			patinetUserExtensionDTO.setLastName(lastName);
			patinetUserExtensionDTO.setEmail(email);
			patinetUserExtensionDTO.setHillromId(hillromId);
			patinetUserExtensionDTO.setDeviceType(deviceType);
			patinetUserExtensionDTO.setDob(dob);
			patinetUserExtensionDTO.setRole(AuthoritiesConstants.PATIENT);			
			List<CityStateZipMap> zipCodeList = cityStateZipMapRepository.findByZipCode(zipCode);
			patinetUserExtensionDTO.setAddress(address);
			patinetUserExtensionDTO.setCity(zipCodeList.get(0).getCity());
			patinetUserExtensionDTO.setState(zipCodeList.get(0).getState());
			patinetUserExtensionDTO.setZipcode(zipCode);
			patinetUserExtensionDTO.setSpeciality(speciality);
			UserExtension user = userService.createPatientUser(patinetUserExtensionDTO);

			//creating patient protocol Data
			if(Objects.nonNull(vestProtocol)) {
				if(vestProtocol.equals("default"))
				{
					creatingVestDefaultProtocol(user);
				}else {
					creatingVestCustomProtocol(user);
				}
			}
			
			if(Objects.nonNull(monProtocol)) {
				if(monProtocol.equals("default"))
				{
					creatingMonarchDefaultProtocol(user);
				}else {
					creatingMonarchCustomProtocol(user);
				}
			}
			
			List<Map<String,String>> clinicList =  new ArrayList<Map<String,String>>();
			Map<String,String> map = new HashMap<String, String>();
			map.clear();
			map.put("id", clinic.getId());
			clinicList.clear();
			clinicList.add(map);
			clinicPatientService.associateClinicsToPatient(user.getId(), clinicList);
			
			List<Map<String, String>> hcpList = new LinkedList<Map<String, String>>();
			Map<String,String> hcpMap = new HashMap<String,String>();
			hcpMap.put("id", hcp.getId().toString());
			hcpList.add(hcpMap);
			patientHCPService.associateHCPToPatient(user.getId(), hcpList);
			
			//creating Device history list data
			creatingDeviceHistory(user);
			List<UserPatientAssoc> patientUser = userPatientRepository.findByUserIdAndUserRole(user.getId(), "PATIENT");
			createRawTherapyData(LocalDate.now().minusMonths(6).minusDays(LocalDate.now().getDayOfMonth()-1), LocalDate.now(), patientUser.get(0).getPatient(),patientUser.get(0).getUser());
		} catch (HillromException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Profile("mirror")
	@Scheduled(cron="${cron.mirror.portal.ingestion}")	// 100% schedule
	public void createTherapyData()
	{
		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}

		LocalDate date = LocalDate.now(); 
		Map<String,List<LocalDate>> validPatientsWithDate = new HashMap<String,List<LocalDate>>();
		List<LocalDate> dateList = null;
		List<PatientInfo> patientList100 = patientInfoRepository.findByPrimaryDiagnosis("100%");
		List<PatientInfo> patientList80 = patientInfoRepository.findByPrimaryDiagnosis("80%");
		List<PatientInfo> patientList50 = patientInfoRepository.findByPrimaryDiagnosis("50%");
		for(PatientInfo patient :patientList100){
			if(validPatientsWithDate.containsKey(patient.getId())) {
				dateList = validPatientsWithDate.get(patient.getId());
				dateList.add(date);
				validPatientsWithDate.replace(patient.getId(), dateList);
			}else {
				dateList = new ArrayList<LocalDate>();
				dateList.add(date);
				validPatientsWithDate.put(patient.getId(), dateList);
			}
		}

		Boolean valid80 = false;
		
		switch(date.getDayOfWeek()) {
			case DateTimeConstants.SUNDAY:
			case DateTimeConstants.MONDAY:
			case DateTimeConstants.THURSDAY:
			case DateTimeConstants.FRIDAY:
				{
					valid80 = true;
				}
				break;
			default:{
					valid80 = false;
				}
				break;
		}
		
		if(valid80 == true) {
			for(PatientInfo patient :patientList80){
				if(validPatientsWithDate.containsKey(patient.getId())) {
					dateList = validPatientsWithDate.get(patient.getId());
					dateList.add(date);
					validPatientsWithDate.replace(patient.getId(), dateList);
				}else {
					dateList = new ArrayList<LocalDate>();
					dateList.add(date);
					validPatientsWithDate.put(patient.getId(), dateList);
				}
			}
		}
		
		Boolean valid50 = false;
		
		switch(date.getDayOfWeek()) {
			case DateTimeConstants.WEDNESDAY:
			case DateTimeConstants.SATURDAY:
				{
					valid50 = true;
				}
				break;
			default:{
					valid50 = false;
				}
				break;
		}
		
		if(valid50 == true) {
			for(PatientInfo patient :patientList50){
				if(validPatientsWithDate.containsKey(patient.getId())) {
					dateList = validPatientsWithDate.get(patient.getId());
					dateList.add(date);
					validPatientsWithDate.replace(patient.getId(), dateList);
				}else {
					dateList = new ArrayList<LocalDate>();
					dateList.add(date);
					validPatientsWithDate.put(patient.getId(), dateList);
				}
			}
		}
		
		for (Map.Entry<String, List<LocalDate>> entry : validPatientsWithDate.entrySet())
		{
			createTherapySessions(entry.getKey(), entry.getValue());
			createSpiroData(entry.getKey(), entry.getValue());
		}
	}
	
	public void createTherapySessions(String patientId, List<LocalDate> dateList) {
		if(!isMirror.equalsIgnoreCase("true")) {
			return;
		}

		List<PatientDevicesAssoc> activeDevicesList = patientDevicesAssocRepository.findByPatientId(patientId);
		if(Objects.nonNull(activeDevicesList)) {
			Boolean vest = false;
			Boolean monarch = false;
			String vestSerialNumber = null;
			String monarchSerialNumber = null;
			String vestProtocolType = null;
			String monarchProtocolType = null;
			for (PatientDevicesAssoc patientDevicesAssoc : activeDevicesList) {
				if(patientDevicesAssoc.getDeviceType().equals("VEST")) {
					vest = true;
					vestSerialNumber = patientDevicesAssoc.getSerialNumber();
					List<PatientProtocolData> patientProtocolDataList = patientProtocolRepository.findByPatientIdAndActiveStatus(patientDevicesAssoc.getPatientId());
					vestProtocolType = patientProtocolDataList.get(0).getType();
				}
				if(patientDevicesAssoc.getDeviceType().equals("MONARCH")) {
					monarch = true;
					monarchSerialNumber = patientDevicesAssoc.getSerialNumber();
					List<PatientProtocolDataMonarch> patientProtocolDataList = patientProtocolMonarchRepository.findByPatientIdAndActiveStatus(patientDevicesAssoc.getPatientId());
					monarchProtocolType = patientProtocolDataList.get(0).getType();
				}
			}
			
			PatientVestDeviceHistory latestInActiveDeviceVest = patientVestDeviceRepository.findLatestInActiveDeviceByPatientId(patientId, false);
			PatientVestDeviceHistoryMonarch latestInActiveDeviceMonarch = patientMonarchDeviceRepository.findLatestInActiveDeviceByPatientId(patientId, false);

			List<TherapySession> therapySessions = new ArrayList<TherapySession>();
			List<TherapySessionMonarch> therapySessionsMonarch = new ArrayList<TherapySessionMonarch>();
			
			for (LocalDate date : dateList) {
				if(monarch)
				{
					DateTime mor = date.toDateTimeAtStartOfDay().plusHours(13);
					try {
						therapySessionsMonarch.addAll(PatientVestDeviceTherapyUtilMonarch
								.prepareTherapySessionFromDeviceDataMonarch(createDeviceDataMonarch(monarchSerialNumber,patientId,monarchProtocolType,mor.getMillis()),latestInActiveDeviceMonarch));
					
						if(!vest) {
							DateTime eve = date.toDateTimeAtStartOfDay().plusHours(23);
							therapySessionsMonarch.addAll(PatientVestDeviceTherapyUtilMonarch
									.prepareTherapySessionFromDeviceDataMonarch(createDeviceDataMonarch(monarchSerialNumber,patientId,monarchProtocolType,eve.getMillis()),latestInActiveDeviceMonarch));
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	

				}
				if(vest) {
					try {
						if(!monarch) {
							DateTime mor = date.toDateTimeAtStartOfDay().plusHours(9);
							therapySessions.addAll(PatientVestDeviceTherapyUtil
									.prepareTherapySessionFromDeviceData(createDeviceDataVest(vestSerialNumber,patientId,vestProtocolType,mor.getMillis()),latestInActiveDeviceVest));
						}
						DateTime eve = date.toDateTimeAtStartOfDay().plusHours(19);
						therapySessions.addAll(PatientVestDeviceTherapyUtil
								.prepareTherapySessionFromDeviceData(createDeviceDataVest(vestSerialNumber,patientId,vestProtocolType,eve.getMillis()),latestInActiveDeviceVest));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				}
			}

			
			if(vest) {
				PatientInfo patient = patientInfoRepository.findOneById(patientId);
				patient.setLastVest(DateTime.now().getMillis());
				patientInfoRepository.save(patient);
			}
			
			if(monarch) {
				PatientInfo patient = patientInfoRepository.findOneById(patientId);
				patient.setLastMonarch(DateTime.now().getMillis());
				patientInfoRepository.save(patient);
			}

			try {
				if(vest&&monarch) {
					therapySessionService.saveOrUpdate(therapySessions);
					therapySessionServiceMonarch.saveOrUpdate(therapySessionsMonarch);
				} else if(vest) {
					therapySessionService.saveOrUpdate(therapySessions);
				}else if(monarch) {
					therapySessionServiceMonarch.saveOrUpdate(therapySessionsMonarch);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}	
	
	private List<PatientVestDeviceDataMonarch> createDeviceDataMonarch(String serialNumber, String patientId, String protocolType, Long timeInMillis)
	{
		List<PatientVestDeviceDataMonarch> patientVestDeviceRecordsMonarch = new ArrayList<PatientVestDeviceDataMonarch>();
		if(protocolType.equalsIgnoreCase("Normal")) {
			patientVestDeviceRecordsMonarch = monarchDeviceDataManual(serialNumber,patientId, timeInMillis);
		} else{
			patientVestDeviceRecordsMonarch = monarchDeviceDataProgrammed(serialNumber,patientId, timeInMillis);
		}
		return patientVestDeviceRecordsMonarch;
	}
	
	public List<PatientVestDeviceData> createDeviceDataVest(String serialNumber, String patientId, String protocolType, Long timeInMillis)
	{
		List<PatientVestDeviceData> patientVestDeviceRecords = new ArrayList<PatientVestDeviceData>();
		if(protocolType.equalsIgnoreCase("Normal")) {
			patientVestDeviceRecords = vestDeviceDataManual(serialNumber,patientId, timeInMillis);
		} else{
			patientVestDeviceRecords = vestDeviceDataProgrammed(serialNumber,patientId, timeInMillis);
		}
		return patientVestDeviceRecords;
	}
	
	private List<PatientVestDeviceDataMonarch> monarchDeviceDataProgrammed(String deviceSerialNumber,String patientId, Long timeInMillis) {
		List<PatientVestDeviceDataMonarch> deviceDataEventList = new ArrayList<PatientVestDeviceDataMonarch>();
		List<PatientVestDeviceHistoryMonarch> deviceHistoryList = patientMonarchDeviceRepository
				.findOneBySerialNumberAndStatusActive(deviceSerialNumber);
		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
		Double hmr = 0.0;
		if (!(deviceHistoryList.isEmpty())) {
			hmr = deviceHistoryList.get(0).getHmr();
		}
		Boolean startEvent = true;
		Long currentTimeStamp = timeInMillis;


		if (startEvent) {

			hmr = hmr +1800;
			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP1PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp, "7", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p1StartData = new 
					PatientVestDeviceDataMonarch(1, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP1PK, associatedUser.get(),90,70);
			deviceDataEventList.add(p1StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP2PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 300000L, "8", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p2StartData = new 
					PatientVestDeviceDataMonarch(2, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP2PK, associatedUser.get(),90,70);

			deviceDataEventList.add(p2StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP3PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 600000L, "9", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p3StartData = new 
					PatientVestDeviceDataMonarch(3, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP3PK, associatedUser.get(),90,70);

			deviceDataEventList.add(p3StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP4PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 900000L, "10", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p4StartData = new 
					PatientVestDeviceDataMonarch(4, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP4PK, associatedUser.get(),90,70);

			deviceDataEventList.add(p4StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP5PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1200000L, "11", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p5StartData = new 
					PatientVestDeviceDataMonarch(5, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP5PK, associatedUser.get(),90,70);

			deviceDataEventList.add(p5StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP6PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1500000L, "12", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch p6StartData = new 
					PatientVestDeviceDataMonarch(6, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP6PK, associatedUser.get(),90,70);

			deviceDataEventList.add(p6StartData);

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchCompletePK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1800000L, "15", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch eventCompletedData = new 
					PatientVestDeviceDataMonarch(7, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchCompletePK, associatedUser.get(),90,70);

			deviceDataEventList.add(eventCompletedData);
		}

		patientMonarchDeviceDataRepository.save(deviceDataEventList);

		PatientVestDeviceDataMonarch patientVestDeviceData = patientMonarchDeviceDataRepository.
				findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(associatedUser.get().getId(),deviceSerialNumber);
		if(Objects.nonNull(deviceHistoryList)) {
			deviceHistoryList.get(0).setHmr(patientVestDeviceData.getHmr());
		}
		patientMonarchDeviceRepository.save(deviceHistoryList);
		return deviceDataEventList;	
	}
	
	private List<PatientVestDeviceData> vestDeviceDataProgrammed(String deviceSerialNumber, String patientId, Long timeInMillis) {
		List<PatientVestDeviceData> deviceDataEventList = new ArrayList<PatientVestDeviceData>();
		List<PatientVestDeviceHistory> deviceHistoryList = patientVestDeviceRepository
				.findOneBySerialNumberAndStatusActive(deviceSerialNumber);
		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
		Double hmr = 0.0;
		if (!(deviceHistoryList.isEmpty())) {
			hmr = deviceHistoryList.get(0).getHmr();
		}
		Boolean startEvent = true;
		Long currentTimeStamp = timeInMillis;

		if (startEvent) {


			PatientVestDeviceDataPK patientVestDeviceDataP1PK  = new PatientVestDeviceDataPK(currentTimeStamp,deviceSerialNumber,"7:SessionEventCodeProgramPt1Started",patientInfo);
			PatientVestDeviceData p1StartData = new
					PatientVestDeviceData(1,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP1PK,hmr,15,6,5,associatedUser.get());
			deviceDataEventList.add(p1StartData);


			PatientVestDeviceDataPK patientVestDeviceDataP2PK  = new PatientVestDeviceDataPK(currentTimeStamp + 300000L,deviceSerialNumber,"8:SessionEventCodeProgramPt2Started",patientInfo);
			PatientVestDeviceData p2StartData = new
					PatientVestDeviceData(2,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP2PK,hmr+300,15,6,5,associatedUser.get());

			deviceDataEventList.add(p2StartData);

			PatientVestDeviceDataPK patientVestDeviceDataP3PK  = new PatientVestDeviceDataPK(currentTimeStamp + 600000L ,deviceSerialNumber,"9:SessionEventCodeProgramPt3Started",patientInfo);
			PatientVestDeviceData p3StartData = new
					PatientVestDeviceData(3,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP3PK,hmr+600,15,6,5,associatedUser.get());

			deviceDataEventList.add(p3StartData);

			PatientVestDeviceDataPK patientVestDeviceDataP4PK  = new PatientVestDeviceDataPK(currentTimeStamp + 900000L ,deviceSerialNumber,"10:SessionEventCodeProgramPt4Started",patientInfo);
			PatientVestDeviceData p4StartData = new
					PatientVestDeviceData(4,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP4PK,hmr+900,15,6,5,associatedUser.get());

			deviceDataEventList.add(p4StartData);

			PatientVestDeviceDataPK patientVestDeviceDataP5PK  = new PatientVestDeviceDataPK(currentTimeStamp + 1200000L ,deviceSerialNumber,"11:SessionEventCodeProgramPt5Started",patientInfo);
			PatientVestDeviceData p5StartData = new
					PatientVestDeviceData(5,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP5PK,hmr+1200,15,6,5,associatedUser.get());

			deviceDataEventList.add(p5StartData);

			PatientVestDeviceDataPK patientVestDeviceDataP6PK  = new PatientVestDeviceDataPK(currentTimeStamp + 1500000L ,deviceSerialNumber,"12:SessionEventCodeProgramPt6Started",patientInfo);
			PatientVestDeviceData p6StartData = new
					PatientVestDeviceData(6,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP6PK,hmr+1500,15,6,5,associatedUser.get());

			deviceDataEventList.add(p6StartData);

			PatientVestDeviceDataPK patientVestDeviceDataCompletePK  = new PatientVestDeviceDataPK(currentTimeStamp + 1800000L,deviceSerialNumber,"16:SessionEventCodeProgramCompleted",patientInfo);
			PatientVestDeviceData eventCompletedData = new
					PatientVestDeviceData(7,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataCompletePK,hmr+1800,0,0,0,associatedUser.get());

			deviceDataEventList.add(eventCompletedData);
		}

		patientVestDeviceDataRepository.save(deviceDataEventList);

		PatientVestDeviceData patientVestDeviceData = patientVestDeviceDataRepository.
				findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(associatedUser.get().getId(),deviceSerialNumber);
		if(Objects.nonNull(deviceHistoryList)) {
			deviceHistoryList.get(0).setHmr(patientVestDeviceData.getHmr());
		}
		patientVestDeviceRepository.save(deviceHistoryList);
		return deviceDataEventList;	
	}
	
	private List<PatientVestDeviceDataMonarch> monarchDeviceDataManual(String deviceSerialNumber,String patientId, Long timeInMillis) {

		List<PatientVestDeviceDataMonarch> deviceDataEventList = new ArrayList<PatientVestDeviceDataMonarch>();
		List<PatientVestDeviceHistoryMonarch> deviceHistoryList = patientMonarchDeviceRepository
				.findOneBySerialNumberAndStatusActive(deviceSerialNumber);
		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
		Double hmr = 0.0;
		if (!(deviceHistoryList.isEmpty())) {
			hmr = deviceHistoryList.get(0).getHmr();
		}
		Boolean startEvent = true;
		Long currentTimeStamp = timeInMillis;

		if (startEvent) {

			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchPK = new PatientVestDeviceDataMonarchPK(currentTimeStamp, "1", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch patientVestDeviceData = new 
					PatientVestDeviceDataMonarch(1, deviceSerialNumber, hmr, 15, 10, 30, patientVestDeviceDataMonarchPK, associatedUser.get(),90,70);
			startEvent = false;
			deviceDataEventList.add(patientVestDeviceData);
		}
		if (!startEvent) {
			Long durationToMillies = (long) (30 * (60 * 1000));
			hmr = hmr + ((30) * (60));
			PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchPK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + (durationToMillies), "3", deviceSerialNumber, patientInfo);
			PatientVestDeviceDataMonarch patientVestDeviceData = new PatientVestDeviceDataMonarch(2,deviceSerialNumber,hmr,15,10,30,patientVestDeviceDataMonarchPK,associatedUser.get(),90,70);

			deviceDataEventList.add(patientVestDeviceData);
		}
		patientMonarchDeviceDataRepository.save(deviceDataEventList);

		PatientVestDeviceDataMonarch patientVestDeviceData = patientMonarchDeviceDataRepository.
				findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(associatedUser.get().getId(),deviceSerialNumber);
		if(Objects.nonNull(deviceHistoryList)) {
			deviceHistoryList.get(0).setHmr(patientVestDeviceData.getHmr());
		}
		patientMonarchDeviceRepository.save(deviceHistoryList);
		return deviceDataEventList;		
	}

	private List<PatientVestDeviceData> vestDeviceDataManual(String deviceSerialNumber,String patientId, Long timeInMillis) {

		List<PatientVestDeviceData> deviceDataEventList = new ArrayList<PatientVestDeviceData>();
		List<PatientVestDeviceHistory> deviceHistoryList = patientVestDeviceRepository
				.findOneBySerialNumberAndStatusActive(deviceSerialNumber);
		PatientInfo patientInfo = patientInfoRepository.findOneById(patientId);
		Optional<User> associatedUser = userRepository.findOneByHillromId(patientInfo.getHillromId());
		Double hmr = 0.0;
		if (!(deviceHistoryList.isEmpty())) {
			hmr = deviceHistoryList.get(0).getHmr();
		}
		Boolean startEvent = true;
		Long currentTimeStamp = timeInMillis;

		if (startEvent) {

			PatientVestDeviceDataPK patientVestDeviceDataPK  = new PatientVestDeviceDataPK(currentTimeStamp,deviceSerialNumber,"1:SessionEventCodeNormalStarted",patientInfo);
			PatientVestDeviceData patientVestDeviceData = new
					PatientVestDeviceData(1,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataPK,hmr,15,6,30,associatedUser.get());

			startEvent = false;
			deviceDataEventList.add(patientVestDeviceData);
		}
		if (!startEvent) {
			Long durationToMillies = (long) (30 * (60 * 1000));
			hmr = hmr + ((30) * (60));
			PatientVestDeviceDataPK patientVestDeviceDataPK  = new PatientVestDeviceDataPK(currentTimeStamp + (durationToMillies),deviceSerialNumber,"3:SessionEventCodeCompleted",patientInfo);
			PatientVestDeviceData patientVestDeviceData = new PatientVestDeviceData(2,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataPK,hmr,0,0,0,associatedUser.get());
			deviceDataEventList.add(patientVestDeviceData);
		}

		patientVestDeviceDataRepository.save(deviceDataEventList);

		PatientVestDeviceData patientVestDeviceData = patientVestDeviceDataRepository.
				findTop1ByPatientUserIdAndSerialNumberOrderByHmrDesc(associatedUser.get().getId(),deviceSerialNumber);
		if(Objects.nonNull(deviceHistoryList)) {
			deviceHistoryList.get(0).setHmr(patientVestDeviceData.getHmr());
		}
		patientVestDeviceRepository.save(deviceHistoryList);

		return deviceDataEventList;		

	}
	
	public void creatingVestDefaultProtocol(User activeUser) {
		List<PatientProtocolData> protocolList = new LinkedList<>();
		List<UserPatientAssoc> patientUser = userPatientRepository.findByUserIdAndUserRole(activeUser.getId(), "PATIENT");
		PatientProtocolData newProtocol = new PatientProtocolData("Normal", patientUser.get(0).getPatient(), activeUser,2, 20, null,5, 20,1,10);

		String protocolKey = patientProtocolRepository.id();
		newProtocol.setId(protocolKey);
		newProtocol.setProtocolKey(protocolKey);

		protocolList.add(newProtocol);

		patientProtocolRepository.save(protocolList);
	}
	
	public void creatingMonarchDefaultProtocol(User activeUser) {
		List<PatientProtocolDataMonarch> protocolList = new LinkedList<>();
		List<UserPatientAssoc> patientUser = userPatientRepository.findByUserIdAndUserRole(activeUser.getId(), "PATIENT");
		PatientProtocolDataMonarch newProtocol = new PatientProtocolDataMonarch("Normal", patientUser.get(0).getPatient(), activeUser,2, 20, null,5, 20,1,10);

		String protocolKey = patientProtocolMonarchRepository.id();
		newProtocol.setId(protocolKey);
		newProtocol.setProtocolKey(protocolKey);

		protocolList.add(newProtocol);

		patientProtocolMonarchRepository.save(protocolList);
	}

	public void creatingVestCustomProtocol(User activeUser) throws HillromException {
		List<ProtocolEntryDTO> ppdList = new LinkedList<ProtocolEntryDTO>();
		ppdList.add(new ProtocolEntryDTO("point1",5,5,6,6,8,8));
		ppdList.add(new ProtocolEntryDTO("point2",5,5,7,7,8,8));
		ppdList.add(new ProtocolEntryDTO("point3",5,5,8,8,9,9));
		ppdList.add(new ProtocolEntryDTO("point4",5,5,9,9,8,8));
		ppdList.add(new ProtocolEntryDTO("point5",5,5,10,10,6,6));
		ppdList.add(new ProtocolEntryDTO("point6",5,5,11,11,8,8));

		ProtocolDTO protocolDTO = new ProtocolDTO();			

		protocolDTO.setTreatmentsPerDay(2);
		protocolDTO.setType("Custom");
		protocolDTO.setProtocolEntries(ppdList);

		patientProtocolService.addProtocolToPatient(activeUser.getId(), protocolDTO);
	}

	public void creatingMonarchCustomProtocol(User activeUser) throws HillromException {
		List<ProtocolEntryMonarchDTO> ppdList = new LinkedList<ProtocolEntryMonarchDTO>();
		ppdList.add(new ProtocolEntryMonarchDTO("point1",5,5,6,6,8,8));
		ppdList.add(new ProtocolEntryMonarchDTO("point2",5,5,7,7,8,8));
		ppdList.add(new ProtocolEntryMonarchDTO("point3",5,5,8,8,6,6));
		ppdList.add(new ProtocolEntryMonarchDTO("point4",5,5,9,9,8,8));
		ppdList.add(new ProtocolEntryMonarchDTO("point5",5,5,10,10,7,7));
		ppdList.add(new ProtocolEntryMonarchDTO("point6",5,5,11,11,8,8));

		ProtocolMonarchDTO protocolMonarchDTO = new ProtocolMonarchDTO();			

		protocolMonarchDTO.setTreatmentsPerDay(2);
		protocolMonarchDTO.setType("Custom");
		protocolMonarchDTO.setProtocolEntries(ppdList);
		patientProtocolMonarchService.addProtocolToPatient(activeUser.getId(), protocolMonarchDTO);
	}
	
	public void creatingTitanCustomProtocol(User activeUser) throws HillromException {
		List<ProtocolEntryTitanDTO> ppdList = new LinkedList<ProtocolEntryTitanDTO>();
		ppdList.add(new ProtocolEntryTitanDTO("point1",5,5,6,6,8,8));
		ppdList.add(new ProtocolEntryTitanDTO("point2",5,5,7,7,8,8));
		ppdList.add(new ProtocolEntryTitanDTO("point3",5,5,8,8,6,6));
		ppdList.add(new ProtocolEntryTitanDTO("point4",5,5,9,9,8,8));
		ppdList.add(new ProtocolEntryTitanDTO("point5",5,5,10,10,7,7));
		ppdList.add(new ProtocolEntryTitanDTO("point6",5,5,11,11,8,8));

		ProtocolTitanDTO protocolTitanDTO = new ProtocolTitanDTO();			

		protocolTitanDTO.setTreatmentsPerDay(2);
		protocolTitanDTO.setType("Custom");
		protocolTitanDTO.setProtocolEntries(ppdList);
		patientProtocolTitanService.addProtocolToPatient(activeUser.getId(), protocolTitanDTO);
	}

	public void creatingDeviceHistory(User associatedUser) {
		List<UserPatientAssoc> patientUser = userPatientRepository.findByUserIdAndUserRole(associatedUser.getId(), "PATIENT");
		List<PatientDevicesAssoc> activeDevicesList = patientDevicesAssocRepository.findByPatientId(patientUser.get(0).getPatient().getId());
		PatientInfo patinetDetails = patientInfoRepository.findOne(activeDevicesList.get(0).getPatientId());
		for(PatientDevicesAssoc activeDevices:activeDevicesList) {
			if(activeDevices.getDeviceType().equalsIgnoreCase(Constants.VEST)) { 

				PatientVestDeviceHistory deviceHistory = new PatientVestDeviceHistory( new PatientVestDevicePK(patinetDetails, activeDevices.getSerialNumber()),
						null, null, true, "admin@localhost.com",DateTime.now());
				patientVestDeviceRepository.save(deviceHistory);
			} else if(activeDevices.getDeviceType().equalsIgnoreCase(Constants.MONARCH)){
				PatientVestDeviceHistoryMonarch deviceHistoryMonarch = new PatientVestDeviceHistoryMonarch(new PatientVestDevicePK(patinetDetails, activeDevices.getSerialNumber()),
						null, null,null, true,"admin@localhost.com");
				patientMonarchDeviceRepository.save(deviceHistoryMonarch);
			}else if(activeDevices.getDeviceType().equalsIgnoreCase(Constants.TITAN)){
				PatientVestDeviceHistoryTitan deviceHistoryTitan = new PatientVestDeviceHistoryTitan(new PatientVestDevicePK(patinetDetails, activeDevices.getSerialNumber()),
						null, null,null, true,"admin@localhost.com");
				patientTitanDeviceRepository.save(deviceHistoryTitan);
			}
		}
	}

	private TherapySession rawTherapySessionVestNormal(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySession therapySession = new TherapySession();
		therapySession.setSerialNumber(deviceSerialNumber);
		therapySession.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySession.setFrequency(15);
		therapySession.setPressure(10);
		therapySession.setBluetoothId(deviceSerialNumber);
		therapySession.setDurationInMinutes(30);
		therapySession.setNormalCaughPauses(0);
		therapySession.setProgrammedCaughPauses(0);
		therapySession.setCaughPauseDuration(0);
		therapySession.setHmr(hmr);
		therapySession.setSessionType("Normal");
		DateTime startTime = new DateTime(timeStamp);
		therapySession.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySession.setEndTime(endTime);
		therapySession.setPatientInfo(patient);
		therapySession.setPatientUser(patientUser);
		therapySession.setSessionNo(sessionNo);
		return therapySession;
	}

	private TherapySession rawTherapySessionVestProgram(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySession therapySession = new TherapySession();
		therapySession.setSerialNumber(deviceSerialNumber);
		therapySession.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySession.setFrequency(15);
		therapySession.setPressure(10);
		therapySession.setDurationInMinutes(30);
		therapySession.setNormalCaughPauses(0);
		therapySession.setProgrammedCaughPauses(0);
		therapySession.setCaughPauseDuration(0);
		therapySession.setBluetoothId(deviceSerialNumber);
		therapySession.setHmr(hmr);
		therapySession.setSessionType("Program");
		DateTime startTime = new DateTime(timeStamp);
		therapySession.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySession.setEndTime(endTime);
		therapySession.setPatientInfo(patient);
		therapySession.setPatientUser(patientUser);
		therapySession.setSessionNo(sessionNo);
		return therapySession;
	}
	
	private TherapySessionMonarch rawTherapySessionMonarchNormal(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySessionMonarch therapySessionMonarch = new TherapySessionMonarch();
		therapySessionMonarch.setSerialNumber(deviceSerialNumber);
		//therapySession.setBluetoothId(groupEntries.get(0).getBluetoothId());
		therapySessionMonarch.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySessionMonarch.setFrequency(15);
		therapySessionMonarch.setIntensity(10);
		therapySessionMonarch.setDurationInMinutes(30);
		therapySessionMonarch.setNormalCaughPauses(0);
		therapySessionMonarch.setProgrammedCaughPauses(0);
		therapySessionMonarch.setCaughPauseDuration(0);
		
		therapySessionMonarch.setHmr(hmr);
		therapySessionMonarch.setSessionType("Normal");
		DateTime startTime = new DateTime(timeStamp);
		therapySessionMonarch.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySessionMonarch.setEndTime(endTime);
		therapySessionMonarch.setPatientInfo(patient);
		therapySessionMonarch.setPatientUser(patientUser);
		therapySessionMonarch.setSessionNo(sessionNo);
		therapySessionMonarch.setTherapyIndex(sessionNo);
		therapySessionMonarch.setStartBatteryLevel(90);
		therapySessionMonarch.setEndBatteryLevel(70);
		
		return therapySessionMonarch;	
	}

	private TherapySessionMonarch rawTherapySessionMonarchProgram(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySessionMonarch therapySessionMonarch = new TherapySessionMonarch();
		therapySessionMonarch.setSerialNumber(deviceSerialNumber);
		//therapySession.setBluetoothId(groupEntries.get(0).getBluetoothId());
		therapySessionMonarch.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySessionMonarch.setFrequency(15);
		therapySessionMonarch.setIntensity(6);
		therapySessionMonarch.setDurationInMinutes(30);
		therapySessionMonarch.setNormalCaughPauses(0);
		therapySessionMonarch.setProgrammedCaughPauses(0);
		therapySessionMonarch.setCaughPauseDuration(0);
		
		therapySessionMonarch.setHmr(hmr);
		therapySessionMonarch.setSessionType("Program");
		DateTime startTime = new DateTime(timeStamp);
		therapySessionMonarch.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySessionMonarch.setEndTime(endTime);
		therapySessionMonarch.setPatientInfo(patient);
		therapySessionMonarch.setPatientUser(patientUser);
		therapySessionMonarch.setSessionNo(sessionNo);
		therapySessionMonarch.setTherapyIndex(sessionNo);
		therapySessionMonarch.setStartBatteryLevel(90);
		therapySessionMonarch.setEndBatteryLevel(70);
		
		return therapySessionMonarch;	
	}

	private TherapySessionTitan rawTherapySessionTitanNormal(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySessionTitan therapySessionTitan = new TherapySessionTitan();
		therapySessionTitan.setSerialNumber(deviceSerialNumber);
		//therapySession.setBluetoothId(groupEntries.get(0).getBluetoothId());
		therapySessionTitan.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySessionTitan.setFrequency(15);
		therapySessionTitan.setDurationInMinutes(30);
		therapySessionTitan.setCaughAutoEnable(0);	
		therapySessionTitan.setCaughIntervalMode(0);
		therapySessionTitan.setCaughPauseEnable(0);
		therapySessionTitan.setCaughPauseInterval(0);
		therapySessionTitan.setCaughPauseDuration(0);
		
		therapySessionTitan.setHmr(hmr);
		therapySessionTitan.setSessionType("Normal");
		DateTime startTime = new DateTime(timeStamp);
		therapySessionTitan.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySessionTitan.setEndTime(endTime);
		therapySessionTitan.setPatientInfo(patient);
		therapySessionTitan.setPatientUser(patientUser);
		therapySessionTitan.setSessionNo(sessionNo);
		therapySessionTitan.setTherapyIndex(sessionNo);
		
		return therapySessionTitan;	
	}
	
	private TherapySessionTitan rawTherapySessionTitanProgram(String deviceSerialNumber, PatientInfo patient, Integer sessionNo, User patientUser, Long timeStamp, Double hmr)
	{
		TherapySessionTitan therapySessionTitan = new TherapySessionTitan();
		therapySessionTitan.setSerialNumber(deviceSerialNumber);
		//therapySession.setBluetoothId(groupEntries.get(0).getBluetoothId());
		therapySessionTitan.setDate(LocalDate.fromDateFields(new Date(timeStamp)));
		therapySessionTitan.setFrequency(15);
		therapySessionTitan.setDurationInMinutes(30);
		therapySessionTitan.setCaughAutoEnable(0);	
		therapySessionTitan.setCaughIntervalMode(0);
		therapySessionTitan.setCaughPauseEnable(0);
		therapySessionTitan.setCaughPauseInterval(0);
		therapySessionTitan.setCaughPauseDuration(0);
		
		therapySessionTitan.setHmr(hmr);
		therapySessionTitan.setSessionType("Program");
		DateTime startTime = new DateTime(timeStamp);
		therapySessionTitan.setStartTime(startTime);
		DateTime endTime = startTime.plusMinutes(30);
		therapySessionTitan.setEndTime(endTime);
		therapySessionTitan.setPatientInfo(patient);
		therapySessionTitan.setPatientUser(patientUser);
		therapySessionTitan.setSessionNo(sessionNo);
		therapySessionTitan.setTherapyIndex(sessionNo);
		
		return therapySessionTitan;	
	}
	private List<PatientVestDeviceDataMonarch> rawMonarchDeviceDataManual(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceDataMonarch> deviceDataEventList = new ArrayList<PatientVestDeviceDataMonarch>();
		Long currentTimeStamp = timeInMillis;
		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchPK = new PatientVestDeviceDataMonarchPK(currentTimeStamp, "1", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch patientVestDeviceData = new 
				PatientVestDeviceDataMonarch(1, deviceSerialNumber, hmr, 15, 10, 30, patientVestDeviceDataMonarchPK, patientUser,90,70);
		deviceDataEventList.add(patientVestDeviceData);
		Long durationToMillies = (long) (30 * (60 * 1000));
		hmr = hmr + ((30) * (60));
		patientVestDeviceDataMonarchPK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + (durationToMillies), "3", deviceSerialNumber, patient);
		patientVestDeviceData = new PatientVestDeviceDataMonarch(2,deviceSerialNumber,hmr,15,10,30,patientVestDeviceDataMonarchPK,patientUser,90,70);

		deviceDataEventList.add(patientVestDeviceData);
		return deviceDataEventList;		
	}
	

	private List<PatientVestDeviceDataMonarch> rawMonarchDeviceDataProgram(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceDataMonarch> deviceDataEventList = new ArrayList<PatientVestDeviceDataMonarch>();
		Long currentTimeStamp = timeInMillis;
		hmr = hmr +1800;
		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP1PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp, "7", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p1StartData = new 
				PatientVestDeviceDataMonarch(1, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP1PK, patientUser,90,70);
		deviceDataEventList.add(p1StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP2PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 300000L, "8", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p2StartData = new 
				PatientVestDeviceDataMonarch(2, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP2PK, patientUser,90,70);

		deviceDataEventList.add(p2StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP3PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 600000L, "9", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p3StartData = new 
				PatientVestDeviceDataMonarch(3, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP3PK, patientUser,90,70);

		deviceDataEventList.add(p3StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP4PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 900000L, "10", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p4StartData = new 
				PatientVestDeviceDataMonarch(4, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP4PK, patientUser,90,70);

		deviceDataEventList.add(p4StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP5PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1200000L, "11", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p5StartData = new 
				PatientVestDeviceDataMonarch(5, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP5PK, patientUser,90,70);

		deviceDataEventList.add(p5StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchP6PK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1500000L, "12", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch p6StartData = new 
				PatientVestDeviceDataMonarch(6, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchP6PK, patientUser,90,70);

		deviceDataEventList.add(p6StartData);

		PatientVestDeviceDataMonarchPK patientVestDeviceDataMonarchCompletePK = new PatientVestDeviceDataMonarchPK(currentTimeStamp + 1800000L, "15", deviceSerialNumber, patient);
		PatientVestDeviceDataMonarch eventCompletedData = new 
				PatientVestDeviceDataMonarch(7, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataMonarchCompletePK, patientUser,90,70);

		deviceDataEventList.add(eventCompletedData);
		return deviceDataEventList;		
	}

	private List<PatientVestDeviceData> rawVestDeviceDataManual(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceData> deviceDataEventList = new ArrayList<PatientVestDeviceData>();
		Long currentTimeStamp = timeInMillis;
		PatientVestDeviceDataPK patientVestDeviceDataPK  = new PatientVestDeviceDataPK(currentTimeStamp,deviceSerialNumber,"1:SessionEventCodeNormalStarted",patient);
		PatientVestDeviceData patientVestDeviceData = new
				PatientVestDeviceData(1,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataPK,hmr,15,6,30,patientUser);
		
		deviceDataEventList.add(patientVestDeviceData);
		Long durationToMillies = (long) (30 * (60 * 1000));
		hmr = hmr + ((30) * (60));
		patientVestDeviceDataPK  = new PatientVestDeviceDataPK(currentTimeStamp + (durationToMillies),deviceSerialNumber,"3:SessionEventCodeCompleted",patient);
		patientVestDeviceData = new PatientVestDeviceData(2,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataPK,hmr,0,0,0,patientUser);
		deviceDataEventList.add(patientVestDeviceData);
		return deviceDataEventList;		
	}

	private List<PatientVestDeviceData> rawVestDeviceDataProgram(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceData> deviceDataEventList = new ArrayList<PatientVestDeviceData>();
		Long currentTimeStamp = timeInMillis;
		PatientVestDeviceDataPK patientVestDeviceDataP1PK  = new PatientVestDeviceDataPK(currentTimeStamp,deviceSerialNumber,"7:SessionEventCodeProgramPt1Started",patient);
		PatientVestDeviceData p1StartData = new
				PatientVestDeviceData(1,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP1PK,hmr,15,6,5,patientUser);
		deviceDataEventList.add(p1StartData);


		PatientVestDeviceDataPK patientVestDeviceDataP2PK  = new PatientVestDeviceDataPK(currentTimeStamp + 300000L,deviceSerialNumber,"8:SessionEventCodeProgramPt2Started",patient);
		PatientVestDeviceData p2StartData = new
				PatientVestDeviceData(2,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP2PK,hmr+300,15,6,5,patientUser);

		deviceDataEventList.add(p2StartData);

		PatientVestDeviceDataPK patientVestDeviceDataP3PK  = new PatientVestDeviceDataPK(currentTimeStamp + 600000L ,deviceSerialNumber,"9:SessionEventCodeProgramPt3Started",patient);
		PatientVestDeviceData p3StartData = new
				PatientVestDeviceData(3,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP3PK,hmr+600,15,6,5,patientUser);

		deviceDataEventList.add(p3StartData);

		PatientVestDeviceDataPK patientVestDeviceDataP4PK  = new PatientVestDeviceDataPK(currentTimeStamp + 900000L ,deviceSerialNumber,"10:SessionEventCodeProgramPt4Started",patient);
		PatientVestDeviceData p4StartData = new
				PatientVestDeviceData(4,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP4PK,hmr+900,15,6,5,patientUser);

		deviceDataEventList.add(p4StartData);

		PatientVestDeviceDataPK patientVestDeviceDataP5PK  = new PatientVestDeviceDataPK(currentTimeStamp + 1200000L ,deviceSerialNumber,"11:SessionEventCodeProgramPt5Started",patient);
		PatientVestDeviceData p5StartData = new
				PatientVestDeviceData(5,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP5PK,hmr+1200,15,6,5,patientUser);

		deviceDataEventList.add(p5StartData);

		PatientVestDeviceDataPK patientVestDeviceDataP6PK  = new PatientVestDeviceDataPK(currentTimeStamp + 1500000L ,deviceSerialNumber,"12:SessionEventCodeProgramPt6Started",patient);
		PatientVestDeviceData p6StartData = new
				PatientVestDeviceData(6,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataP6PK,hmr+1500,15,6,5,patientUser);

		deviceDataEventList.add(p6StartData);

		PatientVestDeviceDataPK patientVestDeviceDataCompletePK  = new PatientVestDeviceDataPK(currentTimeStamp + 1800000L,deviceSerialNumber,"16:SessionEventCodeProgramCompleted",patient);
		PatientVestDeviceData eventCompletedData = new
				PatientVestDeviceData(7,deviceSerialNumber,deviceSerialNumber,patientVestDeviceDataCompletePK,hmr+1800,0,0,0,patientUser);

		deviceDataEventList.add(eventCompletedData);
		return deviceDataEventList;		
	}

	private List<PatientVestDeviceDataTitan> rawTitanDeviceDataManual(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceDataTitan> deviceDataEventList = new ArrayList<PatientVestDeviceDataTitan>();
		Long currentTimeStamp = timeInMillis;
		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanPK = new PatientVestDeviceDataTitanPK(currentTimeStamp, "1", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan patientVestDeviceData = new 
				PatientVestDeviceDataTitan(1, deviceSerialNumber, hmr, 15, 10, 30, patientVestDeviceDataTitanPK, patientUser);
		deviceDataEventList.add(patientVestDeviceData);
		Long durationToMillies = (long) (30 * (60 * 1000));
		hmr = hmr + ((30) * (60));
		patientVestDeviceDataTitanPK = new PatientVestDeviceDataTitanPK(currentTimeStamp + (durationToMillies), "3", deviceSerialNumber, patient);
		patientVestDeviceData = new PatientVestDeviceDataTitan(2,deviceSerialNumber,hmr,15,10,30,patientVestDeviceDataTitanPK,patientUser);

		deviceDataEventList.add(patientVestDeviceData);
		return deviceDataEventList;		
	}
	
	private List<PatientVestDeviceDataTitan> rawTitanDeviceDataProgram(String deviceSerialNumber,PatientInfo patient, User patientUser, Long timeInMillis, Double hmr) {
		List<PatientVestDeviceDataTitan> deviceDataEventList = new ArrayList<PatientVestDeviceDataTitan>();
		Long currentTimeStamp = timeInMillis;
		hmr = hmr +1800;
		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP1PK = new PatientVestDeviceDataTitanPK(currentTimeStamp, "7", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p1StartData = new 
				PatientVestDeviceDataTitan(1, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP1PK, patientUser);
		deviceDataEventList.add(p1StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP2PK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 300000L, "8", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p2StartData = new 
				PatientVestDeviceDataTitan(2, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP2PK, patientUser);

		deviceDataEventList.add(p2StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP3PK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 600000L, "9", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p3StartData = new 
				PatientVestDeviceDataTitan(3, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP3PK, patientUser);

		deviceDataEventList.add(p3StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP4PK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 900000L, "10", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p4StartData = new 
				PatientVestDeviceDataTitan(4, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP4PK, patientUser);

		deviceDataEventList.add(p4StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP5PK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 1200000L, "11", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p5StartData = new 
				PatientVestDeviceDataTitan(5, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP5PK, patientUser);

		deviceDataEventList.add(p5StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanP6PK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 1500000L, "12", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan p6StartData = new 
				PatientVestDeviceDataTitan(6, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanP6PK, patientUser);

		deviceDataEventList.add(p6StartData);

		PatientVestDeviceDataTitanPK patientVestDeviceDataTitanCompletePK = new PatientVestDeviceDataTitanPK(currentTimeStamp + 1800000L, "15", deviceSerialNumber, patient);
		PatientVestDeviceDataTitan eventCompletedData = new 
				PatientVestDeviceDataTitan(7, deviceSerialNumber, hmr, 15, 6, 5, patientVestDeviceDataTitanCompletePK, patientUser);

		deviceDataEventList.add(eventCompletedData);
		return deviceDataEventList;		
	}
	
	public void createRawTherapyDataForPatient(String hillromId, LocalDate from, LocalDate to){
		Optional<PatientInfo> patientInfo = patientInfoRepository.findOneByHillromId(hillromId);
		Optional<User> associatedUser = userRepository.findOneByHillromId(hillromId);
		
		if(patientInfo.isPresent() && associatedUser.isPresent()) {
			createRawTherapyData(from, to, patientInfo.get(), associatedUser.get());
		}
	}
	
	public void createRawTherapyData(LocalDate from, LocalDate to, PatientInfo patientObj, User patientUser)
	{
		List<LocalDate> dateList = new ArrayList<LocalDate>();;
		List<PatientInfo> patientList100 = new ArrayList<PatientInfo>();;
		List<PatientInfo> patientList80 = new ArrayList<PatientInfo>();;
		List<PatientInfo> patientList50 = new ArrayList<PatientInfo>();;
		if(Objects.nonNull(patientObj)){
			if(patientObj.getPrimaryDiagnosis().equals("100%")) {
				patientList100.add(patientObj);
			}else if(patientObj.getPrimaryDiagnosis().equals("80%")) {
				patientList80.add(patientObj);
			}else if(patientObj.getPrimaryDiagnosis().equals("50%")) {
				patientList50.add(patientObj);
			}else {
				return;
			}
		}
		
		for(LocalDate date = from; (date.isBefore(to) || date.isEqual(to)); date = date.plusDays(1)) {
			for(PatientInfo patient :patientList100){
				dateList.add(date);
			}
	
			Boolean valid80 = false;
			
			switch(date.getDayOfWeek()) {
				case DateTimeConstants.SUNDAY:
				case DateTimeConstants.MONDAY:
				case DateTimeConstants.THURSDAY:
				case DateTimeConstants.FRIDAY:
				case DateTimeConstants.SATURDAY:
					{
						valid80 = true;
					}
					break;
				default:{
						valid80 = false;
					}
					break;
			}
			
			if(valid80 == true) {
				for(PatientInfo patient :patientList80){
					dateList.add(date);
				}
			}
			
			Boolean valid50 = false;
			
			switch(date.getDayOfWeek()) {
				case DateTimeConstants.WEDNESDAY:
				case DateTimeConstants.SATURDAY:
					{
						valid50 = true;
					}
					break;
				default:{
						valid50 = false;
					}
					break;
			}
			
			if(valid50 == true) {
				for(PatientInfo patient :patientList50){
					dateList.add(date);
				}
			}
		}
		
		createRawTherapySessions(patientObj, patientUser, dateList);
	}

	public void createRawTherapySessions(PatientInfo patient, User patientUser, List<LocalDate> dateList) {
		List<PatientDevicesAssoc> activeDevicesList = patientDevicesAssocRepository.findByPatientId(patient.getId());
		if(Objects.nonNull(activeDevicesList)) {
			Boolean vest = false;
			Boolean monarch = false;
			Boolean titan = false;
			String vestSerialNumber = null;
			String monarchSerialNumber = null;
			String titanSerialNumber = null;
			String vestProtocolType = null;
			String monarchProtocolType = null;
			String titanProtocolType = null;
			for (PatientDevicesAssoc patientDevicesAssoc : activeDevicesList) {
				if(patientDevicesAssoc.getDeviceType().equals(Constants.VEST)) {
					vest = true;
					vestSerialNumber = patientDevicesAssoc.getSerialNumber();
					List<PatientProtocolData> patientProtocolDataList = patientProtocolRepository.findByPatientIdAndActiveStatus(patientDevicesAssoc.getPatientId());
					vestProtocolType = patientProtocolDataList.get(0).getType();
				}
				if(patientDevicesAssoc.getDeviceType().equals(Constants.MONARCH)) {
					monarch = true;
					monarchSerialNumber = patientDevicesAssoc.getSerialNumber();
					List<PatientProtocolDataMonarch> patientProtocolDataList = patientProtocolMonarchRepository.findByPatientIdAndActiveStatus(patientDevicesAssoc.getPatientId());
					monarchProtocolType = patientProtocolDataList.get(0).getType();
				}
				if(patientDevicesAssoc.getDeviceType().equals(Constants.TITAN)) {
					titan = true;
					titanSerialNumber = patientDevicesAssoc.getSerialNumber();
					List<PatientProtocolDataTitan> patientProtocolDataList = patientProtocolTitanRepository.findByPatientIdAndActiveStatus(patientDevicesAssoc.getPatientId());
					titanProtocolType = patientProtocolDataList.get(0).getType();
				}
			}
			
			List<TherapySession> therapySessions = new ArrayList<TherapySession>();
			List<TherapySessionMonarch> therapySessionsMonarch = new ArrayList<TherapySessionMonarch>();
			List<TherapySessionTitan> therapySessionsTitan = new ArrayList<TherapySessionTitan>();
			List<PatientVestDeviceData> deviceData = new ArrayList<PatientVestDeviceData>();
			List<PatientVestDeviceDataMonarch> deviceDataMonarch = new ArrayList<PatientVestDeviceDataMonarch>();
			List<PatientVestDeviceDataTitan> deviceDataTitan = new ArrayList<PatientVestDeviceDataTitan>();
			Double vestHmr = 0.0;
			Double monarchHmr = 0.0;
			Double titanHmr = 0.0;
			
			for (LocalDate date : dateList) {
				if(monarch)
				{
					DateTime mor = date.toDateTimeAtStartOfDay().plusHours(13);
					DateTime eve = date.toDateTimeAtStartOfDay().plusHours(23);
					try {
						if(monarchProtocolType.equalsIgnoreCase("Normal")){
							deviceDataMonarch.addAll(rawMonarchDeviceDataManual(monarchSerialNumber, patient, patientUser, mor.getMillis(), monarchHmr));
							monarchHmr = monarchHmr +(30*60);
							therapySessionsMonarch.add(rawTherapySessionMonarchNormal(monarchSerialNumber, patient, 1, patientUser, mor.getMillis(), monarchHmr));
							if(!vest) {
								deviceDataMonarch.addAll(rawMonarchDeviceDataManual(monarchSerialNumber, patient, patientUser, eve.getMillis(), monarchHmr));
								monarchHmr = monarchHmr +(30*60);							
								therapySessionsMonarch.add(rawTherapySessionMonarchNormal(monarchSerialNumber, patient, 1, patientUser, eve.getMillis(), monarchHmr));
							}
						}else {
							deviceDataMonarch.addAll(rawMonarchDeviceDataProgram(monarchSerialNumber, patient, patientUser, mor.getMillis(), monarchHmr));
							monarchHmr = monarchHmr +(30*60);
							therapySessionsMonarch.add(rawTherapySessionMonarchProgram(monarchSerialNumber, patient, 1, patientUser, mor.getMillis(), monarchHmr));
							if(!vest) 
							{
								deviceDataMonarch.addAll(rawMonarchDeviceDataProgram(monarchSerialNumber, patient, patientUser, eve.getMillis(), monarchHmr));
								monarchHmr = monarchHmr +(30*60);							
								therapySessionsMonarch.add(rawTherapySessionMonarchProgram(monarchSerialNumber, patient, 1, patientUser, eve.getMillis(), monarchHmr));
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(vest) {
					DateTime mor = date.toDateTimeAtStartOfDay().plusHours(8);
					DateTime eve = date.toDateTimeAtStartOfDay().plusHours(19);
					try {
						if(vestProtocolType.equalsIgnoreCase("Normal")){
							if(!monarch) {
								deviceData.addAll(rawVestDeviceDataManual(vestSerialNumber, patient, patientUser, mor.getMillis(), vestHmr));
								vestHmr = vestHmr +(30*60);
								therapySessions.add(rawTherapySessionVestNormal(vestSerialNumber, patient, 1, patientUser, mor.getMillis(), vestHmr));
							}
							deviceData.addAll(rawVestDeviceDataManual(vestSerialNumber, patient, patientUser, eve.getMillis(), vestHmr));
							vestHmr = vestHmr +(30*60);							
							therapySessions.add(rawTherapySessionVestNormal(vestSerialNumber, patient, 1, patientUser, eve.getMillis(), vestHmr));
						}else {
							if(!monarch && !titan)
							{
								deviceData.addAll(rawVestDeviceDataProgram(vestSerialNumber, patient, patientUser, mor.getMillis(), vestHmr));
								vestHmr = vestHmr +(30*60);
								therapySessions.add(rawTherapySessionVestProgram(vestSerialNumber, patient, 1, patientUser, mor.getMillis(), vestHmr));
							}
							deviceData.addAll(rawVestDeviceDataProgram(vestSerialNumber, patient, patientUser, eve.getMillis(), vestHmr));
							vestHmr = vestHmr +(30*60);							
							therapySessions.add(rawTherapySessionVestProgram(vestSerialNumber, patient, 1, patientUser, eve.getMillis(), vestHmr));						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				}
				if(titan) {
					DateTime mor = date.toDateTimeAtStartOfDay().plusHours(13);
					DateTime eve = date.toDateTimeAtStartOfDay().plusHours(23);
					try {
						if(titanProtocolType.equalsIgnoreCase("Normal")){
							deviceDataTitan.addAll(rawTitanDeviceDataManual(titanSerialNumber, patient, patientUser, mor.getMillis(), titanHmr));
							titanHmr = titanHmr +(30*60);
							therapySessionsTitan.add(rawTherapySessionTitanNormal(titanSerialNumber, patient, 1, patientUser, mor.getMillis(), titanHmr));
							if(!monarch && !vest) {
								deviceDataTitan.addAll(rawTitanDeviceDataManual(titanSerialNumber, patient, patientUser, eve.getMillis(), titanHmr));
								titanHmr = titanHmr +(30*60);							
								therapySessionsTitan.add(rawTherapySessionTitanNormal(titanSerialNumber, patient, 1, patientUser, eve.getMillis(), titanHmr));
							}
						}else {
							deviceDataTitan.addAll(rawTitanDeviceDataProgram(titanSerialNumber, patient, patientUser, mor.getMillis(), titanHmr));
							titanHmr = titanHmr +(30*60);
							therapySessionsTitan.add(rawTherapySessionTitanProgram(titanSerialNumber, patient, 1, patientUser, mor.getMillis(), titanHmr));
							if(!vest) 
							{
								deviceDataTitan.addAll(rawTitanDeviceDataProgram(titanSerialNumber, patient, patientUser, eve.getMillis(), titanHmr));
								monarchHmr = monarchHmr +(30*60);							
								therapySessionsTitan.add(rawTherapySessionTitanProgram(titanSerialNumber, patient, 1, patientUser, eve.getMillis(), titanHmr));
							}
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
			
			if(vest) {
				patientVestDeviceDataRepository.save(deviceData);
				therapySessionRepository.save(therapySessions);
				patient.setLastVest(DateTime.now().getMillis());
				patientInfoRepository.save(patient);
				List<PatientVestDeviceHistory> deviceHistoryList = patientVestDeviceRepository
						.findOneBySerialNumberAndStatusActive(vestSerialNumber);
				if(Objects.nonNull(deviceHistoryList)) {
					deviceHistoryList.get(0).setHmr(vestHmr);
					patientVestDeviceRepository.save(deviceHistoryList);					
				}				
			}
			
			if(monarch) {
				patientMonarchDeviceDataRepository.save(deviceDataMonarch);
				therapySessionMonarchRepository.save(therapySessionsMonarch);
				patient.setLastMonarch(DateTime.now().getMillis());
				patientInfoRepository.save(patient);
				List<PatientVestDeviceHistoryMonarch> deviceHistoryList = patientMonarchDeviceRepository
						.findOneBySerialNumberAndStatusActive(monarchSerialNumber);
				if(Objects.nonNull(deviceHistoryList)) {
					deviceHistoryList.get(0).setHmr(monarchHmr);
					patientMonarchDeviceRepository.save(deviceHistoryList);					
				}
			}
			
			if(titan) {
				patientTitanDeviceDataRepository.save(deviceDataTitan);
				therapySessionTitanRepository.save(therapySessionsTitan);
				patient.setLastMonarch(DateTime.now().getMillis());
				patientInfoRepository.save(patient);
				List<PatientVestDeviceHistoryTitan> deviceHistoryList = patientTitanDeviceRepository
						.findOneBySerialNumberAndStatusActive(titanSerialNumber);
				if(Objects.nonNull(deviceHistoryList)) {
					deviceHistoryList.get(0).setHmr(monarchHmr);
					patientTitanDeviceRepository.save(deviceHistoryList);					
				}
			}

			try {
				if(vest&&monarch) {
					rawComplianceUpdateSessionMonarch(therapySessionsMonarch,dateList.get(0),dateList.get(dateList.size()-1));
				} else if(vest) {
					rawComplianceUpdateSessionVest(therapySessions,dateList.get(0),dateList.get(dateList.size()-1));
				}else if(monarch) {
					rawComplianceUpdateSessionMonarch(therapySessionsMonarch,dateList.get(0),dateList.get(dateList.size()-1));
				}else if(titan) {
					rawComplianceUpdateSessionTitan(therapySessionsTitan,dateList.get(0),dateList.get(dateList.size()-1));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void rawComplianceUpdateSessionMonarch(List<TherapySessionMonarch> therapySessions, LocalDate from, LocalDate to) {
		Map<LocalDate, List<TherapySessionMonarch>> groupedTherapySessions = therapySessions
				.stream()
				.collect(
						Collectors
						.groupingBy(TherapySessionMonarch::getDate));
		SortedMap<LocalDate,List<TherapySessionMonarch>> receivedTherapySessionMap = new TreeMap<>(groupedTherapySessions);

		noEventMonarchService.updatePatientFirstTransmittedDate(therapySessions.get(0).getPatientUser().getId(), from,therapySessions.get(0).getPatientInfo().getId());
		List<LocalDate> allDates = DateUtil.getAllLocalDatesBetweenDates(from, to);
		Integer score = DEFAULT_COMPLIANCE_SCORE;
		Double hmr = 0.0;
		Integer hmrRunrate = 0;
		PatientComplianceMonarch prevCompliance = null;
		List<PatientComplianceMonarch> complianceList = new ArrayList<PatientComplianceMonarch>();
		for (LocalDate localDate : allDates) {
			PatientComplianceMonarch currentCompliance = new PatientComplianceMonarch();
			currentCompliance.setPatient(therapySessions.get(0).getPatientInfo());
			currentCompliance.setPatientUser(therapySessions.get(0).getPatientUser());
			List<TherapySessionMonarch> currentDateTherapy = receivedTherapySessionMap.get(localDate);
			if(currentDateTherapy != null) {
				hmr = currentDateTherapy.get(currentDateTherapy.size()-1).getHmr();
				hmrRunrate = currentDateTherapy.get(currentDateTherapy.size()-1).getDurationInMinutes();
				score += 1;
				currentCompliance.setHmrCompliant(true);
				currentCompliance.setSettingsDeviated(false);
				currentCompliance.setMissedTherapyCount(0);
			}else {
				if(Objects.nonNull(prevCompliance)) {
					currentCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
					currentCompliance.setGlobalMissedTherapyCounter(prevCompliance.getGlobalMissedTherapyCounter() + 1);
				}else {
					currentCompliance.setMissedTherapyCount(1);
					currentCompliance.setGlobalMissedTherapyCounter(1);
				}
				currentCompliance.setHmrCompliant(false);
				currentCompliance.setSettingsDeviated(false);
				score -= 2;
			}

			currentCompliance.setHmr(hmr);
			currentCompliance.setHmrRunRate(hmrRunrate);
			currentCompliance.setDate(localDate);

			

			if(score > DEFAULT_COMPLIANCE_SCORE) {
				score = DEFAULT_COMPLIANCE_SCORE;
			}
			
			if(score < 0) {
				score = 0;
			}
			
			currentCompliance.setScore(score);
			
			prevCompliance = currentCompliance;
			complianceList.add(currentCompliance);
		}
		patientComplianceMonarchRepository.save(complianceList);

	}

	private void rawComplianceUpdateSessionVest(List<TherapySession> therapySessions, LocalDate from, LocalDate to) {
		Map<LocalDate, List<TherapySession>> groupedTherapySessions = therapySessions
				.stream()
				.collect(
						Collectors
						.groupingBy(TherapySession::getDate));
		SortedMap<LocalDate,List<TherapySession>> receivedTherapySessionMap = new TreeMap<>(groupedTherapySessions);

		noEventService.updatePatientFirstTransmittedDate(therapySessions.get(0).getPatientUser().getId(), from,therapySessions.get(0).getPatientInfo().getId());
		List<LocalDate> allDates = DateUtil.getAllLocalDatesBetweenDates(from, to);
		Integer score = DEFAULT_COMPLIANCE_SCORE;
		Double hmr = 0.0;
		Integer hmrRunrate = 0;
		PatientCompliance prevCompliance = null;
		List<PatientCompliance> complianceList =  new ArrayList<PatientCompliance>();
		for (LocalDate localDate : allDates) {
			PatientCompliance currentCompliance = new PatientCompliance();
			currentCompliance.setPatient(therapySessions.get(0).getPatientInfo());
			currentCompliance.setPatientUser(therapySessions.get(0).getPatientUser());
			List<TherapySession> currentDateTherapy = receivedTherapySessionMap.get(localDate);
			if(currentDateTherapy != null) {
				hmr = currentDateTherapy.get(currentDateTherapy.size()-1).getHmr();
				hmrRunrate = currentDateTherapy.get(currentDateTherapy.size()-1).getDurationInMinutes();
				score += 1;
				currentCompliance.setHmrCompliant(true);
				currentCompliance.setSettingsDeviated(false);
				currentCompliance.setMissedTherapyCount(0);
			}else {
				if(Objects.nonNull(prevCompliance)) {
					currentCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
					currentCompliance.setGlobalMissedTherapyCounter(prevCompliance.getGlobalMissedTherapyCounter() + 1);
				}else {
					currentCompliance.setMissedTherapyCount(1);
					currentCompliance.setGlobalMissedTherapyCounter(1);
				}
				currentCompliance.setHmrCompliant(false);
				currentCompliance.setSettingsDeviated(false);
				score -= 2;
			}

			currentCompliance.setHmr(hmr);
			currentCompliance.setHmrRunRate(hmrRunrate);
			currentCompliance.setDate(localDate);

			if(score > DEFAULT_COMPLIANCE_SCORE) {
				score = DEFAULT_COMPLIANCE_SCORE;
			}
			
			if(score < 0) {
				score = 0;
			}
			
			currentCompliance.setScore(score);
			
			prevCompliance = currentCompliance;
			complianceList.add(currentCompliance);
		}
		
		patientComplianceRepository.save(complianceList);

	}
	
	private void rawComplianceUpdateSessionTitan(List<TherapySessionTitan> therapySessions, LocalDate from, LocalDate to) {
		Map<LocalDate, List<TherapySessionTitan>> groupedTherapySessions = therapySessions
				.stream()
				.collect(
						Collectors
						.groupingBy(TherapySessionTitan::getDate));
		SortedMap<LocalDate,List<TherapySessionTitan>> receivedTherapySessionMap = new TreeMap<>(groupedTherapySessions);

		noEventTitanService.updatePatientFirstTransmittedDate(therapySessions.get(0).getPatientUser().getId(), from,therapySessions.get(0).getPatientInfo().getId());
		List<LocalDate> allDates = DateUtil.getAllLocalDatesBetweenDates(from, to);
		Integer score = DEFAULT_COMPLIANCE_SCORE;
		Double hmr = 0.0;
		Integer hmrRunrate = 0;
		PatientComplianceTitan prevCompliance = null;
		List<PatientComplianceTitan> complianceList = new ArrayList<PatientComplianceTitan>();
		for (LocalDate localDate : allDates) {
			PatientComplianceTitan currentCompliance = new PatientComplianceTitan();
			currentCompliance.setPatient(therapySessions.get(0).getPatientInfo());
			currentCompliance.setPatientUser(therapySessions.get(0).getPatientUser());
			List<TherapySessionTitan> currentDateTherapy = receivedTherapySessionMap.get(localDate);
			if(currentDateTherapy != null) {
				hmr = currentDateTherapy.get(currentDateTherapy.size()-1).getHmr();
				hmrRunrate = currentDateTherapy.get(currentDateTherapy.size()-1).getDurationInMinutes();
				score += 1;
				currentCompliance.setHmrCompliant(true);
				currentCompliance.setSettingsDeviated(false);
				currentCompliance.setMissedTherapyCount(0);
			}else {
				if(Objects.nonNull(prevCompliance)) {
					currentCompliance.setMissedTherapyCount(prevCompliance.getMissedTherapyCount()+1);
					currentCompliance.setGlobalMissedTherapyCounter(prevCompliance.getGlobalMissedTherapyCounter() + 1);
				}else {
					currentCompliance.setMissedTherapyCount(1);
					currentCompliance.setGlobalMissedTherapyCounter(1);
				}
				currentCompliance.setHmrCompliant(false);
				currentCompliance.setSettingsDeviated(false);
				score -= 2;
			}

			currentCompliance.setHmr(hmr);
			currentCompliance.setHmrRunRate(hmrRunrate);
			currentCompliance.setDate(localDate);

			

			if(score > DEFAULT_COMPLIANCE_SCORE) {
				score = DEFAULT_COMPLIANCE_SCORE;
			}
			
			if(score < 0) {
				score = 0;
			}
			
			currentCompliance.setScore(score);
			
			prevCompliance = currentCompliance;
			complianceList.add(currentCompliance);
		}
		patientComplianceTitanRepository.save(complianceList);

	}
	
	private void createSpiroData(LocalDate from, LocalDate to, String patientId, Long userId) {
		List<LocalDate> dateList = new ArrayList<LocalDate>();
		for(LocalDate date = from; (date.isBefore(to) || date.isEqual(to)); date = date.plusDays(1)) {
			dateList.add(date);
		}
		createSpiroData(patientId,userId,dateList);
	}
	
	private void createSpiroData(String patientId, List<LocalDate> dateList) {
		List<UserPatientAssoc> userPatient =  userPatientRepository.findOneByPatientId(patientId);
		createSpiroData(patientId, userPatient.get(0).getUser().getId(), dateList);
	}
		
	private void createSpiroData(String patientId, Long userId, List<LocalDate> dateList) {
		
		List<PatientTestResult> testReultsList = new ArrayList<PatientTestResult>();
		for (LocalDate date : dateList) {	
			double fev1L = myRandom(4.0,7.9);
			double fev1P = myRandom(3.2,8.9);
			PatientTestResult testResult = new PatientTestResult(date, fev1L, fev1L, 0, fev1P, fev1P, 0, (fev1L/fev1P)*100, "Portal created", "SPIRO");
			testResult.setPatientInfo(patientInfoRepository.getOne(patientId));
			testResult.setUser(userRepository.getOne(userId));
			testReultsList.add(testResult);
		}
		
		patientTestResultRepository.save(testReultsList);
	}
	
	double myRandom(double min, double max) {
	    Random r = new Random();
	    return (r.nextInt((int)((max-min)*10+1))+min*10) / 10.0;
	}
}